#!/usr/bin/env python
# -*- coding: utf8 -*-
"""
  Author: shenhao02@baidu.com
  Date  : 21/06/25 15:29:40
  File  : tool/get_embedding.py
  Desc  : 
"""

import sys
import urllib.parse
import urllib.request
import json

def generator_data(input_file, batch_size=128):
    """
    generator_data
    """
    text_list = list()
    info_list = list()
    def get_data(text_list, info_list):
        """
        get data

        """
        return text_list, info_list

    with open(input_file, "r", encoding="utf8") as fr:
        for line in fr:
            each_list = line.strip().split("\t")
            try:
                text = each_list[0]
                info_ad = each_list[1]
            except:
                continue
            if len(text_list) == batch_size:
                yield get_data(text_list, info_list)
                text_list = []
                info_list = []
            #print(type(each_text))
            text_list.append(text)
            info_list.append(info_ad)

        if len(text_list) > 0:
            yield get_data(text_list, info_list)

def get_each_vector(result_data, embedding_size=128):
    """
    deal result
    """
    result_list = result_data["result"]
    vector_list = result_list[0]["value"]
    all_vector_list = []
    cur_vec = []
    for vec in vector_list:
        if len(cur_vec) == embedding_size - 1:
            cur_vec.append(vec)
            all_vector_list.append(cur_vec)
            cur_vec = []
        else:
            cur_vec.append(vec)
    return all_vector_list

def get_result(input_file, result_file):
    """
    get result
    """
    url = 'http://10.255.121.18:8099/v1/services/batch_req'
    with open(result_file, "w", encoding="utf8")as fw:
        for cur_batch in generator_data(input_file):
            text_list, info_list = cur_batch
            data = {"texts_a": text_list}
            data = json.dumps(data).encode("utf8")
            req = urllib.request.Request(url)
            post_res_str = urllib.request.urlopen(req, data=data).read()
            #post_res_str = urllib2.urlopen(url, data).read()
            result_data = json.loads(post_res_str)
            all_vector = get_each_vector(result_data)
            for info, text, cur_vec in zip(info_list, text_list, all_vector):
                fw.write("%s\t%s\t%s\n" % (text, info, json.dumps(cur_vec)))
            

if __name__ == "__main__":
    input_file = sys.argv[1]
    result_file = sys.argv[2]
    get_result(input_file, result_file)

