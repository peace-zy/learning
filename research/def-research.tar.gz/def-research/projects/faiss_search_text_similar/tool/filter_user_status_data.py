#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: work@baidu.com
  Date  : 21/07/16 14:44:50
  File  : tool/filter_user_status_data.py
  Desc  : filter ��Ч�˻�
"""

import sys
import copy

def load_data(input_file):
    """
    load
    """
    user_unknown = set()
    with open(input_file, "r", encoding="utf8") as fr:
        for line in fr:
            each_list = line.strip().split("\t")
            userid = each_list[0]
            user_status = each_list[1]
            if user_status == "2" or user_status == "3":
                user_unknown.add(userid)
    return user_unknown

def main(all_data_file, final_data_file, user_info):
    """
    main
    """
    user_unknown = load_data(user_info)
    with open(all_data_file, "r", encoding="utf8") as fr, open(final_data_file, "w", encoding="utf8") as fw:
        for line in fr:
            #each_list = line.strip().decode("utf8").split("\t")
            each_list = line.strip().split("\t")
            text = each_list[0]
            info = each_list[1]
            embed = each_list[2]
            info_list = info.split("|")
            final_list = copy.deepcopy(info_list)
            for each_info in info_list:
                each_user = each_info.split("\x01")[0]
                if each_user not in user_unknown:
                    final_list.remove(each_info)
            if len(final_list) == 0:
                continue
            #fw.write("\t".join([text, "|".join(final_list), embed]).encode("utf8") + "\n")
            fw.write("\t".join([text, "|".join(final_list), embed]) + "\n")


if __name__ == "__main__":
    all_data = sys.argv[1]
    final_data = sys.argv[2]
    user_info = sys.argv[3]
    main(all_data, final_data, user_info)

