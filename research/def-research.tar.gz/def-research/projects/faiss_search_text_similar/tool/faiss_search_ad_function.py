"""
  Author: shenhao02@baidu.com
  Date  : 21/07/05 18:01:16
  File  : faiss_search_ad_function.py
"""
import os
import sys
import numpy as np
import json
import logging
import urllib.parse
import urllib.request
import faiss
import time

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../lib/common/" % (_cur_dir))

import logger
logger.init_log("sim_data/faiss_search_log")

class FaissSearch(object):
    """
    faiss search��������
    """
    def __init__(self, embedding_file):
        """
        init
        """
        self.embeding_url = 'http://10.255.121.18:8099/v1/services/batch_req'
        self.dim = 128
        self.nlist = 100
        self.embedding_file = embedding_file

    def init(self):
        """
        ������Ч��Ϣ
        """
        self.id_text, self.id_info, self.vector_list = self.get_train_data(self.embedding_file)
        self.train_vector = np.array(self.vector_list).astype("float32")
        quantizer = faiss.IndexFlatL2(self.dim)
        self.index = faiss.IndexIVFFlat(quantizer, self.dim, self.nlist, faiss.METRIC_INNER_PRODUCT) 
        self.index.nprobe = 30
        faiss.normalize_L2(self.train_vector)
        start_train = time.time()
        self.index.train(self.train_vector) 
        end_train = time.time()
        logging.info("faiss train index cost time: " + str(end_train - start_train) + "s")
        self.index.add(self.train_vector)

    def get_train_data(self, input_file):
        """
        ���ѵ������
        """
        id_text = dict()
        id_info = dict()
        vector_list = list()
        with open(input_file, "r", encoding="utf8") as fr:
            index = 0
            for line in fr:
                each_list = line.strip().split("\t")
                text = each_list[0]
                info_data = each_list[1]
                text_vec = json.loads(each_list[2])
                id_text[index] = text
                id_info[index] = info_data
                vector_list.append(text_vec)
                index += 1
        return id_text, id_info, vector_list

    def get_each_vector(self, result_data, embedding_size=128):
        """
        ����ض�
        """
        result_list = result_data["result"]
        vector_list = result_list[0]["value"]
        all_vector_list = []
        cur_vec = []
        for vec in vector_list:
            if len(cur_vec) == embedding_size - 1:
                cur_vec.append(vec)
                all_vector_list.append(cur_vec)
                cur_vec = []
            else:
                cur_vec.append(vec)
        return all_vector_list

    def get_sim_data(self, text_list, top_k):
        """
        """
        data = {"texts_a": text_list}
        data = json.dumps(data).encode("utf8")
        req = urllib.request.Request(self.embeding_url)
        response = urllib.request.urlopen(req, data=data).read()
        result_data = json.loads(response)
        all_vector = self.get_each_vector(result_data)
        user_vector = np.array(all_vector).astype("float32")
        faiss.normalize_L2(user_vector)
        D, I = self.index.search(user_vector, top_k)
        result_list = []
        for i in range(len(text_list)):
            cur_text_list = []
            logging.info("cur text: "+ text_list[i])
            logging.info("sim search result: ")
            cur_text_list.append(text_list[i])
            for j in range(len(I[i])):
                logging.info(self.id_text[I[i][j]])
                logging.info(self.id_info[I[i][j]])
                logging.info(D[i][j])
                cur_tuple = [self.id_text[I[i][j]], self.id_info[I[i][j]], str(D[i][j])]
                cur_text_list.append(json.dumps(cur_tuple))
            result_list.append(cur_text_list)
        return result_list
