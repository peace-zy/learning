#!/usr/bin/env python
# -*- coding:gb18030 -*-
########################################################################
# 
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: tool/faiss_serach_tornado_service.py
Author: shenhao02(shenhao02@baidu.com)
Date: 2021/07/15 14:46:08
"""

import os
import sys
import time
import logging
import json

import tornado.httpserver
import tornado.ioloop
import tornado.options
import tornado.web

from tornado.options import define, options
from faiss_search_ad_function import FaissSearch

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../lib/common/" % (_cur_dir))

import logger
logger.init_log("sim_data/faiss_search_log")

class IndexHandler(tornado.web.RequestHandler):
    """��������
    """
    def initialize(self, model, check_history):
        """
        ��ʼ��
        """
        self.check_history = check_history
        self.model = model

    def get(self):
        """
        get
        """
        self.render('index.html', check_history=self.check_history)

    def post(self):
        """
        post
        """
        text_list = []
        text = self.get_argument('text')
        logging.info("text: {}".format(text))
        text_list.append(text)
        #Ĭ��Ϊ10��ǰ��չʾΪ10
        result_list = self.model.get_sim_data(text_list, 10)
        query_info_list = result_list[0]
        query_text = query_info_list[0]
        sim_text_list = []
        sim_text_user_list = []
        sim_text_ad_list = []
        sim_text_prob_list = []
        for text_sim_str in query_info_list[1:]:
            text_sim_list = json.loads(text_sim_str)
            text_sim_data = text_sim_list[0]
            logging.info(text_sim_data)
            text_sim_user = text_sim_list[1].split("|")[0].split("\x01")[0]
            text_sim_ad = text_sim_list[1].split("|")[0].split("\x01")[1]
            text_sim_info = "\t".join([text_sim_user, text_sim_ad])
            logging.info(text_sim_info)
            text_sim_prob = text_sim_list[2]
            logging.info(text_sim_prob)
            sim_text_list.append(text_sim_data)
            sim_text_user_list.append(text_sim_user)
            sim_text_ad_list.append(text_sim_ad)
            sim_text_prob_list.append(text_sim_prob)
        final_result = []
        final_result.append(query_text)
        for i in range(len(sim_text_list)):
            final_result.append(sim_text_list[i])

        for i in range(len(sim_text_user_list)):
            final_result.append(sim_text_user_list[i])

        for i in range(len(sim_text_ad_list)):
            final_result.append(sim_text_ad_list[i])

        for i in range(len(sim_text_prob_list)):
            final_result.append(sim_text_prob_list[i])
        self.check_history.insert(0, final_result)
        if len(self.check_history) > 100:
            self.check_history.pop()
        self.render('index.html', check_history=self.check_history)

class FaissSearchService(object):
    """�����Լ���������
    """
    def __init__(self, all_file):
        """
        init
        """
        faiss_search = FaissSearch(all_file)
        faiss_search.init()
        self.model = faiss_search

        define("port", default=8095, help="run on the given port", type=int)
 
        self.res_list = []

    def start(self):
        """����ʼ����
        """
        tornado.options.parse_command_line()
        app = tornado.web.Application(
            handlers=[
                    (r'/', IndexHandler, {"model":self.model, "check_history":self.res_list}),
                    (r'/index', IndexHandler, {"model":self.model, "check_history":self.res_list}),
                    ],
            template_path="./templates/"
        )
        http_server = tornado.httpserver.HTTPServer(app)
        http_server.listen(options.port)
        tornado.ioloop.IOLoop.instance().start()


if __name__ == '__main__':
    all_file = sys.argv[1]
    service = FaissSearchService(all_file)
    service.start()
