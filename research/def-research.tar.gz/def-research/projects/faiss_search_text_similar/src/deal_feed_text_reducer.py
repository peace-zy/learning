#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: work@baidu.com
  Date  : 21/07/15 15:04:31
  File  : src/deal_feed_all_reducer.py
  Desc  : reducer����
"""

import sys

if __name__ == "__main__":
    pre_key = None
    info_set = set()
    for line in sys.stdin:
        each_list = line.strip().split("\t")
        try:
            text = each_list[0]
            userid = each_list[1]
            adid = each_list[4]
        except:
            continue
        if text == "":
            continue
        info_ad = "\x01".join([userid, adid])
        if text != pre_key:
            if pre_key is not None:
                print ("\t".join([pre_key, "|".join(info_set)]))
                info_set = set()
            pre_key = text
        info_set.add(info_ad)
    if pre_key is not None:
        print ("\t".join([pre_key, "|".join(info_set)]))





