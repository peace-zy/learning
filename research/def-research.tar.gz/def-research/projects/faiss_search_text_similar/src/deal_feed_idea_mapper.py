#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: src/deal_feed_idea_mapper.py
Author: work(work@baidu.com)
Date: 2021/07/20 10:56:05
"""
import sys
import random
import json

def feed_idea_process(line):
    """
    data process
    ���ݴ���
    """
    ret = None
    while True:
        try:
            line = line.strip("\n")
            conts = json.loads(line)
            userid = str(conts["userid"])
            unitid = str(conts["unitid"])
            planid = str(conts["planid"])
            ideaid = str(conts["ideaid"])
            text_dict = conts["text"]
            kExtendText_list = []
            kMTargtUrl_list = []
            if "kExtendText" in text_dict:
                kExtendText_list = conts["text"]["kExtendText"]
            url_dict = conts["url"]
            if "kMTargtUrl" in url_dict:
                kMTargtUrl_list = conts["url"]["kMTargetUrl"]
            ideas = "".join(kExtendText_list).lower().strip()
            urls = "\x01".join(kMTargtUrl_list).strip()
            text = ideas

            ret = {
                    "userid": userid,
                    "planid": planid,
                    "unitid": unitid,
                    "id": "",
                    "version": ideaid,
                    "text": text,
                    "url": urls
                    }
        except Exception as e:
            break
        if True:
            break
    return ret


if __name__ == "__main__":
    for line in sys.stdin:
        ret = feed_idea_process(line)
        if ret is None:
            continue
        if ret["text"] == "":
            continue
        print("\t".join([ret["text"], ret["userid"], ret["planid"], ret["unitid"], ret["version"]]).encode("utf8"))

