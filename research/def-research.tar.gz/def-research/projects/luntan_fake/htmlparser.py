# -*- coding:gb18030 -*-
"""
Author:   changxiaojing@baidu.com
Date  :   21/02/05 11:10:39
"""

import sys
import bs4
from bs4 import BeautifulSoup
from treelib import Tree
import re
import word_segger

reload(sys)
sys.setdefaultencoding("gb18030")

def is_contain_chinese(check_str):
    """
    �ж��ַ������Ƿ��������
    """
    chinese_len = 0
    for ch in check_str:
        if u'\u4e00' <= ch <= u'\u9fff':
            chinese_len += 1
    return chinese_len

class DOMNode():
    """
    DOM����ÿ���ڵ������
    """
    def __init__(self, node_id, name, attr, u_feature, text):
        self.node_id = node_id
        self.name = name
        self.attr = attr
        self.u_feature = u_feature
        self.text = text

class DOMTree:
    """
    ��ҳԴ�빹��DOM��, ����ȡ������ͬ��֯�ṹ�����ݿ�
    """
    def __init__(self, html):
        """
        """
        self.seg_obj = word_segger.WordSegger()
        self.dom_id = 1
        self.dom_tree = Tree()
        self.bs_html = BeautifulSoup(html, 'html.parser') # ԭʼhtml
        self.process_html = self.get_process_html() # Ԥ����֮���html
        self.hash_map = {}

    def get_process_html(self):
        """
        Ԥ������ҳԴ��
        """
        # һЩ���õ�tag���Թ��˵�
        for tag in self.bs_html.find_all(["br", "img", "script", "style", "em", "strong", "font"]):
            tag.extract()
        self.process_html = BeautifulSoup(str(self.bs_html), 'html.parser')
        return self.process_html

    # ��ȡtag��feature
    def get_node_feature(self, name, attrs):
        """
        ��ȡtag��feature
        """
        attr_list = []
        node_feature = '<' + name + ' '
        sort_attr = sorted(attrs.keys())
        if "bdsfid" in sort_attr:
            sort_attr.remove("bdsfid")
        node_feature = node_feature + "|".join(sort_attr).strip() + '>'
        return node_feature
    
    def get_dom_tree(self):
        """
        ����DOM��
        """
        for content in self.process_html.contents:
            if isinstance(content, bs4.element.Tag):
                self.process_html = content
        self.recursive_descendants(self.process_html, 1)
    
    def recursive_descendants(self, descendants, parent_id):
        """
        �ݹ�����DOM��
        """
        if self.dom_id == 1:
            u_feature = self.get_node_feature(descendants.name, descendants.attrs)
            text = descendants.string.replace(" ", "") if descendants.string else ""
            seg_text = self.seg_obj.seg_words(text)
            self.dom_tree.create_node(descendants.name, self.dom_id, data=DOMNode(
                self.dom_id, descendants.name, descendants.attrs, u_feature, " ".join(seg_text)))
            self.dom_id = self.dom_id + 1
        for child in descendants.contents:
            if isinstance(child, bs4.element.Tag):
                child_u_feature = self.get_node_feature(child.name, child.attrs)
                child_text = child.string.replace(" ", "") if child.string else ""
                seg_text = self.seg_obj.seg_words(child_text)
                self.dom_tree.create_node(child.name, self.dom_id, parent_id, data=DOMNode(
                    self.dom_id, child.name, child.attrs, child_u_feature, " ".join(seg_text)))
                self.dom_id = self.dom_id + 1
                self.recursive_descendants(child, self.dom_id - 1)
    
    def findDuplicateSubtrees(self):
        """
        ����������ͬ�ṹ������
        """
        same_subtree_set = set()
        if not self.dom_tree:
            return same_subtree_set

        # ��ȱ���, �ݹ鷽ʽ��ȡÿ���ڵ��Ӧ������feature��feature+text
        self.traverse(self.dom_tree, 1, self.hash_map, '', '')

        # ��ȱ���, ���dom�������л���ʾ��ͬ������, �����н������ı���Ϣ�����л���Ϣ����ƴ��
        same_subtree_set = self.level_order(self.dom_tree, 1)
        return same_subtree_set 
    
    def traverse(self, descendants, node_id, hash_map, tree_feature, tree_text):
        """
        ����ͬ�������л�����
        """
        if not descendants:
            return "", ""
        current_node = descendants.get_node(node_id)    # ��ȡ��ǰ�ڵ�
        u_feature = current_node.data.u_feature   # ��ȡ��ǰ�ڵ��feature
        text = current_node.data.text  # ��ȡ��ǰ�ڵ��text
        node_depth = descendants.depth(current_node)    # ��ȡ��ǰ�ڵ�����
        childNode_list = descendants.children(node_id)  # ��ȡ��ǰ�ڵ���ӽڵ��б�
        tree_feature = tree_feature + u_feature  # ��ǰ�ڵ�����л���ʾ(�������ı���Ϣ)
        tree_text = tree_text + "\x01" + u_feature + "\x01" + text # ��ǰ�ڵ�����л���ʾ(�����ı���Ϣ)
        # ��ȡһ��ǰ�ڵ�Ϊ���������������л���ʾ
        for childNode in childNode_list:
            tmp_feature = ""
            tmp_text = ""
            child_node_id = childNode.identifier
            tmp_feature, tmp_text = self.traverse(descendants, child_node_id, self.hash_map, tmp_feature, tmp_text)
            tree_feature = tree_feature + tmp_feature
            tree_text = tree_text + "\x01" + tmp_text
        
        if node_id not in self.hash_map:
            self.hash_map[node_id] = [node_depth, tree_feature, tree_text]
        
        return tree_feature, tree_text

    def level_order(self, dom_tree, node_id):
        """
        ��ȱ���
        """
        same_subtree_set = set()
        stack = [node_id]
        while stack:
            pop_node_id = stack.pop(0)
            child_id_list = dom_tree.is_branch(pop_node_id)
            tmp_map = {}
            for child_id in child_id_list:
                tree_feature = self.hash_map[child_id][1]
                tree_text = self.hash_map[child_id][2]
                if is_contain_chinese(tree_text) == 0:
                    continue
                if tree_feature not in tmp_map:
                    tmp_map[tree_feature] = [(child_id, tree_text)]
                else:
                    tmp_map[tree_feature].append((child_id, tree_text))
            for feature, info in tmp_map.items():
                if len(info) > 1:
                    tmp_list = []
                    for item in info:
                        tmp_item = [i for i in item[1].split("\x01") if i != ""]
                        tmp_list.append("\x01".join(tmp_item))
                    same_subtree = "\x02".join(tmp_list)
                    if is_contain_chinese(same_subtree) > 30:
                        same_subtree_set.add(same_subtree)
                else:
                    stack.append(info[0][0])
        return same_subtree_set

if __name__ == "__main__":
    file = open('./one_source', 'rb') 
    html = file.read()
    data = html.strip("\n").decode("gb18030").split("\t")
    url = data[0]
    html = data[1].replace("<br>", "")
    dom_tree = DOMTree(html)
    dom_tree.get_dom_tree()
    same_subtree_set = dom_tree.findDuplicateSubtrees()
    for item in same_subtree_set:
        print(url + "\t" + item).encode("gb18030")
