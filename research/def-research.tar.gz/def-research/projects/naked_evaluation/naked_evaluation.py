# encoding:utf-8
"""
对图片的人体裸露区域进行裸露比例估计，目前只实现了胸部和腹部区域
"""
import os
import cv2
import requests
import json
import base64
import time
import numpy as np


def get_access_token():
    """
    获取 aceess_token
    :return: aceess_token
    """
    # client_id 为官网获取的AK， client_secret 为官网获取的SK
    access_token = ''
    host = 'https://aip.baidubce.com/oauth/2.0/token?' \
           'grant_type=client_credentials&' \
           'client_id=mXXP0HYFG8Oqigd74H31d2qf&' \
           'client_secret=1auo8aqHnT76uAp4zqURbEtbLk74qsv7'
    response = requests.get(host)
    if response:
        access_token = response.json()['access_token']
        
    return access_token
    
    
def get_key_point(img_path):
    """
    获取图片的关键点信息
    :param img_path: 图片的完整路径
    :return: 图片中的关键点信息
    """
    key_point_dict = {}
    request_url = "https://aip.baidubce.com/rest/2.0/image-classify/v1/body_analysis"
    # 二进制方式打开图片文件
    f_img = open(img_path, 'rb')
    img = base64.b64encode(f_img.read())
    
    params = {"image": img}
    request_url = "%s?access_token=%s" % (request_url, get_access_token())
    headers = {'content-type': 'application/x-www-form-urlencoded'}
    
    response = requests.post(request_url, data=params, headers=headers)
    if response:
        print(response.json())
        key_point_dict = response.json()
    
    return key_point_dict


def get_key_area(key_point_dict):
    """
    解析人体关键点数据，获取人体关键区域
    二期添加：置信度判断。对不符合置信度要求的人体框和关键点，不进行关键区域标注
    :param key_point_dict: 人体关键点标注数据
    :return: 关键区域列表，每个元素为一个人体的关键区域集合，关键区域分别为 脸，胸，腹，胯，腿
    """
    # 获取关键区域
    # cv2.polylines(img, pts, isClosed, color[, thickness[, lineType[,shift]]])
    # points = np.array([[150, 50], [140, 140], [200, 170], [250, 250], [150, 50]], np.int32)
    # points = points.reshape(-1, 1, 2)
    # cv2.polylines(dst, [points], True, (0, 255, 255))
    
    key_area = []
    person_num = key_point_dict['person_num']
    for i in range(person_num):
        person_info = key_point_dict['person_info'][i]
        body_parts = person_info['body_parts']
        location = person_info['location']
        
        face_area = [body_parts['left_ear'], body_parts['right_ear'], body_parts['neck']]
        
        chest_area = [body_parts['left_shoulder']['x'], body_parts['left_shoulder']['y'],
                      body_parts['right_shoulder']['x'], body_parts['right_shoulder']['y'],
                      (body_parts['right_shoulder']['x'] + body_parts['right_hip']['x']) / 2,
                      (body_parts['right_shoulder']['y'] + body_parts['right_hip']['y']) / 2,
                      (body_parts['left_shoulder']['x'] + body_parts['left_hip']['x']) / 2,
                      (body_parts['left_shoulder']['y'] + body_parts['left_hip']['y']) / 2]
        
        belly_area = [(body_parts['left_shoulder']['x'] + body_parts['left_hip']['x']) / 2,
                      (body_parts['left_shoulder']['y'] + body_parts['left_hip']['y']) / 2,
                      (body_parts['right_shoulder']['x'] + body_parts['right_hip']['x']) / 2,
                      (body_parts['right_shoulder']['y'] + body_parts['right_hip']['y']) / 2,
                      body_parts['right_hip']['x'], body_parts['right_hip']['y'],
                      body_parts['left_hip']['x'], body_parts['left_hip']['y']]
        
        hip_area = [body_parts['left_hip'], body_parts['right_hip']]
        
        left_leg_area = [body_parts['left_hip'], body_parts['left_knee'], body_parts['left_ankle']]
        
        right_leg_area = [body_parts['right_hip'], body_parts['right_knee'], body_parts['right_ankle']]
        
        body_area = [location]
        
        # 二期项目添加
        back_area = []
        side_area = []
        ass_area = []
        area_dict = {}
        
        key_area.append([face_area, chest_area, belly_area, hip_area, left_leg_area, right_leg_area, body_area])
    
    return key_area


def get_key_mask(key_area, img):
    """
    后续优化，将获取 mask 区域的函数整理至此
    因为每一个人体区域需要不同的策略来定位修正，因此每一个区域都得对应一个获取区域函数
    :param key_area: 关键区域
    :param img: 输入图片
    :return: 截取的图片 mask
    """
    pass


def get_skin_feature(face_area):
    """
    获取肤色特征，自适应的进行裸露估计
    :param face_area: 面部区域 mask
    :return: 肤色特征
    """
    skin_feature = []
    
    return skin_feature


def calculate_naked_percent(cvimg, area, skin_feature=False):
    """
    对裸露区域进行估计。
    :param cvimg:  cv2.imread 读取后传入的图片矩阵
    :param area: 解析人体关键点信息后的人体区域，一般包含4个关键点
    :param skin_feature: 是否使用自适应的人体皮肤特征，目前默认关闭
    :return:人体区域裸露比例
    """
    if skin_feature:
        get_skin_feature(area)
    # orange 默认皮肤颜色
    lower_orange = np.array([11, 43, 46])
    upper_orange = np.array([25, 255, 255])
    
    body_mask = np.zeros(cvimg.shape, dtype=np.uint8)
    mask_area = np.array([[area[0], area[1]], [area[2], area[3]], [area[4], area[5]], [area[6], area[7]]])
    cv2.fillPoly(body_mask, [mask_area], (255, 255, 255))
    # print(cvimg.shape, cvimg.dtype, body_mask.shape, body_mask.dtype)
    
    body_area = cv2.bitwise_and(cvimg, body_mask)
    time_str = str(time.time())
    cv2.imwrite(time_str + '_mask.jpg', body_area)
    
    gray_mask = cv2.cvtColor(body_mask, cv2.COLOR_BGR2GRAY)
    ret, thresh = cv2.threshold(gray_mask, 127, 255, cv2.THRESH_BINARY)

    contours, hiera = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    acreage = 0
    for cnt in contours:
        acreage += cv2.contourArea(cnt)
    
    hsv = cv2.cvtColor(body_area, cv2.COLOR_BGR2HSV)
    naked_mask = cv2.inRange(hsv, lower_orange, upper_orange)
    # cv2.imwrite(time_str + '_hsv.jpg', naked_mask)
    
    binary = cv2.threshold(naked_mask, 127, 255, cv2.THRESH_BINARY)[1]
    binary = cv2.dilate(binary, None, iterations=2)
    contours, hiera = cv2.findContours(binary.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    area_sum = 0
    for cnt in contours:
        area_sum += cv2.contourArea(cnt)
        
    percent = round((area_sum / acreage), 2)
    
    return percent


def naked_detect(cvimg, body_areas):
    """
    逐个计算区域裸露程度
    :param cvimg: cv2.imread 读取的图片矩阵
    :param body_areas: 不同身体区域的点集对应的列表
    :return: 字典：{不同区域：区域裸露得分}
    """
    result_dict = {}
    for each_person in body_areas:
        #for each_area in each_person:
        
        chest_area = list(map(int, each_person[1]))
        result_dict['chest'] = calculate_naked_percent(cvimg, chest_area)
        
        belly_area = list(map(int, each_person[2]))
        result_dict['belly'] = calculate_naked_percent(cvimg, belly_area)
    
    return result_dict


def process(img_dir, output_file_path):
    """
    处理流程函数
    :param img_dir: 要批量处理的图片路径
    :param output_file_path: 输出结果文件路径
    """
    output_file = open(output_file_path, 'w')
    for each_img in os.listdir(img_dir):
        each_img_path = os.path.join(img_dir, each_img)
        img = cv2.imread(each_img_path)
        
        key_point_info = get_key_point(each_img_path)
        time.sleep(0.5)  # 目前人体关键点检测服务的 QPS 为 2
        body_areas = get_key_area(key_point_info)
        
        naked_info = naked_detect(img, body_areas)
        print(naked_info)
        output_file.write(json.dumps(naked_info))
    
    output_file.close()


if __name__ == '__main__':
    work_dir = '/Users/huxu01/Downloads/test/'
    img_path = '/Users/huxu01/Downloads/test/img_7.jpg'
    output_file = '/Users/huxu01/Downloads/naked_detection_result.txt'
    # get_key_point(img_path)
    process(work_dir, output_file)
