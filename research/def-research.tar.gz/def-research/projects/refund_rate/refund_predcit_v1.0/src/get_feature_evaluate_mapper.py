#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
Author: liuxingwang(liuxingwang@baidu.com)
Date: 2021/04/20 11:50:35
Desc: ��Ʒ����������ȡ
"""
import sys
import json
import time_tool
user_feature = {}
def extract_evaluate(one_line):
    """ extract evaluate feature 
    [in] one_line: a record of table evaluate
    [out] [ucid, product_score, shop_service_score, shop_logistics_score]
    """
    try:
        feat = [one_line[4], float(one_line[18]), float(one_line[19]), float(one_line[20])]
    except:
        return None
    return feat

def update_one_score(score_list, vaule):
    """update_one_score
    """
    if vaule < score_list[0]:
        score_list[0] = vaule
    
    if vaule > score_list[1]:
        score_list[1] = vaule
    
    score_list[2] += vaule
    if vaule >= 1:
        score_list[3] += 1
    if vaule >= 2:
        score_list[4] += 1
    if vaule >= 3:
        score_list[5] += 1
    if vaule >= 4:
        score_list[6] += 1
    return score_list

def merge_evaluate(one_line):
    """merge one line evaluate featrue
    """
    evaluate_featrue = extract_evaluate(one_line)
    if not evaluate_featrue:
        return
    one_user = user_feature.get(evaluate_featrue[0], {})
    
    one_user_dict = one_user.get("evaluate", {})
    product_score = one_user_dict.get("product_score", [10, 0, 0, 0, 0, 0, 0])
    
    service_score = one_user_dict.get("service_score", [10, 0, 0, 0, 0, 0, 0])
    logistics_score = one_user_dict.get("logistics_score", [10, 0, 0, 0, 0, 0, 0])
    count = one_user_dict.get("count", 0)
    one_user_dict["count"] = count + 1
   
    product_score = update_one_score(product_score, evaluate_featrue[1])
    service_score = update_one_score(service_score, evaluate_featrue[2])
    logistics_score = update_one_score(logistics_score, evaluate_featrue[3])

    one_user_dict["product_score"] = product_score
    one_user_dict["service_score"] = service_score
    one_user_dict["logistics_score"] = logistics_score

    one_user["evaluate"] = one_user_dict
    user_feature[evaluate_featrue[0]] = one_user


def main():
    """main
    """
    todate = sys.argv[1]
    for line in sys.stdin:
        one_line = line.strip("\n").decode("utf8").split("\t")
        create_time = one_line[25].split(" ")[0]
        #print create_time
        time_diff = time_tool.count_time(todate, create_time)
        if time_diff <= 0:
            continue
        merge_evaluate(one_line)
        
    for uid, key in user_feature.items():
        print uid + "\t" + json.dumps(key)
        

if __name__ == "__main__":
    main()



