#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
Author: liuxingwang(liuxingwang@baidu.com)
Date: 2021/04/20 11:50:35
Desc: ��Ʒ����������ȡ
"""
import sys
import json
user_feature = {}

def merge_spu_price(dict1, dict2):
    """
    [in] dict dict2 ����
    [out]
        res_dict
    """
    if not dict1:
        return dict2
    if not dict2:
        return dict1
    res_dict = {}
    res_dict["min_num"] = [0, 0]
    res_dict["max_num"] = [0, 0]
    res_dict["sum_num"] = [0, 0]
    res_dict["count"] = dict1["count"] + dict2["count"]
    res_dict["min_num"][0] = min(dict1["min_num"][0], dict2["min_num"][0])
    res_dict["min_num"][1] = min(dict1["min_num"][1], dict2["min_num"][1])
    res_dict["max_num"][0] = max(dict1["max_num"][0], dict2["max_num"][0])
    res_dict["max_num"][1] = max(dict1["max_num"][1], dict2["max_num"][1])
    res_dict["sum_num"][0] = dict1["sum_num"][0] + dict2["sum_num"][0]
    res_dict["sum_num"][1] = dict1["sum_num"][1] + dict2["sum_num"][1]
    return res_dict

def merge_all_feature(uid, one_user_feature):
    """merge_all_feature
    [in] uid one_user_feature
    """
    old_one_feature = user_feature.get(uid, {})
    new_one_feature = {}
    map_merge = {"spu_price":merge_spu_price}
    
    for k, v in one_user_feature.items():
        func = map_merge.get(k, None)
        if func:
            new_one_feature[k] = func(old_one_feature.get(k, {}), v)
    user_feature[uid] = new_one_feature

def out_put_spu_price(spu_price):
    """out_put_spu_price
    """
    desc = []
    value = []
    desc.append("max_num_ori_price")
    desc.append("max_num_price")
    desc.append("min_num_ori_price")
    desc.append("min_num_price")
    desc.append("avg_ori_price")
    desc.append("avg_price")
    desc.append("count")
    value.append(spu_price["max_num"][0])
    value.append(spu_price["max_num"][1])
    value.append(spu_price["min_num"][0])
    value.append(spu_price["min_num"][1])
    value.append(spu_price["sum_num"][0] / spu_price["count"] )
    value.append(spu_price["sum_num"][1] / spu_price["count"] )
    value.append(spu_price["count"])
    return desc, value

def output_all_feature():
    """output_all_feature
    """
    map_output_func = [["spu_price", out_put_spu_price]]
    for uid, one_user_feature in user_feature.items():
        desc = []
        value = []
        for map_func in map_output_func:
            one_feature = one_user_feature.get(map_func[0], None)
            if one_feature:
                d, v = map_func[1](one_feature)
                desc.extend(d)
                value.extend(v)
        value = map(str, value)
        print uid + "\t" + " ".join(desc) + "\t" + " ".join(value)


def main():
    """main
    """
    for line in sys.stdin:
        uid, user_dcit = line.strip("\n").split("\t")
        user_dcit = json.loads(user_dcit)
        merge_all_feature(uid, user_dcit)
    
    output_all_feature()
        

if __name__ == "__main__":
    main()



