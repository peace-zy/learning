#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: time_tool.py
Author: liuxingwang(liuxingwang@baidu.com)
Date: 2021/04/21 16:59:10
"""
import time
import datetime

def count_time(date_now, date_past):
    """count the Difference of date_now,date_past
    """
    try:
        date_now = time.strptime(date_now, "%Y-%m-%d")
        date_past = time.strptime(date_past, "%Y-%m-%d")
    except:
        return -1

    date_now = datetime.datetime(date_now[0], date_now[1], date_now[2])
    date_past = datetime.datetime(date_past[0], date_past[1], date_past[2])
    diff = date_now - date_past
    return diff.days

if __name__ == "__main__":
    print count_time("2021-04-21", "2021-04-16")

