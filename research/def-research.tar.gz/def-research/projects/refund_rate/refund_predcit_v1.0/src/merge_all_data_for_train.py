#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: merge_all_data_for_train.py
Author: liuxingwang(liuxingwang@baidu.com)
Date: 2021/04/27 09:54:09
"""
import sys
import os
import read_csv
def load_data(file_path):
    """load feature data
    """
    res_dict = {}
    with open(file_path) as f:
        for line in f:
            one = line.strip("\n").split("\t")
            res_dict[one[0]] = one[2]
    return res_dict

def meger_data(feature_a, feature_b):
    """meger_data
    """
    new_feature = {}
    for key, vaule in feature_a.items():
        if feature_b.get(key, None) is not None:
            vaule = vaule + " " + feature_b[key]
            #print len(vaule.split(" "))
            new_feature[key] = vaule
    return new_feature

def concate_lab(merge_feature, labs, date):
    """concate_lab
    """
    for k, v in merge_feature.items():
        key = k + "_" + date
        if labs.get(key, None) is not None:
            print "\t".join([k, v, labs[key]])

def main():
    """main
    """
    source_data = sys.argv[1]
    labs = read_csv.load_data(sys.argv[2])
    date_list = os.listdir(source_data)
    for date in date_list:
        feature_date = os.path.join(source_data, date)
        spsx_path = os.path.join(feature_date, 'spsx.txt')
        shouhou_path = os.path.join(feature_date, 'shouhou.txt')
        pj_path = os.path.join(feature_date, 'pj.txt')
        
        spsx_data = load_data(spsx_path)
        shouhou_data = load_data(shouhou_path)
        pj_data = load_data(pj_path)

        merge = meger_data(shouhou_data, pj_data)
        #print "merge pj"
        merge = meger_data(merge, spsx_data)
        concate_lab(merge, labs, date)
        #print merge
        #return

if __name__ == "__main__":
    main()

