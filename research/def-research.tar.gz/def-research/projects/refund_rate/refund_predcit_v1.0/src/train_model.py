#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: train_model.py
Author: liuxingwang(liuxingwang@baidu.com)
Date: 2021/04/27 14:12:06
"""
from sklearn.linear_model import LinearRegression
import sys
import numpy as np
from sklearn.externals import joblib 
import sklearn
def load_train_data(file_path):
    """load_train_data
    """
    data = []
    labs = []
    with open(file_path) as f:
        for line in f:
            one = line.strip("\n").split("\t")
            dt = one[1].split(" ")
            #print len(dt)
            dt = map(float, dt)
            data.append(dt)
            labs.append(float(one[2]))
    return np.array(data), labs

def L1_loss(pres, labs):
    """ L1_loss
    """
    sum = 0
    for p, l in zip(pres, labs):
        sum += abs(p - l)
    return sum / len(pres)

def main():
    """main
    """
    data_path = sys.argv[1]
    data, labs = load_train_data(data_path)
    nm= sklearn.preprocessing.StandardScaler(copy=True, with_mean=True, with_std=True) 
    nm.fit(data)
    data = nm.transform(data)
    print data.shape
    md = LinearRegression()
    md.fit(data, labs)
    #print(help(md.fit))

    test_data, test_lab = load_train_data(sys.argv[2])
    test_data = nm.transform(data)
    pre_lab = md.predict(test_data)
    print("test_set_L1_loss is ", L1_loss(pre_lab, test_lab))
    train_pre = md.predict(data)
    print("train_set_l1_loss is", L1_loss(train_pre, labs))
    joblib.dump(md, './model/model.pkl')
    joblib.dump(nm, './model/norm.pkl')
if __name__ == "__main__":
    main()
