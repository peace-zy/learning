#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: predict_lr.py
Author: liuxingwang(liuxingwang@baidu.com)
Date: 2021/04/27 14:12:06
"""
from sklearn.linear_model import LinearRegression
import sys
import numpy as np
from sklearn.externals import joblib 
import sklearn
def load_predict_data(file_path):
    """load_predict_data
    """
    data = []
    user = []
    with open(file_path) as f:
        for line in f:
            one = line.strip("\n").split("\t")
            dt = one[1].split(" ")
            user.append(one[0])
            #print len(dt)
            dt = map(float, dt)
            data.append(dt)
    return np.array(data), user


def main():
    """main
    """
    data_path = sys.argv[1]
    data, user = load_predict_data(data_path)
    nm = joblib.load(sys.argv[2])
    lr = joblib.load(sys.argv[3])
    data = nm.transform(data)
    pre_lab = lr.predict(data)
    for u, pro in zip(user, pre_lab):
        if pro - 1 > 0.000000001:
            pro = 1
        if pro - 0.000000001 > 0:
            print(u + "\t" + str(pro))
        else:
            print(u + "\t" + str(0.0))


if __name__ == "__main__":
    main()
