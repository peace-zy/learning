#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: read_csv.py
Author: liuxingwang(liuxingwang@baidu.com)
Date: 2021/04/27 10:24:22
"""
import sys
def load_data(file_path):
    """load_data
    """
    res_dict = {}
    count = 0
    head = []
    with open(file_path) as f:
        for line in f:
            one = line.strip("\n").split(",")
            ucid = one[0]
            if count == 0:
                head = one[1:]
                count += 1
                continue
            for date, data in zip(head, one[1:]):
                if data != "":
                    pass
                    #continue
                if data == "":
                    data = '0'
                    continue
                key = ucid + "_" + date
                res_dict[key] = data
    return res_dict

if __name__ == "__main__":
    print load_data("./refund_rate_20210506.csv")


