#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
Author: liuxingwang(liuxingwang@baidu.com)
Date: 2021/04/20 11:50:35
Desc: ��Ʒ�ۺ�������ȡ
"""
import sys
import json
import time_tool

user_feature = {}
def extract_refund(one_line):
    """ extract refund feature 
    [in] one_line: a record of table refund
    [out] [ucid, refund_amount, refund_num]
    """
    try:
        time_create = one_line[32].split(" ")[0]
        feat = [one_line[20], time_create, float(one_line[2]), float(one_line[3])]
    except:
        return None
    return feat


def merge_refund(one_line, todate):
    """merge one line refund featrue
    """
    refund_featrue = extract_refund(one_line)
    if not refund_featrue:
        return
    time_diff = time_tool.count_time(todate, refund_featrue[1])
    if time_diff <= 0 or time_diff > 30:
        return 

    one_user = user_feature.get(refund_featrue[0], {})
    
    one_user_dict = one_user.get("refund_fea", {})
    refund_amount_thirty = one_user_dict.get("refund_amount", [0] * 30)
    refund_num_thirty = one_user_dict.get("refund_num", [0] * 30)
    
    refund_amount_thirty[time_diff - 1] += refund_featrue[2]
    refund_num_thirty[time_diff - 1] += refund_featrue[3]

    one_user_dict["refund_amount"] = refund_amount_thirty
    one_user_dict["refund_num"] = refund_num_thirty
    one_user["refund_fea"] = one_user_dict
    user_feature[refund_featrue[0]] = one_user

def main():
    """main
    """
    todate = sys.argv[1]
    for line in sys.stdin:
        one_line = line.strip("\n").decode("utf8").split("\t")
        merge_refund(one_line, todate)
        
    for uid, key in user_feature.items():
        print uid + "\t" + json.dumps(key)
        

if __name__ == "__main__":
    main()



