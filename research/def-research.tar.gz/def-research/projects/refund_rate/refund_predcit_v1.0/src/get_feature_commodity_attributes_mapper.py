#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
Author: liuxingwang(liuxingwang@baidu.com)
Date: 2021/04/20 11:50:35
Desc: ��Ʒ����������ȡ
"""
import sys
import json
import time_tool
user_feature = {}
def extract_price(one_line):
    """ extract price feature 
    [in] one_line: a record of table spu_online
    [out] [ucid, origin_price, price]
    """
    return [one_line[28], float(one_line[9]), float(one_line[10])]

def merge_price(one_line):
    """merge one line price featrue
    """
    price_featrue = extract_price(one_line)
    one_user = user_feature.get(price_featrue[0], {})
    
    one_user_dict = one_user.get("spu_price", {})
    max_num = one_user_dict.get("max_num", [0, 0])
    min_num = one_user_dict.get("min_num", [0, 0])
    sum_num = one_user_dict.get("sum_num", [0, 0])
    count = one_user_dict.get("count", 0)

    one_user_dict["count"] = count + 1
    sum_num[0] += price_featrue[1]
    sum_num[1] += price_featrue[2]
    one_user_dict["sum_num"] = sum_num

    if max_num[0] < price_featrue[1]:
        max_num[0] = price_featrue[1]
    if max_num[1] < price_featrue[2]:
        max_num[1] = price_featrue[2]
    one_user_dict["max_num"] = max_num

    if min_num[0] > price_featrue[1]:
        min_num[0] = price_featrue[1]
    if min_num[1] > price_featrue[2]:
        min_num[1] = price_featrue[2]
    one_user_dict["min_num"] = min_num
    one_user["spu_price"] = one_user_dict
    user_feature[price_featrue[0]] = one_user


def main():
    """main
    """
    todate = sys.argv[1]
    for line in sys.stdin:
        one_line = line.strip("\n").decode("utf8").split("\t")
        create_time = one_line[40].split(" ")[0]
        #print create_time
        time_diff = time_tool.count_time(todate, create_time)
        if time_diff <= 0:
            continue
        merge_price(one_line)
        
    for uid, key in user_feature.items():
        print uid + "\t" + json.dumps(key)
        

if __name__ == "__main__":
    main()



