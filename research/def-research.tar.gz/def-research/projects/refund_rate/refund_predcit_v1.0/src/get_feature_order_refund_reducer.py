#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
Author: liuxingwang(liuxingwang@baidu.com)
Date: 2021/04/20 11:50:35
Desc: ��Ʒ�ۺ�������ȡ
"""
import sys
import json
user_feature = {}

def updata_one_score(score_list_old, score_list_new):
    """updata_one_score
    [in] score_list_old score_list_new 
    """
    res = [0] * len(score_list_new)
    for i in range(len(score_list_new)):
        res[i] = score_list_old[i] + score_list_new[i]
    return res

def merge_refund_fea(dict1, dict2):
    """merge_refund_fea
    [in] dict1 dict2
    """
    if not dict1:
        return dict2
    if not dict2:
        return dict1
    res_dict = {}
    res_dict["refund_amount"] = updata_one_score(dict1["refund_amount"], dict2["refund_amount"])
    res_dict["refund_num"] = updata_one_score(dict1["refund_num"], dict2["refund_num"])
    return res_dict

def merge_all_feature(uid, one_user_feature):
    """merge_all_feature
    [in] uid one_user_feature
    """
    old_one_feature = user_feature.get(uid, {})
    new_one_feature = {}
    map_merge = {"refund_fea":merge_refund_fea}
    
    for k, v in one_user_feature.items():
        func = map_merge.get(k, None)
        if func:
            new_one_feature[k] = func(old_one_feature.get(k, {}), v)
    user_feature[uid] = new_one_feature

def out_put_refund_fea(refund_fea):
    """out_put_refund_fea
    """
    desc = []
    desc.extend(["refund_amount_thirty"] * 30)
    desc.extend(["refund_num_thirty"] * 30)
    value = []
    value.extend(refund_fea["refund_amount"])
    value.extend(refund_fea["refund_num"])
    return desc, value

def output_all_feature():
    """output_all_feature
    """
    map_output_func = [["refund_fea", out_put_refund_fea]]
    for uid, one_user_feature in user_feature.items():
        desc = []
        value = []
        for map_func in map_output_func:
            one_feature = one_user_feature.get(map_func[0], None)
            if one_feature:
                d, v = map_func[1](one_feature)
                desc.extend(d)
                value.extend(v)
        value = map(str, value)
        print uid + "\t" + " ".join(desc) + "\t" + " ".join(value)


def main():
    """main
    """
    for line in sys.stdin:
        uid, user_dcit = line.strip("\n").split("\t")
        user_dcit = json.loads(user_dcit)
        merge_all_feature(uid, user_dcit)
    
    output_all_feature()
        

if __name__ == "__main__":
    main()

