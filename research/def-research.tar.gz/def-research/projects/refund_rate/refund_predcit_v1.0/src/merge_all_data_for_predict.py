#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: merge_all_data_for_train.py
Author: liuxingwang(liuxingwang@baidu.com)
Date: 2021/04/27 09:54:09
"""
import sys
import os
def load_data(file_path):
    """load the feature data
    [in] file_path
    [out] res_dict
    """
    res_dict = {}
    with open(file_path) as f:
        for line in f:
            one = line.strip("\n").split("\t")
            res_dict[one[0]] = one[2]
    return res_dict

def meger_data(feature_a, feature_b):
    """merge two feature
    [in] feature_a feature_b
    [out] new_feature
    """
    new_feature = {}
    for key, vaule in feature_a.items():
        if feature_b.get(key, None) is not None:
            vaule = vaule + " " + feature_b[key]
            #print len(vaule.split(" "))
            new_feature[key] = vaule
    return new_feature

def output_feature(merge_feature):
    """output_feature
    [in] merge_feature
    """
    for k, v in merge_feature.items():
            print "\t".join([k, v])

def main():
    """main
    """
    source_data = sys.argv[1]
    date = sys.argv[2]
    feature_date = os.path.join(source_data, date)
    spsx_path = os.path.join(feature_date, 'spsx')
    shouhou_path = os.path.join(feature_date, 'shouhou')
    pj_path = os.path.join(feature_date, 'pj')
        
    spsx_data = load_data(spsx_path)
    shouhou_data = load_data(shouhou_path)
    pj_data = load_data(pj_path)

    merge = meger_data(shouhou_data, pj_data)
    merge = meger_data(merge, spsx_data)
    output_feature(merge)

if __name__ == "__main__":
    main()


