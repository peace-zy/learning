#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: dangjinming@baidu.com
  Date  : 21/07/02 10:01:28
  File  : order_evaluate_mapper.py
  Desc  : 
"""

import sys

def get_duxiaodian_shop_id():
    """
    ��ö�С��ǰһ��ĵ�����shop_id
    """
    shop_id_set = set()
    with open('./duxiaodian_shop_id.txt', 'r') as fr:
        for line in fr:
            line = line.strip().decode('gb18030', 'ignore')
            shop_id_set.add(line)
    return  shop_id_set   
            
def order_evaluate_process():
    """
    ȡ�������ݵ�������Ϣ
    """
    shop_id_set = get_duxiaodian_shop_id()
    for line in sys.stdin:
        parts = line.strip().decode('utf-8', 'ignore').split('\t')
        if len(parts) != 29 or \
            parts[6] != "5" or \
            parts[3] not in shop_id_set:
            continue
        sku_id                  = parts[1]
        spu_id                  = parts[2]
        shop_id                 = parts[3]
        order_id                = parts[5]
        passport_id             = parts[7]
        user_id                 = parts[8]
        images_num              = parts[10]
        audit_status            = parts[13]
        audit_time              = parts[16]
        product_score           = parts[18]
        shop_service_score      = parts[19]
        shop_logistics_score    = parts[20]
        visible                 = parts[21]
        create_time             = parts[25]
        update_time             = parts[26]
        is_delete               = parts[27]

        print ('\t'.join([
            sku_id,
            spu_id,
            shop_id,
            order_id,
            passport_id,
            user_id,
            images_num,
            audit_status,
            audit_time,
            product_score,
            shop_service_score,
            shop_logistics_score,
            visible,
            create_time,
            update_time,
            is_delete
        ])).encode('utf-8', 'ignore')
 
if __name__ == "__main__":
    order_evaluate_process()

