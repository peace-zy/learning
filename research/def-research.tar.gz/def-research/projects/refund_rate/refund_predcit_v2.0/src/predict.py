#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################

"""
File: predict.py
Author: zhangqifan(zhangqifan01@baidu.com)
Date: 2021/06/08 15:17:45
"""

import sys
import os
import pandas as pd
import joblib
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from deepctr.feature_column import DenseFeat, get_feature_names
from deepctr.models.deepfm import DeepFM
_cur_dir = os.path.dirname(os.path.abspath(__file__))


def load_data(value):
    """
    ��ȡ��Ԥ����������
    """
    df = pd.read_csv('%s/../data/feature.txt' % value)
    df = df.set_index(['level_0', 'level_1'])
    df_zero = df[df.apply(np.sum, axis=1) == 0]
    df = df[df.apply(np.sum, axis=1) != 0]

    return df.reset_index(), df_zero.reset_index()


def normalization(dataframe, loc):
    """
    ��һ��������ģ����������
    """
    #shuffle
    dataframe = dataframe.sample(frac=1)
    dense_features = [str(i) for i in range(0, 235)]
    mms = joblib.load('%s/../model/scaler.save' % loc)
    #mms = MinMaxScaler(feature_range=(0, 1))
    dataframe[dense_features] = mms.transform(dataframe[dense_features])
    fixlen_feature_columns = [DenseFeat(feat, 1,) for feat in dense_features]
    dnn_feature_columns = fixlen_feature_columns
    linear_feature_columns = fixlen_feature_columns
    feature_names = get_feature_names(linear_feature_columns + dnn_feature_columns)

    model_input = {name:dataframe[name].values for name in feature_names}

    return model_input, linear_feature_columns, dnn_feature_columns


def get_predict(input_dict, linear_feature_columns, dnn_feature_columns, loc):
    """
    Ԥ��
    """
    model_0 = DeepFM(linear_feature_columns, dnn_feature_columns, task='regression')
    model_1 = DeepFM(linear_feature_columns, dnn_feature_columns, task='regression')
    model_2 = DeepFM(linear_feature_columns, dnn_feature_columns, task='regression')
    model_3 = DeepFM(linear_feature_columns, dnn_feature_columns, task='regression')
    model_4 = DeepFM(linear_feature_columns, dnn_feature_columns, task='regression')
    model_5 = DeepFM(linear_feature_columns, dnn_feature_columns, task='regression')
    model_6 = DeepFM(linear_feature_columns, dnn_feature_columns, task='regression')
    model_0.load_weights('%s/../model/day_0_weights.h5' % loc)
    model_1.load_weights('%s/../model/day_1_weights.h5' % loc)
    model_2.load_weights('%s/../model/day_2_weights.h5' % loc)
    model_3.load_weights('%s/../model/day_3_weights.h5' % loc)
    model_4.load_weights('%s/../model/day_4_weights.h5' % loc)
    model_5.load_weights('%s/../model/day_5_weights.h5' % loc)
    model_6.load_weights('%s/../model/day_6_weights.h5' % loc)
    pred_ans_0 = model_0.predict(input_dict, batch_size=256)
    pred_ans_1 = model_1.predict(input_dict, batch_size=256)
    pred_ans_2 = model_2.predict(input_dict, batch_size=256)
    pred_ans_3 = model_3.predict(input_dict, batch_size=256)
    pred_ans_4 = model_4.predict(input_dict, batch_size=256)
    pred_ans_5 = model_5.predict(input_dict, batch_size=256)
    pred_ans_6 = model_6.predict(input_dict, batch_size=256)
    pred_ans = np.concatenate((pred_ans_0, pred_ans_1, pred_ans_2, pred_ans_3, pred_ans_4, \
            pred_ans_5, pred_ans_6), axis=1)
    return pred_ans


def output(res, loc, df, df_feature_zero):
    """
    �����Ԥ���ļ�
    """
    df_res = pd.DataFrame(res).applymap(lambda x:0.0 if x < 0 else np.round(x, 4))
    df = pd.concat([df[['level_0']], df_res], axis=1)
    df_pre_zero  = pd.DataFrame(0, index=range(len(df_feature_zero['level_0'])), \
            columns=['level_0', '0', '1', '2', '3', '4', '5', '6'])
    df_pre_zero['level_0'] = df_feature_zero['level_0']
    df_pre_zero.columns = df.columns
    df = pd.concat([df, df_pre_zero], axis=0, ignore_index=True)
    df.to_csv('%s/../output/result_7days.txt' % loc, header=None, sep='\t', index=None)


def main(value):
    """
    ������
    """
    df, df_feature_zero = load_data(value)
    model_input, linear_feature, dnn_feature = normalization(df, value)
    res = get_predict(model_input, linear_feature, dnn_feature, value)
    output(res, value, df, df_feature_zero)


if __name__ == "__main__":
    main(_cur_dir)
