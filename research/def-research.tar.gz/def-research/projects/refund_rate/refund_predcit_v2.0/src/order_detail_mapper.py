#!/usr/bin/env python
# -*- coding: utf-8 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: order_detail_mapper.py
Author: zhangqifan(zhangqifan01@baidu.com)
Date: 2021/06/08 15:17:45
"""
import sys
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)


def is_null(value):
    """
    �ж�ȱʧֵ
    """
    return "1" if value else "0"


def fill_null(value):
    """
    ���ȱʧֵ
    """
    return value if value else -1


def order_detail_process(line, ignore=False):
    """
    ��������������
    """
    ret = None
    while True:
        parts = line.split("\t")
        if len(parts) != 97:
            break
        agent_id                      = parts[0]
        app_id                        = parts[1]
        pay_status                    = parts[5]
        if not (agent_id == "4" and app_id == "5" and pay_status in ("2", "3")):
            break
        order_status                  = parts[3]
        batch_id                      = parts[7]
        order_id                      = parts[8]
        sub_order_id                  = parts[9]
        ucid                          = parts[11]
        passport_id                   = parts[14]
        baiduid                       = is_null(parts[16])
        user_id                       = parts[17]
        product_id                    = parts[18]
        product_snapshot_id           = parts[19]
        buy_num                       = parts[21]
        package_id                    = parts[22]
        sku_id                        = parts[24]
        product_type                  = parts[27]
        create_time                   = parts[29]
        cancel_time                   = parts[31]
        pay_time                      = parts[32]
        pay_timeout                   = parts[33]
        detail_original_price         = parts[34]
        detail_actual_price           = parts[35]
        detail_total_amount           = parts[36]
        detail_cheap_amount           = parts[37]
        detail_sell_price             = parts[38]
        detail_settle_amount          = parts[39]
        detail_payment_amount         = parts[43]
        detail_freight_amount         = parts[44]
        b_prod_dec_promotion_amount   = parts[47]
        b_ord_dec_promotion_amount    = parts[49]
        p_flush_sale_promotion_amount = parts[51]
        p_full_dec_promotion_amount   = parts[55]
        p_reduc_to_coupon_amount      = parts[59]
        p_full_coupon_amount          = parts[61]
        b_full_coupon_amount          = parts[63]
        flow_channel                  = parts[67]
        author_id                     = parts[69]
        ch                            = parts[70]
        sch                           = parts[71]
        cps_type                      = parts[72]
        position                      = parts[73]
        sence_value                   = parts[74]
        content_id                    = parts[75]
        content_type                  = parts[76]
        zhibo_params                  = is_null(parts[78])
        deliver_tag                   = parts[84]
        first_cate_id                 = parts[85]
        second_cate_id                = parts[87]
        third_cate_id                 = parts[89]
        fourth_cate_id                = parts[91]
        ret = '\t'.join([order_status, \
                pay_status, \
                batch_id, \
                order_id, \
                sub_order_id, \
                ucid, \
                passport_id, \
                baiduid, \
                user_id, \
                product_id, \
                product_snapshot_id, \
                buy_num, \
                package_id, \
                sku_id, \
                product_type, \
                create_time, \
                cancel_time, \
                pay_time, \
                pay_timeout, \
                detail_original_price, \
                detail_actual_price, \
                detail_total_amount, \
                detail_cheap_amount, \
                detail_sell_price, \
                detail_settle_amount, \
                detail_payment_amount, \
                detail_freight_amount, \
                b_prod_dec_promotion_amount, \
                b_ord_dec_promotion_amount, \
                p_flush_sale_promotion_amount, \
                p_full_dec_promotion_amount, \
                p_reduc_to_coupon_amount, \
                p_full_coupon_amount, \
                b_full_coupon_amount, \
                flow_channel, \
                author_id, \
                ch, \
                sch, \
                cps_type, \
                position, \
                sence_value, \
                content_id, \
                content_type, \
                zhibo_params, \
                deliver_tag, \
                first_cate_id, \
                second_cate_id, \
                third_cate_id, \
                fourth_cate_id])
        if True:
            break
    return ret



if __name__ == "__main__":
    for line in sys.stdin:
        ret = order_detail_process(line)
        if ret:
            print(ret)

