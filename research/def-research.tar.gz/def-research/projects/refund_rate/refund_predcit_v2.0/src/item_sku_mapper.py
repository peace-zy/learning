#!/usr/bin/env python
# -*- coding: utf-8 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: item_sku_mapper.py
Author: zhangqifan(zhangqifan01@baidu.com)
Date: 2021/06/08 15:17:45
"""
import sys
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)


def is_null(value):
    """
    �ж�ȱʧֵ
    """
    return "1" if value else "0"


def to_length(value):
    """
    �����ַ�����
    """
    return str(len(str(value).split(',')))


def clean(value):
    """
    ȥ������
    """
    return value.replace(',', '')


def item_sku_process(line, ignore=False):
    """
    ��Ʒ��Ϣ����������
    """
    ret = None
    while True:
        parts = line.split("\t")
        if len(parts) != 77:
            break
        spu_unique_id           = parts[1]
        origin_price            = parts[9]
        price                   = parts[10]
        attribute_option_ids    = to_length(parts[20])
        type                    = parts[22]
        support_pay_type        = parts[23]
        freight_template_id     = parts[24]
        status                  = parts[33]
        state                   = parts[34]
        sub_app_id              = parts[36]
        version                 = parts[38]
        is_delete               = parts[39]
        create_time             = parts[40]
        spu_state               = parts[44]
        reason                  = is_null(parts[45])
        platform_category_ids   = clean(parts[47])
        is_stock_alarm          = parts[48]
        snapshot_version        = parts[50]
        virtual_code_start_time = parts[60]
        virtual_code_end_time   = parts[61]
        ex_tags                 = clean(parts[62])
        commission_rate         = parts[63]
        ret = '\t'.join([spu_unique_id, \
                origin_price, \
                price, \
                attribute_option_ids, \
                type, \
                support_pay_type, \
                freight_template_id, \
                status, \
                state, \
                sub_app_id, \
                version, \
                is_delete, \
                create_time, \
                spu_state, \
                reason, \
                platform_category_ids, \
                is_stock_alarm, \
                snapshot_version, \
                virtual_code_start_time, \
                virtual_code_end_time, \
                ex_tags, \
                commission_rate])
        if True:
            break
    return ret



if __name__ == "__main__":
    for line in sys.stdin:
        ret = item_sku_process(line)
        if ret:
            print(ret)

