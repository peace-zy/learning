#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: dangjinming@baidu.com
  Date  : 21/07/02 10:01:28
  File  : order_postsale_mapper.py
  Desc  : 
"""

import sys

def get_duxiaodian_shop_id():
    """
    ��ö�С��ǰһ��ĵ�����shop_id
    """
    shop_id_set = set()
    with open('./duxiaodian_shop_id.txt', 'r') as fr:
        for line in fr:
            line = line.strip().decode('gb18030', 'ignore')
            shop_id_set.add(line)
    return  shop_id_set  

def order_postsale_process():
    """
    ȡ�ۺ����ݵ�������Ϣ
    """
    shop_id_set = get_duxiaodian_shop_id()
    for line in sys.stdin:
        parts = line.strip().decode('utf-8', 'ignore').split('\t')
        if len(parts) != 39 or \
            parts[8] != "5" or \
            parts[9] not in shop_id_set:
            continue

        refund_type         = parts[1]
        refund_amount       = parts[2]
        refund_num          = parts[3]
        order_id            = parts[7]
        shop_id             = parts[9]
        order_payment       = parts[11]
        product_id          = parts[12]
        baiduid             = parts[19]
        status              = parts[22]
        refund_status       = parts[25]
        order_refund_mark   = parts[28]
        apply_time          = parts[31]
        create_time         = parts[32]
        update_time         = parts[33]
        product_type        = parts[34]
        response_time       = parts[35]
        creator_type        = parts[37]
        is_signed           = parts[38]

        print('\t'.join([
            refund_type,
            refund_amount,
            refund_num,
            order_id,
            shop_id,
            order_payment,
            product_id,
            baiduid,
            status,
            refund_status,
            order_refund_mark,
            apply_time,
            create_time,
            update_time,
            product_type,
            response_time,
            creator_type,
            is_signed
        ])).encode('utf-8', 'ignore')
 
if __name__ == "__main__":
    order_postsale_process()

