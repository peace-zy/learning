#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: preprocess.py
Author: zhangqifan(zhangqifan01@baidu.com)
Date: 2021/06/08 15:17:45
"""
import sys
import os
import pandas as pd
import numpy as np
import time
from datetime import timedelta

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)


def load_online_data(value):
    """
    ��ȡ����-״̬-��Ʒ��
    """
    df = pd.read_csv('%s/../data/detail_flow_item.txt' % value,
                     sep='\t',
                     header=None,
                     names=[
                        'order_status',
                        'pay_status',
                        'batch_id',
                        'order_id',
                        'sub_order_id',
                        'ucid',
                        'passport_id',
                        'baiduid',
                        'user_id',
                        'product_id',
                        'product_snapshot_id',
                        'buy_num',
                        'package_id',
                        'sku_id',
                        'product_type',
                        'create_time_detail',
                        'cancel_time',
                        'pay_time',
                        'pay_timeout',
                        'detail_original_price',
                        'detail_actual_price',
                        'detail_total_amount',
                        'detail_cheap_amount',
                        'detail_sell_price',
                        'detail_settle_amount',
                        'detail_payment_amount',
                        'detail_freight_amount',
                        'b_prod_dec_promotion_amount',
                        'b_ord_dec_promotion_amount',
                        'p_flush_sale_promotion_amount',
                        'p_full_dec_promotion_amount',
                        'p_reduc_to_coupon_amount',
                        'p_full_coupon_amount',
                        'b_full_coupon_amount',
                        'flow_channel',
                        'author_id',
                        'ch',
                        'sch',
                        'cps_type',
                        'position',
                        'sence_value',
                        'content_id',
                        'content_type',
                        'zhibo_params',
                        'deliver_tag',
                        'first_cate_id',
                        'second_cate_id',
                        'third_cate_id',
                        'fourth_cate_id',
                        'order_id_flow',
                        'sent_time',
                        'receipt_time',
                        'consumed_time',
                        'closed_time',
                        'spu_unique_id',
                        'origin_price',
                        'price',
                        'attribute_option_ids',
                        'type',
                        'support_pay_type',
                        'freight_template_id',
                        'status',
                        'state',
                        'sub_app_id',
                        'version',
                        'is_delete',
                        'create_time_item',
                        'spu_state',
                        'reason',
                        'platform_category_ids',
                        'is_stock_alarm',
                        'snapshot_version',
                        'virtual_code_start_time',
                        'virtual_code_end_time',
                        'ex_tags',
                        'commission_rate'
                         ])

    return df

def load_offline_data(value):
    """
    ��ȡ���������ļ�,�������ݣ��ۺ�����
    �Լ�����״̬��(��ȡ��������ʱ����Ϊ��������)
    """
    #��������
    """  �ۺ�����۱���mr֮��һ��Ҫ�Ƚ�����(ȡ)  """
    df_order_evaluate = pd.read_csv('%s/../data/order_evaluate.txt' % value,
                     sep='\t',
                     header=None,
                     error_bad_lines=False,
                     names=[
                        'sku_id',
                        'spu_id',
                        'shop_id',
                        'order_id',
                        'passport_id',
                        'user_id',
                        'images_num',
                        'audit_status',
                        'audit_time',
                        'product_score',
                        'shop_service_score',
                        'shop_logistics_score',
                        'visible',
                        'create_time',
                        'update_time',
                        'is_delete'
                     ])
    df_order_postsale = pd.read_csv('%s/../data/order_postsale.txt' % value,
                     sep='\t',
                     header=None,
                     error_bad_lines=False,
                     names=[
                        'refund_type',
                        'refund_amount',
                        'refund_num',
                        'order_id',
                        'shop_id',
                        'order_payment',
                        'product_id',
                        'baiduid',
                        'status',
                        'refund_status',
                        'order_refund_mark',
                        'apply_time',
                        'create_time',
                        'update_time',
                        'product_type',
                        'response_time',
                        'creator_type',
                        'is_signed'
                     ])
    df_evaluate_postsale = pd.merge(df_order_evaluate, df_order_postsale, on=['order_id'], how='outer')
    df_order_sent_time = pd.read_csv('%s/../data/order_sent_time.txt' % value, 
                        sep='\t',
                        header=None,
                        error_bad_lines=False,
                        names=[
                            'order_id',
                            'sent_time'
                            ])
    df_evaluate_postsale_senttime = pd.merge(df_evaluate_postsale, df_order_sent_time, on=['order_id'])
    return df_evaluate_postsale_senttime

def clean_online_data_time(dataframe):
    """
    ����ʱ���
    """
    dataframe['create_time_detail'] = (pd.to_datetime(dataframe['create_time_detail']) - \
            pd.to_datetime(dataframe['sent_time'])).dt.days
    dataframe['cancel_time'] = (pd.to_datetime(dataframe['cancel_time']) - \
            pd.to_datetime(dataframe['sent_time'])).dt.days
    dataframe['pay_time'] = (pd.to_datetime(dataframe['pay_time']) - \
            pd.to_datetime(dataframe['sent_time'])).dt.days
    dataframe['pay_timeout'] = (pd.to_datetime(dataframe['pay_timeout']) - \
            pd.to_datetime(dataframe['sent_time'])).dt.days
    dataframe['receipt_time'] = (pd.to_datetime(dataframe['receipt_time']) - \
            pd.to_datetime(dataframe['sent_time'])).dt.days
    dataframe['consumed_time'] = (pd.to_datetime(dataframe['consumed_time']) - \
            pd.to_datetime(dataframe['sent_time'])).dt.days
    dataframe['closed_time'] = (pd.to_datetime(dataframe['closed_time']) - \
            pd.to_datetime(dataframe['sent_time'])).dt.days
    dataframe['create_time_item'] = (pd.to_datetime(dataframe['create_time_item']) - \
            pd.to_datetime(dataframe['sent_time'])).dt.days
    dataframe['virtual_code_start_time'] = (pd.to_datetime(dataframe['virtual_code_start_time']) - \
            pd.to_datetime(dataframe['sent_time'])).dt.days
    dataframe['virtual_code_end_time'] = (pd.to_datetime(dataframe['virtual_code_end_time']) - \
            pd.to_datetime(dataframe['sent_time'])).dt.days
    #����ʱ�侫ȷ����
    dataframe['sent_time'] = dataframe['sent_time'].map(lambda x:x[:-9])

    return dataframe

def clean_offline_data(dataframe):
    """
    ȱʧֵ����ʱ�������Լ����ݼ�
    """
    #ȱʧֵ���
    dataframe['create_time_x'] = dataframe['create_time_x'].fillna(dataframe['create_time_y'])
    dataframe['create_time_y'] = dataframe['create_time_y'].fillna(dataframe['create_time_x'])
    dataframe['audit_time'] = dataframe['audit_time'].fillna(dataframe['sent_time'])
    dataframe['update_time_x'] = dataframe['update_time_x'].fillna(dataframe['sent_time'])
    dataframe['update_time_y'] = dataframe['update_time_y'].fillna(dataframe['sent_time'])
    dataframe['apply_time'] = dataframe['apply_time'].fillna(dataframe['sent_time'])
    dataframe['response_time'] = dataframe['response_time'].fillna(dataframe['sent_time'])
    dataframe['shop_id_x'] = dataframe['shop_id_x'].fillna(dataframe['shop_id_y'])

    #ȥ��������
    dataframe.drop(dataframe.loc[dataframe['audit_time'].str.len() != 19].index, inplace=True)
    dataframe.drop(dataframe.loc[dataframe['update_time_x'].str.len() != 19].index, inplace=True)
    dataframe = dataframe.dropna(axis=0, subset = ["shop_id_x"])
    dataframe.drop(dataframe.loc[dataframe['shop_id_x'] == 0].index, inplace=True)

    #ʱ������
    dataframe['create_time_x'] = \
        (pd.to_datetime(dataframe['create_time_x'])-pd.to_datetime(dataframe['sent_time'])).dt.days
    dataframe['audit_time'] = \
        (pd.to_datetime(dataframe['audit_time'])-pd.to_datetime(dataframe['sent_time'])).dt.days      
    dataframe['update_time_x'] = \
        (pd.to_datetime(dataframe['update_time_x'])-pd.to_datetime(dataframe['sent_time'])).dt.days      
    dataframe['update_time_y'] = \
        (pd.to_datetime(dataframe['update_time_y'])-pd.to_datetime(dataframe['sent_time'])).dt.days      
    dataframe['apply_time'] = \
        (pd.to_datetime(dataframe['apply_time'])-pd.to_datetime(dataframe['sent_time'])).dt.days
    dataframe['response_time'] = \
        (pd.to_datetime(dataframe['response_time'])-pd.to_datetime(dataframe['sent_time'])).dt.days

    #ȥ�����û��ظ���
    dataframe.drop('sent_time', axis=1, inplace=True)

    #�ۺ󴴽�ʱ��ʱ��ȷ������
    dataframe['create_time_y'] = dataframe['create_time_y'].map(lambda x:x[:-9])
    dataframe = dataframe.fillna(0)
    dataframe.loc[:, dataframe.dtypes == float] = dataframe.loc[:, dataframe.dtypes == float].astype('int')  
    return dataframe

def onehot_and_agg_offline_data(dataframe):
    """����������onehot�����ͷ���ۺ�"""
    #onehot����������
    dataframe = pd.get_dummies(data=dataframe, 
                                columns=[
                                "audit_status",
                                "product_score",
                                "shop_service_score",
                                "shop_logistics_score",
                                "refund_type",
                                # "status",
                                "refund_status",
                                "order_refund_mark",
                                "product_type",
                                "creator_type"])
    dataframe.to_csv('../data/df_offline.txt', sep='\t')
    dataframe = dataframe.groupby(['shop_id_x', 'create_time_y']).agg(
        {
            'sku_id': lambda x:x.nunique(),
            'spu_id': lambda x:x.nunique(),
            'order_id': lambda x:x.nunique(),
            'passport_id': lambda x:x.nunique(),
            'user_id': lambda x:x.nunique(),
            'product_id': lambda x:x.nunique(),
            'images_num': ['max', 'min', 'count', 'mean'],
            'audit_time': ['max', 'min', 'count', 'mean'],
            'create_time_x': ['max', 'min', 'count', 'mean'],
            'update_time_x': ['max', 'min', 'count', 'mean'],
            'refund_amount': ['max', 'min', 'count', 'mean'],
            'refund_num': ['max', 'min', 'count', 'mean'],
            'apply_time': ['max', 'min', 'count', 'mean'],
            'update_time_y': ['max', 'min', 'count', 'mean'],
            'response_time': ['max', 'min', 'count', 'mean'],
            'status': 'mean',
            'is_delete': 'sum',
            'audit_status_0': 'sum',
            'audit_status_1': 'sum',
            'audit_status_2': 'sum',
            'product_score_1':'sum',
            'product_score_2':'sum',
            'product_score_3':'sum',
            'product_score_4':'sum',
            'product_score_5':'sum',
            'shop_service_score_1':'sum',
            'shop_service_score_2':'sum',
            'shop_service_score_3':'sum',
            'shop_service_score_4':'sum',
            'shop_service_score_5':'sum',
            'shop_logistics_score_1':'sum',
            'shop_logistics_score_2':'sum',
            'shop_logistics_score_3':'sum',
            'shop_logistics_score_4':'sum',
            'shop_logistics_score_5':'sum',
            'refund_type_1':'sum',
            'refund_type_2':'sum',
            'refund_type_3':'sum',
            'refund_status_0':'sum',
            'refund_status_1':'sum',
            'refund_status_2':'sum',
            'order_refund_mark_0':'sum',
            'order_refund_mark_1':'sum',
            'product_type_0':'sum',
            'product_type_2':'sum',
            'creator_type_0':'sum',
            'creator_type_2':'sum'
        })
    #�����ϲ�
    dataframe.columns = ['_'.join(col) for col in dataframe.columns.values]
    return dataframe

def make_offline_feature(dataframe, today):
    """
    ������������
    """
    shop_id_set = set(list(dataframe.reset_index()["shop_id_x"]))
    train_without_label = {}
    for shop_id in shop_id_set:
        #����ÿһ��shop_id �������ܵ�label_day��������
        label_day = pd.to_datetime(today) + timedelta(days=1)
        #����ÿһ��label_day��������������
        feature_lst = np.array([0.0 for _ in range(74)])
        flag = False
        for d in range(60, 0, -1):
            feature_day = label_day - timedelta(days=d)
            feature_day_index = str(feature_day).split(' ')[0]
            if (shop_id, feature_day_index) in dataframe.index:
                flag = True
                feature_lst += np.array(dataframe.loc[(shop_id, feature_day_index)])
        if flag:
            label_day_format = str(label_day).split(' ')[0]
            train_without_label[shop_id] = {label_day_format:feature_lst}

    reform = {(shop_id, day):feature for shop_id, day_feature in train_without_label.items() \
        for day, feature in day_feature.items()}
    df = pd.DataFrame.from_dict(reform).T.reset_index()
    return df

def fillna_dtypes(dataframe):
    """
    ���ȱʧֵ����ֵ����ת��
    """
    dataframe.loc[:, (dataframe.columns != 'sent_time') & (dataframe.dtypes == object)] = \
            dataframe.loc[:, (dataframe.columns != 'sent_time') & (dataframe.dtypes == object)]\
            .apply(lambda x:pd.to_numeric(x, errors='coerce'))
    dataframe = dataframe.fillna(0)
    dataframe.loc[:, dataframe.dtypes == float] = dataframe.loc[:, dataframe.dtypes == float].astype('int')
    dataframe.to_csv('../data/df_online.txt', sep='\t')
    return dataframe

def group_by(dataframe):
    """
    �����ۺϣ������̰�����ά�Ⱦۺ�
    """
    df = dataframe.groupby(['ucid', 'sent_time']).agg({
        'batch_id': lambda x:x.nunique(),
        'order_id':  lambda x:x.nunique(),
        'sub_order_id': lambda x:x.nunique(),
        'passport_id': lambda x:x.nunique(),
        'user_id': lambda x:x.nunique(),
        'product_id': lambda x:x.nunique(),
        'product_snapshot_id': lambda x:x.nunique(),
        'buy_num': ['max', 'min', 'count', 'mean'],
        'package_id': lambda x:x.nunique(),
        'sku_id': lambda x:x.nunique(),
        'create_time_detail': ['max', 'min', 'count', 'mean'],
        'cancel_time': ['max', 'min', 'count', 'mean'],
        'pay_time': ['max', 'min', 'count', 'mean'],
        'pay_timeout': ['max', 'min', 'count', 'mean'],
        'detail_original_price': ['max', 'min', 'count', 'mean'],
        'detail_actual_price': ['max', 'min', 'count', 'mean'],
        'detail_total_amount': ['max', 'min', 'count', 'mean'],
        'detail_cheap_amount': ['max', 'min', 'count', 'mean'],
        'detail_sell_price': ['max', 'min', 'count', 'mean'],
        'detail_settle_amount': ['max', 'min', 'count', 'mean'],
        'detail_payment_amount': ['max', 'min', 'count', 'mean'],
        'detail_freight_amount': ['max', 'min', 'count', 'mean'],
        'b_prod_dec_promotion_amount': ['max', 'min', 'count', 'mean'],
        'b_ord_dec_promotion_amount': ['max', 'min', 'count', 'mean'],
        'p_flush_sale_promotion_amount': ['max', 'min', 'count', 'mean'],
        'p_full_dec_promotion_amount': ['max', 'min', 'count', 'mean'],
        'p_reduc_to_coupon_amount': ['max', 'min', 'count', 'mean'],
        'p_full_coupon_amount': ['max', 'min', 'count', 'mean'],
        'b_full_coupon_amount': ['max', 'min', 'count', 'mean'],
        'author_id': lambda x:x.nunique(),
        'sch': lambda x:x.nunique(),
        'sence_value': lambda x:x.nunique(),
        'content_id': lambda x:x.nunique(),
        'receipt_time': ['max', 'min', 'count', 'mean'],
        'consumed_time': ['max', 'min', 'count', 'mean'],
        'closed_time': ['max', 'min', 'count', 'mean'],
        'origin_price': ['max', 'min', 'count', 'mean'],
        'price': ['max', 'min', 'count', 'mean'],
        'attribute_option_ids': ['max', 'min', 'count', 'mean'],
        'freight_template_id': lambda x:x.nunique(),
        'version': lambda x:x.nunique(),
        'create_time_item': ['max', 'min', 'count', 'mean'],
        'platform_category_ids': lambda x:x.nunique(),
        'snapshot_version': lambda x:x.nunique(),
        'virtual_code_start_time': ['max', 'min', 'count', 'mean'],
        'virtual_code_end_time': ['max', 'min', 'count', 'mean'],
        'commission_rate': ['max', 'min', 'count', 'mean'],
        'order_status': 'mean',
        'pay_status': 'mean',
        'baiduid': 'mean',
        'product_type': 'mean',
        'flow_channel': 'mean',
        'ch': 'mean',
        'cps_type': 'mean',
        'position': 'mean',
        'content_type': 'mean',
        'zhibo_params': 'mean',
        'deliver_tag': 'mean',
        'first_cate_id': 'mean',
        'second_cate_id': 'mean',
        'third_cate_id': 'mean',
        'fourth_cate_id': 'mean',
        'type': 'mean',
        'support_pay_type': 'mean',
        'status': 'mean',
        'state': 'mean',
        'sub_app_id': 'mean',
        'is_delete': 'mean',
        'reason': 'mean',
        'is_stock_alarm': 'mean',
        'ex_tags': 'mean'
    })

    return df

def make_online_features(dataframe, today):
    """
    ����30������
    """
    train_without_label = {}
    dump_lst = np.array([0.0 for _ in range(161)])
    for ucid in dataframe.index.unique(level=0):
        label_day = pd.to_datetime(today) + timedelta(days=1)
        feature_lst = np.array([0.0 for _ in range(161)])
        for d in range(30, 0, -1):
            day_d = label_day - timedelta(days=d)
            day_index = str(day_d).split(' ')[0]
            if (ucid, day_index) in dataframe.index:
                feature_lst += np.array(dataframe.loc[(ucid, day_index)])
        feature_lst = np.array(feature_lst)
        label_day_format = str(label_day).split(' ')[0]
        train_without_label[ucid] = {label_day_format: feature_lst}

    #��ucid,����Ϊkey��30����������Ϊvalue
    reform = {(ucid, day):feature for ucid, day_feature in train_without_label.items() \
                for day, feature in day_feature.items()}
    #�ֵ�תdataframe��ת��
    df = pd.DataFrame.from_dict(reform).T.reset_index()
    return df

def merge_online_offline(df_online, df_offline):
    """�����Ϻ��������ݽ��кϲ�"""
    df_on_off_line = pd.merge(df_online, df_offline, on=['level_0', 'level_1'], how='left')
    df_on_off_line = df_on_off_line.set_index(['level_0', 'level_1'])
    df_on_off_line = df_on_off_line.fillna(0)
    df_on_off_line.columns = [str(i) for i in range(len(df_on_off_line.columns))]

    return df_on_off_line.reset_index()

def output(dataframe, loc):
    """
    �����Ԥ���ļ�
    """
    dataframe.to_csv('%s/../data/feature.txt' % loc, index=False)


def main(value, today):
    """
    ������
    """
    #��������
    df_online = load_online_data(value)
    df_online = clean_online_data_time(df_online)
    df_online = fillna_dtypes(df_online)
    df_online = group_by(df_online)
    df_online = make_online_features(df_online, today)
    #��������
    df_offline = load_offline_data(value) 
    df_offline = clean_offline_data(df_offline)
    df_offline = onehot_and_agg_offline_data(df_offline)
    df_offline = make_offline_feature(df_offline, today)
    #���ݺϲ�
    df_feature = merge_online_offline(df_online, df_offline)
    #���
    output(df_feature, value)


if __name__ == "__main__":
    now = time.strftime('%Y-%m-%d', time.localtime())
    main(_cur_dir, now)
