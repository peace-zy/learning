#!/usr/bin/env python
# -*- coding: utf-8 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: order_flow_mapper.py
Author: zhangqifan(zhangqifan01@baidu.com)
Date: 2021/06/08 15:17:45
"""
import sys
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)


def order_flow_process(line, ignore=False):
    """
    ����ʱ��״̬����������
    """
    ret = None
    while True:
        parts = line.split("\t")
        if len(parts) != 10:
            break
        order_id      = parts[0]
        sent_time     = parts[3]
        receipt_time  = parts[4]
        consumed_time = parts[6]
        closed_time   = parts[7]
        if not (sent_time != "\\N" and sent_time != ""):
            break
        ret = '\t'.join([order_id, \
                sent_time, \
                receipt_time, \
                consumed_time, \
                closed_time])
        if True:
            break
    return ret



if __name__ == "__main__":
    for line in sys.stdin:
        ret = order_flow_process(line)
        if ret:
            print(ret)

