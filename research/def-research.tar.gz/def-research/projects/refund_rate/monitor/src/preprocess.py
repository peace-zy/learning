# -*- coding: gbk -*-
"""
File  :   preprocess.py
Author:   zhangqifan01@baidu.com
Date  :   21/04/22 16:15:00
Desc  :   ������̼�ÿ�յ��˻���
"""

import os
import pandas as pd
import datetime


def read_file(today):
    """
    ��ȡ�м��
    """
    df_order_refund = pd.read_csv( \
    '/home/work/zhangqifan01/duxiaodian/monitor/data/order_refund_%s_filter.txt' % today, \
    header=None, \
    error_bad_lines=False, \
    names=['order_detail_id'])

    df_order_detail = pd.read_csv( \
    '/home/work/zhangqifan01/duxiaodian/monitor/data/fengchao_biz_ecom_dwd_order_detail_%s_filter.txt' % today, \
    sep='\t', \
    header=None, \
    error_bad_lines=False, \
    names=['order_id', 'sub_order_id', 'ucid', 'shop_name'])

    df_order_flow = pd.read_csv('/home/work/zhangqifan01/duxiaodian/monitor/data/order_flow_%s_filter.txt' % today, \
    sep='\t', \
    header=None, \
    error_bad_lines=False, \
    names=['order_id', 'sent_time'])


    return df_order_refund, df_order_detail, df_order_flow

def tabulate(order_refund, order_detail, order_flow):
    """
    �����ɽ��������˻��ʱ�
    """
    #����ʱ��״̬��ת�����˵�sent_timeΪ�յ�
    order_flow = order_flow.dropna(subset=['sent_time'])
    #�����ɽ�����
    df_detail_senttime = pd.merge(order_detail, \
                                  order_flow, \
                                  left_on='order_id', \
                                  right_on='order_id')
    #�ɼ���������ʱ����������
    df_detail_senttime.sent_time = df_detail_senttime.sent_time.map(lambda x:str(x).split(' ')[0])
    #�ɽ���unstack����ĸ����
    df_fenmu = df_detail_senttime.groupby(['ucid', 'sent_time'])['sub_order_id'].count().unstack()

    #�����˻�����
    df_detail_senttime_refund = pd.merge(df_detail_senttime, \
                                         order_refund, \
                                         left_on='sub_order_id', \
                                         right_on='order_detail_id')
    #�˻�����unstack�����ӱ���
    df_fenzi = df_detail_senttime_refund.groupby(['ucid', 'sent_time'])['sub_order_id'].count().unstack()
    #�����˻��ʱ�
    df_refund_rate = df_fenzi.div(df_fenmu)


    return df_fenmu, df_fenzi, df_refund_rate

def output(turnover, refundrate, today):
    """
    �������ļ�
    """
    turnover.to_csv('/home/work/zhangqifan01/duxiaodian/monitor/output/turnover_%s.csv'\
            % today, encoding='GB18030')
    refundrate.to_csv('/home/work/zhangqifan01/duxiaodian/monitor/output/refund_rate_%s.csv'\
            % today, encoding='GB18030')



if __name__ == "__main__":
    today = (datetime.datetime.now() + datetime.timedelta(days = -1)).strftime('%Y%m%d')
    df1, df2, df3 = read_file(today)
    fenmu, fenzi, refund_rate = tabulate(df1, df2, df3)
    output(fenmu, refund_rate, today)




