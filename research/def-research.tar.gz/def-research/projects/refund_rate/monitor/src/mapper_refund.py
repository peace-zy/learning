#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: mapper.py
Author: zhangqifan(zhangqifan01@baidu.com)
Date: 2021/05/10 20:04:05
"""
import sys
import os
import random
import json
import urllib

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

def text_normalize(text):
    """��һ���ı�
    [in]  text: str, δ�������ı�
    [out] ���ع�һ�����ı�
    """
    text = urllib.unquote(text.lower())
    text = text.replace("\t", " ").replace("\n", " ").replace("\r", " ").replace("\x01", " ").replace("\x02", " ")
    return text


def click_process(line, ignore=False):
    """��������
    """
    ret = None
    while True:
        parts = line.split('\t')
        order_detail_id  = parts[29]
        refund_type      = parts[1]
        status           = parts[22]
        if not (refund_type == "2" and status == "600"):
            break
        ret = '\t'.join([order_detail_id])
        if True:
            break
    return ret



if __name__ == "__main__":
    for line in sys.stdin:
        ret = click_process(line)
        if ret:
            print(ret.encode("gb18030"))

