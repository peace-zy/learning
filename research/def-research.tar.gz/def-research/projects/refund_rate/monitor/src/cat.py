#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: ../src/cat.py
Author: work(work@baidu.com)
Date: 2020/12/16 19:28:38
"""
import sys


if __name__ == "__main__":
    for eachline in sys.stdin:
        print(eachline.strip("\n"))
