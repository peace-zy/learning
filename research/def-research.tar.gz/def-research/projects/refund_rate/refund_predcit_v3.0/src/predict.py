#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################

"""
File: predict.py
Author: dangjinming@baidu.com
Date: 2021/08/30
"""

import sys
import os
import pandas as pd
import joblib
import numpy as np
import pickle 

from tensorflow.keras.layers import Dense, Input, LSTM, GlobalMaxPool1D, Concatenate, SpatialDropout1D
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam, SGD
from tensorflow.keras import metrics, losses


_cur_dir = os.path.dirname(os.path.abspath(__file__))

#�����Ż������ۺ�������������
optimizer = Adam()
loss_func = losses.MeanSquaredError()
train_loss = metrics.Mean(name='train_loss')
train_metric = metrics.MeanSquaredError(name='MeanSquaredError')
valid_loss = metrics.Mean(name='valid_loss')
valid_metric = metrics.BinaryAccuracy(name='valid_accuracy')

def read_pkl(file_name):
    """
    ��ȡpkl�ļ�
    """
    with open(file_name, 'rb') as fr:

        return pickle.load(fr)

def load_data(features, shop_id_nofeature):
    """
    ��ȡ��Ԥ����������
    """
    result = {}
    pre_features = read_pkl(features)
    shop_id_nofea = read_pkl(shop_id_nofeature)
    shop_ids = list(pre_features.keys())
    features_on = []
    features_off = []
    for shop_id in shop_ids:
        features_on.append(pre_features[shop_id][0])
        features_off.append(pre_features[shop_id][1])
    result['shop_ids'] = shop_ids
    result['features_on'] = features_on
    result['features_off'] = features_off
    result['shop_id_nofea'] = shop_id_nofea

    return result

def get_model():
    """����ģ��ʵ��"""
    x_online = Input(shape=(30, 100, ), name='online')
    x_offline = Input(shape=(30, 100, ), name='offline')
    x_on = LSTM(100, return_sequences=True)(x_online)
    x_on_off = Concatenate(axis=-1)([x_offline, x_on])
    x_on_off = SpatialDropout1D(0.15)(x_on_off)
    x_on_off = LSTM(300, return_sequences=True)(x_on_off)
    x_on_off = GlobalMaxPool1D()(x_on_off)
    x_on_off = Dense(1, activation='sigmoid', name='d1')(x_on_off)
    model = Model(inputs=[x_online, x_offline], outputs=x_on_off)

    return model

def get_predict():
    """
    Ԥ��
    """
    result = load_data(
        '%s/../data/pre_features.pkl' % _cur_dir, 
        '%s/../data/shop_id_no_feature.pkl' % _cur_dir)
    shop_ids = result['shop_ids']
    features_on = result['features_on']
    features_off = result['features_off']
    shop_id_nofea = result['shop_id_nofea']
    model_1 = get_model()
    model_2 = get_model()
    model_3 = get_model()
    model_4 = get_model()
    model_5 = get_model()
    model_6 = get_model()
    model_7 = get_model()
    model_1.load_weights('%s/../model/model_32_xunhuan_day1.h5' % _cur_dir)
    model_2.load_weights('%s/../model/model_32_xunhuan_day2.h5' % _cur_dir)
    model_3.load_weights('%s/../model/model_32_xunhuan_day3.h5' % _cur_dir)
    model_4.load_weights('%s/../model/model_32_xunhuan_day4.h5' % _cur_dir)
    model_5.load_weights('%s/../model/model_32_xunhuan_day5.h5' % _cur_dir)
    model_6.load_weights('%s/../model/model_32_xunhuan_day6.h5' % _cur_dir)
    model_7.load_weights('%s/../model/model_32_xunhuan_day7.h5' % _cur_dir)
    pred_ans_1 = model_1.predict([np.array(features_on), np.array(features_off)], batch_size=10)
    pred_ans_2 = model_2.predict([np.array(features_on), np.array(features_off)], batch_size=10)
    pred_ans_3 = model_3.predict([np.array(features_on), np.array(features_off)], batch_size=10)
    pred_ans_4 = model_4.predict([np.array(features_on), np.array(features_off)], batch_size=10)
    pred_ans_5 = model_5.predict([np.array(features_on), np.array(features_off)], batch_size=10)
    pred_ans_6 = model_6.predict([np.array(features_on), np.array(features_off)], batch_size=10)
    pred_ans_7 = model_7.predict([np.array(features_on), np.array(features_off)], batch_size=10)
    pred_ans = np.concatenate((pred_ans_1, pred_ans_2, pred_ans_3, pred_ans_4, \
            pred_ans_5, pred_ans_6, pred_ans_7), axis=1)

    return shop_ids, pred_ans, shop_id_nofea

def output(res, loc, shop_ids, shop_id_nofea):
    """
    �����Ԥ���ļ�
    """
    df_res = pd.DataFrame(res).applymap(lambda x:0.0 if x < 0 else np.round(x, 4))
    df_shop_id = pd.DataFrame(shop_ids, columns=['shop_id'])
    df_result = pd.concat([df_shop_id[['shop_id']], df_res], axis=1)
    df_pre_zero  = pd.DataFrame(0, index=range(len(shop_id_nofea)), \
            columns=['shop_id', '0', '1', '2', '3', '4', '5', '6'])
    df_pre_zero['shop_id'] = list(shop_id_nofea)
    df_pre_zero.columns = df_result.columns
    df = pd.concat([df_result, df_pre_zero], axis=0, ignore_index=True)
    df.to_csv('%s/../output/result_7days.txt' % loc, header=None, sep='\t', index=None)

def main(value):
    """
    ������
    """
    shop_ids, pre_res, shop_id_nofea = get_predict()
    output(pre_res, value, shop_ids, shop_id_nofea)

if __name__ == "__main__":
    main(_cur_dir)
