#!/usr/bin/env python
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: ../src/cat.py
Author: work(work@baidu.com)
Date: 2020/12/16 19:28:38
"""
import sys


if __name__ == "__main__":
    for eachline in sys.stdin:
        print(eachline.strip("\n"))
