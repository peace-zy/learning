#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: preprocess.py
Author:dangjinming@baidu.com
Date: 2021/08/30
"""
import sys
import os
import pandas as pd
import numpy as np
import time
import pickle

from sklearn.externals import joblib
from datetime import timedelta

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)


def load_online_data(file_in, today):
    """
    �������ݵĶ�ȡ
    ֻȡ��30�������(�漰��shop_id���ܸ���ȫ��)
    ���Ե�����¼�����漰��shop_id
    """
    label_day = pd.to_datetime(today) + timedelta(days=1)
    tem_dict = {}
    shop_ids = set()
    with open(file_in, 'r', encoding='gb18030') as fr:
        for index, line in enumerate(fr):
            if index == 0:
                header = line.strip().split('\t')
                continue
            line = line.strip().split('\t')
            if len(line) != 77:
                continue
            sent_time = line[51]
            shop_id = line[6]
            shop_ids.add(shop_id)
            if (label_day - pd.to_datetime(sent_time)).days <= 30:
                tem_dict[line[0]] = line[1:]
        df_online_data = pd.DataFrame.from_dict(tem_dict, orient='index')
        df_online_data.columns = header

    return df_online_data, shop_ids

def deal_online_data(df_data, scaler_filename, translate_file):
    """
    ȥ��������,��һ��,ϡ������ת��Ϊ��������
    """
    translate = pd.read_csv(translate_file, sep='\t')
    translate = np.array(translate)
    df_data = df_data.fillna(0)
    df_data.drop('batch_id', axis=1, inplace=True)
    df_data.drop('sub_order_id', axis=1, inplace=True)
    df_data.drop('passport_id', axis=1, inplace=True)
    df_data.drop('baiduid', axis=1, inplace=True)
    df_data.drop('product_id', axis=1, inplace=True)
    df_data.drop('order_id_flow', axis=1, inplace=True)
    df_data.drop('spu_unique_id', axis=1, inplace=True)
    df_data.drop('sku_id', axis=1, inplace=True)
    df_data.drop('user_id', axis=1, inplace=True)
    df_data.drop('package_id', axis=1, inplace=True)
    df_data.drop('author_id', axis=1, inplace=True)
    df_data.drop('content_id', axis=1, inplace=True)
    df_data.drop_duplicates(subset='order_id', keep='first', inplace=True)
    df_data = df_data.sort_values(['ucid', 'sent_time', 'order_id'], \
        ascending=[True, True, True])\
            .set_index(['ucid', 'sent_time', 'order_id'])
    #��һ��
    scaler = joblib.load(scaler_filename)
    df_data[list(df_data.columns)] = scaler.transform(df_data[list(df_data.columns)])
    #ϡ������ת��������
    shopid_day_nums  = {}
    shopid_day_features = {}
    for index, row in df_data.iterrows():
        shop_id, create_time, order_id = index
        k = str(shop_id) + '_' + str(create_time)
        shopid_day_nums[k] = shopid_day_nums.get(k, 0) + 1
        value = shopid_day_features.get(k, np.array([0.0] * 100))
        value += np.squeeze(np.matmul(np.expand_dims(list(row), 0), translate))
        shopid_day_features[k] = value
    #ȡƽ��ֵ
    for k in shopid_day_features:
        nums = shopid_day_nums.get(k, 1)
        shopid_day_features[k] = shopid_day_features[k] / nums
    df_data = pd.DataFrame.from_dict(shopid_day_features, orient='index')

    return df_data

def load_offline_data(file_in, today):
    """
    �������ݵĶ�ȡ��ֻȡ��30�������
    """
    label_day = pd.to_datetime(today) + timedelta(days=1)
    tem_dict = {}
    with open(file_in, 'r', encoding='gb18030') as fr:
        for index, line in enumerate(fr):
            if index == 0:
                header = line.strip().split('\t')
                continue
            line = line.strip().split('\t')
            if len(line) != 60:
                continue
            create_time = line[21]
            if (label_day - pd.to_datetime(create_time)).days <= 30:
                tem_dict[line[0]] = line[1:]
        df_offline_data = pd.DataFrame.from_dict(tem_dict, orient='index')
        df_offline_data.columns = header

    return df_offline_data

def deal_offline_data(df_data, scaler_filename, translate_file):
    """
    ȥ��������,��һ��,ϡ������ת��Ϊ��������
    """
    translate = pd.read_csv(translate_file, sep='\t')
    translate = np.array(translate)
    #ȱʧֵ���
    df_data = df_data.fillna(0)
    #ȥ������������
    df_data.drop('passport_id', axis=1, inplace=True)
    df_data.drop('user_id', axis=1, inplace=True)
    df_data.drop('shop_id_y', axis=1, inplace=True)
    df_data.drop('baiduid', axis=1, inplace=True)
    df_data.drop('sku_id', axis=1, inplace=True)
    df_data.drop('spu_id', axis=1, inplace=True)
    #����order_idȥ��(һ�������ж���Ӷ���)
    df_data.drop_duplicates(subset='order_id', keep='first', inplace=True)
    #�趨index
    df_data = df_data.sort_values(['shop_id_x', 'create_time_y', 'order_id'], \
        ascending=[True, True, True])\
            .set_index(['shop_id_x', 'create_time_y', 'order_id'])
    #��һ��
    scaler = joblib.load(scaler_filename)
    df_data[list(df_data.columns)] = scaler.transform(df_data[list(df_data.columns)])
    #ϡ������ת��������
    shopid_day_nums  = {}
    shopid_day_features = {}
    for index, row in df_data.iterrows():
        shop_id, create_time, order_id = index
        k = str(shop_id) + '_' + str(create_time)
        shopid_day_nums[k] = shopid_day_nums.get(k, 0) + 1
        value = shopid_day_features.get(k, np.array([0.0]*100))
        value += np.squeeze(np.matmul(np.expand_dims(list(row), 0), translate))
        shopid_day_features[k] = value
    #ȡƽ��ֵ
    for k in shopid_day_features:
        nums = shopid_day_nums.get(k, 1)
        shopid_day_features[k] = shopid_day_features[k] / nums
    df_data = pd.DataFrame.from_dict(shopid_day_features, orient='index')

    return df_data

def merge_data(df_online, df_offline):
    """
    �����������ݵĺϲ�
    """
    df_online.columns = ['on_' + str(col) for col in df_online.columns.values]
    df_online = df_online.reset_index()
    df_online['shop_id'] = df_online.apply(lambda x: x['index'].split('_')[0], axis=1)
    df_online['day'] = df_online.apply(lambda x: x['index'].split('_')[1], axis=1)
    df_online.drop('index', axis=1, inplace=True)
    df_online = df_online.sort_values(['shop_id', 'day'], ascending=[True, True] ).set_index(['shop_id', 'day'])

    df_offline.columns = ['off_' + str(col) for col in df_offline.columns.values]
    df_offline = df_offline.reset_index()
    df_offline['shop_id'] = df_offline.apply(lambda x: x['index'].split('_')[0], axis=1)
    df_offline['day'] = df_offline.apply(lambda x: x['index'].split('_')[1], axis=1)
    df_offline.drop('index', axis=1, inplace=True)
    df_offline = df_offline.sort_values(['shop_id', 'day'], ascending=[True, True] ).set_index(['shop_id', 'day'])

    df_on_off = pd.merge(df_online.reset_index(), 
                        df_offline.reset_index(), 
                        left_on=['shop_id', 'day'], 
                        right_on=['shop_id', 'day'], 
                        how='left')
    df_on_off = df_on_off.set_index(['shop_id', 'day']).fillna(0)

    return df_on_off

def make_features(df_on_off, today, shop_ids):
    """
    ��������ģ������feature
    """
    pre_features = {}
    shop_id_no_feature = set()
    for shop_id in shop_ids:
        pre_feature_on = []
        pre_feature_off = []
        #����ÿһ��shop_id �������ܵ�label_day��������
        label_day = pd.to_datetime(today) + timedelta(days=1)
        feature_default = [0.0 for _ in range(100)]
        flag = False#��¼��ǰshop_id30�����Ƿ�����һ�����feature
        for d in range(30, 0, -1):
            feature_day = label_day - timedelta(days=d)
            feature_day_index = str(feature_day).split(' ')[0]
            if (shop_id, feature_day_index) in df_on_off.index:
                flag = True
                pre_feature_on.append(list(df_on_off.loc[(shop_id, feature_day_index)])[:100])
                pre_feature_off.append(list(df_on_off.loc[(shop_id, feature_day_index)])[100:])
            else:
               pre_feature_on.append(feature_default) 
               pre_feature_off.append(feature_default)
        if flag:
            label_day_format = str(label_day).split(' ')[0]
            pre_features[shop_id] = [pre_feature_on, pre_feature_off]
        else:
            shop_id_no_feature.add(shop_id)
            
    return pre_features, shop_id_no_feature

def output(pre_features, shop_id_no_feature):
    """
    �����Ԥ���ļ�
    """
    with open(_cur_dir + '/../data/pre_features.pkl', 'wb') as fw:
        pickle.dump(pre_features, fw)
    with open(_cur_dir + '/../data/shop_id_no_feature.pkl', 'wb') as fw:
        pickle.dump(shop_id_no_feature, fw)

def main(day):
    """
    ������
    """
    #�������ݴ���
    df_online, shop_ids= load_online_data('../data/df_online.txt', today)
    df_online = deal_online_data(df_online, '../model/online_scaler.save', '../model/online_translate.txt')
    #�������ݴ���
    df_offline = load_offline_data('../data/df_offline.txt', today)
    df_offline = deal_offline_data(df_offline, '../model/offline_scaler.save', '../model/offline_translate.txt')
    #���ߺ��������ݺϲ�����������
    df_on_off = merge_data(df_online, df_offline)
    pre_features, shop_id_no_feature= make_features(df_on_off, today, shop_ids)
    #�����������������shop_id
    output(pre_features, shop_id_no_feature)

if __name__ == "__main__":
    today = time.strftime('%Y-%m-%d', time.localtime())
    today = '20210715'
    main(today)

    
