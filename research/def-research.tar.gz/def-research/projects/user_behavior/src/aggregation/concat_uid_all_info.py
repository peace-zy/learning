#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/16 20:19:09
"""
拼接所有类型的特征
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")
import random
import json

def load_input_uid_file(filename):
    """读取uid信息
    """
    uid_list = []
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        uid_list.append(uid)
    f.close()
    return uid_list

def load_feature_dict(filename):
    """读取各类型特征信息
    """
    feature_dict = dict()
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        #feature_cnt 0: 特征长度 1: 特征值, libsvm格式
        feature_cnt = json.loads(data[1])
        feature_dict[uid] = feature_cnt
    f.close()
    return feature_dict

if __name__ == "__main__":
    input_uid_file = sys.argv[1]
    feature_file_list = (sys.argv[2]).split('!!')
    
    uid_list = load_input_uid_file(input_uid_file)
    uid_features = dict()
    #特征总长度
    now_max_index = 0
    for uid in uid_list:
        uid_features[uid] = dict()
    for feature_file in feature_file_list:
        feature_dict = load_feature_dict(feature_file)
        if len(feature_dict.items()) == 0:
            continue
        feature_len = int((random.sample(feature_dict.items(), 1))[0][1][0])
        for uid in uid_list:
            if uid in feature_dict:
                feature_infos = feature_dict[uid][1]
                for fea_i, fea_v in feature_infos.items():
                    uid_features[uid][int(fea_i) + now_max_index] = fea_v
        now_max_index += feature_len
    for uid, v in uid_features.items():
        ot_list = [uid, str(now_max_index), json.dumps(v)]
        print('\t'.join(ot_list)).encode('gb18030')
