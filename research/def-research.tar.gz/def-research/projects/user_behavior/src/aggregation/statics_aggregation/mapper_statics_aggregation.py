#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/11 16:46:26
"""
获取账户的统计特征-mapper阶段
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

def load_uid_end_time(filename):
    """ 获取uid以及对应的时间,时间的格式:${Y}${M}${D}
    """
    uid_risk_info = dict()
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        end_time = data[1]
        uid_risk_info[uid] = end_time
    f.close()
    return uid_risk_info

if __name__ == "__main__":
    uid_risk_info = load_uid_end_time(sys.argv[1])
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        if uid in uid_risk_info:
            print(line.strip('\n'))
