#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/11 16:46:40
"""
获取账户的统计特征-reducer阶段
"""

import os
import sys
reload(sys)
sys.setdefaultencoding("utf8")
_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)
import time
import datetime
import numpy as np
import common_tools.common_func as common

def load_uid_end_time(filename):
    """ 获取uid以及对应的时间,时间的格式:${Y}${M}${D}
    """
    uid_endday_info = dict()
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        end_time = data[1]
        uid_endday_info[uid] = end_time
    f.close()
    return uid_endday_info

def cal_gap_time(data1, data2):
    """计算两个日期的天数差
    """
    data1 = time.strptime(data1, "%Y%m%d")
    data2 = time.strptime(data2, "%Y%m%d")
    data1 = datetime.datetime(data1[0], data1[1], data1[2])
    data2 = datetime.datetime(data2[0], data2[1], data2[2])
    return (data2 - data1).days

def cal_avg(data_list):
    """计算均值
    """
    return np.mean(data_list)

def cal_var(data_list):
    """计算方差
    """
    return np.var(data_list)

def process_single_item_statics(content_item, agg_day_list):
    """计算单个特征的静态特征
    """
    ot_list = []
    for day_seg in agg_day_list:
        ot_list.append(cal_avg(content_item[len(content_item) - day_seg: ]))
        ot_list.append(cal_var(content_item[len(content_item) - day_seg: ]))
    return ot_list

def process_fc_click(data):
    """预处理凤巢点击数据
    """
    return data[2: 146]

def process_feed_click(data):
    """预处理feed点击数据
    """
    return data[2: 146]

def process_opt_data(data):
    """预处理操作数据
    """
    return data[2:]

def process_land_data(data):
    """预处理登陆数据
    """
    return data[2:]

def process_recharge_data(data):
    """预处理充值数据
    """
    return data[2:]

def process_report_data(data):
    """预处理举报数据
    """
    return data[2:]

def process_human_acc_check(data):
    """预处理人审账户审核数据
    """
    return data[2:]

def process_human_idea_check(data):
    """预处理人审物料审核数据
    """
    return data[2:]

def process_human_saudit_check(data):
    """预处理人审二三审审核数据
    """
    return data[2:]

if __name__ == "__main__":
    uid_endday_info = load_uid_end_time(sys.argv[1])
    a = sys.argv[2]
    agg_day_list = [int(item) for item in ((a).split('-'))]
    max_agg_day = max(agg_day_list)
    #预处理的数据类型
    data_type = sys.argv[3]
    data_process_func = {'fc_click': process_fc_click,
            'feed_click': process_feed_click,
            'opt_data': process_opt_data,
            'land_data': process_land_data,
            'recharge_data': process_recharge_data,
            'report_data': process_report_data,
            'human_acc_check': process_human_acc_check,
            'human_idea_check': process_human_idea_check,
            'human_saudit_check': process_human_saudit_check
            }

    keyid = "None"
    key_content = []
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        daydate = data[1]
        data_list = data_process_func[data_type](data)
        if keyid == "None":
            key_content = [[0 for j in range(max_agg_day)] for i in range(len(data_list))]
        if keyid != "None" and keyid != uid:
            ot_list = [keyid]
            ot_content = []
            for content_item in key_content:
                statics_content_list = process_single_item_statics(content_item, agg_day_list)
                ot_content += [str(item) for item in statics_content_list]
            ot_content = common.trans_vec_2_libsvm(ot_content)
            ot_list.append(ot_content)
            print('\t'.join(ot_list)).encode('gb18030')
            key_content = [[0 for j in range(max_agg_day)] for i in range(len(data_list))]
        keyid = uid
        assert len(data_list) == len(key_content)
        endday = uid_endday_info[uid]
        time_gap = cal_gap_time(daydate, endday)
        if time_gap <= 0 or time_gap > max_agg_day:
            continue
        for index in range(len(data_list)):
            key_content[index][max_agg_day - time_gap] += int(float(data_list[index]))
    if keyid != "None":
        ot_list = [keyid]
        ot_content = []
        for content_item in key_content:
            statics_content_list = process_single_item_statics(content_item, agg_day_list)
            ot_content += [str(item) for item in statics_content_list]
        ot_content = common.trans_vec_2_libsvm(ot_content)
        ot_list.append(ot_content)
        print('\t'.join(ot_list)).encode('gb18030')
