#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/10/26 15:04:46
"""
reducer stage - build opt ip graph
"""
import sys
import os
reload(sys)
sys.setdefaultencoding("utf8")
_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)
import common_tools.common_func as common

def check_pair_uids_is_relation(uid1, uid2, uid_info_dict, time_gap):
    """check two uid is relationed
    """
    uid1_dates = list(uid_info_dict[uid1])
    uid2_dates = list(uid_info_dict[uid2])
    uid1_dates.sort()
    uid2_dates.sort()
    indexi = 0
    indexj = 0
    check_is_tag = False
    while indexi < len(uid1_dates) and indexj < len(uid2_dates):
        gap_day = common.cal_gap_time(uid1_dates[indexi], uid2_dates[indexj])
        if abs(gap_day) <= time_gap:
            check_is_tag = True
            break
        elif gap_day > 0:
            indexi += 1
        else:
            indexj += 1
    return check_is_tag


def find_ot_link_relation(uid_info_dict, if_consider_time_gap, time_gap):
    """find graph link relation
    """
    relation_pair_uids = []
    uid_list = uid_info_dict.keys()
    uid_number = len(uid_list)
    for indexi in range(uid_number):
        indexj = indexi + 1
        while indexj < uid_number:
            if if_consider_time_gap == 0:
                relation_pair_uids.append([uid_list[indexi], uid_list[indexj]])
                relation_pair_uids.append([uid_list[indexj], uid_list[indexi]])
            else:
                check_tag = check_pair_uids_is_relation(uid_list[indexi], \
                        uid_list[indexj], uid_info_dict, time_gap)
                if check_tag:
                    relation_pair_uids.append([uid_list[indexi], uid_list[indexj]])
                    relation_pair_uids.append([uid_list[indexj], uid_list[indexi]])
            indexj += 1
    return relation_pair_uids

if __name__ == "__main__":
    if_consider_time_gap = int(sys.argv[1])
    time_gap = 0
    if if_consider_time_gap > 0:
        time_gap = int(sys.argv[2])
    key_ip = "None"
    uid_info_dict = dict()
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        ot_ip = data[0]
        uid = data[1]
        date_list = data[2].split('||')
        if key_ip != ot_ip and key_ip != "None":
            relation_pair_uids = find_ot_link_relation(uid_info_dict, \
                    if_consider_time_gap, time_gap) 
            for pair_uids in relation_pair_uids:
                ot_list = pair_uids + [key_ip]
                print('\t'.join(ot_list)).encode('gb18030')
            uid_info_dict = dict()
        key_ip = ot_ip
        if uid not in uid_info_dict:
            uid_info_dict[uid] = set()
        uid_info_dict[uid] |= set(date_list)
    if key_ip != "None":
        relation_pair_uids = find_ot_link_relation(uid_info_dict, \
                if_consider_time_gap, time_gap)
        for pair_uids in relation_pair_uids:
            ot_list = pair_uids + [key_ip]
            print('\t'.join(ot_list)).encode('gb18030')

