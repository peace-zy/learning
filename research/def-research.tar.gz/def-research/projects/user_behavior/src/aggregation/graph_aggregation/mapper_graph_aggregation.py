#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/09/14 15:33:36
"""
mapper stage - build opt graph
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

if __name__ == "__main__":
    info_dict = dict()
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        opt_uid = data[1]
        count = int(data[2])
        key = uid + '|-|' + opt_uid
        if key not in info_dict:
            info_dict[key] = 0
        info_dict[key] += count
    for k, v in info_dict.items():
        ot_list = [k, str(v)]
        print('\t'.join(ot_list)).encode('gb18030')

