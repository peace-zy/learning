#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/10/22 17:18:00
"""
mapper stage - build opt ip graph
"""
import sys
import os
reload(sys)
sys.setdefaultencoding("utf8")
_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)
import common_tools.common_func as common

def load_stop_uids(filename):
    """load not used uids
    """
    stop_uids = set()
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        stop_uids.add(uid)
    f.close()
    return stop_uids

if __name__ == "__main__":
    stop_uids = load_stop_uids(sys.argv[1])
    if_only_self_opt = int(sys.argv[2])
    if_used_ip_address = int(sys.argv[3])
    #if_consider_time_gap = int(sys.argv[3])
    opt_numbers_th = 0
    ip_2_uid_2_date = dict()
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        opt_uid = data[1]
        opt_ip = data[2]
        ip_address_type = data[3]
        ip_network_id = data[4]
        tdate = data[5]
        opt_numbers = data[6]
        if opt_uid in stop_uids or uid in stop_uids:
            continue
        if if_only_self_opt and uid != opt_uid:
            continue
        link_ip = opt_ip
        if if_used_ip_address:
            link_ip = ip_network_id
        if opt_ip not in ip_2_uid_2_date:
            ip_2_uid_2_date[link_ip] = dict()
        if uid not in ip_2_uid_2_date[link_ip]:
            ip_2_uid_2_date[link_ip][uid] = set()
        ip_2_uid_2_date[link_ip][uid].add(tdate)
    for ot_ip, v in ip_2_uid_2_date.items():
        for ot_uid, ot_date_set in v.items():
            ot_list = [ot_ip, ot_uid, '||'.join(ot_date_set)]
            print('\t'.join(ot_list)).encode('gb18030')
