#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/09/14 15:33:36
"""
reducer stage - build opt graph
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

if __name__ == "__main__":
    info_dict = dict()
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        keyid = data[0]
        count = int(data[1])
        if keyid not in info_dict:
            info_dict[keyid] = 0
        info_dict[keyid] += count
    for k, v in info_dict.items():
        ks = k.split('|-|')
        uid, optuid = ks[0], ks[1]
        ot_list = [uid, optuid, str(v)]
        print('\t'.join(ot_list)).encode('gb18030')

