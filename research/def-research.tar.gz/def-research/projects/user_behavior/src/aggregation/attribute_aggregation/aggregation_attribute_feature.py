#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/19 19:57:53
"""
获取指定账户的静态特征
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")
import json

def decode_cols(cols_index):
    """将指定格式字符串解析成列数的列表
    """
    col_index_list = []
    for index_item in cols_index.split('-'):
        if index_item.find('_') >= 0:
            start_index, end_index = index_item.split('_')
            for index_num in range(int(start_index), int(end_index + 1)):
                col_index_list.append(int(index_num))
        else:
            col_index_list.append(int(index_item))
    return col_index_list

 
def load_uid_list(filename):
    """读取账户ID
    """
    uid_list = []
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('utf8').split('\t')
        uid = data[0]
        uid_list.append(uid)
    f.close()
    return uid_list, set(uid_list)


def load_attribute_feature_dict(filename):
    """读取特征类型
    """
    feature_dict = dict()
    feature_list = []
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('gb18030').split('\t')
        cnt_type = data[0]
        cnt_index = data[1]
        feature_dict[cnt_type] = cnt_index
        feature_list.append(cnt_type)
    f.close()
    return feature_dict, feature_list

if __name__ == "__main__":
    #账户ID信息文件
    uid_file = sys.argv[1]
    uid_list, uid_set = load_uid_list(uid_file)
    #数值型值的列 格式: 3-4-7_9, 指抽取3\4\7\8\9列
    value_cols = sys.argv[2]
    #类型型值的列 格式: 3-4-7_9, 指抽取3\4\7\8\9列
    type_cols = sys.argv[3]
    #数据类型文件 格式: 文件1!!文件2!!文件3
    col_type = sys.argv[4]
    #uid的index
    uid_index = int(sys.argv[5])
    #输入文件数据编码
    file_encode = sys.argv[6]
    #非已知类型用other替代
    OTHER_TYPE = 'other'
    value_col_list = []
    col_type_files = []
    if value_cols != "":
        value_col_list = decode_cols(value_cols)
    type_col_list = []
    if type_cols != "":
        type_col_list = decode_cols(type_cols)
    if col_type != "":
        col_type_files = col_type.split('!!')
    assert len(type_col_list) == len(col_type_files)
    #特征的长度
    feature_now_num = 0
    value_colindex_2_featureindex = dict()
    type_colindex_2_feature_startindex = dict()
    type_colindex_2_feature_dict = dict()
    for index in range(len(value_col_list)):
        value_colindex_2_featureindex[value_col_list[index]] = feature_now_num
        feature_now_num += 1
    for index in range(len(type_col_list)):
        feature_dict, feature_list = load_attribute_feature_dict(col_type_files[index])
        type_colindex_2_feature_dict[type_col_list[index]] = feature_dict
        type_colindex_2_feature_startindex[type_col_list[index]] = feature_now_num
        feature_now_num += len(feature_list)
    for line in sys.stdin:
        data = line.strip('\n').decode(file_encode, 'ignore').split('\t')
        uid = data[uid_index]
        if uid not in uid_set:
            continue
        cnt_dict = dict()
        for value_col in value_col_list:
            value = data[value_col]
            cnt_dict[value_colindex_2_featureindex[value_col]] = value
        for type_col in type_col_list:
            value = data[type_col]
            feature_startindex = type_colindex_2_feature_startindex[type_col]
            feature_dict = type_colindex_2_feature_dict[type_col]
            if value not in feature_dict:
                value = OTHER_TYPE
            now_feature_index = int(feature_dict[value])
            feature_index = feature_startindex + now_feature_index
            cnt_dict[feature_index] = 1
        ot_list = [uid, json.dumps([feature_now_num, cnt_dict])]
        print('\t'.join(ot_list)).encode('gb18030')
