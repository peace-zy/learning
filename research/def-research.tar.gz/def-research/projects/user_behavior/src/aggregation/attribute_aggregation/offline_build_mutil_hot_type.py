#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/19 19:28:14
"""
离线获取指定列的类型情况
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

def decode_cols(cols_index):
    """将指定格式字符串解析成列数的列表
    """
    col_index_list = []
    for index_item in cols_index.split('-'):
        if index_item.find('_') >= 0:
            start_index, end_index = index_item.split('_')
            for index_num in range(int(start_index), int(end_index + 1)):
                col_index_list.append(int(index_num))
        else:
            col_index_list.append(int(index_item))
    return col_index_list

if __name__ == "__main__":
    #需要离线获取各类型数据类型情况的列
    #格式: 3-4-7_9, 指抽取3\4\7\8\9列
    cols_index = sys.argv[1]
    #写出各数据类型情况的文件
    #格式: 文件1!!文件2!!文件3
    ofiles = (sys.argv[2]).split('!!')
    file_encode = sys.argv[3]
    col_index_list = decode_cols(cols_index)
    #保证需要获取类情况的列数和输出的文件数一致
    assert len(col_index_list) == len(ofiles)

    col_type_sets = [set() for i in range(len(col_index_list))]
    for line in sys.stdin:
        data = line.strip('\n').decode(file_encode).split('\t')
        for i in range(len(col_index_list)):
            col_type_sets[i].add(data[col_index_list[i]])
    for i in range(len(col_index_list)):
        of = open(ofiles[i], 'w')
        w_index = 0
        for col_type in col_type_sets[i]:
            ot_line_cnt = [col_type, str(w_index)]
            of.write('\t'.join(ot_line_cnt) + '\n')
            w_index += 1
        ot_line_cnt = ['other', str(w_index)]
        of.write(('\t'.join(ot_line_cnt)).encode('gb18030') + '\n')
        of.close()
