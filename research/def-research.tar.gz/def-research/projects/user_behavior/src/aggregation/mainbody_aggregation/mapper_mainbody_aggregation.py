#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/11 16:46:26
"""
获取账户主体聚合特征-mapper阶段
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

def load_uid_endtime(filename):
    """获取uid以及对应的时间,时间的格式:${Y}${M}${D}
    """
    uid_list = []
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        end_time = data[1]
        uid_list.append(uid)
    f.close()
    return uid_list

def load_custid_2_uids(filename):
    """获取需要进行计算的uid, 以及对应的uid和custid的对应关系
    """
    uids_set = set()
    uid_2_custid = dict()
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('gb18030').split('\t')
        custid = data[0]
        uids = data[1:]
        for uid in uids:
            uids_set.add(uid)
            uid_2_custid[uid] = custid
    f.close()
    return uids_set, uid_2_custid

if __name__ == "__main__":
    uid_list = load_uid_endtime(sys.argv[1])
    uids_set, uid_2_custid = load_custid_2_uids(sys.argv[2])
    for uid in uid_list:
        uids_set.add(uid)
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        #为查询到对应custid的uid, 用uid替代custid
        custid = uid
        if uid in uid_2_custid:
            custid = uid_2_custid[uid]
        if uid in uids_set:
            print('\t'.join([custid] + data)).encode('gb18030')
