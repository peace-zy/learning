#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/13 11:28:40
"""
获取uid与custid对应关系
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

def load_uid_need_cal(filename):
    """加载需要数据的uid
    """
    uid_set = set()
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('utf8').split('\t')
        uid = data[0]
        uid_set.add(uid)
    f.close()
    return uid_set

if __name__ == "__main__":
    uid_set = load_uid_need_cal(sys.argv[1])
    #输出文件1: uid到custid的映射关系, uid在输入的uid范围内的 1对1
    of_uid_2_custid_file = sys.argv[2]
    #输出文件2: custid到uid的映射关系, custid包含输入的uid 1对多
    of_custid_2_uid_file = sys.argv[3]
    uid_2_custid_dict = dict()
    custid_2_uid_dict = dict()
    for line in sys.stdin:
        data = line.strip('\n').decode('utf8').split('\t')
        uid = data[0]
        custid = data[2]
        if custid == "-1":
            continue
        if uid in uid_set:
            uid_2_custid_dict[uid] = custid
        if custid not in custid_2_uid_dict:
            custid_2_uid_dict[custid] = set()
        custid_2_uid_dict[custid].add(uid)
    of1 = open(of_uid_2_custid_file, 'w')
    of2 = open(of_custid_2_uid_file, 'w')
    custid_set = set()
    for uid, custid in uid_2_custid_dict.items():
        ot_list = [uid, custid]
        custid_set.add(custid)
        of1.write(('\t'.join(ot_list)).encode('gb18030') + '\n')
    for custid in custid_set:
        uids = custid_2_uid_dict[custid]
        ot_list = [custid] + list(uids)
        of2.write(('\t'.join(ot_list)).encode('gb18030') + '\n')
    of1.close()
    of2.close()
