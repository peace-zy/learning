#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/11 16:46:40
"""
main_body_aggregation
"""

import os
import sys
reload(sys)
sys.setdefaultencoding("utf8")
_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)
import time
import datetime
import numpy as np
import common_tools.common_func as common

def load_uid_end_time(filename):
    """
    """
    uid_endday_info = dict()
    uid_set = set()
    endday_set = set()
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        end_time = data[1]
        uid_endday_info[uid] = end_time
        uid_set.add(uid)
        endday_set.add(end_time)
    f.close()
    return uid_endday_info, uid_set, endday_set

def load_uid_2_custid(filename):
    """
    """
    need_ot_custid_2_uid = dict()
    uid_2_custid = dict()
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        custid = data[1]
        uid_2_custid[uid] = custid
        if custid not in need_ot_custid_2_uid:
            need_ot_custid_2_uid[custid] = set()
        need_ot_custid_2_uid[custid].add(uid)
    f.close()
    return need_ot_custid_2_uid, uid_2_custid

def cal_gap_time(time1, time2):
    """
    """
    data1 = time.strptime(time1, "%Y%m%d")
    data2 = time.strptime(time2, "%Y%m%d")
    date1 = datetime.datetime(data1[0], data1[1], data1[2])
    date2 = datetime.datetime(data2[0], data2[1], data2[2])
    return (date2 - date1).days

def cal_max_min_endday(endday_set):
    """
    """
    max_day = "None"
    min_day = "None"
    index = 0
    for endday in endday_set:
        index += 1
        if index == 1:
            max_day = endday
            min_day = endday
            continue
        maxday_gap = cal_gap_time(max_day, endday)
        minday_gap = cal_gap_time(min_day, endday)
        if maxday_gap > 0:
            max_day = endday
        if minday_gap < 0:
            min_day = endday
    return min_day, max_day

def cal_sum(data_list):
    """
    """
    return sum(data_list)

def process_time_gap_result(content, start_list, end_list):
    """处理指定日期区间内的数据
    """
    ot_list = []
    assert len(start_list) == len(end_list)
    for content_item in content:
        for index in range(len(start_list)):
            start = start_list[index]
            end = end_list[index]
            ot_list.append(str(cal_sum(content_item[start: end + 1])))
    return ot_list

def process_fc_click(data):
    """
    """
    return data[2 + 1: 146 + 1]

def process_punish_data(data):
    """
    """
    return data[3:]

def process_start_data(data):
    """
    """
    return data[3: 4]

if __name__ == "__main__":
    uid_endday_info, uid_set, endday_set = load_uid_end_time(sys.argv[1])
    need_ot_custid_2_uid, uid_2_custid = load_uid_2_custid(sys.argv[2])
    for uid in uid_set:
        if uid not in uid_2_custid:
            need_ot_custid_2_uid[uid] = set([uid])
    agg_day_list = [int(item) for item in ((sys.argv[3]).split('-'))]
    max_agg_day = max(agg_day_list)
    data_type = sys.argv[4]
    data_process_funcs = {'fc_click': process_fc_click,
            'punish_data': process_punish_data,
            'start_data': process_start_data
            }
    process_func = data_process_funcs[data_type]
    min_day, max_day = cal_max_min_endday(endday_set)
    max_agg_day += cal_gap_time(min_day, max_day)
    max_endday = max_day

    keyid = "None"
    key_content = []
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        custid = data[0]
        #uid = data[1]
        daydate = data[2]
        data_list = process_func(data)
        if keyid == "None":
            key_content = [[0 for j in range(max_agg_day)] for i in range(len(data_list))]
        if keyid != "None" and keyid != custid:
            need_ot_ids = need_ot_custid_2_uid[keyid]
            for ot_uid in need_ot_ids:
                uid_endday = uid_endday_info[ot_uid]
                ot_gap_day = cal_gap_time(uid_endday, max_endday)
                start_list = []
                end_list = []
                for agg_day in agg_day_list:
                    start_list.append(max_agg_day - ot_gap_day - agg_day + 1)
                    end_list.append(max_agg_day - ot_gap_day)
                ot_content_list = process_time_gap_result(key_content, start_list, end_list)
                ot_content = common.trans_vec_2_libsvm(ot_content_list)
                ot_list = [ot_uid, ot_content]
                print('\t'.join(ot_list)).encode('gb18030')
            key_content = [[0 for j in range(max_agg_day)] for i in range(len(data_list))]
        keyid = custid
        gapday = cal_gap_time(daydate, max_endday)
        if gapday <= 0 or gapday > max_agg_day:
            continue
        assert len(data_list) == len(key_content)
        for index in range(len(data_list)):
            key_content[index][max_agg_day - gapday] += int(float(data_list[index]))
    if keyid != "None":
        need_ot_ids = need_ot_custid_2_uid[keyid]
        for ot_uid in need_ot_ids:
            uid_endday = uid_endday_info[ot_uid]
            ot_gap_day = cal_gap_time(uid_endday, max_endday)
            start_list = []
            end_list = []
            for agg_day in agg_day_list:
                start_list.append(max_agg_day - ot_gap_day - agg_day + 1)
                end_list.append(max_agg_day - ot_gap_day)
            ot_content_list = process_time_gap_result(key_content, start_list, end_list)
            ot_content = common.trans_vec_2_libsvm(ot_content_list)
            ot_list = [ot_uid, ot_content]
            print('\t'.join(ot_list)).encode('gb18030')
