#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/12 20:23:50
"""
获取账户序列特征-mapper阶段
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

def load_uid_endday_info(filename):
    """获取uid数据
    """
    uid_endday = dict()
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        endday = data[1]
        uid_endday[uid] = endday
    return uid_endday

if __name__ == "__main__":
    uid_endday = load_uid_endday_info(sys.argv[1])
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        if uid not in uid_endday:
            continue
        print(line.strip('\n'))
