#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/12 20:23:59
"""
获取账户序列特征-reducer阶段
"""
import sys
import os
reload(sys)
sys.setdefaultencoding("utf8")
_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)
import time
import datetime
import common_tools.common_func as common

def load_uid_endday_info(filename):
    """获取uid以及结束时间的映射关系
    """
    uid_endday = dict()
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        endday = data[1]
        uid_endday[uid] = endday
    return uid_endday


def cal_gap_time(time1, time2):
    """计算两个日期之间的天数差
    """
    data1 = time.strptime(time1, "%Y%m%d")
    data2 = time.strptime(time2, "%Y%m%d")
    date1 = datetime.datetime(data1[0], data1[1], data1[2])
    date2 = datetime.datetime(data2[0], data2[1], data2[2])
    return (date2 - date1).days


def process_fc_click(data):
    """预处理凤巢点击数据
    """
    return data[2: 146]


def process_feed_click(data):
    """预处理feed点击数据
    """
    return data[2: 146]


def process_opt(data):
    """预处理操作数据
    """
    return data[2:]


def process_land(data):
    """预处理登陆数据
    """
    return data[2:]


def process_recharge(data):
    """预处理充值数据
    """
    return data[2:]

if __name__ == "__main__":
    #获取序列特征采用直接拼接的方式
    #输出特征格式: 1: uid, 2: 序列长度, k x N: k序列长度, N特征数量
    uid_endday = load_uid_endday_info(sys.argv[1])
    max_day = int(sys.argv[2])
    data_type = sys.argv[3]

    func_dict = {"fc_click": process_fc_click,
            "feed_click": process_feed_click,
            "opt": process_opt,
            "land": process_land,
            "recharge": process_recharge}
    process_func = func_dict[data_type]
    keyid = "None"
    key_content = []
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        endday = uid_endday[uid]
        data_date = data[1]
        content_list = process_func(data)
        if keyid == "None":
            key_content = [[0 for j in range(max_day)] for i in range(len(content_list))]
        if keyid != uid and keyid != "None":
            ot_list = [keyid, str(max_day)]
            ot_content = []
            for content_item in key_content:
                ot_content += [str(day_item) for day_item in content_item]
            ot_content = common.trans_vec_2_libsvm(ot_content)
            ot_list.append(ot_content)
            print('\t'.join(ot_list)).encode('gb18030')
            key_content = [[0 for j in range(max_day)] for i in range(len(content_list))]
        keyid = uid
        assert len(content_list) == len(key_content)
        day_gap = cal_gap_time(data_date, endday)
        if day_gap <= 0 or day_gap > max_day:
            continue
        for index in range(len(content_list)):
            key_content[index][max_day - day_gap] += int(float(content_list[index]))
    if keyid != "None":
        ot_list = [keyid, str(max_day)]
        ot_content = []
        for content_item in key_content:
            ot_content += [str(day_item) for day_item in content_item]
        ot_content = common.trans_vec_2_libsvm(ot_content)
        ot_list.append(ot_content)
        print('\t'.join(ot_list)).encode('gb18030')

