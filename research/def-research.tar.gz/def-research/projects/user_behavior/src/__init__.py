#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/23 10:41:33
"""
__init__文件
"""

import sys
reload(sys)
sys.setdefaultencoding("utf8")

if __name__ == "__main__":
    pass


