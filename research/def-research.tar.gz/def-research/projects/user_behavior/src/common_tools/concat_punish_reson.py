#!/usr/bin/env python
# -*- coding:gbk -*-
#Author:   baidu.com
#Date  :   21/10/27 16:19:39
"""
concat reason
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")

def load_id_2_reason(filename):
    """load id 2 risk_reason
    """
    id_2_reason = dict()
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('gb18030').split('\t')
        rid = data[0]
        reason = data[1]
        id_2_reason[rid] = reason
    f.close()
    return id_2_reason

if __name__ == "__main__":
    id_2_reason = load_id_2_reason(sys.argv[1])
    linenumber = 0
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        linenumber += 1
        if linenumber == 1:
            continue
        uid = data[0]
        push_time = data[1]
        audit_time = data[3]
        rids = data[4].split(',')
        first_source = data[5]
        if len(rids) == 1 and rids[0] == '0':
            continue
        reasons = []
        for rid in rids:
            reasons.append(id_2_reason[rid])
        ot_list = [uid, push_time, audit_time, '||'.join(rids), '||'.join(reasons), first_source]
        print('\t'.join(ot_list)).encode('gb18030')

