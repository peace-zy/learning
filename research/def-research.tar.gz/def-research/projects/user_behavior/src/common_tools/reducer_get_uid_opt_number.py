#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/10/20 16:54:56
"""mapper get uids number
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

if __name__ == "__main__":
    uid_opt_number = dict()
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        opt_uid = data[0]
        uids = data[1].split('||')
        if opt_uid not in uid_opt_number:
            uid_opt_number[opt_uid] = set()
        uid_opt_number[opt_uid] |= set(uids)
    for k, v in uid_opt_number.items():
        ot_list = [k, str(len(v)), '||'.join(v)]
        print('\t'.join(ot_list)).encode('gb18030')
