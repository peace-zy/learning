#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/19 15:36:07
"""
通用函数工具
"""

import sys
reload(sys)
sys.setdefaultencoding("utf8")
import json
import time
import datetime

def trans_vec_2_libsvm(line_data):
    """将向量表示成libsvm的格式
    """
    data_len = len(line_data)
    ot_data = [data_len, dict()]
    for index in range(len(line_data)):
        tmp_num = float(line_data[index])
        if abs(tmp_num) < 0.0001:
            continue
        else:
            ot_data[1][index] = tmp_num
    return json.dumps(ot_data)


def cal_gap_time(data1, data2):
    """计算两个日期的天数差
    """
    data1 = time.strptime(data1, "%Y%m%d")
    data2 = time.strptime(data2, "%Y%m%d")
    data1 = datetime.datetime(data1[0], data1[1], data1[2])
    data2 = datetime.datetime(data2[0], data2[1], data2[2])
    return (data2 - data1).days

if __name__ == "__main__":
    test_data = [0.01, 2, 3, 0, 0.00001]
    test_result = trans_vec_2_libsvm(test_data)
    print(test_result)
