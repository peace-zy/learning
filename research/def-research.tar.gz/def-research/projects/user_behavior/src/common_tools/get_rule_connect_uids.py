#!/usr/bin/env python
# -*- coding:gbk -*-
#Author:   zhukaiwen@baidu.com
#Date  :   21/10/27 16:46:35
"""
find connected risk uids
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")

def load_uids(filename):
    """get seed uids
    """
    black_uids = set()
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('gb18030').split('\t')
        buid = data[0]
        black_uids.add(buid)
    f.close()
    return black_uids

if __name__ == "__main__":
    black_uids = load_uids(sys.argv[1])
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid1 = data[0]
        uid2 = data[1]
        ip = data[2]
        if uid1 in black_uids:
            ot_list = [uid2, uid1, uid2, ip]
            print('\t'.join(ot_list)).encode('gb18030')

