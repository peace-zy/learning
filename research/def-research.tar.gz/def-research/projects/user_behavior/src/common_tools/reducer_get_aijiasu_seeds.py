#!/usr/bin/env python
# -*- coding:gbk -*-
#Author:   baidu.com
#Date  :   21/11/12 17:22:16
"""
get aijiasu crawl risk uids reducer
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")

if __name__ == "__main__":
    uid_risk = dict()
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        is_sp_crawl = data[1]
        is_other_crawl = data[2]
        if uid not in uid_risk:
            uid_risk[uid] = ['0', '0']
        if is_sp_crawl != '0':
            uid_risk[uid][0] = '1'
        if is_other_crawl != '0':
            uid_risk[uid][1] = '1'
    for tuid, risk_info in uid_risk.items():
        is_sp = risk_info[0]
        is_other = risk_info[1]
        ot_list = [tuid] + risk_info
        print('\t'.join(ot_list)).encode('gb18030')
