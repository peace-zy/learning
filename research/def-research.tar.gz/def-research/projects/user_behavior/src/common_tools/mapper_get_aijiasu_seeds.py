#!/usr/bin/env python
# -*- coding:gbk -*-
#Author:   baidu.com
#Date  :   21/11/12 16:20:34
"""
get aijiasu crawl risk uids mapper
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")

if __name__ == "__main__":
    seed_crawl_type = set(['38_'])
    uid_risk = dict()
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030', 'ignore').split('\t')
        uid = data[1]
        url = data[2]
        risk = data[4]
        crawl_type = data[10]
        if risk.find('softtext') < 0:
            continue
        seed_tag = False
        for seed_t in seed_crawl_type:
            if crawl_type.find(seed_t) >= 0:
                seed_tag = True
                break
        if uid not in uid_risk:
            uid_risk[uid] = ['0', '0']
        if seed_tag:
            uid_risk[uid][0] = '1'
        else:
            uid_risk[uid][1] = '1'
    for tuid, risk_info in uid_risk.items():
        ot_list = [tuid] + risk_info
        print('\t'.join(ot_list)).encode('gb18030')

