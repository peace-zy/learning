#!/usr/bin/env python
# -*- coding:gbk -*-
#Author:   zhukaiwen@baidu.com
#Date  :   21/10/28 15:08:39
"""
get sample urls
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import random
import datetime

def load_risk_uid(filename):
    """get risk uids
    """
    uid_info_dict = dict()
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        uid_info_dict[uid] = ["None", "None", "None", "None"]
    f.close()
    return uid_info_dict

if __name__ == "__main__":
    uid_info_dict = load_risk_uid(sys.argv[1])
    startdate = sys.argv[2]
    based_sample_url_data_path = sys.argv[3]
    #"/home/disk1/gancaizhao/ct_workspace/get_db_data/uid_sample_url_data/"
    find_data_len = int(sys.argv[4])
    dates = []
    startdate_format = datetime.datetime.strptime(startdate, "%Y%m%d")
    for i in range(find_data_len):
        dates.append((startdate_format - datetime.timedelta(days = i)).strftime("%Y%m%d"))
    for index in range(len(dates)):
        if index == 0:
            continue
        tmp_file = based_sample_url_data_path + dates[index]
        f = open(tmp_file)
        for line in f:
            data = line.strip('\n').decode('gb18030', 'ignore').split('\t')
            uid = data[0]
            if uid not in uid_info_dict:
                continue
            urls = data[1].split('|-|')
            random.shuffle(urls)
            for url in urls:
                if url.find('wejianzhan.com') >= 0 or url.find('baidu.com') >= 0:
                    if uid_info_dict[uid][0] == "None":
                        uid_info_dict[uid][0] = url
                        uid_info_dict[uid][1] = dates[index]
                else:
                    if uid_info_dict[uid][2] == "None":
                        uid_info_dict[uid][2] = url
                        uid_info_dict[uid][3] = dates[index]
        f.close()
    for uid, uid_info in uid_info_dict.items():
        ot_list = [uid] + uid_info
        print('\t'.join(ot_list)).encode('gb18030')
