#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/04 10:30:51
"""
聚合feed点击数据-账户天粒度, mapper阶段
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

def load_proid_map(filename):
    """ 读取省份id和名称的映射关系
    """
    prov_map = dict()
    prov_list = []
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('gb18030').split('\t')
        pid = data[0]
        pname = data[1]
        prov_map[pid] = pname
        prov_list.append(pid)
    f.close()
    prov_list.append('other')
    return prov_map, prov_list

if __name__ == "__main__":
    # 广告点击的省份映射表
    prov_map, prov_list = load_proid_map(sys.argv[1])
    cal_date = sys.argv[2]
    uid_info_dict = dict()
    hour_list = ['0' + str(inum) if len(str(inum)) == 1 else str(inum) for inum in range(24)]
    # 定义夜间的时段
    night_hour = set(['20', '22', '23', '00', '01', '02', '03', '04', '05', '06'])
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030', 'ignore').split('\t')
        if len(data) < 36:
            continue
        uid = data[14]
        try:
            clk = int(data[1])
            price = float(data[2]) * clk
        except:
            continue
        if clk == 0:
            continue
        pid = data[19]
        if pid not in prov_map:
            pid = 'other'
        cid = data[20]
        #pname = prov_map[pid]
        show_time = data[35]
        if len(show_time.split(' ')) != 2:
            continue
        day_time, hour_time = show_time.split(' ')
        hour, min, sec = hour_time.split(':')
        if uid not in uid_info_dict:
            uid_info_dict[uid] = dict()
        # 获得每个小时的统计量 小时总消费 小时总点击次数 [小时各消费地域点击次数 小时各消费地域消费额]
        if 'each_hour' not in uid_info_dict[uid]:
            uid_info_dict[uid]['each_hour'] = dict()
            for hour_item in hour_list:
                uid_info_dict[uid]['each_hour'][hour_item] = [0, 0, dict()]
                for prov_item in prov_list:
                    uid_info_dict[uid]['each_hour'][hour_item][2][prov_item] = [0, 0]
        uid_info_dict[uid]['each_hour'][hour][0] += price
        uid_info_dict[uid]['each_hour'][hour][1] += clk
        uid_info_dict[uid]['each_hour'][hour][2][pid][0] += price
        uid_info_dict[uid]['each_hour'][hour][2][pid][1] += clk
        
        # 获得整天的统计量 全天总消费 全天总点击次数 夜间消费 夜间点击次数 [各地域的 消费总额、消费点击次数、夜间消费总额、夜间点击次数]
        if 'all_day_sum' not in uid_info_dict[uid]:
            uid_info_dict[uid]['all_day_sum'] = [0, 0, 0, 0, dict()]
            for prov_item in prov_list:
                uid_info_dict[uid]['all_day_sum'][4][prov_item] = [0, 0, 0, 0]
        uid_info_dict[uid]['all_day_sum'][0] += price
        uid_info_dict[uid]['all_day_sum'][1] += clk
        if hour in night_hour:
            uid_info_dict[uid]['all_day_sum'][2] += price
            uid_info_dict[uid]['all_day_sum'][3] += clk

        uid_info_dict[uid]['all_day_sum'][4][pid][0] += price
        uid_info_dict[uid]['all_day_sum'][4][pid][1] += clk
        if hour in night_hour:
            uid_info_dict[uid]['all_day_sum'][4][pid][2] += price
            uid_info_dict[uid]['all_day_sum'][4][pid][3] += clk
    # 输出结果到reducer中
    for uid, uid_info in uid_info_dict.items():
        # 1:uid, 2:date
        ot_list = [uid, cal_date]
        # 3~6:全天总消费、全天点击次数、夜间总消费、夜间点击次数
        ot_list.append(str(uid_info['all_day_sum'][0]))
        ot_list.append(str(uid_info['all_day_sum'][1]))
        ot_list.append(str(uid_info['all_day_sum'][2]))
        ot_list.append(str(uid_info['all_day_sum'][3]))
        # 7~146 35x4=140:各地域的 消费总额、点击次数、夜间消费总额、夜间点击次数
        for pid in prov_list:
            pid_info = uid_info['all_day_sum'][4][pid]
            ot_list.append(str(pid_info[0]))
            ot_list.append(str(pid_info[1]))
            ot_list.append(str(pid_info[2]))
            ot_list.append(str(pid_info[3]))
        # 147~194 24x2=48:每小时的消费总额 点击次数 
        for hour in hour_list:
            ot_list.append(str(uid_info['each_hour'][hour][0]))
            ot_list.append(str(uid_info['each_hour'][hour][1]))
        # 195~1874 24x35x2=1680:每小时各地域的消费总额、点击次数
        for hour in hour_list:
            for pid in prov_list:
                ot_list.append(str(uid_info['each_hour'][hour][2][pid][0]))
                ot_list.append(str(uid_info['each_hour'][hour][2][pid][1]))
        # 输出结果(1874列)
        print('\t'.join(ot_list)).encode('gb18030')

        


