#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/11 11:11:02
"""
离线获取操作动作信息-mapper阶段
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

if __name__ == "__main__":
    opt_type_dict = dict()
    for line in sys.stdin:
        data = line.strip('\n').decode('utf8').split('\x01')
        optcontent = data[5]
        opttype = data[6]
        #optcontent拼接opttype作为操作标识
        opt = optcontent + '-' + opttype
        if opt not in opt_type_dict:
            opt_type_dict[opt] = 0
        opt_type_dict[opt] += 1
    for optid, v in opt_type_dict.items():
        print('\t'.join([optid, str(v)])).encode('gb18030')


