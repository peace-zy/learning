#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/11 10:51:13
"""
聚合操作数据-账户天粒度, mapper阶段
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")
import time

def load_opt_type_info(filename):
    """读取操作类型
    """
    opt_type_dict = dict()
    opt_type_list = []
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('utf8').split('\t')
        opt_type = data[0]
        optid = data[1]
        opt_type_dict[opt_type] = optid
        opt_type_list.append(optid)
    f.close()
    return opt_type_dict, opt_type_list

if __name__ == "__main__":
    opt_type_dict, opt_type_list = load_opt_type_info(sys.argv[1])
    need_date = sys.argv[2]
    uid_opt_info = dict()
    hour_list = ['0' + str(inum) if len(str(inum)) == 1 else str(inum) for inum in range(24)]
    # 定义夜间的时段
    night_hour = set(['20', '22', '23', '00', '01', '02', '03', '04', '05', '06'])
    # 位置操作类型, 设为other
    OTHER_OPTID = 'other'
    for line in sys.stdin:
        data = line.strip('\n').decode('utf8').split('\x01')
        uid = data[0]
        opt_uid = data[1]
        #判断是否是自操作
        is_self = False
        if uid == opt_uid:
            is_self = True
        timeArray = time.localtime(int(data[3])/1000)
        opt_time = time.strftime("%Y:%m:%d:%H:%M:%S", timeArray)
        hour = opt_time.split(':')[3]
        is_night = False
        if hour in night_hour:
            is_night = True
        opt = data[5] + '-' + data[6]
        optid = OTHER_OPTID
        if opt in opt_type_dict:
            optid = opt_type_dict[opt]
        if uid not in uid_opt_info:
            uid_opt_info[uid] = [0, 0, 0, 0, dict()]
            for opt_type in opt_type_list:
                uid_opt_info[uid][4][opt_type] = [0, 0, 0, 0]
            uid_opt_info[uid][4][OTHER_OPTID] = [0, 0, 0, 0]
        if is_self:
            uid_opt_info[uid][0] += 1
            uid_opt_info[uid][4][optid][0] += 1
            if is_night:
                uid_opt_info[uid][2] += 1
                uid_opt_info[uid][4][optid][2] += 1
        else:
            uid_opt_info[uid][1] += 1
            uid_opt_info[uid][4][optid][1] += 1
            if is_night:
                uid_opt_info[uid][3] += 1
                uid_opt_info[uid][4][optid][3] += 1
    for uid, v in uid_opt_info.items():
        #输出结果: 1：uid 2：自操作次数 3：被操作次数 4：夜间自操作次数 5：夜间被操作次数
        ot_list = [uid, need_date, str(v[0]), str(v[1]), str(v[2]), str(v[3])]
        # (N + 1) x 4, N:操作类型, 1:其他操作类型, 4:自操作次数\被操作次数\夜间自操作次数\夜间被操作次数
        for opt_type in opt_type_list:
            opt_info = v[4][opt_type]
            ot_list.append(str(opt_info[0]))
            ot_list.append(str(opt_info[1]))
            ot_list.append(str(opt_info[2]))
            ot_list.append(str(opt_info[3]))
        opt_info = v[4][OTHER_OPTID]
        ot_list.append(str(opt_info[0]))
        ot_list.append(str(opt_info[1]))
        ot_list.append(str(opt_info[2]))
        ot_list.append(str(opt_info[3]))
        print('\t'.join(ot_list)).encode('gb18030')
