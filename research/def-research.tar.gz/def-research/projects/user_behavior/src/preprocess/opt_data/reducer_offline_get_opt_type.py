#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/11 11:31:02
"""
离线获取操作动作信息-reducer阶段
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

if __name__ == "__main__":
    opt_dict = dict()
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        optid = data[0]
        optnum = int(data[1])
        if optid not in opt_dict:
            opt_dict[optid] = 0
        opt_dict[optid] += optnum
    for opt, v in opt_dict.items():
        print('\t'.join([opt, str(v)])).encode('gb18030')


