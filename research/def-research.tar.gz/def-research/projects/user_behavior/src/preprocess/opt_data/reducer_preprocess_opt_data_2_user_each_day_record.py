#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/11 14:50:01
"""
聚合操作数据-账户天粒度, mapper阶段
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

if __name__ == "__main__":
    keyid = "None"
    keydate = "None"
    head_num = 2
    content_list = []
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        pdate = data[1]
        line_content = data[head_num: ]
        if keyid == "None":
            keyid = uid
            keydate = pdate
            content_list = [0 for i in range(len(data) - head_num)]
        if keyid != "None" and keyid != uid:
            ot_list = [keyid, keydate]
            for c_item in content_list:
                ot_list.append(str(c_item))
            print('\t'.join(ot_list)).encode('gb18030')
            content_list = [0 for i in range(len(data) - head_num)]
        keyid = uid
        keydate = pdate
        assert len(line_content) == len(content_list)
        for index in range(len(content_list)):
            content_list[index] += int(line_content[index])
    if keyid != "None":
        ot_list = [keyid, keydate]
        for c_item in content_list:
            ot_list.append(str(c_item))
        print('\t'.join(ot_list)).encode('gb18030')

