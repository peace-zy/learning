#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/10 11:12:54
"""
聚合充值数据-账户天粒度, mapper阶段
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

if __name__ == "__main__":
    need_date = sys.argv[1]
    uid_recharge_info = dict()
    for line in sys.stdin:
        data = line.strip('\n').decode('utf8').split('\x01')
        uid = data[2]
        fund = int(data[6])
        time = (data[13].split(' ')[0]).replace('-', '')
        if time == need_date:
            if uid not in uid_recharge_info:
                uid_recharge_info[uid] = 0
            uid_recharge_info[uid] += fund
    for uid, uinfo in uid_recharge_info.items():
        ot_list = [uid, need_date, str(uinfo)]
        print('\t'.join(ot_list)).encode('gb18030')
