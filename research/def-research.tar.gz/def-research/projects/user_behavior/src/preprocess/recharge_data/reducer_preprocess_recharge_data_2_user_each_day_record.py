#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/10 11:23:23
"""
聚合充值数据-账户天粒度, reducer阶段
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

if __name__ == "__main__":
    keyid = "None"
    key_date = "None"
    fund_sum = 0
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        time_date = data[1]
        fund = int(data[2])
        if keyid != "None" and uid != keyid:
            ot_list = [keyid, key_date, str(fund_sum)]
            print('\t'.join(ot_list)).encode('gb18030')
            fund_sum = 0
        keyid = uid
        key_date = time_date
        fund_sum += fund
    if keyid != "None":
        ot_list = [keyid, key_date, str(fund_sum)]
        print('\t'.join(ot_list)).encode('gb18030')
