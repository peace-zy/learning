#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/09 23:34:12
"""
本地处理基础的账户数据中的开户时间、生效时间、失效时间
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

if __name__ == "__main__":
    #获取每天存在开户、生效、失效行为的账户
    need_date = sys.argv[1]
    uid_based_info = dict()
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        regdate = (data[7].split(' ')[0]).replace('-', '')
        effdate = (data[8].split(' ')[0]).replace('-', '')
        expdate = (data[10].split(' ')[0]).replace('-', '')
        if regdate == need_date or effdate == need_date or expdate == need_date:
            if uid not in uid_based_info:
                uid_based_info[uid] = [0, 0, 0]
            if regdate == need_date:
                uid_based_info[uid][0] += 1
            if effdate == need_date:
                uid_based_info[uid][1] += 1
            if expdate == need_date:
                uid_based_info[uid][2] += 1
    for uid, u_based_info in uid_based_info.items():
        ot_list = [uid, need_date, str(u_based_info[0]), str(u_based_info[1]), str(u_based_info[2])]
        print('\t'.join(ot_list)).encode('gb18030')


