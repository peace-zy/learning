#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/09 16:40:31
"""
本地聚合登陆数据，账户天粒度
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

def load_land_province_info(filename):
    """读取登陆位置信息
    """
    land_province_dict = dict()
    land_province_list = []
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('utf8').split('\t')
        province_name = data[0]
        province_id = data[1]
        land_province_dict[province_name] = province_id
        land_province_list.append(province_id)
    f.close()
    return land_province_dict, land_province_list

if __name__ == "__main__":
    land_province_dict, land_province_list = load_land_province_info(sys.argv[1])
    info_date = sys.argv[2]
    uid_info = dict()
    for line in sys.stdin:
        data = line.strip('\n').decode('utf8').split('\t')
        uid = data[1]
        cuid = data[3]
        address = data[6]
        if address not in land_province_dict:
            #非已知类型登陆地址, 归为NULL类型
            address = "NULL"
        land_province_id = land_province_dict[address]
        if uid not in uid_info:
            uid_info[uid] = [0, set(), dict()]
            for provid in land_province_list:
                uid_info[uid][2][provid] = 0
        uid_info[uid][0] += 1
        uid_info[uid][1].add(cuid)
        uid_info[uid][2][land_province_id] += 1
    for uid, u_info in uid_info.items():
        land_province_num = 0
        ot_list = [uid]
        ot_list.append(info_date)
        ot_list.append(str(u_info[0]))
        ot_list.append(str(len(u_info[1])))
        ot_list.append("NULL")
        for province_id in land_province_list:
            id_num = u_info[2][province_id]
            if id_num > 0:
                land_province_num += 1
            ot_list.append(str(id_num))
        ot_list[4] = str(land_province_num)
        print('\t'.join(ot_list)).encode('gb18030')

        


