#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/09 11:58:50
"""
离线获取登陆日志位置信息
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

if __name__ == "__main__":
    land_prov_set = set()
    for line in sys.stdin:
        data = line.strip('\n').decode('utf8').split('\t')
        land_place = data[6]
        land_province = '-'.join(land_place.split('\\t')[:2])
        land_prov_set.add(land_province)
    index = 0
    for item in land_prov_set:
        index += 1
        print('\t'.join([item, str(index)])).encode('utf8')


