#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/04 20:40:29
"""
聚合凤巢点击数据-账户天粒度, reducer阶段
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

if __name__ == "__main__":
    keyid = "None"
    content_list = []
    cal_date = "None"
    #输入及输出的格式
    #1874列: 1:uid 2:date 3～6:全天消费、点击、夜间消费、夜间点击量
    #7～146: 37x4=140 37个地域的 消费、点击、夜间消费、夜间点击量
    #147~194: 24x2=48 24个小时的消费、点击量
    #195～1874: 24x35x2=1680 24个小时的37个地域的消费、点击量
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        date = data[1]
        if keyid == "None":
            content_list = [0 for i in range(len(data) - 2)]
            cal_date = date
        if keyid != "None" and keyid != uid:
            ot_list = [keyid, date] + [str(item) for item in content_list]
            print('\t'.join(ot_list)).encode('gb18030')
            content_list = [0 for i in range(len(data) - 2)]
        keyid = uid
        tmp_content_list = [float(item) for item in data[2: ]]
        assert len(tmp_content_list) == len(content_list)
        for index in range(len(content_list)):
            content_list[index] += tmp_content_list[index]
    if keyid != "None":
        ot_list = [keyid, date] + [str(item) for item in content_list]
        print('\t'.join(ot_list)).encode('gb18030')
        


