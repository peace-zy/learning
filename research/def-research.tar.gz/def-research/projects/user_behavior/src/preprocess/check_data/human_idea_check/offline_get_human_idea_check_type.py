#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/09 11:58:50
"""
获取人审-物料审核的违规类型
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

if __name__ == "__main__":
    human_acc_type_set = set()
    for line in sys.stdin:
        data = line.strip('\n').decode('utf8').split('\t')
        is_reject = data[31]
        human_acc_types = data[32].split(',')
        if is_reject == '4':
            for human_acc_type in human_acc_types:
                human_acc_type_set.add(human_acc_type)
    index = 0
    for item in human_acc_type_set:
        index += 1
        print('\t'.join([item, str(index)])).encode('utf8')


