#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/10 18:58:43
"""
本地处理人审-账户审核数据
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

def load_human_acc_reason(filename):
    """加载拒绝理由 拒绝理由id -> 顺序id
    """
    reject_dict = dict()
    reject_list = []
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('gb18030').split('\t')
        reject_reason = data[0]
        reject_id = data[1]
        reject_dict[reject_reason] = reject_id
        reject_list.append(reject_id)
    f.close()
    return reject_dict, reject_list

if __name__ == "__main__":
    reject_dict, reject_list = load_human_acc_reason(sys.argv[1])
    need_date = sys.argv[2]
    uid_info = dict()
    # 不在已知违规类型的数据，以other代替
    OTHER_SIGN = 'other'
    for line in sys.stdin:
        data = line.strip('\n').decode('utf8').split('\t')
        uid = data[1]
        result = data[13]
        reject_reasons = data[14].split(',')
        if result != '4':
            continue
        if uid not in uid_info:
            uid_info[uid] = [0, dict()]
            for reject_item in reject_list:
                uid_info[uid][1][reject_item] = 0
            uid_info[uid][1][OTHER_SIGN] = 0
        for reject_reason in reject_reasons:
            reject_id = OTHER_SIGN
            if reject_reason in reject_dict:
                reject_id = reject_dict[reject_reason]
            uid_info[uid][0] += 1
            uid_info[uid][1][reject_id] += 1
    for uid, v in uid_info.items():
        ot_list = [uid, need_date, str(v[0])]
        for reject_item in reject_list:
            ot_list.append(str(v[1][reject_item]))
        ot_list.append(str(v[1][OTHER_SIGN]))
        print('\t'.join(ot_list)).encode('gb18030')




