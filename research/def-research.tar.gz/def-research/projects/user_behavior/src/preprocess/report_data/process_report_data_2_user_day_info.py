#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/09 16:40:31
"""
聚合举报数据-账户天粒度
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

def load_report_info(filename):
    """加载举报理由
    """
    report_info_dict = dict()
    report_info_list = []
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('utf8').split('\t')
        report_name = data[0]
        report_id = data[1]
        report_info_dict[report_name] = report_id
        report_info_list.append(report_id)
    f.close()
    return report_info_dict, report_info_list

if __name__ == "__main__":
    report_info_dict, report_info_list = load_report_info(sys.argv[1])
    info_date = sys.argv[2]
    uid_info = dict()
    for line in sys.stdin:
        data = line.strip('\n').decode('utf8').split('\t')
        uid = data[7]
        result = data[11]
        report_type = data[2]
        if report_type not in report_info_dict:
            #非已知类型拒绝理由, 用"其他"替代
            report_type = u"其他"
        report_id = report_info_dict[report_type]
        if uid not in uid_info:
            uid_info[uid] = [0, 0, dict(), dict()]
            for type_id in report_info_list:
                uid_info[uid][2][type_id] = 0
                uid_info[uid][3][type_id] = 0
        uid_info[uid][1] += 1
        uid_info[uid][3][report_id] += 1
        if result == u"有效":
            uid_info[uid][0] += 1
            uid_info[uid][2][report_id] += 1
    for uid, u_info in uid_info.items():
        ot_list = [uid, info_date]
        ot_list.append(str(u_info[0]))
        ot_list.append(str(u_info[1]))
        for report_id in report_info_list:
            ot_list.append(str(u_info[2][report_id]))
        for report_id in report_info_list:
            ot_list.append(str(u_info[3][report_id]))
        print('\t'.join(ot_list)).encode('gb18030')
