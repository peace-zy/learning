#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/09 11:58:50
"""
离线获取举报理由
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")
import re

if __name__ == "__main__":
    report_type_set = set()
    for line in sys.stdin:
        data = line.strip('\n').decode('utf8').split('\t')
        report_types = re.split(u";|；", data[2])
        for report_type in report_types:
            report_type_set.add(report_type)
    index = 0
    for item in report_type_set:
        index += 1
        print('\t'.join([item, str(index)])).encode('utf8')


