#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/15 20:39:00
"""
构建操作关系图mapper阶段
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

if __name__ == "__main__":
    #以"被操作账户ID-操作账户ID"为key，聚合数据
    opt_dict = dict()
    for line in sys.stdin:
        data = line.strip('\n').decode('utf8').split('\x01')
        uid = data[0]
        opt_uid = data[1]
        keyid = uid + '-' + opt_uid
        if keyid not in opt_dict:
            opt_dict[keyid] = 0
        opt_dict[keyid] += 1
    for keyid, v in opt_dict.items():
        ot_list = [keyid, str(v)]
        print('\t'.join(ot_list)).encode('gb18030')

