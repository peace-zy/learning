#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/10/18 11:09:12
"""
mapper get opt info
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")
import math

def convert_ip_2_one_zero(number):
    """convert ip format
    """
    ip_part_length = 8
    tmp_number = number
    convert_str_list = []
    for i in range(ip_part_length - 1, -1, -1):
        tmp_2_pow = math.pow(2, i)
        if tmp_number // tmp_2_pow > 0:
            convert_str_list.append("1")
            tmp_number -= tmp_2_pow
        else:
            convert_str_list.append("0")
    return ''.join(convert_str_list)


def check_ip_address_type(head_ip):
    """find ip type
    """
    ipaddress_type = "0"
    if head_ip.startswith('0'):
        ipaddress_type = "1"
    elif head_ip.startswith('10'):
        ipaddress_type = "2"
    elif head_ip.startswith('110'):
        ipaddress_type = "3"
    elif head_ip.startswith('1110'):
        ipaddress_type = "4"
    elif head_ip.startswith('11110'):
        ipaddress_type = "5"
    return ipaddress_type


def get_ipaddress(ipaddress_type, head_1_ip, head_2_ip, head_3_ip, head_4_ip):
    """get ip address by ip type
    """
    ipaddress = ''.join([head_1_ip, head_2_ip, head_3_ip, head_4_ip])
    if ipaddress_type == "1":
        ipaddress = ''.join([head_1_ip])
    elif ipaddress_type == "2":
        ipaddress = ''.join([head_1_ip, head_2_ip])
    elif ipaddress_type == "3":
        ipaddress = ''.join([head_1_ip, head_2_ip, head_3_ip])
    return ipaddress


def translate_ip_2_ipaddress(ip_info):
    """get ip address from ip
    """
    ip_4_parts = ip_info.split('.')
    head_1_ip = convert_ip_2_one_zero(int(ip_4_parts[0]))
    head_2_ip = convert_ip_2_one_zero(int(ip_4_parts[1]))
    head_3_ip = convert_ip_2_one_zero(int(ip_4_parts[2]))
    head_4_ip = convert_ip_2_one_zero(int(ip_4_parts[3]))
    ipaddress_type = check_ip_address_type(head_1_ip)
    ipaddress = get_ipaddress(ipaddress_type, head_1_ip, head_2_ip, head_3_ip, head_4_ip)
    return ipaddress_type, ipaddress


if __name__ == "__main__":
    optip_number = dict()
    optip_content = dict()
    for line in sys.stdin:
        data = line.strip('\n').decode('utf8').split('\x01')
        uid = data[0]
        opt_uid = data[1]
        opt_ip = data[2]
        if len(opt_ip.split('.')) != 4:
            continue
        keyid = '||'.join([uid, opt_uid, opt_ip])
        if keyid not in optip_content:
            ipaddress_type, ipaddress = translate_ip_2_ipaddress(opt_ip)
            optip_content[keyid] = [uid, opt_uid, opt_ip, ipaddress_type, ipaddress]
        if keyid not in optip_number:
            optip_number[keyid] = 0
        optip_number[keyid] += 1
    for k, v in optip_content.items():
        opt_number = optip_number[k]
        content = v
        ot_list = [k] + content + [str(opt_number)]
        print('\t'.join(ot_list)).encode('gb18030')
