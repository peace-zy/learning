#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/10/18 15:21:21
"""reducer get opt ip info
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

if __name__ == "__main__":
    tdate = sys.argv[1]
    key = "None"
    key_content = ["None", "None", "None", "None", "None"]
    key_opt_number = 0
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        keyid = data[0]
        uid = data[1]
        opt_uid = data[2]
        opt_ip = data[3]
        ipaddress_type = data[4]
        ipaddress = data[5]
        opt_number = int(data[6])
        if key != keyid and key != "None":
            ot_list = key_content + [tdate, str(key_opt_number)]
            print('\t'.join(ot_list)).encode('gb18030')
            key_content = ["None", "None", "None", "None", "None"]
            key_opt_number = 0
        key = keyid
        key_content[0] = uid
        key_content[1] = opt_uid
        key_content[2] = opt_ip
        key_content[3] = ipaddress_type
        key_content[4] = ipaddress
        key_opt_number += opt_number
    if key != "None":
        ot_list = key_content + [tdate, str(key_opt_number)]
        print('\t'.join(ot_list)).encode('gb18030')

