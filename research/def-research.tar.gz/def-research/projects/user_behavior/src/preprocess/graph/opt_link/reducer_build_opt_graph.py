#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/15 20:39:14
"""
构建操作关系图reducer阶段
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

if __name__ == "__main__":
    #以"被操作账户ID-操作账户ID"为key，聚合数据
    ot_date = sys.argv[1]
    keyid = "None"
    opt_num = 0
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid_2_optid = data[0]
        tmp_num = int(data[1])
        if keyid != "None" and uid_2_optid != keyid:
            tmp_ids = keyid.split('-')
            if len(tmp_ids) == 2:
                uid, opt_uid = tmp_ids
                ot_list = [uid, opt_uid, str(opt_num), ot_date]
                print('\t'.join(ot_list)).encode('gb18030')
            opt_num = 0
        keyid = uid_2_optid
        opt_num += tmp_num
    if keyid != "None":
        tmp_ids = keyid.split('-')
        if len(tmp_ids) == 2:
            uid, opt_uid = tmp_ids
            ot_list = [uid, opt_uid, str(opt_num), ot_date]
            print('\t'.join(ot_list)).encode('gb18030')

