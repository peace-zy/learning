#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/09 11:58:50
"""
离线获取判罚理由类型
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

if __name__ == "__main__":
    punish_type_set = set()
    for line in sys.stdin:
        data = line.strip('\n').decode('utf8').split('\t')
        punish_type = data[1]
        punish_type_set.add(punish_type)
    index = 0
    for item in punish_type_set:
        index += 1
        print('\t'.join([item, str(index)])).encode('utf8')


