#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/09 16:40:31
"""
本地聚合判罚数据-账户天粒度
"""
import sys
reload(sys)
sys.setdefaultencoding("utf8")

def load_punish_info(filename):
    """加载判罚拒绝理由
    """
    punish_info_dict = dict()
    punish_info_list = []
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('utf8').split('\t')
        punish_name = data[0]
        punish_id = data[1]
        punish_info_dict[punish_name] = punish_id
        punish_info_list.append(punish_id)
    f.close()
    return punish_info_dict, punish_info_list

if __name__ == "__main__":
    punish_info_dict, punish_info_list = load_punish_info(sys.argv[1])
    info_date = sys.argv[2]
    uid_info = dict()
    for line in sys.stdin:
        data = line.strip('\n').decode('utf8').split('\t')
        uid = data[0]
        source = data[6]
        punish_type = data[1]
        if punish_type not in punish_info_dict:
            #非已知类型拒绝理由, 用others替代
            punish_type = "others"
        punish_id = punish_info_dict[punish_type]
        if uid not in uid_info:
            uid_info[uid] = [0, 0, 0, dict()]
            for type_id in punish_info_list:
                uid_info[uid][3][type_id] = 0
        uid_info[uid][0] += 1
        if source == u"非监察":
            uid_info[uid][1] += 1
        else:
            uid_info[uid][2] += 1
        uid_info[uid][3][punish_id] += 1
    for uid, u_info in uid_info.items():
        ot_list = [uid, info_date]
        ot_list.append(str(u_info[0]))
        ot_list.append(str(u_info[1]))
        ot_list.append(str(u_info[2]))
        for punish_id in punish_info_list:
            ot_list.append(str(u_info[3][punish_id]))
        print('\t'.join(ot_list)).encode('gb18030')
