#!/usr/bin/env python
# -*- coding:gbk -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/09/02 18:26:45
"""�����е�����˻�, ��ΪԤ��������˻�
"""

import sys
reload(sys)
sys.setdefaultencoding("gbk")

if __name__ == "__main__":
    uid_set = set()
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        uid_set.add(uid)
    for uid in uid_set:
        print(uid).encode('gb18030')

