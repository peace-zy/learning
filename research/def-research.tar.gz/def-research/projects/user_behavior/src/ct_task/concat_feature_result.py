#!/usr/bin/env python
# -*- coding:gbk -*-
#Author:   zhukaiwen@baidu.com
#Date  :   21/09/08 10:35:29
"""�ϲ����ģ�͵�Ԥ����
"""

import sys
reload(sys)
sys.setdefaultencoding("gbk")

def load_uid_info_file(filename):
    """ ��ȡ�˻�Ԥ�����
    """
    uid_rates = dict()
    f = open(filename)
    for line in f:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        rate = float(data[1])
        uid_rates[uid] = rate
    f.close()
    return uid_rates

if __name__ == "__main__":
    info_files = (sys.argv[1]).split('!!')
    results = dict()
    for info_file in info_files:
        uid_rates = load_uid_info_file(info_file)
        for uid, rate in uid_rates.items():
            if uid not in results:
                results[uid] = rate
            else:
                old_rate = results[uid]
                if old_rate < rate:
                    results[uid] = rate
    for k, v in results.items():
        ot_list = [k, str(v)]
        print('\t'.join(ot_list)).encode('gb18030')

