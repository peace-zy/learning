#!/usr/bin/env python
# -*- coding:utf8 -*-
#Author:   gancaizhao@baidu.com
#Date  :   21/08/24 14:38:21
"""
xgboost预估账户类型
"""

import sys
reload(sys)
sys.setdefaultencoding("utf8")
import numpy as np
from scipy.sparse import hstack
from scipy import sparse
import random
import json
import pickle

def process_input_feature(data_path):
    """处理输入特征
    """
    input_data = []
    uid_list = []
    f = open(data_path)
    for line in f:
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        uid_list.append(uid)
        data_len = int(data[1])
        data_dict = json.loads(data[2])
        tmp_list = [0.0 for i in range(data_len)]
        for key, value in data_dict.items():
            tmp_list[int(key)] = float(value)
        input_data.append(tmp_list)
    f.close()
    return input_data, uid_list

def trans_rate_2_label(y_pred_rate, threshold):
    """将预测概率转化成预测label, 三类标签：0-正常 1-嫌疑 2-非常嫌疑
    """
    y_pred_label = []
    y_pred_rates = []
    for rates in y_pred_rate:
        max_index = 0
        max_num = 0.0
        for index in range(len(rates)):
            if rates[index] >= max_num:
                max_index = index
                max_num = rates[index]
        if max_index != 0:
            if max_num < threshold:
                max_index = 0
        y_pred_label.append(max_index)
        y_pred_rates.append(rates[max_index])
    return y_pred_label, y_pred_rates

if __name__ == "__main__":
    # xgboost预测账户类型
    # 三类标签：0-正常 1-嫌疑 2-非常嫌疑
    train_data_path = sys.argv[1]
    threshold = float(sys.argv[2])
    model_file = sys.argv[3]
    each_num = 300000
    model = pickle.load(open(model_file, 'rb'))

    y_pred_label = []
    y_pred_rates = []
    uid_list = []
    data_ct = []
    indptr = [0]
    indices = []
    linenumber = 0
    data_len = -100
    tmp_num = 0
    data_size = 0
    f = open(train_data_path)
    for line in f:
        linenumber += 1
        data = line.strip('\n').decode('gb18030').split('\t')
        uid = data[0]
        uid_list.append(uid)
        data_len = int(data[1])
        data_dict = json.loads(data[2])
        tmp_num += len(data_dict)
        data_size += 1
        indptr.append(tmp_num)
        for key, value in data_dict.items():
            indices.append(int(key))
            data_ct.append(float(value))
        if linenumber % each_num == 0:
            sparse_data_x = sparse.csr_matrix((data_ct, indices, indptr), shape = (each_num, data_len))
            y_pred_test = model.predict_proba(sparse_data_x)
            tmp_y_pred_label, tmp_y_pred_rates = trans_rate_2_label(y_pred_test, threshold)
            y_pred_label += tmp_y_pred_label
            y_pred_rates += tmp_y_pred_rates
            data_ct = []
            indptr = [0]
            indices = []
            tmp_num = 0
            data_size = 0
    if len(data_ct) != 0:
        sparse_data_x = sparse.csr_matrix((data_ct, indices, indptr), shape = (data_size, data_len))
        y_pred_test = model.predict_proba(sparse_data_x)
        tmp_y_pred_label, tmp_y_pred_rates = trans_rate_2_label(y_pred_test, threshold)
        y_pred_label += tmp_y_pred_label
        y_pred_rates += tmp_y_pred_rates
    f.close()
    assert len(uid_list) == len(y_pred_label) == len(y_pred_rates)
    for index in range(len(uid_list)):
        ot_list = [uid_list[index], str(y_pred_label[index]), str(y_pred_rates[index])]
        print('\t'.join(ot_list)).encode('gb18030')
