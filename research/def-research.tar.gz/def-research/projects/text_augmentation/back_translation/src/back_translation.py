#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   back_translation.py
Author:   zhanghao55@baidu.com
Date  :   21/01/13 11:28:28
Desc  :   ���ðٶ�ͨ�÷���APIʵ�ֻ��빦��
"""

import codecs
import sys
import http.client
import hashlib
import urllib
import random
import time
import json
from tqdm import tqdm


class BackTranslator(object):
    def __init__(self):
        self.appid = '20210113000670292'  # appid
        self.secretKey = 'CVSxqsHDcTcEMcCzhquW'  # ��Կ

        self.salt = random.randint(32768, 65536)

        self.url_template = "/api/trans/vip/translate/?appid={appid}&q={query}&from={from}&to={to}&salt={salt}&sign={sign}"

        self.dict_template = {
                "appid": self.appid,
                "salt": self.salt,
                }

        # ���������ߵͳ̶� ����ԽС����Խ��
        # ����������[0, 1]������
        self.default_lang_list = [
                "en",   # 0
                "yue",  # 1
                #"wyw",  # 5
                "jp",   # 1
                #"kor",  # 3
                #"fra",  # 3
                "spa",  # 1
                #"th",   # 9
                #"ara",  # 4
                #"ru",   # 9
                #"pt",   # 4
                #"de",   # 4
                #"it",   # 4
                #"el",   # 9
                #"nl",   # 3
                #"vie",  # 3
                ]

        self.api_url = "api.fanyi.baidu.com"

    def trans_back(self, text_list, inter_lang_list=None, max_length=2000, max_retry=3, is_debug=False):
        trans_back_res_list = list()

        if inter_lang_list is None:
            inter_lang_list = self.default_lang_list

        # �����ε���api
        # ����api��qpsҪ�� ÿ�ε��ÿɴ���6000���ֽ�(����Ӧ�޶���Լ2000���ַ�)
        # ��˽��ı�����Ϊ�������� ÿ���γ�����2000����(��ĳһ���ı��ַ����ȳ���2000�����ı�Ϊ����һ��)
        def gen_batch(iter_list, maxlen=2000):
            cur_batch = list()
            cur_batch_len = 0
            for cur_text in tqdm(iter_list, position=0, desc="total text"):
                cur_text_len = len(cur_text)
                if cur_batch_len + cur_text_len > maxlen:
                    if cur_batch_len > 0:
                        yield cur_batch
                    cur_batch = list()
                    cur_batch.append(cur_text)
                    cur_batch_len = cur_text_len
                else:
                    cur_batch.append(cur_text)
                    cur_batch_len += cur_text_len

            if cur_text_len > 0:
                yield cur_batch
        try:
            self.httpClient = http.client.HTTPConnection(self.api_url)
            for cur_text_batch in gen_batch(text_list, max_length):
                cur_res = self.batch_trans_back(cur_text_batch, inter_lang_list, max_retry=max_retry, is_debug=is_debug)
                trans_back_res_list.extend(cur_res)
        except Exception as e:
            raise e
        finally:
            self.httpClient.close()

        return trans_back_res_list

    def batch_trans_back(self, query_list, inter_lang_list, max_retry=3, is_debug=False):
        #print("cur_batch: {}".format(query_list))
        batch_query = "\n".join(query_list)
        trans_lang_list = list()
        trans_back_list = list()
        # �������ı����θ���ָ�������Խ��л���
        with tqdm(inter_lang_list, position=1, desc="batch progress") as pbar:
            for cur_lang in pbar:
                pbar.set_postfix({"to lang": cur_lang})
                cur_trans_list = self.get_trans_res(batch_query, "zh", cur_lang, max_retry, is_debug=is_debug)
                if cur_trans_list is None:
                    continue
                batch_res = "\n".join(cur_trans_list)
                cur_trans_back_list = self.get_trans_res(batch_res, cur_lang, "zh", max_retry, is_debug=is_debug)
                if cur_trans_back_list is None:
                    continue
                trans_back_list.append(cur_trans_back_list)
                trans_lang_list.append(cur_lang)

        res_list = list()
        for cur_query, cur_trans_back_list in zip(query_list, zip(*trans_back_list)):
            cur_query_dict = {
                    "ori_text": cur_query,
                    "trans_text": dict(),
                    }
            for cur_lang, cur_trans_back_text in zip(trans_lang_list, cur_trans_back_list):
                cur_query_dict["trans_text"][cur_lang] = cur_trans_back_text

            #print("cur_query_dict: {}".format(cur_query_dict))
            res_list.append(cur_query_dict)
        #print("res_list: {}".format(res_list))

        return res_list

    def get_trans_res(self, query, fromLang, toLang, max_retry=3, is_debug=False):
        res = None
        sign = self.appid + query + str(self.salt) + self.secretKey
        sign = hashlib.md5(sign.encode()).hexdigest()
        cur_dict = dict({
            "query":urllib.parse.quote(query),
            "from":fromLang,
            "to":toLang,
            "sign":sign},
            **self.dict_template,
            )
        if is_debug:
            print("cur_dict: {}".format(cur_dict))
        cur_url = self.url_template.format(**cur_dict)
        cur_retry = 0
        while cur_retry < max_retry:
            try:
                self.httpClient.request('GET', cur_url)
                response = self.httpClient.getresponse()
                # response��HTTPResponse����
                result_all = response.read().decode("utf-8")
                result = json.loads(result_all)
                if is_debug:
                    print("result: {}".format(result))
                res = [x["dst"] for x in result["trans_result"]]
            except Exception as e:
                #print("error at query: {}".format(query))
                print("error at result: {}".format(response.read()))
                continue

            cur_retry += 1
            time.sleep(1)
            if res is not None:
                break

        return res

def main():
    back_translator = BackTranslator()
    #text_list = [
    #        "����׼ȷ����ζ��壿��������������ϣ���Ȼ���Ѷȴ󣬻᲻������󲻹�ƽ",
    #        "�ٻ�����ô��",
    #        "����׼ȷ����ζ��壿��������������ϣ���Ȼ���Ѷȴ󣬻᲻������󲻹�ƽ",
    #        "������ʱ����",
    #        "������ʱ����",
    #        ]
    text_list = list()
    for line in sys.stdin:
        text_list.append(line.strip("\n"))

    augmentation_res_list = back_translator.trans_back(text_list, max_length=2000, is_debug=False)
    with codecs.open("output/augmentation_res.txt", "w", "utf-8") as wf:
        for cur_augmentation_res in augmentation_res_list:
            ori_text = cur_augmentation_res["ori_text"]
            wf.write("ori text: {}\n".format(ori_text))
            trans_text = cur_augmentation_res["trans_text"]
            wf.write("trans back:\n")
            for cur_lang, cur_trans_text in trans_text.items():
                wf.write(cur_lang + ": " + cur_trans_text + "\n")
            wf.write("="*50 + "\n")


if __name__ == "__main__":
    main()


