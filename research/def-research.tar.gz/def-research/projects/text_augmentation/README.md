# 文本扩充
相似文本扩充，提升样本收集的效率和模型训练的效果。

### 文件结构
```
root: 根目录
├── back_translation: 回译
├── ernie_seqsim: 相似文本检索
│   └── pretrained_models: 预训练模型目录
├── http_service: 相似文本检索服务
│   └── pretrained_models: 预训练模型目录
└── model_eval: 相似文本效果评估
    └── pretrained_models: 预训练模型目录
```


### 运行准备
1. python3
2. requirements.txt指定的库
3. 预训练数据: 保存在`afs://shaolin.afs.baidu.com:9902/app/ecom/fengkong/personal/zhanghao55/archives/pretrained_models/ernie-1.0/pytorch/ernie-1.0.zip`，将该数据下载并解压到某目录，在各目录下添加该数据软链即可。
