#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   main.py
Author:   zhanghao55@baidu.com
Date  :   21/01/19 16:25:38
Desc  :   CUDA_VISIBLE_DEVICES=4,5,6,7 python -m torch.distributed.launch --nproc_per_node=4 --master_addr 127.0.0.7 --master_port 29889 src/main.py --task xxx --uniqid xxx ...
"""

import os
import sys
import codecs
import datetime
import json
import logging
import numpy as np
import time
import torch

from collections import Counter
from sklearn.model_selection import train_test_split
from torch.utils.data import Dataset, DataLoader

from run_arguments import parse_args

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../lib/" % _cur_dir)
from base_model import ClassificationModel, model_distributed
from bert import BertForClassification
from utils import (
        check_dir,
        bert_collate_fn,
        bert_infer_collate_fn,
        get_dataloader,
        ErnieDataset,
        create_dataset,
        )

sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.bert_tokenizer import BertTokenizer
from lib.common.label_encoder import  LabelEncoder
from lib.common.data_io import get_data
from lib.common.logger import init_log


IS_DISTRIBUTED = False
try:
    torch.distributed.init_process_group(backend="nccl")
    LOCAL_RANK = torch.distributed.get_rank()
    IS_DISTRIBUTED = True

    logging_level = logging.INFO if LOCAL_RANK == 0 else logging.WARNING
    init_log(stream_level=logging_level)
except ValueError as e:
    init_log(stream_level=logging.INFO)

logging.info("is_distributed: {}".format(IS_DISTRIBUTED))


class ErnieClassificationModel(ClassificationModel):
    """ErnieClassificationModel
    """
    @model_distributed(find_unused_parameters=True, distributed=IS_DISTRIBUTED)
    def init_model(self, model_dir, num_class, tokenizer, keep_tokens, **kwargs):
        """��ʼ������
        """
        ernie_model = BertForClassification.from_pretrained(
                model_dir,
                num_class=num_class,
                vocab_size=tokenizer.vocab_size,
                keep_tokens=keep_tokens,
                **kwargs
                )
        return ernie_model


class ErnieClassifierRunner(object):
    """Classifier��
    """
    def __init__(self):
        # �ֲ�ʽʱ sys.argv������һ��local_rank���� ����ʱ��Ҫʡ��
        self.config = parse_args(sys.argv[2:]) if IS_DISTRIBUTED else parse_args()

        check_dir(self.config.output_dir)
        check_dir(self.config.model_dir)

        self.label_encoder = LabelEncoder(self.config.class_id_path)
        self.tokenizer, self.keep_tokens = BertTokenizer.load(self.config.vocab_path, simplified=True)
        self.model = ErnieClassificationModel(
                model_dir=self.config.pretrained_model_path,
                tokenizer=self.tokenizer,
                keep_tokens=self.keep_tokens,
                num_class=self.label_encoder.size(),
                pool_out_size=self.config.pool_out_size,
                avg_pool=self.config.avg_pool,
                )
        logging.info("model at device : {}".format(self.model.device))

    def run(self):
        """ִ�����
        """
        {
                "train": self.train,
                "infer": self.infer,
                "stat": self.stat,
                }[self.config.task]()

    def train(self):
        """ѵ��
        """
        train_dataset, test_dataset = create_dataset(
                data_dir=self.config.input_path,
                tokenizer=self.tokenizer,
                label_encoder=self.label_encoder,
                test_size = self.config.test_ratio,
                max_num=self.config.max_num,
                encoding="utf-8",
                )

        train_dataloader = get_dataloader(
                train_dataset,
                shuffle=True,
                collate_fn=bert_collate_fn,
                batch_size=self.config.batch_size,
                distributed=IS_DISTRIBUTED,
                )

        test_dataloader = get_dataloader(
                test_dataset,
                shuffle=False,
                collate_fn=bert_collate_fn,
                batch_size=self.config.batch_size,
                distributed=IS_DISTRIBUTED,
                )

        check_dir(self.config.ernie_classifier_dir)

        run_config = {
                "model_save_path": self.config.ernie_classifier_model,
                "best_model_save_path": self.config.ernie_classifier_model_best,
                "epochs": self.config.epoch,
                "print_step": self.config.print_step,
                "learning_rate": self.config.learning_rate,
                "load_best_model": self.config.load_best_model,
                "scheduler_mode": self.config.scheduler_mode,
                "warm_up": self.config.warm_up,
                }

        best_loss = self.model.train(train_dataloader, test_dataloader, **run_config)

        logging.info("best_loss = {}.".format(best_loss))

    def infer(self):
        """ģ��Ԥ��
        """
        # label�����޹��������
        infer_dataloader, infer_text_list, ori_text_list = self.get_sim_dataloader(
                sim_data_path=self.config.input_path,
                sim_topk=self.config.sim_topk)

        self.model.load_model(self.config.ernie_classifier_model_best)

        infer_res = self.model.predict(infer_dataloader, fetch_list=["text_output"])

        pred = infer_res["text_output"]
        logging.info("pred shape= {}.".format(pred.shape))

        # �����gpu��������֮�� ��cpu().numpy()֮�� �������Ľ��̲��ܽ��� ��Ȼ�Ῠ��
        # �����return���� text_vec_list֮ǰ �����Ῠס
        if IS_DISTRIBUTED and LOCAL_RANK != 0:
            return

        pred_label = np.argmax(pred, axis=1)
        #pred_ratio = np.max(pred, axis=1)
        logging.info("pred label shape= {}.".format(pred_label.shape))
        #logging.info("pred ratio shape= {}.".format(pred_ratio.shape))

        pred_label = [self.label_encoder.inverse_transform(x) for x in pred_label]
        count_res = Counter(pred_label)

        logging.info("label count:")
        for label, count in count_res.items():
            logging.info("{}: {}".format(label, count))

        def sim_record(ori_text, sim_text_info_list):
            """��¼Ԥ����
            """
            res = "ori_text: {}\n".format(ori_text)
            for index, (cur_label, cur_text) in enumerate(sim_text_info_list):
                res += "sim_text #{}, label {}: {}\n".format(index, cur_label, cur_text)
            res += "=" * 150 + "\n"
            return res

        prev_ori_text = None
        sim_text_info_list = list()
        with codecs.open(self.config.infer_res_path, "w", "utf-8") as wf:
            for cur_label, cur_infer_text, cur_ori_text in zip(pred_label, infer_text_list, ori_text_list):

                if cur_ori_text != prev_ori_text:
                    if prev_ori_text is not None:
                        wf.write(sim_record(prev_ori_text, sim_text_info_list))

                    sim_text_info_list = list()
                    prev_ori_text = cur_ori_text

                sim_text_info_list.append((cur_label, cur_infer_text))

            if prev_ori_text is not None:
                wf.write(sim_record(prev_ori_text, sim_text_info_list))


    def stat(self):
        """ͳ�Ʒ�������ռ��
        """
        #path_list = self.config.path_list
        logging.info("path_list: {}".format(self.config.path_list))

        def get_infer_info(data_path):
            """ͳ��Ԥ������Ϣ
            """
            # label_lists[i][j]: ��i�������ĵ�j�����������ı�ǩ
            label_lists = list()
            with codecs.open(data_path, "r", "utf-8") as rf:
                for line in rf:
                    line = line.strip("\n")
                    if line.startswith("ori_text"):
                        cur_label_list = list()
                    elif line.startswith("sim_text"):
                        label = line[line.find("label ") + 6:line.find(":")]
                        cur_label_list.append(label)
                    elif line.startswith("======"):
                        label_lists.append(cur_label_list)
                        cur_label_list = None
            #logging.info("label_lists size: {}".format(len(label_lists)))
            return label_lists

        def stat_count(label_lists, sim_topk):
            """�����label����
            """
            total_label_list = list()
            for cur_label_list in label_lists:
                cur_label_list = cur_label_list[:sim_topk]
                total_label_list.extend(cur_label_list)
            #logging.info("total_label_list: {}".format(len(total_label_list)))
            return Counter(total_label_list)

        # ���ظ��ļ��еı�ǩ��Ϣ
        path_info_dict = dict()
        for cur_path in self.config.path_list:
            path_info_dict[cur_path] = get_infer_info(cur_path)

        # ͳ�Ƹ��ļ���ͬtopk�µ�����
        topk_list = [
                1,
                2,
                3,
                4,
                5,
                6,
                7,
                8,
                9,
                10,
                12,
                15,
                18,
                20,
                25,
                30,
                40,
                50,
                60,
                70,
                80,
                100,
                ]
        # stat_dict[path][topk] = {label:count}
        stat_dict = dict()
        for file_path, label_lists in path_info_dict.items():
            stat_dict[file_path] = dict()
            for sim_topk in topk_list:
                stat_dict[file_path][sim_topk] = stat_count(label_lists, sim_topk)


        with codecs.open(self.config.stat_res_path, "w", "utf-8") as wf:
            wf.write("\t".join([
                "file_path",
                "cur_topk",
                ] + self.label_encoder.labels()) + "\n")
            for file_path, file_stat_dict in stat_dict.items():
                for cur_topk, count_dict in file_stat_dict.items():
                    wf.write("\t".join([
                        file_path,
                        str(cur_topk),
                        ] + [str(count_dict.get(x, 0)) for x in self.label_encoder.labels()]) + "\n")

    def get_sim_dataloader(self, sim_data_path, sim_topk):
        """����dataloader
        """
        sim_text_list = list()
        ori_text_list = list()
        cur_text_list = None
        ori_text = None
        with codecs.open(sim_data_path, "r", "utf-8") as rf:
            for line in rf:
                line = line.strip("\n")
                if line.startswith("ori_text"):
                    text = line[line.find(":") + 1:]
                    cur_text_list = list()
                    ori_text = text
                elif line.startswith("es_sim_text"):
                    if len(cur_text_list) >= sim_topk:
                        continue
                    text = line[line.find(":") + 1:].strip(" ")
                    cur_text_list.append(text)
                elif line.startswith("======"):
                    sim_text_list.extend(cur_text_list)
                    ori_text_list.extend([ori_text] * len(cur_text_list))
                    ori_text = None
                    cur_text_list = None

        sim_text_encoded_list = list()
        for index, cur_text in enumerate(sim_text_list):
            input_ids, token_type_ids = self.tokenizer.encode(cur_text)
            sim_text_encoded_list.append((input_ids, token_type_ids, index))

        logging.info("sim data size: {}".format(len(sim_text_encoded_list)))
        logging.info("ori data size: {}".format(len(ori_text_list)))

        sim_dataset = ErnieDataset(sim_text_encoded_list)

        sim_dataloader = get_dataloader(
                sim_dataset,
                shuffle=False,
                collate_fn=bert_infer_collate_fn,
                batch_size=self.config.batch_size,
                distributed=IS_DISTRIBUTED,
                )
        return sim_dataloader, sim_text_list, ori_text_list


if __name__ == "__main__":
    runner = ErnieClassifierRunner()
    runner.run()
