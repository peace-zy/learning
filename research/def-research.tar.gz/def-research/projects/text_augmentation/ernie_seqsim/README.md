# 相似文本生成、比较
同时训练相似文本的生成和比较两个任务。
模型结构就是bert结构，预训练数据采用ernie-1.0。


### 文件目录
```
root：根目录
├── data：数据目录
│   ├── eval_data：验证数据，格式与训练数据一致，用于评估模型
│   ├── infer_data：预测数据，仅有预测所需数据
│   └── train_data：训练数据
├── log：日志目录
├── model：模型存储文件
│   ├── ...：训练得到的模型
│   │   └── ernie_seqsim_best：模型参数文件
│   └── ernie_seqsim_v2.0：当前es库向量生成所用的模型
│       └── ernie_seqsim_best：模型参数文件
├── output：输出目录
├── pretrained_models：预训练模型目录，可建软链
│   └── ernie-1.0：ernie预训练数据目录（pytorch版）
│       ├── config.json：ernie结构参数
│       ├── pytorch_model.bin：参数数据
│       └── vocab.txt：字典
└── src：程序目录
    ├── config.ini：运行配置
    └── main.py：运行主程序
```

### 运行手册
#### 环境准备
1. python3
2. pytorch
3. 预训练文件pytorch版本: ernie-1.0

#### 确定运行配置
模型支持以下5个任务，在[src/config.ini](https://console.cloud.baidu-int.com/devops/icode/repos/baidu/fengkong/def-research/blob/master:projects/text_augmentation/ernie_seqsim/src/config.ini)中的`[RUN]`下配置需要运行的任务
1. `train`：训练模型，配置在`[ERNIE]`下。
2. `gen_sim_text`: 使用指定的模型，生成指定样本的相似样本，配置在`[SEQ]`下。
3. `gen_text_vec`: 使用指定的模型，生成指定样本的文本向量。
4. `get_similiar_text`: 使用指定模型，检索本地的文本向量数据集中与指定文本向量余弦距离最近的topk样本，配置在`[SIM]`下。
5. `es_get_sim_text`:使用指定模型，检索es库中与指定文本向量余弦距离最近的topk样本，配置在`[ES]`下。

#### 运行脚本
在root下执行命令

【单卡运行】 

`python src/main.py ${CONFIG_PATH} ${UNIQ_POSTFIX}`

其中：
    
1. `${CONFIG_PATH}`：配置文件的地址，默认的在`src/config.ini`
2. `${UNIQ_POSTFIX}`：该任务特殊的后缀，该后缀会影响输出的模型文件名称

运行示例：`python src/main.py src/config.ini v2.0`

【多卡运行】

`python -m torch.distributed.launch --nproc_per_node=${GPU_NUM} --master_addr ${IP} --master_port ${PORT} src/main.py ${CONFIG_PATH} ${UNIQ_POSTFIX}`

其中：
    
1. `${GPU_NUM}`：gpu显卡数，想用几张就设为几
2. `${IP}`： 主任务机器的IP地址。有时候运行会出现address already in use的信息，可修改IP和PORT来解决。当前都是单机多卡的，所以IP可以随便填
3. `${PORT}`： 主任务机器的端口。有时候运行会出现address already in use的信息，可修改IP和PORT来解决。当前都是单机多卡的，所以PORT可以随便填
2. `${CONFIG_PATH}`：配置文件的地址，demo config文件为`src/config.ini`
2. `${UNIQ_POSTFIX}`：该任务特殊的后缀，该后缀会影响输出的模型文件名称

运行示例：`python -m torch.distributed.launch --nproc_per_node=4 --master_addr 127.0.0.7 --master_port 29889 src/main.py src/config.ini v3.0`