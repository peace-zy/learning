#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   main.py
Author:   zhanghao55@baidu.com
Date  :   21/01/19 16:25:38
Desc  :   python -m torch.distributed.launch --nproc_per_node=4 --master_addr 127.0.0.7 --master_port 29889 src/main.py src/config.ini v3.0
"""

import os
import sys
import codecs
import configparser
import datetime
import faiss
import json
import logging
import numpy as np
import time
import torch

from faiss import normalize_L2
from itertools import combinations
from sklearn.model_selection import train_test_split
from sklearn.neighbors import DistanceMetric
from sklearn.neighbors import NearestNeighbors
from torch.utils.data import Dataset, DataLoader

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../lib/" % _cur_dir)
from base_model import BertSeq2seqModel, model_distributed
from es_client import EsClient
from seqsim_distributed_sampler import SeqSimDistributedSampler
from bert import BertForSeqSim
from utils import (
        check_dir,
        bert_collate_fn,
        bert_infer_collate_fn,
        get_dataloader,
        ErnieDataset,
        )

sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.bert_tokenizer import BertTokenizer
from lib.common.data_io import get_data
from lib.common.logger import init_log


IS_DISTRIBUTED = False
try:
    torch.distributed.init_process_group(backend="nccl")
    LOCAL_RANK = torch.distributed.get_rank()
    IS_DISTRIBUTED = True

    logging_level = logging.INFO if LOCAL_RANK == 0 else logging.WARNING
    init_log(stream_level=logging_level)
except ValueError as e:
    init_log(stream_level=logging.INFO)

logging.info("is_distributed: {}".format(IS_DISTRIBUTED))


class ErnieSeqSimModel(BertSeq2seqModel):
    """ErnieSeqSimģ��
    """
    @model_distributed(find_unused_parameters=True, distributed=IS_DISTRIBUTED)
    def init_model(self, model_dir, tokenizer, keep_tokens, pool_out_size=None):
        """��ʼ������
        """
        ernie_model = BertForSeqSim.from_pretrained(
                model_dir,
                vocab_size=tokenizer.vocab_size,
                keep_tokens=keep_tokens,
                pool_out_size=pool_out_size,
                )
        return ernie_model


class ErnieSeqSimRunner(object):
    """SeqSim��
    """
    def __init__(self, config_path, uniqid=None):
        self.config = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
        self.config.read(config_path)
        if uniqid is not None:
            if uniqid == "${time}":
                now_time = datetime.datetime.now()
                uniqid = datetime.datetime.strftime(datetime.datetime.now(), "%Y%m%d")
            # ���ӵ�ǰuniqid
            self.config.set("DEFAULT", "uniqid", uniqid)
        logging.info("uniqid: {}".format(self.config.get("DEFAULT", "uniqid")))

        check_dir(self.config["DEFAULT"]["output_dir"])
        check_dir(self.config["DEFAULT"]["data_dir"])
        check_dir(self.config["DEFAULT"]["model_dir"])

        self.run_config = self.config["RUN"]
        self.data_config = self.config["DATA"]
        self.model_config = self.config["MODEL_PATH"]

        cuda_visible_devices = self.run_config.get("cuda_visible_devices", None)
        if cuda_visible_devices is not None:
            os.environ["CUDA_VISIBLE_DEVICES"] = cuda_visible_devices
            logging.info("set cuda_visible_devices : {}".format(cuda_visible_devices))

        self.tokenizer, self.keep_tokens = BertTokenizer.load(self.model_config["tokenizer"], simplified=True)
        self.model = ErnieSeqSimModel(
                model_dir=self.model_config["pretrained_model_path"],
                tokenizer=self.tokenizer,
                keep_tokens=self.keep_tokens,
                pool_out_size=self.config["ERNIE"].getint("pool_out_size")
                )
        logging.info("model at device : {}".format(self.model.device))

    def run(self):
        """ִ�����
        """
        if self.run_config.getboolean("train"):
            self.train()

        if self.run_config.getboolean("gen_sim_text"):
            self.gen_sim_text()

        if self.run_config.getboolean("gen_text_vec"):
            self.gen_text_vec()

        if self.run_config.getboolean("get_similiar_text"):
            self.get_similiar_text()

        if self.run_config.getboolean("es_get_sim_text"):
            self.es_get_sim_text()

    def train(self):
        """ѵ��
        """
        ernie_config = self.config["ERNIE"]

        train_dataloader, test_dataloader = self.gen_dataloader(
                self.data_config["train_data_path"],
                is_infer=False, max_num=self.data_config.getint("max_num"))

        check_dir(self.model_config["ernie_seqsim_dir"])

        run_config = {
                "model_save_path": self.model_config["ernie_model"],
                "best_model_save_path": self.model_config["ernie_model_best"],
                "epochs": ernie_config.getint("epoch"),
                "print_step": ernie_config.getint("print_step"),
                "learning_rate": ernie_config.getfloat("learning_rate"),
                "load_best_model": ernie_config.getboolean("load_best_model"),
                }

        best_loss = self.model.train(train_dataloader, test_dataloader, **run_config)

        logging.info("best_loss = {}.".format(best_loss))

    def gen_sim_text(self):
        """���������ı�
        """
        if IS_DISTRIBUTED and LOCAL_RANK != 0:
            return
        # ======================== ���ش����������������ı� ==========================
        _, infer_data_list = self.gen_dataloader(
                self.data_config["eval_data_path"],
                is_infer=True, max_num=self.data_config.getint("max_num"))

        seq_config = self.config["SEQ"]
        logging.info("seg config: {}".format(seq_config))

        self.model.load_model(self.model_config["ernie_model_best"])

        #np.random.shuffle(infer_data_list)

        for text, _ in infer_data_list[:20]:
            start_time = time.time()
            logging.info("ori_text: {}".format(text))
            generate_list = self.model.generate(
                    text,
                    out_max_length=seq_config.getint("out_max_length"),
                    beam_size=seq_config.getint("beam_size"),
                    beam_group=seq_config.getint("beam_group"),
                    repeat_penalty=seq_config.getfloat("repeat_penalty"),
                    diverse_penalty=seq_config.getfloat("diverse_penalty"),
                    diverse_step=seq_config.getint("diverse_step"),
                    random_step=seq_config.getint("random_step"),
                    top_k=seq_config.getint("top_k"),
                    top_p=seq_config.getfloat("top_p"),
                    )
            for index, (text, score) in enumerate(generate_list):
                logging.info("gen_text #{}: {}".format(index, text))
            logging.info("cost time: {}s".format(time.time() - start_time))

    def gen_text_vec(self):
        """�����ı�����
        """
        # ======================== ���ش����������������ı� ==========================
        infer_dataloader, infer_data_list = self.gen_dataloader(
                self.data_config["infer_data_path"],
                is_infer=True, max_num=self.data_config.getint("max_num"))

        self.model.load_model(self.model_config["ernie_model_best"])

        infer_res = self.model.predict(infer_dataloader, gather_output_inds=[1])

        text_vec = infer_res[0]
        logging.info("text_vec shape: {}".format(text_vec.shape))

        # �����gpu��������֮�� ��cpu().numpy()֮�� �������Ľ��̲��ܽ��� ��Ȼ�Ῠ��
        # �����return���� text_vec_list֮ǰ �����Ῠס
        if IS_DISTRIBUTED and LOCAL_RANK != 0:
            return

        text_set = set()
        with codecs.open(self.config["ERNIE"]["text_vec_path"], "w", "gb18030") as wf:
            for cur_text, cur_text_vec in zip(infer_data_list, text_vec):
                cur_text = cur_text[0]
                if cur_text in text_set:
                    continue
                text_set.add(cur_text)
                cur_obj = json.dumps({
                    "text": cur_text,
                    "vec": cur_text_vec.tolist(),
                    })
                wf.write("{}\n".format(cur_obj))

    def es_get_sim_text(self):
        """es����
        """
        # ======================== ���ش������������ı� ==========================
        infer_dataloader, infer_data_list = self.gen_dataloader(
                self.data_config["eval_data_path"],
                is_infer=True, max_num=self.data_config.getint("max_num"))

        self.model.load_model(self.model_config["ernie_model_best"])

        infer_res = self.model.predict(infer_dataloader, gather_output_inds=[1])

        src_vec = infer_res[0]

        logging.info("src_vec shape: {}".format(src_vec.shape))

        # �����gpu��������֮�� ��cpu().numpy()֮�� �������Ľ��̲��ܽ��� ��Ȼ�Ῠ��
        # �����return���� text_vec_list֮ǰ �����Ῠס
        if IS_DISTRIBUTED and LOCAL_RANK != 0:
            return

        # ============================ ����ES�ı������� ============================
        es_config = self.config["ES"]
        es_client = EsClient(
                host=es_config["host"],
                index=es_config["index"],
                user=es_config["user"],
                password=es_config["password"],
                )

        start_time = time.time()
        with codecs.open(es_config["es_sim_text_res_path"], "w", "gb18030") as wf:
            for cur_vec, cur_text in zip(src_vec, infer_data_list):
                cur_text = cur_text[0]
                cur_es_res = es_client.hnsw_search(cur_vec.tolist(), num=100)
                wf.write("ori text: {}\n".format(cur_text))
                for index, (cur_sim_text, cur_sim_score) in enumerate(cur_es_res):
                    wf.write("es_sim_text #{}, score {}: {}\n".format(\
                            index, cur_sim_score, cur_sim_text))
                wf.write("=" * 150 + "\n")
        logging.info("es search sim text time: {}s".format(time.time() - start_time))

    def get_similiar_text(self):
        """��ȡ�����ı�
        """
        # ======================== ���ش������������ı� ==========================
        infer_dataloader, infer_data_list = self.gen_dataloader(
                self.data_config["sim_data_path"],
                is_infer=True, max_num=self.data_config.getint("max_num"))

        self.model.load_model(self.model_config["ernie_model_best"])

        infer_res = self.model.predict(infer_dataloader, gather_output_inds=[1])

        src_vec = infer_res[0]

        logging.info("src_vec shape: {}".format(src_vec.shape))

        # �����gpu��������֮�� ��cpu().numpy()֮�� �������Ľ��̲��ܽ��� ��Ȼ�Ῠ��
        # �����return���� text_vec_list֮ǰ �����Ῠס
        if IS_DISTRIBUTED and LOCAL_RANK != 0:
            return

        # ��һ��
        start_time = time.time()
        normalize_L2(src_vec)
        logging.info("normalize time: {}s".format(time.time() - start_time))

        # ============================ �����ı������� ============================
        text_vec, text_list = self.load_text_vec_database(self.config["ERNIE"]["text_vec_path"])
        logging.info("text_vec shape: {}".format(text_vec.shape))
        logging.info("text_list size: {}".format(len(text_list)))

        _, vec_dim = text_vec.shape

        # ��һ��
        start_time = time.time()
        normalize_L2(text_vec)
        logging.info("normalize time: {}s".format(time.time() - start_time))

        start_time = time.time()
        index = faiss.IndexFlatIP(vec_dim)
        logging.info("index flatip time: {}s".format(time.time() - start_time))

        start_time = time.time()
        index.add(text_vec)
        logging.info("add time: {}s".format(time.time() - start_time))

        # ============================ ���������ı� ==============================
        start_time = time.time()
        dis_matrix, ind_matrix = index.search(src_vec, self.config["SIM"].getint("topk"))
        logging.info("search time: {}s".format(time.time() - start_time))

        start_time = time.time()
        src_num, tar_num = ind_matrix.shape
        with codecs.open(self.config["SIM"]["similiar_text_res_path"], "w", "gb18030") as wf:
            for src_ind, sim_inds in enumerate(ind_matrix):
                wf.write("ori text: {}\n".format(infer_data_list[src_ind]))
                for index, cur_sim_ind in enumerate(sim_inds):
                    wf.write("sim_text #{}, similarity {}: {}\n".format(\
                            index, dis_matrix[src_ind][index], text_list[cur_sim_ind]))
                wf.write("=" * 150 + "\n")
        logging.info("record time: {}s".format(time.time() - start_time))

    def load_text_vec_database(self, data_path):
        """�����ı������ļ�
        """
        text_list = list()
        text_vec = list()
        with codecs.open(data_path, "r", "utf-8") as rf:
            for line in rf:
                cur_obj = json.loads(line.strip("\n"))
                text_list.append(cur_obj["text"])
                text_vec.append(np.array(cur_obj["vec"]).reshape((1, -1)))
        text_vec = np.concatenate(text_vec, axis=0).astype(np.float32)
        logging.info("text_vec dtype: {}".format(text_vec.dtype))
        return text_vec, text_list

    def gen_dataloader(self, data_path, is_infer=False, max_num=None):
        """����data_loader
        """
        batch_size = self.data_config.getint("batch_size")
        if is_infer:
            infer_dataset, infer_data_list = self.get_infer_dataset(
                    data_path,
                    max_num,
                    )
            infer_dataloader = get_dataloader(
                    infer_dataset,
                    collate_fn=bert_infer_collate_fn,
                    batch_size=batch_size,
                    distributed=IS_DISTRIBUTED,
                    shuffle=False,
                    )
            return infer_dataloader, infer_data_list
        else:
            train_dataset, test_dataset = self.get_train_dataset(
                    data_path,
                    max_num,
                    )
            if IS_DISTRIBUTED:
                train_dataloader = get_dataloader(
                        train_dataset,
                        collate_fn=bert_collate_fn,
                        batch_size=batch_size,
                        distributed=True,
                        sampler=SeqSimDistributedSampler(train_dataset, shuffle=True),
                        )

                test_dataloader = get_dataloader(
                        test_dataset,
                        collate_fn=bert_collate_fn,
                        batch_size=batch_size,
                        distributed=True,
                        sampler=SeqSimDistributedSampler(test_dataset, shuffle=False),
                        )
            else:
                train_dataloader = get_dataloader(
                        train_dataset,
                        shuffle=True,
                        collate_fn=bert_collate_fn,
                        batch_size=batch_size,
                        distributed=False,
                        )

                test_dataloader = get_dataloader(
                        test_dataset,
                        shuffle=False,
                        collate_fn=bert_collate_fn,
                        batch_size=batch_size,
                        distributed=False,
                        )
            return train_dataloader, test_dataloader

    def get_train_dataset(self, data_dir, max_num=None):
        """��ȡѵ�����ݼ�
        """
        def process_line(line):
            """�д�������
            """
            parts = line.strip("\n").split("\t")
            text_list = list(set(parts[1].split("\x01")))
            if len(text_list) < 2:
                return None
            # ������������
            pair_list = list()
            for cur_text_a, cur_text_b in combinations(text_list, 2):
                pair_list.append((cur_text_a, cur_text_b))
                #if len(pair_list) >= 4:
                #    break
            return pair_list
            # ֻȡһ�����
            #np.random.shuffle(text_list)
            #text_a, text_b = text_list[:2]
            #return [(text_a, text_b)]

        def encode_data_list(cur_data_list):
            """����data
            """
            text_list = list()
            encode_list = list()
            def add_sim_pair(text_a, text_b, label_id):
                """���������ı���
                """
                cur_token_ids, cur_token_type_ids = \
                        self.tokenizer.encode(text_a, text_b)
                encode_list.append((
                    cur_token_ids,
                    cur_token_type_ids,
                    label_id))
                text_list.append((
                    text_a,
                    text_b,
                    label_id))

            for cur_data in cur_data_list:
                text_a, text_b, label_id = cur_data
                add_sim_pair(text_a, text_b, label_id)
                add_sim_pair(text_b, text_a, label_id)

            return text_list, encode_list

        data_list = list()
        for index, cur_res in enumerate(\
                get_data(data_dir, read_func=process_line)):
            if  cur_res is None:
                continue
            if max_num is not None and index >= max_num:
                break
            for text_a, text_b in cur_res:
                data_list.append((text_a, text_b, index))

        train_data_list, test_data_list= train_test_split(
                data_list,
                test_size=self.data_config.getfloat("test_ratio"),
                random_state=self.data_config.getint("random_state"),
                shuffle=self.data_config.getboolean("is_shuffle"),
                )
        train_text_list, train_encoded_data = encode_data_list(train_data_list)
        test_text_list, test_encoded_data = encode_data_list(test_data_list)

        logging.info("train num = {}".format(len(train_text_list)))
        logging.info("test num = {}".format(len(test_text_list)))

        logging.info(u"��������")
        for index, (text, (token_ids, _, label_id)) in enumerate(zip(
                train_text_list[:self.data_config.getint("example_num")],
                train_encoded_data[:self.data_config.getint("example_num")],
                )):
            logging.info("example #{}:".format(index))
            logging.info("label_id: {}".format(label_id))
            logging.info("text: {}".format(text))
            logging.info("token_ids: {}".format(token_ids))

        train_dataset = ErnieDataset(train_encoded_data)
        test_dataset = ErnieDataset(test_encoded_data)

        return train_dataset, test_dataset


    def get_infer_dataset(self, data_dir, max_num=None):
        """����infer���ݼ�
        """
        def process_line(line):
            """�д�������
            """
            parts = line.strip("\n").split("\t")
            # ����ȫ��
            return parts[1].split("\x01")

            # ����ǰ����
            #return parts[1].split("\x01")[:2]

            # �����������
            #text_list = list(set(parts[1].split("\x01")))
            #np.random.shuffle(text_list)
            #return text_list[:2]

        def encode_data_list(cur_data_list):
            """����data
            """
            text_list = list()
            encode_list = list()

            for index, text in enumerate(cur_data_list):
                cur_token_ids, cur_token_type_ids = \
                        self.tokenizer.encode(text)
                encode_list.append((
                    cur_token_ids,
                    cur_token_type_ids,
                    index,
                    ))
                text_list.append((
                    text,
                    index,
                    ))

            return text_list, encode_list

        infer_data_list = list()
        for index, res_list in enumerate(\
                get_data(data_dir, read_func=process_line)):
            if max_num is not None and \
                    len(infer_data_list) >= max_num:
                break
            infer_data_list.extend(res_list)

        infer_data_list, infer_encoded_data = \
                encode_data_list(infer_data_list)

        logging.info("infer num = {}".format(len(infer_data_list)))

        logging.info(u"��������")
        for index, (text, (token_ids, _, _)) in enumerate(zip(
                infer_data_list[:self.data_config.getint("example_num")],
                infer_encoded_data[:self.data_config.getint("example_num")],
                )):
            logging.info("example #{}:".format(index))
            logging.info("text: {}".format(text))
            logging.info("token_ids: {}".format(token_ids))

        infer_dataset = ErnieDataset(infer_encoded_data)

        return infer_dataset, infer_data_list


if __name__ == "__main__":
    if IS_DISTRIBUTED:
        config_path = sys.argv[2]
        uniqid = sys.argv[3] if len(sys.argv) > 3 else None
    else:
        config_path = sys.argv[1]
        uniqid = sys.argv[2] if len(sys.argv) > 2 else None

    logging.info("args: {}".format(sys.argv))
    runner = ErnieSeqSimRunner(config_path, uniqid)
    runner.run()
