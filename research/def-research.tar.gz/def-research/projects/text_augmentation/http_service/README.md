# 相似文本检索服务 
利用训练好的文本向量模型，建立相似文本检索、生成服务端，可如客户端一样发送请求获得相似文本。

## 文件结构
```
root: 根目录
├── bin: 脚本目录
│   └── start_server.sh: 启动服务的脚本
├── ernie_seqsim_v2.0: 文本向量模型目录，可用软链
│   └── ernie_seqsim_best: 模型参数数据
├── log: 日志目录，运行脚本启动服务后生成
│   └── sim_text_service.log: 日志文本，运行脚本启动服务后生成
├── pretrained_models: 预训练模型目录，可用软链
│   └── ernie-1.0: ernie-1.0预训练模型数据
│       ├── config.json: 配置文件
│       ├── pytorch_model.bin: 模型参数数据
│       └── vocab.txt: 词典
└── src: 程序目录
    ├── sim_text_model.py: 加载模型，完成相似样本检索和生成功能的程序
    ├── sim_text_retrieve_client.py: 检索相似文本的客户端
    └── sim_text_retrieve_service.py: 检索相似文本的服务端
```

## 运行手册

### 环境准备
1. python3
2. pytorch
3. 预训练文件pytorch版本: ernie-1.0
4. 模型数据: ernie_seqsim_v2

### 启动服务
1. 查看是否有以前启动的服务
    
    `ps aux|grep "python ./src/sim_text_retrieve_service.py 8890"|grep -v "grep"`
2. 如果有以前启动的服务，将这些服务杀掉

    `kill -9 ${PID}`    
3. 确定服务的端口`${PORT}`
4. 在根目录启动服务

    `sh bin/start_server.sh ${PORT}`

   如果端口已被占用，可更换端口或者kill掉占用端口的PID（最好更换端口号，除非确认该PID不重要，可以被kill）。

### 客户端发送请求
参考客户端`sim_text_retrieve_client.py`的代码

可发送两种请求，根据请求的目标路径区分：
#### 1. 相似样本生成服务

    请求url: http://10.255.121.18:8890/generate/
    请求的参数为：
        {
            "text_list": 必需，源文本列表,
            "beam_size": int，可选，beam_search大小，默认为4
            "out_max_length": int，可选，生成样本最大长度，默认为100,
            "repeat_penalty": int，可选，同beam生成重复字符的惩罚，默认为2,
            "beam_group": int，可选，分组beam_search的大小，默认为5,
            "diverse_step": int，可选，各组间进行重复惩罚的周期，默认为5,
            "diverse_penalty": float，可选，各组间输出字符重复的惩罚，默认为0.7,
            "random_step": int，可选，各beam随机当前输出的周期，默认为1,
            "top_k": int，可选，随机时考虑概率top_k的字符，默认为200,
            "top_p": float，可选，随机时考虑概率排序后累加到top_p的所涉及的字符，默认为0.7,
            "progress": bool，可选，True则展示当前进行到第几个text，默认为False,
        } 
#### 2. 相似样本检索服务
    
    请求url: http://10.255.121.18:8890/retrieve/
    请求的参数为：
        {
            "text_list": 必需，源文本列表,
            "topk": int，可选，检索余弦相似度topk的样本，默认为20,
            "display": bool，可选，True则展示检索结果，默认为False,
            "progress": bool，可选，True则展示当前进行到第几个text，默认为False,
        } 

#### 注意

为防止单次服务耗时过程，两类服务都限制了"text_list"的大小以使单次服务耗时在1min左右。
1. **检索服务速度较快，平均耗时0.08s/条，限制列表最大为1184。**
2. **生成服务速度慢，平均耗时2.7s/条，限制列表最大为32。**
 
<font color="#dd0000">**生成服务速度极慢，使用时先评估耗时是否承受，是否会影响检索请求的响应。**</font><br />

### 解析请求结果
结果为json字符串，用`json.loads()`可解析为字典，各字段如下

    {
        "status": xxx,                               # int，返回状态，0则成功，1则失败
        "error_info": xxx,                           # int，失败时保存失败信息，成功时为None
        "result": [                                  # list，成功时保存结果列表
            [
                ori_text_1,                                # str， 原样本1
                [
                    (sim_text_1, sim_score_1),           # tuple，第1个相似样本信息，包括样本文本和相似度
                    (sim_text_2, sim_score_2),           # tuple，第2个相似样本信息，包括样本文本和相似度
                    ...
                    (sim_text_n, sim_score_n),           # tuple，第n个相似样本信息，包括样本文本和相似度
                ]
            ], [
                ori_text_2,                                # str， 原样本2
                [
                    (sim_text_1, sim_score_1),           # tuple，第1个相似样本信息，包括样本文本和相似度
                    (sim_text_2, sim_score_2),           # tuple，第2个相似样本信息，包括样本文本和相似度
                    ...
                    (sim_text_n, sim_score_n),           # tuple，第n个相似样本信息，包括样本文本和相似度
                ]
            ], ...
        ]
    }
