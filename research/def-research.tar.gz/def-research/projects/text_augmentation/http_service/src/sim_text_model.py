#!/usr/bin/env python3
# -*- coding:gb18030 -*-
"""
File  :   sim_text_model.py
Author:   zhanghao55@baidu.com
Date  :   21/01/29 15:37:03
Desc  :   
"""

import os
import sys
import codecs
import json
import logging
import time
import torch
from tqdm import tqdm

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../lib/" % _cur_dir)
from base_model import BertSeq2seqModel, model_distributed
from bert import BertForSeqSim
from es_client import EsClient
from utils import (
        check_dir,
        bert_infer_collate_fn,
        get_dataloader,
        ErnieDataset,
        )

sys.path.append("%s/../../../../" % _cur_dir)

from lib.common.logger import init_log
from lib.common.bert_tokenizer import BertTokenizer

IS_DISTRIBUTED = False
try:
    torch.distributed.init_process_group(backend="nccl")
    LOCAL_RANK = torch.distributed.get_rank()
    IS_DISTRIBUTED = True

    logging_level = logging.INFO if LOCAL_RANK == 0 else logging.WARNING
    init_log(stream_level=logging_level)
except ValueError as e:
    init_log(stream_level=logging.INFO)

logging.info("is_distributed: {}".format(IS_DISTRIBUTED))


class ErnieSeqSimModel(BertSeq2seqModel):
    """ErnieSeqSimģ��
    """
    @model_distributed(find_unused_parameters=True, distributed=IS_DISTRIBUTED)
    def init_model(self, model_dir, tokenizer, keep_tokens, pool_out_size=None):
        """��ʼ������
        """
        ernie_model = BertForSeqSim.from_pretrained(
                model_dir,
                vocab_size=tokenizer.vocab_size,
                keep_tokens=keep_tokens,
                pool_out_size=pool_out_size,
                )
        return ernie_model


class SimTextModel(object):

    def __init__(self, vocab_path, pretrained_model_path, best_model_path, pool_out_size=128):
        self.tokenizer, self.keep_tokens = BertTokenizer.load(vocab_path, simplified=True)
        self.model = ErnieSeqSimModel(
                model_dir=pretrained_model_path,
                tokenizer=self.tokenizer,
                keep_tokens=self.keep_tokens,
                pool_out_size=128,
                )
        logging.info("model at device : {}".format(self.model.device))
        self.model.load_model(best_model_path)

        self.es_client = EsClient(
                host="http://10.138.71.8:8200/",
                index="vector_search_v2",
                user="superuser",
                password="Fkrd123",
                )

    def es_search(self, text_list, topk=20, sim_res_path=None, display=False, progress=True):
        start_time = time.time()
        cur_dataloader = self.gen_dataloader(text_list)
        logging.info("gen dataloader time: {}s".format(time.time() - start_time))

        start_time = time.time()
        text_vec = self.model.predict(cur_dataloader, gather_output_inds=[1])[0]
        logging.info("gen text vec time: {}s".format(time.time() - start_time))
        #logging.info("text_vec shape: {}".format(text_vec.shape))

        if IS_DISTRIBUTED and LOCAL_RANK != 0:
            return

        def get_sim_text():
            if progress:
                pbar = tqdm(total=len(text_list), desc="searching")
            for cur_vec, cur_text in zip(text_vec, text_list):
                cur_es_res = self.es_client.hnsw_search(cur_vec.tolist(), num=topk)
                if progress:
                    pbar.update(1)
                yield cur_es_res
            if progress:
                pbar.close()

        start_time = time.time()
        sim_res_list = list(zip(text_list, get_sim_text()))
        logging.info("es search sim text time: {}s".format(time.time() - start_time))

        if sim_res_path is None:
            if display:
                for cur_text, cur_es_res in sim_res_list:
                    logging.info("ori text: {}".format(cur_text))
                    for index, (cur_sim_text, cur_sim_score) in enumerate(cur_es_res):
                        logging.info("es_sim_text #{}, score {}: {}".format(\
                                index, cur_sim_score, cur_sim_text))
                    logging.info("=" * 150)
        else:
            with codecs.open(sim_res_path, "w", "gb18030") as wf, \
                    codecs.open(sim_res_path + "_json", "w", "gb18030") as wf_json:
                for cur_text, cur_es_res in sim_res_list:
                    json_obj = json.dumps({
                        "ori_text": cur_text,
                        "sim_texts": cur_es_res,
                        })
                    wf_json.write(json_obj + "\n")
                    wf.write("ori text: {}\n".format(cur_text))
                    for index, (cur_sim_text, cur_sim_score) in enumerate(cur_es_res):
                        wf.write("es_sim_text #{}, score {}: {}\n".format(\
                                index, cur_sim_score, cur_sim_text))
                    wf.write("=" * 150 + "\n")
        return sim_res_list

    def generate(self, text_list,
            out_max_length=100, beam_size=4, beam_group=1,
            repeat_penalty=5, diverse_step=5, diverse_penalty=5,
            random_step=1, top_k=0, top_p=1.0, progress=True):

        # ֻ����������
        if IS_DISTRIBUTED and LOCAL_RANK != 0:
            return

        start_time = time.time()
        if progress:
            pbar = tqdm(total=len(text_list), desc="searching")

        for cur_text in text_list:
            cur_generate_res = self.model.generate(
                    cur_text,
                    out_max_length=out_max_length,
                    beam_size=beam_size,
                    beam_group=beam_group,
                    repeat_penalty=repeat_penalty,
                    diverse_step=diverse_step,
                    diverse_penalty=diverse_penalty,
                    random_step=random_step,
                    top_k=top_k,
                    top_p=top_p,
                    )
            if progress:
                pbar.update(1)
            logging.debug("cur_text: {}".format(cur_text))
            logging.debug("cur_generate_res: {}".format(cur_generate_res))
            yield cur_text, cur_generate_res

        if progress:
            pbar.close()
        logging.info("sim text generate time: {}s".format(time.time() - start_time))

    def gen_dataloader(self, text_list, batch_size=32, max_num=None, example_num=5):
        text_id_list = [self.tokenizer.encode(x) for x in text_list]
        data_list = list(zip(*zip(*text_id_list), range(len(text_id_list))))

        logging.debug(u"��������")
        for index, (text, (token_ids, _, _)) in enumerate(zip(
                text_list[:example_num],
                data_list[:example_num],
                )):
            logging.debug("example #{}:".format(index))
            logging.debug("text: {}".format(text))
            logging.debug("token_ids: {}".format(token_ids))

        res_dataloader = get_dataloader(
                ErnieDataset(data_list),
                collate_fn=bert_infer_collate_fn,
                batch_size=batch_size,
                distributed=IS_DISTRIBUTED,
                shuffle=False,
                )
        return res_dataloader
