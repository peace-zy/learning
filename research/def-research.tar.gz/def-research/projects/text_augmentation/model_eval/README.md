# 相似文本效果评估
以低俗数据集为例，评估相似文本对模型准召效果的影响。
模型选择textcnn，评估过程中模型结构不变。


### 文件目录
```
root
├── data：数据目录
│   ├── class_id
│   ├── class_id_biclass
│   ├── eval_data：评估数据集
│   │   ├── shrink_eval_data：多分类
│   │   └── shrink_eval_data_biclass：二分类
│   ├── sim_data：扩充数据集
│   │   ├── shrink_sim_data_with_label：多分类
│   │   └── shrink_sim_data_with_label：二分类
│   ├── total_data：原始数据集
│   │   ├── total_sim_text_refine_label：原始扩充数据集
│   │   └── total_train_data：原始训练数据
│   └── train_data：训练数据集
│       ├── shrink_train_data：多分类
│       └── shrink_train_data_biclass：二分类
├── ernie_seqsim_v2.0：训练好的模型目录，可建软链
│   └── ernie_seqsim_best：模型参数文件
├── pretrained_models：预训练模型目录，可建软链（这里只是借用了vocab文件）
│   └── ernie-1.0：ernie预训练数据目录（pytorch版）
│       └── vocab.txt：字典
├── README.md：说明
└── src：程序文件
    ├── config.py：评估配置文件
    ├── model_eval.py：评估程序
    └── sample_small_train_data.py：从原始数据集生成训练数据集
```

### 运行手册
#### 环境准备
1. python3
2. pytorch
3. 预训练文件pytorch版本: ernie-1.0

#### 确定评估配置
在[src/config.py](https://console.cloud.baidu-int.com/devops/icode/repos/baidu/fengkong/def-research/blob/master:projects/text_augmentation/model_eval/src/config.py)配置

通过`EVAL_MODE`设置实验评估类型：
1. `data`: 变化样本比例进行评估
2. `config`: 变化相似样本扩充配置进行评估
3. `all`: 两类均进行

两类评估是两个config_list，但其实config可配置的参数都是相同的：
1. `is_biclass`：bool，true则采用二分类数据，否则是多分类数据
2. `refine_label`：bool，true则扩充的相似样本采用标注后的标签，否则各相似样本的标签与原样本一致
3. `topk_sim`：int，扩充时各样本扩充`${topk_sim}`条相似样本。不设置该参数，则不进行扩充。
4. `each`：int，训练数据集进行抽样，有风险样本按类别各抽`${each}`条
5. `other`：int，训练数据集进行抽样，无风险样本抽`${other}`条

可根据自己要求在配置文件中修改评估配置

#### 运行脚本
在root下执行命令

`nohup python src/model_eval.py &`