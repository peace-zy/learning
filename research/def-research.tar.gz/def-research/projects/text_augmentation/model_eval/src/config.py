#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   config.py
Author:   zhanghao55@baidu.com
Date  :   21/03/01 11:02:52
Desc  :   
"""

# all��data��config
EVAL_MODE = "all"


# ========================= ͨ������ ===================================

# ͨ������
common_config_dict = {
        "vocab_path": "pretrained_models/ernie-1.0/vocab.txt",
        "pretrained_model_path": "pretrained_models/ernie-1.0/",
        "train_data_prefix": "data/train_data/shrink_train_data",
        "sim_data_prefix": "data/sim_data/shrink_sim_data_with_label",
        "eval_data_prefix": "data/eval_data/shrink_eval_data",
        "label_id_prefix": "data/class_id",
        "model_save_prefix": "./model/textcnn",
        "best_model_save_prefix": "./model/best_textcnn",
        "test_num": 2,
        "test_record_path": "./output/test_record.txt",
        "run_config": {
            "epochs": 5,
            "print_step": 200,
            "load_best_model": False,
            "scheduler_mode": "cosine",
            #"scheduler_mode": None,
            "warm_up": 0.1,
            #"swa": False,
            #"swa_start_epoch": 15,
            #"swa_anneal_epoch": 3,
            "learning_rate": 5e-3,
            #"swa_lr": 1e-3,
            #"adversarial_training": False,
            }
        }


# ========================= ʵ������ ===================================
diff_config_list = list()

# ��������
# ԭѵ������
diff_config_list.append({
    "is_biclass": False,
    "refine_label": False,
    })

# �������� δ�޸ı�ǩ
diff_config_list.append({
    "is_biclass": False,
    "refine_label": False,
    "topk_sim": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20],
    })

# �������� �޸ı�ǩ
diff_config_list.append({
    "is_biclass": False,
    "refine_label": True,
    "topk_sim": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20],
    })

# ������
# ԭѵ������
diff_config_list.append({
    "is_biclass": True,
    "refine_label": False,
    })

# �������� δ�޸ı�ǩ
diff_config_list.append({
    "is_biclass": True,
    "refine_label": False,
    "topk_sim": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20],
    })

# �������� �޸ı�ǩ
diff_config_list.append({
    "is_biclass": True,
    "refine_label": True,
    "topk_sim": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20],
    })

# ������
#diff_config_list = [{
#    "is_biclass": False,
#    "refine_label": False,
#    }, {
#    "is_biclass": True,
#    "refine_label": True,
#    "topk_sim": [0, 5, 10, 20],
#    }]

diff_data_list = list()
# ԭѵ������
diff_data_list.append({
    "each": 50,
    "other": 2000,
    "is_biclass": False,
    "refine_label": True,
    "topk_sim": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20],
    })

# ��������10 �޷�������100
diff_data_list.append({
    "each": 10,
    "other": 100,
    "is_biclass": False,
    "refine_label": True,
    "topk_sim": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20],
    })

# ��������10 �޷�������300
diff_data_list.append({
    "each": 10,
    "other": 300,
    "is_biclass": False,
    "refine_label": True,
    "topk_sim": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20],
    })

# ��������10 �޷�������500
diff_data_list.append({
    "each": 10,
    "other": 500,
    "is_biclass": False,
    "refine_label": True,
    "topk_sim": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20],
    })

# ��������30 �޷�������300
diff_data_list.append({
    "each": 30,
    "other": 300,
    "is_biclass": False,
    "refine_label": True,
    "topk_sim": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20],
    })

# ��������30 �޷�������600
diff_data_list.append({
    "each": 30,
    "other": 600,
    "is_biclass": False,
    "refine_label": True,
    "topk_sim": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20],
    })

# ��������30 �޷�������1200
diff_data_list.append({
    "each": 30,
    "other": 1200,
    "is_biclass": False,
    "refine_label": True,
    "topk_sim": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20],
    })

# ������
#diff_data_list=[{
#    "each": 30,
#    "other": 1200,
#    "is_biclass": False,
#    "refine_label": True,
#    "topk_sim": [0, 5, 10, 20],
#    }]

if EVAL_MODE == "all":
    run_config_list = diff_config_list + diff_data_list
elif EVAL_MODE == "data":
    run_config_list = diff_data_list
elif EVAL_MODE == "config":
    run_config_list = diff_config_list
else:
    raise ValueError("unknown eval mode: {}".format(EVAL_MODE))
