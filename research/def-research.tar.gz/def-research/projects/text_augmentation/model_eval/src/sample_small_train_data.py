#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   sample_small_train_data.py
Author:   zhanghao55@baidu.com
Date  :   21/02/24 10:15:56
Desc  :   
"""

import os
import sys
import codecs
import logging

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../lib/" % _cur_dir)
from weighted_sampler import Sampler

sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.data_io import get_data
from lib.common.logger import init_log
init_log(stream_level=logging.INFO)


def main(total_data_dir, shrink_train_data_path, sample_num=50, sim_data_dir=None, shrink_sim_data_path=None):
    """�����
    """
    def process_line(line):
        """�д�������
        """
        parts = line.strip("\n").split("\t")
        label = parts[0]
        text = parts[1]
        return label, text

    total_data_iter = get_data(total_data_dir, read_func=process_line, header=True, encoding="utf-8")

    sampler_dict=dict()
    for cur_label, cur_text in total_data_iter:
        if cur_label not in sampler_dict:
            if cur_label == u"�޹�":
                sampler_dict[cur_label] = Sampler(sys.maxsize)
            else:
                sampler_dict[cur_label] = Sampler(sample_num)

        sampler_dict[cur_label].put(cur_text)

    # ��������sample_num���� �޹�����ȫ������
    label_sample_dict = {cur_label:cur_sampler.get_sample_list() for cur_label, cur_sampler in sampler_dict.items()}

    with codecs.open(shrink_train_data_path, "w", "utf-8") as wf:
        for cur_label, cur_sample_list in label_sample_dict.items():
            for cur_sample in cur_sample_list:
                wf.write("\t".join([
                    cur_label,
                    cur_sample
                    ]) + "\n")

    if sim_data_dir is not None:
        sim_text_dict = load_sim_data(sim_data_dir, 20)
        with codecs.open(shrink_sim_data_path, "w", "utf-8") as wf:
            for cur_label, cur_sample_list in label_sample_dict.items():
                if cur_label == u"�޹�":
                    continue
                for cur_text in cur_sample_list:
                    if cur_text not in sim_text_dict:
                        logging.warning("not find text in sim_dict: {}".format(cur_text))
                        continue
                    for sim_text_info in sim_text_dict[cur_text]:
                        cur_sim_text, cur_label, cur_modify_flag, cur_sim_score = sim_text_info
                        wf.write("\t".join([
                            cur_label,
                            cur_sim_text,
                            cur_modify_flag,
                            cur_sim_score,
                            cur_text]) + "\n")


def load_sim_data(sim_data_dir, topk=5):
    """���������ı�
    """
    def process_line(line):
        """�д�������
        """
        parts = line.strip("\n").split("\t")
        label = parts[0]
        sim_text = parts[1]
        ori_text = parts[2]
        modify_flag = parts[3]
        sim_score = parts[4]
        return ori_text, (sim_text, label, modify_flag, sim_score)

    sim_data_list = get_data(sim_data_dir, read_func=process_line, encoding="utf-8")

    processed_list = list()
    pre_ori_text = None
    pre_list = None
    for cur_ori_text, cur_sim_info in sim_data_list:
        if cur_ori_text != pre_ori_text:
            if pre_ori_text is not None:
                processed_list.append((pre_ori_text, pre_list))
            pre_ori_text = cur_ori_text
            pre_list = list()
        if len(pre_list) < topk:
            pre_list.append(cur_sim_info)

    return {k: v for k, v in processed_list}


if __name__ == "__main__":
    # ��ԭ���ݼ��зֳ�train��eval���ݼ�
    # TODO ����ֻ��train, eval��Ҫ�Լ���train��û�е��ó���
    main(
        total_data_dir="data/origin_train_data/origin_train_data",
        shrink_train_data_path="output/shrink_train_data",
        sim_data_dir="data/sim_data/vec_sim_text_refine_label.txt",
        shrink_sim_data_path="output/shrink_sim_data_with_label.txt",
       )

    # ����Ҫ�Լ�sample��each_m_other_n�������� model_eval���Զ�sample
    #main(
    #    total_data_dir="data/small_data/shrink_train_data",
    #    shrink_train_data_path="data/total_data/shrink_train_data_10",
    #    sample_num=10,
    #    )

    #main(
    #    total_data_dir="data/small_data/shrink_train_data",
    #    shrink_train_data_path="data/total_data/shrink_train_data_30",
    #    sample_num=30,
    #    )
