#!/usr/bin/env python3
# -*- coding:gb18030 -*-
"""
File  :   model_eval.py
Author:   zhanghao55@baidu.com
Date  :   21/02/08 16:52:32
Desc  :   
"""

import os
import sys
import codecs
import json
import logging
import time
import torch

from sklearn.metrics import confusion_matrix

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../lib/" % _cur_dir)
from textcnn import TextCNNClassifier
from base_model import ClassificationModel, model_distributed
from utils import (
        check_dir,
        get_dataloader,
        ErnieDataset,
        create_dataset,
        common_collate_fn
        )

sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.bert_tokenizer import BertTokenizer
from lib.common.data_io import get_data
from lib.common.label_encoder import LabelEncoder
from lib.common.logger import init_log

IS_DISTRIBUTED = False
try:
    torch.distributed.init_process_group(backend="nccl")
    LOCAL_RANK = torch.distributed.get_rank()
    IS_DISTRIBUTED = True

    logging_level = logging.INFO if LOCAL_RANK == 0 else logging.WARNING
    init_log(stream_level=logging_level)
except ValueError as e:
    init_log(stream_level=logging.INFO)

logging.info("is_distributed: {}".format(IS_DISTRIBUTED))


class TextCNNClassificationModel(ClassificationModel):
    """textcnn�ķ���ģ��
    """
    @model_distributed(find_unused_parameters=True, distributed=IS_DISTRIBUTED)
    def init_model(self, **kwargs):
        """��ʼ������
        """
        model = TextCNNClassifier(**kwargs)
        return model


class Classifier(object):
    """����ģ�͵�ѵ������������
    """
    def __init__(self, label_id_path, vocab_path, pretrained_model_path, run_config):
        """��ʼ��
        """
        self.label_encoder = LabelEncoder(label_id_path, isFile=True)
        self.tokenizer, self.keep_tokens = BertTokenizer.load(vocab_path, simplified=True)

        self.textcnn_config = {
                "num_class": self.label_encoder.size(),
                "vocab_size": self.tokenizer.vocab_size,
                "emb_dim": 125,
                "num_filters": 64,
                "fc_hid_dim": 128,
                "num_channels": 1,
                "win_size_list": [3, 7],
                "is_sparse": False,
                }

        self.run_config = run_config
        self.model = TextCNNClassificationModel(**self.textcnn_config)

    def train(self, train_data_dir, each_num="all", other_num="all", eval_data_dir=None,
            sim_data_dir=None, refine_label=False, topk_sim=20,
            eval_res_path=None, batch_size=32):
        """ѵ��ģ��
        """

        sim_text_dict = None if sim_data_dir is None else self.load_sim_data(sim_data_dir, topk_sim)
        if sim_text_dict is not None:
            logging.info("sim_text_dict: {}".format(list(sim_text_dict.keys())[:10]))

        if eval_data_dir is None:
            train_dataset, eval_dataset = create_dataset(
                    train_data_dir,
                    self.tokenizer,
                    self.label_encoder,
                    each_num=each_num,
                    other_num=other_num,
                    sim_text_dict=sim_text_dict,
                    refine_label=refine_label,
                    test_size=0.15,
                    encoding="utf-8")
        else:
            train_dataset = create_dataset(
                    train_data_dir,
                    self.tokenizer,
                    self.label_encoder,
                    each_num=each_num,
                    other_num=other_num,
                    sim_text_dict=sim_text_dict,
                    refine_label=refine_label,
                    encoding="utf-8")

            eval_dataset = create_dataset(
                    eval_data_dir,
                    self.tokenizer,
                    self.label_encoder,
                    sim_text_dict=None,
                    encoding="utf-8")

        train_dataloader = get_dataloader(
                train_dataset,
                collate_fn=common_collate_fn,
                batch_size=batch_size,
                distributed=IS_DISTRIBUTED,
                shuffle=True,
                )

        eval_dataloader = get_dataloader(
                eval_dataset,
                collate_fn=common_collate_fn,
                batch_size=batch_size,
                distributed=IS_DISTRIBUTED,
                shuffle=False,
                )

        best_score = self.model.train(
                train_dataloader,
                eval_dataloader,
                label_encoder=self.label_encoder,
                **self.run_config)
        logging.info("best_score = {}.".format(best_score))

        # ��������ģ��
        self.model.load_model(self.run_config["best_model_save_path"])
        # ����Ч��
        precision, recall = self.eval(
                eval_dataloader,
                eval_res_path,
                print_step=self.run_config["print_step"],
                )

        return precision, recall

    def eval(self, eval_dataloader, eval_res_path=None, print_step=50):
        """����ģ��׼��
        """
        all_pred = list()
        all_label = list()
        cur_eval_step = 0
        start_time = time.time()
        loss_list = list()
        for cur_eval_batch in eval_dataloader:
            cur_eval_step += 1
            cur_data = cur_eval_batch[:-1]
            cur_label_ids = cur_eval_batch[-1]
            cur_logits = self.model.infer(*cur_data, labels=None)
            cur_pred = cur_logits.argmax(dim=-1)
            cur_label = cur_label_ids.detach()
            all_pred.append(cur_pred)
            all_label.append(cur_label)

            if cur_eval_step % print_step == 0:
                cost_time = time.time() - start_time
                speed = cur_eval_step / cost_time
                logging.info('eval step %d, total cost time = %.4fs, speed %.2f step/s' \
                        % (cur_eval_step, cost_time, speed))

        # pred��ģ��Ԥ��Ľ�� ģ������self.device�ϵ�
        all_pred = torch.cat(all_pred, dim=0)
        # label��ֱ�Ӵ�dataloader�õ����� ��û�з���self.device��
        all_label = torch.cat(all_label, dim=0).to(self.model.device)
        logging.debug("all pred shape: {}".format(all_pred.shape))
        logging.debug("all label shape: {}".format(all_label.shape))
        all_pred = all_pred.cpu().numpy()
        all_label = all_label.cpu().numpy()

        if eval_res_path is not None:
            with codecs.open(eval_res_path, "w", "utf-8") as wf:
                for cur_pred, cur_label in zip(all_pred, all_label):
                    cur_pred = self.label_encoder.inverse_transform(cur_pred)
                    cur_label = self.label_encoder.inverse_transform(cur_label)
                    wf.write("\t".join([cur_pred, cur_label]) + "\n")

        all_pred = [0 if x == 0 else 1 for x in all_pred]
        all_label = [0 if x == 0 else 1 for x in all_label]

        tn, fp, fn, tp = confusion_matrix(all_label, all_pred, labels=[0, 1]).ravel()
        acc = (tp + tn) / float(tn + fp + fn + tp)
        recall = tp / float(fn + tp)
        precision = tp / float(fp + tp)
        f_score = 2 / (1 / recall + 1 / precision)
        logging.info("acc = {:.4f}, recall = {:.4f}, precision = {:.4f}, f-score = {:.4f}".format(
            acc, recall, precision, f_score))

        return precision, recall

    def load_sim_data(self, sim_data_dir, topk_sim=5):
        """������������
        """
        def process_line(line):
            """�д�������
            """
            parts = line.strip("\n").split("\t")
            label = parts[0]
            sim_text = parts[1]
            sim_score = parts[2]
            ori_text = parts[3]
            return ori_text, (sim_text, label, sim_score)

        sim_data_list = get_data(sim_data_dir, read_func=process_line, encoding="utf-8")

        processed_list = list()
        pre_ori_text = None
        pre_list = None
        for cur_ori_text, cur_sim_info in sim_data_list:
            if cur_ori_text != pre_ori_text:
                if pre_ori_text is not None:
                    processed_list.append((pre_ori_text, pre_list))
                pre_ori_text = cur_ori_text
                pre_list = list()
            if len(pre_list) < topk_sim:
                pre_list.append(cur_sim_info)

        return {k: v for k, v in processed_list}


def model_eval():
    """���config�и���ʵ�����ý���ģ��׼�ٵ�����
    """
    import codecs

    from config import common_config_dict, run_config_list

    logging.info("common_config_dict : {}".format(common_config_dict))

    def train_once(
            cur_config_name,
            label_id_path,
            train_data_dir,
            each_num,
            other_num,
            eval_data_dir,
            sim_data_dir,
            refine_label,
            topk_sim=None,
            ):
        """����һ��ѵ��������׼��
        """
        model_save_path = "_".join([
            common_config_dict["model_save_prefix"],
            cur_config_name,
            ])

        best_model_save_path = "_".join([
            common_config_dict["best_model_save_prefix"],
            cur_config_name,
            ])

        cls = Classifier(
                label_id_path=label_id_path,
                vocab_path=common_config_dict["vocab_path"],
                pretrained_model_path=common_config_dict["pretrained_model_path"],
                run_config=dict(common_config_dict["run_config"], **{
                    "model_save_path": model_save_path,
                    "best_model_save_path": best_model_save_path,
                    }),
                )

        precision, recall = cls.train(
                train_data_dir=train_data_dir,
                each_num=each_num,
                other_num=other_num,
                eval_data_dir=eval_data_dir,
                sim_data_dir=sim_data_dir,
                refine_label=refine_label,
                topk_sim=topk_sim,
                )
        return precision, recall

    record_dict = dict()
    for cur_config in run_config_list:
        logging.info("cur config: {}".format(cur_config))

        # �����Ƿ��Ƕ�����
        is_biclass = cur_config.get("is_biclass", False)
        refine_label = cur_config.get("refine_label", True)
        each_num = cur_config.get("each", "all")
        other_num = cur_config.get("other", "all")
        topk_sim_list = cur_config.get("topk_sim", None)

        # ȷ�ϸ����׺
        # ��������׺
        class_postfix = "_biclass" if is_biclass else ""
        # ѵ�����ݳ�����׺
        data_sample_postfix = "_each_{}_other_{}".format(each_num, other_num)
        # ��ǩ������׺
        label_postfix = "_refine_label" if refine_label else "_origin_label"

        # ���ļ���ַ
        # label_id�ļ���ַ
        label_id_path = common_config_dict["label_id_prefix"] + class_postfix
        # ѵ�����ݵ�ַ
        train_data_dir = common_config_dict["train_data_prefix"] + class_postfix
        # ��֤���ݵ�ַ
        eval_data_dir = common_config_dict["eval_data_prefix"] + class_postfix
        # �������ݵ�ַ
        # ���cur_config��û��topk ������������
        sim_data_dir = None if topk_sim_list is None else common_config_dict["sim_data_prefix"] + class_postfix

        if topk_sim_list is None:
            cur_config_name = class_postfix + data_sample_postfix + "_no_sim" + label_postfix

            record_dict[cur_config_name[1:]] = list()

            for _ in range(common_config_dict["test_num"]):
                precision, recall = train_once(
                        cur_config_name,
                        label_id_path,
                        train_data_dir,
                        each_num,
                        other_num,
                        eval_data_dir,
                        sim_data_dir,
                        refine_label,
                        )

                record_dict[cur_config_name[1:]].append((precision, recall))
        else:
            for cur_topk_sim in topk_sim_list:
                cur_config_name = class_postfix + data_sample_postfix + \
                        "_top{}_sim".format(cur_topk_sim) + label_postfix

                record_dict[cur_config_name[1:]] = list()

                for _ in range(common_config_dict["test_num"]):
                    precision, recall = train_once(
                            cur_config_name,
                            label_id_path,
                            train_data_dir,
                            each_num,
                            other_num,
                            eval_data_dir,
                            sim_data_dir,
                            refine_label,
                            cur_topk_sim,
                            )

                    record_dict[cur_config_name[1:]].append((precision, recall))

    logging.info("record: {}".format(record_dict))
    with codecs.open(common_config_dict["test_record_path"], "w", "utf-8") as wf:
        for config_name, test_record in record_dict.items():
            wf.write(config_name + "\n" + "\t".join(["index", "precision", "recall"]) + "\n")
            record_num = 0
            total_precision = 0.0
            total_recall = 0.0
            for index, (cur_precision, cur_recall) in enumerate(test_record):
                wf.write("\t".join([
                    str(index),
                    "{:.4f}".format(cur_precision),
                    "{:.4f}".format(cur_recall),
                    ]) + "\n")
                record_num += 1
                total_precision += cur_precision
                total_recall += cur_recall

            avg_precision = total_precision / float(record_num)
            avg_recall = total_recall / float(record_num)

            wf.write("\t".join([
                "avg:",
                "{:.4f}".format(avg_precision),
                "{:.4f}".format(avg_recall),
                ]) + "\n")


if __name__ == "__main__":
    model_eval()
