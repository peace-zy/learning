#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: shenhao02@baidu.com
  Date  : 20/09/17 11:27:56
  File  : http_replace_word_service.py
  Desc  : һ�ַǺ��Ĵ��滻�����ķ����
"""
from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
import logging
import json
import time
import tf_idf_replace_word
import replace_config

SUCC = 0
ERROR = 1
tf_data_aug = tf_idf_replace_word.TfIdfAug()
#ƽ��һ���ı�����ʱ��0.2S-0.3s,Ϊ�������Ѻã����õ��������������288
max_request_data_nums = replace_config.max_deal_nums

class S(BaseHTTPRequestHandler):
    """
    http service
    """
    def do_HEAD(self):
        """
        post response
        text/plain
        status 200
        """
        self.send_response(200)
        self.send_header('Content-type', 'text/plain')
        self.end_headers()

    def do_GET(self):
        """
        do get
        """
        paths = {
            '/TestServer': {'status': 200},
            '/bar': {'status': 302},
            '/baz': {'status': 404},
            '/qux': {'status': 500}
        }

        if self.path in paths:
            self.respond(paths[self.path])
        else:
            self.respond({'status': 500})
        logging.info("GET request,\nPath: %s\nHeaders:\n%s\n", str(self.path), str(self.headers))

    def do_POST(self):
        """
        do post
        """
        content_length = int(self.headers['Content-Length']) # <--- Gets the size of data
        post_data = self.rfile.read(content_length) # <--- Gets the data itself
        request_data_dict = json.loads(post_data)
        text_list = request_data_dict["text_list"]
        text_nums = len(text_list)
        logging.info("\n".join([
            "",
            "POST REQUEST:", "=" * 100,
            "ori text size: {}".format(text_nums),
            "first 5 example:", "\n".join(text_list[:5]).encode("utf8"), "-" * 100,
            ]))
        #ȥ����������
        res_dict = {
                "status": None,
                "error_info":None,
                "result":None}

        if text_nums > max_request_data_nums:
            res_dict["status"] = ERROR
            res_dict["error_info"] = \
                      "replace word text num is expected to be smaller than {}, actual {}."\
                      .format(max_request_data_nums, text_nums)
            logging.info("request fail: {}".format(res_dict["error_info"]))
        else:
            start_time = time.time()
            result = tf_data_aug.get_data_aug(post_data)
            res_dict["status"] = SUCC
            res_dict["result"] = result
            logging.info("cost time: {:.4f}s".format(time.time() - start_time))

        self.do_HEAD()
        self.wfile.write(json.dumps(res_dict).encode('utf-8'))
        #self.wfile.write(predict_result.encode('utf-8'))

    def respond(self, opts):
        """
        respond
        """
        response = self.handle_http(opts['status'], self.path)
        self.wfile.write(response)

    def handle_http(self, status_code, path):
        """
        get response
        text/html
        """
        self.send_response(status_code)
        self.send_header('Content-type', 'text/html')
        self.end_headers()

        content = '''
           <html><head><title>Title goes here.</title></head>
           <body></p>
           <p>You accessed path: {}</p>
           </body></html>
           '''.format(path)
        return bytes(content, 'UTF-8')


def run(server_class=HTTPServer, handler_class=S, port=8085):
    """
    Ĭ�϶˿�8085
    """
    print("run()")
    #logging.basicConfig(level=logging.INFO)
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    logging.info('Starting httpd...\n')
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    httpd.server_close()
    print("httpd.server_close()")
    logging.info('Stopping httpd...\n')


if __name__ == '__main__':
    from sys import argv

    if len(argv) == 2:
        run(port=int(argv[1]))
    else:
        run()
