#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: shenhao02@baidu.com
  Date  : 21/03/04 17:52:36
  File  : key_replace_word_client.py
  Desc  : һ�ַǺ��Ĵ��滻�����Ŀͻ���
"""

import sys
import requests
import json
import time

class ReplaceWordClient(object):
    """һ�ַǹؼ����滻
    """
    def __init__(self, url, host):
        """��ʼ��
        [IN]  url: str, �����������ַ
              host: str, host��ַ
        """
        self.url = url
        self.headers = {
                'content-Type': "text/plain",
                'Accept': "*/*",
                'Cache-Control': "no-cache",
                'Host': host,
                'accept-encoding': "gzip, deflate",
                'content-length': "1",
                'Connection': "keep-alive",
                'cache-control': "no-cache"
                }
    def replace_word_inquire(self, text_list, topk=10, batch_size=32):
        """
        �滻�ǹؼ��ʵ�����
        [IN]  text_list: list[str], ����ȡ�����ı����ı��б�
        aug_nums: int, һ���������ɵĸ���,Ĭ��Ϊ10
        batch_size: int, ��������ʱ��һ���Ĵ�С
        [OUT] res_list: list[text(str), list[list[aug_text(str)]]], ���ظ��ı��������ı��б�
        """
        def gen_batch_data(in_iter):
            """
            ���ݷ���
            """
            sample_list = list()
            for cur_text in in_iter:
                sample_list.append(cur_text.strip("\n"))
                if len(sample_list) == batch_size:
                    yield sample_list
                    sample_list = list()
            if len(sample_list) > 0:
                yield sample_list

        data_dict = dict()
        res_list = list()
        for cur_batch in gen_batch_data(text_list):
            data_dict["text_list"] = cur_batch
            data_dict["topk"] = topk
            payload = json.dumps(data_dict)
            #post��post��д������get
            response = requests.request("POST", self.url, data=payload, headers=self.headers)
            cur_res = json.loads(response.text)
            assert cur_res["status"] == 0, "generate fail: {}".format(cur_res["error_info"])
            res_list.extend(cur_res["result"])
        return res_list

if __name__ == "__main__":
    start_time = time.time()
    url = "http://10.255.121.18:8085/TestServer"
    host = "10.255.121.18:8085"
    
    client = ReplaceWordClient(url, host)
    res_list = client.replace_word_inquire(sys.stdin, 10, 32)
    #���Ϊ ԭʼ�ı�\t�����ı�
    for data in res_list:
        text = data[0]
        text_aug_list = data[1]
        for aug_text in text_aug_list:
            print ("\t".join([text, aug_text[0]]))
    end_time = time.time()
    print ("replace word text cost time : %.5fs" % (end_time - start_time))
