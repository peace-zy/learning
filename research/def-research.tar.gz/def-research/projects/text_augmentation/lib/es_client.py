#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   es_client.py
Author:   zhanghao55@baidu.com
Date  :   21/01/28 15:05:18
Desc  :   ͨ��requests����ES�Ŀͻ��ˣ�֧�֣��ı�������knn��hnsw
"""

import json
import logging
import requests


class EsClient(object):
    """
    ͨ��requests����ES�Ŀͻ��ˣ�֧�֣��ı�������knn��hnsw
    """
    def __init__(self, host, index, user, password, default_res_num=20):
        """
        Args:
            host            ES��ַ
            index           ES����
        """
        assert user is not None and password is not None, "user and password is required"
        self.host = host
        self.index = index
        self.auth = (user, password)
        uri = '{index}/_search'.format(index=index)
        self.search_url = requests.compat.urljoin(self.host, uri)

        # index�д洢�ı����ֶ�
        self._text_field = "text"
        # index�д洢�ı��������ֶ�
        self._vector_field = "vec"
        # Ĭ�Ϸ��ؽ����
        self._default_res_num = default_res_num

    def knn_search(self, vector, num=None):
        """
        knn����
        Args:
            vector:         list����������
            num:            int�����ؽ������
        Return:
            res:            list��ƥ���ı��б���unicode����
        """
        if num is None:
            num = self._default_res_num

        data = {
            "size": num,
            "_source": [
                self._text_field
            ],
            "query": {
                "script_score": {
                "query": {
                    "match_all": {}
                },
                "script": {
                    "source": "bpack_knn_script",
                    "lang": "knn",
                    "params": {
                        "space": "cosine",
                        "field": self._vector_field,
                        "vector": vector
                    }
                }
                }
            }
        }
        hits = self._search(data)
        return hits

    def hnsw_search(self, vector, num=None):
        """
        knn����
        Args:
            vector:         list����������
            num:            int�����ؽ������
        Return:
            res:            list��ƥ���ı��б���unicode����
        """
        if num is None:
            num = self._default_res_num

        data = {
            "_source": [
                self._text_field
            ],
            "size": num,
            "query": {
                "knn": {
                    self._vector_field: {
                        "vector": vector,
                        "k": 16,
                        "ef": 512
                    }
                }
            }
        }
        hits = self._search(data)
        return hits

    def text_search(self, text, num=None):
        """
        �ı�����
        Args:
            text:           unicode�������ı�����
            num:            int�����ؽ������
        Return:
            res:            list��ƥ���ı��б���unicode����
        """
        if num is None:
            num = self._default_res_num

        data = {
            "_source": [
                self._text_field
            ],
            "size": num,
            "query": {
                "match": {
                    self._text_field: {
                        "query": text
                    }
                }
            }
        }
        hits = self._search(data)
        return hits

    def _search(self, data, max_retry=3):
        """
        ͨ��request����ES�ӿ�
        """
        headers = {'Content-Type': 'application/json'}
        cur_retry = 0

        res = None

        while cur_retry < max_retry:
            try:
                r = requests.get(
                    self.search_url,
                    data=json.dumps(data),
                    headers=headers,
                    auth=self.auth
                )
                res = self._extract_hits(r.json())
                break
            except requests.exceptions.RequestException as e:
                logging.exception(e)
                cur_retry += 1
                continue

        return res

    def _extract_hits(self, es_res):
        """
        ��ES���ؽ������ȡ�ı�����
        """
        hits = None
        if 'hits' in es_res:
            hits = [(hit['_source'][self._text_field], hit['_score']) for hit in es_res['hits']['hits']]
        return hits


if __name__ == "__main__":
    # ��������
    test_text = (
        "�¿ͻ������ƻ�?���ٶ� ������������Ѱ�ҿͻ� ���˽������ƹ�?"
        "ѡ�ٶ�,����ƽ̨,רҵ����,95%���񸲸�,��׼�����ͻ�. ebaidu,Ϊ�����������ƹ㷽��!"
    )
    test_vector = [
        0.10078766196966171,
        0.02417379803955555,
        -0.06588204205036163,
        0.09321152418851852,
        0.09389954805374146,
        0.10684507340192795,
        0.007240018341690302,
        0.0851881206035614,
        -0.009863083250820637,
        -0.12724758684635162,
        0.08160372078418732,
        0.1231248676776886,
        0.06563802063465118,
        0.08977779746055603,
        -0.11332929134368896,
        -0.11295398324728012,
        0.06513851881027222,
        0.11067375540733337,
        0.12904410064220428,
        0.1198195368051529,
        -0.04696616902947426,
        0.07953669875860214,
        0.0844886526465416,
        0.08452624827623367,
        -0.12084608525037766,
        0.06847305595874786,
        -0.02877555415034294,
        0.04439488425850868,
        -0.0835941731929779,
        0.1042294055223465,
        -0.13046491146087646,
        0.05045340955257416,
        0.08099770545959473,
        0.011788180097937584,
        0.06179004907608032,
        0.12297046184539795,
        0.09883073717355728,
        -0.08219874650239944,
        0.04564732685685158,
        -0.10959703475236893,
        0.04097073897719383,
        0.025332322344183922,
        -0.058952100574970245,
        0.08328796178102493,
        0.11421050131320953,
        0.024416973814368248,
        0.11604492366313934,
        0.10160965472459793,
        0.10020024329423904,
        0.04904743656516075,
        -0.0812373086810112,
        0.10768627375364304,
        -0.006583491340279579,
        0.08602607250213623,
        0.07530844211578369,
        0.10640911012887955,
        0.08463679999113083,
        -0.022909823805093765,
        -0.12307935208082199,
        -0.10465328395366669,
        -0.11636454612016678,
        0.01125570759177208,
        -0.008390800096094608,
        0.059578996151685715,
        -0.07079136371612549,
        -0.12600557506084442,
        0.11916820704936981,
        0.025258494541049004,
        0.028395280241966248,
        -0.09682862460613251,
        0.07250244170427322,
        0.01143017690628767,
        0.12009209394454956,
        -0.10939782112836838,
        -0.05911794304847717,
        0.04344428703188896,
        -0.091854028403759,
        0.08350968360900879,
        0.12974342703819275,
        0.10816752910614014,
        0.10292476415634155,
        0.13434457778930664,
        0.06807166337966919,
        0.09349462389945984,
        -0.04001869633793831,
        0.09238464385271072,
        -0.06990265846252441,
        0.10820560157299042,
        0.05165008082985878,
        -0.028862364590168,
        0.11609447002410889,
        -0.03308705613017082,
        -0.09509814530611038,
        -0.09618960320949554,
        -0.05187922343611717,
        0.12094918638467789,
        -0.09883957356214523,
        -0.10738585144281387,
        -0.062205277383327484,
        0.051352351903915405,
        0.028121860697865486,
        -0.04193670302629471,
        -0.12064392864704132,
        0.051973436027765274,
        -0.10044542700052261,
        0.12764327228069305,
        0.11645318567752838,
        -0.11898616701364517,
        0.12590321898460388,
        -0.09347724914550781,
        -0.03291015699505806,
        -0.09698150306940079,
        0.12386079132556915,
        0.08967695385217667,
        0.025389155372977257,
        0.10363975912332535,
        -0.03729066997766495,
        0.05552617087960243,
        0.03527392819523811,
        0.1165175810456276,
        -0.12218078970909119,
        0.047572799026966095,
        0.12391474097967148,
        -0.10815184563398361,
        -0.07978948950767517,
        -0.1329842209815979,
        0.06867485493421555,
        -0.12994152307510376
    ]
    es = EsClient('http://10.138.71.8:8200/', 'vector_search', 'superuser', 'Fkrd123')
    #print(json.dumps(es.text_search(test_text), indent=2, ensure_ascii=False))
    print(json.dumps(es.hnsw_search(test_vector), indent=2, ensure_ascii=False))
