#!/usr/bin/env python3
# -*- coding:gb18030 -*-
"""
File  :   es_sim_text_search.py
Author:   zhanghao55@baidu.com
Date  :   21/01/29 15:37:03
Desc  :   
"""

import os
import sys
import codecs
import logging
import time
import torch
from tqdm import tqdm

from base_model import BertSeq2seqModel, model_distributed
from bert import BertForSeqSim
from es_client import EsClient
from utils import (
        check_dir,
        bert_infer_collate_fn,
        get_dataloader,
        ErnieDataset,
        )

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../" % _cur_dir)

from lib.common.data_io import get_attr_values
from lib.common.logger import init_log
from lib.common.label_encoder import LabelEncoder
from lib.common.bert_tokenizer import BertTokenizer

IS_DISTRIBUTED = False
try:
    torch.distributed.init_process_group(backend="nccl")
    LOCAL_RANK = torch.distributed.get_rank()
    IS_DISTRIBUTED = True

    logging_level = logging.INFO if LOCAL_RANK == 0 else logging.WARNING
    init_log(stream_level=logging_level)
except ValueError as e:
    init_log(stream_level=logging.INFO)

logging.info("is_distributed: {}".format(IS_DISTRIBUTED))


class ErnieSeqSimModel(BertSeq2seqModel):
    """ErnieSeqSimģ��
    """
    @model_distributed(find_unused_parameters=True, distributed=IS_DISTRIBUTED)
    def init_model(self, model_dir, tokenizer, keep_tokens, pool_out_size=None):
        """��ʼ������
        """
        ernie_model = BertForSeqSim.from_pretrained(
                model_dir,
                vocab_size=tokenizer.vocab_size,
                keep_tokens=keep_tokens,
                pool_out_size=pool_out_size,
                )
        return ernie_model


class EsSimTextSearch(object):

    def __init__(self, label_id_path, vocab_path, pretrained_model_path, best_model_path, pool_out_size=128):
        self.label_encoder = LabelEncoder(label_id_path, isFile=True)
        self.tokenizer, self.keep_tokens = BertTokenizer.load(vocab_path, simplified=True)
        self.model = ErnieSeqSimModel(
                model_dir=pretrained_model_path,
                tokenizer=self.tokenizer,
                keep_tokens=self.keep_tokens,
                pool_out_size=128,
                )
        logging.info("model at device : {}".format(self.model.device))
        self.model.load_model(best_model_path)

        self.es_client = EsClient(
                host="http://10.138.71.8:8200/",
                index="vector_search_v2",
                user="superuser",
                password="Fkrd123",
                )

    def sim_text_search(self, text_list, sim_res_path=None, display=False, topk=20):
        cur_dataloader = self.gen_dataloader(text_list)
        text_vec = self.model.predict(cur_dataloader, gather_output_inds=[1])[0]
        logging.info("text_vec shape: {}".format(text_vec.shape))

        if IS_DISTRIBUTED and LOCAL_RANK != 0:
            return

        def get_sim_text():
            pbar = tqdm(total=len(text_list), desc="searching")
            for cur_vec, cur_text in zip(text_vec, text_list):
                cur_es_res = self.es_client.hnsw_search(cur_vec.tolist(), num=topk)
                pbar.update(1)
                yield cur_es_res
            pbar.close()

        sim_res_iter = zip(text_list, get_sim_text())

        start_time = time.time()
        if sim_res_path is None:
            if display:
                for cur_text, cur_es_res in sim_res_iter:
                    logging.info("ori text: {}".format(cur_text))
                    for index, (cur_sim_text, cur_sim_score) in enumerate(cur_es_res):
                        logging.info("es_sim_text #{}, score {}: {}".format(\
                                index, cur_sim_score, cur_sim_text))
                    logging.info("=" * 150)
        else:
            with codecs.open(sim_res_path, "w", "gb18030") as wf:
                for cur_text, cur_es_res in sim_res_iter:
                    wf.write("ori text: {}\n".format(cur_text))
                    for index, (cur_sim_text, cur_sim_score) in enumerate(cur_es_res):
                        wf.write("es_sim_text #{}, score {}: {}\n".format(\
                                index, cur_sim_score, cur_sim_text))
                    wf.write("=" * 150 + "\n")
        logging.info("es search sim text time: {}s".format(time.time() - start_time))
        return sim_res_iter

    def gen_dataloader(self, text_list, batch_size=32, max_num=None, example_num=5):
        text_id_list = [self.tokenizer.encode(x) for x in text_list]
        data_list = list(zip(*zip(*text_id_list), range(len(text_id_list))))

        logging.info(u"��������")
        for index, (text, (token_ids, _, label_id)) in enumerate(zip(
                text_list[:example_num],
                data_list[:example_num],
                )):
            logging.info("example #{}:".format(index))
            logging.info("text: {}".format(text))
            logging.info("label_name: {}".format(self.label_encoder.inverse_transform(label_id)))
            logging.info("token_ids: {}".format(token_ids))

        res_dataloader = get_dataloader(
                ErnieDataset(data_list),
                collate_fn=bert_infer_collate_fn,
                batch_size=batch_size,
                distributed=IS_DISTRIBUTED,
                shuffle=False,
                )
        return res_dataloader

def test():
    es = EsSimTextSearch(
            label_id_path="data/class_id.txt",
            vocab_path="pretrained_models/ernie-1.0/vocab.txt",
            pretrained_model_path="pretrained_models/ernie-1.0/",
            best_model_path="ernie_seqsim_v2.0/ernie_seqsim_best")

    text_list = [
            "�������꣬���Ӻ��ֵܾ�Ȼ�������������£�����ԭ��",
            "���������óԣ���������",
            "����������������׳���ܲ��ܰ�æ��һ�½�������ѽ~",
            "������ô�죬�������������",
            ]

    es.sim_text_search(text_list)

def stream_search(instream, output_path):
    es = EsSimTextSearch(
            label_id_path="data/class_id.txt",
            vocab_path="pretrained_models/ernie-1.0/vocab.txt",
            pretrained_model_path="pretrained_models/ernie-1.0/",
            best_model_path="ernie_seqsim_v2.0/ernie_seqsim_best")

    text_list = [line.strip("\n") for line in instream]

    es.sim_text_search(text_list, output_path)

def stream_search_with_label(instream):
    es = EsSimTextSearch(
            label_id_path="data/class_id.txt",
            vocab_path="pretrained_models/ernie-1.0/vocab.txt",
            pretrained_model_path="pretrained_models/ernie-1.0/",
            best_model_path="ernie_seqsim_v2.0/ernie_seqsim_best")

    data_list = [line.strip("\n").split("\t") for line in instream][1:]
    label_list, text_list = zip(*data_list)

    sim_res_list = es.sim_text_search(text_list)
    with codecs.open("output/sim_text_with_label", "w", "gb18030") as wf:
        for cur_label, (cur_text, cur_sim_list) in zip(label_list, sim_res_list):
            for cur_sim_text, cur_sim_score in cur_sim_list:
                wf.write("\t".join([
                    cur_label,
                    cur_sim_text,
                    cur_text,
                    str(cur_sim_score),
                    ]) + "\n")


if __name__ == "__main__":
    stream_search_with_label(sys.stdin)
    #stream_search(sys.stdin, "output/sim_text.txt")
    #test()
