#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   custom_distributed_sampler.py
Author:   zhanghao55@baidu.com
Date  :   21/01/16 17:12:45
Desc  :   
"""

import sys
import logging
import math
import torch
from torch.utils.data import Sampler
import torch.distributed as dist


class SeqSimDistributedSampler(Sampler):
    r"""Sampler that restricts data loading to a subset of the dataset.

    ԭDistributedSamplerע��:
    It is especially useful in conjunction with
    :class:`torch.nn.parallel.DistributedDataParallel`. In such a case, each
    process can pass a :class`~torch.utils.data.DistributedSampler` instance as a
    :class:`~torch.utils.data.DataLoader` sampler, and load a subset of the
    original dataset that is exclusive to it.

    .. note::
        Dataset is assumed to be of constant size.

    Arguments:
        dataset: Dataset used for sampling.
        num_replicas (int, optional): Number of processes participating in
            distributed training. By default, :attr:`rank` is retrieved from the
            current distributed group.
        rank (int, optional): Rank of the current process within :attr:`num_replicas`.
            By default, :attr:`rank` is retrieved from the current distributed
            group.
        shuffle (bool, optional): If ``True`` (default), sampler will shuffle the
            indices.
        seed (int, optional): random seed used to shuffle the sampler if
            :attr:`shuffle=True`. This number should be identical across all
            processes in the distributed group. Default: ``0``.

    .. warning::
        In distributed mode, calling the :meth`set_epoch(epoch) <set_epoch>` method at
        the beginning of each epoch **before** creating the :class:`DataLoader` iterator
        is necessary to make shuffling work properly across multiple epochs. Otherwise,
        the same ordering will be always used.

    Example::

        >>> sampler = DistributedSampler(dataset) if is_distributed else None
        >>> loader = DataLoader(dataset, shuffle=(sampler is None),
        ...                     sampler=sampler)
        >>> for epoch in range(start_epoch, n_epochs):
        ...     if is_distributed:
        ...         sampler.set_epoch(epoch)
        ...     train(loader)

    �Զ���ע��: רΪseqsim����ķֲ�ʽsampler����Ϊseqsim�����data������һ�飬
                ���Գ���ʱҪ��������һ�飬���ܴ���
    """

    def __init__(self, dataset, num_replicas=None, rank=None, shuffle=True, seed=0):
        if num_replicas is None:
            if not dist.is_available():
                raise RuntimeError("Requires distributed package to be available")
            num_replicas = dist.get_world_size()
        if rank is None:
            if not dist.is_available():
                raise RuntimeError("Requires distributed package to be available")
            rank = dist.get_rank()

        #  ���ݼ�����һ����ż��
        self.dataset = dataset
        dataset_size = len(self.dataset)
        assert dataset_size % 2 == 0, "dataset_size is not even, actual: {}".format(dataset_size)
        # ���ݻ���ʱҪ����һ�� ���Ի��ֵ�ʱ�� Ҫ������������ ����=self.dataset_size/2 һ��������
        self.group_size = int(dataset_size / 2)
        logging.debug("group_size: {}".format(self.group_size))

        # ������
        self.num_replicas = num_replicas
        # ��ǰ����ID
        self.rank = rank
        # ��ǰepoch
        self.epoch = 0
        # num_groups: ÿ��process_����䵽������
        self.num_groups = int(math.ceil(self.group_size * 1.0 / num_replicas))
        # num_samples: һ��process�����䵽�������� ������*2
        self.num_samples = self.num_groups * 2

        # pad_group_size Ϊ��ȫ����������batch�����ݶ���Ҫ���뵽������
        self.pad_group_size = self.num_groups * self.num_replicas
        logging.debug("pad_group_size: {}".format(self.pad_group_size))
        # total_size Ϊ��ȫ����������batch�����ݶ���Ҫ���뵽�����ݼ���
        #self.total_size = self.num_samples * self.num_replicas
        self.shuffle = shuffle
        self.seed = seed

    def __iter__(self):
        if self.shuffle:
            # deterministically shuffle based on epoch and seed
            g = torch.Generator()
            g.manual_seed(self.seed + self.epoch)
            group_idxs = torch.randperm(self.group_size, generator=g).tolist()
        else:
            group_idxs = list(range(self.group_size))


        # add extra samples to make it evenly divisible
        logging.debug("group_idxs size: {}".format(len(group_idxs)))
        logging.debug("pad_group_size: {}".format(self.pad_group_size))
        # ��group_idxs * 2 < pad_group_sizeʱ���÷�����Ч
        # ���Ը�ֱ�������һ����������İ취
        #group_idxs += group_idxs[:(self.pad_group_size - len(group_idxs))]
        # �����һ����������
        group_idxs += [group_idxs[-1]] * (self.pad_group_size - len(group_idxs))
        assert len(group_idxs) == self.pad_group_size

        # �õ���ǰrank���ֵ�����
        group_idxs = group_idxs[self.rank:self.pad_group_size:self.num_replicas]
        logging.debug("group_idxs: {}".format(group_idxs))

        ds_idxs = list()
        for group_id in group_idxs:
            ds_idxs.append(2 * group_id)
            ds_idxs.append(2 * group_id + 1)

        # subsample
        #indices = indices[self.rank:self.total_size:self.num_replicas]
        #indices = indices[self.rank * self.num_samples : (self.rank + 1) * self.num_samples]
        #:self.total_size:self.num_replicas]
        assert len(ds_idxs) == self.num_samples

        logging.debug("ds_idx: {}".format(ds_idxs))
        return iter(ds_idxs)

    def __len__(self):
        return self.num_samples

    def set_epoch(self, epoch):
        r"""
        Sets the epoch for this sampler. When :attr:`shuffle=True`, this ensures all replicas
        use a different random ordering for each epoch. Otherwise, the next iteration of this
        sampler will yield the same ordering.

        Arguments:
            epoch (int): Epoch number.
        """
        self.epoch = epoch
