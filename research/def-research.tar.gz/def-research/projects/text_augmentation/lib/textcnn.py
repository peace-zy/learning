#!/usr/bin/env python3
# -*- coding:gb18030 -*-
"""
File  :   textcnn.py
Author:   zhanghao55@baidu.com
Date  :   21/01/14 10:53:03
Desc  :   
"""

import sys
import logging
import torch
import torch.nn as nn

from basic_layers import EmbeddingLayer, TextCNNLayer


class TextCNNClassifier(nn.Module):
    """textcnn����ģ��
    """
    def __init__(self,
            num_class,
            vocab_size,
            emb_dim=32,
            num_filters=10,
            fc_hid_dim=32,
            num_channels=1,
            win_size_list=None,
            is_sparse=True,
            ):
        super(TextCNNClassifier, self).__init__()

        self.embedding = EmbeddingLayer(
            vocab_size=vocab_size,
            emb_dim=emb_dim,
            is_sparse=is_sparse,
            )

        if win_size_list is None:
            win_size_list = [3]

        self.textcnn = TextCNNLayer(
            emb_dim,
            num_filters,
            num_channels,
            win_size_list,
            )

        logging.info("num_class     = {}".format(num_class))
        logging.info("vocab size    = {}".format(vocab_size))
        logging.info("emb_dim       = {}".format(emb_dim))
        logging.info("num filters   = {}".format(num_filters))
        logging.info("fc_hid_dim    = {}".format(fc_hid_dim))
        logging.info("num channels  = {}".format(num_channels))
        logging.info("win size list = {}".format(win_size_list))
        logging.info("is sparse     = {}".format(is_sparse))

        self._hid_fc = nn.Linear(in_features=num_filters * len(win_size_list), out_features=fc_hid_dim)
        self._act = nn.Tanh()
        self._output_fc = nn.Linear(in_features=fc_hid_dim, out_features=num_class)
        self.ce_loss = nn.CrossEntropyLoss()

    def forward(self, inputs, *args, labels=None, **kwargs):
        """ǰ��Ԥ��
        """
        #print("\n".join(map(lambda ids: "/ ".join([id_2_token[x] for x in ids]), inputs.numpy())))
        # inputs shape = [batch_size, seq_len]
        #print("inputs shape: {}".format(inputs.shape))

        # emb shape = [batch_size, seq_len, emb_dim]
        emb = self.embedding(inputs)
        #print("emb shape: {}".format(emb.shape))

        conv_pool_res = self.textcnn(emb)

        hid_fc = self._hid_fc(conv_pool_res)
        #print("hid_fc shape: {}".format(hid_fc.shape))

        hid_act = self._act(hid_fc)

        logits = self._output_fc(hid_act)
        #print("logits shape: {}".format(logits.shape))

        # ���û�и���ǩ �����logits���
        if labels is None:
            return logits

        # ����label����״
        if len(labels.shape) == 1:
            labels = torch.reshape(labels, shape=(-1,))
        #logging.info("labels shape: {}".format(labels.shape))
        #logging.info("logits shape: {}".format(logits.shape))

        loss = self.ce_loss(logits, labels)

        return loss, logits

if __name__ == "__main__":
    model_config = {
        "num_class": 12,
        "vocab_size": 3000,
        "emb_dim": 32,
        "num_filters": 10,
        "fc_hid_dim": 64,
        "num_channels": 1,
        "win_size_list": None,
        "is_sparse": True,
    }
    TextCNNClassifier(**model_config)
