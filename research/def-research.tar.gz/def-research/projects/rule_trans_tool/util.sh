#!/bin/bash
#==================================================================================================#
# Author: shenhao02@baidu.com
# Date  : 21/05/19 17:04:38
# File  : util.sh
# Description: 
#==================================================================================================#

BASE_DIR=$(cd "$(dirname "$0")";pwd)
LOG_DIR="${BASE_DIR}/log/"
LOG_FILE="util.log"
if [ ! -d ${LOG_DIR} ]; then
    mkdir ${LOG_DIR}
fi

function WriteLog()
{
    local msg_date=`date +%Y-%m-%d" "%H:%M:%S`
    local msg_begin=""
    local msg_end=""
    if [ $# -eq 1 ]; then
        local msg=$1
        echo "[${msg_date}]${msg}" | tee -a ${LOG_DIR}${LOG_FILE}
    elif [ $# -eq 2 ]
    then
        local msg=$2
        local runstat=$1
        if [ ${runstat} -eq 0 ]; then
            msg_begin="Success"
            msg_end="ok!"
        else
            msg_begin="Error"
            msg_end="fail!"
        fi
        echo "[${msg_date}][${msg_begin}]${msg} ${msg_end}" | tee -a ${LOG_DIR}${LOG_FILE}
        if [ ${runstat} -ne 0 ]; then
            echo "error when Task ${msg} runs at ${msg_date}" | tee -a ${LOG_DIR}${LOG_FILE}
            exit 1
        fi
    else
        return
    fi
}

function exit_error()
{
    info=${1}
    time_now=`date +"%Y%m%d %H:%M:%S"`
    echo -e "ERROR, ${time_now}, ${info}!" >> ${LOG_DIR}${LOG_FILE}
    exit 1
}

function get_file_wget()
{
    local ftp_config=${1}
    #local ftp_path=${3}
    local dst_path=${2}
    WriteLog "get_file_wget ${ftp_path} begin."
    ${ftp_config} ${ftp_path} -O ${dst_path} || exit_error "get fail"
    WriteLog "get_file_wget ${ftp_path} end."
}
