#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: shenhao02@baidu.com
  Date  : 21/06/15 17:46:57
  File  : model_diff_map.py
  Desc  : 
"""

import sys
import logging
import json
import os
from common import Common

class ModelDiffMap(object):
    """
    ��ģ��diff��map��
    """
    def __init__(self, input_file, output_file):
        """
        ��ʼ��
        """
        self.input_file = input_file
        self.output_file = output_file

    def init(self, old_map, new_map):
        """
        ��ʼ������map
        [in] old_map: label map
             new_map: label_map
        """
        self.old_label_id_dict = Common.load_map_dict(old_map)
        self.old_id_label_dict = {v: k for k, v in self.old_label_id_dict.items()}
        self.new_label_id_dict = Common.load_map_dict(new_map)
        self.new_id_label_dict = {v: k for k, v in self.new_label_id_dict.items()}

    def image_result(self, predict_result, id_label_dict):
        """
        ͼƬ���ӳ��
        [in]  predict_result: Ԥ����
              id_label_dict: ӳ��
        [out] result_label_list: label list
        """
        predict_label_dict = json.loads(predict_result)
        predict_check_result = predict_label_dict["check_result"]
        result_label_list = list()
        if len(predict_check_result) > 0:
            predict_check_boxes = predict_check_result["boxes"]
            for check_list in predict_check_boxes:
                result_check_dict = dict()
                label_list = list()
                score_list = list()
                check_label = int(check_list[0])
                check_prob = float(check_list[1])
                check_x_min = float(check_list[2])
                check_y_min = float(check_list[3])
                check_x_max = float(check_list[4])
                check_y_max = float(check_list[5])
                check_w = check_y_max - check_y_min
                check_h = check_x_max - check_x_min
                map_platform_label = check_label
                if str(check_label) in id_label_dict:
                    map_platform_label = int(id_label_dict[str(check_label)])
                else:
                    #�̶����ձ�ǩΪ0,�����ǩƽ̨δע��ᱨ��
                    logging.error("label: %s  not in map." % (str(check_label)))
                    sys.exit(1)
                label_list.append(map_platform_label)
                score_list.append(check_prob)
                result_check_dict["x"] = check_x_min
                result_check_dict["y"] = check_y_min
                result_check_dict["w"] = check_w
                result_check_dict["h"] = check_h
                result_check_dict["label"] = label_list
                result_check_dict["score"] = score_list
                result_label_list.append(result_check_dict)

        return result_label_list

    def diff_image_map(self):
        """
        ��ȡͼƬdiff
        """
        with open(self.input_file, "r") as fr, open(self.output_file, "w") as fw:
            for line in fr:
                each_list = line.strip().split("\t")
                old_label_result = each_list[-2]
                new_label_result = each_list[-1]
                old_label_list = self.image_result(old_label_result, self.old_id_label_dict)
                new_label_list = self.image_result(new_label_result, self.new_id_label_dict)
                fw.write("\t".join(["\t".join(each_list[:-2]), json.dumps(old_label_list), \
                          json.dumps(new_label_list)]) + "\n")

    def text_map(self, label, prob, id_label_dict):
        """
        �ı����ӳ��
        [in]  label: ��ǩ
              prob: ����
              id_label_dict: ��ǩӳ��
        [out] result_label_list: label list
        """
        if label in id_label_dict:
            map_platform_label = id_label_dict[label]
        else:
            logging.error("label: %s  not in map." % (label))
            sys.exit(1)
        result_label_list = list()
        result_label_dict = {
        "label": list(),
        "score": list()
        }
        result_label_dict["label"].append(int(map_platform_label))
        result_label_dict["score"].append(float(prob))
        result_label_list.append(result_label_dict)

        return result_label_list

    def diff_text_map(self):
        """
        ��ȡ�ı�diff
        """
        with open(self.input_file, "r") as fr, open(self.output_file, "w") as fw:
            for line in fr:
                each_list = line.strip().split("\t")
                old_label = each_list[-4]
                old_label_prob = each_list[-3]
                new_label = each_list[-2]
                new_label_prob = each_list[-1]
                old_label_list = self.text_map(old_label, old_label_prob, self.old_id_label_dict)
                new_label_list = self.text_map(new_label, new_label_prob, self.new_id_label_dict)
                fw.write("\t".join(["\t".join(each_list[:-4]), json.dumps(old_label_list), \
                        json.dumps(new_label_list)]) + "\n")


if __name__ == "__main__":
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    old_map = sys.argv[3]
    new_map = sys.argv[4]
    model_type = sys.argv[5]
    model_diff_map = ModelDiffMap(input_file, output_file)
    model_diff_map.init(old_map, new_map)
    #�������õ��ò�ͬ�Ĵ�������
    common_config = Common.read_config("./data/config.ini")
    model_diff_config = common_config["model_diff"]
    text_algorithm_list = model_diff_config["text_algorithm"].split(",")
    image_algorithm_list = model_diff_config["image_algorithm"].split(",")
    if model_type in image_algorithm_list:
        model_diff_map.diff_image_map()
    elif model_type in text_algorithm_list:
        model_diff_map.diff_text_map()
    else:
        logging.error("model type: %s not in list" % (model_type))


