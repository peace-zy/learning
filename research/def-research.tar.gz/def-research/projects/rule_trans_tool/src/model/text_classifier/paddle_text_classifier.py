#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: shenhao02@baidu.com
  Date  : 21/05/13 11:26:29
  File  : paddle_text_classifier.py
  Desc  : ͨ��paddle text classifier��
"""

import sys
import os
import logging
import codecs
import numpy as np
import paddle.fluid as fluid

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(_cur_dir, "../../"))
from model.tokenizers.ernie_tokenizer import ErnieTokenizer
from utils.data_io import get_data, gen_batch_data


class PaddleTextClassifier(object):
    """
    ����paddle��ͨ��paddletextclassifier��
    """
    def __init__(self):
        """
        init
        """
        pass

    def init_infer(self, model_type, model_dir, model_conf):
        """
        ��ʼ��predictor
        [in] model_type, model_dir, model_conf
        """
        self.init_model(model_type, model_dir, model_conf)

    def init_model(self, model_type, model_dir, model_conf):
        """
        [in] model_type, model_dir, model_conf
        creat model predictor
        """
        self.model_type = model_type
        self.model_dir = model_dir
        self.model_conf = model_conf
        self.use_gpu = self.model_conf.getboolean("use_gpu")
        self.tokenizer = ErnieTokenizer.from_pretrained(model_conf["vocab_path"])
        self.create_model(self.model_dir, self.use_gpu)

    def create_model(self,
                 model_dir,
                 use_gpu=False):
        """
        ��ʼ��predictor
        [in] model_dir: ģ���ļ���ַ
             use_gpu: GPU
        """
        self.predictor = self.load_predictor(
                model_dir,
                use_gpu=use_gpu)

    def load_predictor(self, 
                       model_dir,
                       use_gpu=False):
        """
        [in] model_dir
        [out] predictor  AnalysePredictor
        """
        config = fluid.core.AnalysisConfig(model_dir)
        if use_gpu:
            # initial GPU memory(M), device ID
            config.enable_use_gpu(100, 0)
            # optimize graph and fuse op
            config.switch_ir_optim(True)
        else:
            config.disable_gpu()
    
        # disable print log when predict
        config.disable_glog_info()
        # enable shared memory
        config.enable_memory_optim()
        # disable feed, fetch OP, needed by zero_copy_run
        config.switch_use_feed_fetch_ops(False)
        predictor = fluid.core.create_paddle_predictor(config)
        return predictor

    def predict_run(self,
                    infer_data):
        """
        predictor��������
        zerocopyrun
        """
        input_names = self.predictor.get_input_names()
        input_tensor = self.predictor.get_input_tensor(input_names[0])
        input_tensor.copy_from_cpu(infer_data)
        try:
            self.predictor.zero_copy_run()
        except Exception as e:
            logging.info("paddle predictor error")
            raise e

        output_names = self.predictor.get_output_names()
        output_tensor = self.predictor.get_output_tensor(output_names[0])
        logits = output_tensor.copy_to_cpu()
        index_max = np.argmax(logits, axis=-1)
        prob_max = logits[range(logits.shape[0]), index_max]
        return index_max, prob_max

    def predict_batch(self,
                      data_iter,
                      with_label=True,
                      batch_size=32,
                      max_seq_len=300):
        """
        [in] data_iter,
             with_label: �Ƿ�Я��������Ϣ(labelname/text))
             batch_size,
             max_seq_len
        [out] all_predict_label: batchԤ���е�label
              all_prob: prob
              all_text: text
        """
        infer_data_batch = gen_batch_data(
            data_iter,
            batch_size=batch_size,
            max_seq_len=max_seq_len,
            with_label=with_label,
            )
        all_predict_label = list()
        all_prob = list()
        all_text = list()
        for cur_batch in infer_data_batch:
            if with_label:
                cur_infer_data, cur_infer_label = cur_batch
            else:
                cur_infer_data = cur_batch
            index_label, label_prob = self.predict_run(cur_infer_data)
            all_predict_label.extend(index_label)
            all_prob.extend(label_prob)
            if with_label:
                cur_label = np.squeeze(cur_infer_label, axis=-1)
                all_text.extend(cur_label)
        return all_predict_label, all_prob, all_text

    def infer(self, infer_file, output_file, batch_size=32):
        """
        infer
        """
        def line_processor(line):
            """
            ÿ���ı���������
            """
            all_info = line.strip("\n")
            parts = all_info.split("\t")
            text = parts[0]
            return (self.tokenizer.encode(text)[0], all_info)

        infer_data_iter = get_data(infer_file, read_func=line_processor)
        label_index_list, prob_list, text_list = self.predict_batch(infer_data_iter, batch_size=batch_size)

        with codecs.open(output_file, "w", 'gb18030') as wf:
            for label, text, prob in zip(label_index_list, text_list, prob_list):
                wf.write("%s\t%s\t%s\n" % (text, label, prob))

if __name__ == "__main__":
    pass

