#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: shenhao02@baidu.com
  Date  : 21/05/13 11:26:11
  File  : __init__.py
  Desc  : ��ʼ��
"""

import sys

if __name__ == "__main__":
    pass

