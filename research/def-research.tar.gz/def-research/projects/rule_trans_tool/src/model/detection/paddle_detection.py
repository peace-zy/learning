#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: shenhao02@baidu.com
  Date  : 21/05/10 19:00:23
  File  : paddle_detection.py
  Desc  : ͨ��paddle detection��
"""

import sys
import os
import logging
import time
import json
import numpy as np
import paddle.fluid as fluid

from config_yml import Config
from image_process.preprocess import preprocess, Resize, Normalize, Permute, PadStride
from image_process.visualize import visualize_box_mask, lmk2out
_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(_cur_dir, "../../"))
from utils.img_io import ResultEncoder, get_img, multi_thread_down, image_md5_process, url_down

class PaddleDetection(object):
    """
    ����paddle��ͨ��paddledetection��
    """
    def __init__(self):
        """
        init
        """
        pass

    def init_infer(self, model_type, model_dir, model_conf):
        """
        ��ʼ��predictor
        [in] model_type, model_dir, model_conf
        """
        #predictor ��ʼ��
        #exe / predictor
        self.init_model(model_type, model_dir, model_conf)

    def init_model(self, model_type, model_dir, model_conf):
        """
        �������ô���model predictor
        [in] model_type, model_dir, model_conf
        creat model predictor
        """
        #��ʼ�����ã�ģ��load
        self.model_type = model_type
        self.model_dir = model_dir
        self.model_conf = model_conf
        self.use_gpu = self.model_conf.getboolean("use_gpu")
        config = Config(self.model_dir, self.model_conf["infer_cfg"])
        self.create_model(config, self.model_dir, self.use_gpu)

    def create_model(self,
                 config,
                 model_dir,
                 use_gpu=False):
        """
        ����ģ�͵�use_python_inference
        ����predictor/ executor
        """
        self.config = config
        if self.config.use_python_inference:
            self.executor, self.program, self.fecth_targets = self.load_executor(
                model_dir, use_gpu=use_gpu)
        else:
            self.predictor = self.load_predictor(
                model_dir,
                run_mode=self.config.mode,
                min_subgraph_size=self.config.min_subgraph_size,
                use_gpu=use_gpu)

    def load_executor(self, model_dir, use_gpu=False):
        """
        ʹ��executor������
        [in] model_dir ģ��·��
             use_gpu  �Ƿ�GPU
        [out] exe  exe.runִ����
              program
              fetch_targets
              ����3����Ϊexecutor��ִ̬�б�ѡ
        """
        if use_gpu:
            place = fluid.CUDAPlace(0)
        else:
            place = fluid.CPUPlace()
        exe = fluid.Executor(place)
        program, feed_names, fetch_targets = fluid.io.load_inference_model(
            dirname=model_dir,
            executor=exe,
            model_filename='__model__',
            params_filename='__params__')
        return exe, program, fetch_targets

    def load_predictor(self, 
                       model_dir,
                       run_mode='fluid',
                       batch_size=1,
                       use_gpu=False,
                       min_subgraph_size=3):
        """
        ʹ��AnalyseConfig������������ƽ����exectuor��
        [in] model_dir ģ��·��
             run_mode  ģ���Ƿ����trt
             batch_size  Ĭ��1
             use_gpu ʹ��gpu
             min_subgraph_size
        [out] predictor  AnalysePredictor
        """
        #ValueError: predict by TensorRT need use_gpu == True.
        if not use_gpu and not run_mode == 'fluid':
            raise ValueError(
                    "Predict by TensorRT mode: {}, expect use_gpu==True, but use_gpu == {}"
                .format(run_mode, use_gpu))
        if run_mode == 'trt_int8':
            raise ValueError("TensorRT int8 mode is not supported now, "
                             "please use trt_fp32 or trt_fp16 instead.")
        precision_map = {
            'trt_int8': fluid.core.AnalysisConfig.Precision.Int8,
            'trt_fp32': fluid.core.AnalysisConfig.Precision.Float32,
            'trt_fp16': fluid.core.AnalysisConfig.Precision.Half
        }
        config = fluid.core.AnalysisConfig(
            os.path.join(model_dir, '__model__'),
            os.path.join(model_dir, '__params__'))
        if use_gpu:
            # initial GPU memory(M), device ID
            config.enable_use_gpu(100, 0)
            # optimize graph and fuse op
            config.switch_ir_optim(True)
        else:
            config.disable_gpu()
    
        if run_mode in precision_map.keys():
            config.enable_tensorrt_engine(
                workspace_size=1 << 10,
                max_batch_size=batch_size,
                min_subgraph_size=min_subgraph_size,
                precision_mode=precision_map[run_mode],
                use_static=False,
                use_calib_mode=False)
    
        # disable print log when predict
        config.disable_glog_info()
        # enable shared memory
        config.enable_memory_optim()
        # disable feed, fetch OP, needed by zero_copy_run
        config.switch_use_feed_fetch_ops(False)
        predictor = fluid.core.create_paddle_predictor(config)
        return predictor

    def preprocess(self, im):
        """
        ͼ��Ԥ����
        ����Resize Normalize Permute PadStride�� 
        [in] img : img_file
        [out] inputs: dict ����
              im_info: dict shape����Ϣ
        """
        preprocess_ops = []
        for op_info in self.config.preprocess_infos:
            new_op_info = op_info.copy()
            op_type = new_op_info.pop('type')
            if op_type == 'Resize':
                new_op_info['arch'] = self.config.arch
            preprocess_ops.append(eval(op_type)(**new_op_info))
        im, im_info = preprocess(im, preprocess_ops)
        inputs = self.create_inputs(im, im_info, self.config.arch)
        return inputs, im_info

    def postprocess(self, np_boxes, np_masks, np_lmk, im_info, threshold=0.5):
        """
        ͼ�����
        [in] np_boxes, �������[class, score, x_min, y_min, x_max, y_max]
             np_masks
             np_lmk
             im_info
             threshold
        [out] results: dict
        """
        # postprocess output of predictor
        
        results = {}
        if np_lmk is not None:
            results['landmark'] = lmk2out(np_boxes, np_lmk, im_info, threshold)

        if self.config.arch in ['SSD', 'Face']:
            w, h = im_info['origin_shape']
            np_boxes[:, 2] *= h
            np_boxes[:, 3] *= w
            np_boxes[:, 4] *= h
            np_boxes[:, 5] *= w
        expect_boxes = (np_boxes[:, 1] > threshold) & (np_boxes[:, 0] > -1)
        np_boxes = np_boxes[expect_boxes, :]
        for box in np_boxes:
            logging.info('class_id:{:d}, confidence:{:.4f},'
                  'left_top:[{:.2f},{:.2f}],'
                  ' right_bottom:[{:.2f},{:.2f}]'.format(
                      int(box[0]), box[1], box[2], box[3], box[4], box[5]))
        results['boxes'] = np_boxes
        if np_masks is not None:
            np_masks = np_masks[expect_boxes, :, :, :]
            results['masks'] = np_masks
        return results

    def create_inputs(self, im, im_info, model_arch='YOLO'):
        """
        ���ݲ�ͬ��ģ�����Ͳ�����ͬ������
        [in] im: image np.ndarray
             im_info: dict ͼ����Ϣ
             model_arch: ģ�ͽṹ
        [out] inputs: dict ģ����������

        """
        inputs = {}
        inputs['image'] = im
        #logging.info("im shape:{}".format(np.shape(im)))
        origin_shape = list(im_info['origin_shape'])
        resize_shape = list(im_info['resize_shape'])
        pad_shape = list(im_info['pad_shape']) if im_info[
            'pad_shape'] is not None else list(im_info['resize_shape'])
        scale_x, scale_y = im_info['scale']
        if 'YOLO' in model_arch:
            im_size = np.array([origin_shape]).astype('int32')
            #logging.info("im_size shape:{}".format(np.shape(im_size)))
            inputs['im_size'] = im_size
        elif 'RetinaNet' in model_arch or 'EfficientDet' in model_arch:
            scale = scale_x
            im_info = np.array([pad_shape + [scale]]).astype('float32')
            inputs['im_info'] = im_info
        elif ('RCNN' in model_arch) or ('FCOS' in model_arch):
            scale = scale_x
            im_info = np.array([pad_shape + [scale]]).astype('float32')
            im_shape = np.array([origin_shape + [1.]]).astype('float32')
            inputs['im_info'] = im_info
            inputs['im_shape'] = im_shape
        elif 'TTF' in model_arch:
            scale_factor = np.array([scale_x, scale_y] * 2).astype('float32')
            inputs['scale_factor'] = scale_factor
        elif 'SOLOv2' in model_arch:
            scale = scale_x
            im_info = np.array([resize_shape + [scale]]).astype('float32')
            inputs['im_info'] = im_info
        return inputs

    def predict(self,
                image,
                threshold=0.5,
                run_benchmark=False):
        """
        ͨ�õĺ���Ԥ�����
        [in] image: str/np.ndarray ͼ��·�����߾���CV2�������ͼ�����
             threshold: float ��ֵ
             run_benchmark: bool  whether postprecoss
        [out] results: dict ��� boxes shape [N,6]
              [class, score, x_min, y_min, x_max, y_max]
              MaskRCNN's results include 'masks': np.ndarray:
              shape:[N, class_num, mask_resolution, mask_resolution]

        """
        inputs, im_info = self.preprocess(image)
        np_boxes, np_masks, np_lmk = None, None, None
        if self.config.use_python_inference:
            t1 = time.time()
            outs = self.executor.run(self.program,
                                     feed=inputs,
                                     fetch_list=self.fecth_targets,
                                     return_numpy=False)
            t2 = time.time()
            ms = (t2 - t1) * 1000.0
            logging.info("Inference: {} ms per batch image".format(ms))
            np_boxes = np.array(outs[0])
            if self.config.mask_resolution is not None:
                np_masks = np.array(outs[1])
        else:
            input_names = self.predictor.get_input_names()
            for i in range(len(input_names)):
                input_tensor = self.predictor.get_input_tensor(input_names[i])
                input_tensor.copy_from_cpu(inputs[input_names[i]])

            t1 = time.time()
            self.predictor.zero_copy_run()
            output_names = self.predictor.get_output_names()
            boxes_tensor = self.predictor.get_output_tensor(output_names[0])
            np_boxes = boxes_tensor.copy_to_cpu()
            if self.config.mask_resolution is not None:
                masks_tensor = self.predictor.get_output_tensor(
                    output_names[1])
                np_masks = masks_tensor.copy_to_cpu()

            if self.config.with_lmk is not None and self.config.with_lmk == True:
                face_index = self.predictor.get_output_tensor(output_names[
                    1])
                landmark = self.predictor.get_output_tensor(output_names[2])
                prior_boxes = self.predictor.get_output_tensor(output_names[
                    3])
                np_face_index = face_index.copy_to_cpu()
                np_prior_boxes = prior_boxes.copy_to_cpu()
                np_landmark = landmark.copy_to_cpu()
                np_lmk = [np_face_index, np_landmark, np_prior_boxes]
            t2 = time.time()
            ms = (t2 - t1) * 1000.0
            logging.info("Inference: {} ms per batch image".format(ms))

        results = []
        if not run_benchmark:
            if reduce(lambda x, y: x * y, np_boxes.shape) < 6:
                logging.info('[WARNNING] No object detected.')
                results = {'boxes': np.array([])}
            else:
                results = self.postprocess(
                    np_boxes, np_masks, np_lmk, im_info, threshold=threshold)

        return results

    def predict_solov2(self,
                       image,
                       threshold=0.5,
                       run_benchmark=False):
        """
        SOLOV2 ����Ԥ�����
        [in] image: str/np.ndarray ͼ��·�����߾���CV2�������ͼ�����
             threshold: float ��ֵ
             run_benchmark: bool  whether postprecoss
        [out] dict: segm, label, score

        """ 
        inputs, im_info = self.preprocess(image)
        np_label, np_score, np_segms = None, None, None
        if self.config.use_python_inference:
            t1 = time.time()
            outs = self.executor.run(self.program,
                                     feed=inputs,
                                     fetch_list=self.fecth_targets,
                                     return_numpy=False)
            t2 = time.time()
            ms = (t2 - t1) * 1000.0
            logging.info("Inference: {} ms per batch image".format(ms))
            np_label, np_score, np_segms = np.array(outs[0]), np.array(outs[
                1]), np.array(outs[2])
        else:
            input_names = self.predictor.get_input_names()
            for i in range(len(input_names)):
                input_tensor = self.predictor.get_input_tensor(input_names[i])
                input_tensor.copy_from_cpu(inputs[input_names[i]])

            t1 = time.time()
            self.predictor.zero_copy_run()
            output_names = self.predictor.get_output_names()
            np_label = self.predictor.get_output_tensor(output_names[
                0]).copy_to_cpu()
            np_score = self.predictor.get_output_tensor(output_names[
                1]).copy_to_cpu()
            np_segms = self.predictor.get_output_tensor(output_names[
                2]).copy_to_cpu()
            t2 = time.time()
            ms = (t2 - t1) * 1000.0
            logging.info("Inference: {} ms per batch image".format(ms))

        results = []
        if not run_benchmark:
            return dict(segm=np_segms, label=np_label, score=np_score)
        return results

    def predict_image(self, img_list, out_file_dir, result_dict):
        """
        ͼƬԤ��
        [in] img_list: list, img_list
             out_file: dir, output dir
             result_dict: ״̬�ʵ�
        """
        for img in img_list:
            #SOLOv2���Լ���Ԥ�����̣�����ģ���������Ԥ������
            #�ڴ���ͼ��ͨ�������ʱ�򣬻��и���ͼƬ����ͨ����һ������
            #��������, �ݶ�pass

            try:
                if self.config.arch == "SOLOv2":
                    results = self.predict_solov2(img, self.config.draw_threshold)
                else:
                    results = self.predict(img, self.config.draw_threshold)

                self.visualize(
                        img,
                        results,
                        self.config.labels,
                        mask_resolution=self.config.mask_resolution,
                        output_dir=out_file_dir,
                        threshold=self.config.draw_threshold)
            except Exception as e:
                logging.info(e)
                results = {'boxes': np.array([])}

            for each_img_result in result_dict["result_list"]:
                if each_img_result["image_file"] == img.split("/")[-1]:
                    each_img_result["check_result"] = results

    def visualize(self,
                  image_file,
                  results,
                  labels,
                  mask_resolution=14,
                  output_dir='output/',
                  threshold=0.5):
        """
        ���ӻ�Ԥ����������ԭʼͼƬ
        visualize the predict result
        [in] image_file: image�ļ�
             results: ���dict
             labels: ��ǩ
             mask_resolution: mask
             output_dir: ����ļ�Ŀ¼
             threshold: ��ֵ
        """
        # visualize the predict result
        im = visualize_box_mask(
            image_file,
            results,
            labels,
            mask_resolution=mask_resolution,
            threshold=threshold)
        img_name = os.path.split(image_file)[-1]
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        out_path = os.path.join(output_dir, img_name)
        im.save(out_path, quality=95)
        logging.info("save result to: " + out_path)

    def check(self, img_file):
        """
        check,check��infer����������check�ǶԵ�һͼƬ��Ԥ�� 
        #���������ͼƬ�ļ�/url
        [in] img_file: url/.jpg .png ..
        """
        #url
        predict_image_list = list()
        result_dict = {
                "input_file": img_file,
                "result_list": list()
                }
        if img_file.startswith("https://"):
            output_path = img_file.split("/")[-1] + "_down/"
            url_down(img_file, output_path, result_dict)
            predict_image_list = get_img(output_path)
        else:
            origin_img = img_file.split("/")[-1]
            if not img_file.endswith(".jpg"):
                img_file = image_md5_process(img_file)
            predict_image_list.append(img_file)

            img_result = dict()
            img_result["image_file"] = img_file.split("/")[-1]
            img_result["url_status"] = "not"
            img_result["url"] = origin_img
            img_result["check_result"] = dict()
            result_dict["result_list"].append(img_result)

        self.predict_image(predict_image_list, out_file, result_dict)
        return result_dict

    def infer(self, input_file, out_file):
        """
        infer
        [in] input_file
             output_file
        """
        #��ʼ���ʵ䣬�ʵ��¼Ԥ����������׷��
        result_dict = {
                "input_file": input_file,
                "result_list": list()
                }
        info_dict = dict()
        img_list = get_img(input_file)
        predict_image_list = list()
        #������ΪͼƬurl�ļ�ʱ��
        #.txt url�ļ�
        if len(img_list) == 1:
            img_file_name = img_list[0]
            if img_file_name.endswith(".txt"):
                image_down_path_prefix = input_file.split("/")[-1].split(".")[0]
                image_down_path_dir = os.path.dirname(input_file)
                image_down_name_path = image_down_path_prefix + "_down/"
                image_down_path = os.path.join(image_down_path_dir, image_down_name_path)
                if not os.path.exists(image_down_path):
                    os.mkdir(image_down_path)
                multi_thread_down(result_dict, info_dict, \
                        img_file_name, image_down_path, thread_nums=400)
                predict_image_list = get_img(image_down_path)
        #��ʱ����ΪͼƬ�ļ�
        if len(result_dict["result_list"]) == 0:
            #��Ҫ�ж�ͼƬ�ļ��Ƿ�Ϊ.jpg
            #������ǵĻ���Ҫת��Ϊjpg
            for img in img_list:
                #��url down�׶Σ�����ͼƬ����ת��Ϊ.jpg������ͼƬ����Ҫ��ת��
                origin_img = img.split("/")[-1]
                if not img.endswith(".jpg"):
                    img = image_md5_process(img)
                predict_image_list.append(img)
                img_result = dict()
                img_result["image_file"] = img.split("/")[-1]
                img_result["url_status"] = "not"
                img_result["url"] = origin_img
                img_result["check_result"] = dict()
                result_dict["result_list"].append(img_result)
        #����Ԥ�����
        #��url down�׶Σ�����ͼƬ����ת��Ϊ.jpg������ͼƬ����Ҫ��ת��
        out_file_dirname = os.path.dirname(out_file)
        out_file_dir = os.path.join(out_file_dirname, "visual/")
        self.predict_image(predict_image_list, out_file_dir, result_dict)
        with open(out_file, "w") as fw:
            for each_result in result_dict["result_list"]:
                image_file_name = each_result["image_file"]
                image_file_url = each_result["url"]

                image_file_check = json.dumps(each_result, cls=ResultEncoder)
                #��info dictΪ��ʱ��������ΪͼƬ�ļ������Ϊ�ļ���->check
                if len(info_dict) == 0:
                    fw.write("%s\t%s\n" % (image_file_name, image_file_check))
                else:
                    #��info dict��Ϊ�գ�����Ϊurl,���Ϊurl��������Ϣ��check���
                    image_url_info = info_dict[image_file_url]
                    fw.write("%s\t%s\t%s\n" % (image_file_url, image_url_info, image_file_check))

if __name__ == "__main__":
    pass

