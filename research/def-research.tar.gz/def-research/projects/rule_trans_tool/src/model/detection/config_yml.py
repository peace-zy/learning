#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: shenhao02@baidu.com
  Date  : 21/05/11 19:11:00
  File  : config_yml.py
  Desc  : yml�����ļ����� 
"""
import os
import logging
import yaml

#֧�ֵ�ģ��
SUPPORT_MODELS = {
    'YOLO',
    'SSD',
    'RetinaNet',
    'EfficientDet',
    'RCNN',
    'Face',
    'TTF',
    'FCOS',
    'SOLOv2',
}

class Config(object):
    """
    ģ���ڵ��������л�����yml�ļ����ã�
    ���а���������һЩ����,config�����Ϊ�˶�ȡ��Щ����
    """
    def __init__(self, model_dir, cfg_name):
        """
        ������ʼ��infer_cfg.yml�ļ���ȡ����
        """
        # parsing Yaml config for Preprocess
        deploy_file = os.path.join(model_dir, cfg_name)
        with open(deploy_file) as f:
            yml_conf = yaml.safe_load(f)
        self.check_model(yml_conf)
        #ģ�ͽṹ
        self.arch = yml_conf['arch']
        #fluid or trt ��trt��ʱ����Ҫ��gpu
        self.mode = yml_conf['mode']
        #��ֵ
        self.draw_threshold = yml_conf['draw_threshold']
        #ͼƬԤ�����ʵ�
        self.preprocess_infos = yml_conf['Preprocess']
        #exe.run or analyseconfig
        self.use_python_inference = yml_conf['use_python_inference']
        self.min_subgraph_size = yml_conf['min_subgraph_size']
        self.labels = yml_conf['label_list']
        self.mask_resolution = None
        if 'mask_resolution' in yml_conf:
            self.mask_resolution = yml_conf['mask_resolution']
        self.with_lmk = None
        if 'with_lmk' in yml_conf:
            self.with_lmk = yml_conf['with_lmk']
        # print config
        self.print_config()

    def check_model(self, yml_conf):
        """
        ��ǰ���Դ�����ģ�ͽṹ
        Raises:
            ValueError: loaded model not in supported model type 
        """
        for support_model in SUPPORT_MODELS:
            if support_model in yml_conf['arch']:
                return True
        raise ValueError("Unsupported arch: {}, expect {}".format(yml_conf[
            'arch'], SUPPORT_MODELS))

    def print_config(self):
        """
        ���ý���log
        print config logging info
        """
        logging.info('-----------  Model Configuration -----------')
        logging.info('%s: %s' % ('Model Arch', self.arch))
        logging.info('%s: %s' % ('Use Paddle Executor', self.use_python_inference))
        logging.info('%s: ' % ('Transform Order'))
        for op_info in self.preprocess_infos:
            logging.info('--%s: %s' % ('transform op', op_info['type']))
        logging.info('--------------------------------------------')

if __name__ == "__main__":
    pass

