#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: shenhao02@baidu.com
  Date  : 21/05/10 18:51:58
  File  : __init__.py
  Desc  : ��ʼinit
"""

import sys

if __name__ == "__main__":
    pass

