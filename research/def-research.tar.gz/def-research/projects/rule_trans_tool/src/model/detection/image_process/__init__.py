#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: shenhao02@baidu.com
  Date  : 21/05/11 20:00:43
  File  : __init__.py
  Desc  : 
"""

import sys

if __name__ == "__main__":
    pass

