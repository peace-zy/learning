#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   20/11/30 19:52:26
Desc  :   LRģ��
"""
import os
import sys
import re
import math
import json
import logging
import codecs
from collections import defaultdict

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)

from common import Common

class LR(object):
    """LRģ��
    """
    def __init__(self):
        """��ʼ��
        """
        self.alpha_pattern = re.compile(ur'^[a-zA-Z]+$')
        self.alpha_num_pattern = re.compile(ur'^[a-zA-Z0-9]+$')

    def init_train(self, train_file_path, test_file_path, model_dir, output_dir, \
                    model_conf, word_segger, stopword_file='data/stopword_lr.txt'):
        """��ʼ��
        """
        self.train_file_path = train_file_path
        self.test_file_path = test_file_path
        self.model_dir = model_dir
        self.output_dir = output_dir
        self.model_conf = model_conf
        self.word_segger = word_segger
        self.stopword = Common.load_word_file(stopword_file)
        self.vocab = defaultdict(int)
        self.label_map_path = self.model_dir + self.model_conf["label_map_path"]
        self.label_id_dict = Common.load_map_dict(self.label_map_path)

    def init_infer(self, model_type, model_dir, model_conf, word_segger, stopword_file='data/stopword_lr.txt'):
        """��ʼ��
        """
        self.model_type = model_type
        self.model_dir = model_dir
        self.model_conf = model_conf
        self.word_segger = word_segger

        model_file = os.path.join(model_dir, model_conf['model_path'])
        feature_id_file = os.path.join(model_dir, model_conf['vocab_path'])

        self.stopword = Common.load_word_file(stopword_file)
        self.feature_dict = Common.load_vocab(feature_id_file)
        self.model_dict, self.model_feature_num = self.load_multiclass_lr_model_file(model_file)
        self.feature_dict_keys = set(self.feature_dict.keys())

    def init_diff(self, model_dir, model_conf, word_segger, stopword_file='data/stopword_lr.txt'):
        """��ʼ��
        """
        self.model_dir = model_dir
        self.model_conf = model_conf
        self.word_segger = word_segger

        model_file = os.path.join(model_dir, model_conf['model_path'])
        feature_id_file = os.path.join(model_dir, model_conf['vocab_path'])

        self.stopword = Common.load_word_file(stopword_file)
        self.feature_dict = Common.load_vocab(feature_id_file)
        self.model_dict, self.model_feature_num = self.load_multiclass_lr_model_file(model_file)
        self.feature_dict_keys = set(self.feature_dict.keys())

    def data_io(self, phase='train'):
        """����ʼ����
        Return:
            �����train��������vocab
        """
        self.vocab_path = self.model_dir + self.model_conf['vocab_path']
        if phase == 'train':
            self.train_ngram_path = self.output_dir + self.model_conf['train_ngram_path']
            self.train_format_path = self.output_dir + self.model_conf['train_format_path']

            # ѵ�����ݲ���ngram�ļ���vocab
            vocab_freq = defaultdict(int)
            with open(self.train_file_path, "r") as ftrain, \
                    open(self.train_ngram_path, "w") as fngram:
                for line in ftrain:
                    parts = line.strip("\n").decode("gb18030", "ignore").split("\t")
                    label_list = json.loads(parts[-1])
                    platform_label = str(label_list[0]["label"][0])
                    label_id = ""
                    if platform_label in self.label_id_dict:
                        label_id = self.label_id_dict[platform_label]
                    else:
                        logging.error("label: %s  not in map." % (platform_label))
                        sys.exit(1)
                    text = parts[0]
                    seg_list = self.word_segger.seg_words_unicode(text)
                    ngram_feature_set = self.ngram_feature(seg_list)
                    fngram.write("%s\t%s\n" % (str(label_id), " ".join(list(ngram_feature_set))))
                    for ngram_text in ngram_feature_set:
                        vocab_freq[ngram_text] += 1

            # �洢vocab
            count_tmp = 0
            with open(self.vocab_path, "w") as fvocab:
                for feature, freq in vocab_freq.items():
                    if freq >= self.model_conf.getint('min_freq'):
                        count_tmp += 1
                        fvocab.write("%d\t%s\t%d\n" % (count_tmp, feature, freq))

            # ѵ�����ݲ���format
            self.vocab = Common.load_vocab(self.vocab_path)
            with open(self.train_ngram_path, "r") as fngram, \
                    open(self.train_format_path, "w") as fformat:
                for line in fngram:
                    parts = line.strip("\n").decode("gb18030", "ignore").split("\t")
                    label = parts[0]
                    ngram_text = parts[1]
                    format_text = self.liblinear_format(ngram_text.split(" "))
                    fformat.write("%s\t%s\n" % (label, format_text))
        elif phase == 'test':
            self.test_ngram_path = self.output_dir + self.model_conf['test_ngram_path']
            self.test_format_path = self.output_dir + self.model_conf['test_format_path']
            self.vocab = Common.load_vocab(self.vocab_path)
            with open(self.test_file_path, "r") as ftest, \
                    open(self.test_ngram_path, "w") as fngram, \
                    open(self.test_format_path, "w") as fformat:
                for line in ftest:
                    parts = line.strip("\n").decode("gb18030", "ignore").split("\t")
                    label_list = json.loads(parts[-1])
                    platform_label = str(label_list[0]["label"][0])
                    label_id = ""
                    if platform_label in self.label_id_dict:
                        label_id = self.label_id_dict[platform_label]
                    else:
                        logging.error("label: %s  not in map." % (platform_label))
                        sys.exit(1)
                    text = parts[0]
                    seg_list = self.word_segger.seg_words_unicode(text)
                    ngram_feature_set = self.ngram_feature(seg_list)
                    fngram.write("%s\t%s\n" % (str(label_id), " ".join(list(ngram_feature_set))))
                    format_text = self.liblinear_format(list(ngram_feature_set))
                    fformat.write("%s\t%s\n" % (str(label_id), format_text))

    def train(self):
        """ѵ��
        """
        self.data_io(phase='train')
        train_args = " ".join(['./src/model/liblinear/train', '-s', 
                    self.model_conf['s'], 
                    self.train_format_path, 
                    self.model_dir + self.model_conf['model_path']])
        Common.shell_execute(train_args)

    def test(self):
        """����
        """
        self.data_io(phase='test')
        test_args = " ".join(['./src/model/liblinear/predict', '-b', 
                    self.model_conf['b'], 
                    self.test_format_path, 
                    self.model_dir + self.model_conf['model_path'],
                    self.output_dir + self.model_conf['test_output_path']])
        Common.shell_execute(test_args)

    def check(self, text, with_evidence=False):
        """Ԥ����
        text: unicode
        with_evidence: Ԥ�������Ƿ������֤��
        """
        seg_list = self.word_segger.seg_words_unicode(text)
        ngram_feature_set = self.ngram_feature(seg_list)
        hit_feature = ngram_feature_set & self.feature_dict_keys
        hit_feature_num = len(hit_feature)

        label_list = self.cal_multiclass_lr_predict(self.model_dict, self.model_feature_num, \
                                    self.feature_dict, hit_feature, with_evidence)
        if len(label_list) == 0:
            predict_label = 0
            predict_label_prob = 0.0
        else:
            predict_label = label_list[0][0]
            predict_label_prob = label_list[0][1]
        return predict_label, predict_label_prob

    def infer(self, infer_file, output_file):
        """��������check��������infer������ļ���Ԥ�⣬��check����Ե����ı���Ԥ��
        Args:
            infer_file:     ��Ԥ���ļ����������������ϣ����еڶ���Ϊ�ı�
            output_file:    Ԥ���ļ�����һ��Ϊģ��Ԥ���ļ�
        """
        with open(infer_file, "r") as fin, \
                codecs.open(output_file, "w", 'gb18030') as fout:
            for line in fin:
                line_unicode = line.strip("\n").decode("gb18030", "ignore")
                parts = line_unicode.split("\t")
                text = parts[0]
                text_label, text_pred = self.check(text)
                predict_label = str(text_label)
                predict_label_prob = str(text_pred)

                fout.write("\t".join([line_unicode, predict_label, predict_label_prob]) + "\n")

    def ngram(self, seg_list, n=3):
        """
        Args:
            seg_list:   �кôʵ�list
        Return:
            ngram:      set, ��seg_list����ngram
        """
        word_num = len(seg_list)
        ngram = set()
        for i in range(0, word_num):
            for j in range(1, n + 1):
                if i + j > word_num:
                    break
                word = "".join(seg_list[i: i + j])
                if len(word) > 1: #��������unicode���ȴ���1
                    ngram.add(word)
        return ngram

    def ngram_feature(self, token_list, ngram=3, feature_min_length=2):
        """�д�listתngram
        Args:
            token_list:   list, �д��б�
        Return:
            ngram:      set
        """
        # ȥ��ͣ�ô�
        valid_tokens = [x for x in token_list if len(x.strip()) != 0 and x not in self.stopword]

        # �����֡���ĸ���滻Ϊ�������
        format_tokens = list()
        prev_token = None
        for token in valid_tokens:
            if token.isnumeric():
                token = u"[NUM]"
                # ������������źϲ�
                # ��˸�token������
                if prev_token == token:
                    continue
            elif self.alpha_pattern.match(token):
                token = u"[ALPHA]"
                if prev_token == token:
                    continue
            elif self.alpha_num_pattern.match(token):
                token = u"[ALNUM]"
                if prev_token == token:
                    continue
            prev_token = token

            format_tokens.append(token)

        def token_ngram(token_list):
            """�����б�����ngram����
            [in] token_list: list[str], �����б�, unicode����
            [out] features: list[str], �����б�, unicode����
            """
            feature_set = set()
            # ����ngram����
            for start_pos in range(len(token_list)):
                cur_feature = ""
                for offset in range(min(len(token_list)-start_pos, ngram)):
                    cur_feature += token_list[start_pos + offset]
                    if len(cur_feature) >= feature_min_length:
                        feature_set.add(cur_feature)
            return feature_set

        return token_ngram(valid_tokens) | token_ngram(format_tokens)

        ## ����ngram����
        #for start_pos in range(len(valid_tokens)):
        #    cur_feature_list = [""]
        #    for offset in range(min(len(valid_tokens) - start_pos, ngram)):
        #        new_feature_list = list()
        #        cur_token = valid_tokens[start_pos + offset]
        #        for cur_feature in cur_feature_list:
        #            cur_feature += cur_token
        #            if len(cur_feature) >= feature_min_length:
        #                new_feature_list.append(cur_feature)
        #        # �жϵ�ǰ
        #        if cur_token.isnumeric():
        #            new_feature_list += ["%s[NUM]" % x for x in cur_feature_list if not x.endswith("[NUM]")]
        #        elif self.alpha_pattern.match(cur_token):
        #            new_feature_list += ["%s[ALPHA]" % x for x in cur_feature_list if not x.endswith("[ALPHA]")]
        #        elif self.alpha_num_pattern.match(cur_token):
        #            new_feature_list += ["%s[ALNUM]" % x for x in cur_feature_list if not x.endswith("[ALNUM]")]

        #        feature_set.update(new_feature_list)
        #        cur_feature_list = new_feature_list
        #return feature_set

    def liblinear_format(self, seg_list):
        """ngram�ı�תΪliblinear�����ʽ
        Args:
            seg_list:   ngram list
            vocab:      dict, ѵ���������Ĵʵ�
        Return:
            liblinear data format
        """
        wids = []
        for word in seg_list:
            if word in self.vocab:
                wids.append(self.vocab[word])
        wids.sort()
        return "\t".join(map(lambda x:str(x)+":1", wids))

    def load_multiclass_lr_model_file(self, file_name):
        """
        [in]  file_name: str, ģ���ļ���
        [out] model_dict: dict, str(label) -> list[����]
              model_feature_num: int, ģ��������
        """
        label_list = []
        model_dict = {}
        with open(file_name, "r") as f:
            line_num = 0
            for eachline in f:
                line_num += 1
                if line_num == 3:
                    for item in eachline.strip().split(" ")[1:]:
                        model_dict[item] = []
                        label_list.append(item)
                if line_num <= 6:
                    continue
                line = eachline.strip().split(" ")
                if len(label_list) > 2:
                    for i in range(0, len(label_list)):
                        key = label_list[i]
                        model_dict[key].append(float(line[i]))
                else:
                    key = label_list[0]
                    model_dict[key].append(float(line[0]))
                    key = label_list[1]
                    model_dict[key].append(-1.0 * float(line[0]))
        model_feature_num = line_num - 6
        return model_dict, model_feature_num

    def load_online_lr_model_file(self, model_file):
        """
        ����ģ����Ҫ��id \t feature \t v1 v2��ʽ
        ����Ǽ�������ģ�͸�ʽ���ļ�
        [in]  model_file
        [out] feature_dict, model_dict
        """
        feature_dict = {}
        model_dict = defaultdict(list)
        with open(model_file, "r")as fr:
            for line in fr:
                each_list = line.strip("\n").lower().decode("gb18030", "ignore").split("\t")
                index = int(each_list[0])
                feature = each_list[1]
                feature_value_parts = each_list[2].split(" ")
                if feature not in feature_dict:
                    feature_dict[feature] = index
                for i in range(len(feature_value_parts)):
                    model_dict[i].append(float(feature_value_parts[i]))
        return feature_dict, model_dict

    def cal_multiclass_lr_predict(self, model_dict, model_feature_num, feature_dict,
            hit_feature, with_evidence=False, top_k=10):
        """��������Ԥ����, ����Ԥ��ֵ����0.03�Ľ��list, ÿ��Ԫ��[id, name, val]
        [in]  model_dict: ģ�Ͳ���
              model_feature_num: ģ��������
              feature_dict: ����
              hit_feature: ���е�����
              with_evidence: �Ƿ񷵻�֤��
              top_k: ����֤����
        [out] label_list: Ԥ����
        """
        if with_evidence:
            evidence_label = {}
        predict_label = {}
        total = 0.0
        for k in model_dict:
            predict_label[k] = 0.0
            if with_evidence:
                evidence_label[k] = list()
            value = 0.0
            for f in hit_feature:
                fid = feature_dict[f]
                if fid > model_feature_num:
                    continue
                w = model_dict[k][fid - 1]
                value += -1.0 * w
                if with_evidence:
                    evidence_label[k].append((f, w))
            predict_label[k] += 1.0 / (1.0 + math.exp(value))
            total += predict_label[k]
        label_list = []
        for k, v in sorted(predict_label.items(), key = lambda d: d[1], reverse = True):
            val = "%.4f" % (v / total)
            if float(val) < 0.03:
                continue
            if with_evidence:
                evidence_str = "||".join(["%s(%.4f)" % (f, w) for f, w in \
                                sorted(evidence_label[k], key=lambda x:abs(x[1]), reverse=True)][:top_k])
                label_list.append([k, val, evidence_str])
            else:
                label_list.append([k, val])

        return label_list


if __name__ == "__main__":
    pass


