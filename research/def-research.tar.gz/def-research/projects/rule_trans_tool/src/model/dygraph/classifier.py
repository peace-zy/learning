#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   classifier.py
Author:   zhanghao55@baidu.com
Date  :   20/12/14 18:47:05
Desc  :   
"""

import os
import sys
import codecs
import logging
import numpy as np
import json
import paddle.fluid as F
import paddle.fluid.dygraph as D

from nets.ernie_for_sequence_classification import ErnieModelCustomized
from nets.gru import GRU
from nets.textcnn import TextCNN
from train_infer_utils import batch_infer
from train_infer_utils import eval as dygraph_eval
from train_infer_utils import infer as dygraph_infer
from train_infer_utils import train
from utils.data_io import get_data, load_model

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(_cur_dir, "../../"))
from model.tokenizers.ernie_tokenizer import ErnieTokenizer
from utils.label_encoder import LabelEncoder
from common import Common


def textcnn_init(model_conf):
    """�������ò�����ʼ��ģ��
    """
    textcnn_params = {
            "num_class": model_conf.getint("num_class"),
            "vocab_size": model_conf.getint("vocab_size"),
            }

    if "emb_dim" in model_conf:
        textcnn_params["emb_dim"] = model_conf.getint("emb_dim")

    if "num_filters" in model_conf:
        textcnn_params["num_filters"] = model_conf.getint("num_filters")

    if "fc_hid_dim" in model_conf:
        textcnn_params["fc_hid_dim"] = model_conf.getint("fc_hid_dim")

    if "num_channels" in model_conf:
        textcnn_params["num_channels"] = model_conf.getint("num_channels")

    if "win_size_list" in model_conf:
        textcnn_params["win_size_list"] = [int(x) for x in model_conf["win_size_list"].split("|")]

    if "is_sparse" in model_conf:
        textcnn_params["is_sparse"] = model_conf.getboolean("is_sparse")

    if "use_cudnn" in model_conf:
        textcnn_params["use_cudnn"] = model_conf.getboolean("use_cudnn")

    return TextCNN(**textcnn_params)


def gru_init(model_conf):
    """�������ò�����ʼ��ģ��
    """
    gru_params = {
            "num_class": model_conf.getint("num_class"),
            "vocab_size": model_conf.getint("vocab_size"),
            }

    if "emb_dim" in model_conf:
        gru_params["emb_dim"] = model_conf.getint("emb_dim")

    if "gru_dim" in model_conf:
        gru_params["gru_dim"] = model_conf.getint("gru_dim")

    if "fc_hid_dim" in model_conf:
        gru_params["fc_hid_dim"] = model_conf.getint("fc_hid_dim")

    if "is_sparse" in model_conf:
        gru_params["is_sparse"] = model_conf.getboolean("is_sparse")

    if "bi_direction" in model_conf:
        gru_params["bi_direction"] = model_conf.getboolean("bi_direction")

    return GRU(**gru_params)


def ernie_init(model_conf):
    """�������ò�����ʼ��ģ��
    """
    ernie_params = {
            "pretrain_dir_or_url": model_conf["pretrain_path"],
            "num_labels": model_conf.getint("num_class"),
            }
    return ErnieModelCustomized.from_pretrained(**ernie_params)


class Classifier(object):
    """paddle��̬ͼ������
    """
    def __init__(self):
        """��ʼ��
        """
        self.model_dict = {
                "textcnn": textcnn_init,
                "gru": gru_init,
                "ernie": ernie_init,
                }

    def init_train(self, train_file_path, test_file_path, output_dir, \
            model_type, model_dir, model_conf):
        """ѵ���׶γ�ʼ��
        """
        def gen_data_iter(data_path):
            """���ɸ��ļ����ݵĵ�����
            """
            def line_processor(line):
                """ÿ���ı��Ĵ�������
                """
                parts = line.strip("\n").split("\t")
                text = parts[0]
                label_list = json.loads(parts[-1])
                platform_label = str(label_list[0]["label"][0])
                label_id = ""
                if platform_label in self.label_id_dict:
                    label_id = self.label_id_dict[platform_label]
                else:
                    logging.error("label: %s  not in map." % (platform_label))
                    sys.exit(1)
                return (text, label_id)

            return get_data(data_path, read_func=line_processor)

        #train_data = list(get_data(self.train_file_path, read_func=line_processor))
        #eval_data = get_data(self.test_file_path, read_func=line_processor)
        self.label_map_path = model_dir + model_conf["label_map_path"]
        self.label_id_dict = Common.load_map_dict(self.label_map_path)

        _, train_label_list = zip(*gen_data_iter(train_file_path))

        self.label_encoder = LabelEncoder({x:int(x) for x in train_label_list}, isFile=False)
        self.label_encoder.save(os.path.join(model_dir, model_conf["label_id_path"]))

        with D.guard():
            self.model, self.tokenizer = self.init_model(
                    model_type, model_dir, model_conf, self.label_encoder.size())

            self.optimizer = F.optimizer.Adam(
                        learning_rate=model_conf.getfloat("learning_rate"),
                        parameter_list=self.model.parameters())
            logging.info("learning_rate : {}".format(model_conf.getfloat("learning_rate")))

        self.train_data = [(self.tokenizer.encode(x[0])[0], int(x[1])) for x in gen_data_iter(train_file_path)]
        self.eval_data = [(self.tokenizer.encode(x[0])[0], int(x[1]) )for x in gen_data_iter(test_file_path)]

        logging.info("train_data size: {}".format(len(self.train_data)))
        logging.info("test_data size: {}".format(len(self.eval_data)))

    def init_infer(self, model_type, model_dir, model_conf):
        """Ԥ��׶γ�ʼ��
        """
        self.label_encoder = LabelEncoder(
                os.path.join(model_dir, model_conf["label_id_path"]))

        with D.guard():
            self.model, self.tokenizer = self.init_model(
                    model_type, model_dir, model_conf, self.label_encoder.size())

    def init_model(self, model_type, model_dir, model_conf, num_class):
        """ģ�ͳ�ʼ��:ģ�ͺ�tokenizer
        """
        self.model_type = model_type
        self.model_dir = model_dir
        self.model_conf = model_conf

        tokenizer = ErnieTokenizer.from_pretrained(model_conf["vocab_path"])

        model_conf["num_class"] = str(num_class)
        model_conf["vocab_size"] = str(tokenizer.size())

        model = self.model_dict[model_type](model_conf)

        load_model(model, os.path.join(model_dir, model_conf["best_model_path"]))
        return model, tokenizer

    def train(self):
        """ѵ��
        """
        with D.guard():
            best_acc = train(self.model, self.optimizer,
                    self.train_data, self.eval_data, self.label_encoder, best_acc=0,
                    model_save_path=os.path.join(self.model_dir, self.model_conf["model_save_path"]),
                    best_model_save_path=os.path.join(self.model_dir, self.model_conf["best_model_path"]),
                    epochs=self.model_conf.getint("epoch"),
                    batch_size=self.model_conf.getint("batch_size"),
                    max_seq_len=self.model_conf.getint("max_seq_len"),
                    print_step=self.model_conf.getint("print_step"),
                    )
        logging.info("{} best train score: {}".format(self.model_type, best_acc))

    def test(self):
        """����
        """
        with D.guard():
            acc = dygraph_eval(self.model, self.eval_data, self.label_encoder)
        logging.info("{} final test score: {}".format(self.model_type, acc))

    def check(self, text):
        """Ԥ����
        text: unicode
        """
        text_id = self.tokenizer.encode(text)[0]
        with D.guard():
            logits = dygraph_infer(self.model, [text_id], is_tensor=False)[0]
        pred_label_id = np.argmax(logits)

        pred_label_name = self.label_encoder.inverse_transform(pred_label_id)
        pred_rate = logits[pred_label_id]
        return pred_label_name, pred_rate

    def infer(self, infer_file, output_file, batch_size=32):
        """��������check��������infer������ļ���Ԥ�⣬��check����Ե����ı���Ԥ��
        Args:
            infer_file:     ��Ԥ���ļ����������������ϣ����еڶ���Ϊ�ı�
            output_file:    Ԥ���ļ�����һ��Ϊģ��Ԥ���ļ�
        """
        def line_processor(line):
            """ÿ���ı��Ĵ�������
            """
            all_info = line.strip("\n")
            parts = all_info.split("\t")
            text = parts[0]
            return (self.tokenizer.encode(text)[0], all_info)

        # batch_inferԤ��ʱ��data_iter�ɴ������ǩ��Ϣ������ѱ�ǩ��Ϣ�滻�������ı�
        # ����֮�������
        infer_data_iter = get_data(infer_file, read_func=line_processor)
        with D.guard():
            pred_logits, text_list = batch_infer(self.model, infer_data_iter, batch_size=batch_size)

        pred_label_id = np.argmax(pred_logits, axis=-1)
        pred_label_prob = np.array(pred_logits)[range(np.array(pred_logits).shape[0]), pred_label_id]
        pred_label_name = [self.label_encoder.inverse_transform(x) for x in pred_label_id]

        with codecs.open(output_file, "w", 'gb18030') as wf:
            for label, text, prob in zip(pred_label_name, text_list, pred_label_prob):
                wf.write("%s\t%s\t%s\n" % (text, label, prob))


if __name__ == "__main__":
    pass
