#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   20/12/01 15:35:43
Desc  :   
"""
import sys
from model.liblinear.lr import LR
from model.dygraph.classifier import Classifier
import word_seg

class Train(object):
    """ģ��ѵ��
    """
    def __init__(self, train_file_path, test_file_path, model_dir, output_dir, \
                    model_type, model_conf, segdict_path="dict/chinese_gbk"):
        self.train_file_path = train_file_path
        self.test_file_path = test_file_path
        self.model_dir = model_dir
        self.output_dir = output_dir
        self.model_type = model_type
        self.model_conf = model_conf
        self.word_segger = word_seg.WordSeg(segdict_path)
        self.word_segger.init_wordseg_handle()

    def train(self):
        """ѵ�����
        """
        if self.model_type == 'lr':
            model_obj = LR()
            model_obj.init_train(self.train_file_path,
                            self.test_file_path,
                            self.model_dir,
                            self.output_dir,
                            self.model_conf,
                            self.word_segger)
            model_obj.train()
            model_obj.test()
        elif self.model_type in set(['textcnn', 'ernie', 'gru']):
            model_obj = Classifier()
            model_obj.init_train(self.train_file_path,
                    self.test_file_path,
                    self.output_dir,
                    self.model_type,
                    self.model_dir,
                    self.model_conf)
            model_obj.train()
            model_obj.test()
        elif self.model_type == 'bilstm':
            pass

    def destroy(self):
        """�ͷ��д�
        """
        self.word_segger.destroy_wordseg_handle()


if __name__ == "__main__":
    pass


