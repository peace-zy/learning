#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   20/12/01 15:35:43
Desc  :   
"""
import sys
import word_seg

class Infer(object):
    """ģ��Ԥ��
    """
    def __init__(self, model_dir, model_type, model_conf, segdict_path="dict/chinese_gbk"):
        self.model_dir = model_dir
        self.model_type = model_type
        self.model_conf = model_conf
        #import models
        m_module = __import__(self.model_conf["module_name"], fromlist = ["default"])
        m_class = getattr(m_module, self.model_conf["class_name"])
        self.model_obj = m_class()
        #ʹ���дʵ�ģ�ͳ�ʼ����ʱ�����Ҫ�ṩ�дʾ��
        cur_model_seg = model_conf.getboolean("wordseg")
        self.word_segger = word_seg.WordSeg(segdict_path)
        self.word_segger.init_wordseg_handle()
        if cur_model_seg:
            self.model_obj.init_infer(self.model_type, self.model_dir, self.model_conf, self.word_segger)
        else:
            self.model_obj.init_infer(self.model_type, self.model_dir, self.model_conf)

    def infer(self, infer_file, output_file):
        """�������
        """
        self.model_obj.infer(infer_file, output_file)

    def check(self, text):
        """check���
        """
        return self.model_obj.check(text)

    def destroy(self):
        """�ͷ��д�
        """
        self.word_segger.destroy_wordseg_handle()

if __name__ == "__main__":
    pass


