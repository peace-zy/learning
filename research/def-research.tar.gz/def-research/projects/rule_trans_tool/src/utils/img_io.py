#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: shenhao02@baidu.com
  Date  : 21/05/11 11:50:03
  File  : img_io.py
  Desc  : ͼƬ�ļ���ȡ 
"""
import os
import urllib
import requests
import logging
import os
import json
import concurrent.futures
import concurrent
import hashlib
import shutil
import numpy as np
from PIL import Image

class ResultEncoder(json.JSONEncoder):
    """
    result decoder
    ����array���д��json
    """
    def default(self, obj):
        """
        default
        np.integer->int
        np.floating->float
        np.array->list
        """
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return super(ResultEncoder, self).default(obj)

def get_img_name_list(data_path):
    """���ɹ������ݼ����ļ��б�
        ������ݼ���ַ���ļ����򷵻��б���ֻ�и��ļ���ַ
        ������ݼ���ַ��Ŀ¼���򷵻��б��а�����Ŀ¼�������ļ�����(����.jpg��ʽ)
    [in]  data_path : str, ���ݼ���ַ
    [out] file_list : list[str], ���ݼ��ļ������б�
    """
    from collections import deque
    file_list = list()
    path_stack = deque()
    path_stack.append(data_path)
    while len(path_stack) != 0:
        cur_path = path_stack.pop()
        # ���ȼ��ԭʼ�������ļ������ļ���
        if os.path.isdir(cur_path):
            #logging.debug("data path is directory.")
            files = os.listdir(cur_path)
            # �����ļ����е�ÿһ���ļ�
            for file_name in files:
                # ����ļ�����.��ͷ ˵�����ļ����� ���������������ļ�
                if len(file_name) == 0:
                    continue
                file_path = os.path.join(cur_path, file_name)
                path_stack.append(file_path)
        elif os.path.isfile(cur_path):
            #logging.info("data path is file. add to list.")
            file_list.append(cur_path)
        else:
            raise TypeError("unknown type of data path : %s" % cur_path)
    return file_list

def get_img(data_path):
    """
    ��ȡ�ļ��б�
    [in] data_path: file/dir
    [out] img_file_list: list
    """
    img_file_list = get_img_name_list(data_path)
    return img_file_list

def image_md5_process(image_file):
    """
    ����ͼƬ�ļ�������jpgͼƬת��Ϊ.jpg
    [in] image_file: �����ļ�
    [out] out_image: ����ļ�
    """
    img = open(image_file, 'rb')
    md5 = hashlib.md5(img.read()).hexdigest()
    output_path = "/".join(image_file.split("/")[:-1])
    md5_name = output_path + "/" + md5 + ".jpg"
    if not os.path.exists(md5_name):
        shutil.move(image_file, md5_name)
    else:
        os.remove(image_file)
    if os.path.getsize(md5_name) < 2048:
        os.remove(md5_name)
    try:
        fp = open(md5_name, 'rb')
        img = Image.open(fp)
        fp.close()
    except Exception as e:
        #('cant open with Image.open()', md5_name)
        logging.info(e)
        fp.close()
        os.remove(md5_name)
    return md5_name

def url_down(url, output_path, result_dict):
    """
    �ӵ�һurl ��ȡpicture
    [in] url
        output_path
        result_dict
    """
    kv={'user-agent':'Mozilla/5.0'}
    url_result = dict()
    url = url.strip()
    image_file_name = url.split('/')[-1]
    path = output_path + image_file_name + '.jpg'
    url_result["url"] = url
    url_result["check_result"] = dict()
    try:
        r=requests.get(url, timeout=30, headers=kv)
        r.raise_for_status()
        if not os.path.exists(path):
            with open(path, 'wb') as f:
                f.write(r.content)
            md5_name = image_md5_process(path)
            url_result["image_file"] = md5_name.split("/")[-1]
            url_result["url_status"] = "ok"
            result_dict["result_list"].append(url_result)
        else:
            os.remove(path)
    except Exception as e:
        logging.info(e)
        url_result["image_file"] = image_file_name
        url_result["url_status"] = "error"
        logging.info("get failed:{}".format(url))
        result_dict["result_list"].append(url_result)

def multi_thread_down(result_dict, info_dict, input_file, output_path, thread_nums=400):
    """
    ���̴߳�url�л�ȡͼƬ
    [in]  result_dict: ״̬�ʵ�
          info_dict: ��¼��Ϣ
          input_file: �����ļ�,1�У�ΪͼƬurl
          output_path: ����ļ�Ŀ¼,Ϊdownload�µ�ͼƬ�ļ�
          thread_nums: �߳�������Ĭ��400
    """
    if not os.path.exists(output_path):
        os.makedirs(output_path)
    logging.info("input_file: {}".format(input_file))
    logging.info("output_dir: {}".format(output_path))
    logging.info("thread nums : {}".format(thread_nums))
    kv={'user-agent':'Mozilla/5.0'}

    def downloader(url):
        """
        ����1��url down
        """
        url_result = dict()
        url = url.strip()
        image_file_name = url.split('/')[-1]
        path = output_path + image_file_name + '.jpg'
        url_result["url"] = url
        url_result["check_result"] = dict()
        try:
            r=requests.get(url, timeout=30, headers=kv)
            r.raise_for_status()
            if not os.path.exists(path):
                with open(path, 'wb') as f:
                    f.write(r.content)
                md5_name = image_md5_process(path)
                url_result["image_file"] = md5_name.split("/")[-1]
                url_result["url_status"] = "ok"
                result_dict["result_list"].append(url_result)
            else:
                os.remove(path)
        except Exception as e:
            logging.info(e)
            url_result["image_file"] = image_file_name
            url_result["url_status"] = "error"
            logging.info("get failed:{}".format(url))
            result_dict["result_list"].append(url_result)
    #���̻߳�ȡdownͼƬurl
    #���Ƚ�url������url�ļ�
    input_dirname = os.path.dirname(input_file)
    input_url_file = input_dirname + "/url.txt"
    with open(input_url_file, "w") as fw, open(input_file, "r") as fr:
        for line in fr:
            each_list = line.strip().split("\t")
            url = each_list[0]
            url_info = "\t".join(each_list[1:])
            info_dict[url] = url_info
            fw.write("%s\n" % (url))

    with concurrent.futures.ThreadPoolExecutor(max_workers=thread_nums) as executor:
        with open(input_url_file) as f:
            executor.map(downloader, f)
