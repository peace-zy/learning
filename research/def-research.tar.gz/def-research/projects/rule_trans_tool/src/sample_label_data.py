#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: shenhao02@baidu.com
  Date  : 21/06/01 20:39:29
  File  : sample_label_data.py
  Desc  : 
"""

import sys
import json
from sample.sampler import Sampler
from common import Common
from collections import defaultdict 

class SampleLabel(object):
    """
    ���ݳ���
    """
    def __init__(self, sample_nums):
        """
        """
        self.state_dict = defaultdict(lambda: Sampler(sample_nums, True))

    def text_sample(self, input_file, output_file):
        """
        ͨ�ó���
        """
        default_key = "none"
        with open(input_file, "r") as fr, open(output_file, "w") as fw:
            for line in fr:
                each_str = line.strip()
                each_list = each_str.split("\t")
                text = each_list[0]
                label_list = json.loads(each_list[-1])
                # ��ͼ��Ŀ�����У���label listΪ��ʱ��ΪĬ�ϱ�ǩ����û������
                if len(label_list) == 0:
                    cur_sampler = self.state_dict[default_key]
                    cur_sampler.put(each_str, key=text)
                    self.state_dict[default_key] = cur_sampler
                else:
                    for label_dict in label_list:
                        cur_label_list = label_dict["label"]
                        for cur_label in cur_label_list:
                            cur_sampler = self.state_dict[cur_label]
                            cur_sampler.put(each_str, key=text)
                            self.state_dict[cur_label] = cur_sampler

            for each_label, each_sampler in self.state_dict.items():
                for data_str in each_sampler.get_sample_list():
                    fw.write("%s\n" % (data_str))

if __name__ == "__main__":
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    model_conf = "./data/config.ini"
    config = Common.read_config(model_conf)
    sample_nums = int(sys.argv[3])
    sample_label = SampleLabel(sample_nums)
    sample_label.text_sample(input_file, output_file)
