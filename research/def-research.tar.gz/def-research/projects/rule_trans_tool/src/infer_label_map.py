#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: shenhao02@baidu.com
  Date  : 21/06/17 15:28:55
  File  : src/infer_label_map.py
  Desc  : 
"""

import sys
import logging
import json
from common import Common

class InferDataMap(object):
    """
    ��Ԥ����label����ӳ��
    """
    def __init__(self, input_file, output_file):
        """
        ��ʼ��
        """
        self.input_file = input_file
        self.output_file = output_file

    def init(self, label_map_path):
        """
        ����ӳ���
        """
        self.label_id_dict = Common.load_map_dict(label_map_path)
        self.id_label_dict = {v: k for k, v in self.label_id_dict.items()}

    def text_map(self):
        """
        �ı�ӳ��
        """
        with open(self.input_file, "r") as fr, open(self.output_file, "w") as fw:
            for line in fr:
                each_list = line.strip().split("\t")
                predict_label = each_list[-2]
                predict_label_pred = each_list[-1]
                if predict_label not in self.id_label_dict:
                    logging.error("label: %s  not in map." % (predict_label))
                    sys.exit(1)

                map_platform_label = self.id_label_dict[predict_label]
                result_label_list = list()
                result_label_dict = {
                        "label": list(),
                        "score": list()
                        }
                result_label_dict["label"].append(int(map_platform_label))
                result_label_dict["score"].append(float(predict_label_pred))
                result_label_list.append(result_label_dict)
                fw.write("\t".join(["\t".join(each_list[:-2]), json.dumps(result_label_list)]) + "\n")

    def image_map(self):
        """
        ͼƬӳ��
        """
        with open(self.input_file, "r") as fr, open(self.output_file, "w") as fw:
            for line in fr:
                each_list = line.strip().split("\t")
                predict_label_dict = json.loads(each_list[-1])
                predict_check_result = predict_label_dict["check_result"]
                result_label_list = list()
                if len(predict_check_result) > 0:
                    predict_check_boxes = predict_check_result["boxes"]
                    for check_list in predict_check_boxes:
                        result_check_dict = dict()
                        label_list = list()
                        score_list = list()
                        check_label = int(check_list[0])
                        check_prob = float(check_list[1])
                        check_x_min = float(check_list[2])
                        check_y_min = float(check_list[3])
                        check_x_max = float(check_list[4])
                        check_y_max = float(check_list[5])
                        check_w = check_y_max - check_y_min
                        check_h = check_x_max - check_x_min
                        map_platform_label = check_label
                        if str(check_label) in self.id_label_dict:
                            map_platform_label = int(self.id_label_dict[str(check_label)])
                        else:
                            logging.error("label: %s  not in map." % (str(check_label)))
                            sys.exit(1)
                        label_list.append(map_platform_label)
                        score_list.append(check_prob)
                        result_check_dict["x"] = check_x_min
                        result_check_dict["y"] = check_y_min
                        result_check_dict["w"] = check_w
                        result_check_dict["h"] = check_h
                        result_check_dict["label"] = label_list
                        result_check_dict["score"] = score_list
                        result_label_list.append(result_check_dict)
                fw.write("\t".join(["\t".join(each_list[:-1]), json.dumps(result_label_list)]) + "\n")

if __name__ == "__main__":
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    label_map_path = sys.argv[3]
    model_type = sys.argv[4]
    infer_data_map = InferDataMap(input_file, output_file)
    infer_data_map.init(label_map_path)
    common_config = Common.read_config("./data/config.ini")
    model_diff_config = common_config["model_diff"]
    text_algorithm_list = model_diff_config["text_algorithm"].split(",")
    image_algorithm_list = model_diff_config["image_algorithm"].split(",")
    if model_type in image_algorithm_list:
        infer_data_map.image_map()
    elif model_type in text_algorithm_list:
        infer_data_map.text_map()
    else:
        logging.error("model type: %s not in list" % (model_type))

