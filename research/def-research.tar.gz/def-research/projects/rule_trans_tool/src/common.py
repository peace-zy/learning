#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   20/11/30 18:29:02
Desc  :   common��
"""
import os
import sys
import json
import subprocess
import random
import configparser

class Common(object):
    """ͨ�ú�����
    """
    def __init__(self):
        """init
        """
        pass

    @staticmethod
    def shell_execute(cmd_str):
        """ִ��shell������
        Args:
            cmd_str:        str, ������
        Return:
            ִ�н��
        Attention:
            subprocess.call()�����������3����
            �ֱ���0��1��2������0������ȷִ�У�
            1��2���Ǵ���ִ�У�2ͨ����û�ж�ȡ���ļ���1�ķ���Ŀǰδ֪
        """
        return subprocess.call(cmd_str, shell=True)

    @staticmethod
    def get_label_json_map(input_file, label_map_path):
        """
        ���������list���ͱ�ǩ�����ѵ����ͨ�ñ�ǩ
        [in]: input_file: text, 1(�ؼ���)/2(����), [{"label": [48]}]
        [out]: label_map_path: 48->0  ����48Ϊƽ̨���ṩ��labelid
        """
        label_lists = list()
        label_id_dict = dict()
        try:
            with open(input_file, "r") as fr:
                for line in fr:
                    each_list = line.strip().split("\t")
                    label_list = json.loads(each_list[-1])
                    platform_label_list = label_list[0]["label"]
                    for p_label in platform_label_list:
                        label_lists.append(p_label)
            for label in label_lists:
                if label in label_id_dict:
                    continue
                label_id_dict[label] = len(label_id_dict)

            with open(label_map_path, "w") as fw:
                for label, label_id in label_id_dict.items():
                    fw.write("\t".join([str(label), str(label_id)])+ "\n")
        except Exception as e:
            return False
        return True

    @staticmethod
    def load_map_dict(label_map_path):
        """
        ����ƽ̨��labelid �� ģ�� label ֮���ӳ���ϵ
        """
        label_id_dict = dict()
        with open(label_map_path, "r") as fr:
            for line in fr:
                each_list = line.strip().split("\t")
                label = each_list[0]
                label_id = each_list[1]
                if label not in label_id_dict:
                    label_id_dict[label] = label_id
        return label_id_dict

    @staticmethod
    def random_split_file(input_file, train_file, test_file, partition=0.8):
        """��������ļ�
        Args:
            input_file:     �ļ�����һ��label���ڶ���text��
            train_file:     ѵ���ļ���ռ��partition
            test_file:      �����ļ���ռ��1-partition
            partition:      ������Ĭ��8:2
        Return:
            True/False
        """
        try:
            with open(input_file, "r") as inf, \
                    open(train_file, "w") as trf, \
                    open(test_file, "w") as tsf:
                for line in inf:
                    randnum = random.random()
                    if randnum < partition:
                        trf.write(line)
                    else:
                        tsf.write(line)
        except:
            return False
        return True

    @staticmethod
    def load_word_file(file_name):
        """
        Args:
            file_name:      str, �ļ���
        Return:
            word:           set, Сд, unicode
        """
        word = set()
        with open(file_name, "r") as f:
            for eachline in f:
                line = eachline.lower().decode("gb18030", "ignore").strip("\n")
                word.add(line)
        return word

    @staticmethod
    def load_vocab(file_name):
        """�ʵ�
        Args:
            file_name:  str, �ļ���
        Return:
            vocab:      dict, unicode
        """
        vocab = {}
        with open(file_name) as f:
            for line in f:
                line = line.strip().decode("gbk", "ignore")
                cols = line.split("\t")
                index = int(cols[0])
                word  = cols[1]
                freq  = cols[2]
                vocab[word] = index
        return vocab

    @staticmethod
    def read_config(config_file):
        """��ȡ�����ļ�
        """
        config = configparser.ConfigParser()
        config._interpolation = configparser.ExtendedInterpolation()
        config.read(config_file, encoding="gb18030")
        return config


if __name__ == "__main__":
    pass


