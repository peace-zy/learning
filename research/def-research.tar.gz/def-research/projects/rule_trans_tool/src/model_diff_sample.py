#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: shenhao02@baidu.com
  Date  : 21/06/16 11:50:42
  File  : model_diff_sample.py
  Desc  : 
"""

import sys
import logging
import json
import os
import codecs
from sample.sampler import Sampler
from collections import defaultdict
from common import Common

class ModelDiffSample(object):
    """
    ģ��diff������
    """
    def __init__(self, input_file, output_path, config):
        """
        ��ʼ��
        [in] input_file: �����ļ�
             output_path: ���Ŀ¼
             config: ����
        """
        self.input_file = input_file
        self.output_path = output_path
        self.diff_conf = config

    def get_all_label(self):
        """
        ��ȡ����ģ�����е�label
        """
        #���Ȼ��label�б�,Ϊ��ҲҪ���ǵ�
        default_key = -1
        label_set = set()
        with open(self.input_file, "r") as fr:
            for line in fr:
                each_str = line.strip()
                each_list = each_str.split("\t")
                old_label_list = json.loads(each_list[-2])
                new_label_list = json.loads(each_list[-1])
                # ��ͼ��Ŀ�����У���label listΪ��ʱ��ΪĬ�ϱ�ǩ����û������
                if len(old_label_list) == 0 or len(new_label_list) == 0:
                    label_set.add(default_key)
                for label_dict in old_label_list:
                    cur_label_list = label_dict["label"]
                    for cur_label in cur_label_list:
                        label_set.add(cur_label)

                for label_dict in new_label_list:
                    cur_label_list = label_dict["label"]
                    for cur_label in cur_label_list:
                        label_set.add(cur_label)
        return label_set

    def get_sample_diff(self, is_sample=False):
        """
        ��������
        """
        #���Ȼ��label�б�,Ϊ��ҲҪ���ǵ�
        all_label_set = self.get_all_label()
        label_sample_dict = defaultdict(list)
        o1_n1 = "\x01".join(["1", "1"])
        o1_n0 = "\x01".join(["1", "0"])
        o0_n1 = "\x01".join(["0", "1"])
        o0_n0 = "\x01".join(["0", "0"])

        with open(self.input_file, "r") as fr:
            for line in fr:
                line_str = line.strip()
                parts = line_str.split("\t")
                old_label_list = json.loads(parts[-2])
                new_label_list = json.loads(parts[-1])
                for each_label in all_label_set:
                    old_label_fit = "0"
                    new_label_fit = "0"
                    #��Ҫ�ж�Ϊ�յ�����
                    if each_label == -1:
                        if len(old_label_list) == 0:
                            old_label_fit = "1"
                        if len(new_label_list) == 0:
                            new_label_fit = "1"
                    else:
                        #��ʱ��Ϊ�յ��ж�
                        #��ģ��
                        for old_label_dict in old_label_list:
                            cur_old_label_list = old_label_dict["label"]
                            if each_label in cur_old_label_list:
                                old_label_fit = "1"
                                break
                        #��ģ��
                        for new_label_dict in new_label_list:
                            cur_new_label_list = new_label_dict["label"]
                            if each_label in cur_new_label_list:
                                new_label_fit = "1"
                                break
                    #���ģ��label��prob
                    out_data_str = "\t".join([old_label_fit, new_label_fit, line_str])
                    label_sample_dict[each_label].append(out_data_str)

        for each_label in all_label_set:
            #������Ϊÿһ��label
            if is_sample:
                state_list = [o1_n1, o1_n0, o0_n1, o0_n0]
                #����
                sample_nums = self.diff_conf.getint("sample_nums")
                stat_dict = defaultdict(lambda: {
                    "0": (Sampler(sample_nums), 0),
                    "1": (Sampler(sample_nums), 0),
                    })
                for each_data_str in label_sample_dict[each_label]:
                    data_parts = each_data_str.strip().split("\t")
                    old_model_fit = data_parts[0]
                    new_model_fit = data_parts[1]
                    cur_sampler, cur_count = stat_dict[old_model_fit][new_model_fit]
                    cur_sampler.put(each_data_str)
                    cur_count += 1
                    stat_dict[old_model_fit][new_model_fit] = (cur_sampler, cur_count)
                #���ﱣ�浽list��ҪΪ��������ݸ�ʽΪsample+count��ҲΪ�˲�Ƶ����д�ļ�
                cur_count_list = list()
                cur_sample_list = list()
                for old_model_fit, model_fit_dict in stat_dict.items():
                    for new_model_fit, (cur_sampler, cur_count) in model_fit_dict.items():
                        key = "\x01".join([old_model_fit, new_model_fit])
                        state_list.remove(key)
                        #label_key = each_label
                        cur_count_list.append("\t".join([key, "count", old_model_fit, new_model_fit, str(cur_count)]))
                        for data_str in cur_sampler.get_sample_list():
                            cur_sample_list.append("\t".join([key, "sample", data_str]))
                if len(state_list) > 0:
                    for each_state in state_list:
                        cur_count_list.append("\t".join([each_state, "count", each_state.split("\x01")[0], \
                                              each_state.split("\x01")[1], "0"]))
                output_sample_file_name = "label_{}_diff_sample.txt".format(each_label)
                output_sample_file = os.path.join(self.output_path, output_sample_file_name)
                with open(output_sample_file, "w") as fsw:
                    for sample_str in cur_sample_list:
                        fsw.write("%s\n" % (sample_str))
                    for count_str in cur_count_list:
                        fsw.write("%s\n" % (count_str))
            #�ǳ���
            output_file_name = "label_{}_diff.txt".format(each_label)
            output_file = os.path.join(self.output_path, output_file_name)
            with open(output_file, "w") as fw:
                for each_data_str in label_sample_dict[each_label]:
                    fw.write("%s\n" % (each_data_str))

if __name__ == "__main__":
    input_file = sys.argv[1]
    output_path = sys.argv[2]
    common_config = Common.read_config("./data/config.ini")
    model_diff_config = common_config["model_diff"]
    model_diff_sample = ModelDiffSample(input_file, output_path, model_diff_config)
    model_diff_sample.get_sample_diff(is_sample=True)


