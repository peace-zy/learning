#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: shenhao02@baidu.com
  Date  : 21/04/23 11:51:55
  File  : sample_diff.py
  Desc  : 
"""
import sys
import os
import codecs
import json
from sampler import Sampler
from collections import defaultdict
_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(_cur_dir, "../"))
from utils.img_io import ResultEncoder, get_img, multi_thread_down

class SampleDiff(object):
    """
    diff������
    """
    def __init__(self, old_model_obj, new_model_obj, model_conf):
        """
        ��ʼ��
        [in] old_model_obj: ��ģ��
             new_model_obj: ��ģ��
             model_conf:    ��Ӧ����
        """
        self.old_model_obj = old_model_obj
        self.new_model_obj = new_model_obj
        self.diff_conf = model_conf

    def get_model_result_image(self, input_file, output_file):
        """
        ��Ҫ����¾�ģ�͵�Ԥ����
        [in] input_file: �����ļ�
             output_file: ����ļ�
        """
        #ͼ��һ��Ҫ��down
        result_dict = {
                "input_file": input_file,
                "result_list": list()
                }
        info_dict = dict()
        #������diff��֤��ʱ��,��Ҫdown url�ļ�
        predict_image_list = list()
        image_down_path_prefix = input_file.split("/")[-1].split(".")[0]
        image_down_path_dir = os.path.dirname(input_file)
        image_down_name_path = image_down_path_prefix + "_down/"
        image_down_path = os.path.join(image_down_path_dir, image_down_name_path)
        if not os.path.exists(image_down_path):
            os.mkdir(image_down_path)
        multi_thread_down(result_dict, info_dict, \
                input_file, image_down_path, thread_nums=400)
        predict_image_list = get_img(image_down_path)
        #ͼ����Ҫdown, ��Ҫ�������ļ�is_down
        out_file_dirname = os.path.dirname(output_file)
        out_old_file_dir = os.path.join(out_file_dirname, "old_visual/")
        out_new_file_dir = os.path.join(out_file_dirname, "new_visual/")
        #��ʱ��Ҫ�Խ������Ԥ�⣬�ֱ�Ϊ�¾�����ģ��
        result_old_dict = result_dict
        result_new_dict = result_dict
        self.old_model_obj.predict_image(predict_image_list, out_old_file_dir, result_old_dict)
        self.new_model_obj.predict_image(predict_image_list, out_new_file_dir, result_new_dict)
        check_result_old = dict()
        #�ϲ�Ԥ����
        for each_result in result_old_dict["result_list"]:
            image_file_name = each_result["image_file"]
            image_file_url = each_result["url"]
            image_file_check = json.dumps(each_result, cls=ResultEncoder)
            if len(info_dict) == 0:
                each_key = image_file_name
            else:
                image_url_info = info_dict[image_file_url]
                each_key = "\t".join([image_file_url, image_url_info])
            if each_key not in check_result_old:
                check_result_old[each_key] = image_file_check

        for each_result in result_new_dict["result_list"]:
            image_file_name = each_result["image_file"]
            image_file_url = each_result["url"]
            image_file_check = json.dumps(each_result, cls=ResultEncoder)
            if len(info_dict) == 0:
                each_key = image_file_name
            else:
                image_url_info = info_dict[image_file_url]
                each_key = "\t".join([image_file_url, image_url_info])

        with open(output_file, "w") as fw:
            for each_result in result_new_dict["result_list"]:
                image_file_name = each_result["image_file"]
                image_file_url = each_result["url"]
                image_file_check = json.dumps(each_result, cls=ResultEncoder)
                if len(info_dict) == 0:
                    each_key = image_file_name
                else:
                    image_url_info = info_dict[image_file_url]
                    each_key = "\t".join([image_file_url, image_url_info])
                if each_key not in check_result_old:
                    raise "url key result error"
                fw.write("%s\t%s\t%s\n" % (each_key, check_result_old[each_key], image_file_check))

    def get_model_result_text(self, input_file, output_file):
        """
        ��Ҫ����¾�ģ�͵�Ԥ����
        [in] input_file: �����ļ�
             output_file: ����ļ�
        """
        with open(input_file, "r") as fr, open(output_file, "w") as fw:
            for line in fr:
                line_unicode = line.strip().decode("gb18030")
                parts = line_unicode.split("\t")
                text = parts[0]
                #old & new check
                old_label, old_label_pred = self.old_model_obj.check(text)
                new_label, new_label_pred  = self.new_model_obj.check(text)
                out_str = "\t".join(["\t".join(parts), str(old_label), \
                                    str(old_label_pred), str(new_label), str(new_label_pred)])
                fw.write(out_str + "\n")

