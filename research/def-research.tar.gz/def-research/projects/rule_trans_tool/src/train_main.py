#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   20/11/26 18:29:52
Desc  :   ģ��ѵ�����
          python src/train_main.py --input_file tmp/input_label.txt --model_type lr --model_dir output/test_model/
"""
import sys
import argparse
import logging

from common import Common
from train import Train

def args_func():
    """�������
    """
    parser = argparse.ArgumentParser(description = "dragon_rule_model_train")
    parser.add_argument("-f", "--input_file", \
            help = "�����ļ����������У���һ��Ϊlabel���ڶ���Ϊtext(δ�����ı�)", \
            required = True)
    parser.add_argument("-m", "--model_type", \
            # lr bilist textcnn fasttext ernie
            help = "����ѵ�����õ�ģ������", \
            default = "lr", \
            required = True)
    parser.add_argument("-c", "--model_conf", \
            help = "����ѵ��Ĭ�ϵ�ģ�Ͳ���conf��ַ", \
            default = "data/config.ini")
    parser.add_argument("-o", "--model_dir", \
            help = "���ָ������ô�趨Ϊ����ѵ��������ģ�͵�ַ", \
            required = True)
    parser.add_argument("-t", "--output_dir", \
            help = "�м��ļ���ַ", \
            required = True)

    args = parser.parse_args()
    return args

def clear(file_path):
    """�������½��ļ�
    """
    cmd_str = "rm -rf %s; mkdir %s" % (file_path, file_path)
    logging.info("execute cmd: %s" % cmd_str)
    if Common.shell_execute(cmd_str) != 0:
        logging.error("clear file path failed.")
        sys.exit(1)

def exe_func(args):
    """ִ������
    """
    logging.info("input file path: %s" % (args.input_file))
    logging.info("model file path: %s" % (args.model_dir))
    logging.info("output file path: %s" % (args.output_dir))
    logging.info("read config from file: %s" % args.model_conf)
    config = Common.read_config(args.model_conf)
    #clear(args.model_dir)
    #clear(args.output_dir)
    #label ӳ�䴦��
    label_map_path = args.model_dir + config['DEFAULT']['label_map_path']
    if Common.get_label_json_map(args.input_file, label_map_path):
        logging.info("input file: %s, map label path: %s" \
                % (args.input_file, label_map_path))
    else:
        logging.error("get label map failed.")
        sys.exit(1)
    # ���ѵ���Ͳ����ļ�
    train_file_path = args.output_dir + config['DEFAULT']['train_file_path']
    test_file_path = args.output_dir + config['DEFAULT']['test_file_path']
    if Common.random_split_file(args.input_file, train_file_path, test_file_path):
        logging.info("origin train file: %s, origin test file: %s" \
                % (train_file_path, test_file_path))
    else:
        logging.error("random_split_file execute failed.")
        sys.exit(1)

    logging.info("train start")
    train_obj = Train(train_file_path, test_file_path, args.model_dir, \
            args.output_dir, args.model_type, config[args.model_type])
    train_obj.train()
    train_obj.destroy()
    logging.info("train end")


if __name__ == "__main__":
    # ����Ĭ��logging
    format_str = "%(levelname)s: %(asctime)s: %(filename)s:%(lineno)d * %(message)s"
    datefmt = "%m-%d %H:%M:%S"
    formatter = logging.Formatter(format_str, datefmt)
    logging.basicConfig(level=logging.DEBUG, format=format_str)

    args = args_func()
    exe_func(args)

