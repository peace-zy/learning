#!/usr/bin/env python
# -*- coding:gbk -*-
"""
  Author: shenhao02@baidu.com
  Date  : 21/04/22 15:24:15
  File  : model_diff.py
  Desc  : diff�Ա�ģ�ͣ���ʱ�Ȳ������ѧϰģ��,��ʱ֧��LR
"""
import sys
import os
import codecs
from sample.sample_diff import SampleDiff 
import word_seg

class ModelDiff(object):
    """ģ��Ԥ��
    """
    def __init__(self, old_model_type, old_model_dir, new_model_type, \
                 new_model_dir, model_conf, segdict_path="dict/chinese_gbk"):
        """
        [in] old_model_type: ��ģ������
             new_model_type: ��ģ������
             old_model_dir: ��ģ��·��
             new_model_dir: ��ģ��·��
             model_conf : ����
             segdict_path: �дʰ�
        """
        #common config
        self.common_conf = model_conf
        self.word_segger = word_seg.WordSeg(segdict_path)
        self.word_segger.init_wordseg_handle()
        #��ģ����Ӧ����
        self.old_model_dir = old_model_dir
        self.old_model_type = old_model_type
        self.old_model_conf = self.common_conf[self.old_model_type]
        old_model_seg = self.old_model_conf.getboolean("wordseg")
        old_m_module = __import__(self.old_model_conf["module_name"], fromlist = ["default"])
        old_m_class = getattr(old_m_module, self.old_model_conf["class_name"])
        self.old_model_obj = old_m_class()
        #��ģ����Ӧ����
        self.new_model_dir = new_model_dir
        self.new_model_type = new_model_type
        self.new_model_conf = self.common_conf[self.new_model_type]
        new_model_seg = self.new_model_conf.getboolean("wordseg")
        new_m_module = __import__(self.new_model_conf["module_name"], fromlist = ["default"])
        new_m_class = getattr(new_m_module, self.new_model_conf["class_name"])
        self.new_model_obj = new_m_class()
        #��ģ�ͳ�ʼ��
        if old_model_seg:
            self.old_model_obj.init_infer(self.old_model_type, self.old_model_dir, \
                                          self.old_model_conf, self.word_segger)
        else:
            self.old_model_obj.init_infer(self.old_model_type, self.old_model_dir, \
                                          self.old_model_conf)
        #��ģ�ͳ�ʼ��
        if new_model_seg:
            self.new_model_obj.init_infer(self.new_model_type, self.new_model_dir, \
                                          self.new_model_conf, self.word_segger)
        else:
            self.new_model_obj.init_infer(self.new_model_type, self.new_model_dir, \
                                          self.new_model_conf)

    def get_diff(self, input_file, output_path):
        """���diff�ļ�
        [in] input_file: �����ļ�
             output_path: ����ļ�·��
        """
        sample_model_diff = SampleDiff(self.old_model_obj, self.new_model_obj, self.common_conf)
        #���������ļ������������ı�diff/ͼ��diff
        old_model_down = self.old_model_conf.getboolean("url")
        new_model_down = self.new_model_conf.getboolean("url")
        assert old_model_down == new_model_down, "model diff url down should be the same"
        if old_model_down:
            sample_model_diff.get_model_result_image(input_file, output_path)
        else:
            sample_model_diff.get_model_result_text(input_file, output_path)

    def destroy(self):
        """�ͷ��д�
        """
        self.word_segger.destroy_wordseg_handle()

if __name__ == "__main__":
    pass


