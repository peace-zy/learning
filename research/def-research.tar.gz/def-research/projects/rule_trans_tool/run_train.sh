#!/bin/bash
#=======================================================
# Copyright (C) 2020 Baidu.com, Inc. All rights reserved.
# File:   run.sh
# Author: zhuxiaodong01@baidu.com
# Date:   20201209 18:27:59
#=======================================================

input_file_prefix="input"
output_file_prefix="output"
model_file_prefix="model"
AFS_PATH=$1
MODEL_TYPE=$2
UNIQID=$3
#�����ļ����ƣ�����ļ����ƣ�ģ�����ƶ���jobid�����
input_file_name="${input_file_prefix}_${UNIQID}.txt"
output_file_name="${output_file_prefix}_${UNIQID}.txt"
model_file_name="${model_file_prefix}_${UNIQID}.tar.gz"
# ======��ǰ����Ŀ¼ BASE_DIR=$(dirname $(readlink -f "$0"))=======
S="afs://shaolin.afs.baidu.com:9902"
CHINESE_GBK="${S}/app/ecom/fengkong/kg/tools/chinese_gbk.tar.gz"
BASE_DIR=$(cd "$(dirname "$0")";pwd)
DATA_DIR="${BASE_DIR}/data/"
SRC_DIR="${BASE_DIR}/src/"
OUTPUT_DIR="${BASE_DIR}/output/"
MODEL_DIR="${BASE_DIR}/model/"
DICT_DIR="${BASE_DIR}/dict/"

# ʹ�õ�PYTHON��HADOOP
PYTHON="python"
HADOOP_HOME="/home/users/shenhao02/hadoop-client-1.6.2.2"
HADOOP_PATH="${HADOOP_HOME}/hadoop/bin/hadoop --config ${HADOOP_HOME}/hadoop/conf-fengkong-afs-shaolin"

# ����ѵ���ڱ������ɵ��ļ���
FILE_PATH=${MODEL_TYPE}"_"${UNIQID}"/"
INPUT_FILE=${OUTPUT_DIR}${FILE_PATH}${input_file_name}
MODEL_PATH=${MODEL_DIR}${FILE_PATH}
OUTPUT_PATH=${OUTPUT_DIR}${FILE_PATH}

# ��ȡ�����Լ�����Ŀ¼
if [ ! -d ${MODEL_DIR} ]; then
    mkdir ${MODEL_DIR}
fi
if [ ! -d ${OUTPUT_DIR} ]; then
    mkdir ${OUTPUT_DIR}
fi
if [ ! -d ${MODEL_PATH} ]; then
    mkdir ${MODEL_PATH}
fi
if [ ! -d ${OUTPUT_PATH} ]; then
    mkdir ${OUTPUT_PATH}
fi
# ======����chinese_gbk�дʰ�======
if [ ! -d ${DICT_DIR} ]; then
    mkdir ${DICT_DIR}
    cd ${DICT_DIR}
    ${HADOOP_PATH} fs -get ${CHINESE_GBK} ./
    tar -zxvf chinese_gbk.tar.gz
    rm chinese_gbk.tar.gz
    cd -
fi
if [ ! -f ${INPUT_FILE} ]; then
    ${HADOOP_PATH} fs -get ${AFS_PATH}${input_file_name} ${INPUT_FILE}
else
    rm ${INPUT_FILE}
    ${HADOOP_PATH} fs -get ${AFS_PATH}${input_file_name} ${INPUT_FILE}
fi

# ѵ������
${PYTHON} ${SRC_DIR}train_main.py \
    --input_file ${INPUT_FILE} \
    --model_type ${MODEL_TYPE} \
    --model_dir ${MODEL_PATH} \
    --output_dir ${OUTPUT_PATH}

${PYTHON} ${SRC_DIR}infer_main.py \
    --input_file ${OUTPUT_PATH}train.txt \
    --output_file ${OUTPUT_PATH}train_infer.txt \
    --model_type ${MODEL_TYPE} \
    --model_dir ${MODEL_PATH}

${PYTHON} ${SRC_DIR}infer_main.py \
    --input_file ${OUTPUT_PATH}test.txt \
    --output_file ${OUTPUT_PATH}test_infer.txt \
    --model_type ${MODEL_TYPE} \
    --model_dir ${MODEL_PATH}
#
#ѵ���׶α�ǩmap����
${PYTHON} ${SRC_DIR}infer_label_map.py ${OUTPUT_PATH}train_infer.txt ${OUTPUT_PATH}train_infer_map.txt ${MODEL_PATH}label_map.txt ${MODEL_TYPE}
${PYTHON} ${SRC_DIR}infer_label_map.py ${OUTPUT_PATH}test_infer.txt ${OUTPUT_PATH}test_infer_map.txt ${MODEL_PATH}label_map.txt ${MODEL_TYPE}
#���
awk -F'\t' '{print $1"\t"$2"\t"1"\t"$3"\t"$4}' ${OUTPUT_PATH}train_infer_map.txt > ${OUTPUT_PATH}${output_file_name}
awk -F'\t' '{print $1"\t"$2"\t"2"\t"$3"\t"$4}' ${OUTPUT_PATH}test_infer_map.txt >> ${OUTPUT_PATH}${output_file_name}
##
### ���ģ���ļ�
cd ${MODEL_PATH}
tar -czvf ${model_file_name} ./*
${HADOOP_PATH} fs -test -e ${AFS_PATH}${model_file_name}
if [ $? -eq  0 ]; then
    ${HADOOP_PATH} fs -rmr ${AFS_PATH}${model_file_name}
fi
${HADOOP_PATH} fs -put ${model_file_name} ${AFS_PATH}
cd -
#
## output.txt�ϴ���ָ��λ��
cd ${OUTPUT_PATH}
${HADOOP_PATH} fs -test -e ${AFS_PATH}${output_file_name}
if [ $? -eq  0 ]; then
    ${HADOOP_PATH} fs -rmr ${AFS_PATH}${output_file_name}
fi
${HADOOP_PATH} fs -put ${output_file_name} ${AFS_PATH}
cd -
