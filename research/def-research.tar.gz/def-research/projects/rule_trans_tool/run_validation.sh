#!/bin/bash
#==================================================================================================#
# Author: shenhao02@baidu.com
# Date  : 21/05/19 16:33:05
# File  : run_valiation.sh
# Description: 
#==================================================================================================#
source ./util.sh
input_file_prefix="input"
output_file_prefix="output"
model_file_prefix="model"
AFS_PATH=$1
MODEL_TYPE=$2
ONLINE_PATH=$3
UNIQID=$4
SAMPLE_NUMS=$5
input_file_name="${input_file_prefix}_${UNIQID}.txt"
output_file_name="${output_file_prefix}_${UNIQID}.txt"
model_file_name="${model_file_prefix}_${UNIQID}.tar.gz"
input_infer_name="${input_file_prefix}_${UNIQID}_infer.txt"
input_infer_final="${input_file_prefix}_${UNIQID}_out.txt"
input_infer_sample="${input_file_prefix}_${UNIQID}_sample_out.txt"
# ======当前工作目录 BASE_DIR=$(dirname $(readlink -f "$0"))=======
S="afs://shaolin.afs.baidu.com:9902"
CHINESE_GBK="${S}/app/ecom/fengkong/kg/tools/chinese_gbk.tar.gz"
#BASE_DIR=$(cd "$(dirname "$0")";pwd)
DATA_DIR="${BASE_DIR}/data/"
SRC_DIR="${BASE_DIR}/src/"
OUTPUT_DIR="${BASE_DIR}/output/"
MODEL_DIR="${BASE_DIR}/model/"
DICT_DIR="${BASE_DIR}/dict/"

# 使用的PYTHON和HADOOP
PYTHON="python"
HADOOP_HOME="/home/users/shenhao02/hadoop-client-1.6.2.2"
HADOOP_PATH="${HADOOP_HOME}/hadoop/bin/hadoop --config ${HADOOP_HOME}/hadoop/conf-fengkong-afs-shaolin"

# 本次训练在本地生成的文件名
FILE_PATH=${MODEL_TYPE}"_"${UNIQID}"/"
INPUT_FILE=${OUTPUT_DIR}${FILE_PATH}${input_file_name}
MODEL_PATH=${MODEL_DIR}${FILE_PATH}
OUTPUT_PATH=${OUTPUT_DIR}${FILE_PATH}

# 获取数据以及创建目录,当模型文件为平台训练时，当前目录已有文件
if [ ! -d ${MODEL_DIR} ]; then
    mkdir ${MODEL_DIR}
fi
if [ ! -d ${OUTPUT_DIR} ]; then
    mkdir ${OUTPUT_DIR}
fi
if [ ! -d ${MODEL_PATH} ]; then
    mkdir ${MODEL_PATH}
fi
if [ ! -d ${OUTPUT_PATH} ]; then
    mkdir ${OUTPUT_PATH}
fi
# ======下载chinese_gbk切词包======
if [ ! -d ${DICT_DIR} ]; then
    mkdir ${DICT_DIR}
    cd ${DICT_DIR}
    ${HADOOP_PATH} fs -get ${CHINESE_GBK} ./
    tar -zxvf chinese_gbk.tar.gz
    rm chinese_gbk.tar.gz
    cd -
fi
if [ ! -f ${INPUT_FILE} ]; then
    ${HADOOP_PATH} fs -get ${AFS_PATH}${input_file_name} ${INPUT_FILE}
else
    rm ${INPUT_FILE}
    ${HADOOP_PATH} fs -get ${AFS_PATH}${input_file_name} ${INPUT_FILE}
fi
#当前模型文件为个人上传，所以需要利用wget获得模型，并解压
#当模型为训练阶段的模型时，则需要从路径获得，并解压
if [[ ${ONLINE_PATH} == w* ]]; then
    get_file_wget "${ONLINE_PATH}" "${MODEL_PATH}${model_file_name}"
else
    if [ ! -f ${MODEL_PATH}${model_file_name} ]; then
        ${HADOOP_PATH} fs -get ${ONLINE_PATH} ${MODEL_PATH}${model_file_name}
    else
        rm ${MODEL_PATH}${model_file_name}
        ${HADOOP_PATH} fs -get ${ONLINE_PATH} ${MODEL_PATH}${model_file_name}
    fi
fi

cd ${MODEL_PATH}
tar -zxf ${model_file_name}
cd -

${PYTHON} ${SRC_DIR}infer_main.py \
    --input_file ${OUTPUT_PATH}${input_file_name} \
    --output_file ${OUTPUT_PATH}${input_infer_name} \
    --model_type ${MODEL_TYPE} \
    --model_dir ${MODEL_PATH}
#根据输入模型类型对标签采取不同的后处理方式
#标签的map，目前还没写，待补充
#lr/textcnn/gru/ernie 结果为label，yolo结果为json序列化

online_map="platform_label_map.txt"
label_name_map="model_label_map.txt"
label_map="label_map.txt"
#当前模型文件不是从平台训练的，所以没有label_map.txt
#此时一定要有model_label_map.txt 和 platform_label_map用来处理获得label map
if [ ! -f ${MODEL_PATH}${label_map} ]; then
    WriteLog "should get label map"
    if [ ! -f ${MODEL_PATH}${label_name_map} ]; then
        exit_error "without label name map, can not get truth label"
    else
        ${HADOOP_PATH} fs -test -e ${AFS_PATH}${online_map}
        if [ $? -ne 0 ]; then
            exit_error "without platform label map, can not get truth label"
        fi
        if [ ! -f ${MODEL_PATH}${online_map} ]; then
            ${HADOOP_PATH} fs -get ${AFS_PATH}${online_map} ${MODEL_PATH}${online_map}
        else
            rm ${MODEL_PATH}${online_map}
            ${HADOOP_PATH} fs -get ${AFS_PATH}${online_map} ${MODEL_PATH}${online_map}
        fi
        #通过awk 双文件操作获得模型label与平台label之间的映射
        awk 'NR==FNR{a[$2]=$1; next}($2 in a){print a[$2]"\t"$1}' ${MODEL_PATH}${online_map} ${MODEL_PATH}${label_name_map} > ${MODEL_PATH}${label_map}
    fi
fi

${PYTHON} ${SRC_DIR}infer_label_map.py ${OUTPUT_PATH}${input_infer_name} ${OUTPUT_PATH}${input_infer_final} ${MODEL_PATH}${label_map} ${MODEL_TYPE}

#需要对结果进行抽样，按照label
${PYTHON} ${SRC_DIR}sample_label_data.py ${OUTPUT_PATH}${input_infer_final} ${OUTPUT_PATH}${input_infer_sample} ${SAMPLE_NUMS}
#本地拿取，也无需上传
#${HADOOP_PATH} fs -test -e ${AFS_PATH}${output_file_name}
#if [ $? -eq  0 ]; then
#    ${HADOOP_PATH} fs -rmr ${AFS_PATH}${output_file_name}
#fi
#${HADOOP_PATH} fs -put ${OUTPUT_PATH}${input_infer_final} ${AFS_PATH}${output_file_name}
