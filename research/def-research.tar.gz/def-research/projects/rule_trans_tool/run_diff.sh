#!/bin/bash
#==================================================================================================#
# Author: shenhao02@baidu.com
# Date  : 21/05/19 16:33:05
# File  : run_valiation.sh
# Description: 
#==================================================================================================#
source ./util.sh
input_file_prefix="input"
output_file_prefix="output"
old_model_file_prefix="model"
new_model_file_prefix="model"
AFS_PATH=$1
OLD_MODEL_TYPE=$2
OLD_ONLINE_PATH=$3
NEW_MODEL_TYPE=$4
NEW_ONLINE_PATH=$5
UNIQID=$6
input_file_name="${input_file_prefix}_${UNIQID}.txt"
output_file_name="${output_file_prefix}_${UNIQID}.txt"
output_map_name="${output_file_prefix}_map_${UNIQID}.txt"
old_model_file_name="${old_model_file_prefix}_${UNIQID}.tar.gz"
new_model_file_name="${new_model_file_prefix}_${UNIQID}.tar.gz"
# ======当前工作目录 BASE_DIR=$(dirname $(readlink -f "$0"))=======
S="afs://shaolin.afs.baidu.com:9902"
CHINESE_GBK="${S}/app/ecom/fengkong/kg/tools/chinese_gbk.tar.gz"
#BASE_DIR=$(cd "$(dirname "$0")";pwd)
DATA_DIR="${BASE_DIR}/data/"
SRC_DIR="${BASE_DIR}/src/"
OUTPUT_DIR="${BASE_DIR}/output/"
MODEL_DIR="${BASE_DIR}/model/"
DICT_DIR="${BASE_DIR}/dict/"

# 使用的PYTHON和HADOOP
PYTHON="python"
HADOOP_HOME="/home/users/shenhao02/hadoop-client-1.6.2.2"
HADOOP_PATH="${HADOOP_HOME}/hadoop/bin/hadoop --config ${HADOOP_HOME}/hadoop/conf-fengkong-afs-shaolin"

# 本次训练在本地生成的文件名
FILE_PATH="diff_"${UNIQID}"/"
INPUT_FILE=${OUTPUT_DIR}${FILE_PATH}${input_file_name}
OUTPUT_FILE=${OUTPUT_DIR}${FILE_PATH}${output_file_name}
OUTPUT_FILE_MAP=${OUTPUT_DIR}${FILE_PATH}${output_map_name}
MODEL_PATH=${MODEL_DIR}${FILE_PATH}
OUTPUT_PATH=${OUTPUT_DIR}${FILE_PATH}
OLD_MODEL_PATH="${MODEL_PATH}old_model/"
NEW_MODEL_PATH="${MODEL_PATH}new_model/"

# 获取数据以及创建目录,当模型文件为平台训练时，当前目录已有文件
if [ ! -d ${MODEL_DIR} ]; then
    mkdir ${MODEL_DIR}
fi
if [ ! -d ${OUTPUT_DIR} ]; then
    mkdir ${OUTPUT_DIR}
fi
if [ ! -d ${MODEL_PATH} ]; then
    mkdir ${MODEL_PATH}
fi
if [ ! -d ${OUTPUT_PATH} ]; then
    mkdir ${OUTPUT_PATH}
fi
if [ ! -d ${OLD_MODEL_PATH} ]; then
    mkdir ${OLD_MODEL_PATH}
fi
if [ ! -d ${NEW_MODEL_PATH} ]; then
    mkdir ${NEW_MODEL_PATH}
fi
# ======下载chinese_gbk切词包======
if [ ! -d ${DICT_DIR} ]; then
    mkdir ${DICT_DIR}
    cd ${DICT_DIR}
    ${HADOOP_PATH} fs -get ${CHINESE_GBK} ./
    tar -zxvf chinese_gbk.tar.gz
    rm chinese_gbk.tar.gz
    cd -
fi
if [ ! -f ${INPUT_FILE} ]; then
    ${HADOOP_PATH} fs -get ${AFS_PATH}${input_file_name} ${INPUT_FILE}
else
    rm ${INPUT_FILE}
    ${HADOOP_PATH} fs -get ${AFS_PATH}${input_file_name} ${INPUT_FILE}
fi
#当前模型文件为个人上传，所以需要利用wget获得模型，并解压

if [[ ${OLD_ONLINE_PATH} == w* ]]; then
    get_file_wget "${OLD_ONLINE_PATH}" "${OLD_MODEL_PATH}${old_model_file_name}"
else
    if [ ! -f ${OLD_MODEL_PATH}${old_model_file_name} ]; then
        ${HADOOP_PATH} fs -get ${OLD_ONLINE_PATH} ${OLD_MODEL_PATH}${old_model_file_name}
    else
        rm ${OLD_MODEL_PATH}${old_model_file_name}
        ${HADOOP_PATH} fs -get ${OLD_ONLINE_PATH} ${OLD_MODEL_PATH}${old_model_file_name}
    fi
fi

cd ${OLD_MODEL_PATH}
tar -zxf ${old_model_file_name}
cd -

if [[ ${NEW_ONLINE_PATH} == w* ]]; then
    get_file_wget "${NEW_ONLINE_PATH}" "${NEW_MODEL_PATH}${new_model_file_name}"
else
    if [ ! -f ${NEW_MODEL_PATH}${new_model_file_name} ]; then
        ${HADOOP_PATH} fs -get ${NEW_ONLINE_PATH} ${NEW_MODEL_PATH}${new_model_file_name}
    else
        rm ${NEW_MODEL_PATH}${new_model_file_name}
        ${HADOOP_PATH} fs -get ${NEW_ONLINE_PATH} ${NEW_MODEL_PATH}${new_model_file_name}
    fi
fi

cd ${NEW_MODEL_PATH}
tar -zxf ${new_model_file_name}
cd -
#LR diff
${PYTHON} ${SRC_DIR}model_diff_main.py \
    --input_file ${INPUT_FILE} \
    --output_path ${OUTPUT_FILE} \
    --old_model_type ${OLD_MODEL_TYPE} \
    --new_model_type ${NEW_MODEL_TYPE} \
    --old_model_dir ${OLD_MODEL_PATH} \
    --new_model_dir ${NEW_MODEL_PATH}
#当前结果为所有模型预测的结果，现在需要对模型结果进行映射&抽样
#平台标签映射，只有一个文件
online_map="platform_label_map.txt"
#旧模型标签映射
label_name_map="model_label_map.txt"
label_map="label_map.txt"
#当前模型文件不是从平台训练的，所以没有label_map.txt
#此时一定要有model_label_map.txt 和 platform_label_map用来处理获得label map
if [ ! -f ${NEW_MODEL_PATH}${label_map} ]; then
    WriteLog "should get new model label map"
    if [ ! -f ${NEW_MODEL_PATH}${label_name_map} ]; then
        exit_error "without label name map, can not get truth label"
    else
        ${HADOOP_PATH} fs -test -e ${AFS_PATH}${online_map}
        if [ $? -ne 0 ]; then
            exit_error "without platform label map, can not get truth label"
        fi
        if [ ! -f ${MODEL_PATH}${online_map} ]; then
            ${HADOOP_PATH} fs -get ${AFS_PATH}${online_map} ${MODEL_PATH}${online_map}
        else
            rm ${MODEL_PATH}${online_map}
            ${HADOOP_PATH} fs -get ${AFS_PATH}${online_map} ${MODEL_PATH}${online_map}
        fi
        #通过awk 双文件操作获得模型label与平台label之间的映射
        awk 'NR==FNR{a[$2]=$1; next}($2 in a){print a[$2]"\t"$1}' ${MODEL_PATH}${online_map} ${NEW_MODEL_PATH}${label_name_map} > ${NEW_MODEL_PATH}${label_map}
    fi
fi
if [ ! -f ${OLD_MODEL_PATH}${label_map} ]; then
    WriteLog "should get old model label map"
    if [ ! -f ${OLD_MODEL_PATH}${label_name_map} ]; then
        exit_error "without label name map, can not get truth label"
    else
        ${HADOOP_PATH} fs -test -e ${AFS_PATH}${online_map}
        if [ $? -ne 0 ]; then
            exit_error "without platform label map, can not get truth label"
        fi
        if [ ! -f ${MODEL_PATH}${online_map} ]; then
            ${HADOOP_PATH} fs -get ${AFS_PATH}${online_map} ${MODEL_PATH}${online_map}
        else
            rm ${MODEL_PATH}${online_map}
            ${HADOOP_PATH} fs -get ${AFS_PATH}${online_map} ${MODEL_PATH}${online_map}
        fi
        #通过awk 双文件操作获得模型label与平台label之间的映射
        awk 'NR==FNR{a[$2]=$1; next}($2 in a){print a[$2]"\t"$1}' ${MODEL_PATH}${online_map} ${OLD_MODEL_PATH}${label_name_map} > ${OLD_MODEL_PATH}${label_map}
    fi
fi

${PYTHON} ${SRC_DIR}model_diff_map.py ${OUTPUT_FILE} ${OUTPUT_FILE_MAP} ${OLD_MODEL_PATH}${label_map} ${NEW_MODEL_PATH}${label_map} ${OLD_MODEL_TYPE}
#抽样的逻辑
${PYTHON} ${SRC_DIR}model_diff_sample.py ${OUTPUT_FILE_MAP} ${OUTPUT_PATH}

