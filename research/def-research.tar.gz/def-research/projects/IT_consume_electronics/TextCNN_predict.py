# -*- coding: utf-8 -*-
"""
File  :   TextCNN_predict.py
Author:   zhangqifan01@baidu.com
Date  :   21/01/20 20:13:00
Desc  :   预测
"""

import tensorflow as tf
import numpy as np
import os
import codecs
from TextCNN_model import TextCNN
import pickle
import h5py
import pandas as pd

FLAGS=tf.app.flags.FLAGS

tf.app.flags.DEFINE_float("learning_rate", 0.0003, "学习率")
tf.app.flags.DEFINE_integer("batch_size", 1, "Batch size")
tf.app.flags.DEFINE_integer("decay_steps", 1000, "学习率衰减周期")
tf.app.flags.DEFINE_float("decay_rate", 1.0, "学习率衰减倍率")
tf.app.flags.DEFINE_string("ckpt_dir", "textcnn_checkpoint/", "模型checkpoint存放路径")
tf.app.flags.DEFINE_integer("sentence_len", 200, "最大句长")
tf.app.flags.DEFINE_integer("embed_size", 128, "embedding size")
tf.app.flags.DEFINE_boolean("is_training_flag", True, "训练或预测.true: train, false: inference")
tf.app.flags.DEFINE_integer("num_epochs", 20, "轮次")
tf.app.flags.DEFINE_integer("validate_every", 1, "每n次epoch做一次验证")
tf.app.flags.DEFINE_string("predict_target_file", "predict_result/test_res.csv", "预测结果存放路径文件")
tf.app.flags.DEFINE_string("predict_source_file", 'need_to_predict/test.csv', "待预测文件")
tf.app.flags.DEFINE_integer("num_filters", 128, "filters数量")
tf.app.flags.DEFINE_string("cache_file_h5py", "data/data.h5", "训练集/测试集存放地址文件")
tf.app.flags.DEFINE_string("cache_file_pickle", "data/vocab_label.pik", "词典标签存放地址文件")

filter_sizes=[6, 7, 8]

def main(_):
    """
    主函数：预测（离线）
    """
    res = load_data(FLAGS.cache_file_h5py, FLAGS.cache_file_pickle)
    word2index, label2index = res['word2index'], res['label2index']
    vocab_size = len(word2index)
    num_classes=len(label2index)
    #读取待预测文件
    df = pd.read_csv(FLAGS.predict_source_file)
    df = df[['text_words']]
    question_id_list, testX= load_data_predict(word2index, label2index, df)
    
    config=tf.ConfigProto()
    #config.gpu_options.allow_growth=True
    with tf.Session(config=config) as sess:
        textCNN=TextCNN(filter_sizes, 
                        FLAGS.num_filters, 
                        num_classes, 
                        FLAGS.learning_rate, 
                        FLAGS.batch_size, 
                        FLAGS.decay_steps, 
                        FLAGS.decay_rate, 
                        FLAGS.sentence_len, 
                        vocab_size, 
                        FLAGS.embed_size)
        saver=tf.train.Saver()
        if os.path.exists(FLAGS.ckpt_dir + "checkpoint"):
            print("Restoring Variables from Checkpoint")
            saver.restore(sess, tf.train.latest_checkpoint(FLAGS.ckpt_dir))
        else:
            print("未找到checkpoint,终止")
            return

        index=0
        predict_target_file_f = codecs.open(FLAGS.predict_target_file, 'a', 'utf8')
        from tflearn.data_utils import pad_sequences
        print("start padding....")
        testX2 = pad_sequences(testX, maxlen=FLAGS.sentence_len, value=0.)
        print("end padding...")
        number_of_training_data=len(testX2)
        for start, end in zip(range(0, number_of_training_data, FLAGS.batch_size), 
                range(FLAGS.batch_size, number_of_training_data + 1, FLAGS.batch_size)):
            logits=sess.run(textCNN.logits, 
                            feed_dict={textCNN.input_x:testX2[start:end], 
                            textCNN.dropout_keep_prob: 1, 
                            textCNN.is_training_flag: False})
            #计算预测结果标签和分值
            predicted_labels, predicted_values=get_label_using_logits(logits[0], label2index)
            value_labels_exp= np.exp(predicted_values)
            p_labels=value_labels_exp / np.sum(value_labels_exp)
            #输出样本id和结果到文件
            write_question_id_with_labels(question_id_list[index], 
                                          predicted_labels, 
                                          p_labels, 
                                          predict_target_file_f)
            index=index + 1
        predict_target_file_f.close()


def get_label_using_logits(logits, vocabulary_index2word_label, top_number=19):
    """
    通过预测结果logits获取相应标签内容和分值
    """
    index_list=np.argsort(logits)[-top_number:]
    index_list=index_list[::-1]
    label_list=[]
    value_list=[]
    for index in index_list:
        label=list(vocabulary_index2word_label.keys())[list(vocabulary_index2word_label.values()).index(index + 1)]
        label_list.append(label) 
        value_list.append(logits[index])
    return label_list, value_list



def write_question_id_with_labels(question_id, labels_list, values_list, f):
    """
    输出结果写入文件
    """
    labels_string=",".join([str(i) for i in labels_list])
    values_string=",".join([str(i) for i in  values_list])
    f.write(str(question_id) + "\t" + str(labels_string) + "\t" + str(values_string) + "\n")


def load_data_predict(vocabulary_word2index, vocabulary_word2index_label, df):
    """
    获取样本id和样本中词对应index
    """
    id_list = []
    textX = []
    for index, row in df.iterrows():
        id = index
        words = row['text_words']
        #如果词表中无该词，设置index为0
        x = [vocabulary_word2index.get(e, 0) for e in eval(words)]
        id_list.append(id)
        textX.append(x)
    return  id_list, textX



def load_data(cache_file_h5py, cache_file_pickle):
    """
    读取数据(所读数据通过textcnn.ipynb产出)
    """
    if not os.path.exists(cache_file_h5py) or not os.path.exists(cache_file_pickle):
        raise RuntimeError("No such file\n")
    print("INFO. cache file exists. going to load cache file")
    f_data = h5py.File(cache_file_h5py, 'r')
    print("f_data.keys: ", list(f_data.keys()))
    train_X=f_data['train_X']
    print("train_X.shape: ", train_X.shape)
    train_Y=f_data['train_Y']
    print("train_Y.shape: ", train_Y.shape, ";")
    valid_X=f_data['valid_X']
    valid_Y=f_data['valid_Y']
    test_X=f_data['test_X']
    test_Y=f_data['test_Y']

    word2index, label2index=None, None
    with open(cache_file_pickle, 'rb') as data_f_pickle:
        word2index, label2index=pickle.load(data_f_pickle)
    print("INFO. cache file load successful...")
    res = {'word2index':word2index, 
           'label2index':label2index, 
           'train_X':train_X, 
           'train_Y':train_Y, 
           'valid_X':valid_X, 
           'valid_Y':valid_Y, 
           'test_X':test_X, 
           'test_Y':test_Y}

    return res





if __name__ == "__main__":
    tf.app.run()
