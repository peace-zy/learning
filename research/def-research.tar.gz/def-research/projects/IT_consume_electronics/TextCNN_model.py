# -*- coding:gb18030 -*-
"""
File  :   TextCNN_model.py
Author:   zhangqifan01@baidu.com
Date  :   21/01/20 20:13:00
Desc  :   ģ�ͽṹ
          TextCNN: 1.embedding layers
                   2.convolutional layer
                   3.max-pooling
                   4.softmax layer
"""

import tensorflow as tf
import numpy as np

class TextCNN:
    """
    TextCNN��
    """
    def __init__(self, 
                 filter_sizes,
                 num_filters,
                 num_classes, 
                 learning_rate, 
                 batch_size, 
                 decay_steps, 
                 decay_rate,
                 sequence_length,
                 vocab_size,
                 embed_size,
                 initializer=tf.random_normal_initializer(stddev=0.1)):
        """
        ��ʼ������
        """
        self.num_classes = num_classes
        self.batch_size = batch_size
        self.sequence_length=sequence_length
        self.vocab_size=vocab_size
        self.embed_size=embed_size
        self.learning_rate = tf.Variable(learning_rate, trainable=False, name="learning_rate")
        self.filter_sizes=filter_sizes
        self.num_filters=num_filters
        self.initializer=initializer
        self.num_filters_total=self.num_filters * len(filter_sizes)
        self.is_training_flag = tf.placeholder(tf.bool, name="is_training_flag")

        self.input_x = tf.placeholder(tf.int32, [None, self.sequence_length], name="input_x")
        self.input_y_multilabel = tf.placeholder(tf.float32, [None, self.num_classes], name="input_y_multilabel")
        self.dropout_keep_prob=tf.placeholder(tf.float32, name="dropout_keep_prob")

        self.global_step = tf.Variable(0, trainable=False, name="Global_Step")
        self.epoch_step=tf.Variable(0, trainable=False, name="Epoch_Step")
        self.epoch_increment=tf.assign(self.epoch_step, tf.add(self.epoch_step, tf.constant(1)))
        self.b1 = tf.Variable(tf.ones([self.num_filters]) / 10)
        self.b2 = tf.Variable(tf.ones([self.num_filters]) / 10)
        self.decay_steps, self.decay_rate = decay_steps, decay_rate

        self.instantiate_weights()
        self.logits = self.inference()
        self.loss_val = self.loss_multilabel()
        self.train_op = self.train()

    def instantiate_weights(self):
        """
        ��������Ȩ��
        """
        with tf.name_scope("embedding"):
            self.Embedding = tf.get_variable("Embedding", 
                                             shape=[self.vocab_size, self.embed_size], 
                                             initializer=self.initializer)
            self.W_projection = tf.get_variable("W_projection", 
                                                shape=[self.num_filters_total, self.num_classes],
                                                initializer=self.initializer)
            self.b_projection = tf.get_variable("b_projection", shape=[self.num_classes])

    def inference(self):
        """
        Ԥ�⣺������
        """
        #��ȡ������ÿ���ʵ�embedding
        self.embedded_words = tf.nn.embedding_lookup(self.Embedding, self.input_x)
        self.sentence_embeddings_expanded=tf.expand_dims(self.embedded_words, -1)

        h=self.cnn_single_layer()
        with tf.name_scope("output"):
            logits = tf.matmul(h, self.W_projection) + self.b_projection
        return logits

    def cnn_single_layer(self):
        """
        CNN����ṹ
        """
        pooled_outputs = []
        for i, filter_size in enumerate(self.filter_sizes):
            with tf.variable_scope("convolution-pooling-%s" % filter_size):
                #����filter
                filter = tf.get_variable("filter-%s" % filter_size, 
                                         [filter_size, self.embed_size, 1, self.num_filters], 
                                         initializer=self.initializer)
                #����
                conv = tf.nn.conv2d(self.sentence_embeddings_expanded, 
                                    filter, 
                                    strides=[1, 1, 1, 1], 
                                    padding="VALID", 
                                    name="conv")
                #BN
                conv = tf.contrib.layers.batch_norm(conv, is_training=self.is_training_flag, scope='cnn_bn_')
                #bias
                b = tf.get_variable("b-%s" % filter_size, [self.num_filters])
                #relu����
                h = tf.nn.relu(tf.nn.bias_add(conv, b), "relu")
                #�ػ�
                pooled = tf.nn.max_pool(h, 
                                        ksize=[1, self.sequence_length - filter_size + 1, 1, 1], 
                                        strides=[1, 1, 1, 1], 
                                        padding='VALID', 
                                        name="pool")
                pooled_outputs.append(pooled)

        self.h_pool = tf.concat(pooled_outputs, 3)
        self.h_pool_flat = tf.reshape(self.h_pool, [-1, self.num_filters_total])

        #����dropout
        with tf.name_scope("dropout"):
            self.h_drop = tf.nn.dropout(self.h_pool_flat, keep_prob=self.dropout_keep_prob)

        h = tf.layers.dense(self.h_drop, self.num_filters_total, activation=tf.nn.tanh, use_bias=True)

        return h


    def loss_multilabel(self, l2_lambda=0.0001):
        """
        ��ʧ����
        """
        with tf.name_scope("loss"):
            losses = tf.nn.sigmoid_cross_entropy_with_logits(labels=self.input_y_multilabel, logits=self.logits)
            print("sigmoid_cross_entropy_with_logits.losses:", losses)
            losses=tf.reduce_sum(losses, axis=1)
            loss=tf.reduce_mean(losses)
            l2_losses = tf.add_n([tf.nn.l2_loss(v) for v in tf.trainable_variables() \
                if 'bias' not in v.name]) * l2_lambda
            loss=loss + l2_losses
        return loss



    def train(self):
        """
        ѵ��������SGD���²���
        """
        learning_rate = tf.train.exponential_decay(self.learning_rate, 
                                                   self.global_step, 
                                                   self.decay_steps, 
                                                   self.decay_rate, 
                                                   staircase=True)
        self.learning_rate_=learning_rate
        optimizer = tf.train.AdamOptimizer(learning_rate)
        gradients, variables = zip(*optimizer.compute_gradients(self.loss_val))
        gradients, _ = tf.clip_by_global_norm(gradients, 5.0)
        update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        with tf.control_dependencies(update_ops):
            train_op = optimizer.apply_gradients(zip(gradients, variables))
        return train_op

