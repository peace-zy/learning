# -*- coding: utf-8 -*-
"""
File  :   TextCNN_train.py
Author:   zhangqifan01@baidu.com
Date  :   21/01/20 20:13:00
Desc  :   模型训练
"""

import tensorflow as tf
import numpy as np
from TextCNN_model import TextCNN
import codecs
import pickle
import h5py
import os
from numba import jit

FLAGS=tf.app.flags.FLAGS

tf.app.flags.DEFINE_string("cache_file_h5py", "data/data.h5", "训练集/测试集存放地址文件")
tf.app.flags.DEFINE_string("cache_file_pickle", "data/vocab_label.pik", "词典标签存放地址文件")
tf.app.flags.DEFINE_float("learning_rate", 0.0003, "学习率")
tf.app.flags.DEFINE_integer("batch_size", 64, "Batch size")
tf.app.flags.DEFINE_integer("decay_steps", 1000, "学习率衰减周期")
tf.app.flags.DEFINE_float("decay_rate", 1.0, "学习率衰减倍率")
tf.app.flags.DEFINE_string("ckpt_dir", "textcnn_checkpoint/", "模型checkpoint存放路径")
tf.app.flags.DEFINE_integer("sentence_len", 200, "最大句长")
tf.app.flags.DEFINE_integer("embed_size", 128, "embedding size")
tf.app.flags.DEFINE_boolean("is_training_flag", True, "训练或预测.true: train, false: inference")
tf.app.flags.DEFINE_integer("num_epochs", 20, "轮次")
tf.app.flags.DEFINE_integer("validate_every", 1, "每n次epoch做一次验证")
tf.app.flags.DEFINE_integer("num_filters", 128, "filters数量")

filter_sizes=[6, 7, 8]

def main(_):
    """
    主函数：包含五个步骤
    1.读取数据
    2.创建会话
    3.灌入数据
    4.训练
    5.验证
    """
    #读取数据
    res = load_data(FLAGS.cache_file_h5py, FLAGS.cache_file_pickle)
    word2index = res['word2index']
    label2index = res['label2index']
    trainX = ['trainX']
    trainY = ['trainY']
    validX = ['validX']
    validY = ['validY']
    testX = ['testX']
    testY = ['testY']

    vocab_size = len(word2index)
    print("cnn_model.vocab_size: ",vocab_size)
    num_classes=len(label2index)
    print("num_classes: ", num_classes)
    num_examples, FLAGS.sentence_len=trainX.shape
    print("num_examples of training: ", num_examples, "; sentence_len: ", FLAGS.sentence_len)
    print("trainX[0:10]: ", trainX[0:10])
    print("trainY[0]: ", trainY[0:10])
    print("train_y_short: ", trainY[0])

    #创建会话
    config=tf.ConfigProto()
    #config.gpu_options.allow_growth=True
    with tf.Session(config=config) as sess:
        #实例化模型
        textCNN=TextCNN(filter_sizes, 
                        FLAGS.num_filters, 
                        num_classes, 
                        FLAGS.learning_rate, 
                        FLAGS.batch_size, 
                        FLAGS.decay_steps, 
                        FLAGS.decay_rate, 
                        FLAGS.sentence_len, 
                        vocab_size, 
                        FLAGS.embed_size)

        saver=tf.train.Saver()
        if os.path.exists(FLAGS.ckpt_dir + "checkpoint"):
            print("从上一Checkpoint恢复参数.")
            saver.restore(sess, tf.train.latest_checkpoint(FLAGS.ckpt_dir))
        else:
            print('初始化变量')
            sess.run(tf.global_variables_initializer())
        curr_epoch=sess.run(textCNN.epoch_step)
        #灌入数据并训练
        number_of_training_data=len(trainX)
        batch_size=FLAGS.batch_size
        iteration=0
        for epoch in range(curr_epoch, FLAGS.num_epochs):
            loss, counter =  0.0, 0
            for start, end in zip(range(0, number_of_training_data, batch_size), \
                    range(batch_size, number_of_training_data, batch_size)):
                iteration=iteration + 1
                if epoch==0 and counter==0:
                    print("trainX[start:end]: ",trainX[start:end])
                feed_dict = {textCNN.input_x: trainX[start:end], 
                             textCNN.dropout_keep_prob: 0.8, 
                             textCNN.is_training_flag: FLAGS.is_training_flag}
                feed_dict[textCNN.input_y_multilabel]=trainY[start:end]
                curr_loss, lr, _=sess.run([textCNN.loss_val, 
                                           textCNN.learning_rate, 
                                           textCNN.train_op], 
                                           feed_dict)
                loss,counter=loss + curr_loss, counter + 1
                if counter % 50==0:
                    print("Epoch %d\tBatch %d\tTrain Loss: %.3f\tLearning rate: %.5f" %(epoch, counter, loss/float(counter), lr))
                #每n个batch后做一次验证
                if start % (3000*FLAGS.batch_size)==0:
                    res_1 = do_eval(sess, textCNN, validX, validY, num_classes)
                    eval_loss, f1_score, f1_micro, f1_macro = res_1['loss'], res_1['f1_score'], res_1['f1_micro'], res_1['f1_macro']
                    print("Epoch %d Validation Loss: %.3f\tF1 Score: %.3f\tF1_micro: %.3f\tF1_macro: %.3f" % \
                            (epoch, eval_loss, f1_score, f1_micro, f1_macro))
                    #保存模型到checkpoint
                    save_path = FLAGS.ckpt_dir + "model.ckpt"
                    print("开始保存模型")
                    saver.save(sess, save_path, global_step=epoch)
            
            print("epoch增加一轮")
            sess.run(textCNN.epoch_increment)

            #每轮完毕后的验证
            print(epoch, FLAGS.validate_every, (epoch % FLAGS.validate_every==0))
            if epoch % FLAGS.validate_every==0:
                res_2 = do_eval(sess, textCNN, testX, testY, num_classes)
                eval_loss, f1_score, f1_micro, f1_macro = res_2['loss'], res_2['f1_score'], res_2['f1_micro'], res_2['f1_macro']
                print("Epoch %d Validation Loss: %.3f\tF1 Score: %.3f\tF1_micro: %.3f\tF1_macro: %.3f" % \
                        (epoch, eval_loss, f1_score, f1_micro, f1_macro))
                
                save_path=FLAGS.ckpt_dir + "model.ckpt"
                saver.save(sess, save_path, global_step=epoch)

        #最后在测试集上做测试，并报告测试准确率
        res_3 = do_eval(sess, textCNN, testX, testY, num_classes)
        test_loss, f1_score, f1_micro, f1_macro = res_3['loss'], res_3['f1_score'], res_3['f1_micro'], res_3['f1_macro']
        print("Test Loss: %.3f\tF1 Score: %.3f\tF1_micro: %.3f\tF1_macro: %.3f" % \
                (test_loss, f1_score, f1_micro, f1_macro))




def do_eval(sess, textCNN, evalX, evalY, num_classes):
    """
    验证效果，输出损失和精确度
    """
    number_examples = len(evalX)
    eval_loss, eval_counter, eval_f1_score, eval_p, eval_r = 0.0, 0, 0.0, 0.0, 0.0
    batch_size = 1
    predict = []

    for start, end in zip(range(0, number_examples, batch_size), \
            range(batch_size, number_examples + batch_size, batch_size)):
        feed_dict = {textCNN.input_x: evalX[start:end], 
                     textCNN.input_y_multilabel: evalY[start:end], 
                     textCNN.dropout_keep_prob: 1.0, 
                     textCNN.is_training_flag: False}
        current_eval_loss, logits = sess.run([textCNN.loss_val, textCNN.logits], feed_dict)
        predict = [*predict, np.argmax(np.array(logits[0]))]
        eval_loss += current_eval_loss
        eval_counter += 1
    evalY = [np.argmax(ii) for ii in evalY]

    f1_macro, f1_micro = fastF1(predict, evalY, num_classes)
    f1_score = (f1_micro + f1_macro) / 2.0
    res = {'loss': eval_loss / float(eval_counter), 
           'f1_score': f1_score, 
           'f1_micro': f1_micro, 
           'f1_macro': f1_macro}

    return res

@jit
def fastF1(result: list, predict: list, num_classes: int):
    """
    F1值:分别计算了两种 1.marco_f1  2.micro_f1
    """
    true_total, r_total, p_total, p, r = 0, 0, 0, 0, 0
    total_list = []
    for trueValue in range(num_classes):
        trueNum, recallNum, precisionNum = 0, 0, 0
        for index, values in enumerate(result):
            if values == trueValue:
                recallNum += 1
                if values == predict[index]:
                    trueNum += 1
            if predict[index] == trueValue:
                precisionNum += 1
        R = trueNum / recallNum if recallNum else 0
        P = trueNum / precisionNum if precisionNum else 0
        true_total += trueNum
        r_total += recallNum
        p_total += precisionNum
        p += P
        r += R
        
        f1 = (2 * P * R) / (P + R) if (P + R) else 0
        total_list.append([P, R, f1])
    p, r = np.array([p, r]) / num_classes
    micro_r, micro_p = true_total / np.array([r_total, p_total])
    macro_f1 = (2 * p * r) / (p + r) if (p + r) else 0
    micro_f1 = (2 * micro_p * micro_r) / (micro_p + micro_r) if (micro_p + micro_r) else 0
    accuracy = true_total / len(result)
    print('P: {:.2f}%, R: {:.2f}%, Micro_f1: {:.2f}%, Macro_f1: {:.2f}%, Accuracy: {:.2f}'.format(p * 100, 
     r * 100, 
     micro_f1 * 100, 
     macro_f1 * 100, 
     accuracy * 100))
    
    #return p, r, macro_f1, micro_f1, total_list
    return macro_f1, micro_f1


def load_data(cache_file_h5py,cache_file_pickle):
    """
    读取数据(所读数据通过textcnn.ipynb产出)
    """
    if not os.path.exists(cache_file_h5py) or not os.path.exists(cache_file_pickle):
        raise RuntimeError("No such file\n")
    print("INFO. cache file exists. going to load cache file")
    f_data = h5py.File(cache_file_h5py, 'r')
    print("f_data.keys: ", list(f_data.keys()))
    train_X=f_data['train_X']
    print("train_X.shape: ", train_X.shape)
    train_Y=f_data['train_Y']
    print("train_Y.shape: ", train_Y.shape,";")
    valid_X=f_data['valid_X']
    valid_Y=f_data['valid_Y']
    test_X=f_data['test_X']
    test_Y=f_data['test_Y']

    word2index, label2index=None, None
    with open(cache_file_pickle, 'rb') as data_f_pickle:
        word2index, label2index=pickle.load(data_f_pickle)
    print("INFO. cache file load successful...")
    res = {'word2index':word2index, 
           'label2index':label2index, 
           'train_X':train_X, 
           'train_Y':train_Y, 
           'valid_X':valid_X, 
           'valid_Y':valid_Y, 
           'test_X':test_X, 
           'test_Y':test_Y}

    return res


if __name__ == "__main__":
    tf.app.run()
