"""
common text similarity model 
"""
from sentence_transformers import SentenceTransformer, util
import torch
import sys
import numpy as np

def load_text(path):
    """load text 
    """
    text = []
    with open(path) as f:
        for line in f:
            one = line.strip("\n")
            text.append(one)
    return text

def main():
    """ a simple demo
    """
    model_path = sys.argv[1]
    model = SentenceTransformer(model_path)
    
    train_text_path = sys.argv[2]

    train_text = load_text(train_text_path)
    print("load train text done")
    
    train_text_embeddings = model.encode(train_text, convert_to_tensor=True)
    print("train text embeddings done")
    
    test_text_path = sys.argv[3] 
    test_text = load_text(test_text_path)
    print("load test text done")
    
    top_k = 5
    for query in test_text:
        query_embedding = model.encode(query, convert_to_tensor=True)
        cos_scores = util.pytorch_cos_sim(query_embedding, train_text_embeddings)[0]
        cos_scores = cos_scores.cpu()

        top_results = torch.topk(cos_scores, k=top_k)

        print("\nQuery:", query)
        print("Top 5 most similar sentences:")

        for score, idx in zip(top_results[0], top_results[1]):
            if score - 0.85 > 0.000000001:
                print(train_text[idx], "(Score: %.4f)" % (score))

if __name__ == "__main__":
    main()
