# text similarity

通用文本相似能力建设。python3.6 + pytorch开发。



## 案例应用

风险|query|top1结果|score
-|-|-|-
低俗|耕了嫂子的旱地后，她直夸我力气大，说他家养的牛都比不上|嫂子说，我是村里仅有的村医，我为我的嫂子，我也要竭尽所能|0.93
低俗|#{地域}农村女人，单身很无聊，想约会的来找我|单身女人，找#{地域}附近男人，无要求，看的上的来聊聊|0.93
封建迷信|最近一直不顺_怎么化解,摆脱霉运,看我的经历犯小人如何化解只需要一个简单的生活习惯改变.犯小人如何化解可招财.!防小人.保健康|财运不好怎么办?睡前一个旺财小妙招自己总是挣钱存不住,投资,股票这些一碰就赔,而别人却财运滚滚,想要改变,你只需要这一招|0.93
政敏|今天社会上有几个人不诅咒邓先富的    2770738641  邓富了还能让老百姓吃饱肚子，比某些人自己吃得肥头大耳，饿死几千万老百姓强多了！|中九7月13日，最新升级数据老共不是一般的坏，嘴巴天天在囔囔社会主义人人平等，为人民服务，中九那是穷人的基本娱乐都剥削了！铭记爷爷的>遗训：国民党很坏可是他的对手更阴更毒，说一套做一套|0.89
政敏|谷丽萍是什么人？谷丽萍父亲是谁  1954991866  薄古开来生长于名门望族，多才多艺，父亲谷景生是著名的“一二?九”运动>发起人之一，为中第五女|江姐头可断血可流的下句是什么    共产党员的意志是你永远打垮不了的|0.86
暴恐|黄河捞尸人：9年间我捞上来800多具尸体，却最怕打捞到花季女尸|直击真实黄河捞尸人：不信鬼神，按家庭条件收费，最怕捞到这种人|0.87
暴恐|民间骇人听闻的接阴婆，一句话道出什么人会早死，并非是迷信|民间骇人听闻的阴生子，并非全是迷信，有见过这种的要小心|0.93

## 使用说明
一 python包地址
afs://shaolin.afs.baidu.com:9902/app/ecom/fengkong/personal/liuxingwang/tool/pytorch.tar.gz

afs://shaolin.afs.baidu.com:9902/app/ecom/fengkong/personal/liuxingwang/model/text_similarity/sentence_transformers.tar.gz

二 模型文件地址
afs://shaolin.afs.baidu.com:9902/app/ecom/fengkong/personal/liuxingwang/model/text_similarity/demo.tar.gz

运行方式
```
./pytorch/bin/python similarity.py $model_path $train_file $test_file 

```

数据格式
train_file test_file格式见dataset


## 模型说明
## 注意
输入文本不要太短，对语义不明的可能有误杀。如按摩、spa
