# porn_fengkong_feed

feed低质广告-低俗标题识别, 通过中台对外提供风险能力输出。

#### 使用说明
(1)获得数据，并且做一些切词处理等操作
```bash
cd porn_fengkong_feed/
sh bin/get_all_data.sh

```

#### 低俗风险标签一共划分为16个风险标签

各风险分类以及label：

label|风险标签
-|-
0|其它
1|直婚交友
2|脱单交友
3|单约交友
4|性暗示
5|低俗小说
6|低俗漫画
7|低俗娱乐
8|直播交友
9|妇科相关
10|妇科疾病
11|男科医院
12|男科疾病
13|成人用品
14|肾亏补肾壮阳
15|两性保健
16|调理闭经

其中16-调理闭经为高准词表，不需要经过模型。


处理后，且切完词的数据格式如下：

```
#label 切词后文本数据 
0	消费 太 高 ， 咨询 少 ？ 商家 竞价 外包 ， 一站式 竞价 托管 公司 ！
```

(2)简单的liblinear操作：

```bash
cd porn_fengkong_feed/
sh bin/run_liblinear.sh

```
可以输出LR+Ngram 模型的预测结果&&模型准确率

(3)深度学习模型bilstm&&gru

```bash
cd porn_fengkong_feed/
sh bin/run_train.sh

```

其中bash可更改模型配置以及是否使用GPU运算
```bash

CKPT_PATH=${MODEL_DIR}/gru_model
MODEL_TYPE=${MODEL_TYPE:-gru_net}
USE_CUDA=${USE_CUDA:-false}

}
```
模型训练迭代流程参数

```bash

        --batch_size 16 \
        --save_steps 100 \
        --validation_steps 100 \
        --epoch 20 \
        --skip_steps 10

}
```

(4) ERNIE
使用ERNIE+FINETUNE的方式来训练多分类模型，可以达到目前针对此场景的最优效果

使用ERNIE的整体方案，见wiki:http://wiki.baidu.com/pages/viewpage.action?pageId=1224131471

模型FINETUNE训练过程需要用到(1)步获得的数据

训练示例

```bash
cd porn_fengkong_feed/
python3 src/ernie_finetune_train.py research_data/train_data_Lib.txt research_data/eval_data_lib.txt
```
其中训练过程中的某些参数
```bash
epochs=10
batch_size=32
max_seq_len=60
```
视具体情况使用

预测（推理）示例
```
cd porn_fengkong_feed/
cat research_data/eval_data_lib.txt | python3 src/ernie_predict.py
```
预测过程中需使用训练得到的最佳模型参数

(5)ERNIE复杂网络蒸馏
ERNIE模型在经过FineTune后多分类中的效果要显著优于LR+Ngram模型，但是ERNIE模型复杂，参数庞大，训练以及推理过程需求较大的计算资源,需要一个更简单但是能够复现ERNIE良好效果的轻量级模型来增加问题的处理性能，知识蒸馏正是符合这一需求。
详情见wiki: http://wiki.baidu.com/pages/viewpage.action?pageId=1241652498
过程（4）可获得最佳ERNIE模型
使用此模型来进行知识蒸馏
具体分为三步:
1. 训练好复杂模型-（4）done
2. 引入unlabel data
3. 拟合teacher model 与 student model

*2.引入unlabel data
业务背景基于feed信息流数据进行风险识别，可以根据全量预测数据，按照标签均匀抽样，数据量为有标注的训练数据的3-10倍
```bash
sh bin/distill_infer_unlabel.sh
```
ps:获得数据，未标注的数据来自feed线上,经过训练好的teacher模型推理，合并标注数据作为student模型的训练数据

*3.拟合teacher model && student model
```
loss_ce = student_model(data, labels=label)
loss_kd = KL(logits_s, logits_t) #由KL divergence度量teacher模型输出值与student模型输出值
loss = loss_ce + loss_kd
```
即student模型从真实数据中获得经验+从teacher网络中学习经验，学习出类似teacher的输出形式且符合现实的模型

具体整个蒸馏过程为
```bash
sh bin/run_distill.sh
```
分步骤
1 unlabel 推理，与标注数据合并作为最终训练数据
```bash
cd porn_fengkong_feed/
sh bin/distill_infer_unlabel.sh
```
其中ERNIE模型是(4)训练好的模型
```bash
cat ${LOCAL_OUT_PATH}train_data_lib.txt ${LOCAL_OUT_PATH}unlabel_train.txt > ${LOCAL_OUT_PATH}distill_train.txt
```
是将已标注的数据和teacher模型推理的数据进行混合，交给student模型
2 训练student模型
这里主要是利用 1 获得的数据进行训练，并且是基于CNN分词粒度来进行学习
```bash
cd porn_fengkong_feed/
python3 src/ernie_distill.py research_data/distill_train.txt research_data/distill_train_seg.txt research_data/vocab_distill.txt research_data/eval_data.txt research_data/eval_data.txt
```

这里主要是利用 1 获得的数据进行训练，并且主要是基于CNN 字粒度来进行学习
```bash
python3 src/ernie_distill_char.py research_data/distill_train.txt research_data/eval_data.txt
```

3 模型效果对比

模型|模型效果
-|-
ERNIE+FC|acc: 95.62%; P: 95%; R: 91%;F1:  93%
ERNIE+CNN(word)|acc: 92.95%; P: 89%; R: 86%; F1: 87%
ERNIE+CNN(char)|acc: 93.97%; P: 90%; R: 84%; F1: 86%
ERNIE+CNN+unlabel_data(char)|acc: 95.02%; P: 93%; R: 90%; F1:  91%

由此可见，通过蒸馏将复杂的ERNIE模型转化为简单的CNN模型, 在保证模型效果损失很小的前提下，做到了极大的简化模型，极大的节省了计算资源。

(6) HttpService
部署在GPU机器上，基于HTTP通信,CPU机器上直接预测模型
```bash
nohup python3 httpService/http_service_gpu.py > httpService/http_log.txt 2>&1  &
```

(7)模型效果评估

- P：
- R：
- F1

示例
```python
import sys
from sklearn.metrics import classification_report

if __name__ == "__main__":
    predict = []
    label = []
    for line in sys.stdin:
        each_list = line.strip().split("\t")
        label.append(int(each_list[1]))
        predict.append(int(each_list[2]))
    print (classification_report(label, predict))
```
