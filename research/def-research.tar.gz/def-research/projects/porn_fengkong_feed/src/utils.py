#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
Author:   shenhao02@baidu.com
Date  :   20/09/01 14:47:35
Desc  :   Arguments for configuration
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import six
import argparse
import io
import sys
import random
import numpy as np
import os
import re

import paddle
import paddle.fluid as fluid

base_dir = os.path.abspath('.')
stop_file = base_dir + "/" + "dict/stopword.txt"

class Ngram(object):
    """
    Ngram class
    """
    def __init__(self, stopword):
        self.stopword = stopword

    def extract_feature(self, text_seg):
        """
        extract feature
        """
        features = set()
        skip_word = []
        for seg in text_seg:
            if seg in self.stopword:
                features |= self.get_ngram(skip_word, 4)
                skip_word = []
                continue
            skip_word.append(seg)
        if len(skip_word)>0:
            features |= self.get_ngram(skip_word, 4)
        return features

    def get_ngram(self, skip_word, num):
        """
        get ngram feature
        """
        ngram = set()
        word_num = len(skip_word)
        for i in range(word_num):
            if len(skip_word[i]) > 1:
                ngram.add(skip_word[i])
                for j in range(1, num):
                    if i + j > word_num:
                        break
                    word = "".join(skip_word[i: i + j])
                    if len(word) > 1:
                        ngram.add(word)
        return ngram

def str2bool(v):
    """
    String to Boolean
    """
    # because argparse does not support to parse "true, False" as python
    # boolean directly
    return v.lower() in ("true", "t", "1")


class ArgumentGroup(object):
    """
    Argument Class
    """
    def __init__(self, parser, title, des):
        self._group = parser.add_argument_group(title=title, description=des)

    def add_arg(self, name, type, default, help, **kwargs):
        """
        Add argument
        """
        type = str2bool if type == bool else type
        self._group.add_argument(
            "--" + name,
            default=default,
            type=type,
            help=help + ' Default: %(default)s.',
            **kwargs)


def print_arguments(args):
    """
    Print Arguments
    """
    print('-----------  Configuration Arguments -----------')
    for arg, value in sorted(six.iteritems(vars(args))):
        print('%s: %s' % (arg, value))
    print('------------------------------------------------')


def init_checkpoint(exe, init_checkpoint_path, main_program):
    """
    Init CheckPoint
    """
    assert os.path.exists(
        init_checkpoint_path), "[%s] cann't be found." % init_checkpoint_path
    try:
        checkpoint_path = os.path.join(init_checkpoint_path, "checkpoint")
        fluid.load(main_program, checkpoint_path, exe)
    except:
        fluid.load(main_program, init_checkpoint_path, exe)
    #print("Load model from {}".format(init_checkpoint_path))

    
def data_reader(file_path, word_dict, num_examples, phrase, epoch, max_seq_len):
    """
    Convert word sequence into ids
    """
    unk_id = len(word_dict)
    pad_id = 0
    all_data = []
    stopword = set()
    with open(stop_file, "r", encoding="gb18030")as fr:
        for line in fr:
            stopword.add(line.strip())
    with open(file_path, "r", encoding="gb18030") as fin:
        for line in fin:
            cols = line.strip().split("\t")
            if len(cols) != 2:
                sys.stderr.write("[NOTICE] Error Format Line!")
                continue
            label = int(cols[0])
            text = cols[1].split(" ")
            ngram_deal = Ngram(stopword)
            ngram_list = ngram_deal.extract_feature(text)
            wids = []
            for seg in ngram_list:
                if seg in word_dict:
                    wids.append(word_dict[seg])
                else:
                    wids.append(word_dict["<unk>"])
            seq_len = len(wids)
            if seq_len < max_seq_len:
                for i in range(max_seq_len - seq_len):
                    wids.append(pad_id)
            else:
                wids = wids[:max_seq_len]
                seq_len = max_seq_len
            all_data.append((wids, label, seq_len))

    if phrase == "train":
        random.shuffle(all_data)

    num_examples[phrase] = len(all_data)
        
    def reader():
        """
        Reader Function
        """
        for epoch_index in range(epoch):
            for doc, label, seq_len in all_data:
                yield doc, label, seq_len
    return reader

def load_vocab(file_path):
    """
    load the given vocabulary
    """
    vocab = {}
    with open(file_path, 'r', encoding="gb18030") as f:
        wid = 0
        for line in f:
            if line.strip().split("\t")[1] not in vocab:
                vocab[line.strip().split("\t")[1]] = wid
                wid += 1
    vocab["<unk>"] = len(vocab)
    return vocab


def init_pretraining_params(exe,
                            pretraining_params_path,
                            main_program,
                            use_fp16=False):
    """load params of pretrained model, NOT including moment, learning_rate"""
    assert os.path.exists(pretraining_params_path
                          ), "[%s] cann't be found." % pretraining_params_path

    fluid.load(main_program, pretraining_params_path, exe)
    print("Load pretraining parameters from {}.".format(
        pretraining_params_path))
