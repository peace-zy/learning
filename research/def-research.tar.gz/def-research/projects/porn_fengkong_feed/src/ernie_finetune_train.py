#!/usr/bin/python3
# -*- coding: gbk -*-
"""
  Author: shenhao02@baidu.com
  Date  : 20/08/03 10:53:32
  File  : ernie_finetune_train.py
  Desc  : ERNIE FINETUNE 
"""
import os
import sys
import time
#������������,����Ĭ�ϲ�ʹ��GPU
#os.environ["CUDA_VISIBLE_DEVICES"] = "0"

import numpy as np
import paddle as P
import paddle.fluid as F
import paddle.fluid.layers as L
import paddle.fluid.dygraph as D
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report

from ernie.tokenizing_ernie import ErnieTokenizer
from ernie.modeling_ernie import ErnieModelForSequenceClassification

#���ú����еĳ�����������ERNIE����ѧϰ���Ƽ�ȡ1e-5/2e-5/5e-5, �����Դ��С����BATCH��С, �����ӳ��Ȳ�����512.
LR = 5e-5
MODEL_SAVE_PATH = "model/ernie_finetune_model/"
data_path = sys.argv[1]
eval_path = sys.argv[2]

D.guard().__enter__() # Ϊ����Paddle���붯̬ͼģʽ����Ҫ������һ������ǰ��

# ��ȡ����
ernie = ErnieModelForSequenceClassification.from_pretrained('ernie-1.0', num_labels=16)
optimizer = F.optimizer.Adam(LR, parameter_list=ernie.parameters())
tokenizer = ErnieTokenizer.from_pretrained('ernie-1.0')
label_list = []
data_list = []
eval_label_list = []
eval_data_list = []

with open(data_path, "r", encoding = "gb18030") as fr:
    for line in fr:
        each_list = line.strip().split("\t")
        label_list.append(int(each_list[0]))
        data_list.append(each_list[1].encode("utf-8"))

with open(eval_path, "r", encoding = "gb18030") as fr:
    for line in fr:
        each_list = line.strip().split("\t")
        eval_label_list.append(int(each_list[0]))
        eval_data_list.append(each_list[1].encode("utf-8"))

label_ids = label_list
eval_label_ids = eval_label_list
print("tokenizer encode start")
start_time = time.time()
data_ids = [tokenizer.encode(x)[0] for x in data_list]
eval_data_ids = [tokenizer.encode(x)[0] for x in eval_data_list]
print("cost time: %.4fs" % (time.time() - start_time))

train_data = list(zip(data_ids, label_ids))
eval_data = list(zip(eval_data_ids, eval_label_ids))

#������������ݣ�һ��batch һ��batch�Ļ�ȡ
def gen_batch_data(data_iter, batch_size=32, max_seq_len=60):
    """
    generator����
    """
    batch_data = list()
    def batch_process(cur_batch_data, cur_batch_size):
        """
        ����batch �����ݴ���
        """
        # zip �ϲ� zip(*)��
        data_list, label_list = zip(*cur_batch_data)
        # ��������
        # ȷ����ǰ������󳤶�,����ǰbatch����󳤶�
        cur_max_len = max([len(x) for x in data_list])
        cur_max_len = max_seq_len if cur_max_len > max_seq_len else cur_max_len
        # padding
        data_list = [np.pad(x[:cur_max_len], [0, cur_max_len - len(x[:cur_max_len])], 
                    mode = 'constant') for x in data_list]

        # תnumpy array
        try:
            data_np = np.array(data_list).reshape([cur_batch_size, cur_max_len])
        except ValueError as e:
            print("data list: {}".format(data_list))
            raise e
        data = D.to_variable(data_np)
        label_np = np.array(label_list)
        # תpaddle tensor
        label = D.to_variable(label_np)

        return data, label

    for data, label in data_iter:
        if len(batch_data) == batch_size:
            # ��ǰ�����һ��batch
            yield batch_process(batch_data, batch_size)
            batch_data = list()
        batch_data.append((data, label))

    if len(batch_data) > 0:
        yield batch_process(batch_data, len(batch_data))

def infer(model, infer_data, batch_size=32, max_seq_len=60):
    """
    ��������,ȫ���Ӳ����logits
    ����softmax
    """
    all_pred = []
    all_label = []
    # �����with����ernie��������ݶȼ��㣻
    with D.base._switch_tracer_mode_guard_(is_train=False):
        # ����ģ�ͽ���evalģʽ���⽫��ر����е�dropout��
        model.eval()
        infer_data_batch = gen_batch_data(
                infer_data,
                batch_size=batch_size,
                max_seq_len=max_seq_len)

        for cur_infer_step, (cur_infer_data, cur_infer_label) in enumerate(infer_data_batch):
            _, logits = model(cur_infer_data)
            cur_pred = L.argmax(logits, -1).numpy()
            cur_label = cur_infer_label.numpy()
            all_pred.extend(cur_pred)
            all_label.extend(cur_label)
            if cur_infer_step % 100 == 0:
                print('infer step %d' % (cur_infer_step))
        # ����trainģʽ
        model.train()
    return all_pred, all_label

def eval(model, eval_data, batch_size=32, max_seq_len=60):
    """
    ��Ҫ��������֤ģ�͵ķ�������
    """
    all_pred, all_label = infer(model, eval_data, batch_size, max_seq_len)
    print(classification_report(all_label, all_pred))
    acc = (np.array(all_label) == np.array(all_pred)).astype(np.float32).mean()
    return acc

def train(model, train_data, eval_data, model_save_path=None, epochs=10, batch_size=32, max_seq_len=60):
    """
    ģ�͵�ѵ������
    [in] model-ģ��
         train_data ѵ������
         eval_data ��֤����
         model_save_path ģ�ʹ���·��
         epochs ģ�͵���������Ĭ��Ϊ10
         batch_size batchĬ��32
         max_seq_len �����feed���ı���Ĭ��60
    """
    best_acc = 0.0
    for cur_epoch in range(epochs):
        each_epoch_loss = 100.0
        min_loss_acc = 0.0
        np.random.shuffle(train_data)
        train_data_batch = gen_batch_data(train_data, batch_size=batch_size, max_seq_len=max_seq_len)
        for cur_train_step, (cur_train_data, cur_train_label) in enumerate(train_data_batch):
            loss, logits = model(cur_train_data, labels=cur_train_label)
            loss.backward()
            optimizer.minimize(loss)
            model.clear_gradients()
            if cur_train_step % 10 == 0:
                cur_pred = L.argmax(logits, -1).numpy()
                cur_label = cur_train_label.numpy()
                accuracy = accuracy_score(cur_label, cur_pred)
                if loss.numpy() < each_epoch_loss:
                    each_epoch_loss = loss.numpy()
                    min_loss_acc = accuracy
                print('train epoch %d, step %d: loss %.5f, accu %.5f' 
                         % (cur_epoch, cur_train_step, loss.numpy(), accuracy))
        
        #������֤ÿһ�ֵ�Ч��
        acc = eval(model, eval_data, batch_size=batch_size, max_seq_len=max_seq_len)
        print('eval epoch %d, min loss acc %.5f, min loss %.5f, this epoch eval acc %.5f' 
                % (cur_epoch, min_loss_acc, each_epoch_loss, acc))

        if model_save_path is not None:
            print("save model at epoch {}".format(cur_epoch))
            start_time = time.time()
            F.save_dygraph(ernie.state_dict(), model_save_path + "_epoch{}".format(cur_epoch))
            print("cost time: %.4fs" % (time.time() - start_time))

            if acc > best_acc:
                print("cur best acc score, save model at epoch {} as best model".format(cur_epoch))
                start_time = time.time()
                F.save_dygraph(ernie.state_dict(), model_save_path + "_best")
                print("cost time: %.4fs" % (time.time() - start_time))
                best_acc = acc

BEST_MODEL_PATH = MODEL_SAVE_PATH + "_best"
if os.path.exists(BEST_MODEL_PATH + ".pdparams"):
    print("load model from {}".format(BEST_MODEL_PATH))
    start_time = time.time()
    sd, _ = D.load_dygraph(BEST_MODEL_PATH)
    ernie.set_dict(sd)
    print("cost time: %.4fs" % (time.time() - start_time))

print("train model start")
start_time = time.time()
train(ernie, train_data, eval_data, model_save_path=MODEL_SAVE_PATH, epochs=20, batch_size=32, max_seq_len=60)
print("cost time: %.4fs" % (time.time() - start_time))

