#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
Author:   shenhao02@baidu.com
Date  :   20/09/01 14:47:35
Desc  :   Classification Predict
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import time
import argparse
import numpy as np
import sys
import re
import math

from config import PDConfig
from bilstm import bilstm_net
from gru import gru_net
import paddle
import paddle.fluid as fluid

import reader
from utils import init_checkpoint

base_dir = os.path.abspath('.')
stop_file = base_dir + "/" + "dict/stopword.txt"
dict_file = base_dir + "/" + "research_data/vocab_train_seg.txt"

class Ngram(object):
    """
    ngrm�㷨��
    """
    def __init__(self, stopword):
        self.stopword = stopword
    
    def extract_feature(self, text_seg):
        """
        ��ȡngram ����
        """
        features = set()
        skip_word = []
        for seg in text_seg:
            if seg in self.stopword:
                features |= self.get_ngram(skip_word, 4)
                skip_word = []
                continue
            skip_word.append(seg)
        if len(skip_word)>0:
            features |= self.get_ngram(skip_word, 4)
        return features
    
    def get_ngram(self, skip_word, num):
        """
        ngramʵ��
        """
        ngram = set()
        word_num = len(skip_word)
        for i in range(word_num):
            for j in range(1, num):
                if i + j > word_num:
                    break
                word = "".join(skip_word[i: i + j])
                if len(word) > 1:
                    ngram.add(word)
        return ngram


def create_model(args, pyreader_name, num_labels, is_prediction=False):
    """
    �ֱ����bilstm��gruģ��
    """

    #����ÿ���ı�������
    data = fluid.data(
        name="src_ids", shape=[None, args.max_seq_len], dtype='int64')
    label = fluid.data(name="label", shape=[None, 1], dtype="int64")
    seq_len = fluid.data(name="seq_len", shape=[None], dtype="int64")

    if args.model_type == "bilstm_net":
        network = bilstm_net
    elif args.model_type == "gru_net":
        network = gru_net
    else:
        raise ValueError("Unknown network type!")

    if is_prediction:
        probs = network(
            data, seq_len, None, args.vocab_size, is_prediction=is_prediction)
        return probs, [data.name, seq_len.name]

    ce_loss, probs = network(
        data, seq_len, label, args.vocab_size, is_prediction=is_prediction)
    loss = fluid.layers.mean(x=ce_loss)
    num_seqs = fluid.layers.create_tensor(dtype='int64')
    accuracy = fluid.layers.accuracy(input=probs, label=label, total=num_seqs)
    return [loss, accuracy], num_seqs

def main(args):
    """
    ��Ҫʵ��Ԥ�⹦��
    """
    if args.use_cuda:
        place = fluid.CUDAPlace(0)
        dev_count = 1
    else:
        place = fluid.CPUPlace()
        dev_count = 1
    exe = fluid.Executor(place)
    word_dict = {}
    stopword = set()
    time_begin = time.time()

    with open(dict_file, "r", encoding="gb18030")as fr:
        index = 0
        for line in fr:
            word = line.strip().split("\t")[1]
            if word not in word_dict:
                word_dict[word] = index
                index += 1
            word_dict["<unk>"] = index

    with open(stop_file, "r", encoding="gb18030")as fr:
        for line in fr:
            word = line.strip()
            stopword.add(word)

    #����ģ��
    task_name = args.task_name.lower()
    processor = reader.ClassProcessor(
        data_dir=args.data_dir,
        vocab_path=args.vocab_path,
        random_seed=args.random_seed,
        max_seq_len=args.max_seq_len)
    num_labels = len(processor.get_labels())

    if not (args.do_train or args.do_val or args.do_infer):
        raise ValueError("For args `do_train`, `do_val` and `do_infer`, at "
                         "least one of them must be True.")

    startup_prog = fluid.Program()
    if args.random_seed is not None:
        startup_prog.random_seed = args.random_seed
    
    prop = None
    infer_prog = fluid.Program()
    with fluid.program_guard(infer_prog, startup_prog):
        with fluid.unique_name.guard():
            prop, _ = create_model(
                args,
                pyreader_name='infer_reader',
                num_labels=num_labels,
                is_prediction=True)

    infer_prog = infer_prog.clone(for_test=True)
    exe.run(startup_prog)
    if not args.init_checkpoint:
        raise ValueError("args 'init_checkpoint' should be set if"
                             "only doing validation or testing!")
    init_checkpoint(exe, args.init_checkpoint, main_program=startup_prog)
    
    #ģ�ͼ�����ɺ󣬶����ݽ���Ԥ��
    for line in sys.stdin:
        each_list = line.strip().split("\t")
        text = each_list[1]
        label = each_list[0]

        #��Ҫ��Ϊ�˻��������������ʾ
        seg_text = text.split(" ")
        ngram = Ngram(stopword)
        features = ngram.extract_feature(seg_text)
        wids = []
        for seg in features:
            if seg in word_dict:
                wids.append(word_dict[seg])
            else:
                wids.append(word_dict["<unk>"])
        seq_length = len(wids)
        if seq_length < args.max_seq_len:
            for i in range(args.max_seq_len - seq_length):
                wids.append(0)
        else:
            wids = wids[:args.max_seq_len]
        wids = np.array(wids).reshape(1, 128).astype("int64")

        np_props = exe.run(program = infer_prog, feed = {"src_ids": wids, "seq_len": np.array([seq_length])}, 
                          fetch_list=[prop.name], return_numpy=True)
        probs = np_props[0][0]
        predict = np.argmax(probs)
        max_p = 0.0
        for p in  probs:
            if p > max_p:
                max_p = p

        print ("%s\t%s\t%d\t%f" % (text, label, predict, max_p))

if __name__ == "__main__":
    args = PDConfig('class_config.json')
    args.build()
    #���Ŀǰ��������ѡ
    args.print_arguments()
    main(args)
