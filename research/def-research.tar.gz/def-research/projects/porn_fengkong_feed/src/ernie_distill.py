#!/usr/bin/python3
# -*- coding: gbk -*-
"""
  Author: shenhao02@baidu.com
  Date  : 20/09/08 19:27:56
  File  : ernie_distill.py
  Desc  : �Դ����ȣ�ѵ��CNNģ������
"""
import sys
import os
#����������GPU
#os.environ["CUDA_VISIBLE_DEVICES"] = "0"

import numpy as np
import time
from sklearn.metrics import f1_score
from sklearn.metrics import classification_report
import paddle as P
import paddle.fluid as F
import paddle.fluid.layers as L
import paddle.fluid.dygraph as D

from ernie.tokenizing_ernie import ErnieTokenizer
from ernie.modeling_ernie import ErnieModelForSequenceClassification
from ernie.optimization import AdamW, LinearDecay

#����ģ���ļ�
MODEL_SAVE_PATH = "./model/ernie_finetune_model/"

D.guard().__enter__() # Ϊ����Paddle���붯̬ͼģʽ����Ҫ������һ������ǰ��

# ��ȡ����
ernie = ErnieModelForSequenceClassification.from_pretrained('ernie-1.0', num_labels=16)
tokenizer = ErnieTokenizer.from_pretrained('ernie-1.0')
#����ѵ���õ�teacherģ��
if os.path.exists(MODEL_SAVE_PATH + "_best.pdparams"):
    sd, _ = D.load_dygraph(MODEL_SAVE_PATH + "_best.pdparams")
    ernie.set_dict(sd)

class CNN(D.Layer):
    """
    CNN ����ṹ
    """
    def __init__(self):
        super().__init__()
        self.emb = D.Embedding([32541, 48], padding_idx=0)
        self.cnn = D.Conv2D(48, 128, (1, 3), padding=(0, 1), act='relu')
        self.pool = D.Pool2D((1, 3), pool_padding=(0, 1))
        self.fc = D.Linear(128, 16)
    def forward(self, ids, labels=None):
        """
        cnn network
        """
        embbed = self.emb(ids)
        hidden = embbed
        hidden = L.transpose(hidden, [0, 2, 1]) #change to NCWH
        hidden = L.unsqueeze(hidden, [2])
        hidden = self.cnn(hidden)
        hidden = self.pool(hidden)
        hidden = L.squeeze(hidden, [2])
        hidden = L.transpose(hidden, [0, 2, 1])
        pad_mask = L.unsqueeze(L.cast(ids != 0, 'float32'), [-1])
        hidden = L.softsign(L.reduce_sum(hidden * pad_mask, 1))
        logits = self.fc(hidden)
        if labels is not None:
            if len(labels.shape) == 1:
                labels = L.reshape(labels, [-1, 1])
            loss = L.softmax_with_cross_entropy(logits, labels)
            loss = L.reduce_mean(loss)
        else:
            loss = None
        return loss, logits


def KL(pred, target):
    """
    KLɢ��
    """
    pred = L.log(L.softmax(pred))
    target = L.softmax(target)
    loss = L.kldiv_loss(pred, target)
    return loss

def gen_batch_data(data_iter, batch_size=32, max_seq_len=60, max_stu_len=64):
    """
    generator����
    [in] data
         bacth size
         max seq len
         max stu len
    """
    batch_data = list()
    def batch_process(cur_batch_data, cur_batch_size):
        """
        batch process
        """
        # zip �ϲ� zip(*)��
        data_list, label_list, stu_data_list = zip(*cur_batch_data)
        # ��������
        # ȷ����ǰ������󳤶�,����ǰbatch����󳤶�
        cur_max_len = max([len(x) for x in data_list])
        cur_max_len = max_seq_len if cur_max_len > max_seq_len else cur_max_len
        # padding
        data_list = [np.pad(x[:cur_max_len], [0, cur_max_len - len(x[:cur_max_len])], 
                     mode = 'constant') for x in data_list]
        # תnumpy array
        stu_max_len = max([len(x) for x in stu_data_list])
        stu_max_len = max_stu_len if stu_max_len > max_stu_len else stu_max_len
        # padding
        stu_data_list = [np.pad(x[:stu_max_len], [0, stu_max_len - len(x[:stu_max_len])], 
                        mode = 'constant') for x in stu_data_list]
        try:
            data_np = np.array(data_list).reshape([cur_batch_size, cur_max_len])
            stu_data_np = np.array(stu_data_list).reshape([cur_batch_size, stu_max_len])
        except ValueError as e:
            print("data list: {}".format(data_list))
            raise e
        data = D.to_variable(data_np)
        stu_data = D.to_variable(stu_data_np)
        label_np = np.array(label_list)
        # תpaddle tensor
        label = D.to_variable(label_np)

        return data, label, stu_data

    for data, label, stu_data in data_iter:
        if len(batch_data) == batch_size:
            # ��ǰ�����һ��batch
            yield batch_process(batch_data, batch_size)
            batch_data = list()
        batch_data.append((data, label, stu_data))

    if len(batch_data) > 0:
        yield batch_process(batch_data, len(batch_data))

def infer(model, infer_data, batch_size=32, max_stu_len=64):
    """
    ��������
    """
    all_pred = []
    all_label = []
    # �����with����ernie��������ݶȼ��㣻
    with D.base._switch_tracer_mode_guard_(is_train=False):
        # ����ģ�ͽ���evalģʽ���⽫��ر����е�dropout��
        model.eval()
        infer_data_batch = gen_batch_data(infer_data)
        for cur_infer_step, (cur_infer_data, cur_infer_label, cur_infer_student) in enumerate(infer_data_batch):
            _, logits = model(cur_infer_student)
            cur_pred = L.argmax(logits, -1).numpy()
            cur_label = cur_infer_label.numpy()
            all_pred.extend(cur_pred)
            all_label.extend(cur_label)
        # ����trainģʽ
        model.train()
    return all_pred, all_label

def eval_test(model, eval_data, batch_size=32, max_stu_len=64):
    """
    ͨ����֤����
    ����ģ�ͷ�������
    """
    all_pred, all_label = infer(model, eval_data, batch_size, max_stu_len)
    print(classification_report(all_label, all_pred))
    f1 = f1_score(all_label, all_pred, average='macro')
    acc = (np.array(all_label) == np.array(all_pred)).astype(np.float32).mean()
    return acc

if __name__ == "__main__":
    train_data = sys.argv[1]
    train_data_seg = sys.argv[2]
    dict_file = sys.argv[3]
    label_list = []
    data_list = []
    stu_data_ids = []
    with open(train_data, "r", encoding = "gb18030") as fr:
        for line in fr:
            each_list = line.strip().split("\t")
            label_list.append(int(each_list[0]))
            data_list.append(each_list[1].encode("utf-8"))
    
    vocab_dict = dict()
    with open(dict_file, "r", encoding = "gb18030") as fr:
        index = 0
        for line in fr:
            each_list = line.strip().split("\t")
            word = each_list[0]
            if word not in vocab_dict:
                vocab_dict[word] = index
                index += 1
        vocab_dict['<unk>'] = index
    
    with open(train_data_seg, "r", encoding="gb18030") as fr:
        for line in fr:
            stu_data = []
            each_list = line.strip().split("\t")
            text = each_list[1]
            text_seg = text.split(" ")
            for seg in text_seg:
                if seg in vocab_dict:
                    stu_data.append(vocab_dict[seg])
                else:
                    stu_data.append(vocab_dict['<unk>'])
            stu_data_ids.append(stu_data)
    
    label_ids = label_list
    data_ids = [tokenizer.encode(x)[0] for x in data_list]
    stu_train_data = list(zip(data_ids, label_ids, stu_data_ids))
    
    eval_data = sys.argv[4]
    eval_data_seg = sys.argv[5]
    eval_label_list = []
    eval_data_list = []
    eval_stu_data_ids = []
    with open(eval_data, "r", encoding = "gb18030") as fr:
        for line in fr:
            each_list = line.strip().split("\t")
            eval_label_list.append(int(each_list[0]))
            eval_data_list.append(each_list[1].encode("utf-8"))
    
    with open(eval_data_seg, "r", encoding="gb18030") as fr:
        for line in fr:
            eval_stu_data = []
            each_list = line.strip().split("\t")
            text = each_list[1]
            text_seg = text.split(" ")
            for seg in text_seg:
                if seg in vocab_dict:
                    eval_stu_data.append(vocab_dict[seg])
                else:
                    eval_stu_data.append(vocab_dict['<unk>'])
            eval_stu_data_ids.append(eval_stu_data)
            
    eval_label_ids = eval_label_list
    eval_data_ids = [tokenizer.encode(x)[0] for x in eval_data_list]
    stu_eval_data = list(zip(eval_data_ids, eval_label_ids, eval_stu_data_ids))
    #�����Ҫ�Ǽ���studentģ����ص����� 
    EPOCH = 1
    model_save_path = "./model/student_model/"
    ernie.eval()
    model = CNN()
    LR = 5e-5
    g_clip = F.clip.GradientClipByGlobalNorm(1.0) #experimental
    opt = AdamW(learning_rate = LR, parameter_list = model.parameters(), weight_decay = 0.01, grad_clip = g_clip)
    model.train()
    
    max_acc_epoch  = 0.0
    for cur_epoch in range(EPOCH):
        # ÿ��epoch��shuffle�����Ի�����ѵ��Ч����
        np.random.shuffle(stu_train_data)
        train_data_batch = gen_batch_data(stu_train_data)
        for cur_train_step, (cur_train_data, cur_train_label, cur_stu_train) in enumerate(train_data_batch):
            _, logits_t = ernie(cur_train_data)
            logits_t.stop_gradient = True
            _, logits_s = model(cur_stu_train) # student ģ�����logits
            loss_ce, _ = model(cur_stu_train, labels = cur_train_label)
            loss_kd = KL(logits_s, logits_t)    # ��KL divergence���������ֲ��ľ���
            loss = loss_ce + loss_kd
            loss.backward()
            if cur_train_step % 10 == 0:
                print('[step %03d] distill train loss %.5f lr %.3e' 
                        % (cur_train_step, loss.numpy(), opt.current_step_lr()))
            opt.minimize(loss)
            model.clear_gradients()
        print("save model at epoch {}".format(cur_epoch))
        start_time = time.time()
        F.save_dygraph(model.state_dict(), model_save_path + "_epoch{}".format(cur_epoch))
        print("cost time: %.4fs" % (time.time() - start_time))
        # ÿһ�ֵ�������Ҫ��֤��ģ�͵ķ������������Ҽ�¼��ѵ�Ч��ģ��
        acc = eval_test(model, stu_eval_data)
        if acc > max_acc_epoch:
            max_acc_epoch = acc
            print("save best model at epoch {}".format(cur_epoch))
            print ("best acc is: %.5f" % (max_acc_epoch))
            F.save_dygraph(model.state_dict(), model_save_path + "_best")
    
    #hard train ����ѵ��
    train_data_batch = gen_batch_data(stu_train_data)
    for step, (cur_train_data, cur_train_label, cur_stu_data) in enumerate(train_data_batch):
        loss, _ = model(cur_stu_data, labels = cur_train_label)
        loss.backward()
        if step % 10 == 0:
            print('[step %03d] train loss %.5f lr %.3e' 
                    % (step, loss.numpy(), opt.current_step_lr()))
        opt.minimize(loss)
        model.clear_gradients()
    acc = eval_test(model, stu_eval_data)
    if acc > max_acc_epoch:
        max_acc_epoch = acc
        print("save hard model at epoch")
        F.save_dygraph(model.state_dict(), model_save_path + "_hard")
