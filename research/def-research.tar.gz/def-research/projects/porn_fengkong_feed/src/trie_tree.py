#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   shenhao02@baidu.com
Date  :   20/09/02 11:50:46
Desc  :   trie tree 
"""
import sys

class TrieTree(object):
    """
    ����Trie�����ṩ��ѯ�ӿ�,���еĴʶ���unicode�洢
    """
    def __init__(self):
        """
        ��ʼ��
        """
        self.trie_tree = {}

    def add_word(self, word):
        """
        ���Ӵ�
        """
        tree = self.trie_tree
        for char in word:
            if char in tree:
                tree = tree[char]
            else:
                tree[char] = {}
                tree = tree[char]
        tree['exist'] = True


    def search_word(self, word):
        """
        ��ѯ��
        """
        tree = self.trie_tree
        for char in word:
            if char in tree:
                tree = tree[char]
            else:
                return False
        if 'exist' in tree:
            return True
        return False

    def search_prefix(self, word):
        """
        tree���Ƿ��д���word��ǰ׺
        """
        tree = self.trie_tree
        prefix = ''
        for char in word:
            if char in tree:
                prefix += char
                if 'exist' in tree[char]:
                    return (True, prefix)
                tree = tree[char]
            else:
                break
        return (False, prefix)

    def search_all_prefix(self, word):
        """
        �����������еĴ�
        """
        tree = self.trie_tree
        prefix = []
        p = ""
        for char in word:
            if char in tree:
                p += char
                if 'exist' in tree[char]:
                    prefix.append(p)
                tree = tree[char]
            else:
                break
        if len(prefix) == 0:
            return (False, prefix)
        return (True, prefix)



if __name__ == "__main__":
    pass

