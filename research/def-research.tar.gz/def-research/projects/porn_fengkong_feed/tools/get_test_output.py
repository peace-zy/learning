#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   def-model@baidu.com
Date  :   20/09/08 15:39:00
Desc  :   
"""
import sys

test_predict_file = "./research_data/test_predict_lib.txt"

if __name__ == "__main__":
    label_list = []
    with open(test_predict_file, "r") as fr:
        for line in fr:
            label_list.append(line.strip())
    
    i = 0
    for line in sys.stdin:
        each_list = line.strip().split("\t")
        label = each_list[0]
        text = each_list[1]
        print "\t".join([text, label, str(label_list[i])])
        i += 1

