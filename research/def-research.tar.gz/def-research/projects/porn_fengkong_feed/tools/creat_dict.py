#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   def-model@baidu.com
Date  :   20/09/14 20:27:35
Desc  :   
"""
import sys
import re

if __name__ == "__main__":
    stopfile = sys.argv[1]
    stopword = set()
    chinese = re.compile('[\u4e00-\u9fa5]')
    with open(stopfile, "r")as fr:
        for line in fr:
            stopword.add(line.strip())

    vocab_set = set()
    for line in sys.stdin:
        each_list = line.strip().split("\t")
        text = each_list[1]
        text_seg = text.split(" ")
        for seg in text_seg:
            if (seg in stopword) or (not chinese.search(seg)):
                continue
            else:
                vocab_set.add(seg)
    for seg in vocab_set:
        print (seg)

