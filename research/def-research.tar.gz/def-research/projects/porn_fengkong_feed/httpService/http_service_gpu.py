#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: shenhao02@baidu.com
  Date  : 20/09/17 11:27:56
  File  : http_service_gpu.py
  Desc  : ������GPU�ϵ�http service
"""
from http.server import BaseHTTPRequestHandler, HTTPServer
import logging
import json
import ernie_batch_model


class Service(BaseHTTPRequestHandler):
    """
    get post service
    """
    def do_HEAD(self):
        """
        post response
        text/plain
        status 200
        """
        self.send_response(200)
        self.send_header('Content-type', 'text/plain')
        self.end_headers()

    def do_GET(self):
        """
        get
        """
        paths = {
            '/TestServer': {'status': 200},
            '/bar': {'status': 302},
            '/baz': {'status': 404},
            '/qux': {'status': 500}
        }

        if self.path in paths:
            self.respond(paths[self.path])
        else:
            self.respond({'status': 500})
        logging.info("GET request,\nPath: %s\nHeaders:\n%s\n", str(self.path), str(self.headers))

    def do_POST(self):
        """
        post
        """
        content_length = int(self.headers['Content-Length']) # <--- Gets the size of data
        post_data = self.rfile.read(content_length) # <--- Gets the data itself
        result = ernie.detector(post_data)

        logging.info("POST request,\nPath: %s\nHeaders:\n%s\n\nBody:\n%s\n",
                str(self.path), str(self.headers), post_data.decode('utf-8'))

        self.do_HEAD()
        #wfile.writeֱ�ӻ�д��ʡȥgetͨ��ʱ��
        self.wfile.write(json.dumps(result).encode('utf-8'))

    def respond(self, opts):
        """
        get response
        """
        response = self.handle_http(opts['status'], self.path)
        self.wfile.write(response)

    def handle_http(self, status_code, path):
        """
        get response
        text/html
        """
        self.send_response(status_code)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        # get ���ݿ������⣬���Ϊ�˲��ԣ���ʵû�õ�get
        content = '''
           <html><head><title>Title goes here.</title></head>
           <body></p>
           <p>You accessed path: {}</p>
           </body></html>
           '''.format(path)
        return bytes(content, 'UTF-8')


def run(server_class=HTTPServer, handler_class=Service, port=8080):
    """
    Ĭ�϶˿�8080
    """
    print("run()")
    logging.basicConfig(level=logging.INFO)
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    logging.info('Starting httpd...\n')
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    httpd.server_close()
    print("httpd.server_close()")
    logging.info('Stopping httpd...\n')


if __name__ == '__main__':
    ernie = ernie_batch_model.ErnieModel()

    from sys import argv
    if len(argv) == 2:
        run(port=int(argv[1]))
    else:
        run()
