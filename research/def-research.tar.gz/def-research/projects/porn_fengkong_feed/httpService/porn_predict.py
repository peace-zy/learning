#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   shenhao02@baidu.com
Date  :   20/09/17 11:43:56
Desc  :   ʵ�ʲ����У���http�������GPU���������Ԥ��ֵ�����
"""
import requests
import sys
import json
import time

url = "http://10.255.121.18:8080/TestServer"

def predict(predict_data_batch):
    """
    ����batch���ݵ�Ԥ��,softmax���
    """
    for cur_infer_data in predict_data_batch:
        data_dict = dict()
        data_dict ["data"] = cur_infer_data
        data_json = json.dumps(data_dict)
        payload = data_json
        #postheaders
        headers = {
                'content-Type': "text/plain",
                'Accept': "*/*",
                'Cache-Control': "no-cache",
                'Host': "10.255.121.18:8080",
                'accept-encoding': "gzip, deflate",
                'content-length': "1",
                'Connection': "keep-alive",
                'cache-control': "no-cache"
                }
        #post��post��д������get
        response = requests.request("POST", url, data=payload, headers=headers)
        json_dict = json.loads(response.text)
        for k, v in json_dict.items():
            data = json_dict[k]
            data_dict = json.loads(data)
            id = data_dict["id"]
            text = data_dict["text"]
            ssg1 = data_dict["ssg1"]
            ssg2 = data_dict["ssg2"]
            hit_word = data_dict["hit_word"]
            hit_label = data_dict["hit_word"]
            prob = data_dict["prob"]
            label = data_dict["label"]
            porn_fengkong = data_dict["porn_fengkong_exp_v1"]
            porn_sensitivity_fengkong = data_dict["porn_sensitivity_fengkong_exp_v1"]
            pre_dict = dict()
            pre_dict["porn_fengkong_exp_v1"] = float(porn_fengkong)
            pre_dict["porn_sensitivity_fengkong_exp_v1"] = float(porn_sensitivity_fengkong)
            print ("\t".join([id.encode("gb18030"), text.encode("gb18030"), 
                        ssg1.encode("gb18030"), ssg2.encode("gb18030"), json.dumps(pre_dict)]))
            


if __name__ == "__main__":
    start_time = time.time()
    batch_size = 32
    def gen_batch_data(batch_size):
        """
        �������ɺ����ķ�ʽ yield
        ��bacth�ĵ�Ԫ����Ԥ��
        ��ʡ����ʱ��
        """
        sample_list = []
        for line in sys.stdin:
            samp_data = []
            each_list = line.strip().split("\t")
            sample_list.append(each_list)
            if len(sample_list) == batch_size:
                # ��ǰ�����һ��batch
                yield sample_list
                sample_list = []
        
        if len(sample_list) > 0:
            yield sample_list


    data_batch  = gen_batch_data(batch_size)
    predict(data_batch)
    end_time = time.time()
    print ("all time : %.5fs" % (end_time - start_time))
