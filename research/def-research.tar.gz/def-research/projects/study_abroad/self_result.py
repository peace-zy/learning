#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   changxiaojing@baidu.com
Date  :   20/04/01 16:08:40
Desc  :   python main.py --test_sample "a.txt" --class_id "class_id.txt" --predict_data "predict_data.txt" --predict_out "predict_out.txt"
"""
import sys
import os
import argparse
import time

_cur_dir = os.path.dirname(os.path.abspath(__file__))
_dict_dir = "%s/mid/" % _cur_dir
sys.path.append("%s/../../lib/common" % _cur_dir)
import review_object
import common

def LR_args_result():
    """
    edit : changxiaojing
    func : ͨ�������з�ʽ��ȡģ�ͽ��
    """
    parser = argparse.ArgumentParser(description = "test_model")
    parser.add_argument("--test_sample", help = "��������", required = True)
    parser.add_argument("--class_id", help = "��ǩ�б�", required = True)
    parser.add_argument("--predict_data", help = "Ԥ����", default = "liblinear", required = True)
    parser.add_argument("--predict_out", help = "�Լ���Ҫ���ֶ�", required = True)

    args = parser.parse_args()
    
    class_dict = common.Common.load_class_id_file(args.class_id)
    class_thres = common.Common.load_class_thres(args.class_id)

    result_list = []
    label_list = []
    
    with open(args.predict_data, 'r') as pf:
        for index, eachline in enumerate(pf):
            line = eachline.strip("\n").decode("gbk", "ignore").lower().split(" ")
            if index == 0:
                label_list = line[1:]
            else:
                value_dict = {}
                tmp_list = []
                for i in range(len(label_list)):
                    value_dict[label_list[i]] = float(line[i + 1])
                sort_list = sorted(value_dict.items(), key = lambda item:item[1], reverse = True)
                for key, value in sort_list:
                    if value > 0.03:
                        tmp_list.append([key, class_dict[key], str(value)])
                if len(tmp_list) > 0 and tmp_list[0][0] != "0" and \
                        tmp_list[0][0] in class_thres and float(tmp_list[0][2]) < class_thres[tmp_list[0][0]]:
                        tmp_list[0][0] = "0"
                        tmp_list[0][1] = "����"
                result_list.append(tmp_list)

    error_index = []
    with open(args.test_sample, 'r') as f:
        with open(args.predict_out, 'w') as pf:
            for case_index, eachline in enumerate(f):
                line = eachline.strip("\n").decode("gbk", "ignore").lower().split("\t")
                result = result_list[case_index]
                if len(result) == 0:
                    label = "0"
                    label_name = "����"
                    label_list = ""
                else:
                    label = result[0][0]
                    label_name = result[0][1]
                    label_list = "||".join(":".join(i) for i in result)
                #��ʵ��ǩ\tԤ���ǩ\t��ǩname\t��ǩlist\t�ı�����
                out_str = [line[0], label, label_name, label_list, "\t".join(line[1:])]
                pf.write("\t".join(out_str) + "\n")
                if line[0] != label:
                    error_index.append(case_index)
    error_str = " ".join([str(i + 1) for i in error_index])
    print "error index are %s" % error_str
    predict_rate = (case_index - len(error_index) + 0.0) / case_index
    print "predict acc rate is %f" % predict_rate

if __name__ == "__main__":
    start = time.time()
    LR_args_result()
    end = time.time()
    print "total time: %f" % (end - start)
    pass

