#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   changxiaojing@baidu.com
Date  :   20/04/03 16:52:55
Desc  :   ���������Լ��洢�ĵ�ַ��ȡ, python get_neg_sample.py --out_path "../../lib/mid/neg_sample.txt" --neg_num 10000
"""
import sys
import os
import subprocess
import argparse
import logging

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../lib/" % _cur_dir)
import common.common as common
import common.review_object as review_object
import sample.sample as sample

machine = "hdfs://nmg01-khan-hdfs.dmop.baidu.com:54310"
file_path = "/app/ecom/aries/fengkong/changxiaojing/neg_sample_file/study_aboard_neg_sample.txt"
dest_file = "%s/mid/origin_data.txt" % _cur_dir

def args_func():
    """
    edit : changxiaojing
    func : ������ȡ
    """
    parser = argparse.ArgumentParser(description = "sample")
    parser.add_argument("-op", "--out_path", help = "�����������ַ", required = True)
    parser.add_argument("-nn", "--neg_num", help = "��������������", required = True, type = int)
    args = parser.parse_args()
    return args

def get_neg_sample(out_path, neg_num):
    """
    edit : changxiaojing
    func : �������������hdfs��ַ��ȡ������
    """
    r_obj = None
    neg_label_id = 0
    neg_sample_num = neg_num

    # ��ȡ������ȫ������
    if os.path.exists(dest_file) == False:
        cmd_str = "hadoop fs -get " + machine + file_path + " " + dest_file
        ret = subprocess.call(cmd_str, shell = True)
        if ret != 0:
            logging.error("wget file from remote machine failed !")
            sys.exit(1)
    else:
        logging.info("orgin_data is exsit.")

    logging.info("sampling neg sample... please wait a moment.")
    # �ڴ˳�������
    sampler = common.Sampler(neg_sample_num)
    with open(dest_file, "r") as f:
        for index, eachline in enumerate(f):
            line = eachline.strip("\n").lower().decode("gbk", "ignore").split("\t")
            sampler.put(line)

    sample_list = sampler.get_sample_list()
    with open(out_path, 'w') as of:
        for sample in sample_list:
            r_obj = review_object.ReviewUnitObj()
            r_obj.init(sample)
            idea = "|".join(r_obj.idea_list)
            word = "|".join(r_obj.word_list)
            of.write("%d\t%s\n" % (neg_label_id, "||".join([word, idea])))
    logging.info("sample neg sample success!")


if __name__ == "__main__":
    args = args_func()
    get_neg_sample(args.out_path, args.neg_num)
    pass


