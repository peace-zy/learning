#encoding=utf-8
"""
Author:   jiaodayuan@baidu.com
Date  :   2021/04/02 16:35:26
Desc  :   商标注册证OCR信息提取
"""
import base64
import urllib2
import json
import traceback
import os
import random

def GetXvisionWebOcrResult(image_bin):
    """
    OCR接口访问，vis接口
    """
    feature_name = "FEATURE_VIS_IMG_OCR_GPU_WEBIMGS2"
    business_name = "tradition_fengkong_meteor_video_and_image_media_ocr_web_gpu_online" 
    url = "http://group.xvision-xvisionproxy.xVision.all.serv:8089/xvision/xvision_sync"
    auth_key = "8e50a5f8-80c6-545b-ab49-e3fb1ad271d9"
    feature_data = json.dumps({
                    'appid': '10005',
                    'logid': random.randint(1000000, 100000000),
                    'format': 'json',
                    'from': 'test-python',
                    'cmdid': '123',
                    'clientip': '0.0.0.0',
                    'data': base64.b64encode("object_type=general_v4&disp_paragraph_poly=true&disp_line_poly=true&" \
                    "type=st_ocrapi_all&appid=分配编号&clientip=x.x.x.x&fromdevice=pc&version=1.0.0&" \
                    "detecttype=LocateRecognize&languagetype=CHN_ENG&locate_type=v4&imgDirection=setImgDirFlag&image=" \
                            + base64.b64encode(image_bin))})

    data_dict = {
                "business_name": business_name, #必填，jobname
                "resource_key": "test.jpg", #用于标记图片
                "auth_key": auth_key, #必填，token
                "feature_name": feature_name, #算子名称
                "data": base64.b64encode(feature_data)
                }
    data = json.dumps(data_dict)
    headers = {"Content-Type": "application/json"}
    request = urllib2.Request(url, data, headers)
    response = urllib2.urlopen(request)
    results = response.read()
    response.close()
    results = json.loads(results)
    return results


def Xvision_FEATURE_VIS_IMG_OCR_GPU_WEBIMGS2(url):
    """
    OCR返回信息拆解
    """
    line = [url, "\t", "", "", "fail reason"]
    image_bin = open(url, 'rb').read() #本地路径，以二进制打开
    results = GetXvisionWebOcrResult(image_bin) 
    dengjihao = ''
    error = ''
    info = ''
    output = ''
    if "feature_result" in results.keys():
        feature_result = results["feature_result"]
        try:
            if "value" in feature_result.keys():
                value = json.loads(feature_result["value"])
                if value and "result" in value:
                    result = json.loads(base64.b64decode(value["result"]))
                    if "errno" in result:
                        errno = int(result['errno'])
                        if -14 == errno:
                            line[4]  = "图片太大，需要小于2M"
                            return "\t".join(line)
                        elif 0 != errno:
                            print "============>errno =", errno
                    if "ret" in result: # a vision line
                        ret = result["ret"]
                        for r in ret:
                            if '' == dengjihao:
                                field = r["word"].encode('utf-8')
                                output += field + "|"
                                dengjihao = get_dengjihao(field)

                software = get_key_info(output).replace("|", "")
                if "" != software:
                    line[1] = software
                line[2] = dengjihao
                line[3] = output.strip()
        except Exception as e:
            traceback.print_exc()
    
    return "\t".join(line)

def get_key_info(info):
    """
    对应关键字信息提取
    """
    ret = ''
    start = info.find('软件名称')
    if -1 == start:
        return ''
    start = info[start:].find(':') + start
    end = info[start:].find('著作权人') + start
    if -1 == end:
        return ''
    ret += info[start + 1: end]

    start = end
    if -1 == start:
        return ''
    start = info[start:].find(':') + start
    end = info[start:].find('开发完成日期') + start
    if -1 == end:
        return ''
    ret += "\t" + info[start + 1: end]
    return ret

def get_dengjihao(info):
    """
    登记号信息提取
    """
    start = info.find('登记号')
    if -1 == start:
        return ""
    end = info.find(":")
    
    return info[end + 1:]

path = './pic/'
count = 0
imgs = os.listdir(path)
for img in imgs:
    count += 1
    img_url = path + img
    print Xvision_FEATURE_VIS_IMG_OCR_GPU_WEBIMGS2(img_url)
