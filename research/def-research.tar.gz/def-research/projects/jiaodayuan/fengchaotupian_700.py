#encoding=gb18030
"""
Author:   jiaodayuan@baidu.com
Date  :   2021/04/07 10:25:01
Desc  :   凤巢图片700万发人工图片处置分析
"""

import sys
import json

reload(sys)
sys.setdefaultencoding('gb18030')
count = 0
for line in sys.stdin:
    count += 1
    line = line.strip()
    json_loads = json.loads(line)
    url = json_loads['media'][0]['kMedia_Image']
    for hits in json_loads['result']['audit_elem_res_field']['risk_info']:
        if 1 == hits["suggestion_result"]:
            loads = json.loads(hits['option'])
            print "\t".join([url, hits['risk_name'], hits['reason'], hits['risk_id'], str(loads['model_id'])])
print("count =", count)
