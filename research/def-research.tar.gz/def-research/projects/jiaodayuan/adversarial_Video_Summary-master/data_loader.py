# -*- coding: utf-8 -*-
"""
File  :   data_loader.py
Author:   jiaodayuan@baidu.com
Date  :   2021/06/24 15:40:38
Desc  :   to load video 
"""

import torch
from torch.utils.data import Dataset, DataLoader
from torchvision.datasets.folder import default_loader
from pathlib import Path

from feature_extraction import resnet_transform
import h5py
import numpy as np

from utils import writeline

class VideoData(Dataset):
    """
    video data
    """
    def __init__(self, root, preprocessed=False, transform=resnet_transform, with_name=False):
        """dataset init"""
        self.root = root
        self.preprocessed = preprocessed
        self.transform = transform
        self.with_name = with_name
        writeline("self.root.iterdir() = %s" % self.root.iterdir())
        self.video_list = list(self.root.iterdir())

    def __len__(self):
        return len(self.video_list)

    def __getitem__(self, index):
        writeline("-" * 25 + "B VideoData __getitem__" + "-" * 25)
        writeline("index = %s" % index)
        if self.preprocessed:
            image_path = self.video_list[index]
            writeline("image_path = %s" % image_path)
            writeline("self.with_name = %s" % self.with_name)
            with h5py.File(image_path, 'r') as f:
                if self.with_name:
                    return torch.Tensor(np.array(f['pool5'])), image_path.name[:-5]
                else:
                    return torch.Tensor(np.array(f['pool5']))

        else:
            images = []
#            for i, p in enumerate(self.video_list):
#                writeline("p_%s = %s" % (i, self.video_list[i]))
#                writeline("type(self.video_list[%s]) = %s" % (i, type(p)))
            for img_path in Path(self.video_list[index]).glob('*.jpeg'):
                writeline("img_path = %s" % str(img_path))
                #type(img = default_loader) = <class 'PIL.Image.Image'>
                img = default_loader(img_path)
                writeline("type(img = default_loader) = %s" % type(img))
                writeline("img = %s" % str(img))
                img_tensor = self.transform(img)
                writeline("type(img_tensor) = %s" % type(img_tensor))
                writeline("img_tensor = %s" % img_tensor)
                writeline("img_tensor.size() = %s" % str(img_tensor.size()))
                images.append(img_tensor)
                writeline("len(images) = %s" % len(images))
            writeline("-" * 25 + "E VideoData __getitem__" + "-" * 25)
            return torch.stack(images), img_path.parent.name[4:]


def get_loader(root, mode):
    """
    get dataset
    """
    if mode.lower() == 'train':
        return DataLoader(VideoData(root), batch_size=1)
    else:
        return VideoData(root, with_name=True)


if __name__ == '__main__':
    pass
