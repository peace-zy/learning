#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
File  :   train_lstm.py
Author:   changxiaojing@baidu.com
Date  :   21/02/23 15:44:50
Desc  :
"""

import sys
import numpy as np
import paddle
import data_process as dp
from model_lstm import ForumClassifier

batch_size = 64
epoch_num = 25
embedding_size = 128
hidden_size = 128
learning_rate = 0.0001
max_seq_len = 45
num_layers = 3

paddle.set_device('gpu:0')
def train(forum_classifier, word2id_dict, train_data, model_path, epoch_num):
    """
    train model
    """
    step = 0
    optimizer = paddle.optimizer.Adam(parameters=forum_classifier.parameters())
    forum_classifier.train()
    for texts, seg_texts, labels in dp.build_batch(word2id_dict, train_data, 
            forum_classifier.batch_size, epoch_num, forum_classifier.num_steps):
        sens_var = paddle.to_tensor(np.array(seg_texts).astype("int64"))
        labels_var = paddle.to_tensor(np.array(labels).astype("int64"))
        pred, loss = forum_classifier(sens_var, labels_var)

        loss.backward()
        optimizer.step()
        optimizer.clear_grad()

        step += 1
        if step % 50 == 0:
            print("step %d, loss %.3f" % (step, loss.numpy()[0]))

    paddle.save(forum_classifier.state_dict(), model_path)

def eval(forum_classifier, word2id_dict, eval_data):
    """
    eval
    """
    forum_classifier.eval()
    tp = 0.
    tn = 0.
    fp = 0.
    fn = 0.
    for texts, seg_texts, labels in dp.build_batch(word2id_dict, eval_data, batch_size, 1, max_seq_len):
        sens_var = paddle.to_tensor(np.array(seg_texts).astype("int64"))
        labels_var = paddle.to_tensor(np.array(labels).astype("int64"))

        pred, loss = forum_classifier(sens_var, labels_var)
        pred = pred.numpy()
        for i in range(len(pred)):
            if labels[i][0] == 1:
                if pred[i][1] > pred[i][0]:
                    tp += 1
                else:
                    fn += 1
            else:
                if pred[i][1] > pred[i][0]:
                    fp += 1
                else:
                    tn += 1
    print("acc is %.3f" % ((tp + tn) / (tp + tn + fp + fn)))

def predict(forum_classifier, word2id_dict, predict_data, model_file):
    """
    ����ģ��
    """
    param_dict = paddle.load(model_file)
    forum_classifier.load_dict(param_dict)

    forum_classifier.eval()
    pred_count = 0
    real_count = 0
    jiaoji = 0
    for texts, seg_texts, labels in dp.build_batch(word2id_dict, predict_data, 
            forum_classifier.batch_size, 1, forum_classifier.num_steps):
        sens_var = paddle.to_tensor(np.array(seg_texts).astype("int64"))
        labels_var = paddle.to_tensor(np.array(labels).astype("int64"))

        pred, loss = forum_classifier(sens_var, labels_var)
        pred = pred.numpy()
        for i in range(len(pred)):
            max_index = np.argmax(pred[i])
            predict_value = pred[i][max_index]
            print(str(max_index) + "\t" + str(labels[i][0]) + 
                    "\t" + str(predict_value) + "\t" + texts[i]).encode("gb18030")
                
            
if __name__ == "__main__":
    # ���ݵ�ַ
    train_file = "../data/train_g.txt"
    predict_file = "../data/test_g.txt"
    
    stop_file = "../data/stop_word.txt"
    model_file = sys.argv[2]
    
    # ��������
    stop_set = dp.load_stopword(stop_file)
    train_list = dp.load_data(train_file)
    # ��ȡvocab
    word2id_dict, word2id_freq = dp.build_dict(train_list, stop_set)
    
    forum_classifier = ForumClassifier(embedding_size, hidden_size, len(word2id_dict), batch_size, class_num=3, 
            num_steps=max_seq_len, num_layers=num_layers)
    if sys.argv[1] == "train":
        train_convert_id = dp.convert_corpus_to_id(train_list, word2id_dict)
        train(forum_classifier, word2id_dict, train_convert_id, model_file, epoch_num)
    if sys.argv[1] == "predict":
        predict_list = dp.load_data(predict_file)
        predict_convert_id = dp.convert_corpus_to_id(predict_list, word2id_dict)
        predict(forum_classifier, word2id_dict, predict_convert_id, model_file)
     
