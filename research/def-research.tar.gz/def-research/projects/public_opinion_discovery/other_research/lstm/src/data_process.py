#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
File  :   data_process.py
Author:   changxiaojing@baidu.com
Date  :   21/02/23 11:04:46
Desc  :   
"""

import sys
import math
import random
import numpy as np

def load_data(file_name):
    """
    加载数据
    """
    data_list = []
    c = 0
    with open(file_name, 'r') as f:
        for line in f:
            data = line.strip("\n").decode("gb18030", "ignore").lower().split("\t")
            label = int(data[1])
            #url = data[1]
            text = data[2]
            seg_text = data[3].split(" ")
            data_list.append((label, seg_text, text))
    return data_list

def load_stopword(file_name):
    """
    加载停用词
    """
    stopword_set = set()
    with open(file_name) as f:
        for line in f:
            stopword_set.add(line.strip("\n").decode("gb18030"))
    return stopword_set

def build_dict(corpus, stopword_set):
    """
    创建vocab
    """
    word_freq_dict = {}
    for label, seg_text, text in corpus:
        for word in seg_text:
            if word in stopword_set:
                continue
            if word not in word_freq_dict:
                word_freq_dict[word] = 0
            word_freq_dict[word] += 1
    word_freq_dict = sorted(word_freq_dict.items(), key=lambda x:x[1], reverse=True)
    
    word2id_dict = {}
    word2id_freq = {}
    word2id_dict['[oov]'] = 0
    word2id_freq[0] = 1e10
    word2id_dict['[pad]'] = 1
    word2id_freq[1] = 1e10

    for word, freq in word_freq_dict:
        word2id_dict[word] = len(word2id_dict)
        word2id_freq[word2id_dict[word]] = freq
    return word2id_dict, word2id_freq

def convert_corpus_to_id(corpus, word2id_dict):
    """
    将sentence转换为id
    """
    data_list = []
    for label, seg_text, text in corpus:
        seg_text = [word2id_dict[word] if word in word2id_dict else word2id_dict['[oov]'] for word in seg_text]
        data_list.append((label, seg_text, text))
    return data_list

def build_batch(word2id_dict, corpus, batch_size, epoch_num, max_seq_len, shuffle=True):
    """
    获取batch数据
    """
    sen_batch = []
    sen_label_batch = []
    text_batch = []
    for _ in range(epoch_num):
        if shuffle:
            random.shuffle(corpus)

        for label, seg_text, text in corpus:
            sen_sample = seg_text[:min(max_seq_len, len(seg_text))]
            if len(sen_sample) < max_seq_len:
                for _ in range(max_seq_len - len(seg_text)):
                    sen_sample.append(word2id_dict['[pad]'])

            sen_batch.append([sen_sample])
            sen_label_batch.append([label])
            text_batch.append(text)

            if len(sen_batch) == batch_size:
                yield text_batch, sen_batch, sen_label_batch
                sen_batch = []
                sen_label_batch = []
                text_batch = []
        if len(sen_batch) == batch_size:
            yield text_batch, sen_batch, sen_label_batch

def postprocess(result_file):
    """
    postprocess
    """
    res_dict = {}
    real_count = 0
    pred_count = 0
    jiaoji = 0
    with open(result_file, "r") as f:
        for line in f:
            data = line.strip("\n").split("\t")
            url = data[0]
            real_label = int(data[1])
            pred_label = int(data[2])
            pred = data[3]
            text = data[4]
            if url not in res_dict:
                res_dict[url] = [[], [], []]
            res_dict[url][0].append(real_label)
            res_dict[url][1].append(pred_label)
            res_dict[url][2].append(text)
    for k, v in res_dict.items():
        if 1 in v[1]:
            pred_label = 1
            pred_count += 1
        else:
            pred_label = 0
        if 1 in v[0]:
            real_label = 1
            real_count += 1
        else:
            real_label = 0
        if real_label == pred_label and real_label == 1:
            jiaoji += 1
        print(k + "\t" + str(real_label) + "\t" + str(pred_label) + "\t" + "||".join(v[2]))
   

if __name__ == "__main__":
    
    data_file = "../data/seg_data"
    stop_file = "../data/stopword.txt"
    data_list = load_data(data_file)
    stop_set = load_stopword(stop_file)
    word2id_dict, word2id_freq = build_dict(data_list, stop_set)
    for k, v in word2id_dict.items():
        print(k + "\t" + str(v)).encode("gb18030")
    convert_id = convert_corpus_to_id(data_list, word2id_dict)
    for batch_id, batch in enumerate(build_batch(word2id_dict, convert_id, 32, 1, 512)):
        print(batch)
