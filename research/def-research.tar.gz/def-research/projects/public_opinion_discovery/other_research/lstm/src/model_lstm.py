#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
File  :   model_lstm.py
Author:   changxiaojing@baidu.com
Date  :   21/02/23 14:53:26
Desc  :   
"""

import sys
import numpy as np
import paddle
from paddle.nn import LSTM, Embedding, Dropout, Linear
import paddle.nn.functional as F

class ForumClassifier(paddle.nn.Layer):
    """
    构建分类器
    """
    def __init__(self, embedding_size, hidden_size, vocab_size, batch_size, 
            class_num=2, num_steps=128, num_layers=1, init_scale=0.1, dropout=None):
        """
        初始化
        """
        super(ForumClassifier, self).__init__()
        self.embedding_size = embedding_size # emdedding size
        self.hidden_size = hidden_size  # embedding size, hidden, cell向量的维度
        self.vocab_size = vocab_size    # vocab大小
        self.batch_size = batch_size
        self.class_num = class_num  # 分类大小
        self.init_scale = init_scale    # 网络参数初始化范围
        self.num_layers = num_layers  # 网络层数
        self.num_steps = num_steps  # 最大句子长度
        self.dropout = dropout 

        self.lstm_rnn = LSTM(input_size=embedding_size, hidden_size=hidden_size, num_layers=num_layers)
        self.embedding = Embedding(num_embeddings=vocab_size, embedding_dim=embedding_size, sparse=False, 
                weight_attr=paddle.ParamAttr(initializer=
                    paddle.nn.initializer.Uniform(low=-init_scale, high=init_scale)))
        self.cls_fc = Linear(in_features=self.hidden_size, out_features=self.class_num, 
                weight_attr=None, bias_attr=None)
        self.dropout_layer = Dropout(p=self.dropout, mode='upscale_in_train')
        
        init_hidden_data = np.zeros((self.num_layers, self.batch_size, self.hidden_size), dtype='float32')
        init_cell_data = np.zeros((self.num_layers, self.batch_size, self.hidden_size), dtype='float32')
        init_hidden = paddle.to_tensor(init_hidden_data)
        init_hidden.stop_gradient = True
        init_cell = paddle.to_tensor(init_cell_data)
        init_cell.stop_gradient = True

        self.init_h = paddle.reshape(init_hidden, shape=[self.num_layers, -1, self.hidden_size])
        self.init_c = paddle.reshape(init_cell, shape=[self.num_layers, -1, self.hidden_size])


    def forward(self, input, label):
        """
        forward
        """
        x_emb = self.embedding(input)
        x_emb = paddle.reshape(x_emb, shape=[-1, self.num_steps, self.embedding_size])
        if self.dropout is not None and self.dropout > 0.0:
            x_emb = self.dropout_layer(x_emb)

        rnn_out, (last_hidden, last_cell) = self.lstm_rnn(x_emb, (self.init_h, self.init_c))
        
        last_hidden = paddle.reshape(last_hidden[-1], shape=[-1, self.hidden_size])
        projection = self.cls_fc(last_hidden)
        pred = F.softmax(projection, axis=-1)
        
        loss = F.softmax_with_cross_entropy(logits=projection, label=label, soft_label=False)
        loss = paddle.mean(loss)

        return pred, loss


if __name__ == "__main__":
    pass


