#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Author:   changxiaojing@baidu.com
Date  :   21/08/30 19:37:00
"""


import sys
import os
import json
import base64
import time

from urllib.request import urlopen
from urllib.request import Request
from urllib.error import URLError
from urllib.parse import urlencode
from urllib.parse import quote_plus

import ssl

ssl._create_default_https_context = ssl._create_unverified_context
API_KEY = 'DfGHOojQqqEvkYaIjPVV40G2'
SECRET_KEY = 'YVu7XUxIVK9gAOSTTsdChNpbj53upswF'

COMMENT_TAG_URL = 'https://aip.baidubce.com/rpc/2.0/nlp/v1/sentiment_classify'
TOKEN_URL = 'https://aip.baidubce.com/oauth/2.0/token'

def fetch_token():
    """
    fetch_token
    """
    params = {'grant_type': 'client_credentials',
            'client_id': API_KEY,
            'client_secret': SECRET_KEY}
    post_data = urlencode(params)
    post_data = post_data.encode('utf-8')
    req = Request(TOKEN_URL, post_data)
    try:
        f = urlopen(req, timeout=5)
        result_str = f.read()
    except URLError as err:
        print(err)
    result_str = result_str.decode()
    result = json.loads(result_str)
    if ('access_token' in result.keys() and 'scope' in result.keys()):
        if not 'brain_all_scope' in result['scope'].split(' '):
            print ('please ensure has check the  ability')
            exit()
        return result['access_token']
    else:
        print ('please overwrite the correct API_KEY and SECRET_KEY')
        exit()

def make_request(url, comment, label, label1):
    """
    获取response
    """
    response = request(url, json.dumps(
    {
            "text": comment,
    }))
    data = json.loads(response)
    if "error_code" not in data or data["error_code"] == 0:
        for item in data["items"]:
            print(label + "\t" + label1 + "\t" + comment + 
                    "\t" + str(item["sentiment"]) + "\t" + str(item["confidence"]) + 
                    "\t" + str(item["positive_prob"]) + "\t" + str(item["negative_prob"]))
    else:
        print(response)
    # 防止qps超限
    time.sleep(0.5)

def request(url, data):
    """
    request
    """
    req = Request(url, data.encode('utf-8'))
    has_error = False
    try:
        f = urlopen(req)
        result_str = f.read()
        result_str = result_str.decode()
        return result_str
    except  URLError as err:
        print(err)

if __name__ == '__main__':
    
    # get access token
    token = fetch_token()
    # concat url
    url = COMMENT_TAG_URL + "?charset=UTF-8&access_token=" + token

    for line in sys.stdin:
        data = line.strip("\n").split("\t")
        label = data[0]
        label1 = data[1]
        text = data[2] + "." + data[3]
        make_request(url, text, label, label1)

