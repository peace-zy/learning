#-*- coding:utf-8 -*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了百度热搜榜抓取功能。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2021/07/01 10:00:00
"""

import os
import sys
import requests
from lxml import etree
import time
from datetime import date, timedelta
import json
import traceback

_cur_dir = os.path.dirname(os.path.abspath(__file__))
today = (date.today()).strftime("%Y-%m-%d")
_hot_search_dir = "%s/../data/hot_search_data/%s/" % (_cur_dir, today)

def make_path(path):
    """创建目录
    Args:
        path: 待创建路径
    """
    if not os.path.exists(path):
        os.makedirs(path)

def parse_baidu():
    """解析百度热搜网页"""
    make_path(_hot_search_dir)
    try:
        url = "http://top.baidu.com/buzz?b=1"
        r = requests.get(url, timeout=10)
        soup = etree.HTML(r.text.replace("<!--s-data:", '<!--'))
        list_time = time.strftime("%Y-%m-%d-%H:%M:%S", time.localtime())
        fname = os.path.join(_hot_search_dir, list_time + ".txt")
        w_file = open(fname, "w+", encoding='utf-8')
        for soup_a in soup.xpath("//div[@id='sanRoot']"):
            data = json.loads(soup_a[0].text)
            content = data['data']['cards'][0]['content']
            for cnt in content: 
                hot_title = cnt['word']
                hot_url = cnt['url']
                hot_desc = cnt['desc']
                hot_image = cnt['img']
                out = "\t".join([hot_title, hot_desc, hot_url, hot_image, list_time])
                w_file.write(out + "\n")
        w_file.close()
    except Exception as e:
        print(sys._getframe().f_code.co_name + "解析错误，请及时更新规则！")
        traceback.print_exc()

if __name__ == '__main__':
    parse_baidu()
