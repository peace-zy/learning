#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
  Author: changxiaojing@baidu.com
  Date  : 21/09/22 10:53:32
  File  : ernie predict batch.py
  Desc  : 
"""

import os
import sys
import time
import argparse
from datetime import date

import numpy as np
import paddle as P
import paddle.fluid.dygraph as D

from ernie.tokenizing_ernie import ErnieTokenizer
from ernie.modeling_ernie import ErnieModelForSequenceClassification

_cur_dir = os.path.dirname(os.path.abspath(__file__))
today = (date.today()).strftime("%Y-%m-%d")
_hot_search_dir = "%s/../data/hot_search_data/%s" % (_cur_dir, today)
_mid_dir = "%s/../data/mid_data/%s/" % (_cur_dir, today)


D.guard().__enter__() # 为了让Paddle进入动态图模式，需要添加这一行在最前面

def make_data(data_set, tokenizer, max_seqlen):
    """转换data为feature
    """
    d = []
    for l in data_set:
        data = l.strip().split('\t')
        title = data[0]
        desc = data[1]
        text = title + "." + desc
        url = data[2]
        img = data[3]
        time = data[4]
        # ErnieTokenizer 会自动添加ERNIE所需要的特殊token，如[CLS], [SEP]
        text_id, _ = tokenizer.encode(text)
        text_id = text_id[:max_seqlen]
        # 对所有句子都补长至300，这样会比较费显存；
        text_id = np.pad(text_id, [0, max_seqlen - len(text_id)], mode='constant') 
        d.append((text_id, title, desc, url, img, time))
    return d

def get_batch_data(data, i, batch_size):
    """获取batch数据
    """
    result = {"feature": "", "title": "", "desc": "", "url": "", "img": "", "time": ""}
    d = data[i * batch_size: (i + 1) * batch_size]
    feature, result["title"], result["desc"], result["url"], result["img"], result["time"] = zip(*d)
    feature = np.stack(feature) 
    feature = P.to_tensor(feature)
    result["feature"] =  feature
    return result 



#以下为预测，对于每条输入，进行预测
def predict(model, test_data, batch_size, w_file):
    """模型预测
    """
    # 在这个with域内ernie不会进行梯度计算；
    with D.base._switch_tracer_mode_guard_(is_train=False):
        # 控制模型进入eval模式，这将会关闭所有的dropout；
        model.eval()
        all_title, all_desc, all_url, all_img, all_time, all_pred = [], [], [], [], [], []
        for j in range((len(test_data) // batch_size)+1):
            info = get_batch_data(test_data, j, batch_size)
            _, logits = model(info["feature"])
            all_title.extend(info["title"])
            all_desc.extend(info["desc"])
            all_url.extend(info["url"])
            all_img.extend(info["img"])
            all_time.extend(info["time"])
            all_pred.extend(logits.argmax(-1).numpy())

        for index, item in enumerate(all_pred):
            out = "\t".join([str(all_pred[index]-1), all_title[index], \
                    all_desc[index], all_url[index], all_img[index], all_time[index]])
            w_file.write(out + "\n")

def set_argparse():
    """参数设置
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--batch', '-b', type=int, default=32)
    parser.add_argument('--max_len', '-l', type=int, default=120)
    parser.add_argument('--model_path', '-m', type=str, default="")
    parser.add_argument('--num_labels', '-n', type=int, default=3)
    parser.add_argument('-learning_rate', '-r', type=float, default=5e-5)
    parser.add_argument('--shuffle', '-s', type=bool, default=True)
    parser.add_argument('--function', '-f', type=str, default="") # theme或者sentiment
    return parser

if __name__ == "__main__":

    parser = set_argparse()
    args = parser.parse_args()

    if not os.path.exists(_mid_dir):
        os.makedirs(_mid_dir)
    currect_time = time.strftime("%Y-%m-%d-%H", time.localtime())
    savefile = os.path.join(_mid_dir + currect_time + "_" + args.function + ".txt")
    w_file = open(savefile, "w+", encoding="utf-8")
    data_set = set()
    for root, dirs, files in os.walk(_hot_search_dir):
        for filename in files:
            if currect_time in filename:
                r_file = os.path.join(root, filename)
                with open(r_file, "r", encoding="utf-8") as f:
                    for line in f:
                        data_set.add(line.strip("\n"))
    # 获取数据,模型加载
    ernie = ErnieModelForSequenceClassification.from_pretrained('ernie-1.0', num_labels=args.num_labels)
    sd, _ = D.load_dygraph(args.model_path)
    ernie.set_dict(sd)
    tokenizer = ErnieTokenizer.from_pretrained('ernie-1.0')
    test_data = make_data(data_set, tokenizer, args.max_len)
    predict(ernie, test_data, args.batch, w_file)
    w_file.close()

