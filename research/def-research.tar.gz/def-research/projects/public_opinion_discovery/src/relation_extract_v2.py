# -*- coding: utf-8 -*-
"""
@author:Changxiaojing
@description:
"""
import sys
import os
import time
from datetime import date, timedelta
import re
import hanlp

_cur_dir = os.path.dirname(os.path.abspath(__file__))
today = (date.today()).strftime("%Y-%m-%d")
_hot_search_dir = "%s/../data/hot_search_data/%s" % (_cur_dir, today)
_mid_dir = "%s/../data/mid_data/%s/" % (_cur_dir, today)
_model_dir = "%s/../data/common_data/" % _cur_dir

class RelationExtract:
    """
    知识提取
    """
    def __init__(self, stopfile):
        """初始化
        """
        self.model = hanlp.load(hanlp.pretrained.mtl.CLOSE_TOK_POS_NER_SRL_DEP_SDP_CON_ELECTRA_SMALL_ZH)
        self.stop_set = self.load_stopfile(stopfile)

    def load_stopfile(self, stopfile):
        """停用词加载
        """
        stop_set = set()
        with open(stopfile, "r+", encoding="utf-8") as f:
            for line in f:
                stop_set.add(line.strip("\n"))
        return stop_set

    def tok_parser(self, text):
        """获取文本的分词/词性/ner/语义角色标注/依存句法分析结果
        """
        if not text:
          return
        ret_dict = self.model(text, tasks=['tok/coarse', 'ner/msra', 'pos/pku', 'srl', 'dep'], skip_tasks='tok/fine')
        return ret_dict 

    @staticmethod
    def remove_noisy(text):
        """
        移除括号内的信息，去除噪声
        """
        p1 = re.compile(r'（[^）]*）')
        p2 = re.compile(r'\([^\)]*\)')
        return p2.sub('', p1.sub('', text))

    @staticmethod
    def get_last_word(words_list, triple):
        """
        取多词组合的长词中的最后词
        """
        wd, begin, end = triple[0], triple[2], triple[3]
        words = words_list[begin:end]
        if len(words) == 0:
            word = ''
        elif len(words) in [1, 2, 3]:
            word = wd
        else:
            word = words[-1][0]  # 重点词在文本靠后
        return word

    def filter_str(self, text):
        """
        过滤字符串
        """
        # 过滤停用词
        if text in self.stop_set or len(text) < 2:
            return False

        # 过滤数字
        if text.isdigit() == True:
            return False
        return True


    def get_ners(self, ners):
        """
        获取组织机构和人名
        """
        word_type = {"ORGANIZATION": set(), "PERSON": set()}
        for item in ners:
            if item[1] == 'ORGANIZATION' and self.filter_str(item[0]):
                word_type['ORGANIZATION'].add(item[0])
            elif item[1] == "PERSON" and self.filter_str(item[0]):
                word_type["PERSON"].add(item[0])
        return word_type

    def get_event_by_srl(self, words, postags, srls, subj_list=None, verb_list=None, obj_list=None):
        """
        抽取出施事者，谓词，受事者三元组
        "srl": [
                [["阿婆主", "ARG0", 0, 1], ["来到", "PRED", 1, 2], ["北京立方庭", "ARG1", 2, 4]],
                [["阿婆主", "ARG0", 0, 1], ["参观", "PRED", 4, 5], ["自然语义科技公司", "ARG1", 5, 9]]
            ],
        """
        ret = []
        # 谓语动词
        if verb_list is None:
            verb_list = ['PRED']
        # 施事者
        if subj_list is None:
            subj_list = ['ARG0']
        # 受事者
        if obj_list is None:
            obj_list = ['ARG1']
        words_list = [[i[0], i[1]] for i in zip(words, postags)]
        for srl in srls:
            if len(srl) >= 3:
                subj = ''
                verb = ''
                obj = ''
                for srl_unit in srl:
                    # srl_unit format: ["阿婆主", "ARG0", 0, 1]
                    word, rel, begin, end = srl_unit[0], srl_unit[1], srl_unit[2], srl_unit[3]
                    if rel in subj_list:
                        subj = self.get_last_word(words_list, srl_unit)
                    elif rel in verb_list:
                        verb = word
                    elif rel in obj_list:
                        obj = self.get_last_word(words_list, srl_unit)
                if subj and verb and obj:
                    ret.append([subj, verb, obj])
        return ret

    def extract_triples(self, words, postags, ners, srls):
        """
        抽取实体词和实体关系
        """
        # 存储实体关系抽取结果，三元组
        extract_dict = {}

        # 获取文章事件(施事者，谓词，受事者)三元组
        events = self.get_event_by_srl(words, postags, srls)
        event_triples = []
        for t in events:
            name = t[0]
            obj = t[2]
            if len(name) > 1 and len(obj) > 1:
                event_triples.append(t)
        if event_triples:
            extract_dict['event'] = event_triples

        # 获取组织机构和人名
        ners_dict = self.get_ners(ners)
        extract_dict['ORGANIZATION'] = ners_dict["ORGANIZATION"]
        extract_dict['PERSON'] = ners_dict['PERSON']
        return extract_dict

    def get_extract(self, r_file, w_file):
        """
        关系抽取
        """
        with open(r_file, "r", encoding="utf-8") as rf, open(w_file, "w+", encoding="utf-8") as wf:
            for line in rf:
                data = line.strip("\n").split("\t")
                title = data[0]
                desc = data[1]
                text = (title + "." + desc).replace("/", "")
                url = data[2]
                img = data[3]
                time = data[4]

                origanization = ""
                person = ""
                events = ""

                text = self.remove_noisy(text).strip()
                if len(text) > 500 or text == "":
                    continue
                # 分词，词性标注，ner, 依存句法分析，短语成分分析，语义角色标注
                ret_dict = self.tok_parser(text)
                words = ret_dict['tok/coarse']
                postags = ret_dict['pos/pku']
                ners = ret_dict['ner/msra']
                srls = ret_dict['srl']
                deps = ret_dict['dep']
                extract_dict = self.extract_triples(words, postags, ners, srls)
                if "ORGANIZATION" in extract_dict:
                    origanization = "||".join(list(extract_dict["ORGANIZATION"]))
                if "PERSON" in extract_dict:
                    person = "||".join(list(extract_dict["PERSON"]))
                if "event" in extract_dict:
                    events = str(extract_dict["event"])
                wf.write(title + "\t" + desc + "\t" + origanization + "\t" + person + "\t" + events + "\t"
                         + url + "\t" + img + "\t" + time + "\n")

if __name__ == '__main__':

    currect_time = time.strftime("%Y-%m-%d-%H", time.localtime())
    w_file = os.path.join(_mid_dir + currect_time + "_hanlp_v2.txt")
    data_set = set()
    r_file = ""
    for root, dirs, files in os.walk(_hot_search_dir):
        for filename in files:
            if currect_time in filename:
                r_file = os.path.join(root, filename)
                break
    stop_file = os.path.join(_model_dir, "stop_word.txt")
    extract_obj = RelationExtract(stop_file)
    extract_obj.get_extract(r_file, w_file)

