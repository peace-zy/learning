#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
  Author: work@baidu.com
  Date  : 21/10/12 20:33:09
  File  : merge_result.py
  Desc  : 
"""

import sys
import os
from datetime import date
import time

_cur_dir = os.path.dirname(os.path.abspath(__file__))
today = (date.today()).strftime("%Y-%m-%d")
_mid_dir = "%s/../data/mid_data/%s/" % (_cur_dir, today)
_common_dir = "%s/../data/common_data/" % _cur_dir

def read_conf(conf_path):
    """
    ��ȡ�����ļ�
    """
    result = {}
    with open(conf_path, "r", encoding="utf-8") as f:
        for line in f:
            data = line.strip().split("\t")
            result[data[0]] = data[1]
    return result

def read_file(data_file):
    """
    ��ȡ�ļ�
    """
    result = {}
    with open(data_file, "r", encoding="utf-8") as f:
        for line in f:
            data = line.strip().split("\t")
            label = data[0]
            title = data[1]
            desc = data[2]
            text = title + "." + desc
            result[text] = label
    return result

def read_hanlp_file(hanlp_file):
    """��ȡhanlp�ļ�
    """
    result = {}
    with open(hanlp_file, "r", encoding="utf-8") as f:
        for line in f:
            data = line.strip().split("\t")
            title = data[0]
            desc = data[1]
            text = title + "." + desc
            orgination = data[2]
            person = data[3]
            event = data[4]
            url = data[5]
            img = data[6]
            time = data[7]
            result[text] = [orgination, person, event, title, desc, url, img, time]
    return result

if __name__ == "__main__":

    currect_time = time.strftime("%Y-%m-%d-%H", time.localtime())
    savefile = os.path.join(_mid_dir + currect_time + "_merge.txt")
    theme_file = os.path.join(_mid_dir + currect_time + "_theme.txt")
    semtiment_file = os.path.join(_mid_dir + currect_time + "_sentiment.txt")
    hanlp_file = os.path.join(_mid_dir + currect_time + "_hanlp_v2.txt")
    theme_index = _common_dir + "theme_index.txt"
    sentiment_index = _common_dir + "sentiment_index.txt"

    w_file = open(savefile, "w+", encoding="utf-8")

    theme_label = read_conf(theme_index)
    sentiment_label = read_conf(sentiment_index)

    theme_dict = read_file(theme_file)
    sentiment_dict = read_file(semtiment_file)
    hanlp_dict = read_hanlp_file(hanlp_file)

    for k, v in hanlp_dict.items():
        out = "\t".join([theme_dict[k], theme_label[theme_dict[k]], sentiment_dict[k], \
            sentiment_label[sentiment_dict[k]], "\t".join(v)])
        w_file.write(out + "\n")

