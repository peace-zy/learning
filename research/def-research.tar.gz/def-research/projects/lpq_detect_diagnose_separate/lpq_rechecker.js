// encoding: gbk

// job_args:
// input_path_to_detect: input url path on hdfs used to detect, normalized url
// output_dir: base path to save output features
// seperator: input and output sperator, default: \t
// crawl_type : [pc, wise]
// detect_type: detect types in [401, 431, 311, 312, 1000, 1001, 1002] as a list
// data_tag: data_tag to save in table: default: base
// detect_priority: default: 3,
// spider_version: spider_version used to detect
// app_id: app_id used to detect
// spider_cluster: cluster used to crawl, default: "Detect"
// hadoop_cluster_name: cluster used  to access input/output data and run hadoop mr task, default: the default hadoop cluster used in each workers
// hadoop_queue_name: hadoop queue name, default: cms
// hadoop_job_priority: hadoop job priority, default: the default hadoop job priority used in each workers
// hadoop_job_name: hadoop job name, default: the default hadoop job name used in each workers
// reduce_num: hadoop reducer number, default: the default value used in each workers
// hdfs_done_file_path: done file will touch when all workers are done
// hadoop_ugi: the ugi to access hdfs/afs path and hadoop queue in each workers, default: the default value used in each workers
// score_version_list: socre version list for score workers to calculate the quality score, a version incluld operator_model and operator_model_bin_path

function get_hadoop_client(hadoop_cluster_name) {
    let client_root = "/home/work/nexus/client/cms";
    let hadoop_client_list = {};
    hadoop_client_list["hadoop"] = `${client_root}/hadoop-client-nmg/hadoop/bin/hadoop`;
    hadoop_client_list["cms_queue_hadoop"] = `${client_root}/hadoop-client-cms-queue/hadoop/bin/hadoop`;
    hadoop_client_list["tianqi_hadoop"] = `${client_root}/hadoop-client-tianqi/hadoop/bin/hadoop`;
    hadoop_client_list["bjhw_hadoop"] = `${client_root}/hadoop-client-bjhw/hadoop/bin/hadoop`;
    hadoop_client_list["yq2_hadoop"] = `${client_root}/hadoop-client-yq2/hadoop/bin/hadoop`;
    hadoop_client_list["fenghuang_hadoop"] = `${client_root}/hadoop-client-cms-fenghuang/hadoop/bin/hadoop`;
    hadoop_client_list["shaolin_hadoop"] = `${client_root}/hadoop-client-cms-shaolin/hadoop/bin/hadoop`;
    hadoop_client_list["khan"] = `${client_root}/hadoop-client-nmg/hadoop/bin/hadoop`;
    hadoop_client_list["khan_qlpq"] = `${client_root}/hadoop-client-qlpq/hadoop/bin/hadoop`;
    hadoop_client_list["mulan_qlpq"] = `${client_root}/hadoop-client-mulan-qlpq/hadoop/bin/hadoop`;
    hadoop_client_list["taihang"] = `${client_root}/taihang/hadoop/bin/hadoop`;
    hadoop_client_list["lizhu_hadoop"] =`${client_root}/hadoop-client-gzns-lizhu/hadoop/bin/hadoop`;
    return hadoop_client_list[hadoop_cluster_name];
}

function main(input) {
    sequence {
        let detect_type = input.job_args.get("detect_type", 1002);
        let separator = input.job_args.get("separator", "\t");
        let crawl_type = input.job_args.get("crawl_type", "wise");
        let detect_priority = input.job_args.get("detect_priority", 0);
        let data_tag = input.job_args.get("data_tag", "base");
        let spider_version = input.job_args.get("spider_version", "spider_workspace_detect_db98faf3f463a0274e37ed91fc2d0d8f9453a07f");
        let app_id = input.job_args.get("app_id", "detect");
        let spider_cluster = input.job_args.get("spider_cluster", "Detect");
        let hadoop_cluster_name = input.job_args.get("hadoop_cluster_name", "cms_queue_hadoop");
        let hadoop_queue_name = input.job_args.get("hadoop_queue_name", "cms");
        let hadoop_job_name = input.job_args.get("hadoop_job_name", "job_lpq_detect_diagnose");
        let hadoop_job_priority = input.job_args.get("hadoop_job_priority", "VERY_HIGH");
        let reduce_num = input.job_args.get("reduce_num", 100);
        let hadoop_ugi = input.job_args.get("hadoop_ugi", "");
        let score_version_list = input.job_args.get("score_version_list", []);
        let strategy_score_cibiao = input.job_args.get("strategy_score_cibiao", "");
        let export_hours = input.job_args.get("export_hours", 6);
        let diagnose_reduce_num = input.job_args.get("diagnose_reduce_num", 3);
        let pos_of_url_query = 2;
        let pos_of_url_origin = 2;
        let pos_of_id = 1;
        let hadoop = get_hadoop_client(hadoop_cluster_name);
        let hadoop_ugi_conf = "";
        if hadoop_ugi != "" {
            hadoop_ugi_conf = `-D hadoop.job.ugi=${hadoop_ugi}`;
        }

        let token = input.job_args.get("token", "WATT-TOKEN:2259174625bb9c3e16a6bbce5a1d568d");
        let header = input.job_args.get("header", "WATT-PROD:fcbiz");
        let md5_path = input.job_args.get("md5_path", "http://watt-data.baidu-int.com:18081/watt/base/fcbiz-landpagebenchmark-online/0/bid.info.md5");
        let md5_hdfs_path = input.job_args.get("md5_hdfs_path", "afs://fenghuang.afs.baidu.com:9902/user/im-cms/shangzhongbin/lpq_detect_diagnose/md5_file");
        let diagnose_file_path = input.job_args.get("diagnose_file_path", "http://watt-data.baidu-int.com:18081/watt/base/fcbiz-landpagebenchmark-online/0/merge/bid.info");
        let wait_time = input.job_args.get("wait_time", 600);
        let post_token = input.job_args.get("post_token","66334422d12d71d26c70234883e8ef60");
        let url_post_result = input.job_args.get("url_post_result", "http://hairuo-api.baidu-int.com/cloud/LandingPageQualityService/updateLandingPagetestttt");
        let optid = input.job_args.get("optid", "25206564");
        let score_version = input.job_args.get("score_version", "OPERATOR_RULE_111110");

        // high diagnose root
        let high_diagnose_root = input.job_args.get("high_diagnose_root", "afs://fenghuang.afs.baidu.com:9902/user/im-cms/cms_temp/lpa-lpq/high_diagnose/test");

        let today = s2.bash_c(`date +"%Y-%m-%d"`);
        let start_time =  input.job_args.get("start_time", today);
        let timestamp = s2.bash_c(`date +%s`);

        let org_lpq_diagnose_result = "";
        let deadlink_diagnose_result = "";
        let ps_pop_diagnose_result = "";
        let soft_article_diagnose_result = "";

        // high recheck
        let high_recheck_probs_org_lpq = "";
        let high_recheck_probs_deadlink = "";
        let high_recheck_probs_ps_pop = "";
        let high_recheck_probs_soft_article = "";

        // wait user recheck data from business for lpq
        let wait_file_args = {};
        wait_file_args["hadoop_cluster_name"] = hadoop_cluster_name;
        wait_file_args["token"] = token;
        wait_file_args["header"] = header;
        wait_file_args["file_path"] = diagnose_file_path;
        wait_file_args["md5_path"] = md5_path;
        wait_file_args["md5_hdfs_path"] = md5_hdfs_path;
        wait_file_args["wait_time"] = wait_time;
        wait_file_args["output_dir"] = `${high_diagnose_root}/input_file`;
        let wait_file_output = cc.py("wait_diagnose_file", {
            "sys_args": input.sys_args,
            "worker_args": wait_file_args
        });

        let dispatch_args = {};
        dispatch_args["input_all_probs"] = wait_file_output.ret_data.output_dir;
        dispatch_args["dispatch_output"] = `${high_diagnose_root}/dispatcher/${timestamp}`;
        dispatch_args["hadoop_cluster_name"] = hadoop_cluster_name;
        dispatch_args["reduce_num"] = 1;
        dispatch_args["hadoop_ugi"] = hadoop_ugi;
        let dispatcher_output_data = cc.py("diagnose_dispatcher_separate", {
            "sys_args": input.sys_args,
            "worker_args": dispatch_args
        });

        parallel {
            // org lpa diagnose
            sequence {
                //crawl
                if dispatcher_output_data.ret_data.output_dir.org_lpq.size > 0 {
                    // unique original lpq detect urls
                    let org_lpq_unique_args = {};
                    org_lpq_unique_args["input_path_list"] = [`${dispatcher_output_data.ret_data.output_dir.org_lpq.path}`];
                    org_lpq_unique_args["input_seperator"] = separator;
                    org_lpq_unique_args["field_list"] = [pos_of_url_origin];
                    org_lpq_unique_args["hadoop_job_priority"] = hadoop_job_priority;
                    org_lpq_unique_args["hadoop_queue_name"] = hadoop_queue_name;
                    org_lpq_unique_args["hadoop_job_name"] = `${hadoop_job_name}_${input.sys_args.job_id}_unique_worker_org_lpq`;
                    org_lpq_unique_args["output_dir"] = `${high_diagnose_root}/org_lpq/unique_worker/${timestamp}`;
                    org_lpq_unique_args["hadoop_cluster_name"] = hadoop_cluster_name;
                    org_lpq_unique_args["reduce_num"] = reduce_num;
                    let org_lpq_unique_output_data = cc.py("unique_worker", {
                        "sys_args": input.sys_args,
                        "worker_args": org_lpq_unique_args
                    });

                    let crawler_args = {};
                    crawler_args["url_column"] = pos_of_url_origin;
                    crawler_args["spider_version"] = spider_version;
                    crawler_args["detect"] = true;
                    crawler_args["detect_type"] = detect_type;
                    crawler_args["app_id"] = app_id;
                    crawler_args["data_type"] = "hdfs";
                    crawler_args["data_source"] = org_lpq_unique_output_data.ret_data.output_dir;
                    crawler_args["data_tag"] = data_tag;
                    crawler_args["crawl_type"] = crawl_type;
                    crawler_args["flag_random"] = true;
                    crawler_args["priority"] = detect_priority;
                    crawler_args["input_seperator"] = separator;
                    crawler_args["cluster"] = spider_cluster;
                    crawler_args["hadoop_cluster_name"] = hadoop_cluster_name;
                    cc.py("crawler_worker", {
                        "sys_args": input.sys_args,
                        "worker_args": crawler_args
                    });

                    // query get crawl result for origin
                    let query_args = {};
                    query_args["input_path"] = org_lpq_unique_output_data.ret_data.output_dir;
                    query_args["key_column"] = pos_of_url_query;
                    query_args["query_type"] = "url_data";
                    query_args["input_seperator"] = separator;
                    query_args["extend_memory"] = true;
                    query_args["data_type"] = crawl_type;
                    query_args["data_tag"] = data_tag;
                    query_args["hadoop_job_priority"] = hadoop_job_priority;
                    query_args["hadoop_queue_name"] = hadoop_queue_name;
                    query_args["hadoop_job_name"] = `${hadoop_job_name}_${input.sys_args.job_id}_query_worker`;
                    query_args["need_stat"] = "yes";
                    query_args["output_dir"] = `${high_diagnose_root}/org_lpq/query_worker/${timestamp}`;
                    query_args["content_name"] = detect_type;
                    query_args["start_time"] = start_time;
                    query_args["seperator"] = separator;
                    query_args["hadoop_cluster_name"] = hadoop_cluster_name;
                    if reduce_num != 0 {
                        query_args["reduce_num"] = reduce_num;
                    }
                    let query_output_data = cc.py("query_worker", {
                        "sys_args": input.sys_args,
                        "worker_args": query_args
                    });

                    for version in score_version_list {
                        let operator_model = version["operator_model"];
                        let operator_model_bin_path = version["operator_model_bin_path"];
                        //strategy_score_worker
                        let strategy_score_args = {};
                        strategy_score_args["input_path"] = `${query_output_data.ret_data.output_dir}/*A`;
                        strategy_score_args["operator_model"] = operator_model;
                        strategy_score_args["operator_model_bin_path"] = operator_model_bin_path;
                        strategy_score_args["output_dir"] = `${high_diagnose_root}/org_lpq/strategy_score_worker_${operator_model}/${timestamp}`;
                        strategy_score_args["hadoop_job_priority"] = hadoop_job_priority;
                        strategy_score_args["hadoop_queue_name"] = hadoop_queue_name;
                        strategy_score_args["hadoop_job_name"] = `${hadoop_job_name}_${input.sys_args.job_id}_strategy_score_worker`;
                        strategy_score_args["hadoop_cluster_name"] = hadoop_cluster_name;
                        if strategy_score_cibiao != "" {
                            strategy_score_args["strategy_score_cibiao"] = strategy_score_cibiao;
                        }
                        let strategy_score_output_data = cc.py("strategy_score_worker", {
                            "sys_args": input.sys_args,
                            "worker_args": strategy_score_args
                        });
                        //storage_worker
                        let storage_args = {};
                        storage_args["input_path"] = `${high_diagnose_root}/org_lpq/strategy_score_worker_${operator_model}/${timestamp}`;
                        storage_args["output_dir"] = `${high_diagnose_root}/org_lpq/storage_worker_${operator_model}/${timestamp}`;
                        storage_args["hadoop_job_priority"] = hadoop_job_priority;
                        storage_args["hadoop_queue_name"] = hadoop_queue_name;
                        storage_args["hadoop_job_name"] = `${hadoop_job_name}_${input.sys_args.job_id}_storage_worker`;
                        storage_args["diagnose_flag"] = 1;
                        storage_args["hadoop_cluster_name"] = hadoop_cluster_name;
                        let storage_output_data_local = cc.py("storage_worker", {
                            "sys_args": input.sys_args,
                            "worker_args": storage_args
                        });
                    }
                    //get score and push back to service
                    let diagnose_args = {};
                    diagnose_args["input_path"] = `${dispatcher_output_data.ret_data.output_dir.org_lpq.path}`;
                    diagnose_args["output_dir"] = `${high_diagnose_root}/org_lpq/diagnose_worker/${timestamp}`;
                    diagnose_args["hadoop_cluster_name"] = hadoop_cluster_name;
                    diagnose_args["hadoop_job_name"] = `${hadoop_job_name}_${input.sys_args.job_id}_diagnose_worker`;
                    diagnose_args["hadoop_queue_name"] = hadoop_queue_name;
                    diagnose_args["reduce_num"] = diagnose_reduce_num;
                    diagnose_args["score_version"] = score_version;
                    diagnose_args["export_hours"] = export_hours;
                    let diagnose_out_data = cc.py("lpq_detect_diagnose_slim", {
                        "sys_args": input.sys_args,
                        "worker_args": diagnose_args
                    });
                    org_lpq_diagnose_result = diagnose_out_data.ret_data.output_dir;

                    // dump recheck problems
                    let dump_org_lpq_recheck_probs_arg = {};
                    dump_org_lpq_recheck_probs_arg["diagnose_org_lpq"] = diagnose_out_data.ret_data.output_dir;
                    dump_org_lpq_recheck_probs_arg["high_recheck_org_lpq_output_root"] = `${high_diagnose_root}/org_lpq/recheck_probs`;
                    dump_org_lpq_recheck_probs_arg["hadoop_job_name"] = `${hadoop_job_name}_${input.sys_args.job_id}_diagnose_dump_org_lpq_probs`;
                    dump_org_lpq_recheck_probs_arg["reduce_num"] = 10;
                    dump_org_lpq_recheck_probs_arg["hadoop_cluster_name"] = hadoop_cluster_name;
                    let dump_org_lpq_recheck_probs_out_data = cc.py("dump_recheck_probs_org_lpq", {
                        "sys_args": input.sys_args,
                        "worker_args": dump_org_lpq_recheck_probs_arg
                    });
                    high_recheck_probs_org_lpq = dump_org_lpq_recheck_probs_out_data.ret_data.output_dir;
                }
            }

            // deadlink
            sequence {
                if dispatcher_output_data.ret_data.output_dir.deadlink.size > 0 {
                    // unique original lpq detect urls
                    let deadlink_lpq_unique_args = {};
                    deadlink_lpq_unique_args["input_path_list"] = [`${dispatcher_output_data.ret_data.output_dir.deadlink.path}`];
                    deadlink_lpq_unique_args["input_seperator"] = separator;
                    deadlink_lpq_unique_args["field_list"] = [pos_of_url_origin];
                    deadlink_lpq_unique_args["hadoop_job_priority"] = hadoop_job_priority;
                    deadlink_lpq_unique_args["hadoop_queue_name"] = hadoop_queue_name;
                    deadlink_lpq_unique_args["hadoop_job_name"] = `${hadoop_job_name}_${input.sys_args.job_id}_unique_worker_deadlink`;
                    deadlink_lpq_unique_args["output_dir"] = `${high_diagnose_root}/deadlink/unique_worker/${timestamp}`;
                    deadlink_lpq_unique_args["hadoop_cluster_name"] = hadoop_cluster_name;
                    deadlink_lpq_unique_args["reduce_num"] = reduce_num;
                    let deadlink_unique_output_data = cc.py("unique_worker", {
                        "sys_args": input.sys_args,
                        "worker_args": deadlink_lpq_unique_args
                    });

                    // crawler deadlink
                    let deadlink_crawler_arg = {};
                    deadlink_crawler_arg["data_type"] = "hdfs";
                    deadlink_crawler_arg["url_column"] = pos_of_url_origin;
                    deadlink_crawler_arg["data_source"] = deadlink_unique_output_data.ret_data.output_dir;
                    deadlink_crawler_arg["data_tag"] = "base";
                    deadlink_crawler_arg["cluster"] = "spicloud";
                    deadlink_crawler_arg["crawl_type"] = "wise";
                    deadlink_crawler_arg["crawl_system"] = "spi_cloud";
                    deadlink_crawler_arg["priority"] = 3;
                    deadlink_crawler_arg["input_seperator"] = separator;
                    deadlink_crawler_arg["url_batch_num"] = 10000;
                    deadlink_crawler_arg["hadoop_cluster_name"] = hadoop_cluster_name;
                    cc.py("crawler_worker", {
                        "sys_args": input.sys_args,
                        "worker_args": deadlink_crawler_arg
                    });

                    let deadlink_diagnose_arg = {};
                    deadlink_diagnose_arg["input_deadlink"] = `${dispatcher_output_data.ret_data.output_dir.deadlink.path}`;
                    deadlink_diagnose_arg["deadlink_output"] = `${high_diagnose_root}/deadlink/diagnose_worker`;
                    deadlink_diagnose_arg["hadoop_job_name"] = `${hadoop_job_name}_${input.sys_args.job_id}_diagnose_worker_deadlink`;
                    deadlink_diagnose_arg["deadlink_output_recheck"] = `${high_diagnose_root}/deadlink/recheck_probs`;
                    deadlink_diagnose_arg["hadoop_cluster_name"] = hadoop_cluster_name;
                    let diagnose_deadlink_out_data = cc.py("lpq_detect_diagnose_deadlink", {
                        "sys_args": input.sys_args,
                        "worker_args": deadlink_diagnose_arg
                    });
                    deadlink_diagnose_result = diagnose_deadlink_out_data.ret_data.output_dir.deadlink.path;
                    high_recheck_probs_deadlink = diagnose_deadlink_out_data.ret_data.output_dir.high_recheck.path;
                }
            }

            sequence {
                if dispatcher_output_data.ret_data.output_dir.ns_pop.size > 0 {
                    let send_ps_pop_urls_arg = {};
                    send_ps_pop_urls_arg["hadoop_cluster_name"] = hadoop_cluster_name;
                    send_ps_pop_urls_arg["dispatch_ps_pop_input"] = dispatcher_output_data.ret_data.output_dir.ns_pop.path;
                    send_ps_pop_urls_arg["ps_pop_cluster_send_root"] = `${high_diagnose_root}/ps_pop/cluster/input`;
                    send_ps_pop_urls_arg["ps_pop_cluster_recv_root"] = `${high_diagnose_root}/ps_pop/cluster/output`;
                    let send_ps_pop_urls_out_data = cc.py("send_recv_ps_pop_urls", {
                        "sys_args": input.sys_args,
                        "worker_args": send_ps_pop_urls_arg
                    });

                    if send_ps_pop_urls_out_data.ret_data.size > 0 {
                        let ps_pop_import_arg = {};
                        ps_pop_import_arg["input_path"] = send_ps_pop_urls_out_data.ret_data.output_dir;
                        ps_pop_import_arg["output_dir"] = `${high_diagnose_root}/ps_pop/import_worker/${timestamp}`;
                        ps_pop_import_arg["seperator"] = "\t";
                        ps_pop_import_arg["url_index"] = "3";
                        ps_pop_import_arg["data_type"] = "wise_page";
                        ps_pop_import_arg["content_name"] = {"2": "ns_pop"};
                        ps_pop_import_arg["data_tag"] = "base";
                        ps_pop_import_arg["hadoop_cluster_name"] = hadoop_cluster_name;
                        ps_pop_import_arg["hadoop_queue_name"] = hadoop_queue_name;
                        ps_pop_import_arg["hadoop_ugi"] = hadoop_ugi;
                        ps_pop_import_arg["hadoop_job_priority"] = hadoop_job_priority;
                        ps_pop_import_arg["hadoop_job_name"] = `${hadoop_job_name}_${input.sys_args.job_id}_import_ps_pop`;
                        ps_pop_import_arg["reduce_num"] = 10;
                        let ps_pop_import_out_data = cc.py("import_worker", {
                            "sys_args": input.sys_args,
                            "worker_args": ps_pop_import_arg
                        });
                    }

                    let ps_pop_diagnose_arg = {};
                    ps_pop_diagnose_arg["ps_pop_cluster_resp"] = send_ps_pop_urls_out_data.ret_data.output_dir;
                    ps_pop_diagnose_arg["ps_pop_dispatch_output"] = dispatcher_output_data.ret_data.output_dir.ns_pop.path;
                    ps_pop_diagnose_arg["ps_pop_diagnose_output_root"] = `${high_diagnose_root}/ps_pop/diagnose_worker`;
                    ps_pop_diagnose_arg["ps_pop_diagnose_probs_output_root"] = `${high_diagnose_root}/ps_pop/recheck_probs`;
                    ps_pop_diagnose_arg["hadoop_cluster_name"] = hadoop_cluster_name;
                    ps_pop_diagnose_arg["reduce_num"] = 20;
                    let ps_pop_diagnose_out_data = cc.py("lpq_detect_diagnose_ps_pop", {
                        "sys_args": input.sys_args,
                        "worker_args": ps_pop_diagnose_arg
                    });
                    ps_pop_diagnose_result = ps_pop_diagnose_out_data.ret_data.output_dir.diagnose.path;
                    high_recheck_probs_ps_pop = ps_pop_diagnose_out_data.ret_data.output_dir.high_recheck.path;
                }
            }

            // soft_article
            sequence {
                if dispatcher_output_data.ret_data.output_dir.soft_article.size > 0 {
                    // unique soft article lpq detect urls
                    let soft_article_lpq_unique_args = {};
                    soft_article_lpq_unique_args["input_path_list"] = [`${dispatcher_output_data.ret_data.output_dir.soft_article.path}`];
                    soft_article_lpq_unique_args["input_seperator"] = separator;
                    soft_article_lpq_unique_args["field_list"] = [pos_of_url_origin];
                    soft_article_lpq_unique_args["hadoop_job_priority"] = hadoop_job_priority;
                    soft_article_lpq_unique_args["hadoop_queue_name"] = hadoop_queue_name;
                    soft_article_lpq_unique_args["hadoop_job_name"] = `${hadoop_job_name}_${input.sys_args.job_id}_unique_worker_soft_article`;
                    soft_article_lpq_unique_args["output_dir"] = `${high_diagnose_root}/soft_article/unique_worker/${timestamp}`;
                    soft_article_lpq_unique_args["hadoop_cluster_name"] = hadoop_cluster_name;
                    soft_article_lpq_unique_args["reduce_num"] = reduce_num;
                    let soft_article_unique_output_data = cc.py("unique_worker", {
                        "sys_args": input.sys_args,
                        "worker_args": soft_article_lpq_unique_args
                    });

                    // crawler soft_article
                    let soft_article_crawler_arg = {};
                    soft_article_crawler_arg["data_type"] = "hdfs";
                    soft_article_crawler_arg["url_column"] = pos_of_url_origin;
                    soft_article_crawler_arg["data_source"] = soft_article_unique_output_data.ret_data.output_dir;
                    soft_article_crawler_arg["data_tag"] = "base";
                    soft_article_crawler_arg["cluster"] = "spicloud";
                    soft_article_crawler_arg["crawl_type"] = "wise";
                    soft_article_crawler_arg["crawl_system"] = "spi_cloud";
                    soft_article_crawler_arg["priority"] = 3;
                    soft_article_crawler_arg["input_seperator"] = separator;
                    soft_article_crawler_arg["url_batch_num"] = 10000;
                    soft_article_crawler_arg["hadoop_cluster_name"] = hadoop_cluster_name;
                    cc.py("crawler_worker", {
                        "sys_args": input.sys_args,
                        "worker_args": soft_article_crawler_arg
                    });


                    let soft_article_diagnose_arg = {};
                    soft_article_diagnose_arg["input_soft_article"] = `${dispatcher_output_data.ret_data.output_dir.soft_article.path}`;
                    soft_article_diagnose_arg["soft_article_output"] = `${high_diagnose_root}/soft_article/diagnose_worker`;
                    soft_article_diagnose_arg["hadoop_job_name"] = `${hadoop_job_name}_${input.sys_args.job_id}_diagnose_worker_soft_article`;
                    soft_article_diagnose_arg["soft_article_output_recheck"] = `${high_diagnose_root}/soft_article/recheck_probs`;
                    soft_article_diagnose_arg["hadoop_cluster_name"] = hadoop_cluster_name;
                    let diagnose_soft_article_out_data = cc.py("lpq_detect_diagnose_soft_article", {
                        "sys_args": input.sys_args,
                        "worker_args": soft_article_diagnose_arg
                    });
                    soft_article_diagnose_result = diagnose_soft_article_out_data.ret_data.output_dir.soft_article.path;
                    high_recheck_probs_soft_article = diagnose_soft_article_out_data.ret_data.output_dir.high_recheck.path;
                }

            }
        }

        // merge diagnose result
        let diagnose_merge_arg = {};
        diagnose_merge_arg["input_list"] = [
            org_lpq_diagnose_result,
            deadlink_diagnose_result,
            ps_pop_diagnose_result,
            soft_article_diagnose_result
        ];
        diagnose_merge_arg["merge_output"] = `${high_diagnose_root}/diagnose_merge`;
        diagnose_merge_arg["hadoop_cluster_name"] = hadoop_cluster_name;
        diagnose_merge_arg["url_post_result"] = url_post_result;
        diagnose_merge_arg["token"] = post_token;
        diagnose_merge_arg["optid"] = optid;
        let diagnose_merge_out_data = cc.py("lpq_detect_diagnose_merge", {
            "sys_args": input.sys_args,
            "worker_args": diagnose_merge_arg
        });

        // merge recheck
        let merge_recheck_probs_arg = {};
        merge_recheck_probs_arg["hadoop_cluster_name"] = hadoop_cluster_name;
        merge_recheck_probs_arg["reduce_num"] = 100;
        merge_recheck_probs_arg["recheck_input_list"] = [
            high_recheck_probs_org_lpq,
            high_recheck_probs_deadlink,
            high_recheck_probs_ps_pop,
            high_recheck_probs_soft_article
        ];
        merge_recheck_probs_arg["recheck_output_root"] = `${high_diagnose_root}/recheck_merge/current`;
        let merge_recheck_probs_out_data = cc.py("merge_recheck_problems", {
            "sys_args": input.sys_args,
            "worker_args": merge_recheck_probs_arg
        });

        cc.py("process", {
            "sys_args": input.sys_args,
            "worker_args": {
                "process": 100,
                "process_name": "job_done",
                "output": diagnose_merge_out_data.ret_data.output_dir
            }
        });
    }
}