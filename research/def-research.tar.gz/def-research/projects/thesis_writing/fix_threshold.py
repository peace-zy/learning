#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   dangjinming@baidu.com
Date  :   2020/6/2
"""
import sys
import os
import argparse
import time
import numpy as np

_cur_dir = os.path.dirname(os.path.abspath(__file__))
_dict_dir = "%s/mid/" % _cur_dir
sys.path.append("%s/../../lib/common" % _cur_dir)
import review_object
import common

def LR_args_result():
    """
    edit : dangjinming
    func : ͨ�������з�ʽ��ȡģ�ͽ��
    """
    parser = argparse.ArgumentParser(description = "test_model")
    parser.add_argument("--test_sample", help = "��������", required = True)
    parser.add_argument("--class_id", help = "��ǩ�б�", required = True)
    parser.add_argument("--predict_data", help = "Ԥ����", default = "liblinear", required = True)
    parser.add_argument("--predict_out", help = "�Լ���Ҫ���ֶ�", required = True)

    args = parser.parse_args()

    class_dict = common.Common.load_class_id_file(args.class_id)
    class_thres = common.Common.load_class_thres(args.class_id)

    result_list = []
    label_list = []

    with open(args.predict_data, 'r') as pf:
        for index, eachline in enumerate(pf):
            line = eachline.strip("\n").decode("gbk", "ignore").lower().split(" ")
            if index == 0:
                label_list = line[1:]
            else:
                probs = line[1:]
                probs = list(map(float, probs))
                max_index = np.argmax(probs)
                pre_label = label_list[max_index]
                pre_label_name = class_dict[pre_label.decode("gbk")]
                pre_prob = probs[max_index]
                if pre_label in class_thres:
                    if class_thres[pre_label] <= pre_prob:
                        result_list.append([pre_label, pre_label_name, str(pre_prob)])
                    else:
                        result_list.append(['0', '����', str(pre_prob)])
                else:
                    result_list.append(['0', '����', str(pre_prob)])

    error_index = []
    with open(args.test_sample, 'r') as f:
        with open(args.predict_out, 'w') as pf:
            for case_index, eachline in enumerate(f):
                line = eachline.strip("\n").decode("gbk", "ignore").lower().split("\t")
                result = result_list[case_index]
                label = result[0]
                label_name = result[1]
                label_prob = result[2]
                #��ʵ��ǩ\tԤ���ǩ\t��ǩname\t����ʵ��ı�����
                out_str = [line[0], label, label_name, line[1]]
                pf.write("\t".join(out_str) + "\n")
                if line[0] != label:
                    error_index.append(case_index)
    error_str = " ".join([str(i + 1) for i in error_index])
    print "error index are %s" % error_str
    predict_rate = (case_index - len(error_index) + 0.0) / case_index
    print "predict acc rate is %f" % predict_rate

if __name__ == "__main__":
    start = time.time()
    LR_args_result()
    end = time.time()
    print "total time: %f" % (end - start)
    pass
