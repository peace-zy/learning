#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   dangjinming@baidu.com
Date  :   2020/6/2
Desc  :   ��������shaolin��Ⱥ���Լ��洢�ĵ�ַ��ȡ, python get_neg_sample.py --out_path "./mid/neg_sample.txt" --neg_num 10000
"""
import sys
import os
import subprocess
import argparse
import logging

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../lib/" % _cur_dir)

import common.common as common
import common.word_seg as word_seg
import common.review_object as review_object
import sample.sample as sample

machine = "hdfs://nmg01-mulan-hdfs.dmop.baidu.com:54310"
file_path = "/app/ecom/aries/fengkong/dangjinming/thesis_writing_def_research_samples/fyb"
dest_file = "%s/mid/origin_data.txt" % _cur_dir

def args_func():
    """
    func : ������ȡ
    """
    parser = argparse.ArgumentParser(description = "sample")
    parser.add_argument("-op", "--out_path", help = "�����������ַ", required = True)
    parser.add_argument("-nn", "--neg_num", help = "��������������", required = True, type = int)
    args = parser.parse_args()
    return args

def filt_word(word_list, stop_word_set):
    """
    func : �Էִʽ������ȥ��ͣ�ôʺͽ϶̵Ĵ�
    """
    word_list=[word for word in word_list  if word not in stop_word_set]
    word_list=[word for word in word_list  if len(word)>1 ]
    return word_list
def get_neg_sample(out_path, neg_num):
    """
    func : �������������hdfs��ַ��ȡ������
    """
    r_obj = None
    neg_label_id = 0
    neg_sample_num = neg_num

    # ��ȡ������ȫ������
    if os.path.exists(dest_file) == False:
        cmd_str = "hadoop fs -get " + machine + file_path + " " + dest_file
        ret = subprocess.call(cmd_str, shell = True)
        if ret != 0:
            logging.error("wget file from remote machine failed !")
            sys.exit(1)
    else:
        logging.info("orgin_data is exsit.")

    logging.info("sampling neg sample... please wait a moment.")

    #��ʼ���д���
    _dict_dir = "%s/../../dict/" % _cur_dir
    stopword_path = os.path.join(_dict_dir, "stopword.txt")
    with open(stopword_path, 'r') as fr:
        stop_word_list = [line.strip() for line in fr if line.strip() != '']
        stop_word_set = set(stop_word_list)
    ws = word_seg.WordSeg("%s/../../dict" % _cur_dir + "/chinese_gbk")
    ws.init_wordseg_handle()
   
    #��lp7��feature���д������ִʼ���fea��
    count = 0 #ͳ�Ƶ�ǰ�����������������neg_sample_num����ֹͣ
    with open(dest_file, 'r') as fr:
        with open(out_path, 'w') as fw:
            for line in fr:
                count += 1
                if neg_sample_num < count:
                    break
                parts=line.strip("\n").split("\t")
                title = filt_word(ws.seg_words(parts[1]), stop_word_set)
                navi = filt_word(ws.seg_words(parts[2]), stop_word_set)
                content = filt_word(ws.seg_words(parts[3]), stop_word_set)
                meta_keywords = filt_word(ws.seg_words(parts[4]), stop_word_set)
                meta_desc = filt_word(ws.seg_words(parts[5]), stop_word_set)
                in_anchor = filt_word(ws.seg_words(parts[6]), stop_word_set)
                out_anchor = filt_word(ws.seg_words(parts[7]), stop_word_set)
                
                
                title_seg = ";title ".join(title)+";title"
                navi_seg = ";navi ".join(navi)+";navi"
                content_seg = ";content ".join(content)+";content"
                meta_keywords_seg = ";meta_keywords ".join(meta_keywords)+";meta_keywords"
                meta_desc_seg = ";meta_desc ".join(meta_desc)+";meta_desc"
                in_anchor_seg = ";in_anchor ".join(in_anchor)+";in_anchor"
                out_anchor_seg = ";out_anchor ".join(out_anchor)+";out_anchor"
                fw.write("%d\t%s\n" % (0, " ".join([title_seg, navi_seg, content_seg, meta_keywords_seg, \
                meta_desc_seg, in_anchor_seg, out_anchor_seg])))

                
                


if __name__ == "__main__":
    args = args_func()
    get_neg_sample(args.out_path, args.neg_num)
    pass


