# !/usr/bin/env python3
# coding=utf-8
"""
Author: changxiaojing@baidu.com
Date: 2021/11/10
"""
import os
import copy
import json
import torch
import random
import logging
import numpy as np

logger = logging.getLogger(__name__)

def set_seed(seed):
    """
    设置随机种子
    """
    random.seed(seed)
    torch.manual_seed(seed)
    np.random.seed(seed)
    torch.cuda.manual_seed_all(seed)


def prepare_para_dict(opt):
    """
    获取para dict
    """
    feature_para, dataset_para, model_para = {}, {}, {}
    task_type = opt.task_type

    if hasattr(opt, 'dropout_prob'):
        model_para['dropout_prob'] = opt.dropout_prob

    if task_type == 'trigger':
        dataset_para['use_distant_trigger'] = opt.use_distant_trigger
        model_para['use_distant_trigger'] = opt.use_distant_trigger

    elif task_type == 'role1':
        dataset_para['use_trigger_distance'] = opt.use_trigger_distance
        model_para['use_trigger_distance'] = opt.use_trigger_distance
    
    return feature_para, dataset_para, model_para


def load_model_and_parallel(model, gpu_ids, ckpt_path=None, strict=True):
    """
    加载模型 & 放置到 GPU 中（单卡 / 多卡）
    """

    gpu_ids = gpu_ids.split(',')

    # set to device to the first cuda
    device = torch.device("cpu" if gpu_ids[0] == '-1' else "cuda:" + gpu_ids[0])

    if ckpt_path is not None:
        logger.info(f'Load ckpt from {ckpt_path}')
        model.load_state_dict(torch.load(ckpt_path, map_location=torch.device('cpu')), strict=strict)

    model.to(device)

    if len(gpu_ids) > 1:
        logger.info(f'Use multi gpus in: {gpu_ids}')
        gpu_ids = [int(x) for x in gpu_ids]
        model = torch.nn.DataParallel(model, device_ids=gpu_ids)
    else:
        logger.info(f'Use single gpu in: {gpu_ids}')

    return model, device

