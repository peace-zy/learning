# !/usr/bin/env python3
# coding=utf-8
"""
Author: changxiaojing@baidu.com
Date: 2021/11/10
"""
import torch
import logging
import numpy as np
from tqdm import tqdm
from src.processor import search_label_index


logger = logging.getLogger(__name__)


def get_base_out(model, loader, device, task_type):
    """
    每一个任务的 forward 都一样，封装起来
    """
    model.eval()

    with torch.no_grad():
        for idx, _batch in enumerate(tqdm(loader, desc=f'Get {task_type} task predict logits')):

            for key in _batch.keys():
                _batch[key] = _batch[key].to(device)

            tmp_out = model(**_batch)

            yield tmp_out


def pointer_trigger_decode(logits, raw_text, distant_triggers, start_threshold=0.5, end_threshold=0.5,
                           one_trigger=True):
    """
    trigger decode
    """
    candidate_entities = []

    start_ids = np.argwhere(logits[:, 0] > start_threshold)[:, 0]
    end_ids = np.argwhere(logits[:, 1] > end_threshold)[:, 0]

    # 选最短的
    for _start in start_ids:
        for _end in end_ids:
            # 限定 trigger 长度不能超过 3
            if _end >= _start and _end - _start <= 2:
                # (start, end, start_logits + end_logits)
                candidate_entities.append((raw_text[_start: _end + 1], _start, logits[_start][0] + logits[_end][1], logits[_start][0], logits[_end][1]))
                break

    if not len(candidate_entities):
        for _dis_trigger in distant_triggers:
            trigger_ids = search_label_index(raw_text, _dis_trigger)

            for idx in trigger_ids:
                if idx[1] >= len(logits):
                    continue
                candidate_entities.append((raw_text[idx[0]: idx[1] + 1], idx[0],
                                           logits[idx[0]][0] + logits[idx[1]][1], logits[idx[0]][0], logits[idx[1]][1]))

    entities = []

    if len(candidate_entities):
        candidate_entities = sorted(candidate_entities, key=lambda x: x[2], reverse=True)

        if one_trigger:
            # 只解码一个，返回 logits 最大的 trigger
            entities.append(candidate_entities[0][:])
        else:
            # 解码多个，返回多个 trigger + 对应的 logits
            for _ent in candidate_entities:
                entities.append(_ent[:])
    
    else:
        # 最后还是没有解码出 trigger 时选取 logits 最大的作为 trigger
        start_ids = np.argmax(logits[:, 0])
        end_ids = np.argmax(logits[:, 1])

        if end_ids < start_ids:
            end_ids = start_ids + np.argmax(logits[start_ids:, 1])
        
        entities.append((raw_text[start_ids: end_ids + 1], int(start_ids), logits[start_ids][0] + logits[end_ids][1], logits[start_ids][0], logits[end_ids][1]))
    
    return entities


def pointer_decode(logits, raw_text, start_threshold=0.5, end_threshold=0.5, force_decode=False):
    """
    pointer_decode 
    """
    entities = []
    candidate_entities = []

    start_ids = np.argwhere(logits[:, 0] > start_threshold)[:, 0]
    end_ids = np.argwhere(logits[:, 1] > end_threshold)[:, 0]

    # 选最短的
    for _start in start_ids:
        for _end in end_ids:
            if _end >= _start:
                # (start, end, logits)
                candidate_entities.append((_start, _end, logits[_start][0] + logits[_end][1]))
                break
    if len(candidate_entities):
        candidate_entities = sorted(candidate_entities, key=lambda x: x[2], reverse=True)

        entities.append((raw_text[candidate_entities[0][0]:candidate_entities[0][1] + 1], float(candidate_entities[0][2]))) 
    
    return entities


def trigger_evaluation(model, dev_info, device, **kwargs):
    """
    线下评估 trigger 模型
    """
    dev_loader, dev_callback_info = dev_info

    pred_logits = None

    for tmp_pred in get_base_out(model, dev_loader, device, 'role'):
        tmp_pred = tmp_pred[0].cpu().numpy()

        if pred_logits is None:
            pred_logits = tmp_pred
        else:
            pred_logits = np.append(pred_logits, tmp_pred, axis=0)

    assert len(pred_logits) == len(dev_callback_info)

    start_threshold = kwargs.pop('start_threshold')
    end_threshold = kwargs.pop('end_threshold')

    all_entities = []

    for tmp_pred, tmp_callback in zip(pred_logits, dev_callback_info):
        text, gt_triggers, distant_triggers = tmp_callback
        tmp_pred = tmp_pred[1:1 + len(text)]

        pred_triggers = pointer_trigger_decode(tmp_pred, text, distant_triggers,
                                               start_threshold=start_threshold,
                                               end_threshold=end_threshold,
                                               one_trigger=False)
        all_entities.append(pred_triggers)

    result = {"all_entities": all_entities, "pred_logits": pred_logits}

    return result


def role1_evaluation(model, dev_info, device, **kwargs):
    """
    线下评估 role 模型
    """
    dev_loader, (dev_callback_info, type_weight) = dev_info

    pred_logits = None
    all_sub_desc_entities = []
    all_sub_entities = []
    all_obj_desc_entities = []
    all_obj_entities = []
    all_reason_entities = []
    all_result_entities = []
    all_location_entities = []
    all_time_entities = []

    for tmp_pred in get_base_out(model, dev_loader, device, 'role'):
        tmp_pred = tmp_pred[0].cpu().numpy()

        if pred_logits is None:
            pred_logits = tmp_pred
        else:
            pred_logits = np.append(pred_logits, tmp_pred, axis=0)

    assert len(pred_logits) == len(dev_callback_info)

    start_threshold = kwargs.pop('start_threshold')
    end_threshold = kwargs.pop('end_threshold')

    role_types = ['sub_desc', 'subject', 'obj_desc', 'object', 'reason', 'result', 'location', 'time']

    for tmp_pred, tmp_callback in zip(pred_logits, dev_callback_info):
        text, trigger, gt_roles = tmp_callback
        tmp_pred = tmp_pred[1:len(text) + 1]

        pred_sub_desc = pointer_decode(tmp_pred[:, :2], text, start_threshold, end_threshold, True)
        pred_sub = pointer_decode(tmp_pred[:, 2:4], text, start_threshold, end_threshold, True)
        pred_obj_desc = pointer_decode(tmp_pred[:, 4:6], text, start_threshold, end_threshold, True)
        pred_obj = pointer_decode(tmp_pred[:, 6:8], text, start_threshold, end_threshold, True)
        pred_reason = pointer_decode(tmp_pred[:, 8:10], text, start_threshold, end_threshold, True)
        pred_result = pointer_decode(tmp_pred[:, 10:12], text, start_threshold, end_threshold, True)
        pred_location = pointer_decode(tmp_pred[:, 12:14], text, start_threshold, end_threshold, True)
        pred_time = pointer_decode(tmp_pred[:, 14:], text, start_threshold, end_threshold, True)
        
        all_sub_desc_entities.append(pred_sub_desc)
        all_sub_entities.append(pred_sub)
        all_obj_desc_entities.append(pred_obj_desc)
        all_obj_entities.append(pred_obj)
        all_reason_entities.append(pred_reason)
        all_result_entities.append(pred_result)
        all_location_entities.append(pred_location)
        all_time_entities.append(pred_time)

    result = {"sub_desc": all_sub_desc_entities, "sub": all_sub_entities, 
              "obj_desc": all_obj_desc_entities, "obj": all_obj_entities, 
              "reason": all_reason_entities, "result": all_result_entities, 
              "location": all_location_entities, "time": all_time_entities}
    
    return result
