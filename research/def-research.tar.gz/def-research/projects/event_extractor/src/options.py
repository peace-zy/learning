# !/usr/bin/env python3
# coding=utf-8
"""
Author: changxiaojing@baidu.com
Date: 2021/11/10
"""
import argparse


class BaseArgs:
    """
    设置参数
    """
    @staticmethod
    def parse():
        """
        创建参数对象
        """
        parser = argparse.ArgumentParser()
        return parser

    @staticmethod
    def initialize(parser: argparse.ArgumentParser):
        """
        add参数
        """
        # args for path
        parser.add_argument('--raw_data_dir', default='',
                            help='the data dir of raw data')

        parser.add_argument('--output_dir', default='./out/',
                            help='the output dir for model checkpoints')

        parser.add_argument('--bert_dir', default='../bert/torch_roberta_wwm',
                            help='bert dir for ernie / roberta-wwm / uer / semi-bert')

        parser.add_argument('--bert_type', default='roberta_wwm',
                            help='roberta_wwm / ernie_1 / uer_large for bert')

        # other args
        parser.add_argument('--gpu_ids', type=str, default='0',
                            help='gpu ids to use, -1 for cpu, "1, 3" for multi gpu')

        parser.add_argument('--mode', type=str, default='train',
                            help='train / test / stack (train / dev)')

        parser.add_argument('--task_type', type=str, default='trigger',
                            help='trigger / role1 & role2 / attribution task for event extraction')

        # args used for train / dev

        parser.add_argument('--max_seq_len', default=256, type=int)

        parser.add_argument('--eval_batch_size', default=64, type=int)

        parser.add_argument('--swa_start', default=1, type=int,
                            help='the epoch when swa start')

        # module change
        parser.add_argument('--use_distant_trigger', default=False, action='store_true',
                            help='whether to use distant trigger information')

        parser.add_argument('--use_trigger_distance', default=False, action='store_true',
                            help='whether to use the distance between trigger and other words')

        parser.add_argument('--enhance_data', default=False, action='store_true')

        parser.add_argument('--start_threshold', default=0.5, type=float,
                            help='threshold of entity start when decoding')

        parser.add_argument('--end_threshold', default=0.5, type=float,
                            help='threshold of entity end when decoding')

        return parser

    def get_parser(self):
        """
        获取参数
        """
        parser = self.parse()
        parser = self.initialize(parser)
        return parser.parse_args()


class DevArgs(BaseArgs):
    """
    预测时输入参数
    """
    @staticmethod
    def initialize(parser: argparse.ArgumentParser):
        """
        参数初始化
        """
        parser = BaseArgs.initialize(parser)

        parser.add_argument('--dev_dir', type=str, help='dev model dir')
        parser.add_argument('--model_path', type=str, help='dev model path')
        
        return parser

