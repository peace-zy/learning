# !/usr/bin/env python3
# coding=utf-8
"""
Author: changxiaojing@baidu.com
Date: 2021/11/10
"""

import os
import torch
import torch.nn as nn
from torchcrf import CRF
from transformers import BertModel


class ConditionalLayerNorm(nn.Module):
    """
    ConditionalLayerNorm
    """
    def __init__(self,
                 normalized_shape,
                 eps=1e-12):
        """init"""
        super().__init__()

        self.eps = eps

        self.weight = nn.Parameter(torch.Tensor(normalized_shape))
        self.bias = nn.Parameter(torch.Tensor(normalized_shape))

        self.weight_dense = nn.Linear(normalized_shape * 2, normalized_shape, bias=False)
        self.bias_dense = nn.Linear(normalized_shape * 2, normalized_shape, bias=False)

        self.reset_weight_and_bias()

    def reset_weight_and_bias(self):
        """
        此处初始化的作用是在训练开始阶段不让 conditional layer norm 起作用
        """
        nn.init.ones_(self.weight)
        nn.init.zeros_(self.bias)

        nn.init.zeros_(self.weight_dense.weight)
        nn.init.zeros_(self.bias_dense.weight)

    def forward(self, inputs, cond=None):
        """
        前向计算
        """
        assert cond is not None, 'Conditional tensor need to input when use conditional layer norm'
        cond = torch.unsqueeze(cond, 1)  # (b, 1, h*2)

        weight = self.weight_dense(cond) + self.weight  # (b, 1, h)
        bias = self.bias_dense(cond) + self.bias  # (b, 1, h)

        mean = torch.mean(inputs, dim=-1, keepdim=True)  # （b, s, 1）
        outputs = inputs - mean  # (b, s, h)

        variance = torch.mean(outputs ** 2, dim=-1, keepdim=True)
        std = torch.sqrt(variance + self.eps)  # (b, s, 1)

        outputs = outputs / std  # (b, s, h)

        outputs = outputs * weight + bias

        return outputs


class BaseModel(nn.Module):
    """base model"""
    def __init__(self,
                 bert_dir,
                 dropout_prob=0.1):
        """inti"""
        super(BaseModel, self).__init__()
        config_path = os.path.join(bert_dir, 'config.json')

        assert os.path.exists(bert_dir), \
            'pretrained bert file does not exist'

        self.bert_module = BertModel.from_pretrained(bert_dir)

        self.bert_config = self.bert_module.config

        self.dropout_layer = nn.Dropout(dropout_prob)

    @staticmethod
    def _init_weights(blocks, **kwargs):
        """
        参数初始化，将 Linear / Embedding / LayerNorm 与 Bert 进行一样的初始化
        """
        for block in blocks:
            for module in block.modules():
                if isinstance(module, nn.Linear):
                    nn.init.zeros_(module.bias)
                elif isinstance(module, nn.Embedding):
                    nn.init.normal_(module.weight, mean=0, std=kwargs.pop('initializer_range', 0.02))
                elif isinstance(module, nn.LayerNorm):
                    nn.init.zeros_(module.bias)
                    nn.init.ones_(module.weight)

    @staticmethod
    def _batch_gather(data: torch.Tensor, index: torch.Tensor):
        """
        实现类似 tf.batch_gather 的效果
        :param data: (bs, max_seq_len, hidden)
        :param index: (bs, n)
        :return: a tensor which shape is (bs, n, hidden)
        """
        index = index.unsqueeze(-1).repeat_interleave(data.size()[-1], dim=-1)  # (bs, n, hidden)
        return torch.gather(data, 1, index)


# trigger 提取器
class TriggerExtractor(BaseModel):
    """
    trigger提取建模
    """
    def __init__(self,
                 bert_dir,
                 dropout_prob=0.1,
                 use_distant_trigger=False,
                 **kwargs):
        """init"""
        super(TriggerExtractor, self).__init__(bert_dir=bert_dir,
                                               dropout_prob=dropout_prob)

        self.use_distant_trigger = use_distant_trigger

        out_dims = self.bert_config.hidden_size

        if use_distant_trigger:
            embedding_dim = kwargs.pop('embedding_dims', 256)
            self.distant_trigger_embedding = nn.Embedding(num_embeddings=2, embedding_dim=embedding_dim)
            out_dims += embedding_dim

        mid_linear_dims = kwargs.pop('mid_linear_dims', 128)

        self.mid_linear = nn.Sequential(
            nn.Linear(out_dims, mid_linear_dims),
            nn.ReLU(),
            nn.Dropout(dropout_prob)
        )

        self.classifier = nn.Linear(mid_linear_dims, 2)

        self.activation = nn.Sigmoid()

        self.criterion = nn.BCELoss()

        init_blocks = [self.mid_linear, self.classifier]

        if use_distant_trigger:
            init_blocks += [self.distant_trigger_embedding]

        self._init_weights(init_blocks, initializer_range=self.bert_config.initializer_range)

    def forward(self,
                token_ids,
                attention_masks,
                token_type_ids,
                distant_trigger=None,
                labels=None):
        """
        前向计算
        """
        bert_outputs = self.bert_module(
            input_ids=token_ids,
            attention_mask=attention_masks,
            token_type_ids=token_type_ids
        )

        seq_out = bert_outputs[0]

        if self.use_distant_trigger:
            assert distant_trigger is not None, \
                'When using distant trigger features, distant trigger should be implemented'

            distant_trigger_feature = self.distant_trigger_embedding(distant_trigger)
            seq_out = torch.cat([seq_out, distant_trigger_feature], dim=-1)

        seq_out = self.mid_linear(seq_out)

        logits = self.activation(self.classifier(seq_out))

        out = (logits,)

        if labels is not None:
            loss = self.criterion(logits, labels.float())
            out = (loss,) + out

        return out


# sub & obj 提取器
class Role1Extractor(BaseModel):
    """
    role提取器
    """
    def __init__(self,
                 bert_dir,
                 dropout_prob=0.1,
                 use_trigger_distance=False,
                 **kwargs):
        """init"""
        super(Role1Extractor, self).__init__(bert_dir=bert_dir,
                                             dropout_prob=dropout_prob)

        out_dims = self.bert_config.hidden_size

        self.use_trigger_distance = use_trigger_distance

        self.conditional_layer_norm = ConditionalLayerNorm(out_dims, eps=self.bert_config.layer_norm_eps)

        if use_trigger_distance:
            embedding_dim = kwargs.pop('embedding_dims', 256)

            self.trigger_distance_embedding = nn.Embedding(num_embeddings=512, embedding_dim=embedding_dim)

            out_dims += embedding_dim

            self.layer_norm = nn.LayerNorm(out_dims, eps=self.bert_config.layer_norm_eps)

        mid_linear_dims = kwargs.pop('mid_linear_dims', 128)

        self.mid_linear = nn.Sequential(
            nn.Linear(out_dims, mid_linear_dims),
            nn.ReLU(),
            nn.Dropout(dropout_prob)
        )
        
        self.obj_desc_classifier = nn.Linear(mid_linear_dims, 2)
        self.obj_classifier = nn.Linear(mid_linear_dims, 2)
        self.sub_desc_classifier = nn.Linear(mid_linear_dims, 2)
        self.sub_classifier = nn.Linear(mid_linear_dims, 2)
        self.reason_classifier = nn.Linear(mid_linear_dims, 2)
        self.result_classifier = nn.Linear(mid_linear_dims, 2)
        self.location_classifier = nn.Linear(mid_linear_dims, 2)
        self.time_classifier = nn.Linear(mid_linear_dims, 2)

        self.activation = nn.Sigmoid()

        self.criterion = nn.BCELoss()

        init_blocks = [self.mid_linear, self.obj_desc_classifier, self.obj_classifier, \
                self.sub_desc_classifier, self.sub_classifier, self.reason_classifier, self.result_classifier, self.location_classifier, self.time_classifier]

        if use_trigger_distance:
            init_blocks += [self.trigger_distance_embedding, self.layer_norm]

        self._init_weights(init_blocks, initializer_range=self.bert_config.initializer_range)

    def forward(self,
                token_ids,
                attention_masks,
                token_type_ids,
                trigger_index,
                trigger_distance=None,
                labels=None):
        """
        前向计算
        """
        bert_outputs = self.bert_module(
            input_ids=token_ids,
            attention_mask=attention_masks,
            token_type_ids=token_type_ids
        )

        seq_out, pooled_out = bert_outputs[0], bert_outputs[1]

        trigger_label_feature = self._batch_gather(seq_out, trigger_index)

        trigger_label_feature = trigger_label_feature.view([trigger_label_feature.size()[0], -1])

        seq_out = self.conditional_layer_norm(seq_out, trigger_label_feature)

        if self.use_trigger_distance:
            assert trigger_distance is not None, \
                'When using trigger distance features, trigger distance should be implemented'

            trigger_distance_feature = self.trigger_distance_embedding(trigger_distance)
            seq_out = torch.cat([seq_out, trigger_distance_feature], dim=-1)
            seq_out = self.layer_norm(seq_out)

        seq_out = self.mid_linear(seq_out)

        obj_desc_logits = self.activation(self.obj_desc_classifier(seq_out))
        obj_logits = self.activation(self.obj_classifier(seq_out))
        sub_desc_logits = self.activation(self.sub_desc_classifier(seq_out))
        sub_logits = self.activation(self.sub_classifier(seq_out))
        reason_logits = self.activation(self.reason_classifier(seq_out))
        result_logits = self.activation(self.result_classifier(seq_out))
        location_logits = self.activation(self.location_classifier(seq_out))
        time_logits = self.activation(self.time_classifier(seq_out))

        logits = torch.cat([sub_desc_logits, sub_logits, obj_desc_logits, obj_logits, reason_logits, result_logits, location_logits, time_logits], dim=-1)
        out = (logits,)

        if labels is not None:
            masks = torch.unsqueeze(attention_masks, -1)

            labels = labels.float()
            sub_desc_loss = self.criterion(sub_desc_logits * masks, labels[:, :, 0:2])
            sub_loss = self.criterion(sub_logits * masks, labels[:, :, 2:4])
            obj_desc_loss = self.criterion(obj_desc_logits * masks, labels[:, :, 4:6])
            obj_loss = self.criterion(obj_logits * masks, labels[:, :, 6:8])
            reason_loss = self.criterion(reason_logits * masks, labels[:, :, 8:10])
            result_loss = self.criterion(result_logits * masks, labels[:, :, 10:12])
            location_loss = self.criterion(location_logits * masks, labels[:, :, 12:14])
            time_loss = self.criterion(time_logits * masks, labels[:, :, 14:])

            loss = sub_desc_loss + sub_loss + obj_desc_loss + obj_loss + reason_loss + result_loss + location_loss + time_loss

            out = (loss,) + out

        return out

def build_model(task_type, bert_dir, **kwargs):
    """build model
    """
    assert task_type in ['trigger', 'role1'], 'task mismatch'

    if task_type == 'trigger':
        model = TriggerExtractor(bert_dir=bert_dir,
                                 dropout_prob=kwargs.pop('dropout_prob', 0.1),
                                 use_distant_trigger=kwargs.pop('use_distant_trigger'))

    elif task_type == 'role1':
        model = Role1Extractor(bert_dir=bert_dir,
                               dropout_prob=kwargs.pop('dropout_prob', 0.1),
                               use_trigger_distance=kwargs.pop('use_trigger_distance'))
    return model
