# !/usr/bin/env python3
# coding=utf-8
"""
@author: Oscar
@license: (C) Copyright 2019-2022, ZJU.
@contact: 499616042@qq.com
@software: pycharm
@file: processor.py
@time: 2020/9/1 10:52
"""
import json
import random
import logging
from tqdm import tqdm
from transformers import BertTokenizer


logger = logging.getLogger(__name__)


__all__ = ['TriggerProcessor', 'RoleProcessor', 'fine_grade_tokenize', 
           'search_label_index', 'convert_examples_to_features', 'covert_trigger_result_to_json']

class BaseExample:
    """base example
    """
    def __init__(self,
                 set_type,
                 text,
                 label=None):
        """初始化
        """
        self.set_type = set_type
        self.text = text
        self.label = label


class TriggerExample(BaseExample):
    """
    trigger example
    """
    def __init__(self,
                 set_type,
                 text,
                 distant_triggers=None,
                 label=None):
        """trigger example init
        """
        super(TriggerExample, self).__init__(set_type=set_type,
                                             text=text,
                                             label=label)
        self.distant_triggers = distant_triggers


class RoleExample(BaseExample):
    """role examle
    """
    def __init__(self,
                 set_type,
                 text,
                 trigger_location,
                 label=None):
        """ role example init 
        """
        super(RoleExample, self).__init__(set_type=set_type,
                                          text=text,
                                          label=label)

        self.trigger_location = trigger_location  # trigger location in the text


class BaseFeature:
    """base feature
    """
    def __init__(self,
                 token_ids,
                 attention_masks,
                 token_type_ids,
                 labels=None):
        """init"""
        self.token_ids = token_ids
        self.attention_masks = attention_masks
        self.token_type_ids = token_type_ids
        self.labels = labels


class TriggerFeature(BaseFeature):
    """trigger feature
    """
    def __init__(self,
                 token_ids,
                 attention_masks,
                 token_type_ids,
                 distant_trigger_label=None,
                 labels=None):
        """init"""
        super(TriggerFeature, self).__init__(token_ids=token_ids,
                                             attention_masks=attention_masks,
                                             token_type_ids=token_type_ids,
                                             labels=labels)
        self.distant_trigger_label = distant_trigger_label


class RoleFeature(BaseFeature):
    """role feature
    """
    def __init__(self,
                 token_ids,
                 attention_masks,
                 token_type_ids,
                 trigger_loc,
                 trigger_distance=None,
                 labels=None):
        """
        attribution detection use two handcrafted feature：
        1、trigger label： 1 for the tokens which are trigger, 0 for not;
        2、trigger distance: the relative distance of other tokens and the trigger tokens
        """
        super(RoleFeature, self).__init__(token_ids=token_ids,
                                          attention_masks=attention_masks,
                                          token_type_ids=token_type_ids,
                                          labels=labels)
        self.trigger_loc = trigger_loc
        self.trigger_distance = trigger_distance


class BaseProcessor:
    """
    数据预处理基类
    """
    @staticmethod
    def read_json(file_path):
        """
        读取json文件
        """
        with open(file_path, encoding='utf-8') as f:
            examples = json.load(f)
        return examples


class TriggerProcessor(BaseProcessor):
    """
    trigger预处理文件
    """
    @staticmethod
    def _example_generator(raw_examples, set_type):
        """
        获取预处理数据
        """
        examples = []
        callback_info = []

        for _ex in raw_examples:
            text = _ex['sentence']
            tmp_triggers = []

            for _event in _ex['events']:
                tmp_triggers.append((_event['trigger']['text'], int(_event['trigger']['offset'])))

            examples.append(TriggerExample(set_type=set_type,
                                           text=text,
                                           label=tmp_triggers,
                                           distant_triggers=_ex['distant_triggers']))

            callback_info.append((text, tmp_triggers, _ex['distant_triggers']))

        if set_type == 'dev':
            return examples, callback_info
        else:
            return examples

    def get_train_examples(self, raw_examples):
        """
        获取训练预处理数据
        """
        return self._example_generator(raw_examples, 'train')

    def get_dev_examples(self, raw_examples):
        """
        获取预测预处理数据
        """
        return self._example_generator(raw_examples, 'dev')


class RoleProcessor(BaseProcessor):
    """role预处理类
    """
    @staticmethod
    def _example_generator(raw_examples, set_type):
        examples = []
        callback_info = []

        type_nums = 0
        type_weight = {'sub_desc': 0,
                       'subject': 0,
                       'obj_desc': 0,
                       'object': 0,
                       'reason': 0,
                       'result': 0,
                       'location': 0,
                       'time': 0}
        
        for _ex in raw_examples:
            text = _ex['sentence']

            for _event in _ex['events']:
                tmp_trigger = _event['trigger']

                # 加 1 是为了 CLS 偏置，保证 trigger loc 与真实的对应
                tmp_trigger_start = tmp_trigger['offset'] + 1
                tmp_trigger_end = tmp_trigger['offset'] + len(tmp_trigger['text'])

                examples.append(RoleExample(set_type=set_type,
                                            text=text,
                                            trigger_location=[tmp_trigger_start, tmp_trigger_end],
                                            label=_event['arguments']))
                gt_labels = {'sub_desc': [],
                             'subject': [],
                             'obj_desc': [],
                             'object': [],
                             'reason': [],
                             'result': [],
                             'location': [],
                             'time': []}
                
                for _role in _event['arguments']:
                    gt_labels[_role['role']].append((_role['text'], _role['offset']))

                    type_nums += 1
                    type_weight[_role['role']] += 1

                callback_info.append((text, tmp_trigger['text'], gt_labels))

        for key in type_weight.keys():
            type_weight[key] /= (type_nums + 5e-5)

        if set_type == 'dev':
            return examples, (callback_info, type_weight)
        else:
            return examples

    def get_train_examples(self, raw_examples):
        return self._example_generator(raw_examples, 'train')

    def get_dev_examples(self, raw_examples):
        return self._example_generator(raw_examples, 'dev')


def search_label_index(tokens, label_tokens):
    """
    search label token indexes in all tokens
    """
    index_list = []  # 存放搜到的所有的index

    # 滑动窗口搜索 labels 在 token 中的位置
    for index in range(len(tokens) - len(label_tokens) + 1):
        if tokens[index: index + len(label_tokens)] == label_tokens:
            start_index = index
            end_index = start_index + len(label_tokens) - 1
            index_list.append((start_index, end_index))

    return index_list


def fine_grade_tokenize(raw_text, tokenizer):
    """
    序列标注任务 BERT 分词器可能会导致标注偏移, 用 char-level 来 tokenize
    """
    tokens = []

    for _ch in raw_text:
        if _ch in [' ', '\t', '\n']:
            tokens.append('[BLANK]')
        else:
            if not len(tokenizer.tokenize(_ch)):
                tokens.append('[INV]')
            else:
                tokens.append(_ch)

    return tokens


def convert_trigger_example(ex_idx, example: TriggerExample, max_seq_len, tokenizer: BertTokenizer):
    """
    转换trigger样本
    """
    set_type = example.set_type
    raw_text = example.text
    raw_label = example.label
    distant_triggers = example.distant_triggers

    tokens = fine_grade_tokenize(raw_text, tokenizer)

    labels = [[0] * 2 for i in range(len(tokens))]  # start / end

    distant_trigger_label = [0] * len(tokens)

    # tag labels
    for _label in raw_label:
        tmp_start = _label[1]
        tmp_end = _label[1] + len(_label[0]) - 1
        if (tmp_start < 0) or (tmp_end < 0):
            continue
        labels[tmp_start][0] = 1
        labels[tmp_end][1] = 1

    # tag distant triggers
    for _trigger in distant_triggers:
        tmp_trigger_tokens = fine_grade_tokenize(_trigger, tokenizer)
        tmp_index_list = search_label_index(tokens, tmp_trigger_tokens)

        assert len(tmp_index_list)

        for _index in tmp_index_list:
            for i in range(_index[0], _index[1] + 1):
                distant_trigger_label[i] = 1

    if len(labels) > max_seq_len - 2:
        labels = labels[:max_seq_len - 2]
        distant_trigger_label = distant_trigger_label[:max_seq_len - 2]

    pad_labels = [[0] * 2]
    labels = pad_labels + labels + pad_labels

    distant_trigger_label = [0] + distant_trigger_label + [0]

    if len(labels) < max_seq_len:
        pad_length = max_seq_len - len(labels)

        labels = labels + pad_labels * pad_length
        distant_trigger_label = distant_trigger_label + [0] * pad_length

    assert len(labels) == max_seq_len
    assert len(distant_trigger_label) == max_seq_len

    encode_dict = tokenizer.encode_plus(text=tokens,
                                        max_length=max_seq_len,
                                        pad_to_max_length=True,
                                        is_pretokenized=True,
                                        return_token_type_ids=True,
                                        return_attention_mask=True)

    token_ids = encode_dict['input_ids']
    attention_masks = encode_dict['attention_mask']
    token_type_ids = encode_dict['token_type_ids']

    if ex_idx < 3 and set_type == 'train':
        logger.info(f"*** {set_type}_example-{ex_idx} ***")
        logger.info(f'text: {" ".join(tokens)}')
        logger.info(f"token_ids: {token_ids}")
        logger.info(f"attention_masks: {attention_masks}")
        logger.info(f"token_type_ids: {token_type_ids}")
        logger.info(f'distant trigger: {distant_trigger_label}')

    feature = TriggerFeature(token_ids=token_ids,
                             attention_masks=attention_masks,
                             token_type_ids=token_type_ids,
                             distant_trigger_label=distant_trigger_label,
                             labels=labels)

    return feature


def convert_role1_example(ex_idx, example: RoleExample, max_seq_len, tokenizer: BertTokenizer):
    """
    convert role examples to sub & obj features
    """
    set_type = example.set_type
    raw_text = example.text
    raw_label = example.label
    trigger_loc = example.trigger_location

    if set_type == 'train' and trigger_loc[0] > max_seq_len:
        logger.info('Skip this example where the tag is longer than max sequence length')
        return None

    tokens = fine_grade_tokenize(raw_text, tokenizer)

    labels = [[0] * 16 for i in range(len(tokens))]  # sub / obj

    # sub / obj 为空时丢弃该 example
    role_type = ["sub_desc", "subject", "obj_desc", "object", "reason", "result", "location", "time"]

    # tag labels
    for role in raw_label:
        if role['role'] in ["type"]:
            continue
        index = role_type.index(role['role'])
        role_type_idx = index * 2

        role_start = role['offset']
        role_end = role_start + len(role['text']) - 1

        labels[role_start][role_type_idx] = 1  # start 位置标注为 1
        labels[role_end][role_type_idx + 1] = 1  # end 位置标注为 1


    if len(labels) > max_seq_len - 2:
        labels = labels[:max_seq_len - 2]

    pad_labels = [[0] * 16]
    labels = pad_labels + labels + pad_labels

    if len(labels) < max_seq_len:
        pad_length = max_seq_len - len(labels)
        labels = labels + pad_labels * pad_length

    # build trigger distance features
    trigger_distance = [511] * max_seq_len
    for i in range(max_seq_len):
        if trigger_loc[0] <= i <= trigger_loc[1]:
            trigger_distance[i] = 0
            continue
        elif i < trigger_loc[0]:
            trigger_distance[i] = trigger_loc[0] - i
        else:
            trigger_distance[i] = i - trigger_loc[1]
    
    assert len(labels) == max_seq_len

    encode_dict = tokenizer.encode_plus(text=tokens,
                                        max_length=max_seq_len,
                                        pad_to_max_length=True,
                                        is_pretokenized=True,
                                        return_token_type_ids=True,
                                        return_attention_mask=True)

    token_ids = encode_dict['input_ids']
    attention_masks = encode_dict['attention_mask']
    token_type_ids = encode_dict['token_type_ids']

    for i in range(trigger_loc[0], trigger_loc[1] + 1):
        token_type_ids[i] = 1

    if ex_idx < 3 and set_type == 'train':
        logger.info(f"*** {set_type}_example-{ex_idx} ***")
        logger.info(f'text: {" ".join(tokens)}')
        logger.info(f"token_ids: {token_ids}")
        logger.info(f"attention_masks: {attention_masks}")
        logger.info(f"token_type_ids: {token_type_ids}")
        logger.info(f'trigger location: {trigger_loc}')

    feature = RoleFeature(token_ids=token_ids,
                          attention_masks=attention_masks,
                          token_type_ids=token_type_ids,
                          trigger_loc=trigger_loc,
                          trigger_distance=trigger_distance,
                          labels=labels)

    return feature


def convert_examples_to_features(task_type, examples, bert_dir, max_seq_len, **kwargs):
    """
    将样本转换为feature格式
    """
    assert task_type in ['trigger', 'role1']

    tokenizer = BertTokenizer.from_pretrained(bert_dir)
    logger.info(f'Vocab nums in this tokenizer is: {tokenizer.vocab_size}')

    features = []

    for i, example in enumerate(tqdm(examples, desc=f'convert examples')):
        if task_type == 'trigger':

            feature = convert_trigger_example(
                ex_idx=i,
                example=example,
                max_seq_len=max_seq_len,
                tokenizer=tokenizer,
            )

        elif task_type == 'role1':
            feature = convert_role1_example(
                ex_idx=i,
                example=example,
                max_seq_len=max_seq_len,
                tokenizer=tokenizer
            )

        if feature is None:
            continue
        features.append(feature)

    return features

def covert_trigger_result_to_json(dev_info, all_entities, all_logits, w_file):
    """
    转换trigger结果为json格式
    """
    ret = []
    for index, info in enumerate(dev_info):
        text, gt_triggers, distant_triggers = info
        entities = all_entities[index]
        logits = all_logits[index]
        if len(entities) == 0:
            continue
        d = {}
        d["sentence"] = text
        d["events"] = []
        d["distant_triggers"] = []
        for item in entities:
            tmp_dict = {"trigger": {}, "tense": "", "polarity": "", "arguments": [] }
            length = len(item[0])
            offset = text.find(item[0])
            tmp_dict["trigger"]["text"] = item[0]
            tmp_dict["trigger"]["length"] = length
            tmp_dict["trigger"]["offset"] = offset
            d["events"].append(tmp_dict)
        ret.append(d)
    js = json.dumps(ret, ensure_ascii=False, indent=4)
    w_file.write(js)

