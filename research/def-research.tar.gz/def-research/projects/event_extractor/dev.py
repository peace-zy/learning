# !/usr/bin/env python3
# coding=utf-8
"""
Author: changxiaojing@baidu.com
Date: 2021/11/10
"""

import os
import logging
from torch.utils.data import DataLoader
from src.processor import *
from src.options import DevArgs
from src.model_utils import build_model
from src.dataset_utils import build_dataset
from src.evaluator import trigger_evaluation, role1_evaluation
from src.functions_utils import load_model_and_parallel, prepare_para_dict

logger = logging.getLogger(__name__)
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s -   %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO
)


def evaluate(opt):
    """
    模型评估
    """
    processors = {'trigger': TriggerProcessor,
                  'role1': RoleProcessor}

    processor = processors[opt.task_type]()
    feature_para, dataset_para, model_para = prepare_para_dict(opt)
    dev_raw_examples = processor.read_json(opt.raw_data_dir)
    dev_examples, dev_callback_info = processor.get_dev_examples(dev_raw_examples)
    dev_features = convert_examples_to_features(opt.task_type, dev_examples, opt.bert_dir,
                                                opt.max_seq_len, **feature_para)

    logger.info(f'Build {len(dev_features)} dev features')
    dev_dataset = build_dataset(opt.task_type, dev_features,
                                mode='dev', **dataset_para)
    dev_loader = DataLoader(dev_dataset, batch_size=opt.eval_batch_size,
                            shuffle=False, num_workers=8)
    dev_info = (dev_loader, dev_callback_info)

    model = build_model(opt.task_type, opt.bert_dir, **model_para)

    all_entities = []
    all_logits = []

    all_sub_desc_entities, all_sub_entities, all_obj_desc_entities, all_obj_entities = [], [], [], []

    model_path = opt.model_path
    model, device = load_model_and_parallel(model, opt.gpu_ids[0],
                                                ckpt_path=model_path)
    if opt.task_type == 'trigger':

        result = trigger_evaluation(model, dev_info, device,
                                                        start_threshold=opt.start_threshold,
                                                        end_threshold=opt.end_threshold)
        all_entities = result["all_entities"]
        all_logits = result["pred_logits"]

    elif opt.task_type == 'role1':
        result = role1_evaluation(model, dev_info, device,
                                                        start_threshold=opt.start_threshold,
                                                        end_threshold=opt.end_threshold)
        all_sub_desc_entities = result["sub_desc"]
        all_sub_entities = result["sub"]
        all_obj_desc_entities = result["obj_desc"]
        all_obj_entities = result["obj"]
        all_reason_entities = result["reason"]
        all_result_entities = result["result"]
        all_location_entities = result["location"]
        all_time_entities = result["time"]

    eval_save_path = os.path.join(opt.dev_dir)

    with open(eval_save_path, 'w', encoding='utf-8') as f1:
        if opt.task_type == "trigger":
            covert_trigger_result_to_json(dev_info[1], all_entities, all_logits, f1)

        elif opt.task_type == 'role1':
            for index, item in enumerate(dev_info[1][0]):
                text, gt_triggers, distant_triggers = item
                join_sub_desc = "||".join([i[0] for i in all_sub_desc_entities[index]])
                join_sub = "||".join([i[0] for i in all_sub_entities[index]])
                join_obj_desc = "||".join([i[0] for i in all_obj_desc_entities[index]])
                join_obj = "||".join([i[0] for i in all_obj_entities[index]])
                join_reason = "||".join([i[0] for i in all_reason_entities[index]])
                join_result = "||".join([i[0] for i in all_result_entities[index]])
                join_location = "||".join([i[0] for i in all_location_entities[index]])
                join_time = "||".join([i[0] for i in all_time_entities[index]])

                w = text + "\t" + join_sub_desc + "\t" + join_sub + "\t" + gt_triggers + "\t" + join_obj_desc + "\t" + join_obj \
                        + "\t" + join_reason + "\t" + join_result + "\t" + join_location + "\t" + join_time + "\n"
                f1.write(w)


if __name__ == '__main__':
    args = DevArgs().get_parser()

    dev_dir = args.dev_dir

    if '_distant_trigger' in dev_dir:
        args.use_distant_trigger = True

    if '_distance' in dev_dir:
        args.use_trigger_distance = True

    evaluate(args)
