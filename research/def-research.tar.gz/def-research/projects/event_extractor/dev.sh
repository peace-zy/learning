#!/usr/bin/env bash

export BERT_TYPE="roberta_wwm"  # roberta_wwm / ernie_1  / uer_large
export BERT_DIR="./model/chinese-roberta-wwm-ext"
export TASK_TYPE="role1"
export MODE="dev"
export GPU_IDS="1"

python dev.py \
--gpu_ids=$GPU_IDS \
--mode=$MODE \
--raw_data_dir="./data/trigger_predict.json" \
--bert_dir=$BERT_DIR \
--bert_type=$BERT_TYPE \
--task_type=$TASK_TYPE \
--eval_batch_size=256 \
--max_seq_len=250 \
--start_threshold=0.3 \
--end_threshold=0.3 \
--dev_dir="./data/${TASK_TYPE}_predict.json" \
--model_path="./out/role1_distance_pgd/checkpoint-100000/model.pt" \
--use_trigger_distance
