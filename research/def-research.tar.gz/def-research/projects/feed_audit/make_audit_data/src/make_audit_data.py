#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   make_audit_data.py
Author:   zhanghao55@baidu.com
Date  :   21/04/15 18:09:16
Desc  :   
"""

import os
import sys
import codecs
import copy
import json
import logging
import numpy as np
import random
import time

from collections import defaultdict
from heapq import heappush, heappop
from sklearn.cluster import MiniBatchKMeans
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import calinski_harabasz_score
from sklearn.metrics.pairwise import cosine_similarity

from run_arguments import parse_args
from utils import AuditData

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.data_io import dump_pkl, get_data, load_pkl
from lib.common.logger import init_log

init_log()


def kmeans(
        vec_list,
        text_list,
        info_list,
        load_cluster_model,
        cluster_res_path,
        cluster_model_path,
        sorted_cluster_res_path=None,
        k=1000,
        batch_size=None,
        seed=1,
        ):
    if load_cluster_model:
        model = load_pkl(cluster_model_path)
        y_pre = model.predict(vec_list)
    else:
        logging.info("cluster start...")
        start_time = time.time()
        if batch_size is None:
            batch_size = 10 * k
        # batch_size����������Mini Batch KMeans�㷨�Ĳ������Ĵ�С��Ĭ����100.����������ݼ������϶����������϶࣬��Ҫ�������ֵ�Դﵽ�Ϻõľ���Ч����
        model = MiniBatchKMeans(n_clusters=k, batch_size=batch_size, random_state=seed)
        y_pre = model.fit_predict(vec_list)
        score = calinski_harabasz_score(vec_list, y_pre)
        logging.info("cluster score: {:.4f}".format(score))
        logging.info("cost time: {:.4f}s".format(time.time() - start_time))

        # ����ģ��
        dump_pkl(model, cluster_model_path, True)

    # ���������
    cluster_res_list = list(zip(text_list, y_pre, info_list))
    with codecs.open(cluster_res_path, "w", "gb18030") as wf:
        for text, cluter_id, info in cluster_res_list:
            wf.write("{}\t{}\t{}\n".format(cluter_id, text, info))

    # ���������ľ�����
    with codecs.open(sorted_cluster_res_path, "w", "gb18030") as wf:
        for text, cluter_id, info in sorted(cluster_res_list, key=lambda x:x[1]):
            wf.write("{}\t{}\t{}\n".format(cluter_id, text, info))

    return y_pre


def load_vec_file(data_path, max_num, encoding):
    """���������ļ�
    """
    def get_vec(line):
        """��ȡ�����ļ�ÿ������
        """
        obj = json.loads(line.strip("\n"))
        return obj["text"], obj["vec"]

    logging.info("load_vec_file begin...")
    start_time = time.time()
    text_list = list()
    vec_list = list()
    for cur_text, cur_vec in get_data(data_path, read_func=get_vec, encoding=encoding):
        if max_num is not None and max_num <= len(text_list):
            break
        vec_list.append(cur_vec)
        text_list.append(cur_text)
    logging.info("load_vec_file end, cost time: {:.4f}s".format(time.time() - start_time))
    return text_list, vec_list


def load_audit_file(data_path, max_num, encoding):
    """���������ļ�
    """
    def get_audit_res(line):
        """���������ļ�ÿ������
        """
        parts = line.strip("\n").split("\t")
        text = parts[1]
        reason_list = [x for x in parts[-1].split("\x01") if len(x) > 0]
        info = "\t".join(parts[2:-1])
        if len(reason_list) == 0:
            reason_list = ["�޷���"]
        return text, reason_list, info
        #return parts[1], [x for x in parts[-1].split("\x01") if len(x) > 0]

    logging.info("load_audit_file begin...")
    start_time = time.time()
    text_list = list()
    audit_lists = list()
    info_list = list()
    for cur_text, cur_audit_list, cur_info in get_data(data_path, read_func=get_audit_res, encoding=encoding):
        if max_num is not None and max_num <= len(text_list):
            break
        text_list.append(cur_text)
        audit_lists.append(cur_audit_list)
        info_list.append(cur_info)
    logging.info("load_audit_file end, cost time: {:.4f}s".format(time.time() - start_time))
    return text_list, audit_lists, info_list


def make_audit_data(config):
    """���ɴ�������
    """
    # ���������ļ�
    vec_text_list, vec_list = load_vec_file(config.vec_path, config.max_num, config.encoding)
    # ���������ļ�
    audit_text_list, audit_lists, info_list = load_audit_file(config.audit_path, config.max_num, config.encoding)

    for index, (cur_vec_text, cur_audit_text) in enumerate(zip(vec_text_list, audit_text_list)):
        assert cur_vec_text == cur_audit_text, "text not equal at line #{}".format(index + 1)

    # ����õ����
    cluster_id_list = kmeans(
            vec_list,
            vec_text_list,
            info_list,
            config.load_cluster_model,
            config.cluster_res_path,
            config.cluster_model_path,
            sorted_cluster_res_path=config.sorted_cluster_res_path,
            k=config.k,
            )

    with codecs.open(config.audit_data_path, "w", config.encoding) as wf:
        for index, (cur_text, cur_audit_list, cur_cluster_id) in \
                enumerate(zip(audit_text_list, audit_lists, cluster_id_list)):
            audit_data = AuditData(
                    value=cur_text,
                    label_list=[int(cur_cluster_id)],
                    risk_list=cur_audit_list,
                    )
            wf.write(audit_data.to_json() + "\n")

    with codecs.open(config.plain_text_path, "w", config.encoding) as wf:
        for index, (cur_text, cur_audit_list, cur_cluster_id, cur_info) in \
                enumerate(zip(audit_text_list, audit_lists, cluster_id_list, info_list)):
            wf.write("\t".join([
                cur_text,
                str(cur_cluster_id),
                "|||".join(cur_audit_list),
                cur_info,
                ]) + "\n")


def load_audit_data(audit_data_path, encoding):
    """���ش�������
    """
    def process_line(line):
        """�д���
        """
        audit_data = AuditData.init_from_json(line.strip("\n"))
        return audit_data

    audit_data_list = list()
    for cur_audit_data in get_data(audit_data_path, read_func=process_line, encoding=encoding):
        audit_data_list.append(cur_audit_data)

    return audit_data_list


def stat_audit_data(config):
    """ͳ�ƴ�������
    """
    audit_data_list = load_audit_data(config.audit_data_path, config.encoding)

    total_risk_count = 0
    risk_count = defaultdict(int)
    label_count = defaultdict(int)
    risk_label_count = defaultdict(lambda: defaultdict(int))
    label_risk_count = defaultdict(lambda: defaultdict(int))
    for audit_data in audit_data_list:
        assert len(audit_data.label_list) == 1
        #assert len(audit_data.risk_list) <= 1
        cur_label = audit_data.label_list[0]

        label_count[cur_label] += 1
        #if len(audit_data.risk_list) == 0:
        #    continue
        for cur_risk in audit_data.risk_list:
            #cur_risk = "�޷���" if len(audit_data.risk_list) == 0 else audit_data.risk_list[0]
            total_risk_count += 1
            #logging.info("cur_label: {}".format(cur_label))
            #logging.info("cur_risk: {}".format(cur_risk))
            risk_label_count[cur_risk][cur_label] += 1
            label_risk_count[cur_label][cur_risk] += 1
            risk_count[cur_risk] += 1

    with codecs.open(config.stat_res_path, "w", config.encoding) as wf:
        wf.write("risk_label_count:\n")
        for risk, cur_label_count in risk_label_count.items():
            wf.write("risk: {}, total: {}\n".format(risk, risk_count[risk]))
            cur_risk_count = risk_count[risk]
            for label, count in sorted(cur_label_count.items(), key=lambda x:x[1], reverse=True):
                wf.write("label: {}, count: {}, ratio: {:.2f}%\n".format(
                    label,
                    count,
                    (count * 100 / float(cur_risk_count)),
                    ))
            wf.write("=" * 100 + "\n")

        wf.write("label_risk_count:\n")
        for label, cur_risk_count in label_risk_count.items():
            wf.write("label: {}, total: {}\n".format(label, label_count[label]))
            cur_label_count = label_count[label]
            for risk, count in sorted(cur_risk_count.items(), key=lambda x:x[1], reverse=True):
                wf.write("risk: {}, count: {}, ratio: {:.2f}%\n".format(
                    risk,
                    count,
                    (count * 100 / float(cur_label_count)),
                    ))
            wf.write("=" * 100 + "\n")

        wf.write("total risk count: {}\n".format(total_risk_count))


def main():
    """�����
    """
    config = parse_args()
    logging.info(config)

    task = config.task
    if task == "make":
        make_audit_data(config)
    elif task == "stat":
        stat_audit_data(config)
    else:
        raise ValueError("unkown task: {}".format(task))


if __name__ == "__main__":
    main()
