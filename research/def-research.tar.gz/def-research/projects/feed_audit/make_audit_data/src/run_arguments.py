#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   run_arguments.py
Author:   zhanghao55@baidu.com
Date  :   21/04/14 11:19:18
Desc  :   
"""

import os
import sys
import argparse


def parse_args(args=None):
    parser = argparse.ArgumentParser(description = "audit experiment run args")

    # ==================================== default =======================================
    default_group = parser.add_argument_group('default')
    default_group.add_argument("--output_dir", default = "output", help = "���Ŀ¼")

    # =================================== run config =====================================
    run_group = parser.add_argument_group('run_config')
    # ��������
    run_group.add_argument("--task",
            choices = [
                "make",
                "stat"
                ], help = "��������")
    run_group.add_argument("--uniqid", default = "default", help = "��ǰ�����ʶ")

    # ================================== cluster config =====================================
    cluster_group = parser.add_argument_group('cluster_config')
    cluster_group.add_argument("--load_cluster_model", action="store_true", help = "kmeans������")
    cluster_group.add_argument("--k", type = int, default=2000, help = "kmeans������")

    # ================================== data config =====================================
    data_group = parser.add_argument_group('data_config')
    data_group.add_argument("--vec_path", help = "�ı������ļ�λ��")
    data_group.add_argument("--audit_path", help = "�������ļ�λ��")
    data_group.add_argument("--reason_dict_path", help = "����ӳ��")
    data_group.add_argument("--max_num", type = int, default = None, help = "�����������ֵ")
    #data_group.add_argument("--random_seed", type = int, default = 1, help = "�������")
    #data_group.add_argument("--shuffle", action="store_true", help = "���������Ƿ��������")
    #data_group.add_argument("--example_num", type = int, default = 5, help = "չʾ�����ĸ���")
    data_group.add_argument("--encoding", default = "gb18030", help = "���������ļ��ı���")

    # ================================== config end ======================================

    # ��������
    pargs_res = parser.parse_args() if args is None else  parser.parse_args(args)

    # ������λ��
    pargs_res.cluster_res_path = os.path.join(pargs_res.output_dir, "cluster_res_{}.txt".format(pargs_res.uniqid))
    pargs_res.sorted_cluster_res_path = os.path.join(pargs_res.output_dir, "sorted_cluster_res_{}.txt".format(pargs_res.uniqid))
    pargs_res.cluster_model_path = os.path.join(pargs_res.output_dir, "cluster_model_{}.pkl".format(pargs_res.uniqid))
    pargs_res.audit_data_path = os.path.join(pargs_res.output_dir, "audit_data_{}.txt".format(pargs_res.uniqid))
    pargs_res.plain_text_path = os.path.join(pargs_res.output_dir, "plain_text_{}.txt".format(pargs_res.uniqid))
    pargs_res.stat_res_path = os.path.join(pargs_res.output_dir, "stat_res_{}.txt".format(pargs_res.uniqid))

    return pargs_res

if __name__ == "__main__":
    args = parse_args()
    print(args)


