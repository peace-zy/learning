#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   utils.py
Author:   zhanghao55@baidu.com
Date  :   21/04/14 17:01:23
Desc  :   
"""

import copy
import json
import logging
import numpy as np
import numpy.ma as ma
import random
import uuid
from collections import defaultdict
from collections import Counter
from sklearn.metrics import pairwise_distances
from sklearn.cluster import AgglomerativeClustering


class CustomizedForJson(object):
    """���Ա�json dumps loads�Ļ�����
    """
    @classmethod
    def init_from_json(cls, init_json):
        """��json�ַ�����ʼ��
        """
        # ��Ϊֱ�Ӵ�json����ʼ�� �����������ֱ����json.loads�õ����ֵ������Ҫcopy
        return cls.init_from_dict(json.loads(init_json), zero_copy=True)

    @classmethod
    def init_from_dict(cls, init_dict, zero_copy=True):
        """��dict��ʼ��
        [in]  init_dict��dict����ʼ���ֵ�
              zero_copy��bool���Ƿ���audit_data_dict�и�ֵͬ������
           ��zero_copyΪTrue������init_dict�������ݹ����ڴ�
           �����ط���init_dict�е����ݽ����޸�ʱ��Ҳ��Ӱ�쵽���������������
        """
        if not zero_copy:
            init_dict = {k: copy.deepcopy(v) for k, v in init_dict.items()}
        return cls(**init_dict)

    def to_dict(self):
        """ת�ֵ�
        """
        return vars(self)

    def to_json(self):
        """תjson
        """
        return json.dumps(self.to_dict())

    def __repr__(self):
        return self.to_str(sep="\n")

    def to_str(self, sep="\t"):
        """תΪstr
        """
        raise NotImplementedError


def record_matrix_expand(tar_matrix, row_size=None, col_size=None, mask_matrix=False):
    """��Ŀ�����ά����չ��ָ����С
    """
    if tar_matrix is None:
        tar_matrix = np.zeros((0, 0))
        if mask_matrix:
            tar_matrix = ma.array(tar_matrix, mask=False)

    if row_size is not None:
        row_diff = row_size - tar_matrix.shape[0]
        if row_diff > 0:
            if mask_matrix:
                tar_matrix = ma.row_stack((
                    tar_matrix,
                    ma.array(np.zeros((row_diff, tar_matrix.shape[1])), mask=False),
                    ))
            else:
                tar_matrix = np.row_stack((
                    tar_matrix,
                    np.zeros((row_diff, tar_matrix.shape[1])),
                    ))

    if col_size is not None:
        col_diff = col_size - tar_matrix.shape[1]
        if col_diff > 0:
            if mask_matrix:
                tar_matrix = ma.column_stack((
                    tar_matrix,
                    ma.array(np.zeros((tar_matrix.shape[0], col_diff)), mask=False),
                    ))
            else:
                tar_matrix = np.column_stack((
                    tar_matrix,
                    np.zeros((tar_matrix.shape[0], col_diff)),
                    ))
    return tar_matrix


def update_record(id_list, id_size, high_sim_matrix=None):
    """���ݵ�ǰ���� ���¸������ͳ�ƾ�����Ϣ
    """
    # ��ʼ��ʱ�͸�������������
    cur_record = np.zeros((id_size))

    # ���ݵ�ǰ���ݵ�label ���Ӽ���
    for cur_id in id_list:
        if high_sim_matrix is None:
            cur_record[cur_id] += 1
        else:
            cur_record += high_sim_matrix[cur_id]

    return cur_record


class TaskV2(CustomizedForJson):
    """����
    """
    def __init__(self,
            uid=None,
            userid=None,
            audit_data_id_list=None,
            earliest_in_time=None,
            chosen_info=None,
            label_id_dict=None,
            risk_id_dict=None,
            text_high_sim_matrix=None,
            image_high_sim_matrix=None,
            ):
        super(TaskV2, self).__init__()
        self.uid = str(uuid.uuid1()) if uid is None else uid
        self.userid = userid
        self.audit_data_id_list = list() if audit_data_id_list is None else audit_data_id_list
        self.label_id_dict = label_id_dict
        self.risk_id_dict = risk_id_dict
        self.text_high_sim_matrix = text_high_sim_matrix
        self.image_high_sim_matrix = image_high_sim_matrix

        self.text_cluster_count = np.zeros((1, text_high_sim_matrix.shape[1]))
        self.image_cluster_count = np.zeros((1, image_high_sim_matrix.shape[1]))
        self.label_count = np.zeros((1, len(label_id_dict)))
        self.risk_count = np.zeros((1, len(risk_id_dict)))

        self.text_cluster_record_list = list()
        self.image_cluster_record_list = list()
        self.label_record_list = list()
        self.risk_record_list = list()
        self.text_image_count_record_list = list()

        self.earliest_in_time = earliest_in_time
        self.chosen_info = "" if chosen_info is None else chosen_info
        self.text_count = 0
        self.image_count = 0

    def to_str(self, sep="\t"):
        return sep.join([
            "uid: {}".format(self.uid),
            "userid: {}".format(self.userid),
            "audit_data_id_list: {}".format(self.audit_data_id_list),
            "text_cluster_record: {}".format(self.text_cluster_record),
            "image_cluster_record: {}".format(self.image_cluster_record),
            "label_record: {}".format(self.label_record),
            "risk_record: {}".format(self.risk_record),
            "earliest_in_time: {}".format(self.earliest_in_time),
            "chosen_info: {}".format(self.chosen_info),
            "text_count: {}".format(self.text_count),
            "image_count: {}".format(self.image_count),
            ])

    def add_audit_data(self, audit_data, with_high_sim=True):
        """�������������Ϣ
        """
        #logging.info("text_high_sim_matrix shape: {}".format(text_high_sim_matrix.shape))
        self.audit_data_id_list.append(audit_data.uid)
        audit_data.task_uid = self.uid

        def add_record(id_list, tar_count=None, tar_record_list=None, high_sim_matrix=None):
            """���ݵ�ǰ���� ���¸������ͳ�ƾ�����Ϣ
            """
            if with_high_sim:
                increasement_record = update_record(id_list, tar_count.shape[1], high_sim_matrix)
            else:
                increasement_record = update_record(id_list, tar_count.shape[1])

            if tar_count is not None:
                tar_count[0] += increasement_record

            if tar_record_list is not None:
                tar_record_list.append(increasement_record.reshape((1, -1)))

        # ��¼label��Ϣ
        if self.label_id_dict is not None:
            label_id_list = [self.label_id_dict[x] for x in audit_data.label_list]
            add_record(label_id_list, self.label_count, self.label_record_list)

        # ��¼risk��Ϣ
        if self.risk_id_dict is not None:
            risk_id_list = [self.risk_id_dict[x] for x in audit_data.risk_list]
            add_record(risk_id_list, self.risk_count, self.risk_record_list)

        # ��¼text_cluster��Ϣ
        add_record(
                audit_data.text_clusters,
                self.text_cluster_count,
                self.text_cluster_record_list,
                self.text_high_sim_matrix,
                )
        self.text_count += len(audit_data.text_clusters)

        # ��¼image_cluster��Ϣ
        add_record(
                audit_data.image_clusters,
                self.image_cluster_count,
                self.image_cluster_record_list,
                self.image_high_sim_matrix,
                )
        self.image_count += len(audit_data.image_clusters)

        self.text_image_count_record_list.append(
                np.array([[len(audit_data.text_clusters), len(audit_data.image_clusters)]]))

        if self.earliest_in_time is None or audit_data.in_time < self.earliest_in_time:
            self.earliest_in_time = audit_data.in_time

    def sim_sort(self):
        """�������µ����ϸ������Ƴ̶Ƚ��оۺ�����
        """
        # ���ݸ��������� �������¶��������Ͼۺ�
        def cal_distance(record_list):
            """���������ָ��ά�ȵ����Ҿ���
            """
            try:
                record_distance = pairwise_distances(np.concatenate(record_list, axis=0), metric="cosine")
            except ValueError as e:
                logging.warning(e)
                # ʧ����������ȫΪ0
                record_distance = np.zeros((len(self.audit_data_id_list), len(self.audit_data_id_list)))
            return record_distance

        def combine(children_list):
            """�ϲ������ĸ�����
            """
            # ��Ϊ�����ǲ�ξ������� �����ڸ��ڵ����һ��С��������ľ���
            # ���Ժϲ��������ڵ�ʱ ���ﲻ��Ҫ�������������ڵ������������
            # Ϊ��Ӧ���ϰ�� ���ڵ�������������ǰ��
            res_list = list()
            for cur_children in sorted(children_list, key=lambda x:len(x), reverse=True):
                res_list.extend(cur_children)
            return res_list

        def sort_children(children_list, leaf_num):
            """���ݲ�ξ�����Ϊ��������
            """
            tree_dict = dict()
            # Ҷ�ӽڵ�
            for cur_ind in range(leaf_num):
                tree_dict[cur_ind] = [cur_ind]
            # �ۺ�
            for cur_ind, cur_children in enumerate(children_list):
                #print("tree_dict: {}".format(tree_dict))
                cur_id = leaf_num + cur_ind
                #print("cur_id: {}".format(cur_ind))
                #print("cur_children: {}".format(cur_children))
                #print("="*100)
                cur_list = list()
                for cur_child in cur_children:
                    cur_list.append(tree_dict[cur_child])
                    del tree_dict[cur_child]
                tree_dict[cur_id] = combine(cur_list)
            assert len(tree_dict) == 1, "tree_dict size = {}: {}".format(len(tree_dict), tree_dict)
            return combine(tree_dict.values())

        if len(self.audit_data_id_list) > 2:
            # TODO ��ǰ������ ʵ��label��һ�� û��Ҫ���������ƾ��� ����ǰЧ��û��Ӱ�� ��˱���
            label_distance = cal_distance(self.label_record_list)
            #logging.info("label_distance: {}".format(label_distance))
            risk_distance = cal_distance(self.risk_record_list)
            #logging.info("risk_distance: {}".format(risk_distance))
            text_cluster_distance = cal_distance(self.text_cluster_record_list)
            #logging.info("text_cluster_distance: {}".format(text_cluster_distance))
            image_cluster_distance = cal_distance(self.image_cluster_record_list)
            #logging.info("image_cluster_distance: {}".format(image_cluster_distance))
            # ��¼�����ϵ��ı���ͼƬ�� ��ǰ���������ִ��ı��ʹ�ͼƬ����Ч�� �����ı���ͼƬ�Ļ���Ҫ����
            text_image_count_distance = cal_distance(self.text_image_count_record_list)
            #logging.info("text_image_count_distance: {}".format(text_image_count_distance))

            # TODO ��ǰ�趨���������Ȩ��һ�� ֮�������Ҫ����
            distance_matrix = (text_image_count_distance + label_distance + risk_distance + \
                    text_cluster_distance + image_cluster_distance) / 5.0
            #logging.info("distance_matrix: {}".format(distance_matrix))
            #logging.info("distance_matrix shape: {}".format(distance_matrix.shape))

            model = AgglomerativeClustering(affinity="precomputed", linkage="complete")
            model.fit(distance_matrix)
            sort_ind = sort_children(model.children_, leaf_num=distance_matrix.shape[0])
            sorted_audit_data_id_list = [self.audit_data_id_list[x] for x in sort_ind]
        else:
            sorted_audit_data_id_list = self.audit_data_id_list

        return sorted_audit_data_id_list

    def __eq__(self, other):
        """ȷ������ά������ȫ�ظ�
        """
        if isinstance(other, TaskV2):
            return self.uid == other.uid
        else:
            return False


class Task(CustomizedForJson):
    """�˻�ά������
    """
    def __init__(self,
            uid=None,
            userid=None,
            audit_data_id_list=None,
            text_cluster_num=None,
            image_cluster_num=None,
            earliest_in_time=None,
            chosen_info=None,
            ):
        super(Task, self).__init__()
        self.uid = str(uuid.uuid1()) if uid is None else uid
        self.userid = userid
        self.audit_data_id_list = list() if audit_data_id_list is None else audit_data_id_list
        self.text_cluster_count = None if text_cluster_num is None else np.zeros((1, text_cluster_num))
        self.image_cluster_count = None if image_cluster_num is None else np.zeros((1, image_cluster_num))
        self.label_count = np.zeros((1, 0))
        self.risk_count = np.zeros((1, 0))
        self.earliest_in_time = earliest_in_time
        self.chosen_info = "" if chosen_info is None else chosen_info
        self.text_count = 0
        self.image_count = 0

    def to_str(self, sep="\t"):
        return sep.join([
            "uid: {}".format(self.uid),
            "userid: {}".format(self.userid),
            "audit_data_id_list: {}".format(self.audit_data_id_list),
            "text_cluster_count: {}".format(self.text_cluster_count),
            "image_cluster_count: {}".format(self.image_cluster_count),
            "label_count: {}".format(self.label_count),
            "risk_count: {}".format(self.risk_count),
            "earliest_in_time: {}".format(self.earliest_in_time),
            "chosen_info: {}".format(self.chosen_info),
            "text_count: {}".format(self.text_count),
            "image_count: {}".format(self.image_count),
            ])

    def add_audit_data(self,
            audit_data,
            label_id_dict=None,
            risk_id_dict=None,
            text_high_sim_matrix=None,
            image_high_sim_matrix=None):
        """�������������Ϣ
        """
        #logging.info("text_high_sim_matrix shape: {}".format(text_high_sim_matrix.shape))
        self.audit_data_id_list.append(audit_data.uid)
        audit_data.task_uid = self.uid

        if label_id_dict is not None:
            # ���label_count������С��label_id_dict����Ŀ ���ұ���������ֱ�����
            col_add = len(label_id_dict) - self.label_count.shape[1]
            if col_add > 0:
                self.label_count = np.column_stack((self.label_count, np.zeros((1, col_add))))

            # ���ݵ�ǰ���ݵ�label ���Ӽ���
            for cur_label in audit_data.label_list:
                self.label_count[0][label_id_dict[cur_label]] += 1

        if risk_id_dict is not None:
            # ���risk_count������С��label_id_dict����Ŀ ���ұ���������ֱ�����
            col_add = len(risk_id_dict) - self.risk_count.shape[1]
            if col_add > 0:
                self.risk_count = np.column_stack((self.risk_count, np.zeros((1, col_add))))

            # ���ݵ�ǰ���ݵ�label ���Ӽ���
            for cur_risk in audit_data.risk_list:
                self.risk_count[0][risk_id_dict[cur_risk]] += 1

        if self.text_cluster_count is not None:
            for cur_label in audit_data.text_clusters:
                if text_high_sim_matrix is None:
                    self.text_cluster_count[0][cur_label] += 1
                else:
                    self.text_cluster_count[0] += text_high_sim_matrix[cur_label]
                self.text_count += 1

        if self.image_cluster_count is not None:
            for cur_label in audit_data.image_clusters:
                if image_high_sim_matrix is None:
                    self.image_cluster_count[0][cur_label] += 1
                else:
                    self.image_cluster_count[0] += image_high_sim_matrix[cur_label]
                self.image_count += 1

        if self.earliest_in_time is None or audit_data.in_time < self.earliest_in_time:
            self.earliest_in_time = audit_data.in_time

    def __eq__(self, other):
        """ȷ������ά������ȫ�ظ�
        """
        if isinstance(other, Task):
            return self.uid == other.uid
        else:
            return False


class ADAuditData(CustomizedForJson):
    """���������
    """
    def __init__(self,
            uid=None,
            userid=None,
            task_uid=None,
            ad_id=None,
            text_list=None,
            image_url_list=None,
            text_clusters=None,
            image_clusters=None,
            label_list=None,
            risk_list=None,
            distributed_num=None,
            left_num=None,
            audit_res_list=None,
            in_time=None,
            distributed_time=None,
            audit_end_time=None,
            chosen_info=None,
            ):
        super(ADAuditData, self).__init__()
        self.uid = str(uuid.uuid1()) if uid is None else uid
        self.userid = userid
        self.ad_id = ad_id
        self.task_uid = task_uid
        self.text_list = list() if text_list is None else text_list
        self.image_url_list = list() if image_url_list is None else image_url_list
        self.text_clusters = list() if text_clusters is None else text_clusters
        self.image_clusters = list() if image_clusters is None else image_clusters
        self.label_list = list() if label_list is None else label_list
        # ����ʵ�ʷ���
        self.risk_list = list() if risk_list is None else risk_list
        self.distributed_num = distributed_num
        self.left_num = left_num
        self.audit_res_list = audit_res_list
        self.in_time = in_time
        self.distributed_time = distributed_time
        self.audit_end_time = audit_end_time
        self.chosen_info = "" if chosen_info is None else chosen_info

    def to_str(self, sep="\t"):
        return sep.join([
            "uid: {}".format(self.uid),
            "userid: {}".format(self.userid),
            "ad_id: {}".format(self.ad_id),
            "task_uid: {}".format(self.task_uid),
            "text_list: {}".format(self.text_list),
            "image_url_list: {}".format(self.image_url_list),
            "text_clusters: {}".format(self.text_clusters),
            "image_clusters: {}".format(self.image_clusters),
            "risk_list: {}".format(self.risk_list),
            "distributed_num: {}".format(self.distributed_num),
            "left_num: {}".format(self.left_num),
            "audit_res_list: {}".format(self.audit_res_list),
            "in_time: {}".format(self.in_time),
            "distributed_time: {}".format(self.distributed_time),
            "audit_end_time: {}".format(self.audit_end_time),
            "chosen_info: {}".format(self.chosen_info),
            ])

    def __eq__(self, other):
        """ȷ������ά������ȫ�ظ�
        """
        if isinstance(other, AuditData):
            return self.uid == other.uid
        else:
            return False

    def __lt__(self, other):
        """heapq����ʱ��Ҫ
        """
        if isinstance(other, ADAuditData):
            return self.in_time < other.in_time
        else:
            raise ValueError("'<' not supported between instances of {} and {}".format(type(self), type(other)))


class AuditData(CustomizedForJson):
    """���������
    """
    def __init__(self,
            uid=None,
            value=None,
            label_list=None,
            #feature_vec=None,
            risk_list=None,
            distributed_num=None,
            left_num=None,
            audit_res_list=None,
            in_time=None,
            distributed_time=None,
            audit_end_time=None,
            chosen_info=None,
            ):
        super(AuditData, self).__init__()
        self.uid = str(uuid.uuid1()) if uid is None else uid
        self.value = value
        # ���ϻ��ֱ�ǩ
        self.label_list = label_list
        # ����ʵ�ʷ���
        self.risk_list = risk_list
        #self.feature_vec = feature_vec
        self.distributed_num = distributed_num
        self.left_num = left_num
        self.audit_res_list = audit_res_list
        self.in_time = in_time
        self.distributed_time = distributed_time
        self.audit_end_time = audit_end_time
        self.chosen_info = chosen_info

    def to_str(self, sep="\t"):
        return sep.join([
            "uid: {}".format(self.uid),
            "value: {}".format(self.value),
            "label_list: {}".format(self.label_list),
            "risk_list: {}".format(self.risk_list),
            "distributed_num: {}".format(self.distributed_num),
            "left_num: {}".format(self.left_num),
            "audit_res_list: {}".format(self.audit_res_list),
            "in_time: {}".format(self.in_time),
            "distributed_time: {}".format(self.distributed_time),
            "audit_end_time: {}".format(self.audit_end_time),
            "chosen_info: {}".format(self.chosen_info),
            ])

    def __eq__(self, other):
        if isinstance(other, AuditData):
            return self.uid == other.uid
        else:
            return False


class AuditRes(CustomizedForJson):
    """������ݷַ������Ա�������˵���
    """
    def __init__(self,
            audit_data_uid,
            auditor_uid,
            audit_in_time=None,
            audit_time=None,
            audit_out_time=None,
            audit_res_list=None,
            ):
        super(AuditRes, self).__init__()
        self.audit_data_uid = audit_data_uid
        self.auditor_uid = auditor_uid
        # ������ݷַ������Ա��ʱ��
        self.audit_in_time = audit_in_time
        # ���Ա��˵�ʱ��
        self.audit_time = audit_time
        # �������ʵ�ʽ�����ʱ��
        self.audit_out_time = audit_out_time
        self.audit_res_list = audit_res_list

    def to_str(self, sep="\t"):
        return sep.join([
            "audit_data_uid: {}".format(self.audit_data_uid),
            "auditor_uid: {}".format(self.auditor_uid),
            "audit_in_time: {}".format(self.audit_in_time),
            "audit_time: {}".format(self.audit_time),
            "audit_out_time: {}".format(self.audit_out_time),
            "audit_res_list: {}".format(self.audit_res_list),
            ])

    def __eq__(self, other):
        if isinstance(other, AuditRes):
            return self.audit_data_uid == other.audit_data_uid \
                    and self.auditor_uid == other.auditor_uid
        else:
            return False


class AuditorRecord(CustomizedForJson):
    """���Ա�ڷ���˵ļ�¼
    """
    def __init__(self, uid=None):
        super(AuditorRecord, self).__init__()
        self.uid = str(uuid.uuid1()) if uid is None else uid
        # TP FP FN
        # ����עTN
        # ���һ������ֻ����һ�����Ա �����Ա�ı�ע�Զ�����TP û����������
        # audit_performance��riskΪ׼
        self.audit_performance = defaultdict(lambda: {"TP": 0, "FP": 0, "FN": 0})
        # audit_effeciency��labelΪ׼
        # self.audit_effeciency[label] = {"audit_time": xxx, "audit_time_list": list(xxx)}
        self.audit_effeciency = {
                "image": dict(),
                "text": dict(),
                }

    def to_str(self, sep="\t"):
        return sep.join([
            "uid: {}".format(self.uid),
            "audit_performance: {}".format(self.audit_performance),
            "audit_effeciency: {}".format(self.audit_effeciency),
            ])

    def __eq__(self, other):
        if isinstance(other, AuditData):
            return self.uid == other.uid
        else:
            return False


if __name__ == "__main__":
    print("��ʼ����")
    audit_data = AuditData(label_list=["1", "2"])
    print("origin: {}".format(audit_data))

    print("����json��ʼ��")
    new_audit_data = AuditData.init_from_json(audit_data.to_json())
    new_audit_data.label_list.append("3")
    print("origin: {}".format(audit_data))
    print("new   : {}".format(new_audit_data))
    assert str(audit_data) != str(new_audit_data)

    print("����dict��ʼ����zero_copyΪFalse")
    new_audit_data = AuditData.init_from_dict(audit_data.to_dict(), zero_copy=False)
    new_audit_data.label_list.append("3")
    print("origin: {}".format(audit_data))
    print("new   : {}".format(new_audit_data))
    assert str(audit_data) != str(new_audit_data)

    print("����dict��ʼ����zero_copyΪTrue")
    new_audit_data = AuditData.init_from_dict(audit_data.to_dict(), zero_copy=True)
    new_audit_data.label_list.append("3")
    print("origin: {}".format(audit_data))
    print("new   : {}".format(new_audit_data))
    assert str(audit_data) == str(new_audit_data)
