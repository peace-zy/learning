#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   make_image_audit_data.py
Author:   zhanghao55@baidu.com
Date  :   21/05/10 17:07:13
Desc  :   
"""

import os
import sys
import codecs
import json
import logging
import random
import re
import time

from collections import defaultdict
from image_tag_client import ImageTagClient
from run_arguments import parse_args
from sklearn.cluster import MiniBatchKMeans
from sklearn.metrics import calinski_harabasz_score
from utils import AuditData

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log
from lib.common.data_io import get_data, dump_pkl, load_pkl
from lib.common.sampler import Sampler

init_log()


def load_strategy_format(data_path):
    """����ͼƬ��ģ�͵���˽���淶���ʵ�
    """
    format_dict = dict()
    with codecs.open(data_path, "r", "utf-8") as rf:
        for line in rf:
            parts = line.strip("\n").split("\t")
            ori_word = parts[0]
            format_word = parts[1]
            if format_word == "null":
                format_word = None
            format_dict[ori_word] = format_word
    return format_dict


def format_image_audit_log(config):
    """�淶��ͼƬ�������־
    """
    sample_num = sys.maxsize if config.max_num is None else config.max_num
    # image_url���ظ�
    audit_log_sampler = Sampler(sample_num=sample_num, uniq=True)

    strategy_map = load_strategy_format(config.strategy_map_path)

    # ģ�ͷ��ط����������ͣ�
    # 1. xxxx
    # 2. xxxx:xxxx:xxxx;xxx:xxxxxx
    # 3. xxxx;xxx:xxxxxx
    # 4. xxxx:xx.xxs: xx; xx.xxs: xxx:xxxxx;;xxx:x.xxs: xxx;
    match_pattern = re.compile(r"[^:;]+(:|[^s]*s:[^;]*;|[^;]*:?)*;?")

    reason_count = defaultdict(int)
    input_path = sys.argv[1]
    with codecs.open(config.audit_log_path, "r", config.encoding) as rf:
        for index, line in enumerate(rf):
            parts = line.strip("\n").split("\t")
            product_id = parts[0]
            ad_id = parts[1]
            user_id = parts[2]
            model_res = parts[3]
            manual_res = parts[4]
            strategy_word = parts[5]
            strategy_type = parts[6]
            reject_reason = parts[7]
            risk_id = parts[8]
            image_url = parts[9]
            # ֻ������һurl
            if image_url.startswith("["):
                continue
            # �޷���
            if strategy_word.lower() == "null":
                strategy_word = "�޷���"

            reason_list = list()
            for t in re.finditer(match_pattern, strategy_word):
                cur_reason = t.group(0)
                #print("#{}: {}".format(index, cur_reason))
                if ";" in cur_reason:
                    cur_reason = cur_reason[:cur_reason.find(";")]
                if ":" in cur_reason:
                    cur_reason = cur_reason[:cur_reason.find(":")]
                if cur_reason in strategy_map:
                    cur_reason = strategy_map[cur_reason]
                    if cur_reason is None:
                        continue
                reason_count[cur_reason] += 1
                reason_list.append(cur_reason)

            audit_log_sampler.put("\t".join([
                str(index),
                image_url,
                product_id,
                ad_id,
                user_id,
                model_res,
                manual_res,
                strategy_word,
                reject_reason,
                "\x01".join(reason_list),
                ]), key=image_url)

    with codecs.open(config.formated_audit_log_path, "w", config.encoding) as wf:
        for cur_line in audit_log_sampler.get_sample_list():
            wf.write(cur_line + "\n")


def get_vec(config):
    """��ȡͼƬ����
    """
    def process_line(line):
        """�д�������
        """
        parts = line.strip("\n").split("\t")
        image_url = parts[1]
        return image_url

    query_list = list(get_data(config.audit_log_path, read_func=process_line, encoding=config.encoding))
    if config.max_num is not None:
        query_list = query_list[:config.max_num]

    #if config.shuffle:
    #    random.Random(config.random_seed).shuffle(query_list)

    logging.info("query example:")
    for index, cur_query in enumerate(query_list[:config.example_num]):
        logging.info("#{}: {}".format(index, cur_query))

    vec_pkl_path = config.vec_res_path + ".pkl"

    if os.path.exists(vec_pkl_path):
        query_res_list = load_pkl(vec_pkl_path)
    else:
        client = ImageTagClient()

        logging.info("query size: {}".format(len(query_list)))
        query_res_list = client.query_tag(query_list, query_type="url", n_jobs=27, batch_size=32)
        dump_pkl(query_res_list, config.vec_res_path + ".pkl", True)

    vec_info_list = list()
    for cur_query_res in query_res_list:
        #logging.info("cur_query_res: {}".format(cur_query_res))
        cur_query_id = cur_query_res["id"]
        cur_query_url = query_list[cur_query_id]
        #assert cur_query_url == cur_query_res["url"], "url not consistant: {} != {}".format(cur_query_url, cur_query_res["url"])
        if "image_taginfo" not in cur_query_res or \
                cur_query_res["image_taginfo"] is None or \
                "ann_search_tag" not in cur_query_res["image_taginfo"] or \
                "ann_politic_black_128_feature" not in cur_query_res["image_taginfo"]["ann_search_tag"]:
            continue
        try:
            cur_query_vec = \
                    cur_query_res["image_taginfo"]["ann_search_tag"]["ann_politic_black_128_feature"]["content"]
            cur_query_vec_version = \
                    cur_query_res["image_taginfo"]["ann_search_tag"]["ann_politic_black_128_feature"]["version"]
        except Exception as e:
            logging.info("url: {}, cur_query_res:\n{}".format(cur_query_url, cur_query_res))
            continue
        vec_info_list.append((cur_query_id, cur_query_url, cur_query_vec, cur_query_vec_version))

    with codecs.open(config.vec_res_path, "w", config.encoding) as wf:
        for cur_id, cur_url, cur_vec, cur_version in sorted(vec_info_list, key=lambda x: x[0]):
            wf.write(json.dumps({
                "id": cur_id,
                "text": cur_url,
                "vec": cur_vec,
                "version": cur_version,
                }) + "\n")


def kmeans(
        vec_list,
        text_list,
        info_list,
        load_cluster_model,
        cluster_res_path,
        cluster_model_path,
        sorted_cluster_res_path=None,
        k=1000,
        batch_size=None,
        seed=1,
        ):
    """����
    """
    assert len(vec_list) == len(text_list) and len(text_list) == len(info_list)

    if load_cluster_model and os.path.exists(cluster_model_path):
        model = load_pkl(cluster_model_path)
        y_pre = model.predict(vec_list)
    else:
        logging.info("data size: {}, cluster start...".format(len(text_list)))
        start_time = time.time()
        if batch_size is None:
            batch_size = 10 * k
        # batch_size����������Mini Batch KMeans�㷨�Ĳ������Ĵ�С��Ĭ����100.����������ݼ������϶����������϶࣬��Ҫ�������ֵ�Դﵽ�Ϻõľ���Ч����
        model = MiniBatchKMeans(n_clusters=k, batch_size=batch_size, random_state=seed)
        y_pre = model.fit_predict(vec_list)
        score = calinski_harabasz_score(vec_list, y_pre)
        logging.info("cluster score: {:.4f}".format(score))
        logging.info("cost time: {:.4f}s".format(time.time() - start_time))

        # ����ģ��
        dump_pkl(model, cluster_model_path, True)

    # ���������
    cluster_res_list = list(zip(text_list, y_pre, info_list))
    with codecs.open(cluster_res_path, "w", "gb18030") as wf:
        for text, cluter_id, info in cluster_res_list:
            wf.write("{}\t{}\t{}\n".format(cluter_id, text, info))

    # ���������ľ�����
    with codecs.open(sorted_cluster_res_path, "w", "gb18030") as wf:
        for text, cluter_id, info in sorted(cluster_res_list, key=lambda x:x[1]):
            wf.write("{}\t{}\t{}\n".format(cluter_id, text, info))

    return y_pre


def load_vec_file(data_path, max_num, encoding):
    """���������ļ�
    """
    def get_vec(line):
        """��ȡ�����ļ�ÿ������
        """
        obj = json.loads(line.strip("\n"))
        return obj["id"], obj["text"], obj["vec"]

    logging.info("load_vec_file begin...")
    start_time = time.time()
    id_list = list()
    url_list = list()
    vec_list = list()
    for cur_id, cur_url, cur_vec in get_data(data_path, read_func=get_vec, encoding=encoding):
        if max_num is not None and max_num <= len(url_list):
            break
        id_list.append(cur_id)
        vec_list.append(cur_vec)
        url_list.append(cur_url)
    logging.info("load_vec_file end, cost time: {:.4f}s".format(time.time() - start_time))
    return id_list, url_list, vec_list


def load_audit_log(data_path, max_num, encoding):
    """���������ļ�
    """
    def get_audit_res(line):
        """���������ļ�ÿ������
        """
        parts = line.strip("\n").split("\t")
        url = parts[1]
        reason_list = [x for x in parts[-1].split("\x01") if len(x) > 0]
        info = "\t".join([parts[0]] + parts[2:-1])
        #assert len(reason_list) > 0
        if len(reason_list) == 0:
            reason_list = ["�޷���"]
        return url, reason_list, info

    logging.info("load_audit_log begin...")
    start_time = time.time()
    url_list = list()
    audit_lists = list()
    info_list = list()
    for cur_url, cur_audit_list, cur_info in get_data(data_path, read_func=get_audit_res, encoding=encoding):
        if max_num is not None and max_num <= len(url_list):
            break
        url_list.append(cur_url)
        audit_lists.append(cur_audit_list)
        info_list.append(cur_info)
    logging.info("load_audit_log end, cost time: {:.4f}s".format(time.time() - start_time))
    return url_list, audit_lists, info_list


def make_audit_data(config):
    """���ɴ�������
    """
    # ���������ļ�
    vec_id_list, vec_url_list, vec_list = load_vec_file(config.vec_path, config.max_num, config.encoding)
    # ���������ļ�
    # �����ļ��еļ�¼����ÿһ�춼����
    # ��vec�ļ�Ϊ׼
    audit_url_list, audit_lists, info_list = load_audit_log(config.audit_log_path, config.max_num, config.encoding)

    # ����vec_id_list������info_list vec_id_list�е�id ��ʾ����info_list������
    vec_info_list = list()
    vec_label_list = list()
    for index, (cur_vec_id, cur_vec_url) in enumerate(zip(vec_id_list, vec_url_list)):
        cur_audit_url = audit_url_list[cur_vec_id]
        assert cur_vec_url == cur_audit_url, "url not equal at line #{}".format(index + 1)
        vec_info_list.append(info_list[cur_vec_id])
        vec_label_list.append(audit_lists[cur_vec_id])

    # ����õ����
    cluster_id_list = kmeans(
            vec_list,
            vec_url_list,
            vec_info_list,
            config.load_cluster_model,
            config.cluster_res_path,
            config.cluster_model_path,
            sorted_cluster_res_path=config.sorted_cluster_res_path,
            k=config.k,
            )

    #logging.info("cluster_id_list[476523]: {}".format(cluster_id_list[476523]))

    assert len(cluster_id_list) == len(vec_url_list)
    assert len(cluster_id_list) == len(vec_label_list)
    assert len(cluster_id_list) == len(vec_info_list)

    with codecs.open(config.audit_data_path, "w", config.encoding) as wf:
        for index, (cur_url, cur_audit_list, cur_cluster_id) in \
                enumerate(zip(vec_url_list, vec_label_list, cluster_id_list)):
            audit_data = AuditData(
                    value=cur_url,
                    label_list=[int(cur_cluster_id)],
                    risk_list=cur_audit_list,
                    )
            wf.write(audit_data.to_json() + "\n")

    with codecs.open(config.plain_text_path, "w", config.encoding) as wf:
        for index, (cur_url, cur_audit_list, cur_cluster_id, cur_info) in \
                enumerate(zip(vec_url_list, vec_label_list, cluster_id_list, vec_info_list)):
            wf.write("\t".join([
                cur_url,
                str(cur_cluster_id),
                "|||".join(cur_audit_list),
                cur_info,
                ]) + "\n")


def load_audit_data(audit_data_path, encoding):
    """���ش�������
    """
    def process_line(line):
        """�д���
        """
        audit_data = AuditData.init_from_json(line.strip("\n"))
        return audit_data

    audit_data_list = list()
    for cur_audit_data in get_data(audit_data_path, read_func=process_line, encoding=encoding):
        audit_data_list.append(cur_audit_data)

    return audit_data_list


def stat_audit_data(config):
    """ͳ�ƴ�������
    """
    audit_data_list = load_audit_data(config.audit_data_path, config.encoding)

    total_risk_count = 0
    risk_count = defaultdict(int)
    label_count = defaultdict(int)
    risk_label_count = defaultdict(lambda: defaultdict(int))
    label_risk_count = defaultdict(lambda: defaultdict(int))
    for audit_data in audit_data_list:
        assert len(audit_data.label_list) == 1
        cur_label = audit_data.label_list[0]

        label_count[cur_label] += 1
        for cur_risk in audit_data.risk_list:
            total_risk_count += 1
            #logging.info("cur_label: {}".format(cur_label))
            #logging.info("cur_risk: {}".format(cur_risk))
            risk_label_count[cur_risk][cur_label] += 1
            label_risk_count[cur_label][cur_risk] += 1
            risk_count[cur_risk] += 1

    with codecs.open(config.stat_res_path, "w", config.encoding) as wf:
        wf.write("risk_label_count:\n")
        for risk, cur_label_count in risk_label_count.items():
            wf.write("risk: {}, total: {}\n".format(risk, risk_count[risk]))
            cur_risk_count = risk_count[risk]
            for label, count in sorted(cur_label_count.items(), key=lambda x:x[1], reverse=True):
                wf.write("label: {}, count: {}, ratio: {:.2f}%\n".format(
                    label,
                    count,
                    (count * 100 / float(cur_risk_count)),
                    ))
            wf.write("=" * 100 + "\n")

        wf.write("label_risk_count:\n")
        for label, cur_risk_count in label_risk_count.items():
            wf.write("label: {}, total: {}\n".format(label, label_count[label]))
            cur_label_count = label_count[label]
            for risk, count in sorted(cur_risk_count.items(), key=lambda x:x[1], reverse=True):
                wf.write("risk: {}, count: {}, ratio: {:.2f}%\n".format(
                    risk,
                    count,
                    (count * 100 / float(cur_label_count)),
                    ))
            wf.write("=" * 100 + "\n")

        wf.write("total risk count: {}\n".format(total_risk_count))

def main():
    """�����
    """
    config = parse_args()
    logging.info("config: \n{}".format(config))

    task = config.task
    if task == "format_image":
        format_image_audit_log(config)
    elif task == "get_vec":
        get_vec(config)
    elif task == "make":
        make_audit_data(config)
    elif task == "stat":
        stat_audit_data(config)
    else:
        raise ValueError("unkown task: {}".format(task))


if __name__ == "__main__":
    main()
