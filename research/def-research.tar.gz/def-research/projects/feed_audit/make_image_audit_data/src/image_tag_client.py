#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   image_tag_client.py
Author:   zhanghao55@baidu.com
Date  :   21/05/08 15:13:40
Desc  :   
"""

import sys
import base64
import json
import logging
import re
import subprocess
import time
from urllib import request
from multiprocessing import Pool, Manager


class ImageTagClient(object):
    def __init__(self):
        self.server_urls = self._init_server_urls()

    def _init_server_urls(self):
        bns_node = "group.opera-tagserveronline-tagserver2-000-sz.FENGKONG.all"
        cmd = "get_instance_by_service -ip {}".format(bns_node)
        ret_code, output = subprocess.getstatusoutput(cmd)
        assert int(ret_code) == 0, "get instance by service fail"

        urls = list()
        for server_info in output.split("\n"):
            parts = server_info.split(" ")
            # ���л�����
            # ����ʱΪ��ip��port
            # ����ʱΪ��hostname��ip��port
            # ��˶���ȡ�����ڶ��͵�����һ�м���
            url = "http://{}:{}/ImageQueryTagService/query".format(parts[-2], parts[-1])
            urls.append(url)
        logging.info("instances num: {}".format(len(urls)))
        return urls

    def query_tag(self, query_list, tag_paths=None, query_type="url", n_jobs=None, batch_size=32):
        """
        [IN]  query_list: list(str)�������б�
              query_type: str, ["url", "local"], url��ʾͼƬurl��local��ʾΪͼƬ���ص�ַ
        """
        start_time = time.time()
        manager = Manager()

        # �������
        query_queue = manager.Queue()
        # ����������
        req_res_queue = manager.Queue()

        # ��query_listѹ�����������
        for query_index, cur_query in enumerate(query_list):
            query_queue.put((query_index, cur_query))

        if n_jobs is None or n_jobs == -1:
            n_jobs = len(self.server_urls)

        # �ж��ٽ��� ��ѹ�����None
        for _ in range(n_jobs):
            query_queue.put((None, None))

        process_res_list = list()
        p = Pool()
        # ���������
        for cur_job_id in range(n_jobs):
            server_url = self.server_urls[cur_job_id % len(self.server_urls)]

            cur_process_res = p.apply_async(_query_tag, args=(
                cur_job_id,
                server_url,
                query_queue,
                req_res_queue,
                tag_paths,
                query_type,
                batch_size,
                ))

            process_res_list.append(cur_process_res)

        p.close()
        p.join()

        query_res_list = list()
        for cur_process_res in process_res_list:
            query_res_list.extend(cur_process_res.get())

        logging.info("cost time: {}".format(time.time() - start_time))
        return query_res_list


def _query_tag(
        worker_id,
        server_url,
        req_queue,
        req_res_queue,
        tag_paths=None,
        query_type="url",
        batch_size=32,
        ):
    """
    [IN]  server_url: str������˵�ַ
          req_queue: Queue�� ���������
          req_res_queue: Queue������������
          tag_paths: list(str)�������ǩ
          query_type: str, ["url", "local"], url��ʾͼƬurl��local��ʾΪͼƬ���ص�ַ
          batch_size: int��ÿ������������
    """
    logging.info("worker #{} start...".format(worker_id))
    if tag_paths is None:
        tag_paths = ["ann_search_tag.ann_politic_black_128_feature"]

    def gen_batch_data():
        cur_batch = list()
        if query_type == "url":
            while True:
                req_index, req_url = req_queue.get()
                if req_url is None:
                    break
                cur_batch.append({
                    "id": req_index,
                    "req_url": req_url,
                    })
                if len(cur_batch) >= batch_size:
                    yield cur_batch
                    cur_batch = list()
        elif query_type == "local":
            while True:
                req_index, req_addr = req_queue.get()
                if req_addr is None:
                    break
                with open(req_addr, "rb") as rf:
                    req_cont_b64 = base64.b64encode(rf.read())
                cur_batch.append({
                    "id": req_index,
                    "req_cont": req_cont_b64,
                    "is_req_cont_base64": True,
                    })
                if len(cur_batch) >= batch_size:
                    yield cur_batch
                    cur_batch = list()
        else:
            raise ValurError("Unknown query type: {}".format(query_type))

        if len(cur_batch) > 0:
            yield cur_batch

    query_res_list = list()
    for cur_batch in gen_batch_data():
        logging.info("worker #{} get batch size: {}, req left: {}".format(worker_id, len(cur_batch), req_queue.qsize()))
        request_res = _request_tag(server_url, cur_batch, default_tag_paths=tag_paths)

        # ģ�ͼ��������ocrʶ����
        # ����ֺܶ�\
        # ��Щ������Щ��ֱ�ӵ��½���ʧ��
        # ���ｫ�䴦����
        # �����ʣ��һ������������� ��{"xxx": "xxxx\"}�����
        # ���ﲻ�Ὣ\"��\��չΪ\\
        # ���������������
        request_res = re.sub(r'\\(?![/u"])', r"\\\\", request_res.decode("gb18030"))

        #request_res = request_res.decode("gb18030").replace(r"\\", r"\\\\")
        #logging.info("\nrequest_res: {}".format(request_res))
        max_retry = 50
        error_info = None
        while max_retry > 0:
            try:
                max_retry -= 1
                request_res = json.loads(request_res)
                break
            except json.decoder.JSONDecodeError as e:
                # ��������ʱֻ����һ�ִ��� ����json��"ǰ����һ��\
                # ��ʱjson�������� ����ʾ�Ĵ���λ��=\��λ��+4
                # �����ڵõ���ʾ�Ĵ���λ�ú�����ǰ����ַ��ķ�Χ����\
                # Ȼ���滻
                error_info = e
                logging.warning("error info: {}".format(error_info))
                error_index = re.findall(r"char (\d+)\)", str(error_info))
                assert len(error_index) > 0
                error_index = int(error_index[0])
                max_before = 5
                logging.warning("decode error index: {}".format(error_index))
                error_index = request_res.rfind("\\", error_index-max_before, error_index)
                logging.warning("actual error index: {}".format(error_index))
                if error_index == -1:
                    max_retry = 0
                    break
                request_res = request_res[:error_index] + "_" + request_res[error_index + 1:]

        if max_retry == 0:
            logging.info("cur_batch: {}".format(cur_batch))
            logging.info("fail request_res: {}".format(request_res))
            logging.info("error: {}".format(error_info))
            request_res_origin_str = request_res
            request_res = {"res_status": 1, "items": list()}
            for cur_dict in cur_batch:
                request_res["items"].append({
                    "id": cur_dict["id"],
                    "image_taginfo": None,
                    "origin_str": request_res_origin_str,
                    "error": error_info,
                    })

        assert request_res["res_status"] == 0 or max_retry == 0, "query fail: {}, left_retry = {}".format(request_res, max_retry)
        query_res_list.extend(request_res["items"])
        #logging.info("\nres: {}".format(json.dumps(request_res, indent=4, sort_keys=True)))
        time.sleep(0.5)

    logging.info("worker #{} finish, query num: {}.".format(worker_id, len(query_res_list)))
    return query_res_list


def _request_tag(
        server_url,
        req_list,
        default_tag_paths=None,
        default_userid=None,
        default_biz_src_id=None,
        default_service_id=None,
        default_is_deliver=True,
        ):
    """ request����tag��Ϣ
    [IN] server_url: str, �����ַ
         req_list: list(dict), �����ַ
         ����������ͼƬʱ��req_list[i] = {"req_url": xxx, is_req_cont_base64=False}
         �����󱾵�ͼƬ�ǣ�req_list[i] = {"req_cont": xxx, is_req_cont_base64=True}

         "is_deliver": True, # ���ʱ�ǩ�� tag_paths = [] �����Ѽ����ǩ
         "is_deliver": False, # ���¼���
    """

    logid = int(time.time() * 1000)
    param = {
            "logid": logid,
            "items": list(),
            }

    default_item_dict = {
            "userid": default_userid,
            "biz_src_id": default_biz_src_id,
            "service_id": default_service_id,
            "is_deliver": default_is_deliver,
            "tag_paths": default_tag_paths,
            }

    for cur_req_dict in req_list:
        cur_item = dict(**default_item_dict, **cur_req_dict)
        assert "tag_paths" in cur_item, "tag_paths should be specified"
        param["items"].append(cur_item)

    header = {"Content-Type": "application/json"}
    data = json.dumps(param).encode("utf-8")

    req = request.Request(server_url, data=data, headers=header)
    request_res = request.urlopen(req)
    request_res_str = request_res.read()
    return request_res_str


if __name__ == "__main__":
    import os
    _cur_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.append("%s/../../../../" % _cur_dir)
    from lib.common.logger import init_log

    init_log()

    client = ImageTagClient()
    req_url_list = [
            "http://fc1tn.baidu.com/it/u=4013445950,158990817&fm=203",
            "http://fc1tn.baidu.com/it/u=1936968727,1594275818&fm=203",
            "http://fc6tn.baidu.com/it/u=2312803923,4132865788&fm=203",
            ]
    query_res_list = client.query_tag(req_url_list, batch_size=2)
    vec_info_list = list()
    for cur_query_res in query_res_list:
        cur_query_id = cur_query_res["id"]
        if "image_taginfo" in cur_query_res:
            cur_query_vec = cur_query_res["image_taginfo"]["ann_search_tag"]["ann_politic_black_128_feature"]["content"]
            cur_query_vec_version = cur_query_res["image_taginfo"]["ann_search_tag"]["ann_politic_black_128_feature"]["version"]
        else:
            cur_query_vec = None
            cur_query_vec_version = None
        vec_info_list.append((cur_query_id, cur_query_vec, cur_query_vec_version))

    for cur_id, cur_vec, cur_version in sorted(vec_info_list, key=lambda x: x[0]):
        print(json.dumps({
            "id": cur_id,
            "text": req_url_list[cur_id],
            "vec": cur_vec,
            "vec_version": cur_version,
            }))
