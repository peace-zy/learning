#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   audit_client.py
Author:   zhanghao55@baidu.com
Date  :   21/04/14 17:19:27
Desc  :   
"""

import os
import requests
import sys
import json
import logging
import random
import time

from multiprocessing import Pool
from run_arguments import parse_args
from auditor import Auditor
from utils import AuditData

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log
from lib.common.data_io import get_data

init_log()
#logging.getLogger("requests").setLevel(logging.WARNING)
# ȥ��requestsʱ��log �е���� Ҫ����urllib3����־����������requests��log
logging.getLogger("urllib3").setLevel(logging.WARNING)

class Client(object):
    """��ȡ�����ı��Ŀͻ���
    """
    def __init__(self, url, host):
        """��ʼ��
        [IN]  url: str, �����������ַ
              host: str, host��ַ
        """
        self.url = url
        self.headers = {
                'content-Type': "text/plain",
                'Accept': "*/*",
                'Cache-Control': "no-cache",
                'Host': host,
                'accept-encoding': "gzip, deflate",
                'content-length': "1",
                'Connection': "keep-alive",
                'cache-control': "no-cache",
                }

    def request_emit(self, request_postfix, post_dict=None, retry=0):
        """����request����
        """
        #logging.info("request url: {}, path_postfix: {}".format(self.url, request_postfix))
        payload = "{}" if post_dict is None else json.dumps(post_dict)
        #post��post��д������get
        request_succeed = False
        while True:
            try:
                response = requests.request("POST", self.url + request_postfix, data=payload, headers=self.headers)
                request_res = json.loads(response.text)
                response.close()
                request_succeed = True
                break
            except requests.exceptions.ConnectionError as e:
                retry += 1
                logging.warning("request fail, retry #{}".format(retry))
                time.sleep(random.uniform(0.1, 2))
        assert request_succeed
        assert request_res["status"] == 0, "request fail: {}".format(request_res["error_info"])
        return request_res


class AuditorClient(Client):
    """���Ա��
    """
    def register(self, config):
        """ע��
        """
        logging.info("register")
        request_res = self.request_emit("register")
        uid = request_res["uid"]
        logging.info("register as auditor #{}".format(uid))
        self.auditor = Auditor(config, uid)

    def start_audit(self, config):
        """��ʼ���
        """
        logging.info("start_audit")
        retry = 0
        prev_audit_time = None
        while retry < 3:
            logging.info("auditor #{} request audit.".format(self.auditor.uid))
            request_res = self.request_emit("audit_request", {
                "uid": self.auditor.uid,
                "batch_size": config.audit_batch_size,
                "prev_audit_time": prev_audit_time,
                })
            #logging.info("auditor #{} recv {} data from server.".format(self.auditor.uid, len(request_res["audit_data_list"])))
            # ��ʼ���
            audit_data_list = [AuditData.init_from_dict(x) for x in request_res["audit_data_list"]]
            if len(audit_data_list) == 0:
                retry += 1
                time.sleep(1)
                continue
            retry = 0
            audit_res_list = list()
            for audit_data in audit_data_list:
                #audit_res = self.auditor.audit(audit_data, real_audit_speed=True)
                # ���뵱ǰ���Ӧ�ÿ�ʼ��ʱ��
                # ��һ��audit_data������ʱ�� �Ǳ���audit_data��ʼ��ʱ��
                audit_res = self.auditor.audit(audit_data, audit_start_time=prev_audit_time)
                if prev_audit_time is None or audit_res.audit_out_time > prev_audit_time:
                    prev_audit_time = audit_res.audit_out_time
                audit_res_list.append(audit_res.to_dict())
            request_res = self.request_emit("audit_res_in", {
                "auditor_uid": self.auditor.uid,
                "audit_res_list": audit_res_list,
                })
            logging.info("auditor #{} send {} audit_res to server.".format(self.auditor.uid, len(audit_res_list)))
            #time.sleep(random.random() * 5)


class AuditDataClient(Client):
    """���ʹ���������
    """
    def push_audit_data(self, audit_data_list, batch_size=None):
        """���ʹ��������
        """
        #logging.info("audit_data[0]: {}".format(audit_data_list[0]))
        audit_data_list = [x.to_dict() for x in audit_data_list]
        if batch_size is None:
            batch_size = len(audit_data_list)

        def gen_batch(total_list):
            """��������������
            """
            one_batch = list()
            for item in total_list:
                if len(one_batch) >= batch_size:
                    yield one_batch
                    one_batch = list()
                one_batch.append(item)

            if len(one_batch) > 0:
                yield one_batch

        for cur_batch in gen_batch(audit_data_list):
            logging.info("send {} audit_data to server.".format(len(cur_batch)))
            request_res = self.request_emit("audit_data_in", {"audit_data_list": cur_batch})
            #time.sleep(random.uniform(0.1, 0.5))


class DownloadClient(Client):
    """��Ϣ������
    """
    def download_info(self, **kwargs):
        """������Ϣ���浽����
        """
        logging.info("request downloadinfo at server.")
        request_res = self.request_emit("download_info", kwargs)


def clear_func(url, host):
    """���зַ������Ϣ���
    """
    class ClearClient(Client):
        """�����Ϣ������
        """
        def clear(self):
            """�����Ϣ����
            """
            logging.info("request clear server info")
            request_res = self.request_emit("clear")
    clear_client = ClearClient(url, host)
    clear_client.clear()


def auditor_func(url, host, config):
    """�������Ա�����
    """
    auditor = AuditorClient(url, host)
    time.sleep(random.uniform(0.1, 0.5))
    auditor.register(config)
    time.sleep(random.uniform(0.5, 1))
    auditor.start_audit(config)
    return 0


def audit_data_func(url, host, audit_data_list, batch_size=None):
    """���ʹ�������
    """
    audit_data = AuditDataClient(url, host)
    audit_data.push_audit_data(audit_data_list, batch_size)


def load_audit_data(audit_data_path, max_num=None, shuffle=True, random_seed=None, encoding="gb18030", example_num=5):
    """���ش�������
    """
    def process_line(line):
        """��ÿ�д������ݳ�ʼ��Ϊ��ʽ������
        """
        audit_data = AuditData.init_from_json(line.strip("\n"))
        return audit_data

    audit_data_list = list()
    for cur_audit_data in get_data(audit_data_path, read_func=process_line, encoding=encoding):
        if max_num is not None and max_num <= len(audit_data_list):
            break
        cur_audit_data.uid = len(audit_data_list)
        audit_data_list.append(cur_audit_data)

    if shuffle:
        random.Random(random_seed).shuffle(audit_data_list)

    for cur_audit_data in audit_data_list[:example_num]:
        print(cur_audit_data.to_str(sep="\t"))

    return audit_data_list


def push_and_audit(config):
    """�������ݲ��������
    """
    host = "{}:{}".format(config.server_ip, config.port)

    audit_data_list = load_audit_data(
            config.audit_data_path,
            config.max_num,
            config.shuffle,
            config.random_seed,
            config.encoding,
            config.example_num,
            )

    # ���÷�������Ϣ
    clear_func(
        "http://{}/".format(host),
        host,
        )

    audit_data_func(
        "http://{}/".format(host),
        host,
        audit_data_list,
        )

    auditor_func(
        "http://{}/".format(host),
        host,
        config,
        )


def push_and_multi_audit(config):
    """�������ݲ��������
    """
    host = "{}:{}".format(config.server_ip, config.port)

    # ���Աid�б�
    auditor_id_list = [x for x in range(config.auditor_num)]

    audit_data_list = load_audit_data(
            config.audit_data_path,
            config.max_num,
            config.shuffle,
            config.random_seed,
            config.encoding,
            config.example_num,
            )

    # ���÷�������Ϣ
    clear_func(
        "http://{}/".format(host),
        host,
        )

    process_res_list = list()
    p = Pool()
    # ��������˳�
    cur_process_res = p.apply_async(audit_data_func, args=(
        "http://{}/".format(host),
        host,
        audit_data_list,
        config.audit_batch_size,
        ))
    process_res_list.append(cur_process_res)

    for cur_auditor_id in auditor_id_list:
        cur_process_res = p.apply_async(auditor_func, args=(
            "http://{}/".format(host),
            host,
            config,
            ))
        process_res_list.append(cur_process_res)
        #time.sleep(0.1)

    p.close()
    p.join()

    for cur_process_res in process_res_list:
        cur_process_res.get()


def push_audit_data(config):
    """���ʹ��������
    """
    host = "{}:{}".format(config.server_ip, config.port)

    # ���÷�������Ϣ
    clear_func(
        "http://{}/".format(host),
        host,
        )

    audit_data_list = load_audit_data(
            config.audit_data_path,
            config.max_num,
            config.shuffle,
            config.random_seed,
            config.encoding,
            config.example_num,
            )

    audit_data_func(
        "http://{}/".format(host),
        host,
        audit_data_list,
        )


def audit(config):
    """�������
    """
    host = "{}:{}".format(config.server_ip, config.port)

    auditor_func(
        "http://{}/".format(host),
        host,
        config,
        )


def multi_audit(config):
    """�������
    """
    host = "{}:{}".format(config.server_ip, config.port)

    # ���Աid�б�
    auditor_id_list = [x for x in range(config.auditor_num)]

    process_res_list = list()
    p = Pool()
    # ��������˳�
    for cur_auditor_id in auditor_id_list:
        logging.info("establish auditor #{}".format(cur_auditor_id))
        cur_process_res = p.apply_async(auditor_func, args=(
            "http://{}/".format(host),
            host,
            config,
            ))
        process_res_list.append(cur_process_res)
        #time.sleep(0.5)

    p.close()
    p.join()

    for cur_process_res in process_res_list:
        cur_process_res.get()


def download_info(config):
    """��Ϣ���浽����
    """
    host = "{}:{}".format(config.server_ip, config.port)
    download_client = DownloadClient(
            "http://{}/".format(host),
            host,
            )
    download_client.download_info(
            audit_data_path=config.download_audit_data_path,
            audit_res_path=config.download_audit_res_path,
            auditor_info_path=config.download_auditor_info_path,
            auditor_performance_path=config.auditor_performance_path,
            auditor_effeciency_path=config.auditor_effeciency_path,
            audit_delay_path=config.audit_delay_path,
            distribute_info_path=config.distribute_info_path,
            audit_data_groupby_auditor_path=config.audit_data_groupby_auditor_path,
            )


def main():
    """�����
    """
    config = parse_args()
    assert config.auditor_num <= 50, "auditor_num should not be greater than 50, actual: {}".format(config.auditor_num)
    logging.info(config)

    task = config.task
    if task == "push":
        push_audit_data(config)
    elif task == "audit":
        audit(config)
    elif task == "audit_multi":
        multi_audit(config)
    elif task == "both_single":
        push_and_audit(config)
    elif task == "both_multi":
        push_and_multi_audit(config)
    elif task == "download":
        download_info(config)
    else:
        raise ValueError("unkown task: {}".format(task))


if __name__ == "__main__":
    main()
