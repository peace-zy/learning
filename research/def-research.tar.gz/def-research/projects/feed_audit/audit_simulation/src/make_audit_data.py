#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   make_audit_data.py
Author:   zhanghao55@baidu.com
Date  :   21/04/14 14:56:52
Desc  :   
"""

import os
import sys
import codecs
import json
import logging

from utils import AuditData
_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log
from lib.common.data_io import get_data, load_pkl

init_log()


def make_audit_data(
        risk_label_path,
        vec_path,
        cluster_model_path,
        output_path,
        need_predict=True,
        encoding="gb18030",
        example_num=5,
        ):
    """�����������б������Ӧ��������� ���ɴ��������ļ�
    """
    def get_risk_list(line):
        """�������� ��ȡ�����б�
        """
        parts = line.strip("\n").split("\t")
        return parts[1], [x for x in parts[-1].split("\x01") if len(x) > 0]

    def get_vec(line):
        """�����ļ�����ȡÿ�е�text��vec��Ϣ
        """
        obj = json.loads(line.strip("\n"))
        return obj["text"], obj["vec"]

    risk_text_list = list()
    risk_lists = list()
    for cur_text, cur_risk_list in get_data(risk_label_path, read_func=get_risk_list, encoding=encoding):
        risk_text_list.append(cur_text)
        risk_lists.append(cur_risk_list)

    vec_text_list = list()
    vec_list = list()
    for cur_text, cur_vec in get_data(vec_path, read_func=get_vec, encoding=encoding):
        vec_list.append(cur_vec)
        vec_text_list.append(cur_text)

    for index, (cur_risk_text, cur_vec_text) in enumerate(zip(risk_text_list, vec_text_list)):
        assert cur_vec_text == cur_vec_text, "text not equal at line #{}".format(index + 1)

    cluster_model = load_pkl(cluster_model_path)
    if need_predict:
        cluster_id_list = cluster_model.predict(vec_list)
    else:
        cluster_id_list = cluster_model.labels_
    logging.info("cluster_id_list: {}".format(cluster_id_list))
    logging.info("cluster_id_list shape: {}".format(cluster_id_list.shape))
    logging.info("labels_: {}".format(cluster_model.labels_))
    assert (cluster_id_list == cluster_model.labels_).all()

    with codecs.open(output_path, "w", "gb18030") as wf:
        for index, (cur_text, cur_risk_list, cur_cluster_id) in \
                enumerate(zip(risk_text_list, risk_lists, cluster_id_list)):
            audit_data = AuditData(
                    value=cur_text,
                    label_list=[int(cur_cluster_id)],
                    risk_list=cur_risk_list,
                    )
            wf.write(audit_data.to_json() + "\n")


if __name__ == "__main__":
    make_audit_data(
            "data/parse_feed_human_data_20210407_4_deduplicate_reason_format",
            "data/text_vec_v2.0",
            "data/cluster_model_n312847_k10000.model",
            "data/audit_data.txt",
            need_predict=False,
            encoding="utf-8",
            )
