#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   node.py
Author:   zhanghao55@baidu.com
Date  :   21/04/22 18:48:30
Desc  :   
"""

import sys
import logging
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity


class Node(object):
    """�����������Ľڵ���
    """
    def __init__(self, node_id, vec=None, indexs=None, weight=None, left=None, right=None, distance=None):
        self.node_id = node_id
        self.vec = vec
        self.indexs = indexs
        self.weight = weight
        self.distance = distance

        self.add_child(left, right)

        ## ���㵱ǰ�ڵ����
        #self.depth = 1 if self.is_leaf else (max(self.left.depth, self.right.depth) + 1)
        # ���㵱ǰ�ڵ�Ȩ��
        #if weight is None:
        #    self.weight = 1 if self.is_leaf else (self.left.weight + self.right.weight)
        #else:
        #    self.weight = weight
        ## ���㵱ǰ�ڵ������������
        #if indexs is None:
        #    self.indexs = list() if self.is_leaf else (self.left.indexs + self.right.indexs)
        #else:
        #    self.indexs = indexs

        self.father = None
        self.sibling = None

    def add_child(self, left, right):
        """���������ӽڵ�
        """
        assert (left is None and right is None) or (left is not None and right is not None)
        self.is_leaf = (left is None)
        self.left = left
        self.right = right

        if not self.is_leaf:
            self.left.father = self
            self.right.father = self
            self.left.sibling = self.right
            self.right.sibling = self.left

    def children(self, filter_node_id_set=None):
        """���ظýڵ��µ������ӽڵ�
        """
        node_stack = list()
        node_stack.append(self)

        if filter_node_id_set is None:
            filter_node_id_set = set()

        while len(node_stack) > 0:
            cur_node = node_stack.pop()
            if cur_node.node_id in filter_node_id_set:
                continue
            yield cur_node
            if not cur_node.is_leaf:
                # node_idС���ȵ���
                if cur_node.left.node_id > cur_node.right.node_id:
                    node_stack.append(cur_node.left)
                    node_stack.append(cur_node.right)
                else:
                    node_stack.append(cur_node.right)
                    node_stack.append(cur_node.left)

    def leaves(self, filter_node_id_set=None):
        """���ظýڵ��µ�����Ҷ�ӽڵ�
        """
        return [x for x in self.children(filter_node_id_set) if x.is_leaf]

    def get_nearest_leaf(self, vec=None):
        """ �ҵ������Ҷ�ڵ�
            vecΪNoneʱ����ʾ���뵱ǰ�ڵ�����Ľڵ�
            vec��λNoneʱ����ʾ�Ե�ǰ�ڵ�Ϊ���ڵ㣬�ҵ����vec
            ������ҵ�ǰ�����Ҷ�ӽڵ� ���ų�����Ѱ��
            ����Ǹ���һ��vec�����Ҷ�ӽڵ� ���������
        """
        if self.father is None and vec is None:
            logging.error("cur node is root, has no siblings.")
            return None

        tar_vec = self.vec if vec is None else vec
        tar_vec = np.array(tar_vec)
        if tar_vec.ndim == 1:
            tar_vec = np.expand_dims(tar_vec, axis=0)
        logging.info("tar_vec shape: {}".format(tar_vec.shape))
        logging.info("tar_vec dim: {}".format(tar_vec.ndim))

        search_root = self.sibling if vec is None else self
        leaf_list = search_root.leaves()

        assert tar_vec.shape[0] == 1
        sim_res_list = cosine_similarity(tar_vec, [x.vec for x in leaf_list])[0]
        logging.info("sim_res_list: {}".format(sim_res_list))
        logging.info("sim_res_list shape: {}".format(sim_res_list.shape))

        nearest_leaf_index = np.argmax(sim_res_list, axis=0)
        logging.info("nearest_leaf_index: {}".format(nearest_leaf_index))

        return leaf_list[nearest_leaf_index]

    def __eq__(self, other):
        if isinstance(other, Node):
            return self.node_id == other.node_id
        else:
            return False

    def __hash__(self):
        return hash(id(self))

    def __repr__(self):
        return "node #{}(weight: {}, is_leaf: {}, father: {}, left: {}, right:{}, index_example: {})".format(
                self.node_id,
                self.weight,
                self.is_leaf,
                "None" if self.father is None else self.father.node_id,
                "None" if self.left is None else self.left.node_id,
                "None" if self.right is None else self.right.node_id,
                self.indexs[:5],
                )



if __name__ == "__main__":
    pass


