#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   utils.py
Author:   zhanghao55@baidu.com
Date  :   21/04/14 17:01:23
Desc  :   
"""

import copy
import json
import random
import uuid
from collections import defaultdict


class CustomizedForJson(object):
    """���Ա�json dumps loads�Ļ�����
    """
    @classmethod
    def init_from_json(cls, init_json):
        """��json�ַ�����ʼ��
        """
        # ��Ϊֱ�Ӵ�json����ʼ�� �����������ֱ����json.loads�õ����ֵ������Ҫcopy
        return cls.init_from_dict(json.loads(init_json), zero_copy=True)

    @classmethod
    def init_from_dict(cls, init_dict, zero_copy=True):
        """��dict��ʼ��
        [in]  init_dict��dict����ʼ���ֵ�
              zero_copy��bool���Ƿ���audit_data_dict�и�ֵͬ������
           ��zero_copyΪTrue����init_from_dict���label_list�ȶ�����޸ģ�
           ��Ӱ��ԭaudit_data_dict�е�ֵ
        """
        if not zero_copy:
            init_dict = {k: copy.deepcopy(v) for k, v in init_dict.items()}
        return cls(**init_dict)

    def to_dict(self):
        """ת�ֵ�
        """
        return vars(self)

    def to_json(self):
        """תjson
        """
        return json.dumps(self.to_dict())

    def __repr__(self):
        return self.to_str(sep="\n")

    def to_str(self, sep="\t"):
        """תΪstr
        """
        raise NotImplementedError


class AuditData(CustomizedForJson):
    """���������
    """
    def __init__(self,
            uid=None,
            value=None,
            label_list=None,
            #feature_vec=None,
            risk_list=None,
            distributed_num=None,
            left_num=None,
            audit_res_list=None,
            in_time=None,
            distributed_time=None,
            audit_end_time=None,
            chosen_info=None,
            ):
        super(AuditData, self).__init__()
        self.uid = str(uuid.uuid1()) if uid is None else uid
        self.value = value
        # ���ϻ��ֱ�ǩ
        self.label_list = label_list
        # ����ʵ�ʷ���
        self.risk_list = risk_list
        #self.feature_vec = feature_vec
        self.distributed_num = distributed_num
        self.left_num = left_num
        self.audit_res_list = audit_res_list
        self.in_time = in_time
        self.distributed_time = distributed_time
        self.audit_end_time = audit_end_time
        self.chosen_info = chosen_info

    def to_str(self, sep="\t"):
        return sep.join([
            "uid: {}".format(self.uid),
            "value: {}".format(self.value),
            "label_list: {}".format(self.label_list),
            "risk_list: {}".format(self.risk_list),
            "distributed_num: {}".format(self.distributed_num),
            "left_num: {}".format(self.left_num),
            "audit_res_list: {}".format(self.audit_res_list),
            "in_time: {}".format(self.in_time),
            "distributed_time: {}".format(self.distributed_time),
            "audit_end_time: {}".format(self.audit_end_time),
            "chosen_info: {}".format(self.chosen_info),
            ])

    def __eq__(self, other):
        if isinstance(other, AuditData):
            return self.uid == other.uid
        else:
            return False


class AuditRes(CustomizedForJson):
    """������ݷַ������Ա�������˵���
    """
    def __init__(self,
            audit_data_uid,
            auditor_uid,
            audit_in_time=None,
            audit_time=None,
            audit_out_time=None,
            audit_res_list=None,
            ):
        super(AuditRes, self).__init__()
        self.audit_data_uid = audit_data_uid
        self.auditor_uid = auditor_uid
        # ������ݷַ������Ա��ʱ��
        self.audit_in_time = audit_in_time
        # ���Ա��˵�ʱ��
        self.audit_time = audit_time
        # �������ʵ�ʽ�����ʱ��
        self.audit_out_time = audit_out_time
        self.audit_res_list = audit_res_list

    def to_str(self, sep="\t"):
        return sep.join([
            "audit_data_uid: {}".format(self.audit_data_uid),
            "auditor_uid: {}".format(self.auditor_uid),
            "audit_in_time: {}".format(self.audit_in_time),
            "audit_time: {}".format(self.audit_time),
            "audit_out_time: {}".format(self.audit_out_time),
            "audit_res_list: {}".format(self.audit_res_list),
            ])

    def __eq__(self, other):
        if isinstance(other, AuditRes):
            return self.audit_data_uid == other.audit_data_uid \
                    and self.auditor_uid == other.auditor_uid
        else:
            return False


class AuditorRecord(CustomizedForJson):
    """���Ա�ڷ���˵ļ�¼
    """
    def __init__(self, uid=None):
        super(AuditorRecord, self).__init__()
        self.uid = str(uuid.uuid1()) if uid is None else uid
        # TP FP FN
        # ����עTN
        # ���һ������ֻ����һ�����Ա �����Ա�ı�ע�Զ�����TP û����������
        # audit_performance��riskΪ׼
        self.audit_performance = defaultdict(lambda: {"TP": 0, "FP": 0, "FN": 0})
        # audit_effeciency��labelΪ׼
        # self.audit_effeciency[label] = {"audit_time": xxx, "audit_time_list": list(xxx)}
        self.audit_effeciency = dict()

    def to_str(self, sep="\t"):
        return sep.join([
            "uid: {}".format(self.uid),
            "audit_performance: {}".format(self.audit_performance),
            "audit_effeciency: {}".format(self.audit_effeciency),
            ])

    def __eq__(self, other):
        if isinstance(other, AuditData):
            return self.uid == other.uid
        else:
            return False


if __name__ == "__main__":
    print("��ʼ����")
    audit_data = AuditData(label_list=["1", "2"])
    print("origin: {}".format(audit_data))

    print("����json��ʼ��")
    new_audit_data = AuditData.init_from_json(audit_data.to_json())
    new_audit_data.label_list.append("3")
    print("origin: {}".format(audit_data))
    print("new   : {}".format(new_audit_data))
    assert str(audit_data) != str(new_audit_data)

    print("����dict��ʼ����zero_copyΪFalse")
    new_audit_data = AuditData.init_from_dict(audit_data.to_dict(), zero_copy=False)
    new_audit_data.label_list.append("3")
    print("origin: {}".format(audit_data))
    print("new   : {}".format(new_audit_data))
    assert str(audit_data) != str(new_audit_data)

    print("����dict��ʼ����zero_copyΪTrue")
    new_audit_data = AuditData.init_from_dict(audit_data.to_dict(), zero_copy=True)
    new_audit_data.label_list.append("3")
    print("origin: {}".format(audit_data))
    print("new   : {}".format(new_audit_data))
    assert str(audit_data) == str(new_audit_data)
