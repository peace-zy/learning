#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   sample_task.py
Author:   zhanghao55@baidu.com
Date  :   21/07/05 19:18:14
Desc  :   
"""

import os
import sys
import codecs
import logging
import time

from collections import defaultdict
from tqdm import tqdm
from utils import ADAuditData
_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log
init_log()

from lib.common.sampler import Sampler


def sample_task(task_path, sample_task_path, start_time, end_time, sample_num, sample_time):
    """将给定数据格式化为ADAuditData格式的数据 根据给定数据的不同 下面对数据信息提取逻辑可能也需要改变
    """
    start_time_stamp = int(time.mktime(time.strptime(start_time, '%Y%m%d%H')))
    end_time_stamp = int(time.mktime(time.strptime(end_time, '%Y%m%d%H')))
    logging.info("time restrain: [{}, {})".format(start_time_stamp, end_time_stamp))
    logging.info("sample_num: {}, sample_time: {}".format(sample_num, sample_time))

    task_dict = defaultdict(list)
    task_in_time_dict = defaultdict(int)
    with codecs.open(task_path, "r", "utf-8") as rf:
        for line in tqdm(rf, desc="loading"):
            line = line.strip("\n")
            ad_audit_data = ADAuditData.init_from_json(line)
            if ad_audit_data.in_time < start_time_stamp or \
                    end_time_stamp <= ad_audit_data.in_time:
                continue
            task_dict[ad_audit_data.task_uid].append(line)
            if ad_audit_data.in_time < task_in_time_dict[ad_audit_data.task_uid]:
                task_in_time_dict[ad_audit_data.task_uid] = ad_audit_data.in_time

    # 任务按时间先后排序
    task_sorted = list(sorted(task_in_time_dict.items(), key=lambda x:x[1]))
    logging.info("task_sorted size: {}".format(len(task_sorted)))

    # 抽样任务
    sampler = Sampler(sample_num=sample_num * sample_time)
    for task_uid, _ in task_sorted:
        sampler.put(task_uid)

    sample_res_list = sampler.get_sample_list()
    logging.info("sample_res_list size: {}".format(len(sample_res_list)))

    for cur_index in range(sample_time):
        cur_sample_res_set = sample_res_list[cur_index * sample_num:(cur_index + 1) * sample_num]
        # 按时间先后顺序 输出任务抽样结果
        with codecs.open(sample_task_path + "_{}".format(cur_index), "w", "utf-8") as wf:
            for task_uid, _ in tqdm(task_sorted, desc="writing"):
                if task_uid in cur_sample_res_set:
                    for line in task_dict[task_uid]:
                        wf.write(line + "\n")


if __name__ == "__main__":
    task_path = sys.argv[1]
    sample_task_path = sys.argv[2]
    start_time = sys.argv[3]
    end_time = sys.argv[4]
    sample_num = int(sys.argv[5])
    sample_time = int(sys.argv[6])
    sample_task(
            task_path,
            sample_task_path,
            start_time,
            end_time,
            sample_num,
            sample_time,
            )


