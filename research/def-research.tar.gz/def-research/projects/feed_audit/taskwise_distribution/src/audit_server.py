#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   audit_server.py
Author:   zhanghao55@baidu.com
Date  :   21/04/14 15:53:53
Desc  :   
"""

import os
import sys
import logging
import json

from collections import defaultdict
from http.server import BaseHTTPRequestHandler, HTTPServer
from run_arguments import parse_args
from auditor import Auditor
from utils import ADAuditData, AuditorRecord, AuditRes
from audit_distribution_strategy import BaseDistributionStrategy
from audit_distribution_strategy_v0 import V0DistributionStrategy
from audit_distribution_strategy_v1 import V1DistributionStrategy
from audit_distribution_strategy_v8 import V8DistributionStrategy

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log

init_log()

SUCC  = 0
ERROR = 1


class RequestHandler(BaseHTTPRequestHandler):
    """http����
    """
    def __init__(self, *args, **kwargs):
        # ·�� Ĭ��Ϊ�����ı�����
        self.router = {
                "clear": self.clear,
                "register": self.register,
                "audit_request": self.audit_request,
                "audit_data_in": self.audit_data_in,
                "audit_res_in": self.audit_res_in,
                "download_info": self.download_info,
                }
        # �Զ������Ժ��ٳ�ʼ������ �����Զ�������Ի��Ҳ���
        # TODO ����ԭ��Ӧ����BaseHTTPRequestHandler�ڲ�do_POST�����߼����µ� δȷ��
        super(RequestHandler, self).__init__(*args, **kwargs)

    def do_HEAD(self):
        """����header����
        content-type: text/plain
        status: 200
        """
        self.send_response(200)
        self.send_header('Content-type', 'text/plain')
        self.end_headers()

    def log_request(self, *args, **kwargs):
        """����requestʱ��ӡ��־ ����ʹ�䲻��
        """
        pass

    def response(self, res_dict):
        """����data
        """
        self.do_HEAD()
        #wfile.writeֱ�ӻ�д
        self.wfile.write(json.dumps(res_dict).encode('utf-8'))

    def do_POST(self):
        """����POST����
        """
        # ��ȡ���ݳ���
        content_length = int(self.headers['Content-Length'])
        #logging.info("content_length: {}".format(content_length))
        #logging.info("headers: {}".format(self.headers))
        # ��ȡ����
        post_data = self.rfile.read(content_length)
        post_dict = json.loads(post_data)
        # ���ݲ�ͬ������·�� ִ�в�ͬ����
        self.router[self.path.strip("/")](post_dict)

    def audit_request(self, post_dict):
        """��������
        """
        request_uid = post_dict["uid"]
        prev_audit_time = post_dict.get("prev_audit_time", None)
        batch_size = post_dict.get("batch_size", None)
        chosen_audit_data_list = self.server.distribution_strategy.distribute_audit_data(
                request_uid,
                prev_audit_time,
                batch_size,
                )

        self.response({
            "status": SUCC,
            "audit_data_list": [x.to_dict() for x in chosen_audit_data_list],
            })

    def audit_res_in(self, post_dict):
        """������˽��
        """
        auditor_uid = post_dict["auditor_uid"]
        audit_res_list = post_dict["audit_res_list"]
        audit_res_list = [AuditRes.init_from_dict(x) for x in audit_res_list]
        self.server.distribution_strategy.receive_audit_res(audit_res_list, auditor_uid)

        self.response({
            "status": SUCC,
            })

    def audit_data_in(self, post_dict):
        """������audit_data
        """
        new_audit_data_list = [ADAuditData.init_from_dict(x) for x in post_dict["audit_data_list"]]

        self.server.distribution_strategy.receive_audit_data(new_audit_data_list)

        self.response({
            "status": SUCC,
            })

    def register(self, post_dict):
        """ע����auditor
        """
        new_auditor = self.server.distribution_strategy.register()
        self.response({
            "status": SUCC,
            "uid": new_auditor.uid,
            })

    def download_info(self, post_dict):
        """���������Ϣ
        """
        logging.info("download info")

        self.server.distribution_strategy.download_info(**post_dict)
        self.response({
            "status": SUCC,
            })


    def clear(self, post_dict):
        """����server
        """
        self.server.distribution_strategy.clear()
        self.response({
            "status": SUCC,
            })


class AuditServer(object):
    """��˷����
    """
    def __init__(self, config):
        server_address = ('', config.port)
        self.server = HTTPServer(server_address, RequestHandler)
        self.server.distribution_strategy = {
                "v0": V0DistributionStrategy,
                "v1": V1DistributionStrategy,
                "v8": V8DistributionStrategy,
                }[config.distribution_version](config)

    def start(self):
        """��������
        """
        logging.info('Starting server...\n')
        try:
            self.server.serve_forever()
        except KeyboardInterrupt:
            pass
        self.stop()

    def stop(self):
        """��������
        """
        self.server.server_close()
        logging.info('Stopping server...\n')


def run():
    """��������
    """
    config = parse_args()
    assert config.auditor_num <= 50, "auditor_num should not be greater than 50, actual: {}".format(config.auditor_num)
    logging.info(config)

    server = AuditServer(config)
    server.start()


if __name__ == '__main__':
    run()
