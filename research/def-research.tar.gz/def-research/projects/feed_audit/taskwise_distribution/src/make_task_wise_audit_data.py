#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   make_task_wise_audit_data.py
Author:   zhanghao55@baidu.com
Date  :   21/05/28 16:36:44
Desc  :   
"""

import os
import sys
import codecs
import json
import logging
from tqdm import tqdm
from utils import ADAuditData

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log
from lib.common.data_io import get_data, load_pkl

init_log()


def load_user_meg(userid_meg_path, encoding="gb18030"):
    """�����˻���ҵ��Ϣ
    """
    userid_meg_dict = dict()
    with codecs.open(userid_meg_path, "r", encoding) as rf:
        for line in tqdm(rf, desc="load user meg"):
            parts = line.strip("\n").split("\t")
            userid = parts[0]
            first_trade_name = parts[2]
            second_trade_name = parts[4]
            if first_trade_name == "����":
                assert second_trade_name == "����"
                userid_meg_dict[userid] = [first_trade_name]
            else:
                userid_meg_dict[userid] = [first_trade_name, second_trade_name]
    return userid_meg_dict


def make_ad_audit_data(
        input_path,
        output_path,
        text_vec_path,
        image_vec_path,
        text_cluster_model_path,
        image_cluster_model_path,
        user_meg_path,
        ):
    """��������ά�ȵĴ�������
    """

    text_cluster_model = load_pkl(text_cluster_model_path)
    image_cluster_model = load_pkl(image_cluster_model_path)
    userid_meg_dict = load_user_meg(user_meg_path)

    # �����text���ڵ�label_id
    text_cluster_dict = dict()
    text_list = list()
    text_vec_list = list()
    with codecs.open(text_vec_path, "r", "gb18030") as rf:
        for line in tqdm(rf, desc="text cluster"):
            obj = json.loads(line.strip("\n"))
            text = obj["text"]
            vec = obj["vec"]
            text_list.append(text)
            text_vec_list.append(vec)

    text_vec_clusters = text_cluster_model.predict(text_vec_list)
    assert len(text_list) == len(text_vec_list)
    for cur_text, cur_cluster in zip(text_list, text_vec_clusters):
        text_cluster_dict[cur_text] = int(cur_cluster)

    # �����image���ڵ�label_id
    image_cluster_dict = dict()
    image_list = list()
    image_vec_list = list()
    with codecs.open(image_vec_path, "r", "gb18030") as rf:
        for line in tqdm(rf, desc="image cluster"):
            obj = json.loads(line.strip("\n"))
            text = obj["text"]
            vec = obj["vec"]
            image_list.append(text)
            image_vec_list.append(vec)

    image_vec_clusters = image_cluster_model.predict(image_vec_list)
    assert len(image_list) == len(image_vec_list)
    for cur_image, cur_cluster in zip(image_list, image_vec_clusters):
        image_cluster_dict[cur_image] = int(cur_cluster)


    ad_audit_data_list = list()
    with codecs.open(input_path, "r", "gb18030") as rf, \
            codecs.open(output_path, "w", "gb18030") as wf:
        for line in tqdm(rf, "make ad wise audit data"):
            ad_audit_data = ADAuditData.init_from_json(line.strip("\n"))

            if ad_audit_data.userid in userid_meg_dict:
                ad_audit_data.label_list.extend(userid_meg_dict[ad_audit_data.userid])

            # ����audit_data��ֵcluster_id
            for cur_text in ad_audit_data.text_list:
                if len(cur_text) == 0:
                    continue
                if cur_text in text_cluster_dict:
                    ad_audit_data.text_clusters.append(text_cluster_dict[cur_text])
                else:
                    logging.warning("not found text: {}".format(cur_text))

            # ����audit_data��ֵcluster_id
            for cur_image in ad_audit_data.image_url_list:
                if len(cur_image) == 0:
                    continue
                if cur_image in image_cluster_dict:
                    ad_audit_data.image_clusters.append(image_cluster_dict[cur_image])
                else:
                    logging.warning("not found url: {}".format(cur_image))

            ad_audit_data_list.append((ad_audit_data.in_time, ad_audit_data))

        for _, cur_ad_audit_data in sorted(ad_audit_data_list, key=lambda x:x[0]):
            wf.write(cur_ad_audit_data.to_json() + "\n")

if __name__ == "__main__":
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    text_vec_path = sys.argv[3]
    image_vec_path = sys.argv[4]
    text_cluster_model_path = sys.argv[5]
    image_cluster_model_path = sys.argv[6]
    user_meg_path = sys.argv[7]

    make_ad_audit_data(
            input_path,
            output_path,
            text_vec_path,
            image_vec_path,
            text_cluster_model_path,
            image_cluster_model_path,
            user_meg_path,
            )
