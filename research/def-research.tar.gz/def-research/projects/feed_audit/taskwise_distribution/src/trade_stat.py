#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   trade_stat.py
Author:   zhanghao55@baidu.com
Date  :   21/07/06 14:01:11
Desc  :   
"""

import sys
import codecs

from collections import defaultdict


def trade_stat_by_auditor(distributed_data_path):
    """根据实际分发结果制造实验对照组
    """
    # 各任务包含的物料列表
    # task_data_count_dict[task_id] = data_num
    task_data_count_dict = defaultdict(int)

    # 各审核员分发到的任务字典
    # auditor_task_dict[auditor_id] = set(task_id)
    auditor_task_dict = defaultdict(set)

    # 各任务的行业标签信息
    # task_trade_info_dict[task_id] = trade_info
    task_trade_info_dict = dict()

    # 加载原始分发的结果
    with codecs.open(distributed_data_path, "r", "utf-8") as rf:
        for line in rf:
            parts = line.strip("\n").split("\t")
            auditor_id = parts[1]
            task_id = parts[2]
            trade_info = parts[10].split("|||")[0]

            # 更新审核员分发的任务信息
            auditor_task_dict[auditor_id].add(task_id)
            # 更新任务包含的物料
            task_data_count_dict[task_id] += 1
            # 更新任务的行业标签信息
            task_trade_info_dict[task_id] = trade_info

    assert len(task_trade_info_dict) == len(task_data_count_dict)

    # 各行业任务的数量
    trade_task_total_dict = defaultdict(int)
    # 各行业物料的数量
    trade_data_total_dict = defaultdict(int)
    for cur_task_id, cur_data_num in task_data_count_dict.items():
        cur_task_trade = task_trade_info_dict[cur_task_id]
        trade_task_total_dict[cur_task_trade] += 1
        trade_data_total_dict[cur_task_trade] += cur_data_num

    taskwise_stat_list = list()
    datawise_stat_list = list()

    for cur_auditor_id in sorted(auditor_task_dict.keys()):
        cur_task_set = auditor_task_dict[cur_auditor_id]

        total_data_num = 0
        # 统计当前审核员
        # 任务维度 各行业数量
        trade_task_count_dict = defaultdict(int)
        # 物料维度 各行业数量
        trade_data_count_dict = defaultdict(int)
        for cur_task_id in cur_task_set:
            cur_task_trade = task_trade_info_dict[cur_task_id]
            trade_task_count_dict[cur_task_trade] += 1
            trade_data_count_dict[cur_task_trade] += task_data_count_dict[cur_task_id]
            total_data_num += task_data_count_dict[cur_task_id]

        # 生成统计数据信息
        # 任务维度
        cur_trade_task_ratio_list = list()
        for cur_trade_info, cur_task_count in \
                sorted(trade_task_count_dict.items(), key=lambda x:x[1], reverse=True)[:8]:
            cur_trade_task_ratio_list.append("{}({}/{:.2f}%)".format(
                cur_trade_info,
                cur_task_count,
                cur_task_count * 100 / float(trade_task_total_dict[cur_trade_info]),
                ))
        taskwise_stat_list.append("auditor #{}, task_num = {}: {}".format(
            cur_auditor_id,
            len(cur_task_set),
            cur_trade_task_ratio_list,
            ))

        # 物料维度
        cur_trade_data_ratio_list = list()
        for cur_trade_info, cur_data_count in \
                sorted(trade_data_count_dict.items(), key=lambda x:x[1], reverse=True)[:8]:
            cur_trade_data_ratio_list.append("{}({}/{:.2f}%)".format(
                cur_trade_info,
                cur_data_count,
                cur_data_count * 100 / float(trade_data_total_dict[cur_trade_info]),
                ))
        datawise_stat_list.append("auditor #{}, data_num = {}: {}".format(
            cur_auditor_id,
            total_data_num,
            cur_trade_data_ratio_list,
            ))

    # 输出
    print("=" * 150)
    print("任务维度")
    for line in taskwise_stat_list:
        print(line)

    print("=" * 150)
    print("物料维度")
    for line in datawise_stat_list:
        print(line)


def trade_stat_total(distributed_data_path):
    """根据实际分发结果制造实验对照组
    """
    # 各任务包含的物料列表
    task_id_set = set()

    # 各行业任务的数量
    # trade_task_count_dict[trade_info] = task_num
    trade_task_count_dict = defaultdict(int)
    # 各行业物料的数量
    # trade_data_count_dict[trade_info] = data_num
    trade_data_count_dict = defaultdict(int)

    total_task_num = 0
    total_data_num = 0

    # 加载原始分发的结果
    with codecs.open(distributed_data_path, "r", "utf-8") as rf:
        for line in rf:
            parts = line.strip("\n").split("\t")
            task_id = parts[2]
            trade_info = parts[10].split("|||")[0]

            if task_id not in task_id_set:
                trade_task_count_dict[trade_info] += 1
                task_id_set.add(task_id)
                total_task_num += 1

            # 更新任务包含的物料
            trade_data_count_dict[trade_info] += 1
            total_data_num += 1

    print("=" * 150)
    taskwise_ratio_list = list()
    for cur_trade_info, cur_task_count in sorted(trade_task_count_dict.items(), key=lambda x:x[1], reverse=True)[:10]:
        taskwise_ratio_list.append("{}, num = {}, ratio = {:.2f}%".format(
            cur_trade_info,
            cur_task_count,
            cur_task_count * 100 / float(total_task_num),
            ))
    print("total task num = {}, dist: \n{}".format(total_task_num, "\n".join(taskwise_ratio_list)))

    print("=" * 150)
    datawise_ratio_list = list()
    for cur_trade_info, cur_data_count in sorted(trade_data_count_dict.items(), key=lambda x:x[1], reverse=True)[:10]:
        datawise_ratio_list.append("{}, num = {}, ratio = {:.2f}%".format(
            cur_trade_info,
            cur_data_count,
            cur_data_count * 100 / float(total_data_num),
            ))
    print("total data num = {}, dist: \n{}".format(total_data_num, "\n".join(datawise_ratio_list)))


if __name__ == "__main__":
    distributed_data_path = sys.argv[1]
    trade_stat_by_auditor(distributed_data_path)
    trade_stat_total(distributed_data_path)
