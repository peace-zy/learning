#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   audit_distribution_strategy.py
Author:   zhanghao55@baidu.com
Date  :   21/04/19 14:15:35
Desc  :   
"""

import os
import sys
import codecs
import logging
import random
import time
import numpy as np
import pandas as pd
from collections import defaultdict
from utils import AuditorRecord

from sklearn.metrics.pairwise import cosine_similarity

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log
from lib.common.data_io import load_pkl

init_log()


class BaseDistributionStrategy(object):
    """���Ϸַ��߼�����
    """
    def __init__(self, config):
        # ���������
        self.pending_data_dict = dict()
        # �ѷַ�����
        self.distributed_data_dict = dict()
        # ������˽��
        self.audit_res_dict = defaultdict(list)
        # ���Ա��Ϣ
        self.auditor_dict = dict()
        self.auditor_uniqid = 0
        # �ѷ�������Ա��
        # ���ÿ����С
        self.batch_size = config.audit_batch_size
        self.eval_auditor_num = config.eval_auditor_num

    def clear(self):
        """������зַ���Ϣ
        """
        self.pending_data_dict = dict()
        self.distributed_data_dict = dict()
        self.audit_res_dict = defaultdict(list)
        self.auditor_dict = dict()
        self.auditor_uniqid = 0

    def register(self):
        """ע��
        """
        new_auditor = AuditorRecord(self.auditor_uniqid)
        self.auditor_uniqid += 1
        self.auditor_dict[new_auditor.uid] = new_auditor
        logging.info("register new auditor #{}".format(new_auditor.uid))
        return new_auditor

    def receive_audit_data(self, audit_data_list):
        """���մ�������
        """
        for cur_audit_data in audit_data_list:
            self.pending_data_dict[cur_audit_data.uid] = cur_audit_data

        logging.info("recv {} audit_data from client, pending size: {}".format(
            len(audit_data_list),
            len(self.pending_data_dict),
            ))

    def distribute_audit_data(self, auditor_uid, prev_audit_time=None, batch_size=None):
        """�ַ��������� ��ʱ��˳��ַ�
        """
        raise NotImplementedError

    def _auditor_need_eval(self, auditor_record):
        """Ĭ�����Ա��������
        """
        return False

    def receive_audit_res(self, audit_res_list, auditor_uid):
        """���մ�������
        """
        #logging.info("recv {} data from auditor #{}.".format(len(audit_res_list), auditor_uid))
        for cur_audit_res in audit_res_list:
            self._update_audit_res(cur_audit_res)

    def _update_audit_res(self, new_audit_res):
        # ��ǰaudit_res������audit_data
        #logging.info("new_audit_res: {}".format(new_audit_res.to_str("\t")))
        audit_data = self.distributed_data_dict[new_audit_res.audit_data_uid]
        #logging.info("audit_data: {}".format(audit_data.to_str("\t")))
        # ��ǰaudit_data����˽���б�
        audit_res_list = self.audit_res_dict[audit_data.uid]
        #logging.info("res_list: {}".format(audit_res_list))
        # ��˽������
        audit_res_list.append(new_audit_res)
        # ���صĽ��һ�������ڷַ���ȥ����Ŀ
        #logging.info("res_list: {}".format(audit_res_list))
        assert len(audit_res_list) <= audit_data.distributed_num, \
                "res size: {}, distributed_num: {}".format(len(audit_res_list), audit_data.distributed_num)

        risk_count_dict = defaultdict(int)
        # ����ַ���ȥ�Ļ�û��ȫ�����ؽ�� ��ȴ�
        if len(audit_res_list) < audit_data.distributed_num:
            return

        # ���ַ���ȥ�Ķ����ؽ���� ��pending_data�оͲ�Ӧ���и�������
        assert audit_data.uid not in self.pending_data_dict

        # ������˵���ַ���ȥ�Ķ��ѷ��ؽ�� ��ʼ�������
        # ͳ����˽�����漰���ĸ�risk��
        for cur_audit_res in audit_res_list:
            for cur_risk in cur_audit_res.audit_res_list:
                risk_count_dict[cur_risk] += 1

        # ȷ����˽�� ����������Ϊrisk����
        confirmed_risk_set = set()
        for risk, count in risk_count_dict.items():
            if count * 2 > audit_data.distributed_num:
                confirmed_risk_set.add(risk)

        audit_data.audit_res_list = list(confirmed_risk_set)

        # ������˽�� ���¸�auditor���������Ч��
        for cur_audit_res in audit_res_list:
            cur_auditor = self.auditor_dict[cur_audit_res.auditor_uid]
            #logging.info("cur_auditor: {}".format(cur_auditor))
            # �������������Ϣ
            cur_audit_res_set = set(cur_audit_res.audit_res_list)
            for cur_risk in (confirmed_risk_set | cur_audit_res_set):
                # �������Ա��ȷ�ϵ�����risk

                # ���Ա����д��ڵ�risk
                if cur_risk in cur_audit_res_set:
                    # �������Ϊ��risk
                    if cur_risk in confirmed_risk_set:
                        cur_auditor.audit_performance[cur_risk]["TP"] += 1
                    # �������Ϊ����risk
                    else:
                        cur_auditor.audit_performance[cur_risk]["FP"] += 1
                else:
                    # ���Ա����в����ڵ�risk
                    # һ���Ǵ������Ϊ��risk
                    assert cur_risk in confirmed_risk_set
                    cur_auditor.audit_performance[cur_risk]["FN"] += 1

            for cur_label in audit_data.text_clusters:
                # �������Ա���Ч����Ϣ
                #audit_time = cur_audit_res.audit_out_time - cur_audit_res.audit_in_time
                if cur_label not in cur_auditor.audit_effeciency["text"]:
                    cur_auditor.audit_effeciency["text"][cur_label] = {"audit_time": 0, "audit_time_list": list()}
                cur_auditor.audit_effeciency["text"][cur_label]["audit_time_list"].append(cur_audit_res.audit_time)
                cur_auditor.audit_effeciency["text"][cur_label]["audit_time"] += cur_audit_res.audit_time

            for cur_label in audit_data.image_clusters:
                # �������Ա���Ч����Ϣ
                #audit_time = cur_audit_res.audit_out_time - cur_audit_res.audit_in_time
                if cur_label not in cur_auditor.audit_effeciency["image"]:
                    cur_auditor.audit_effeciency["image"][cur_label] = {"audit_time": 0, "audit_time_list": list()}
                cur_auditor.audit_effeciency["image"][cur_label]["audit_time_list"].append(cur_audit_res.audit_time)
                cur_auditor.audit_effeciency["image"][cur_label]["audit_time"] += cur_audit_res.audit_time

            # �������ݵ����ʱ����Ϣ
            if audit_data.audit_end_time is None or audit_data.audit_end_time < cur_audit_res.audit_out_time:
                audit_data.audit_end_time = cur_audit_res.audit_out_time

    def download_info(self,
            audit_data_path,
            audit_res_path,
            auditor_info_path,
            auditor_performance_path,
            auditor_effeciency_path,
            audit_delay_path,
            audit_data_groupby_auditor_path,
            ):
        """���������Ϣ������
        """
        audit_data_id_list = self.distributed_data_dict.keys()
        # �������������Ϣ
        with codecs.open(audit_data_path, "w", "utf-8") as wf:
            for cur_audit_data_id in audit_data_id_list:
                audit_data = self.distributed_data_dict[cur_audit_data_id]
                wf.write("{}\n".format(audit_data.to_str(sep="\t")))
        logging.info("download audit data info")

        # ������˽����Ϣ
        with codecs.open(audit_res_path, "w", "utf-8") as wf:
            for cur_audit_data_id in audit_data_id_list:
                audit_res_list = self.audit_res_dict[cur_audit_data_id]
                for cur_audit_res in audit_res_list:
                    wf.write("{}\n".format(cur_audit_res.to_str(sep="\t")))
        logging.info("download audit res info")

        # ��������Ա��˵�����
        auditor_audit_dict = defaultdict(list)
        for cur_audit_data_id in audit_data_id_list:
            audit_res_list = self.audit_res_dict[cur_audit_data_id]
            for cur_audit_res in audit_res_list:
                auditor_audit_dict[cur_audit_res.auditor_uid].append(cur_audit_data_id)

        with codecs.open(audit_data_groupby_auditor_path, "w", "utf-8") as wf:
            for auditor_uid, audit_data_list in auditor_audit_dict.items():
                for cur_audit_data_id in audit_data_list:
                    cur_audit_data = self.distributed_data_dict[cur_audit_data_id]
                    wf.write("\t".join([
                        str(auditor_uid),
                        str(cur_audit_data.task_uid),
                        str(cur_audit_data.userid),
                        str(cur_audit_data.ad_id),
                        "\x01".join(cur_audit_data.text_list),
                        "\x01".join(cur_audit_data.image_url_list),
                        "|||".join([str(x) for x in cur_audit_data.text_clusters]),
                        "|||".join([str(x) for x in cur_audit_data.image_clusters]),
                        "|||".join(cur_audit_data.risk_list),
                        "|||".join(cur_audit_data.label_list),
                        str(cur_audit_data.in_time),
                        str(cur_audit_data.distributed_time),
                        str(cur_audit_data.audit_end_time),
                        cur_audit_data.chosen_info,
                        ])+ "\n")
        logging.info("audit data group by auditor's info")

        # �������Ա��Ϣ
        with codecs.open(auditor_info_path, "w", "utf-8") as wf:
            for cur_auditor in self.auditor_dict.values():
                wf.write("{}\n".format(cur_auditor.to_str(sep="\t")))
        logging.info("download auditor's info")

        # ����������
        # �����������
        audit_performance = defaultdict(lambda: {"TP": 0, "FP": 0, "FN": 0})
        for audit_data in self.distributed_data_dict.values():
            real_risk_set = set(audit_data.risk_list)
            audit_res_set = set(audit_data.audit_res_list)
            for cur_risk in (real_risk_set | audit_res_set):
                # ��˽���д��ڵ�risk
                if cur_risk in audit_res_set:
                    # ʵ��ȷʵ��risk
                    if cur_risk in real_risk_set:
                        audit_performance[cur_risk]["TP"] += 1
                        audit_performance["total"]["TP"] += 1
                    # ʵ�ʲ���risk
                    else:
                        audit_performance[cur_risk]["FP"] += 1
                        audit_performance["total"]["FP"] += 1
                else:
                    # ��˽���в����ڵ�risk
                    # һ����ʵ�ʵ�risk
                    assert cur_risk in real_risk_set
                    audit_performance[cur_risk]["FN"] += 1
                    audit_performance["total"]["FN"] += 1

        def cal_performance(cur_risk, performance_dict):
            """ͳ��Ч��
            """
            TP = performance_dict["TP"]
            FP = performance_dict["FP"]
            FN = performance_dict["FN"]
            acc = TP / float(TP + FP) if TP + FP != 0 else np.nan
            recall = TP / float(TP + FN) if TP + FN != 0 else np.nan
            return ("risk: {}, acc: {:.4f}, recall: {:.4f}, TP: {}, FP: {}, FN: {}".format(
                cur_risk,
                acc,
                recall,
                TP,
                FP,
                FN
                ))

        with codecs.open(auditor_performance_path, "w", "utf-8") as wf:
            wf.write("{}\n".format(cal_performance("total", audit_performance["total"])))
            for cur_risk, performance_dict in audit_performance.items():
                if cur_risk == "total":
                    continue
                wf.write("{}\n".format(cal_performance(cur_risk, performance_dict)))
        logging.info("download audit performance info")

        # �������Ч��
        # audit_effeciency[auditor_uid] = {"audit_num": xx, "audit_time": xx}
        audit_effeciency = defaultdict(lambda: {
            "text": {
                "audit_num": 0,
                "audit_time": 0,
                },
            "image": {
                "audit_num": 0,
                "audit_time": 0,
                },
            }
            )
        for auditor_record in self.auditor_dict.values():
            for cur_effeciency in auditor_record.audit_effeciency["text"].values():
                cur_audit_num = len(cur_effeciency["audit_time_list"])
                cur_audit_time = cur_effeciency["audit_time"]
                audit_effeciency[auditor_record.uid]["text"]["audit_num"] += cur_audit_num
                audit_effeciency[auditor_record.uid]["text"]["audit_time"] += cur_audit_time
                audit_effeciency["total"]["text"]["audit_num"] += cur_audit_num
                audit_effeciency["total"]["text"]["audit_time"] += cur_audit_time

            for cur_effeciency in auditor_record.audit_effeciency["image"].values():
                cur_audit_num = len(cur_effeciency["audit_time_list"])
                cur_audit_time = cur_effeciency["audit_time"]
                audit_effeciency[auditor_record.uid]["image"]["audit_num"] += cur_audit_num
                audit_effeciency[auditor_record.uid]["image"]["audit_time"] += cur_audit_time
                audit_effeciency["total"]["image"]["audit_num"] += cur_audit_num
                audit_effeciency["total"]["image"]["audit_time"] += cur_audit_time

        def cal_effeciency(auditor_uid, effeciency_dict):
            """ͳ�Ƹ����Ա�����Ч��
            """
            text_audit_num = effeciency_dict["text"]["audit_num"]
            text_audit_time = effeciency_dict["text"]["audit_time"]
            text_audit_effeciency = text_audit_time / float(text_audit_num) if text_audit_num != 0 else np.nan
            image_audit_num = effeciency_dict["image"]["audit_num"]
            image_audit_time = effeciency_dict["image"]["audit_time"]
            image_audit_effeciency = image_audit_time / float(image_audit_num) if image_audit_num != 0 else np.nan
            return "auditor_uid: {}, audit_effeciency: [text: {:.4f}s/audit_data, audit_num: {}, audit_time: {:.4f}s]"\
                    "[image: {:.4f}s/audit_data, audit_num: {}, audit_time: {:.4f}s]".format(
                            auditor_uid,
                            text_audit_effeciency,
                            text_audit_num,
                            text_audit_time,
                            image_audit_effeciency,
                            image_audit_num,
                            image_audit_time,
                            )

        with codecs.open(auditor_effeciency_path, "w", "utf-8") as wf:
            wf.write("{}\n".format(cal_effeciency("total", audit_effeciency["total"])))
            for cur_auditor, effeciency_dict in audit_effeciency.items():
                if cur_auditor == "total":
                    continue
                wf.write("{}\n".format(cal_effeciency(cur_auditor, effeciency_dict)))
        logging.info("download audit effeciency info")

        # �����������ʱ��
        audit_delay_list = list()
        for audit_data in self.distributed_data_dict.values():
            audit_delay_list.append(audit_data.audit_end_time - audit_data.in_time)

        with codecs.open(audit_delay_path, "w", "utf-8") as wf:
            audit_delay = sum(audit_delay_list)
            audit_num = len(audit_delay_list)
            avg_delay = audit_delay / float(audit_num) if audit_num != 0 else np.nan
            wf.write("avg_delay: {:.4f}s, audit_num: {}, audit_delay: {:.4f}s\n".format(
                avg_delay,
                audit_num,
                audit_delay,
                ))

            delay_series = pd.Series(audit_delay_list)
            wf.write("delay stats:\n{}".format(delay_series.describe()))
        logging.info("download audit delay info")

        logging.info("download distribution info")


if __name__ == "__main__":
    pass


