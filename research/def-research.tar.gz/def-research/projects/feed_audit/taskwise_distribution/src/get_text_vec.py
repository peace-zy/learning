#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   get_text_vec.py
Author:   zhanghao55@baidu.com
Date  :   21/05/28 10:35:18
Desc  :   
"""

import os
import sys
import codecs
import json
import logging
import torch

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/ernie_lib/" % _cur_dir)
from base_model import BertSeq2seqModel, model_distributed
from bert import BertForSeqSim
from ernie_lib.utils import (
        bert_collate_fn,
        bert_infer_collate_fn,
        get_dataloader,
        ErnieDataset,
        )

sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.bert_tokenizer import BertTokenizer
from lib.common.data_io import get_data
from lib.common.logger import init_log

IS_DISTRIBUTED = False
try:
    torch.distributed.init_process_group(backend="nccl")
    LOCAL_RANK = torch.distributed.get_rank()
    IS_DISTRIBUTED = True

    logging_level = logging.INFO if LOCAL_RANK == 0 else logging.WARNING
    init_log(stream_level=logging_level)
except ValueError as e:
    init_log(stream_level=logging.INFO)

logging.info("is_distributed: {}".format(IS_DISTRIBUTED))


class ErnieSeqSimModel(BertSeq2seqModel):
    """ErnieSeqSimģ��
    """
    @model_distributed(find_unused_parameters=True, distributed=IS_DISTRIBUTED)
    def init_model(self, model_dir, tokenizer, keep_tokens, **kwargs):
        """��ʼ������
        """
        ernie_model = BertForSeqSim.from_pretrained(
                model_dir,
                vocab_size=tokenizer.vocab_size,
                keep_tokens=keep_tokens,
                **kwargs
                )
        return ernie_model


class ErnieInfer(object):
    """Ԥ���ı���������ģ��
    """
    def __init__(self,
            pretrained_model_path,
            model_path,
            vocab_path,
            simplified=True,
            pool_out_size=128,
            ):
        self.tokenizer, self.keep_tokens = BertTokenizer.load(vocab_path, simplified=simplified)
        self.model = ErnieSeqSimModel(
                model_dir=pretrained_model_path,
                tokenizer=self.tokenizer,
                keep_tokens=self.keep_tokens,
                seq_task=False,
                sim_task=False,
                pool_out_size=pool_out_size,
                )
        self.model.load_model(model_path, strict=False)
        logging.info("model at device : {}".format(self.model.device))

    def gen_infer_dataset(self, data_dir, max_num, encoding, example_num=5):
        """����Ԥ�����ݼ�
        """
        def process_line(line):
            """�д�������
            """
            parts = line.strip("\n").split("\t")
            return parts[0].split("\x01")

        def encode_data_list(cur_data_list):
            """����data
            """
            text_list = list()
            encode_list = list()

            for index, text in enumerate(cur_data_list):
                cur_token_ids, cur_token_type_ids = \
                        self.tokenizer.encode(first_text=text)
                encode_list.append((
                    cur_token_ids,
                    cur_token_type_ids,
                    index,
                    ))
                text_list.append((
                    text,
                    index,
                    ))

            return text_list, encode_list

        infer_data_list = list()
        for index, res_list in enumerate(\
                get_data(data_dir, read_func=process_line, encoding=encoding)):
            if max_num is not None and \
                    len(infer_data_list) >= max_num:
                break
            infer_data_list.extend(res_list)

        infer_data_list, infer_encoded_data = \
                encode_data_list(infer_data_list)

        logging.info("infer num = {}".format(len(infer_data_list)))

        logging.info(u"��������")
        for index, (text, (token_ids, _, _)) in enumerate(zip(
                infer_data_list[:example_num],
                infer_encoded_data[:example_num],
                )):
            logging.info("example #{}:".format(index))
            logging.info("text: {}".format(text))
            logging.info("token_ids: {}".format(token_ids))

        infer_dataset = ErnieDataset(infer_encoded_data)

        return infer_dataset, infer_data_list


    def gen_text_vec(self, text_path, text_vec_path, max_num=None, batch_size=32, encoding="utf-8"):
        """�����ı�����
        """
        # ======================== ���ش����������������ı� ==========================
        infer_dataset, infer_data_list = self.gen_infer_dataset(
                text_path,
                max_num,
                encoding,
                )

        infer_dataloader = get_dataloader(
                infer_dataset,
                collate_fn=bert_infer_collate_fn,
                batch_size=batch_size,
                distributed=IS_DISTRIBUTED,
                shuffle=False,
                )

        infer_res = self.model.predict(infer_dataloader, fetch_list=["text_output"])

        text_vec = infer_res["text_output"]
        logging.info("text_vec shape: {}".format(text_vec.shape))

        # �����gpu��������֮�� ��cpu().numpy()֮�� �������Ľ��̲��ܽ��� ��Ȼ�Ῠ��
        # �����return���� text_vec_list֮ǰ �����Ῠס
        if IS_DISTRIBUTED and LOCAL_RANK != 0:
            return

        with codecs.open(text_vec_path, "w", "utf-8") as wf:
            for cur_text, cur_text_vec in zip(infer_data_list, text_vec):
                # cur_text = (text, index)
                cur_text = cur_text[0]
                cur_obj = json.dumps({
                    "text": cur_text,
                    "vec": cur_text_vec.tolist(),
                    })
                wf.write("{}\n".format(cur_obj))


if __name__ == "__main__":
    # �ֲ�ʽʱ sys.argv������һ��local_rank���� ����ʱ��Ҫʡ��
    args = sys.argv[2:] if IS_DISTRIBUTED else sys.argv[1:]

    text_path = args[0]
    text_vec_path = args[1]
    pretrained_model_path = args[2]
    model_path = args[3]
    vocab_path = args[4]
    max_num = int(args[5]) if len(args) > 5 else None
    batch_size = int(args[6]) if len(args) > 6 else 32

    infer = ErnieInfer(
            pretrained_model_path,
            model_path,
            vocab_path,
            simplified=True,
            pool_out_size=128,
            )

    infer.gen_text_vec(
            text_path,
            text_vec_path,
            max_num,
            batch_size
            )
