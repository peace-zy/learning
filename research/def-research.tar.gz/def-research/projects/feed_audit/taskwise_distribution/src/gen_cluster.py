#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   gen_cluster.py
Author:   zhanghao55@baidu.com
Date  :   21/05/28 15:47:13
Desc  :   
"""

import os
import sys
import codecs
import json
import logging
import random
import re
import time

from collections import defaultdict
from image_tag_client import ImageTagClient
from sklearn.cluster import MiniBatchKMeans
from sklearn.metrics import calinski_harabasz_score
from utils import AuditData

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log
from lib.common.data_io import get_data, dump_pkl, load_pkl
from lib.common.sampler import Sampler

init_log()


def kmeans_cluster(
        vec_list,
        text_list,
        info_list,
        cluster_model_path,
        cluster_res_path=None,
        sorted_cluster_res_path=None,
        k=1000,
        batch_size=None,
        seed=None,
        ):
    """����
    """
    assert len(vec_list) == len(text_list) and len(text_list) == len(info_list)

    if os.path.exists(cluster_model_path):
        model = load_pkl(cluster_model_path)
        y_pre = model.predict(vec_list)
    else:
        logging.info("model path doesn't exist: {}".format(cluster_model_path))
        logging.info("data size: {}, cluster start...".format(len(text_list)))
        start_time = time.time()
        if batch_size is None:
            batch_size = 10 * k
        # batch_size����������Mini Batch KMeans�㷨�Ĳ������Ĵ�С��Ĭ����10�������.����������ݼ������϶����������϶࣬��Ҫ�������ֵ�Դﵽ�Ϻõľ���Ч����
        model = MiniBatchKMeans(n_clusters=k, batch_size=batch_size, random_state=seed)
        y_pre = model.fit_predict(vec_list)
        score = calinski_harabasz_score(vec_list, y_pre)
        logging.info("cluster score: {:.4f}".format(score))
        logging.info("cost time: {:.4f}s".format(time.time() - start_time))

        # ����ģ��
        dump_pkl(model, cluster_model_path, True)

    # ���������
    if cluster_res_path:
        cluster_res_list = list(zip(text_list, y_pre, info_list))
        with codecs.open(cluster_res_path, "w", "gb18030") as wf:
            for text, cluter_id, info in cluster_res_list:
                wf.write("{}\t{}\t{}\n".format(cluter_id, text, info))

    if sorted_cluster_res_path:
        # ���������ľ�����
        with codecs.open(sorted_cluster_res_path, "w", "gb18030") as wf:
            for text, cluter_id, info in sorted(cluster_res_list, key=lambda x:x[1]):
                wf.write("{}\t{}\t{}\n".format(cluter_id, text, info))

    return y_pre, model

def load_vec_file(data_path, max_num, encoding):
    """���������ļ�
    """
    def get_vec(line):
        """��ȡ�����ļ�ÿ������
        """
        obj = json.loads(line.strip("\n"))
        return obj["text"], obj["vec"]

    logging.info("load_vec_file begin...")
    start_time = time.time()
    text_list = list()
    vec_list = list()
    for cur_text, cur_vec in get_data(data_path, read_func=get_vec, encoding=encoding):
        if max_num is not None and max_num <= len(text_list):
            break
        text_list.append(cur_text)
        vec_list.append(cur_vec)
    logging.info("load_vec_file end, cost time: {:.4f}s".format(time.time() - start_time))
    return text_list, vec_list


def gen_cluster(vec_path,
        cluster_num,
        cluster_model_path,
        cluster_res_path,
        cluster_sorted_res_path,
        max_num,
        encoding="utf-8",
        ):
    """���ɾ���ģ��
    """
    text_list, vec_list = load_vec_file(vec_path, max_num, encoding)
    info_list = [""] * len(text_list)

    label_id, model = kmeans_cluster(
        vec_list,
        text_list,
        info_list,
        cluster_model_path,
        cluster_res_path=cluster_res_path,
        sorted_cluster_res_path=cluster_sorted_res_path,
        k=cluster_num,
        batch_size=None,
        seed=None,
        )


if __name__ == "__main__":

    vec_path = sys.argv[1]
    cluster_num = int(sys.argv[2])
    cluster_model_path = sys.argv[3]
    cluster_res_path = sys.argv[4]
    cluster_sorted_res_path = sys.argv[5]

    max_num = int(sys.argv[6]) if len(sys.argv) > 6 else None

    gen_cluster(
            vec_path,
            cluster_num,
            cluster_model_path,
            cluster_res_path,
            cluster_sorted_res_path,
            max_num
            )
