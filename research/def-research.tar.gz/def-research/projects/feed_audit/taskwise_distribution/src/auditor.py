#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   auditor.py
Author:   zhanghao55@baidu.com
Date  :   21/04/15 19:38:08
Desc  :   
"""

import sys
import logging
import random
import time
import uuid

from utils import CustomizedForJson, AuditRes

class Auditor(CustomizedForJson):
    """����audit_client�׶� ����auditor������Ϣ ģ��auditor������˽��
    """
    def __init__(self, config, uid=None):
        super(Auditor, self).__init__()
        self.config = config
        self.uid = str(uuid.uuid1()) if uid is None else uid
        # �����Ա�ڸ������µ�׼��
        # audit_performance[risk] = (acc, recall)
        self.audit_performance = dict()
        # �����Ա�ڸ������µ��������¼
        # risk_audit_num[label] = (cur_audit_num, prev_audit_num)
        self.risk_audit_num = dict()

        # �����Ա�ڸ�����µ����Ч��
        # audit_effeciency[label] = audit_time_cost
        self.audit_effeciency = {
                "image": dict(),
                "text": dict(),
                }
        # �����Ա�ڸ�����µ��������¼
        # label_audit_num[label] = (cur_audit_num, prev_audit_num)
        self.label_audit_num = {
                "image": dict(),
                "text": dict(),
                }

    def __repr__(self):
        return self.to_str(sep="\n")

    def to_str(self, sep="\t"):
        """ת��Ϊ�ַ���
        """
        return sep.join([
            "uid: {}".format(self.uid),
            "audit_performance: {}".format(self.audit_performance),
            "audit_effeciency: {}".format(self.audit_effeciency),
            "label_audit_num: {}".format(self.label_audit_num),
            "risk_audit_num: {}".format(self.risk_audit_num),
            ])

    def performance_init(self):
        """���������ʼ��
        """
        return random.triangular(
               self.config.audit_performance_lowest,
               self.config.audit_performance_highest,
               self.config.audit_performance_medium,
               )

    def performance_improve(self, cur_performance):
        """�������������ʽ
        """
        return cur_performance + \
                (self.config.audit_performance_highest - cur_performance) \
                * self.config.improve_ratio

    def effeciency_init(self):
        """���Ч�ʳ�ʼ��
        """
        return random.triangular(
                self.config.audit_effeciency_slowest,
                self.config.audit_effeciency_fastest,
                self.config.audit_effeciency_medium,
                )

    def effeciency_improve(self, cur_effeciency):
        """���Ч��������ʽ
        """
        return cur_effeciency + \
                (self.config.audit_effeciency_fastest - cur_effeciency) \
                * self.config.improve_ratio

    def probabilistic_active(self, probability):
        """��ָ�����ʷ���True
        """
        cur_prob = random.uniform(1e-13, 1)
        if probability >= cur_prob:
            return True
        else:
            return False

    def audit(self, audit_data, audit_start_time=None, real_audit_speed=False, audit_delay=True):
        """ģ�����
        """
        start_time = time.time()
        # ȷ�������
        risk_res_list = list()
        for cur_risk in audit_data.risk_list:
            if cur_risk not in self.audit_performance:
                self.audit_performance[cur_risk] = (
                        self.performance_init(),
                        self.performance_init(),
                        )
            cur_acc, cur_recall = self.audit_performance[cur_risk]
            if self.probabilistic_active(cur_recall):
                risk_res_list.append(cur_risk)
            # TODO ����ֻ���з��յ� �Ž���������
            # �޷��յ�һ�������ط���

        # ȷ������ʱ��
        cost_time_list = list()
        for cur_label in audit_data.text_clusters:
            if cur_label not in self.audit_effeciency["text"]:
                self.audit_effeciency["text"][cur_label] = self.effeciency_init()
            cost_time_list.append(self.audit_effeciency["text"][cur_label])

        for cur_label in audit_data.image_clusters:
            if cur_label not in self.audit_effeciency["image"]:
                self.audit_effeciency["image"][cur_label] = self.effeciency_init()
            cost_time_list.append(self.audit_effeciency["image"][cur_label])
        # ȡƽ��
        mock_audit_time = sum(cost_time_list) / float(len(cost_time_list)) if len(cost_time_list) > 0 else 5

        # ��˽�����ʱ��
        if audit_start_time is None:
            audit_start_time = audit_data.distributed_time
        audit_out_time = audit_start_time + mock_audit_time

        # ����Ч��
        for cur_label in audit_data.text_clusters:
            if cur_label not in self.label_audit_num:
                self.label_audit_num["text"][cur_label] = (1, 1)
                continue
            cur_audit_num, prev_audit_num = self.label_audit_num[cur_label]
            cur_audit_num += 1
            if cur_audit_num >= prev_audit_num * 2:
                cur_audit_effeciency = self.audit_effeciency["text"][cur_label]
                # ÿ�����ĳlabel���������� ���Ч�������Ч�ʼ�Ĳ������improve_ratio
                cur_audit_effeciency += \
                        (self.config.audit_effeciency_fastest - cur_audit_effeciency) \
                        * self.config.improve_ratio
                self.audit_effeciency["text"][cur_label] = cur_audit_effeciency
                prev_audit_num = cur_audit_num
            self.label_audit_num["text"][cur_label] = (cur_audit_num, prev_audit_num)

        # ����Ч��
        for cur_label in audit_data.image_clusters:
            if cur_label not in self.label_audit_num:
                self.label_audit_num["image"][cur_label] = (1, 1)
                continue
            cur_audit_num, prev_audit_num = self.label_audit_num[cur_label]
            cur_audit_num += 1
            if cur_audit_num >= prev_audit_num * 2:
                cur_audit_effeciency = self.audit_effeciency["image"][cur_label]
                # ÿ�����ĳlabel���������� ���Ч�������Ч�ʼ�Ĳ������improve_ratio
                cur_audit_effeciency += \
                        (self.config.audit_effeciency_fastest - cur_audit_effeciency) \
                        * self.config.improve_ratio
                self.audit_effeciency["image"][cur_label] = cur_audit_effeciency
                prev_audit_num = cur_audit_num
            self.label_audit_num["image"][cur_label] = (cur_audit_num, prev_audit_num)

        # ��������
        for cur_risk in audit_data.risk_list:
            if cur_risk not in self.risk_audit_num:
                self.risk_audit_num[cur_risk] = (1, 1)
                continue
            cur_risk_num, prev_risk_num = self.risk_audit_num[cur_risk]
            cur_risk_num += 1
            if cur_risk_num >= prev_risk_num * 2:
                cur_risk_acc, cur_risk_recall = self.audit_performance[cur_risk]
                cur_risk_acc = self.performance_improve(cur_risk_acc)
                cur_risk_recall = self.performance_improve(cur_risk_recall)
                self.audit_performance[cur_risk] = (cur_risk_acc, cur_risk_recall)
                prev_risk_num = cur_risk_num
            self.risk_audit_num[cur_risk] = (cur_risk_num, prev_risk_num)

        if real_audit_speed:
            # �ӳ�ʱ�� = ģ������ʱ�� - �����ĵ�ʱ��
            actual_func_time = time.time() - start_time
            sleep_time = mock_audit_time - actual_func_time
            if sleep_time < 0:
                logging.warning("actual func time({:.4f}s) > mock audit time({:.4f}s)".format(
                    actual_func_time,
                    mock_audit_time,
                    ))
                sleep_time = 0
            logging.info("auditor #{} sleep {:.4f}s".format(self.uid, sleep_time))
            time.sleep(sleep_time)
        elif audit_delay:
            time.sleep(random.uniform(0.01, 0.03))

        # ������˽��
        return AuditRes(
                audit_data_uid=audit_data.uid,
                auditor_uid=self.uid,
                audit_in_time=audit_data.distributed_time,
                audit_time=mock_audit_time,
                audit_out_time=audit_out_time,
                audit_res_list=risk_res_list,
                )


if __name__ == "__main__":
    from run_arguments import parse_args
    from utils import AuditData
    config = parse_args()
    print(config)
    print("=" * 150)
    auditor = Auditor(config)

    test_list = [
            ([1, 2], ["2"], 100),
            ([1, 3], ["3"], 101),
            ([1, 4], ["2"], 102),
            ([2, 4], ["3"], 103),
            ([3, 4], ["3"], 104),
            ([2, 3], ["3"], 105),
            ]

    audit_data_list = [AuditData(label_list=x[0], risk_list=x[1], out_time=x[2]) for x in test_list]
    for audit_data in audit_data_list:
        print("audit_data: \n{}".format(audit_data))
        audit_res = auditor.audit(audit_data)
        print("auditor status: \n{}".format(auditor))
        print("audit res: \n{}".format(audit_res))
        print("=" * 150)

