#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   get_text_vec.py
Author:   zhanghao55@baidu.com
Date  :   21/06/17 15:31:25
Desc  :   
"""

import sys
import codecs
import json
import numpy as np
import requests
from tqdm import tqdm

class Text2VecClient(object):
    """�ı�ת�����ͻ���
    """
    def __init__(
            self,
            host,
            port,
            path="/ernie_sim_2.0/services/batch_text_2_vec",
            ):
        self.host = host
        self.port = port
        self.path = path
        self.url = "http://{}:{}{}".format(
                self.host,
                self.port,
                self.path,
                )

    def batch_text_2_vec(self, text_list, batch_size=32, progress=False):
        """�ı�ת����
        """
        def gen_batch(text_iter):
            """������
            """
            cur_batch = list()
            if progress:
                pbar = tqdm()
            for cur_text in text_iter:
                if len(cur_batch) >= batch_size:
                    yield cur_batch
                    cur_batch = list()
                cur_batch.append(cur_text)
                if progress:
                    pbar.update(1)
            if progress:
                pbar.close()
            if len(cur_batch) > 0:
                yield cur_batch

        vec_list = list()
        for cur_batch in gen_batch(text_list):
            cur_batch_size = len(cur_batch)
            cur_req_data = json.dumps({
                "texts_a": cur_batch,
                })
            cur_response = requests.post(self.url, data=cur_req_data)
            #print("cur_response: {}".format(cur_response))
            #print("cur_response text: {}".format(cur_response.text))
            cur_response_dict = cur_response.json()
            #error_code = response_dict["error_code"]
            cur_result = cur_response_dict["result"]
            #print("result size: {}".format(len(result)))
            cur_values = cur_result[0]["value"]
            #print("values size: {}".format(len(values)))
            cur_vec = np.array(cur_values).reshape((cur_batch_size, -1))
            #print("cur_vec shape: {}".format(cur_vec.shape))
            vec_list.extend(cur_vec.tolist())
        return vec_list


def test():
    """����
    """
    text_list = [
            "Ӣ������Ӣ�����",
            "�������Ÿ����",
            ]

    client = Text2VecClient(
            host="yq01-qianmo-com-255-121-18.yq01.baidu.com",
            port=9001,
            path="/ernie_sim_2.0/services/batch_text_2_vec",
            )

    vec_list = client.batch_text_2_vec(text_list)
    print("text_list: {}".format(text_list))
    print("vec_list: {}".format(vec_list))


def infer_vec(file_path=None, output=None, batch_size=32):
    """Ԥ������
    """
    client = Text2VecClient(
            host="yq01-qianmo-com-255-121-18.yq01.baidu.com",
            port=9001,
            path="/ernie_sim_2.0/services/batch_text_2_vec",
            )
    #client = Text2VecClient(
    #        host="0.opera-xforce-BRPTDDiluOnline-000-hd.SC-GPU.szth.serv",
    #        port=35050,
    #        path="/ernie_sim_2.0/services/batch_text_2_vec",
    #        )
    #client = Text2VecClient(
    #        host="group.opera-xforce-BRPTDDiluOnline-all-hd.SC-GPU.all.serv",
    #        port=35050,
    #        path="/ernie_sim_2.0/services/batch_text_2_vec",
    #        )

    text_list = list()
    if file_path is None:
        for line in sys.stdin:
            line = line.strip("\n")
            text_list.append(line)
    else:
        with codecs.open(file_path, "r", "utf-8") as rf:
            for line in rf:
                text_list.append(line.strip("\n"))

    vec_list = client.batch_text_2_vec(text_list, batch_size, True)
    if output is None:
        for cur_text, cur_vec in zip(text_list, vec_list):
            print(json.dumps({
                "text": cur_text,
                "vec": cur_vec,
                }))
    else:
        with codecs.open(output, "w", "utf-8") as wf:
            for cur_text, cur_vec in zip(text_list, vec_list):
                wf.write(json.dumps({
                    "text": cur_text,
                    "vec": cur_vec,
                    }) + "\n")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description='get text vec.')
    parser.add_argument('-f', '--file', default=None, help='input file path')
    parser.add_argument('-b', '--batch_size', type=int, default=256, help='request text batch size')
    parser.add_argument('-o', '--output', default=None, help='output file path')
    args = parser.parse_args()

    infer_vec(
            file_path=args.file,
            output=args.output,
            batch_size=args.batch_size,
            )
