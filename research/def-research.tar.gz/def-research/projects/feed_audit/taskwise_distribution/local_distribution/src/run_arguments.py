#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   run_arguments.py
Author:   zhanghao55@baidu.com
Date  :   21/04/14 11:19:18
Desc  :   
"""

import os
import sys
import argparse


def parse_args(args=None):
    """运行参数配置解析
    """
    parser = argparse.ArgumentParser(description = "audit experiment run args")

    # ==================================== default =======================================
    default_group = parser.add_argument_group('default')
    default_group.add_argument("--output_dir", default = "output", help = "输出目录")

    # =================================== run config =====================================
    run_group = parser.add_argument_group('run_config')
    run_group.add_argument("--uniqid", default = "default", help = "当前任务标识")

    # =================================== server config =====================================
    server_group = parser.add_argument_group('server_config')
    server_group.add_argument("--distribution_version", default = "default", help = "分发版本")
    server_group.add_argument("--text_cluster_model_path", help = "文本聚类模型")
    server_group.add_argument("--text_high_sim_threshold", type = float, default = 0.50, help = "类别高度相似的阈值")
    server_group.add_argument("--image_cluster_model_path", help = "图片聚类模型")
    server_group.add_argument("--image_high_sim_threshold", type = float, default = 0.95, help = "类别高度相似的阈值")
    # 审核时间得分参数
    server_group.add_argument("--delay_start", type = float, default = 00.0, help = "开始算延迟的待审核时间")
    server_group.add_argument("--delay_max", type = float, default = 3600.0, help = "开始算延迟的待审核时间")
    # 内容相似得分参数
    server_group.add_argument("--text_weight", type = float, default = 1.0, help = "文本优先级得分权重")
    server_group.add_argument("--image_weight", type = float, default = 0.5, help = "图片优先级得分权重")
    # 各维度参数权重
    server_group.add_argument("--sim_weight", type = float, default = 1.0, help = "相似度得分权重")
    server_group.add_argument("--label_weight", type = float, default = 5.0, help = "行业标签得分权重")
    server_group.add_argument("--risk_weight", type = float, default = 1.0, help = "风险标签得分权重")
    server_group.add_argument("--delay_penalty", type = float, default = 0.0, help = "审核延迟损失权重")

    server_group.add_argument("--epsilon", type = float, default = 1e-13, help = "极小值")

    # =================================== auditor config =====================================
    auditor_group = parser.add_argument_group('auditor_config')
    auditor_group.add_argument("--auditor_num", type = int, default = 5, help = "审核人员数")
    auditor_group.add_argument("--audit_batch_size", type = int, default = 10, help = "每次请求多少元素进行审核")

    # ================================== data config =====================================
    data_group = parser.add_argument_group('data_config')
    data_group.add_argument("--task_path", default=None, help = "审核数据输入文件位置")
    data_group.add_argument("--max_num", type = int, default = None, help = "输入数据最大值")
    data_group.add_argument("--encoding", default = "utf-8", help = "输入数据文件的编码")

    # ================================== config end ======================================

    # 解析参数
    pargs_res = parser.parse_args() if args is None else  parser.parse_args(args)

    # 结果输出位置
    pargs_res.distribution_info_path = os.path.join(
            pargs_res.output_dir,
            "distribution_info_{}.txt".format(pargs_res.uniqid),
            )

    pargs_res.distribution_res_path = os.path.join(
            pargs_res.output_dir,
            "distribution_res_{}.txt".format(pargs_res.uniqid),
            )

    return pargs_res

if __name__ == "__main__":
    args = parse_args()
    print(args)


