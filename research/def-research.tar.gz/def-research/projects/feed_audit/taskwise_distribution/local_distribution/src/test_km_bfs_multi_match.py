#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   test_km_bfs_multi_match.py
Author:   zhanghao55@baidu.com
Date  :   21/07/06 10:05:20
Desc  :   
"""

import sys
import logging
from numpy import random
import numpy as np
import time

from km_bfs_v2 import KMBFS as KM2
from km_bfs_v3 import KMBFS as KM3


def test_km2(auditor_num, task_num, score_matrix, request_num=10):
    """用km_bfs_v2匹配
    """
    h = KM2(auditor_num * request_num, task_num)

    # 构造edges
    cur_left_node = 1
    auditor_id_list = list()
    for cur_auditor_index in range(auditor_num):
        for _ in range(request_num):
            auditor_id_list.append(cur_auditor_index)
            for cur_right_node in range(task_num):
                h.add_edge(cur_left_node, cur_right_node + 1, score_matrix[cur_auditor_index][cur_right_node])
            cur_left_node += 1
    match_time = time.time() 
    score = h.solve()
    match_time = time.time() - match_time

    # 按auidtor ID大小 按task ID大小排序
    match_res_str = " ".join([str(y) for x, y in sorted(zip(auditor_id_list, h.match_x))])
    print("km2 score = {}, cost time = {:.4f}s".format(score, match_time))
    return score, match_res_str


def test_km3(auditor_num, task_num, score_matrix, request_num=10):
    """用km_bfs_v3匹配
    """
    h = KM3(auditor_num, task_num, [request_num]*auditor_num)

    # 构造edges
    for cur_auditor_index in range(auditor_num):
        for cur_right_node in range(task_num):
            cur_weight = score_matrix[cur_auditor_index][cur_right_node]
            #if cur_weight == -1:
            #    continue
            h.add_edge(cur_auditor_index + 1, cur_right_node + 1, cur_weight)

    match_time = time.time() 
    score = h.solve()
    match_time = time.time() - match_time

    match_res_list = list()
    # 按auidtor ID大小 按task ID大小排序
    for cur_auditor_id, cur_task_list in enumerate(h.left_match):
        for cur_task_id in cur_task_list:
            match_res_list.append((cur_auditor_id, cur_task_id))
    match_res_str = " ".join([str(y) for x, y in sorted(match_res_list)])

    print("km3 score = {}, cost time = {:.4f}s".format(score, match_time))
    return score, match_res_str


def test_diff(auditor_num, task_num):
    """比较kmbfs v2和v3是否有区别
    """
    score_matrix = random.uniform(low=-100, high=100, size=(auditor_num, task_num))
    score_matrix = np.where(score_matrix > 0, score_matrix, 0)

    km2_score, km2_res = test_km2(auditor_num, task_num, score_matrix)
    km3_score, km3_res = test_km3(auditor_num, task_num, score_matrix)
    print("km2: {}".format(km2_res))
    print("km3: {}".format(km3_res))
    print("score compare: {}".format(km2_score == km3_score))
    print("res compare: {}".format(km2_res == km3_res))
    assert km2_res == km3_res
    assert abs(km2_score - km3_score) < 1e-6


def test_score_to_priority(auditor_num, task_num):
    """测试得分矩阵变为优势矩阵的区别
    """
    """比较将score矩阵 改为优势矩阵 匹配结果的区别
    """
    score_matrix = random.randint(low=-10, high=10, size=(auditor_num, task_num))
    #.uniform(low=-100, high=100, size=(auditor_num, task_num))
    score_matrix = np.where(score_matrix > 0, score_matrix, 0)
    print("score_matrix: {}".format(score_matrix))

    km2_score, km2_res = test_km3(auditor_num, task_num, score_matrix, 1)

    #score_max = np.max(score_matrix, axis=0).reshape((1, -1))
    #score_min = np.min(score_matrix, axis=0).reshape((1, -1))
    #score_diff = score_max - score_min
    #score_diff = np.where(score_diff, score_diff, 1e-20)
    #score_priority = (score_matrix - score_min) / score_diff

    #score_max = np.max(score_matrix, axis=0).reshape((1, -1))
    #score_priority = score_matrix - score_max
    ##score_priority -= np.min(score_priority)


    partition_res = np.argpartition(score_matrix, (-1, -2), axis=0)
    first_big = partition_res[-1, :]
    #print("1: {}".format(first_big))
    second_big = partition_res[-2, :]
    #print("2: {}".format(second_big))
    #first_res = score_matrix[np.ix_(range())]
    
    first_value = score_matrix[first_big, range(score_matrix.shape[1])].reshape((1, -1))
    score_priority = np.empty_like(score_matrix)
    for index, (cur_first_index, cur_second_index) in enumerate(zip(first_big, second_big)):
        cur_first_value = score_matrix[cur_first_index, index]
        cur_second_value = score_matrix[cur_second_index, index]
        score_priority[:, index] = score_matrix[:, index] - cur_first_value
        score_priority[cur_first_index, index] += cur_first_value - cur_second_value
    #print(score_priority)  

    print("score_priority: {}".format(score_priority))

    km3_score, km3_res = test_km3(auditor_num, task_num, score_priority, 1)
    print("km2: {}".format(km2_res))
    print("km3: {}".format(km3_res))

    match_res = km3_res.split()
    origin_km3_score = 0
    for cur_auditor_index, cur_task_index in enumerate(match_res):
        origin_km3_score += score_matrix[cur_auditor_index][int(cur_task_index)]
    print("origin km3 score = {}".format(origin_km3_score))

    print("score compare: {}".format(km2_score == origin_km3_score))
    print("res compare: {}".format(km2_res == km3_res))
    assert km2_score == origin_km3_score


def test1():
    """测试1
    """
    test_diff(50, 5)
    test_diff(5, 5)
    test_diff(5, 20)
    for _ in range(5):
        test_diff(5, 500)


def test2():
    """测试2
    """
    #test_score_to_priority(50, 5)
    test_score_to_priority(4, 4)
    test_score_to_priority(5, 5)
    for _ in range(5):
        test_score_to_priority(5, 10)


if __name__ == "__main__":
    #test1()
    test2()
