#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   km_bfs.py
Author:   zhanghao55@baidu.com
Date  :   21/07/06 10:05:20
Desc  :   
"""

import sys
import logging
from collections import deque


class KMBFS(object):
    """传统kb
    """
    def __init__(self, left_node_num, right_node_num):
        """初始化
        """
        self.left_node_num = left_node_num
        self.right_node_num = right_node_num
        self.big_node_num = max(self.left_node_num, self.right_node_num)

        self.inf = float("inf")
        self.graph = [[0] * self.big_node_num for _ in range(self.big_node_num)]

        self.queue = deque()

        self.match_x = [None] * self.big_node_num
        self.match_y = [None] * self.big_node_num
        self.prev = [None] * self.big_node_num

        self.vis_x = [False] * self.big_node_num
        self.vis_y = [False] * self.big_node_num

        self.lx = [-self.inf] * self.big_node_num
        self.ly = [0] * self.big_node_num
        self.slack = [None] * self.big_node_num

    def set_graph(self, tar_graph):
        """设置图
        """
        self.graph = list()
        for cur_list in tar_graph:
            pad_length = self.big_node_num - len(cur_list)
            self.graph.append(cur_list + ([0] * pad_length))

        while len(self.graph) > self.big_node_num:
            self.graph.append([0] * self.big_node_num)

    def add_edge(self, left_node, right_node, weight):
        """添加边
        """
        #logging.info("weight: {}".format(weight))
        self.graph[left_node - 1][right_node - 1] = max(weight, 0)

    def solve(self):
        """二分匹配
        """
        for i in range(self.big_node_num):
            # 遍历各左集合点
            for j in range(self.big_node_num):
                # 遍历各右集合点
                # 记录各左集合点连接边的最大权值
                # 作为初始顶标
                if self.graph[i][j] is not None:
                    self.lx[i] = max(self.lx[i], self.graph[i][j])

        for i in range(self.left_node_num):
            # 遍历左集合各点 
            # 初始化各记录数组
            self.slack = [self.inf] * self.big_node_num
            # 各点均为未访问过
            self.vis_x = [False] * self.big_node_num
            self.vis_y = [False] * self.big_node_num
            # 宽度优先寻找该点的最优匹配
            self.bfs(i)

        score = 0
        for i in range(self.big_node_num):
            if i >= self.left_node_num:
                break
            if self.match_x[i] >= self.right_node_num:
                self.match_x[i] = -1
            #if self.graph[i][self.match_x[i]] == 0:
            #    self.match_x[i] = -1
            #else:
            score += self.graph[i][self.match_x[i]]
        #print("{}".format(score))
        #print(" ".join([str(self.match_x[i]) for i in range(self.left_node_num)]))
        return score

    def bfs(self, left_index):
        """循环形式
        """
        # 清空队列
        while len(self.queue) > 0:
            self.queue.popleft()
        # 以当前左集合点作为起始点 加入队列
        self.queue.append(left_index)
        # 记录当前左集合点已访问
        self.vis_x[left_index] = True
        # 循环直到找到最优匹配????
        # TODO 要提前停止
        while True:
            while len(self.queue) > 0:
                # 寻找增广路
                cur_left_index = self.queue.popleft()
                # 遍历右集合点
                for cur_right_index in range(self.big_node_num):
                    # 如果已访问过 则跳过
                    # 个人感觉：不管是不是这条路径都可以跳过 说明该路径已被找过 没有增广路径 或还在队列中？
                    if self.vis_y[cur_right_index]:
                        continue
                    # 记录当前边的权值与当前两点顶标加起来的要求值的差距
                    # 如果要匹配该边则 左集合点的顶标需要下降该值
                    delta = self.lx[cur_left_index] + self.ly[cur_right_index] \
                            - self.graph[cur_left_index][cur_right_index]
                    # 记录各右集合点所需的最小松弛量
                    if self.slack[cur_right_index] >= delta:
                        # 如果该松弛量小于等于当前右集合点标的松弛量 则更新
                        # prev记录该右集合点达到最小松弛量时 对应的左集合点
                        # 更新交替路信息
                        self.prev[cur_right_index] = cur_left_index
                        # 如果当前松弛量为零 则说明找到了相等边
                        if delta == 0:
                            # 检测当前右集合点是否已被匹配 若没有 则找到了增广路径 否则就是交替路 加入队列等待
                            if self.check(cur_right_index):
                                return
                        else:
                            # 如果松弛量不为零 则更新到该右集合点的slack中
                            self.slack[cur_right_index] = delta

            a = self.inf
            # 遍历右集合点
            for j in range(self.big_node_num):
                #if self.graph[left_index][j] is None:
                #    continue
                # 对于没有访问过的右集合点
                # 只有相等边的右集合点才会被访问
                # 所以没有访问过的右集合点的是slack都应该大大于0
                # 找最小的松弛量
                if not self.vis_y[j]:
                    a = min(a, self.slack[j])

            # 遍历所有集合点 尝试扩大相等子图
            for k in range(self.big_node_num):
                if self.vis_x[k]:
                    # 对于访问过的左集合点 其顶标都下降a
                    self.lx[k] -= a
                if self.vis_y[k]:
                    # 对于访问过的右集合点 为保证现有路径符合两点顶标之和不变 则其顶标需要增加a
                    self.ly[k] += a
                else:
                    # 没有访问过的右集合点 因访问过的左集合点顶标都下降a 因此各右集合点的slack也会下降a
                    self.slack[k] -= a

            # 调整顶标后 查看是否有新的相等边出现
            for l in range(self.big_node_num):
                #if self.graph[left_index][l] is None:
                #    continue
                # 查看没有访问的右集合点中 是否有相等边 
                # 如果有 检测该右集合点 成功则找到了增广路 否则该点加入队列 生成新的交替路
                if not self.vis_y[l] and self.slack[l] == 0 and self.check(l):
                    return

    def check(self, right_index):
        """检测为增广路还是交替路
        """
        # 记录当前右集合点被访问
        self.vis_y[right_index] = True
        if self.match_y[right_index] is not None:
            # 如果当前右集合点已被匹配
            # 则将该右集合点先前匹配的左集合点加入队列 之后寻找其增广路径
            self.queue.append(self.match_y[right_index])
            # 记录该左集合点已被访问
            self.vis_x[self.match_y[right_index]] = True
            # 表示当前没有找到增广路径
            return False

        # 否则确认了增广路径 根据记录不断反转增广路径上的匹配和非匹配边
        while right_index is not None:
            # 将非匹配边变为匹配边
            self.match_y[right_index] = self.prev[right_index]
            # 将原匹配边的左集合点加入到另一条匹配边
            tmp_index = self.match_x[self.prev[right_index]]
            self.match_x[self.prev[right_index]] = right_index
            # 变为原匹配边的右集合点 进行下一次反转 该右集合点也会在prev中记录相应的可反转的非匹配边
            right_index = tmp_index

        # 表示当前已找到增广路径 并完成反转
        return True

def bfs_match():
    """测试入口
    """
    h = oj_data_load()
    score = h.solve()
    #print("{}".format(match_num))
    #for left_index, right_index in enumerate(left_match):
    #    print("{} {}".format(left_index+1, 0 if right_index is None else right_index+1))


def local_load(lines):
    """本地读取
    """
    edges = None
    for index, line in enumerate(lines.strip("\n").split("\n")):
        parts = line.strip("\n").split()
        if index == 0:
            right_node_num = int(parts[0])
            left_node_num = int(parts[1])
            edges = [[0] * right_node_num for _ in range(left_node_num)]
        else:
            left_node_id = int(parts[0]) - 1
            right_node_id = int(parts[1]) - 1
            edges[left_node_id][right_node_id] = 1
    return edges


def oj_data_load():
    """读取数据
    """
    left_node_num, right_node_num, edge_num = map(int, sys.stdin.readline().strip().split())
    h = KMBFS(left_node_num, right_node_num)

    for _ in range(edge_num):
        left_node, right_node, weight = map(int, sys.stdin.readline().strip().split())
        h.add_edge(left_node, right_node, weight)

    return h


if __name__ == "__main__":
    bfs_match()
