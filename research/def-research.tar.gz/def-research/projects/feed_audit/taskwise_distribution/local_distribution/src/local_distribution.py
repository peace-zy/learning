#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   local_distribution.py
Author:   zhanghao55@baidu.com
Date  :   21/07/06 10:48:49
Desc  :   
"""

import os
import sys
import codecs
import logging
import time

from tqdm import tqdm
from collections import defaultdict
from local_distribution_strategy import DistributionStrategyV1
from local_distribution_strategy_v2 import DistributionStrategyV2
from local_distribution_strategy_v3 import DistributionStrategyV3
from local_distribution_strategy_v4 import DistributionStrategyV4
from local_distribution_strategy_v5 import DistributionStrategyV5
from local_distribution_strategy_v6 import DistributionStrategyV6
from local_distribution_strategy_v7 import DistributionStrategyV7

from run_arguments import parse_args
from utils import ADAuditData, ADFeature, TaskFeature, TaskMatrix, AuditorFeature, AuditorMatrix

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../../../" % _cur_dir)
from lib.common.logger import init_log

init_log()


def main():
    """将指定文件的审核任务分配给指定auditor_num个审核员
    """
    config = parse_args()

    distribute_strategy = {
            "default": DistributionStrategyV1,
            "v1": DistributionStrategyV1,
            "v2": DistributionStrategyV2,
            "v3": DistributionStrategyV3,
            "v4": DistributionStrategyV4,
            "v5": DistributionStrategyV5,
            "v6": DistributionStrategyV6,
            "v7": DistributionStrategyV7,
            }[config.distribution_version](config)

    # 生成matrix
    matrix_dict = gen_matrix(
            task_path=config.task_path,
            auditor_num=config.auditor_num,
            )
    task_matrix = matrix_dict["task_matrix"]
    auditor_matrix = matrix_dict["auditor_matrix"]
    audit_data_dict = matrix_dict["audit_data_dict"]
    task_audit_data_dict = matrix_dict["task_audit_data_dict"]

    # 分配任务 直到待审task为空
    # 记录当前请求批数
    request_id = 0
    # 保存分配记录
    auditor_data_uid_dict = defaultdict(list)
    # 统计任务和物料维度各行业的统计信息
    auditor_task_trade_count_dict = defaultdict(lambda: defaultdict(int))
    auditor_data_trade_count_dict = defaultdict(lambda: defaultdict(int))
    task_trade_total_count_dict = defaultdict(int)
    data_trade_total_count_dict = defaultdict(int)

    distributed_time = 0
    dist_time = 0
    ad_sort_time = 0
    while task_matrix.size() > 0:
        logging.info("request #{}".format(request_id))
        # 每个审核员都请求指定audit_batch_size个任务
        for cur_auditor_feature in auditor_matrix:
            cur_auditor_feature.request_num = config.audit_batch_size
        dist_start_time = time.time()
        cur_distribute_res_list, new_auditor_matrix_dict = distribute_strategy.distribute(
                task_matrix,
                auditor_matrix
                )
        dist_time += time.time() - dist_start_time
        request_id += 1

        # 更新审核员矩阵
        auditor_matrix.update(new_auditor_matrix_dict)

        # 处理分配结果
        # 记录当前分配出去的task_uid 之后从task_matrix中去除
        distributed_task_uid_list = list()
        for cur_auditor_uid, cur_task_uid in cur_distribute_res_list:
            # 遍历每个审核员分配到的每个任务
            # 更新已分配的task_uid列表
            distributed_task_uid_list.append(cur_task_uid)
            # 获得当前分配的task_feature
            cur_task_feature = task_matrix[cur_task_uid]
            # 任务下的物料排序 得到排序后的audit_data_uid列表
            ad_sort_start_time = time.time()
            sorted_audit_data_uid_list = distribute_strategy.ad_sort(cur_task_feature)
            ad_sort_time += time.time() - ad_sort_start_time
            # 记录当前任务 物料属于哪个行业标签
            cur_first_trade = None
            for cur_audit_data_uid in sorted_audit_data_uid_list:
                # 各任务的chosen_info转移到各物料
                audit_data_dict[cur_audit_data_uid].chosen_info = cur_task_feature.chosen_info
                audit_data_dict[cur_audit_data_uid].distributed_time = distributed_time
                distributed_time += 1
                # 记录分配结果
                auditor_data_uid_dict[cur_auditor_uid].append(cur_audit_data_uid)
                # 更新行业统计信息
                if cur_first_trade is None:
                    cur_audit_data = audit_data_dict[cur_audit_data_uid]
                    cur_first_trade = cur_audit_data.label_list[0] if len(cur_audit_data.label_list) > 0 else "空"
                    auditor_task_trade_count_dict[cur_auditor_uid][cur_first_trade] += 1
                    task_trade_total_count_dict[cur_first_trade] += 1
                auditor_data_trade_count_dict[cur_auditor_uid][cur_first_trade] += 1
                data_trade_total_count_dict[cur_first_trade] += 1

        # 移除已分配任务
        task_matrix.remove(distributed_task_uid_list)

    logging.info("distribute time: {:.4f}s, ad sort: {:.4f}s".format(dist_time, ad_sort_time))

    # 记录分配结果
    with codecs.open(config.distribution_res_path, "w", "utf-8") as wf:
        for cur_auditor_uid, audit_data_uid_list in auditor_data_uid_dict.items():
            for cur_audit_data_uid in audit_data_uid_list:
                cur_audit_data = audit_data_dict[cur_audit_data_uid]
                wf.write("\t".join([
                    str(cur_auditor_uid),
                    cur_audit_data.task_uid,
                    cur_audit_data.userid,
                    cur_audit_data.ad_id,
                    "\x01".join(cur_audit_data.text_list),
                    "\x01".join(cur_audit_data.image_url_list),
                    "|||".join([str(x) for x in cur_audit_data.text_clusters]),
                    "|||".join([str(x) for x in cur_audit_data.image_clusters]),
                    "|||".join(cur_audit_data.risk_list),
                    "|||".join(cur_audit_data.label_list),
                    str(cur_audit_data.in_time),
                    str(cur_audit_data.distributed_time),
                    cur_audit_data.chosen_info,
                    ]) + "\n")

    # 打印给审核员分配的结果
    with codecs.open(config.distribution_info_path, "w", "utf-8") as wf:
        # 任务级别的各行业占比
        wf.write("="*150 + "\n")
        wf.write("任务级别各行业分布占比：\n")
        for cur_auditor_uid, cur_trade_count_dict in auditor_task_trade_count_dict.items():
            total_count = 0
            trade_ratio_info = list()
            for cur_trade, cur_count in sorted(cur_trade_count_dict.items(), key=lambda x:x[1], reverse=True):
                total_count += cur_count
                trade_ratio_info.append("{}[{}/{:.2f}%]".format(
                    cur_trade,
                    cur_count,
                    cur_count * 100 / float(task_trade_total_count_dict[cur_trade]),
                    ))
            wf.write("auditor uid = {}, num = {}: {}".format(
                cur_auditor_uid,
                total_count,
                trade_ratio_info
                ) + "\n")
        # 物料级别的各行业占比
        wf.write("="*150 + "\n")
        wf.write("物料级别各行业分布占比：\n")
        for cur_auditor_uid, cur_trade_count_dict in auditor_data_trade_count_dict.items():
            total_count = 0
            trade_ratio_info = list()
            for cur_trade, cur_count in sorted(cur_trade_count_dict.items(), key=lambda x:x[1], reverse=True):
                total_count += cur_count
                trade_ratio_info.append("{}[{}/{:.2f}%]".format(
                    cur_trade,
                    cur_count,
                    cur_count * 100 / float(data_trade_total_count_dict[cur_trade]),
                    ))
            wf.write("auditor uid = {}, num = {}: {}".format(
                cur_auditor_uid,
                total_count,
                trade_ratio_info
                ) + "\n")

def gen_matrix(task_path, auditor_num):
    #text_cluster_max_id = 0
    #image_cluster_max_id = 0
    label_index_dict = dict()
    risk_index_dict = dict()

    audit_data_dict = dict()
    with codecs.open(task_path, "r", "gb18030") as rf:
        for line in tqdm(rf, desc="load audit data"):
            cur_audit_data = ADAuditData.init_from_json(line.strip("\n"))
            cur_audit_data.text_list = [ x for x in cur_audit_data.text_list if len(x) > 0]
            audit_data_dict[cur_audit_data.uid] = cur_audit_data
            #for cur_text_cluster in cur_audit_data.text_clusters:
            #    if cur_text_cluster > text_cluster_max_id:
            #        text_cluster_max_id = cur_text_cluster
            #for cur_image_cluster in cur_audit_data.image_clusters:
            #    if cur_image_cluster > image_cluster_max_id:
            #        image_cluster_max_id = cur_image_cluster
            for cur_label in cur_audit_data.label_list:
                if cur_label not in label_index_dict:
                    label_index_dict[cur_label] = len(label_index_dict)
            for cur_risk in cur_audit_data.risk_list:
                if cur_risk not in risk_index_dict:
                    risk_index_dict[cur_risk] = len(risk_index_dict)

    dim_params = {
            "text_dim": 2000,
            "image_dim": 2000,
            #"text_dim": text_cluster_max_id + 1,
            #"image_dim": image_cluster_max_id + 1,
            "label_dim": len(label_index_dict),
            "risk_dim": len(risk_index_dict),
            }

    # 任务矩阵
    task_audit_data_dict = defaultdict(list)
    task_matrix = TaskMatrix()
    for cur_audit_data in tqdm(audit_data_dict.values(), desc="load task matrix"):
        #logging.info("cur_audit_data: {}".format(cur_audit_data.text_vec_list))
        task_audit_data_dict[cur_audit_data.task_uid].append(cur_audit_data.uid)
        cur_ad_feature = ADFeature(
                audit_data=cur_audit_data,
                label_index_dict=label_index_dict,
                risk_index_dict=risk_index_dict,
                **dim_params,
                )
        if cur_audit_data.task_uid not in task_matrix:
            new_task_feature = TaskFeature(
                    cur_audit_data.task_uid,
                    **dim_params,
                    )
            task_matrix.append(new_task_feature)

        cur_task_feature = task_matrix[cur_audit_data.task_uid]
        cur_task_feature.append(cur_ad_feature)

    # 根据各维度的大小 创立审核员矩阵
    auditor_matrix = AuditorMatrix()
    for auditor_id in range(auditor_num):
        new_auditor = AuditorFeature(
                uid=auditor_id,
                **dim_params,
                )
        auditor_matrix.append(new_auditor)

    return {
        "task_matrix": task_matrix,
        "auditor_matrix": auditor_matrix,
        "audit_data_dict": audit_data_dict,
        "task_audit_data_dict": task_audit_data_dict,
        }


if __name__ == "__main__":
    main()
