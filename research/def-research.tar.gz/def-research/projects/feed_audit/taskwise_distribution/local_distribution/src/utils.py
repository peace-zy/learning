#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   utils.py
Author:   zhanghao55@baidu.com
Date  :   21/07/06 10:58:52
Desc  :   
"""

import copy
import json
import logging
import numpy as np
import numpy.ma as ma
import uuid
from sklearn.metrics import pairwise_distances
from sklearn.cluster import AgglomerativeClustering


class CustomizedForJson(object):
    """可以被json dumps loads的基础类
    """
    @classmethod
    def init_from_json(cls, init_json):
        """从json字符串初始化
        """
        # 因为直接从json串初始化 所以这里可以直接用json.loads得到的字典而不需要copy
        return cls.init_from_dict(json.loads(init_json), zero_copy=True)

    @classmethod
    def init_from_dict(cls, init_dict, zero_copy=True):
        """从dict初始化
        [in]  init_dict：dict，初始化字典
              zero_copy：bool，是否与audit_data_dict中各值同步更新
           若zero_copy为True，则与init_dict给的数据共享内存
           其他地方对init_dict中的数据进行修改时，也会影响到共享给本类的数据
        """
        if not zero_copy:
            init_dict = {k: copy.deepcopy(v) for k, v in init_dict.items()}
        return cls(**init_dict)

    def to_dict(self):
        """转字典
        """
        return vars(self)

    def to_json(self):
        """转json
        """
        return json.dumps(self.to_dict())

    def __repr__(self):
        return self.to_str(sep="\n")

    def to_str(self, sep="\t"):
        """转为str
        """
        raise NotImplementedError


def record_matrix_expand(tar_matrix, row_size=None, col_size=None, mask_matrix=False):
    """将目标矩阵维度扩展至指定大小
    """
    if tar_matrix is None:
        tar_matrix = np.zeros((0, 0))
        if mask_matrix:
            tar_matrix = ma.array(tar_matrix, mask=False)

    if row_size is not None:
        row_diff = row_size - tar_matrix.shape[0]
        if row_diff > 0:
            if mask_matrix:
                tar_matrix = ma.row_stack((
                    tar_matrix,
                    ma.array(np.zeros((row_diff, tar_matrix.shape[1])), mask=False),
                    ))
            else:
                tar_matrix = np.row_stack((
                    tar_matrix,
                    np.zeros((row_diff, tar_matrix.shape[1])),
                    ))

    if col_size is not None:
        col_diff = col_size - tar_matrix.shape[1]
        if col_diff > 0:
            if mask_matrix:
                tar_matrix = ma.column_stack((
                    tar_matrix,
                    ma.array(np.zeros((tar_matrix.shape[0], col_diff)), mask=False),
                    ))
            else:
                tar_matrix = np.column_stack((
                    tar_matrix,
                    np.zeros((tar_matrix.shape[0], col_diff)),
                    ))
    return tar_matrix


def update_record(id_list, id_size, high_sim_matrix=None):
    """根据当前物料 更新该任务各统计矩阵信息
    """
    # 初始化时就给各矩阵列数了
    cur_record = np.zeros((id_size))

    # 根据当前数据的label 增加计数
    for cur_id in id_list:
        if high_sim_matrix is None:
            cur_record[cur_id] += 1
        else:
            cur_record += high_sim_matrix[cur_id]

    return cur_record


class TaskV2(CustomizedForJson):
    """任务
    """
    def __init__(self,
            uid=None,
            userid=None,
            audit_data_id_list=None,
            earliest_in_time=None,
            chosen_info=None,
            label_id_dict=None,
            risk_id_dict=None,
            text_high_sim_matrix=None,
            image_high_sim_matrix=None,
            ):
        super(TaskV2, self).__init__()
        self.uid = str(uuid.uuid1()) if uid is None else uid
        self.userid = userid
        self.audit_data_id_list = list() if audit_data_id_list is None else audit_data_id_list
        self.label_id_dict = label_id_dict
        self.risk_id_dict = risk_id_dict
        self.text_high_sim_matrix = text_high_sim_matrix
        self.image_high_sim_matrix = image_high_sim_matrix

        self.text_cluster_count = np.zeros((1, text_high_sim_matrix.shape[1]))
        self.image_cluster_count = np.zeros((1, image_high_sim_matrix.shape[1]))
        self.label_count = np.zeros((1, len(label_id_dict)))
        self.risk_count = np.zeros((1, len(risk_id_dict)))

        self.text_cluster_record_list = list()
        self.image_cluster_record_list = list()
        self.label_record_list = list()
        self.risk_record_list = list()
        self.text_image_count_record_list = list()

        self.earliest_in_time = earliest_in_time
        self.chosen_info = "" if chosen_info is None else chosen_info
        self.text_count = 0
        self.image_count = 0

    def to_str(self, sep="\t"):
        return sep.join([
            "uid: {}".format(self.uid),
            "userid: {}".format(self.userid),
            "audit_data_id_list: {}".format(self.audit_data_id_list),
            "text_cluster_record: {}".format(self.text_cluster_record),
            "image_cluster_record: {}".format(self.image_cluster_record),
            "label_record: {}".format(self.label_record),
            "risk_record: {}".format(self.risk_record),
            "earliest_in_time: {}".format(self.earliest_in_time),
            "chosen_info: {}".format(self.chosen_info),
            "text_count: {}".format(self.text_count),
            "image_count: {}".format(self.image_count),
            ])

    def add_audit_data(self, audit_data, with_high_sim=True):
        """添加审核数据信息
        """
        #logging.info("text_high_sim_matrix shape: {}".format(text_high_sim_matrix.shape))
        self.audit_data_id_list.append(audit_data.uid)
        audit_data.task_uid = self.uid

        def add_record(id_list, tar_count=None, tar_record_list=None, high_sim_matrix=None):
            """根据当前物料 更新该任务各统计矩阵信息
            """
            if with_high_sim:
                increasement_record = update_record(id_list, tar_count.shape[1], high_sim_matrix)
            else:
                increasement_record = update_record(id_list, tar_count.shape[1])

            if tar_count is not None:
                tar_count[0] += increasement_record

            if tar_record_list is not None:
                tar_record_list.append(increasement_record.reshape((1, -1)))

        # 记录label信息
        if self.label_id_dict is not None:
            label_id_list = [self.label_id_dict[x] for x in audit_data.label_list]
            add_record(label_id_list, self.label_count, self.label_record_list)

        # 记录risk信息
        if self.risk_id_dict is not None:
            risk_id_list = [self.risk_id_dict[x] for x in audit_data.risk_list]
            add_record(risk_id_list, self.risk_count, self.risk_record_list)

        # 记录text_cluster信息
        add_record(
                audit_data.text_clusters,
                self.text_cluster_count,
                self.text_cluster_record_list,
                self.text_high_sim_matrix,
                )
        self.text_count += len(audit_data.text_clusters)

        # 记录image_cluster信息
        add_record(
                audit_data.image_clusters,
                self.image_cluster_count,
                self.image_cluster_record_list,
                self.image_high_sim_matrix,
                )
        self.image_count += len(audit_data.image_clusters)

        self.text_image_count_record_list.append(
                np.array([[len(audit_data.text_clusters), len(audit_data.image_clusters)]]))

        if self.earliest_in_time is None or audit_data.in_time < self.earliest_in_time:
            self.earliest_in_time = audit_data.in_time

    def sim_sort(self):
        """对任务下的物料根据相似程度进行聚合排序
        """
        # 根据各物料特征 在任务下对相似物料聚合
        def cal_distance(record_list):
            """计算各物料指定维度的余弦距离
            """
            try:
                record_distance = pairwise_distances(np.concatenate(record_list, axis=0), metric="cosine")
            except ValueError as e:
                logging.warning(e)
                # 失败则距离矩阵全为0
                record_distance = np.zeros((len(self.audit_data_id_list), len(self.audit_data_id_list)))
            return record_distance

        def combine(children_list):
            """合并给定的各子树
            """
            # 因为该树是层次聚类所得 子树内各节点距离一定小于子树间的距离
            # 所以合并子树各节点时 这里不需要考虑两子树各节点间哪组距离最近
            # 为适应审核习惯 将节点更多的子树放在前面
            res_list = list()
            for cur_children in sorted(children_list, key=lambda x:len(x), reverse=True):
                res_list.extend(cur_children)
            return res_list

        def sort_children(children_list, leaf_num):
            """根据层次聚类结果为物料排序
            """
            tree_dict = dict()
            # 叶子节点
            for cur_ind in range(leaf_num):
                tree_dict[cur_ind] = [cur_ind]
            # 聚合
            for cur_ind, cur_children in enumerate(children_list):
                #print("tree_dict: {}".format(tree_dict))
                cur_id = leaf_num + cur_ind
                #print("cur_id: {}".format(cur_ind))
                #print("cur_children: {}".format(cur_children))
                #print("="*100)
                cur_list = list()
                for cur_child in cur_children:
                    cur_list.append(tree_dict[cur_child])
                    del tree_dict[cur_child]
                tree_dict[cur_id] = combine(cur_list)
            assert len(tree_dict) == 1, "tree_dict size = {}: {}".format(len(tree_dict), tree_dict)
            return combine(tree_dict.values())

        if len(self.audit_data_id_list) > 2:
            # TODO 当前任务下 实际label都一样 没必要计算其相似距离 但当前效率没有影响 因此保留
            label_distance = cal_distance(self.label_record_list)
            #logging.info("label_distance: {}".format(label_distance))
            risk_distance = cal_distance(self.risk_record_list)
            #logging.info("risk_distance: {}".format(risk_distance))
            text_cluster_distance = cal_distance(self.text_cluster_record_list)
            #logging.info("text_cluster_distance: {}".format(text_cluster_distance))
            image_cluster_distance = cal_distance(self.image_cluster_record_list)
            #logging.info("image_cluster_distance: {}".format(image_cluster_distance))
            # 记录各物料的文本和图片数 当前计算在区分纯文本和纯图片上有效果 混杂文本和图片的还需要测试
            text_image_count_distance = cal_distance(self.text_image_count_record_list)
            #logging.info("text_image_count_distance: {}".format(text_image_count_distance))

            # TODO 当前设定各方面距离权重一致 之后可能需要调整
            distance_matrix = (text_image_count_distance + label_distance + risk_distance + \
                    text_cluster_distance + image_cluster_distance) / 5.0
            #logging.info("distance_matrix: {}".format(distance_matrix))
            #logging.info("distance_matrix shape: {}".format(distance_matrix.shape))

            model = AgglomerativeClustering(affinity="precomputed", linkage="complete")
            model.fit(distance_matrix)
            sort_ind = sort_children(model.children_, leaf_num=distance_matrix.shape[0])
            sorted_audit_data_id_list = [self.audit_data_id_list[x] for x in sort_ind]
        else:
            sorted_audit_data_id_list = self.audit_data_id_list

        return sorted_audit_data_id_list

    def __eq__(self, other):
        """确保物料维度无完全重复
        """
        if isinstance(other, TaskV2):
            return self.uid == other.uid
        else:
            return False


class ADAuditData(CustomizedForJson):
    """审核数据类
    """
    def __init__(self,
            uid=None,
            userid=None,
            task_uid=None,
            ad_id=None,
            text_list=None,
            image_url_list=None,
            text_vec_list=None,
            image_vec_list=None,
            text_clusters=None,
            image_clusters=None,
            label_list=None,
            risk_list=None,
            distributed_num=None,
            left_num=None,
            audit_res_list=None,
            in_time=None,
            distributed_time=None,
            audit_end_time=None,
            chosen_info=None,
            ):
        super(ADAuditData, self).__init__()
        self.uid = str(uuid.uuid1()) if uid is None else uid
        self.userid = userid
        self.ad_id = ad_id
        self.task_uid = task_uid
        self.text_list = list() if text_list is None else text_list
        self.image_url_list = list() if image_url_list is None else image_url_list
        self.text_vec_list = list() if text_vec_list is None else text_vec_list
        self.image_vec_list = list() if image_vec_list is None else image_vec_list
        self.text_clusters = list() if text_clusters is None else text_clusters
        self.image_clusters = list() if image_clusters is None else image_clusters
        self.label_list = list() if label_list is None else label_list
        # 物料实际风险
        self.risk_list = list() if risk_list is None else risk_list
        self.distributed_num = distributed_num
        self.left_num = left_num
        self.audit_res_list = audit_res_list
        self.in_time = in_time
        self.distributed_time = distributed_time
        self.audit_end_time = audit_end_time
        self.chosen_info = "" if chosen_info is None else chosen_info

    def to_str(self, sep="\t"):
        return sep.join([
            "uid: {}".format(self.uid),
            "userid: {}".format(self.userid),
            "ad_id: {}".format(self.ad_id),
            "task_uid: {}".format(self.task_uid),
            "text_list: {}".format(self.text_list),
            "image_url_list: {}".format(self.image_url_list),
            "text_clusters: {}".format(self.text_clusters),
            "image_clusters: {}".format(self.image_clusters),
            "risk_list: {}".format(self.risk_list),
            "distributed_num: {}".format(self.distributed_num),
            "left_num: {}".format(self.left_num),
            "audit_res_list: {}".format(self.audit_res_list),
            "in_time: {}".format(self.in_time),
            "distributed_time: {}".format(self.distributed_time),
            "audit_end_time: {}".format(self.audit_end_time),
            "chosen_info: {}".format(self.chosen_info),
            ])

    def __eq__(self, other):
        """确保物料维度无完全重复
        """
        if isinstance(other, ADAuditData):
            return self.uid == other.uid
        else:
            return False

    def __lt__(self, other):
        """heapq排序时需要
        """
        if isinstance(other, ADAuditData):
            return self.in_time < other.in_time
        else:
            raise ValueError("'<' not supported between instances of {} and {}".format(type(self), type(other)))


class BaseFeature(object):
    """基础信息向量
    """
    def __init__(self,
            text_vec_list=None,
            image_vec_list=None,
            text_dim=None,
            image_dim=None,
            label_dim=None,
            risk_dim=None,
            ):
        self.text_feature = None
        self.image_feature = None
        self.label_feature = None
        self.risk_feature = None
        self.image_vec_list = list() if text_vec_list is None else text_vec_list
        self.text_vec_list = list() if image_vec_list is None else image_vec_list
        self.set_text_feature_dim(text_dim)
        self.set_image_feature_dim(image_dim)
        self.set_label_feature_dim(label_dim)
        self.set_risk_feature_dim(risk_dim)

    def set_text_feature_dim(self, text_dim):
        """设置文本类信息向量
        """
        self.text_feature = record_matrix_expand(
                self.text_feature,
                row_size=1,
                col_size=text_dim,
                mask_matrix=False)

    def set_image_feature_dim(self, image_dim):
        """设置图片类信息向量
        """
        self.image_feature = record_matrix_expand(
                self.image_feature,
                row_size=1,
                col_size=image_dim,
                mask_matrix=False)

    def set_label_feature_dim(self, label_dim):
        """设置标签类信息向量
        """
        self.label_feature = record_matrix_expand(
                self.label_feature,
                row_size=1,
                col_size=label_dim,
                mask_matrix=False)

    def set_risk_feature_dim(self, risk_dim):
        """设置风险类信息向量
        """
        self.risk_feature = record_matrix_expand(
                self.risk_feature,
                row_size=1,
                col_size=risk_dim,
                mask_matrix=False)

    def add_feature(self, other):
        """指定信息向量加和到自身
        """
        assert isinstance(other, BaseFeature)
        def single_feature_add(tar_feature, src_feature):
            """单维度信息向量的加和
            """
            if tar_feature is None:
                tar_feature = copy.deepcopy(src_feature)
            else:
                tar_feature += src_feature
            return tar_feature
        self.text_vec_list.extend(other.text_vec_list)
        self.text_vec_list.extend(other.text_vec_list)
        self.text_feature = single_feature_add(self.text_feature, other.text_feature)
        self.image_feature = single_feature_add(self.image_feature, other.image_feature)
        self.label_feature = single_feature_add(self.label_feature, other.label_feature)
        self.risk_feature = single_feature_add(self.risk_feature, other.risk_feature)

def combine_vec(vec_list, method="mean"):
    if len(vec_list) == 0:
        vec_res = np.zeros((1, 128))
    else:
        vec_res = getattr(np, method)(np.array(vec_list), axis=0).reshape((1, -1))
    #logging.info("vec_list size: {}".format(len(vec_list)))
    #logging.info("vec_list[0] type: {}".format(type(vec_list[0])))
    return vec_res

    #def get_text_vec(self, method="mean"):
    #    return self._combine_vec(self.text_vec_list, method)

    #def get_image_vec(self, method="mean"):
    #    return self._combine_vec(self.image_vec_list, method)

def update_vec(update_vec_list, cur_vec=None, cur_size=None, method="mean"):
    if cur_vec is None:
        new_vec_list = update_vec_list
    elif method == "mean":
        assert cur_size is not None, "cur_size is required when update vec by method 'mean'"
        new_vec_list = update_vec_list + ([cur_vec] * cur_size)
    elif method == "max":
        new_vec_list = update_vec_list + [cur_vec]
    elif method == "sum":
        new_vec_list = update_vec_list + [cur_vec]
    
    return combine_vec(new_vec_list, method)


def norm(tar_matrix):
    norm_tar_matrix = tar_matrix / np.sqrt((tar_matrix * tar_matrix).sum(axis=-1, keepdims=True))
    return norm_tar_matrix


class ADFeature(BaseFeature):
    """物料信息向量
    """
    def __init__(self, audit_data, label_index_dict, risk_index_dict, **kwargs):
        super(ADFeature, self).__init__(
            text_vec_list=audit_data.text_vec_list,
            image_vec_list=audit_data.image_vec_list,
            **kwargs,
        )
        self.uid = audit_data.uid
        self.in_time = audit_data.in_time
        self.text_count = 0
        self.image_count = 0

        def add_record(id_list, tar_feature=None, id_dict=None):
            """根据当前物料 更新该任务各统计矩阵信息
            """
            if id_dict is not None:
                id_list = [id_dict[x] for x in id_list]
            inc_record = update_record(id_list, tar_feature.shape[1])
            tar_feature[0] += inc_record

        # 更新text_feature
        add_record(audit_data.text_clusters, self.text_feature)
        # 更新image_feature
        add_record(audit_data.image_clusters, self.image_feature)
        # 更新label_list
        add_record(audit_data.label_list, self.label_feature, label_index_dict)
        # 更新risk_list
        add_record(audit_data.risk_list, self.risk_feature, risk_index_dict)

        # 更新物料中类型的数目
        self.text_count = len([x for x in audit_data.text_list if len(x) > 0])
        self.image_count = len(audit_data.image_url_list)


class TaskFeature(BaseFeature):
    """任务信息向量
    """
    def __init__(self, uid, **kwargs):
        super(TaskFeature, self).__init__(**kwargs)
        self.uid = uid
        self.ad_feature_list = list()
        self.earliest_in_time = None
        self.text_count = 0
        self.image_count = 0
        self.chosen_info = ""

    def append(self, ad_feature):
        """添加
        """
        self.ad_feature_list.append(ad_feature)
        if self.earliest_in_time is None or self.earliest_in_time > ad_feature.in_time:
            self.earliest_in_time = ad_feature.in_time
        self.add_feature(ad_feature)
        self.text_count += ad_feature.text_count
        self.image_count += ad_feature.image_count
    
    def make_matrix(self):
        """生成各维度矩阵
        """
        text_feature_list = list()
        image_feature_list = list()
        text_vec_feature_list = list()
        image_vec_feature_list = list()
        label_feature_list = list()
        risk_feature_list = list()
        text_image_count_list = list()
        ad_uid_list = list()

        for cur_ad_feature in self.ad_feature_list:
            # TODO 添加text_vec_list
            text_feature_list.append(cur_ad_feature.text_feature)
            image_feature_list.append(cur_ad_feature.image_feature)
            text_vec_feature_list.append(combine_vec(cur_ad_feature.text_vec_list))
            image_vec_feature_list.append(combine_vec(cur_ad_feature.image_vec_list))
            label_feature_list.append(cur_ad_feature.label_feature)
            risk_feature_list.append(cur_ad_feature.risk_feature)
            text_image_count_list.append((
                cur_ad_feature.text_count,
                cur_ad_feature.image_count,
                ))
            ad_uid_list.append(cur_ad_feature.uid)

        text_feature_matrix = np.concatenate(text_feature_list, axis=0)
        image_feature_matrix = np.concatenate(image_feature_list, axis=0)
        text_vec_feature_matrix = np.concatenate(text_vec_feature_list, axis=0)
        image_vec_feature_matrix = np.concatenate(image_vec_feature_list, axis=0)
        label_feature_matrix = np.concatenate(label_feature_list, axis=0)
        risk_feature_matrix = np.concatenate(risk_feature_list, axis=0)
        text_image_count_matrix = np.array(text_image_count_list)

        return {
                "text_feature_matrix": text_feature_matrix,
                "image_feature_matrix": image_feature_matrix,
                "text_vec_feature_matrix": text_vec_feature_matrix,
                "image_vec_feature_matrix": image_vec_feature_matrix,
                "label_feature_matrix": label_feature_matrix,
                "risk_feature_matrix": risk_feature_matrix,
                "text_image_count_matrix": text_image_count_matrix,
                "ad_uid_list": ad_uid_list,
                }

    def size(self):
        """大小
        """
        return len(self.ad_feature_list)

class TaskMatrix(object):
    """任务信息矩阵
    """
    def __init__(self):
        self.task_feature_list = list()
        self.task_feature_dict = dict()

    def make_matrix(self):
        """生成各维度矩阵
        """
        text_feature_list = list()
        image_feature_list = list()
        text_vec_feature_list = list()
        image_vec_feature_list = list()
        text_vec_list_list = list()
        image_vec_list_list = list()
        label_feature_list = list()
        risk_feature_list = list()
        wait_time_list = list()
        text_count_list = list()
        image_count_list = list()
        task_uid_list = list()
        # 找出待审任务最晚的进入时间
        latest_time = None
        for cur_task_feature in self.task_feature_list:
            if latest_time is None or latest_time < cur_task_feature.earliest_in_time:
                latest_time = cur_task_feature.earliest_in_time

        for cur_task_feature in self.task_feature_list:
            text_feature_list.append(cur_task_feature.text_feature)
            image_feature_list.append(cur_task_feature.image_feature)
            label_feature_list.append(cur_task_feature.label_feature)
            risk_feature_list.append(cur_task_feature.risk_feature)
            text_vec_feature_list.append(combine_vec(cur_task_feature.text_vec_list))
            image_vec_feature_list.append(combine_vec(cur_task_feature.image_vec_list))
            text_vec_list_list.append(cur_task_feature.text_vec_list)
            image_vec_list_list.append(cur_task_feature.image_vec_list)
            wait_time_list.append(latest_time - cur_task_feature.earliest_in_time)
            text_count_list.append(cur_task_feature.text_count)
            image_count_list.append(cur_task_feature.image_count)
            task_uid_list.append(cur_task_feature.uid)

        text_feature_matrix = np.concatenate(text_feature_list, axis=0)
        image_feature_matrix = np.concatenate(image_feature_list, axis=0)
        text_vec_feature_matrix = np.concatenate(text_vec_feature_list, axis=0)
        image_vec_feature_matrix = np.concatenate(image_vec_feature_list, axis=0)
        label_feature_matrix = np.concatenate(label_feature_list, axis=0)
        risk_feature_matrix = np.concatenate(risk_feature_list, axis=0)
        wait_time_matrix = np.array(wait_time_list).reshape((-1, 1))
        text_count_matrix = np.array(text_count_list).reshape((-1, 1))
        image_count_matrix = np.array(image_count_list).reshape((-1, 1))


        return {
                "text_feature_matrix": text_feature_matrix,
                "image_feature_matrix": image_feature_matrix,
                "text_vec_feature_matrix": text_vec_feature_matrix,
                "image_vec_feature_matrix": image_vec_feature_matrix,
                "label_feature_matrix": label_feature_matrix,
                "risk_feature_matrix": risk_feature_matrix,
                "wait_time_matrix": wait_time_matrix,
                "text_count_matrix": text_count_matrix,
                "image_count_matrix": image_count_matrix,
                "text_vec_list_list": text_vec_list_list,
                "image_vec_list_list": image_vec_list_list,
                "task_uid_list": task_uid_list,
                }

    def append(self, task_feature):
        """添加
        """
        assert task_feature.uid not in self.task_feature_dict
        self.task_feature_list.append(task_feature)
        self.task_feature_dict[task_feature.uid] = task_feature

    def remove(self, task_uids):
        """移除
        """
        if isinstance(task_uids, list) or isinstance(task_uids, tuple):
            task_uids = set(task_uids)
        else:
            task_uids = set([task_uids])

        self.task_feature_list = [x for x in self.task_feature_list if x.uid not in task_uids]
        for cur_task_uid in task_uids:
            del self.task_feature_dict[cur_task_uid]

    def at(self, index):
        """索引
        """
        return self.task_feature_list[index]

    def __contains__(self, task_uid):
        return task_uid in self.task_feature_dict

    def __getitem__(self, task_uid):
        return self.task_feature_dict[task_uid]

    def size(self):
        """大小
        """
        return len(self.task_feature_list)


class AuditorFeature(BaseFeature):
    """审核员信息向量
    """
    def __init__(self, uid, **kwargs):
        super(AuditorFeature, self).__init__(**kwargs)
        self.uid = uid
        self.request_num = 0
        self.available_index = None


class AuditorMatrix(object):
    """审核员矩阵
    """
    def __init__(self):
        self.auditor_feature_list = list()
        self.auditor_feature_dict = dict()

    def make_matrix(self):
        """生成各维度矩阵
        """
        text_feature_list = list()
        image_feature_list = list()
        text_vec_list_list = list()
        image_vec_list_list = list()
        text_vec_feature_list = list()
        image_vec_feature_list = list()
        label_feature_list = list()
        risk_feature_list = list()
        auditor_uid_list = list()
        auditor_request_num_list = list()
        auditor_availabel_index_list = list()

        for cur_auditor_feature in self.auditor_feature_list:
            text_feature_list.append(cur_auditor_feature.text_feature)
            image_feature_list.append(cur_auditor_feature.image_feature)
            text_vec_list_list.append(cur_auditor_feature.text_vec_list)
            image_vec_list_list.append(cur_auditor_feature.image_vec_list)
            text_vec_feature_list.append(combine_vec(cur_auditor_feature.text_vec_list))
            image_vec_feature_list.append(combine_vec(cur_auditor_feature.image_vec_list))
            label_feature_list.append(cur_auditor_feature.label_feature)
            risk_feature_list.append(cur_auditor_feature.risk_feature)
            auditor_uid_list.append(cur_auditor_feature.uid)
            auditor_request_num_list.append(cur_auditor_feature.request_num)
            auditor_availabel_index_list.append(cur_auditor_feature.available_index)

        text_feature_matrix  = np.concatenate(text_feature_list, axis=0)
        image_feature_matrix = np.concatenate(image_feature_list, axis=0)
        text_vec_feature_matrix = np.concatenate(text_vec_feature_list, axis=0)
        image_vec_feature_matrix = np.concatenate(image_vec_feature_list, axis=0)
        label_feature_matrix = np.concatenate(label_feature_list, axis=0)
        risk_feature_matrix  = np.concatenate(risk_feature_list, axis=0)

        return {
                "text_feature_matrix": text_feature_matrix,
                "image_feature_matrix": image_feature_matrix,
                "text_vec_feature_matrix": text_vec_feature_matrix,
                "image_vec_feature_matrix": image_vec_feature_matrix,
                "label_feature_matrix": label_feature_matrix,
                "risk_feature_matrix": risk_feature_matrix,
                "text_vec_list_list": text_vec_list_list,
                "image_vec_list_list": image_vec_list_list,
                "auditor_uid_list": auditor_uid_list,
                "auditor_request_num_list": auditor_request_num_list,
                "auditor_availabel_index_list": auditor_availabel_index_list,
                }

    def update(self, new_matrix_dict):
        """更新矩阵
        """
        for cur_index, cur_auditor_feature in enumerate(self.auditor_feature_list):
            cur_auditor_feature.text_feature = new_matrix_dict["text_feature_matrix"][cur_index].reshape((1, -1))
            cur_auditor_feature.image_feature = new_matrix_dict["image_feature_matrix"][cur_index].reshape((1, -1))
            cur_auditor_feature.label_feature = new_matrix_dict["label_feature_matrix"][cur_index].reshape((1, -1))
            cur_auditor_feature.risk_feature = new_matrix_dict["risk_feature_matrix"][cur_index].reshape((1, -1))
            cur_auditor_feature.text_vec_list = new_matrix_dict["text_vec_list_list"][cur_index]
            cur_auditor_feature.image_vec_list = new_matrix_dict["image_vec_list_list"][cur_index]

    def append(self, auditor_feature):
        """添加
        """
        assert auditor_feature.uid not in self.auditor_feature_dict
        self.auditor_feature_list.append(auditor_feature)
        self.auditor_feature_dict[auditor_feature.uid] = auditor_feature

    def at(self, index):
        """索引
        """
        return self.auditor_feature_list[index]

    def __contains__(self, auditor_feature):
        return auditor_feature.uid in self.auditor_feature_dict

    def __getitem__(self, auditor_uid):
        return self.auditor_feature_dict[auditor_uid]

    def size(self):
        """大小
        """
        return len(self.auditor_feature_list)

    def __iter__(self):
        for cur_auditor_feature in self.auditor_feature_list:
            yield cur_auditor_feature
