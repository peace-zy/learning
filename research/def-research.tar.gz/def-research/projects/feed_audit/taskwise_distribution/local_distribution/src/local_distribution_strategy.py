#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   local_distribution_strategy.py
Author:   zhanghao55@baidu.com
Date  :   21/07/06 10:05:20
Desc  :   
"""

import os
import sys
import logging
import time
import numpy as np
import numpy.ma as ma

from scipy import sparse
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics import pairwise_distances
from sklearn.cluster import AgglomerativeClustering

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../../../" % _cur_dir)
from lib.common.data_io import load_pkl


class DistributionStrategyV1(object):
    """本地任务分发 接收可分配任务矩阵和审核员矩阵
    线上分配算法v1.0
    """
    # TODO 可以将多种维度放在一个矩阵里 用一个dict存储各label、cluster对应的index
    def __init__(self, config):

        # 配置参数
        self.delay_start = config.delay_start
        self.delay_max = config.delay_max
        self.delay_penalty = config.delay_penalty
        self.text_weight = config.text_weight
        self.image_weight = config.image_weight
        self.sim_weight = config.sim_weight
        self.label_weight = config.label_weight
        self.risk_weight = config.risk_weight
        self.epsilon = config.epsilon

        # 文本cluster相似度
        self.text_cluster_model = load_pkl(config.text_cluster_model_path)
        self.text_center_similarity_matrix = cosine_similarity(self.text_cluster_model.cluster_centers_)
        self.text_cluster_num = self.text_center_similarity_matrix.shape[0]
        logging.info("text similarity matrix shape: {}".format(self.text_center_similarity_matrix.shape))
        self.text_high_sim_matrix = self.init_high_sim_matrix(
                self.text_center_similarity_matrix,
                config.text_high_sim_threshold,
                )

        # 图片cluster相似度
        self.image_cluster_model = load_pkl(config.image_cluster_model_path)
        self.image_center_similarity_matrix = cosine_similarity(self.image_cluster_model.cluster_centers_)
        self.image_cluster_num = self.image_center_similarity_matrix.shape[0]
        logging.info("image similarity matrix shape: {}".format(self.image_center_similarity_matrix.shape))
        self.image_high_sim_matrix = self.init_high_sim_matrix(
                self.image_center_similarity_matrix,
                config.image_high_sim_threshold,
                )

        logging.info("DistributionStrategyV1 init succeed")

    def init_high_sim_matrix(self, sim_matrix, sim_threshold):
        """高相似度的类别按相似度程度赋值
        1. 自身相似度为1
        2. 高相似度取值范围(0,1)
        3. 低相似度为0
        """
        assert sim_threshold < 1, "sim_threshold should be smaller than 1"
        # 例如sim_matrix = [[0.95, 0.97, 0.84, 0.99]] sim_threshold = 0.95
        # 大于sim_threshold才算有用 小于sim_threshold的全赋值为sim_threshold
        # sim_matrix = [[0.95, 0.97, 0.95, 0.99]]
        sim_matrix = np.where(sim_matrix >= sim_threshold, sim_matrix, sim_threshold)

        # 按行 归一化
        # sim_matrix_max = [[0.99]]
        sim_matrix_max = sim_matrix.max(axis=0)
        # sim_matrix_min = [[0.95]]
        sim_matrix_min = sim_matrix.min(axis=0)

        # sim_matrix - sim_matrix_min = [[0.00, 0.02, 0.00, 0.04]]
        # sim_matrix_max - sim_matrix_min = [[0.04]]
        # sim_matrix = [[0., 0.5, 0., 1.0]]
        sim_matrix = (sim_matrix - sim_matrix_min) / (sim_matrix_max - sim_matrix_min + self.epsilon)

        return sim_matrix

    def _rank_task(self, task_matrix_dict, auditor_matrix_dict, auditor_index, request_num, available_index):
        """ 为task排序
        影响因素：
        1. task中包含的text image内容
        2. task中包含的label risk
        3. task的待审时长

        找出的task的index是available_index的index
        通过available_index转回整个matrix的index

        不直接计算审核员和任务的矩阵 复杂度太高
        先得到该审核员在审核员维度上各类型的优先级
        然后根据该优先级计算该审核员在各任务的优先级
        """
        def cal_count_priority(count_matrix):
            """
            审核员审核各类任务的数据
            count_matrix[ai][cj] = xxx，审核员ai审核过类型cj的数目
            该审核员在各类型上的比例
            """
            # 变为mask array
            count_matrix = ma.masked_array(count_matrix, mask=False)
            # TODO 这里只是简单根据各审核员审核数来确定该审核员在各类型的权重
            # 可以参考tfidf bm25等方案
            # 来确定 哪些类型 对于该审核员最重要
            # 计算各审核员审核各类型的占比
            count_ratio = count_matrix / (count_matrix.sum(axis=0) + self.epsilon)
            # 除自身审核员的最高审核占比
            #logging.info("uid: {}".format(auditor_record.uid))
            count_ratio.mask[auditor_index] = True
            #logging.info("count_ratio_after: {}".format(count_ratio))
            count_ratio_others_max = count_ratio.max(axis=0)
            #logging.info("count_ratio_others_max: {}".format(count_ratio_others_max))
            count_ratio.mask[auditor_index] = False
            #logging.info("count_ratio_recover: {}".format(count_ratio))
            count_ratio_self = count_ratio[auditor_index]
            #logging.info("count_ratio_self: {}".format(count_ratio_self))

            count_priority = count_ratio_self - count_ratio_others_max

            return count_priority

        def cal_matrix_score(task_matrix, auditor_matrix, sim_matrix=None):
            """任务、审核员各维度矩阵得分
            """
            if available_index is not None:
                task_matrix = task_matrix[available_index]

            if sim_matrix is not None:
                auditor_matrix = np.dot(auditor_matrix, sim_matrix)

            # 计算指定审核员在各维度上的经验优势得分 得到经验优势得分向量
            auditor_priority = cal_count_priority(auditor_matrix).reshape((-1, 1))
            # TODO 有没有必要转成百分比 还是直接数量就可以？
            # 各任务的各维度的计数转为在任务中的占比
            task_matrix = task_matrix / (task_matrix.sum(axis=1, keepdims=True) + self.epsilon)
            # 各任务各维度的占比 与 该审核员在各维度的经验优势得分向量 做内积
            # 得到该审核员在各任务上得分
            matrix_score = np.dot(task_matrix, auditor_priority).reshape((-1, 1))
            return matrix_score

        def cal_delay_score(wait_time_matrix):
            """任务待审时间得分
            """
            if available_index is not None:
                wait_time_matrix = wait_time_matrix[available_index]

            delay_time_matrix = wait_time_matrix - self.delay_start
            # 待审时间得分 时间越长 得分越高
            delay_score =  np.where(delay_time_matrix > 0, delay_time_matrix, 0) / float(self.delay_max)
            return delay_score

        def norm(cur_matrix):
            """归一化
            """
            cur_matrix_max = cur_matrix.max()
            cur_matrix_min = cur_matrix.min()
            if cur_matrix_max == cur_matrix_min:
                cur_matrix_max += self.epsilon
            norm_matrix = (cur_matrix - cur_matrix_min) / (cur_matrix_max - cur_matrix_min)
            return norm_matrix

        def rank_task_score(top_k=1):
            """任务得分排序
            """
            # 文本维度得分
            text_sim_score = cal_matrix_score(
                    task_matrix_dict["text_feature_matrix"],
                    auditor_matrix_dict["text_feature_matrix"],
                    )

            # 图片维度得分
            image_sim_score = cal_matrix_score(
                    task_matrix_dict["image_feature_matrix"],
                    auditor_matrix_dict["image_feature_matrix"],
                    )

            # 标签维度得分
            label_score = cal_matrix_score(
                    task_matrix_dict["label_feature_matrix"],
                    auditor_matrix_dict["label_feature_matrix"],
                    )

            # 风险维度得分
            risk_score = cal_matrix_score(
                    task_matrix_dict["risk_feature_matrix"],
                    auditor_matrix_dict["risk_feature_matrix"],
                    )

            # 任务待审时间得分
            time_score = cal_delay_score(
                    task_matrix_dict["wait_time_matrix"],
                    )

            #logging.info("text_sim_score shape: {}".format(text_sim_score.shape))
            #logging.info("image_sim_score shape: {}".format(image_sim_score.shape))
            # 图片文本得分按比例和权重加和
            text_count_matrix = task_matrix_dict["text_count_matrix"][available_index]
            image_count_matrix = task_matrix_dict["image_count_matrix"][available_index]
            total_count_matrix = (text_count_matrix + image_count_matrix).astype(np.float64)
            #logging.info("text_count_matrix shape: {}".format(text_count_matrix.shape))
            #logging.info("image_count_matrix shape: {}".format(image_count_matrix.shape))
            #logging.info("total_count_matrix shape: {}".format(total_count_matrix.shape))
            #logging.info("sim score * count matrix shape: {}".format((text_sim_score * text_count_matrix).shape))

            # 按图片和文本在task中的占比给分
            sim_score = self.text_weight * text_sim_score * text_count_matrix \
                    + self.image_weight * image_sim_score * image_count_matrix

            sim_score /= (self.image_weight + self.text_weight) * total_count_matrix
            #logging.info("sim_score shape: {}".format(sim_score.shape))

            sim_score = sim_score.flatten()
            label_score = label_score.flatten()
            risk_score = risk_score.flatten()
            time_score = time_score.flatten()

            norm_sim_score = norm(sim_score)
            norm_label_score = norm(label_score)
            norm_risk_score = norm(risk_score)

            # 按占比给总得分
            total_score = self.label_weight * norm_label_score \
                    + self.risk_weight * norm_risk_score \
                    + self.sim_weight * norm_sim_score
            total_score /= float(self.label_weight + self.risk_weight + self.sim_weight)
            total_score += self.delay_penalty * time_score

            #logging.info("total_score shape: {}".format(total_score.shape))
            #logging.info("label_score shape: {}".format(label_score.shape))
            #logging.info("risk_score  shape: {}".format(risk_score.shape))
            #logging.info("time_score  shape: {}".format(time_score.shape))

            task_index_list =  range(len(total_score)) if available_index is None else available_index

            # 将各任务的各种分数聚合在一起 并根据总分进行排序
            score_pack_sorted_list = sorted(zip(task_index_list, total_score,
                norm_label_score, label_score,
                norm_risk_score, risk_score,
                norm_sim_score, sim_score,
                time_score), key=lambda x:x[1], reverse=True)

            top_k_task_list = list()
            for cur_task_index, cur_total_score, \
                    cur_norm_label_score, cur_label_score, \
                    cur_norm_risk_score, cur_risk_score, \
                    cur_norm_sim_score, cur_sim_score, \
                    cur_time_score in score_pack_sorted_list[:top_k]:

                cur_score_info = "task score:{:.4f}(label:{:.4f}(ori:{:.4f}) + "\
                        "risk:{:.4f}(ori:{:.4f}) + sim:{:.4f}(ori:{:.4f}) + time:{:.4f})".format(
                            cur_total_score,
                            cur_norm_label_score,
                            cur_label_score,
                            cur_norm_risk_score,
                            cur_risk_score,
                            cur_norm_sim_score,
                            cur_sim_score,
                            cur_time_score,
                            )
                top_k_task_list.append((cur_task_index, cur_total_score, cur_score_info))
            return top_k_task_list

        chosen_task_list = list()
        while len(chosen_task_list) < request_num and len(available_index) > 0:
            cur_index_score_rank = rank_task_score(top_k=1)
            cur_chosen_task = cur_index_score_rank[0]
            chosen_task_list.append(cur_chosen_task)
            cur_chosen_task_index = cur_chosen_task[0]
            available_index.remove(cur_chosen_task_index)
            # 更新auditor审核矩阵信息
            auditor_matrix_dict["text_feature_matrix"][auditor_index] += \
                    task_matrix_dict["text_feature_matrix"][cur_chosen_task_index]
            auditor_matrix_dict["image_feature_matrix"][auditor_index] += \
                    task_matrix_dict["image_feature_matrix"][cur_chosen_task_index]
            auditor_matrix_dict["label_feature_matrix"][auditor_index] += \
                    task_matrix_dict["label_feature_matrix"][cur_chosen_task_index]
            auditor_matrix_dict["risk_feature_matrix"][auditor_index] += \
                    task_matrix_dict["risk_feature_matrix"][cur_chosen_task_index]

        return chosen_task_list

    def distribute(self, task_matrix, auditor_matrix):
        """分发待审数据
        # 各账户先分成任务
        """

        task_matrix_dict = task_matrix.make_matrix()
        auditor_matrix_dict = auditor_matrix.make_matrix()

        dist_res_list = list()
        dist_index_set = set()

        distribute_begin_time = time.time()
        # 遍历有需要的
        for cur_index, (cur_request_num, cur_availabel_index) in enumerate(zip(
                auditor_matrix_dict["auditor_request_num_list"],
                auditor_matrix_dict["auditor_availabel_index_list"])):
            # 如果cur_availabel_index未指定 则所有的task都可分配
            if cur_availabel_index is None:
                cur_availabel_index = list(range(task_matrix.size()))
            # 本批次已分配给别人的先去除
            cur_availabel_index = [x for x in cur_availabel_index if x not in dist_index_set]
            # 如果当前该审核员已无可分配的任务 则打印信息 跳过
            if len(cur_availabel_index) == 0:
                logging.info("no available task for auditor {}, left task num: {}".format(
                    auditor_matrix.at(cur_index).uid,
                    task_matrix.size() - len(dist_index_set),
                    ))
                continue
            # 为指定审核员分配指定数量任务
            chosen_task_list = self._rank_task(
                    task_matrix_dict=task_matrix_dict,
                    auditor_matrix_dict=auditor_matrix_dict,
                    auditor_index=cur_index,
                    request_num=cur_request_num,
                    available_index=cur_availabel_index)

            # 得到分配给当前审核员的任务uid集合 更新已分配的index记录
            for cur_task_index, cur_score, cur_info in chosen_task_list:
                cur_auditor = auditor_matrix.at(cur_index)
                dist_index_set.add(cur_task_index)
                cur_chosen_task = task_matrix.at(cur_task_index)
                cur_chosen_task.chosen_info += cur_info
                dist_res_list.append((cur_auditor.uid, cur_chosen_task.uid))

            cur_auditor_end_time = time.time()
            cur_dist_task_num = len(chosen_task_list)
            total_dist_task_num = len(dist_index_set)
            left_task_num = task_matrix.size() - total_dist_task_num
            cost_time = cur_auditor_end_time - distribute_begin_time
            dist_speed = total_dist_task_num / float(cost_time)

            logging.info("assign {} tasks to auditor #{}, task left: {}, " \
                    "cost_time: {:.2f}s, speed: {:.2f} dist/s".format(
                cur_dist_task_num,
                auditor_matrix.at(cur_index).uid,
                left_task_num,
                cost_time,
                dist_speed,
                ))

        return dist_res_list, auditor_matrix_dict

    def ad_sort(self, task_feature):
        """对任务下的物料进行排序
        """
        def cal_distance(ad_matrix, sim_matrix=None, strict=True):
            """计算各物料指定维度的余弦距离
            """
            try:
                if sim_matrix is not None:
                    ad_matrix = np.dot(ad_matrix, sim_matrix)
                ad_distance = pairwise_distances(ad_matrix, metric="cosine")
            except ValueError as e:
                if strict:
                    logging.warning(e)
                # 失败则距离矩阵全为0
                ad_distance = np.zeros((ad_matrix.shape[0], ad_matrix.shape[0]))
            return ad_distance

        def combine(children_list):
            """合并给定的各子树
            """
            # 因为该树是层次聚类所得 子树内各节点距离一定小于子树间的距离
            # 所以合并子树各节点时 这里不需要考虑两子树各节点间哪组距离最近
            # 为适应审核习惯 将节点更多的子树放在前面
            res_list = list()
            for cur_children in sorted(children_list, key=lambda x:len(x), reverse=True):
                res_list.extend(cur_children)
            return res_list

        def sort_children(children_list, leaf_num):
            """根据层次聚类结果为物料排序
            """
            tree_dict = dict()
            # 叶子节点
            for cur_ind in range(leaf_num):
                tree_dict[cur_ind] = [cur_ind]
            # 聚合
            for cur_ind, cur_children in enumerate(children_list):
                #print("tree_dict: {}".format(tree_dict))
                cur_id = leaf_num + cur_ind
                #print("cur_id: {}".format(cur_ind))
                #print("cur_children: {}".format(cur_children))
                #print("="*100)
                cur_list = list()
                for cur_child in cur_children:
                    cur_list.append(tree_dict[cur_child])
                    del tree_dict[cur_child]
                tree_dict[cur_id] = combine(cur_list)
            assert len(tree_dict) == 1, "tree_dict size = {}: {}".format(len(tree_dict), tree_dict)
            return combine(tree_dict.values())

        if task_feature.size() > 2:
            total_begin_time = time.time()
            ad_matrix_dict = task_feature.make_matrix()

            distance_begin_time = time.time()
            #start_time = time.time()
            text_sim_distance = cal_distance(
                    ad_matrix_dict["text_feature_matrix"],
                    sim_matrix=self.text_high_sim_matrix,
                    )
            #logging.info("text_sim_distance: {}".format(text_sim_distance))
            #logging.info("text sim cost time: {:.2f}s".format(time.time() - start_time))
            #start_time = time.time()
            image_sim_distance = cal_distance(
                    ad_matrix_dict["image_feature_matrix"],
                    sim_matrix=self.image_high_sim_matrix,
                    )
            #logging.info("image_sim_distance: {}".format(image_sim_distance))
            #logging.info("image sim cost time: {:.2f}s".format(time.time() - start_time))
            #start_time = time.time()
            #label_distance = cal_distance(ad_matrix_dict["label_feature_matrix"])
            #logging.info("label_distance: {}".format(label_distance))
            #logging.info("label cost time: {:.2f}s".format(time.time() - start_time))
            #start_time = time.time()
            #risk_distance = cal_distance(ad_matrix_dict["risk_feature_matrix"], strict=False)
            #logging.info("risk_distance: {}".format(risk_distance))
            #logging.info("risk cost time: {:.2f}s".format(time.time() - start_time))
            #start_time = time.time()
            text_image_count_distance = cal_distance(ad_matrix_dict["text_image_count_matrix"])
            #logging.info("text_image_distance: {}".format(text_image_count_distance))
            #logging.info("text image count cost time: {:.2f}s".format(time.time() - start_time))

            #start_time = time.time()
            sim_distance = text_sim_distance * self.text_weight \
                    + image_sim_distance * self.image_weight
            sim_distance /= float(self.text_weight + self.image_weight)

            total_distance = sim_distance + text_image_count_distance
                    #+ self.label_weight * label_distance
                    #+ self.risk_weight * risk_distance \
            #logging.info("total_distance: {}".format(total_distance))
            #logging.info("combine cost time: {:.2f}s".format(time.time() - start_time))
            distance_end_time = time.time()

            cluster_begin_time = time.time()
            model = AgglomerativeClustering(affinity="precomputed", linkage="complete")
            model.fit(total_distance)
            cluster_end_time = time.time()

            sort_begin_time = time.time()
            sort_ind = sort_children(model.children_, leaf_num=total_distance.shape[0])
            sort_end_time = time.time()
            sorted_audit_data_uid_list = [task_feature.ad_feature_list[ind].uid for ind in sort_ind]
            total_end_time = time.time()

            #logging.info("task ad size = {}, time: [total = {:.2f}s, distance = {:.2f}s, " \
            #        "cluster = {:.2f}s, sort = {:.2f}s]".format(
            #    task_feature.size(),
            #    total_end_time - total_begin_time,
            #    distance_end_time - distance_begin_time,
            #    cluster_end_time - cluster_begin_time,
            #    sort_end_time - sort_begin_time,
            #    ))
        else:
            sorted_audit_data_uid_list = [x.uid for x in task_feature.ad_feature_list]

        return sorted_audit_data_uid_list

    def cluster_predict(self, vec_list, element_type):
        """预测向量属于的聚类簇
        """
        if element_type == "text":
            cluster_res = self.text_cluster_model.predict(vec_list)
            cluster_num = self.text_cluster_num
        elif element_type == "image":
            cluster_res = self.image_cluster_model.predict(vec_list)
            cluster_num = self.image_cluster_num
        else:
            raise ValueError("unknown element_type: {}".format(element_type))

        cluster_res_num = cluster_res.shape[0]
        cluster_res_ont_hot = np.zeros((cluster_res_num, cluster_num))
        cluster_res_ont_hot[range(cluster_res_num), cluster_num] = 1
        return cluster_res_ont_hot


if __name__ == "__main__":
    pass


