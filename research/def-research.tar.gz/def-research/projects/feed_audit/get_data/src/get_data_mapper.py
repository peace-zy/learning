#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: src/get_data_mapper.py
Author: zhanghao55(zhanghao55@baidu.com)
Date: 2021/04/07 10:29:29
"""

import sys
from audit_objects import AdAuditObj
from sampler import Sampler


def main():
    """�����
    """
    sample_num = int(sys.argv[1])

    tar_pipe = set([
        'aka-ad-output-other1-pipe',
        'aka-ad-output-fc-pipe',
        'aka-ad-output-trad-fc-pipe',
        ])
    tar_product = set([
        119, 310, 286, 238, 175, 250, 163, 156, 188, 187,
        340, 159, 257, 308, 309, 319, 160, 118, 334, 120,
        268, 318, 136, 113, 88, 89, 42, 40, 60, 87,
        61, 64, 96, 62, 28, 27, 41, 55, 57, 63,
        26, 59, 58,
        ])
    filter_set = set([
        "1040",
        "720",
        ])

    pass_sample = Sampler(sample_num, uniq=True)
    reject_sample = Sampler(sample_num, uniq=True)

    for line in sys.stdin:
        parts = line.strip("\n").decode("gb18030").split("\t")

        obj = AdAuditObj()
        obj.init_from_list(parts)

        if obj.audit_channel_type != 3:
            continue

        if obj.pipe not in tar_pipe:
            continue

        if obj.product_id not in tar_product:
            continue

        # ȥ��text_list�д����ֵ�Ƭ��
        # �����ݷ��� ������Ҫ��1040��720
        # �����������ֻɾ������������
        obj.idea_list = [x for x in obj.idea_list if x not in filter_set]
        if len(obj.idea_list) == 0:
            return
        
        # ����ܾ��������� ͼƬ��URL��ص���ʡ��
        reason_list = list()
        for cur_reason in obj.reason_array:
            if (u"ͼƬ" in cur_reason or u"URL" in cur_reason) \
                    and u"����" not in cur_reason:
                continue
            reason_list.append(cur_reason)

        # ��reason��ʱ�����һ��''
        if len(reason_list) == 0:
            continue

        obj.reason_array = reason_list

        # ��idea_list�е�����ȥ��
        if obj.review_result == 0:
            pass_sample.put(obj, key="\x01".join(obj.idea_list))
        elif obj.review_result == 1:
            reject_sample.put(obj, key="\x01".join(obj.idea_list))
        else:
            raise ValueError("wrong line: {}".format(line))

    def print_obj(obj):
        """��ʽ�����obj��Ϣ
        """
        print "\t".join([
            obj.sep.join(obj.word_list),
            "|||".join(obj.idea_list),
            str(obj.product_id),
            str(obj.user_id),
            str(obj.ad_id),
            str(obj.ad_type),
            str(obj.human_in_start_timestamp),
            str(obj.human_out_end_timestamp),
            str(obj.chk_user),
            str(obj.review_result),
            obj.sep.join(obj.reason_array),
            ]).encode("gb18030")

    for obj in pass_sample.get_sample_list():
        print_obj(obj)

    for obj in reject_sample.get_sample_list():
        print_obj(obj)


if __name__ == "__main__":
    main()
