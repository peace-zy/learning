#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: src/get_data_reducer.py
Author: zhanghao55(zhanghao55@baidu.com)
Date: 2021/04/07 14:07:44
"""

import sys
from sampler import Sampler


def main():
    """�����
    """
    sample_num = int(sys.argv[1])
    pass_sample = Sampler(sample_num, uniq=True)
    reject_sample = Sampler(sample_num, uniq=True)
    for line in sys.stdin:
        line = line.strip("\n")
        parts = line.decode("gb18030").split("\t")
        review_result = int(parts[-2])
        idea = parts[1]
        if review_result == 0:
            pass_sample.put(line, key=idea)
        elif review_result == 1:
            reject_sample.put(line, key=idea)
        else:
            raise ValueError("wrong line: {}".format(line))

    for line in pass_sample.get_sample_list():
        print(line)

    for line in reject_sample.get_sample_list():
        print(line)


if __name__ == "__main__":
    main()
