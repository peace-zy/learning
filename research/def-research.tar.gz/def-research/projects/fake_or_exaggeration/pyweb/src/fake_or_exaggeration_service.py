#!/usr/bin/env python
# -*- coding:gb18030 -*-
########################################################################
# 
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: src/fake_or_exaggeration_service.py
Author: zhanghao55(zhanghao55@baidu.com)
Date: 2020/09/17 14:46:08
"""

import os
import sys
_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(_cur_dir, "../../../../"))
from lib.common import logger
import logging
logger.init_log()
import time

import tornado.httpserver
import tornado.ioloop
import tornado.options
import tornado.web

from tornado.options import define, options

sys.path.append(os.path.join(_cur_dir, "../../src/"))
from static_predict import StaticPredictor

class IndexHandler(tornado.web.RequestHandler):
    """��������
    """
    def initialize(self, model, check_history):
        self.check_history = check_history
        self.model = model

    def get(self):
        self.render('index.html', check_history=self.check_history)

    def post(self):
        text = self.get_argument('text')
        logging.info("text: {}".format(text.encode("gb18030")))
        start_time = time.time()
        label, rate = self.model.predict([text])[0]
        logging.info("label: {}, rate: {}, text: {}, cost_time: {}s".format(
                label.encode("gb18030"),
                "%.4f" % rate,
                text.encode("gb18030"),
                time.time() - start_time))
        self.check_history.insert(0, (text, label, "%.4f" % rate))
        if len(self.check_history) > 100:
            self.check_history.pop()
        self.render('index.html', check_history=self.check_history)

class FakeOrExaggerationService(object):
    """��ٿ��ʶ�������
    """
    def __init__(self):
        logging.info("cur_work_dir: {}".format(_cur_dir))
        model_dir = os.path.join(_cur_dir, "../../model")
        logging.info("model_dir: {}".format(model_dir))
        static_model_path = os.path.join(model_dir, "textcnn_static")
        label_id_path = os.path.join(model_dir, "class_id.txt")
        vocab_path = os.path.join(model_dir, "vocab.txt")

        self.model = StaticPredictor(
                static_model_path,
                label_id_path,
                vocab_path,
                gpu_id=None,
                zero_copy=True,
                )

        define("port", default=8001, help="run on the given port", type=int)
 
        self.res_list = []

    def start(self):
        """����ʼ����
        """
        tornado.options.parse_command_line()
        app = tornado.web.Application(
            handlers=[
                    (r'/', IndexHandler, {"model":self.model, "check_history":self.res_list}),
                    (r'/index', IndexHandler, {"model":self.model, "check_history":self.res_list}),
                    ],
            template_path=os.path.join(_cur_dir, "../templates")
        )
        http_server = tornado.httpserver.HTTPServer(app)
        http_server.listen(options.port)
        tornado.ioloop.IOLoop.instance().start()


if __name__ == '__main__':
    service = FakeOrExaggerationService()
    service.start()
