#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   mark_data_clean.py
Author:   zhanghao55@baidu.com
Date  :   20/09/24 15:02:29
Desc  :   
"""

import codecs
import configparser
import datetime
import paddle.fluid.dygraph as D
import logging
import numpy as np
import os
import sys
_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(_cur_dir, "../../../"))

from cleanlab.pruning import get_noise_indices
from ernie_tokenizer import ErnieTokenizer
from label_encoder import LabelEncoder
from lib.common.data_io import load_model, get_file_name_list, get_attr_values
from nets.ernie_for_sequence_classification import ErnieModelCustomized
from nets.textcnn import TextCNN
from dygraph import infer, batch_infer


def ernie_init(config, label_encoder):
    """��ʼ��ernie
    """
    model_config = config["MODEL_PATH"]
    ernie = ErnieModelCustomized.from_pretrained(
            model_config["ernie_pretrain"],
            num_labels=label_encoder.size())
    load_model(ernie, model_config["ernie_model_best"])
    return ernie


def distill_textcnn_init(config, label_encoder):
    """��ʼ��distill_textcnn
    """
    textcnn_config = config["TEXTCNN"]
    model_config = config["MODEL_PATH"]
    text_cnn = TextCNN(
            num_class=label_encoder.size(),
            vocab_size=textcnn_config.getint("vocab_size"),
            emb_dim=textcnn_config.getint("emb_dim"),
            num_filters=textcnn_config.getint("num_filters"),
            fc_hid_dim=textcnn_config.getint("fc_hid_dim"),
            use_cudnn=textcnn_config.getboolean("use_cudnn"),
            )

    load_model(text_cnn, model_config["distill_textcnn_model_best"])
    return text_cnn


def wrong_label_detect(config):
    """�����������
    """
    model_dict = {
        "ernie": ernie_init,
        "distill_textcnn": distill_textcnn_init,
        }

    label_clean_config = config["LABEL_CLEAN"]
    label_check_dir= label_clean_config["label_check_dir"]
    wrong_label_path = label_clean_config["wrong_label_res"]
    file_encoding = label_clean_config["encoding"]
    pred_model = label_clean_config["pred_model"]

    file_path_list = get_file_name_list(label_check_dir)
    model_init_func = model_dict.get(pred_model, distill_textcnn_init)

    model_config = config["MODEL_PATH"]
    tokenizer = ErnieTokenizer.from_pretrained(model_config["tokenizer"])
    label_encoder = LabelEncoder(label_id_info=model_config["label_encoder"], isFile=True)

    text_list = list()
    label_list = list()
    file_info_list = list()
    for file_path in file_path_list:
        logging.info("process file : {}".format(file_path))

        cur_label_list, cur_text_list = \
                get_attr_values(file_path, fetch_list=["label", "text"], encoding=file_encoding)

        text_list.extend(cur_text_list)
        label_list.extend(cur_label_list)
        for index in range(len(cur_text_list)):
            file_info_list.append("\t".join([file_path, str(index + 1)]))

    text_ids = [tokenizer.encode(text)[0] for text in text_list]
    label_ids = np.array([label_encoder.transform(label) for label in label_list])
    infer_data = zip(text_ids, label_ids)

    with D.guard():
        model = model_init_func(config, label_encoder)

        logits_list, _ = batch_infer(model, infer_data, batch_size=32, max_seq_len=300, logits_softmax=True)

    wrong_label_indexs = get_noise_indices(
        s=label_ids,
        psx=np.array(logits_list),
        sorted_index_method='normalized_margin', # Orders label errors
        )
    logging.info("wrong_label_index: {}".format(wrong_label_indexs))

    with codecs.open(wrong_label_path, "w", file_encoding) as wf:
        # ��ӡ�����ܴ��������
        for index in wrong_label_indexs:
            wf.write("\t".join([
                label_encoder.inverse_transform(np.argmax(logits_list[index])),
                label_list[index],
                text_list[index],
                file_info_list[index],
                ]) + "\n")


if __name__ == "__main__":
    config_path = sys.argv[1]
    uniqid = sys.argv[2] if len(sys.argv) > 2 else None

    config = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
    config.read(config_path)
    if uniqid is not None:
        if uniqid == "{time}":
            now_time = datetime.datetime.now()
            uniqid = datetime.datetime.strftime(datetime.datetime.now(), "%Y%m%d")
        # ���ӵ�ǰuniqid
        config.set("DEFAULT", "uniqid", uniqid)
    logging.info("uniqid: {}".format(config.get("DEFAULT", "uniqid")))

    wrong_label_detect(config)
