# 任务分配模拟程序

## 文件结构
```
root
├── bin
│   ├── run.sh：通过运行该文件并配置相关参数来执行各类功能
│   └── util.sh -> ../../bin/util.sh：软链
├── data
├── ernie_sim_server： 获取文本向量所需的模型，从hdfs上获取
├── log
├── output
├── README.md
└── src
    ├── ad_sort.py：任务内物料排序逻辑，与服务端文件一致，本地分配时调用该文件中的类
    ├── auditor_vec_trans.py：将线上用户的2000维聚类向量转为128维语义向量
    ├── base_distribution.py：任务分配基类，本地逻辑分配和请求服务端分配都继承该类基础逻辑
    ├── distribution_strategy_v2.py：任务分配逻辑，与服务端文件一致，本地分配时调用该文件中的类
    ├── format_given_feed_audit_task.py： 处理指定文件 （生成待分配数据 1/3）
    ├── get_image_vec.py： 获取文件中各行图片的向量 （生成待分配数据 2/3）
    ├── get_text_ernie_sim_vec.py： 获取文件中各行文本的向量 （生成待分配数据 2/3）
    ├── image_tag_client.py： 获取图片向量的辅助程序
    ├── km_bfs.py： 改进的二部图分配
    ├── local_arguments.py： 本地分配的运行参数配置
    ├── local_distribution.py： 本地分配主入口
    ├── make_task_wise_audit_data.py：根据前序得到的各文件生成待分配数据 （生成待分配数据 3/3）
    ├── server_arguments.py： 服务端分配的运行参数配置
    ├── server_distribution.py： 服务端分配主入口
    ├── time_stat.py： 分析待分配数据中各时间的的任务、物料量，及其行业分布
    ├── uniq_feed_audit_data.py：处理feed_audit的文件以生成待分配数据（暂时没有用）
    └── utils.py：任务分配时所需工具
```

## 运行手册

### 准备环境

执行各功能前，先建立软链

`ln -s ../../bin/util.sh bin/util.sh`

### 生成待分配数据

#### 准备环境

生成文本向量时需要启动ernie_sim模型，其余时候不需要。
模型地址：`afs://shaolin.afs.baidu.com:9902/app/ecom/fengkong/personal/zhanghao55/archives/task_distribution/ernie_sim_server_model.tar.gz`

1. 根目录新建一个`ernie_sim_server`文件夹，并切换到该文件夹

`mkdir ernie_sim_server && cd ernie_sim_server`

2. 将模型取到本地，解压到该文件夹中

`hadoops fs -get afs://shaolin.afs.baidu.com:9902/app/ecom/fengkong/personal/zhanghao55/archives/task_distribution/ernie_sim_server_model.tar.gz ./ && tar zxvf ernie_sim_server_model.tar.gz`

3. 修改`bin/env.sh`中cuda、cudnn的环境路径

`vim bin/env.sh`

4. 启动ernie_sim服务

`sh bin/start_server.sh`

5. 生成文本向量后关闭该服务

#### 执行

`sh bin/run.sh --format_data=file_path [--uniq_id uniqid] [-o|--over_write]`

其中：
1. file_path: 从指定文件生成待分配数据
2. uniqid: 待分配数据文件后缀
3. o|over_write: 覆盖已生成的文件。若没有该参数，则遇到已生成的文件会跳过

#### 指定文件格式

1. ad_id         ：物料ID
2. task_id       ：任务ID
3. user_id       ：账户ID
4. add_time      ：物料入审时间
5. text_content  ：文本内容, 空格分割
6. media_content ：多媒体url， 空格分隔
7. url_content   ：落地页url, 空格分隔（非必需）
8. ustat         ：账户状态，2-生效、3-余额为零（非必需）

#### 指定文件示例

示例地址：`afs://shaolin.afs.baidu.com:9902/app/ecom/fengkong/personal/zhanghao55/archives/task_distribution/data`

下面有三类文件：
1. feed_136_test_data_20210705：feed 136产品线数据，各物料只包含文本或只包含图片。测试分配效果一般用这个比较直观。
2. feed_other_test_data_20210812：feed其他产品线数据，各物料里包含文本和图片，较复杂。
3. jimuyu_20210907：基木鱼数据，物料里包含文本和图片，且文本较长，更复杂。

### 模拟分配

模拟分配示例数据地址：`afs://shaolin.afs.baidu.com:9902/app/ecom/fengkong/personal/zhanghao55/archives/task_distribution/task_wise_audit_data_test`

本地模拟分配效率统计数据地址：`afs://shaolin.afs.baidu.com:9902/app/ecom/fengkong/personal/zhanghao55/archives/task_distribution/efficiency_statistics.20210823_20210901`

`cd data && ln -s efficiency_statistics.20210823_20210901 efficiency_statistics`


#### 本地分配

分配逻辑也在本地

`sh bin/run.sh --local_distribution=file_path [--uniq_id uniqid] [-m max_num] [-n|--auditor_num auditor_num] [-a|--auditor_info] [-o|--overwrite]`

其中：
1. file_path      : 生成的待分配数据
2. uniqid         : 分配结果文件后缀
3. max_num        : 有时候待分配数据过多， 指定max_num则只取前max_num的物料组成任务进行分配
4. n|auditor_num  : 审核员人数
5. a|auditor_info : 使用指定的审核员的实际特征向量及行业ID映射表，当本地没有相关文件时会实时从线上数据库上拉取数据
6. o|overwrite    : 实时拉取最新的数据覆盖本地已有的审核员的特征向量和行业ID映射表

#### 服务端分配

请求服务端分配，该服务端需要自己线下启动dilu中的task_distribution服务并根据自己服务地址修改`src/server_distribution.py`中请求的地址

`sh bin/run.sh --server_distribution=file_path [--uniq_id uniqid] [-m max_num] [-n|--auditor_num auditor_num] [-a|--auditor_info] [-o|--overwrite]`

其中：
1. file_path      : 生成的待分配数据
2. uniqid         : 分配结果文件后缀
3. max_num        : 有时候待分配数据过多， 指定max_num则只取前max_num的物料组成任务进行分配
4. n|auditor_num  : 审核员人数
5. a|auditor_info : 使用指定的审核员的实际特征向量及行业ID映射表，当本地没有相关文件时会实时从线上数据库上拉取数据
6. o|overwrite    : 实时拉取最新的数据覆盖本地已有的审核员的特征向量和行业ID映射表配


# TODO

1. 服务端分配还要在代码中改地址
2. 线上行业ID映射存在重复的index，需要工程同学解决
