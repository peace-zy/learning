#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   get_image_vec.py
Author:   zhanghao55@baidu.com
Date  :   21/05/27 15:00:24
Desc  :   
"""

import os
import sys
import codecs
import json
import logging

from image_tag_client import ImageTagClient

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.data_io import get_data, dump_pkl, load_pkl
from lib.common.logger import init_log

init_log()


def get_image_vec(
        image_url_path,
        image_vec_path,
        max_num=None,
        n_jobs=20,
        batch_size=32,
        example_num=5,
        encoding="utf-8",
        ):
    """��ȡͼƬ����
    """
    def process_line(line):
        """�д�������
        """
        parts = line.strip("\n").split("\t")
        image_url = parts[0]
        return image_url

    query_list = list(get_data(image_url_path, read_func=process_line, encoding=encoding))
    if max_num is not None:
        query_list = query_list[:max_num]

    logging.info("query example:")
    for index, cur_query in enumerate(query_list[:example_num]):
        logging.info("#{}: {}".format(index, cur_query))

    image_vec_pkl_path = image_vec_path + ".pkl"

    if os.path.exists(image_vec_pkl_path):
        query_res_list = load_pkl(image_vec_pkl_path)
    else:
        client = ImageTagClient()

        logging.info("query size: {}".format(len(query_list)))
        query_res_list = client.query_tag(query_list, query_type="url", n_jobs=n_jobs, batch_size=batch_size)
        dump_pkl(query_res_list, image_vec_pkl_path, True)

    vec_info_list = list()
    for cur_query_res in query_res_list:
        #logging.info("cur_query_res: {}".format(cur_query_res))
        cur_query_id = cur_query_res["id"]
        cur_query_url = query_list[cur_query_id]
        #assert cur_query_url == cur_query_res["url"], "url not consistant: {} != {}".format(cur_query_url, cur_query_res["url"])
        if "image_taginfo" not in cur_query_res or \
                cur_query_res["image_taginfo"] is None or \
                "ann_search_tag" not in cur_query_res["image_taginfo"] or \
                "ann_politic_black_128_feature" not in cur_query_res["image_taginfo"]["ann_search_tag"]:
            continue
        try:
            cur_query_vec = \
                    cur_query_res["image_taginfo"]["ann_search_tag"]["ann_politic_black_128_feature"]["content"]
            cur_query_vec_version = \
                    cur_query_res["image_taginfo"]["ann_search_tag"]["ann_politic_black_128_feature"]["version"]
        except Exception as e:
            logging.info("url: {}, cur_query_res:\n{}".format(cur_query_url, cur_query_res))
            continue
        vec_info_list.append((cur_query_id, cur_query_url, cur_query_vec, cur_query_vec_version))

    with codecs.open(image_vec_path, "w", encoding) as wf:
        for cur_id, cur_url, cur_vec, cur_version in sorted(vec_info_list, key=lambda x: x[0]):
            wf.write(json.dumps({
                "id": cur_id,
                "text": cur_url,
                "vec": cur_vec,
                "version": cur_version,
                }) + "\n")


if __name__ == "__main__":
    image_url_path = sys.argv[1]
    image_vec_path = sys.argv[2]
    max_num = int(sys.argv[3]) if len(sys.argv) > 3 else None
    n_jobs = int(sys.argv[4]) if len(sys.argv) > 4 else 20
    get_image_vec(
            image_url_path,
            image_vec_path,
            max_num=max_num,
            n_jobs=n_jobs,
            )




