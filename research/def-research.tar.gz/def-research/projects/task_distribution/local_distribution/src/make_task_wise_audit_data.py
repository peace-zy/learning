#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
File  :   make_task_wise_audit_data.py
Author:   zhanghao55@baidu.com
Date  :   21/05/28 16:36:44
Desc  :   
"""

import os
import sys
import codecs
import json
import logging
from tqdm import tqdm
from utils import ADAuditData

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log
from lib.common.data_io import get_data, load_pkl

init_log()


def load_vec_dict(vec_path, encoding="gb18030"):
    """加载向量信息
    """
    vec_dict = dict()
    with codecs.open(vec_path, "r", encoding) as rf:
        for line in tqdm(rf, desc="load vec"):
            obj = json.loads(line.strip("\n"))
            vec_dict[obj["text"]] = obj["vec"]
    return vec_dict


def make_ad_audit_data(
        input_path,
        output_path,
        text_vec_path,
        image_vec_path,
        ):
    """生成任务维度的待审数据
    """

    text_vec_dict = load_vec_dict(text_vec_path)
    image_vec_dict = load_vec_dict(image_vec_path)

    # 读入各ad_audit_data 添加属性
    ad_audit_data_list = list()
    with codecs.open(input_path, "r", "utf-8") as rf:
        for line in tqdm(rf, "make ad wise audit data"):
            ad_audit_data = ADAuditData.init_from_json(line.strip("\n"))

            # 添加各text的向量
            for cur_text in ad_audit_data.text_list:
                if len(cur_text) == 0:
                    continue
                if cur_text in text_vec_dict:
                    ad_audit_data.text_vec_list.append(text_vec_dict[cur_text])
                else:
                    logging.warning("not found text: {}".format(cur_text))

            # 添加各image的向量
            for cur_image in ad_audit_data.image_url_list:
                if len(cur_image) == 0:
                    continue
                if cur_image in image_vec_dict:
                    ad_audit_data.image_vec_list.append(image_vec_dict[cur_image])
                elif not cur_image.endswith(".mp4") \
                        and not cur_image.endswith(".gif") \
                        and not cur_image.endswith(".webp"):
                    # mp4格式的地址没有向量 自动忽略
                    logging.warning("not found url: {}".format(cur_image))

            ad_audit_data_list.append((ad_audit_data.in_time, ad_audit_data))

    # 添加属性后的ad_audit_data存入文件 按进审时间排序
    with codecs.open(output_path, "w", "gb18030") as wf:
        for _, cur_ad_audit_data in sorted(ad_audit_data_list, key=lambda x:x[0]):
            wf.write(cur_ad_audit_data.to_json() + "\n")

if __name__ == "__main__":
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    text_vec_path = sys.argv[3]
    image_vec_path = sys.argv[4]

    make_ad_audit_data(
            input_path,
            output_path,
            text_vec_path,
            image_vec_path,
            )
