#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   utils.py
Author:   zhanghao55@baidu.com
Date  :   21/07/06 10:58:52
Desc  :
"""

import codecs
import copy
import json
import logging
import numpy as np
import time
import uuid
import copy
import os

from tqdm import tqdm
from collections import defaultdict


class CustomizedForJson(object):
    """可以被json dumps loads的基础类
    """
    @classmethod
    def init_from_json(cls, init_json):
        """从json字符串初始化
        """
        # 因为直接从json串初始化 所以这里可以直接用json.loads得到的字典而不需要copy
        return cls.init_from_dict(json.loads(init_json), zero_copy=True)

    @classmethod
    def init_from_dict(cls, init_dict, zero_copy=True):
        """从dict初始化
        [in]  init_dict：dict，初始化字典
              zero_copy：bool，是否与audit_data_dict中各值同步更新
           若zero_copy为True，则与init_dict给的数据共享内存
           其他地方对init_dict中的数据进行修改时，也会影响到共享给本类的数据
        """
        if not zero_copy:
            init_dict = {k: copy.deepcopy(v) for k, v in init_dict.items()}
        return cls(**init_dict)

    def to_dict(self):
        """转字典
        """
        return vars(self)

    def to_json(self):
        """转json
        """
        return json.dumps(self.to_dict())

    def __repr__(self):
        return self.to_str(sep="\n")

    def to_str(self, sep="\t"):
        """转为str
        """
        raise NotImplementedError


class ADAuditData(CustomizedForJson):
    """审核数据类
    """
    def __init__(self,
            uid=None,
            userid=None,
            task_uid=None,
            ad_id=None,
            text_list=None,
            image_url_list=None,
            text_vec_list=None,
            image_vec_list=None,
            trade_id_list=None,
            trade_list=None,
            in_time=None,
            distributed_time=None,
            chosen_info=None,
            ):
        super(ADAuditData, self).__init__()
        self.uid = str(uuid.uuid1()) if uid is None else uid
        self.userid = userid
        self.ad_id = ad_id
        self.task_uid = task_uid
        self.text_list = list() if text_list is None else text_list
        self.image_url_list = list() if image_url_list is None else image_url_list
        self.text_vec_list = list() if text_vec_list is None else text_vec_list
        self.image_vec_list = list() if image_vec_list is None else image_vec_list
        self.trade_list = list() if trade_list is None else trade_list
        self.trade_id_list = list() if trade_id_list is None else trade_id_list
        self.in_time = in_time
        self.distributed_time = distributed_time
        self.chosen_info = "" if chosen_info is None else chosen_info

    def to_str(self, sep="\t"):
        return sep.join([
            "uid: {}".format(self.uid),
            "userid: {}".format(self.userid),
            "ad_id: {}".format(self.ad_id),
            "task_uid: {}".format(self.task_uid),
            "text_list: {}".format(self.text_list),
            "image_url_list: {}".format(self.image_url_list),
            "trade_list: {}".format(self.trade_list),
            "trade_id_list: {}".format(self.trade_id_list),
            "in_time: {}".format(self.in_time),
            "distributed_time: {}".format(self.distributed_time),
            "chosen_info: {}".format(self.chosen_info),
            ])

    def __eq__(self, other):
        """确保物料维度无完全重复
        """
        if isinstance(other, ADAuditData):
            return self.uid == other.uid
        else:
            return False

    def __lt__(self, other):
        """heapq排序时需要
        """
        if isinstance(other, ADAuditData):
            return self.in_time < other.in_time
        else:
            raise ValueError("'<' not supported between instances of {} and {}".format(type(self), type(other)))


class BaseMatrix(object):
    """基础矩阵
    """
    def __init__(self, text_feature_dim=128, image_feature_dim=128):
        """初始化
        """
        self.text_feature_dim = text_feature_dim
        self.image_feature_dim = image_feature_dim
        self.text_feature_list = list()
        self.image_feature_list = list()
        self.trade_feature_list = list()
        self.text_count_list = list()
        self.image_count_list = list()

    def append(self, text_feature, image_feature, trade_feature, text_count, image_count):
        """添加记录
        """
        # 未知的向量 取全零 则计算相似度时 和别的向量都为0
        # 在更新审核员向量时 会因为该处
        if text_feature is None:
            text_feature = [0] * self.text_feature_dim
        if image_feature is None:
            image_feature = [0] * self.image_feature_dim
        self.text_feature_list.append(text_feature)
        self.image_feature_list.append(image_feature)
        self.trade_feature_list.append(trade_feature)
        self.text_count_list.append(text_count)
        self.image_count_list.append(image_count)

    def to_dict(self):
        """处理方便计算的字典格式
        """
        text_feature_matrix = np.array(self.text_feature_list, dtype=np.float)
        image_feature_matrix = np.array(self.image_feature_list, dtype=np.float)
        trade_feature_matrix = np.array(self.trade_feature_list, dtype=np.float)
        text_count_matrix = np.array(self.text_count_list, dtype=np.int32).reshape((-1, 1))
        image_count_matrix = np.array(self.image_count_list, dtype=np.int32).reshape((-1, 1))

        return {
            "text_feature_matrix": text_feature_matrix,
            "image_feature_matrix": image_feature_matrix,
            "trade_feature_matrix": trade_feature_matrix,
            "text_count_matrix": text_count_matrix,
            "image_count_matrix": image_count_matrix,
        }

    def summary(self, ori_dict=False):
        """汇总各维度的特征信息
        """
        cur_dict = self.to_dict()
        text_count = np.sum(cur_dict["text_count_matrix"])
        image_count = np.sum(cur_dict["image_count_matrix"])
        if text_count == 0:
            text_feature = [0] * self.text_feature_dim
        else:
            text_feature = (np.sum(cur_dict["text_feature_matrix"] * cur_dict["text_count_matrix"], axis=0) \
                / float(text_count)).tolist()
        #logging.info("text_feature: {}".format(text_feature))
        #image_feature = np.mean(cur_dict["image_feature_matrix"] * cur_dict["image_count_matrix"], axis=0).tolist()
        if image_count == 0:
            image_feature = [0] * self.image_feature_dim
        else:
            image_feature = (np.sum(cur_dict["image_feature_matrix"] * cur_dict["image_count_matrix"], axis=0) \
                / float(image_count)).tolist()
        trade_feature = np.sum(cur_dict["trade_feature_matrix"], axis=0)

        res_dict = {
            "text_feature": text_feature,
            "image_feature": image_feature,
            "trade_feature": trade_feature,
            "text_count": text_count,
            "image_count": image_count,
        }

        if ori_dict:
            res_dict["ori_dict"] = cur_dict

        return res_dict


class TaskMatrix(BaseMatrix):
    """任务矩阵
    """
    def __init__(self, text_feature_dim=128, image_feature_dim=128):
        super(TaskMatrix, self).__init__(text_feature_dim, image_feature_dim)
        self.task_id_list = list()
        self.task_id_index_dict = dict()
        self.in_time_list = list()
        self.wait_time_list = None

    def append(self, task_id, text_feature, image_feature, trade_feature,
            text_count, image_count, in_time):
        super(TaskMatrix, self).append(text_feature, image_feature, trade_feature, text_count, image_count)
        self.task_id_list.append(task_id)
        self.task_id_index_dict[task_id] = len(self.task_id_index_dict)
        self.in_time_list.append(in_time)

    def gen_wait_time(self, latest_time=None):
        """根据in_time_list和指定的latest_time生成wait_time_list
        """
        self.wait_time_list = list()
        for cur_time in self.in_time_list:
            # 如果没有latest_time 则默认in_time就是输入的wait_time
            if latest_time is None:
                self.wait_time_list.append(cur_time)
            else:
                self.wait_time_list.append(latest_time - cur_time)

    def to_dict(self):
        matrix_dict = super(TaskMatrix, self).to_dict()
        wait_time_matrix = np.array(self.wait_time_list, dtype=np.float).reshape((-1, 1))

        matrix_dict.update({
            "task_id_list": self.task_id_list,
            "wait_time_matrix": wait_time_matrix,
        })
        return matrix_dict

    def size(self):
        """返回当前给出的task大小
        """
        return len(self.task_id_list)

    def at(self, index):
        """返回指定位置的task_id
        """
        return self.task_id_list[index]


class AuditorMatrix(BaseMatrix):
    """审核员矩阵
    """
    def __init__(self, text_feature_dim=128, image_feature_dim=128):
        super(AuditorMatrix, self).__init__(text_feature_dim, image_feature_dim)
        self.auditor_id_list = list()
        self.request_num_list = list()
        self.available_indexs_list = list()
        self.efficiency_feature_list = list()

    def append(self, auditor_id, text_feature, image_feature, trade_feature, efficiency_feature,
            text_count, image_count, request_num, available_indexs):
        super(AuditorMatrix, self).append(text_feature, image_feature, trade_feature, text_count, image_count)
        self.auditor_id_list.append(auditor_id)
        self.request_num_list.append(request_num)
        self.available_indexs_list.append(available_indexs)
        self.efficiency_feature_list.append(efficiency_feature)

    def to_dict(self):
        matrix_dict = super(AuditorMatrix, self).to_dict()

        matrix_dict.update({
            "auditor_id_list": self.auditor_id_list,
            "request_num_list": self.request_num_list,
            "available_indexs_list": self.available_indexs_list,
            "efficiency_feature_matrix": np.array(self.efficiency_feature_list, dtype=np.float),
        })

        return matrix_dict

    def at(self, index):
        """返回指定位置的auditor_id
        """
        return self.auditor_id_list[index]


def auditor_matrix_dict_format(tar_dict):
    """将审核员信息矩阵字典转为response需要的格式
    """
    res_dict = {
        "target_user": []
    }
    for auditor_ind, auditor_id in enumerate(tar_dict["auditor_id_list"]):
        cur_auditor_info_dict = {
            "text_vector": tar_dict["text_feature_matrix"][auditor_ind].tolist(),
            "image_vector": tar_dict["image_feature_matrix"][auditor_ind].tolist(),
            "trade_vector": tar_dict["trade_feature_matrix"][auditor_ind].tolist(),
            "text_count": int(tar_dict["text_count_matrix"][auditor_ind]),
            "image_count": int(tar_dict["image_count_matrix"][auditor_ind]),
        }

        res_dict["target_user"].append({
            "key": auditor_id,
            "val": json.dumps(cur_auditor_info_dict),
        })

    return res_dict


class ADMatrix(BaseMatrix):
    """物料矩阵
    """
    def __init__(self, text_feature_dim=128, image_feature_dim=128):
        super(ADMatrix, self).__init__(text_feature_dim, image_feature_dim)
        self.in_time_list = list()
        self.ad_id_list = list()
        #self.ad_id_index_dict = dict()

    def append(self, ad_id, text_feature, image_feature, trade_feature, text_count, image_count, in_time):
        super(ADMatrix, self).append(text_feature, image_feature, trade_feature, text_count, image_count)
        self.ad_id_list.append(ad_id)
        #self.ad_id_index_dict[ad_id] = len(self.ad_id_index_dict)
        self.in_time_list.append(in_time)

    def to_dict(self):
        #start_time = time.time()
        matrix_dict = super(ADMatrix, self).to_dict()
        #upper_to_dict_time = time.time() - start_time

        #start_time = time.time()
        in_time_matrix = np.array(self.in_time_list, dtype=np.int32).reshape((-1, 1))
        #count_to_dict_time = time.time() - start_time

        matrix_dict.update({
            "in_time_matrix": in_time_matrix,
        })
        #logging.info("upper to dict time = {:.2f}s, count to dict time = {:.2f}s".format(
        #    upper_to_dict_time, count_to_dict_time))
        return matrix_dict

    def summary(self):
        """汇总各维度的特征信息
        """
        res_dict = super(ADMatrix, self).summary(ori_dict=True)
        ori_dict = res_dict.pop("ori_dict")
        #in_time_matrix = np.array(self.in_time_list, dtype=np.int32).reshape((-1, 1))
        in_time = int(np.min(ori_dict["in_time_matrix"]))

        res_dict["in_time"] = in_time

        return res_dict

    def size(self):
        """返回当前给出的task大小
        """
        return len(self.ad_id_list)

    def at(self, index):
        """返回指定位置的task_id
        """
        return self.ad_id_list[index]

def get_auditor_efficiency(efficiency_filepath, choice='mean'):
    """
    input:
        efficiency_filepath:    审核员历史效率统计文件
        choice：                选择策略，选择均值（mean）或者中位数（median）
    output：
        auditor_efficiency dict {auditorid: {'first_trade_level': {tradeid: value -> float}}}

    """
    assert os.path.exists(os.path.abspath(efficiency_filepath)), f'file not exists! [{efficiency_filepath}]'
    # aspect  tradeid auditorid   mean_direct_audit_efficiency    median_direct_audit_efficiency
    schema = None
    auditor_efficiency = defaultdict(lambda: defaultdict(lambda: defaultdict(float)))
    with codecs.open(efficiency_filepath, 'r', 'UTF-8') as fin:
        for index, line in tqdm(enumerate(fin), desc='load auditor efficiency file...'):
            if index == 0:
                schema = line.strip('\n').split('\t')
                continue
            effi_dict = {k:v for k, v in zip(schema, line.strip('\n').split('\t'))}
            auditor_efficiency[effi_dict['auditorid']][effi_dict['aspect']][effi_dict['tradeid']] = float(
                                                    effi_dict[f'{choice}_direct_audit_efficiency'])
    return copy.deepcopy(auditor_efficiency)

def gen_matrix(task_path, auditor_num, audit_batch_size,
               efficiency_filepath, trade_map_path="", auditor_vector_path="",
               max_num=None, text_feature_dim=128, image_feature_dim=128):
    """
    [out] audit_data_dict: dict, audit_data_dict[audit_data_id] = audit_data
          task_ad_matrix_dict: dict, task_ad_matrix_dict[task_id] = ADMatrix, 该任务下的物料的信息矩阵
    """
    # 行业ID字典
    # 如果指定了trade_map_path 则加载指定trade_index映射
    # 否则根据数据生成
    logging.info("trade_map_path: {}".format(trade_map_path))
    if trade_map_path == "":
        trade_id_index_dict = dict()
    else:
        trade_id_index_dict = load_trade_map(trade_map_path)

    audit_data_dict = dict()
    with codecs.open(task_path, "r", "gb18030") as rf:
        for index, line in tqdm(enumerate(rf), desc="load audit data"):
            if max_num is not None and index >= max_num:
                break
            cur_audit_data = ADAuditData.init_from_json(line.strip("\n"))
            cur_audit_data.text_list = [x for x in cur_audit_data.text_list if len(x) > 0]
            audit_data_dict[cur_audit_data.uid] = cur_audit_data
            if trade_map_path == "":
                for cur_trade_id in cur_audit_data.trade_id_list:
                    if cur_trade_id not in trade_id_index_dict:
                        trade_id_index_dict[cur_trade_id] = len(trade_id_index_dict)

    # 此时已生成行业字典 确定行业向量长度了
    trade_vec_size = len(trade_id_index_dict)
    #logging.info("trade index dict: {}".format(trade_id_index_dict))

    # 先构造审核员矩阵 因为审核员矩阵有可能要加载线上审核员行业向量
    # 线上审核员的行业向量有可能长度大于当前数据涉及的行业数 需要根据审核员的行业向量调整

    # 加载审核员特征
    # 如果文件地址为None 则生成初始化的审核员特征
    # 如果文件内审核员不够 则初始化补齐
    auditor_vector_list, trade_vec_size = load_auditor_vector(auditor_vector_path, auditor_num, trade_vec_size)

    # 根据各维度的大小 创立审核员矩阵
    auditor_matrix = AuditorMatrix(
        text_feature_dim=text_feature_dim,
        image_feature_dim=image_feature_dim,
        )

    # 获取审核员效率
    logging.info(f'Get auditor efficiency from file [{efficiency_filepath}]')
    auditor_efficiency = get_auditor_efficiency(efficiency_filepath, choice='mean')


    for cur_auditor_id, cur_auditor_vector in auditor_vector_list:
        efficiency_feature = np.zeros((trade_vec_size))
        this_auditor_id = cur_auditor_id if cur_auditor_id in auditor_efficiency.keys() else 'unkown'
        for tradeid, idx in trade_id_index_dict.items():
            aspect = 'first_level_trade' if len(tradeid) == 4 else 'second_level_trade'
            # 当tradeid不在历史效率统计dict中，用平均值填充
            if tradeid in auditor_efficiency[this_auditor_id][aspect]:
                efficiency_feature[idx] = auditor_efficiency[this_auditor_id][aspect][tradeid]
            else:
                efficiency_feature[idx] = auditor_efficiency[this_auditor_id][aspect]['total']

        auditor_matrix.append(
            auditor_id=cur_auditor_id,
            text_feature=cur_auditor_vector["text_vector"],
            image_feature=cur_auditor_vector["image_vector"],
            trade_feature=cur_auditor_vector["trade_vector"],
            efficiency_feature=efficiency_feature,
            text_count=cur_auditor_vector["text_count"],
            image_count=cur_auditor_vector["image_count"],
            request_num=audit_batch_size,
            available_indexs=None,
        )

    # 记录当前所有物料中最晚的进审时间
    latest_in_time = None
    # 先统计各audit_data所属任务
    # 将各物料加入到对应任务的ADMatrix中
    task_ad_matrix_dict = defaultdict(lambda: ADMatrix(text_feature_dim, image_feature_dim))
    for cur_audit_data in tqdm(audit_data_dict.values(), desc="load task matrix"):
        #logging.info("cur_audit_data: {}".format(cur_audit_data.text_vec_list))

        # 更新最晚的进审时间
        if latest_in_time is None or cur_audit_data.in_time > latest_in_time:
            latest_in_time = cur_audit_data.in_time

        # 生成当前数据的行业向量
        cur_trade_feature = np.zeros((trade_vec_size))
        for cur_trade_id in cur_audit_data.trade_id_list:
            cur_trade_index = trade_id_index_dict[cur_trade_id]
            cur_trade_feature[cur_trade_index] += 1

        # 文本向量
        cur_text_feature = None
        if len(cur_audit_data.text_vec_list) > 0:
            cur_text_feature = np.mean(np.array(cur_audit_data.text_vec_list), axis=0).tolist()

        # 图片向量
        cur_image_feature = None
        if len(cur_audit_data.image_vec_list) > 0:
            cur_image_feature=np.mean(np.array(cur_audit_data.image_vec_list), axis=0).tolist()

        # 将各物料加入对应task的ADMatrix中
        task_ad_matrix_dict[cur_audit_data.task_uid].append(
            ad_id=cur_audit_data.uid,
            text_feature=cur_text_feature,
            image_feature=cur_image_feature,
            trade_feature=cur_trade_feature,
            text_count=len(cur_audit_data.text_vec_list),
            image_count=len(cur_audit_data.image_vec_list),
            in_time=cur_audit_data.in_time,
        )

    task_matrix = TaskMatrix(text_feature_dim=text_feature_dim, image_feature_dim=image_feature_dim)
    # 根据各任务的ADMatrix 生成TaskMatrix
    for cur_task_id, cur_ad_matrix in task_ad_matrix_dict.items():
        task_matrix.append(
            task_id=cur_task_id,
            **cur_ad_matrix.summary())

        cur_ad_dict = cur_ad_matrix.to_dict()

    task_matrix.gen_wait_time(latest_in_time)

    logging.info("task size: {}".format(task_matrix.size()))

    return {
        "task_matrix": task_matrix,
        "auditor_matrix": auditor_matrix,
        "audit_data_dict": audit_data_dict,
        "task_ad_matrix_dict": task_ad_matrix_dict,
        }


def init_request_dict(auditor_matrix, task_matrix):
    """根据审核员和任务矩阵生成request
    """
    # 初始化请求字典
    request_dict = {
        "log_id": "11112222",
        "tag_name": ["task_distribution.task_distribution_v2"],
        "recommend_data": [{
            "data_id": 666,
            "source_elem":[],
            "target_user":[],
        }]
    }
    task_matrix_dict = task_matrix.to_dict()
    auditor_matrix_dict = auditor_matrix.to_dict()

    # 添加审核员信息
    for auditor_index, auditor_uid in enumerate(auditor_matrix_dict["auditor_id_list"]):
        cur_auditor_dict = {
            "text_vector": auditor_matrix_dict["text_feature_matrix"][auditor_index].tolist(),
            "image_vector": auditor_matrix_dict["image_feature_matrix"][auditor_index].tolist(),
            "trade_vector": auditor_matrix_dict["trade_feature_matrix"][auditor_index].tolist(),
            "efficiency_vector": auditor_matrix_dict["efficiency_feature_matrix"][auditor_index].tolist(),
            "text_count": int(auditor_matrix_dict["text_count_matrix"][auditor_index]),
            "image_count": int(auditor_matrix_dict["image_count_matrix"][auditor_index]),
            "request_num": auditor_matrix_dict["request_num_list"][auditor_index],
            "available_task_id": auditor_matrix_dict["available_indexs_list"][auditor_index],
        }
        request_dict["recommend_data"][0]["target_user"].append({
            "key": auditor_uid,
            "val": json.dumps(cur_auditor_dict),
        })

    # 添加任务信息
    for task_index, task_uid in enumerate(task_matrix_dict["task_id_list"]):
        cur_task_dict = {
            "text_vector": task_matrix_dict["text_feature_matrix"][task_index].tolist(),
            "image_vector": task_matrix_dict["image_feature_matrix"][task_index].tolist(),
            "trade_vector": task_matrix_dict["trade_feature_matrix"][task_index].tolist(),
            "text_count": int(task_matrix_dict["text_count_matrix"][task_index]),
            "image_count": int(task_matrix_dict["image_count_matrix"][task_index]),
            "wait_time": float(task_matrix_dict["wait_time_matrix"][task_index]),
        }

        request_dict["recommend_data"][0]["source_elem"].append({
            "key": task_uid,
            "val": json.dumps(cur_task_dict),
        })

    return request_dict


def update_request_dict(request_dict, new_auditor_matrix_dict, distributed_task_uid_set, audit_batch_size):
    """根据返回的分配结果和新的审核员向量更新request
    """
    # 去除已分配的任务
    assert len(request_dict["recommend_data"]) == 1
    left_task_uid_set = set()
    new_source_elem = list()
    source_elem_list = request_dict["recommend_data"][0]["source_elem"]
    for cur_ind, cur_task_dict in enumerate(source_elem_list):
        cur_task_uid = cur_task_dict["key"]
        if cur_task_uid in distributed_task_uid_set:
            continue
        left_task_uid_set.add(cur_task_uid)
        new_source_elem.append(cur_task_dict)
    request_dict["recommend_data"][0]["source_elem"] = new_source_elem

    # new_auditor_matrix_dict[auditor_id] = {"text_cluster_vector":xxx, "image_cluster_vector":xxx, "trade_vector":xxx}
    # 然后遍历request_dict中的审核员 更新信息
    new_target_user_list = list()
    for cur_user_dict in request_dict["recommend_data"][0]["target_user"]:
        cur_auditor_uid = cur_user_dict["key"]
        # 更换成新的
        if cur_auditor_uid in new_auditor_matrix_dict:
            cur_dict = new_auditor_matrix_dict[cur_auditor_uid]
        else:
            cur_dict = cur_user_dict["val"]
        cur_dict = json.loads(cur_dict)
        cur_dict["request_num"] = audit_batch_size
        new_target_user_list.append({
            "key": cur_auditor_uid,
            "val": json.dumps(cur_dict),
        })
    request_dict["recommend_data"][0]["target_user"] = new_target_user_list

    return request_dict, len(left_task_uid_set)


def auditor_matrix_dict_format(tar_dict):
    """将审核员信息矩阵字典转为response需要的格式
    """
    res_dict = {
        "target_user": []
    }
    for auditor_ind, auditor_id in enumerate(tar_dict["auditor_id_list"]):
        cur_auditor_info_dict = {
            "text_vector": tar_dict["text_feature_matrix"][auditor_ind].tolist(),
            "image_vector": tar_dict["image_feature_matrix"][auditor_ind].tolist(),
            "trade_vector": tar_dict["trade_feature_matrix"][auditor_ind].tolist(),
            "efficiency_vector": tar_dict["efficiency_feature_matrix"][auditor_ind].tolist(),
            "text_count": int(tar_dict["text_count_matrix"][auditor_ind]),
            "image_count": int(tar_dict["image_count_matrix"][auditor_ind]),
        }

        res_dict["target_user"].append({
            "key": auditor_id,
            "val": json.dumps(cur_auditor_info_dict),
        })

    return res_dict


def load_auditor_vector(auditor_vector_path, auditor_num, trade_vec_size):
    """加载线上审核员的向量 且加载指定数量
    """
    auditor_vector_list = list()
    if auditor_vector_path != "":
        with open(auditor_vector_path, mode="r", encoding="utf-8") as rf:
            for index, line in enumerate(rf):
                if index == 0:
                    continue
                parts = line.strip("\n").split("\t")
                auditor_id = parts[0]
                auditor_vector = json.loads(parts[1])
                # 确认行业向量最大的长度是多少
                cur_trade_vec_size = len(auditor_vector["trade_vector"])
                if cur_trade_vec_size > trade_vec_size:
                    trade_vec_size = cur_trade_vec_size
                auditor_vector_list.append((auditor_id, auditor_vector))
                if auditor_num is not None and len(auditor_vector_list) >= auditor_num:
                    break

    # 根据确认的最大长度 调整各auditor的trade_vec
    for _, auditor_vec in auditor_vector_list:
        pad_size = trade_vec_size - len(auditor_vec["trade_vector"])
        assert pad_size >= 0, "auditor vec size = {}, max vec size = {}".format(
            len(auditor_vec["trade_vector"]), trade_vec_size)
        auditor_vec["trade_vector"] += [0] * pad_size

    if auditor_num is not None:
        while len(auditor_vector_list) < auditor_num:
            auditor_vector_list.append((
                "pad_auditor_{}".format(len(auditor_vector_list)),
                {
                    "text_vector": None,
                    "image_vector": None,
                    "trade_vector": np.zeros((trade_vec_size)),
                    "text_count": 0,
                    "image_count": 0,
                }
            ))

    return auditor_vector_list, trade_vec_size


def load_trade_map(trade_map_path):
    """加载线上行业映射
    """
    trade_id_index_dict = dict()
    index_set = set()
    with open(trade_map_path, mode="r", encoding="utf-8") as rf:
        for index, line in enumerate(rf):
            if index == 0:
                continue
            parts = line.strip("\n").split("\t")
            cur_index = int(parts[0])
            # TODO 应该保证cur_index唯一 现在线上的数据还有问题 需要修复
            #assert cur_index not in index_set, "duplicate index: {}".format(cur_index)
            index_set.add(cur_index)
            trade_id = parts[1]
            # 如果trade重复 则后来的覆盖之前的
            trade_id_index_dict[trade_id] = cur_index

    return trade_id_index_dict


def cal_seq_sim_score(seq_list):
    """计算序列的一致度
    """
    total_sum = 0
    prev_count = 0
    prev_item = None
    for cur_item in seq_list:
        if cur_item != prev_item:
            if prev_item is not None:
                total_sum += prev_count * prev_count
            prev_item = cur_item
            prev_count = 0
        prev_count += 1

    if prev_item is not None:
        total_sum += prev_count * prev_count

    score = total_sum / float(len(seq_list))
    return score
