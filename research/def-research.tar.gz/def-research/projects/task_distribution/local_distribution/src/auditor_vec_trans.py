#!/usr/bin/env python3
# -*- coding:gb18030 -*-
"""
File  :   audit_vec_trans.py
Author:   zhanghao55@baidu.com
Date  :   21/09/06 18:20:02
Desc  :   
"""

import os
import sys
import json
import logging
import numpy as np
import pandas as pd
from tqdm import tqdm

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log
from lib.common.data_io import load_pkl

init_log()


def main(auditor_vec_path, trans_vec_path,
        text_cluster_model_path, image_cluster_model_path):

    text_cluster_model = load_pkl(text_cluster_model_path)
    image_cluster_model = load_pkl(image_cluster_model_path)

    text_cluster_centers = text_cluster_model.cluster_centers_
    image_cluster_centers = image_cluster_model.cluster_centers_
    logging.info(f"text cluster centers shape: {text_cluster_centers.shape}")
    logging.info(f"image cluster centers shape: {image_cluster_centers.shape}")

    df = pd.read_csv(auditor_vec_path, header=None, names=["id", "auditor_id", "vector", "add_time", "mod_time"]) 
    with open(trans_vec_path, mode="w", encoding="utf-8") as wf:
        for index, cur_row in df.iterrows():
            cur_auditor_id = cur_row["auditor_id"]
            cur_vector = json.loads(cur_row["vector"])
            #logging.info("cur vector type: {}".format(type(cur_vector)))
            #logging.info("cur vector keys: {}".format(cur_vector.keys()))
            new_vector = dict()
            new_vector["trade_vector"] = cur_vector["trade_vector"]
            new_vector["text_vector"], new_vector["text_count"] = \
                trans_vec(cur_vector["text_cluster_vector"], text_cluster_centers)
            new_vector["image_vector"], new_vector["image_count"] = \
                trans_vec(cur_vector["image_cluster_vector"], image_cluster_centers)
            #logging.info("new vector: {}".format(new_vector))
            wf.write(f"{cur_auditor_id}\t{json.dumps(new_vector)}\n")


def trans_vec(cluster_vec, cluster_centers):
    cluster_vec = np.array(cluster_vec).reshape((1, -1))
    #logging.info(f"cluster_vec shape: {cluster_vec.shape}")
    new_count = np.sum(cluster_vec)
    if new_count == 0:
        new_vec = np.zeros((1, cluster_centers.shape[1]))
    else:
        new_vec = np.dot(cluster_vec / new_count, cluster_centers)
    return new_vec.tolist(), new_count


if __name__ == "__main__":
    auditor_vec_path = sys.argv[1]
    trans_vec_path = sys.argv[2]
    #auditor_vec_path = "data/auditor_vec_20210906.csv"
    #trans_vec_path = "lo"
    main(
        auditor_vec_path=auditor_vec_path,
        trans_vec_path=trans_vec_path,
        text_cluster_model_path="local_distribution/cluster_model/text_cluster_model_2000",
        image_cluster_model_path="local_distribution/cluster_model/image_cluster_model_2000",
    )