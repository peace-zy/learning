#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   local_distribution.py
Author:   zhanghao55@baidu.com
Date  :   21/07/06 10:48:49
Desc  :
"""

import os
import sys
import json
import logging

from distribution_strategy_v2 import DistributionStrategyV2
from ad_sort import ADSort

from local_arguments import parse_args
from utils import AuditorMatrix, TaskMatrix, auditor_matrix_dict_format
from base_distribution import BaseDistribution

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log

init_log()


class LocalDistribution(BaseDistribution):
    """本地分配类
    """
    @classmethod
    def init_from_config(cls):
        """根据指定config初始化
        """
        config = parse_args()
        new_ins = cls(config)
        new_ins.init()

        new_ins.distribution_strategy = DistributionStrategyV2(
            delay_penalty=config.delay_penalty,
            delay_start=config.delay_start,
            delay_max=config.delay_max,
            text_weight=config.text_weight,
            image_weight=config.image_weight,
            sim_weight=config.sim_weight,
            trade_weight=config.trade_weight,
            efficiency_weight=config.efficiency_weight,
            epsilon=config.epsilon,
        )

        new_ins.ad_sort_strategy = ADSort(
            text_weight=config.text_weight,
            image_weight=config.image_weight,
            epsilon=config.epsilon,
        )

        return new_ins

    def distribution(self, request_dict):
        """分配
        """
        data_result = list()
        chosen_info_list = list()

        request_data = request_dict["recommend_data"]
        assert len(request_data) == 1, \
            "request_dict[\"recommend_data\"] size > 1, actual: {}".format(len(request_data))
        request_data = request_data[0]

        # 从request转回本地调用所需的matrix类
        task_matrix = TaskMatrix(
            text_feature_dim=128,
            image_feature_dim=128,
        )

        auditor_matrix = AuditorMatrix(
            text_feature_dim=128,
            image_feature_dim=128,
        )

        # 构建task matrix
        for cur_task in request_data["source_elem"]:
            cur_task_id = cur_task["key"]
            cur_task_dict = json.loads(cur_task["val"])
            # 这里是把wait_time存在了in_time中
            task_matrix.append(
                task_id=cur_task_id,
                text_feature=cur_task_dict["text_vector"],
                image_feature=cur_task_dict["image_vector"],
                trade_feature=cur_task_dict["trade_vector"],
                text_count=cur_task_dict["text_count"],
                image_count=cur_task_dict["image_count"],
                in_time=cur_task_dict["wait_time"],
            )
        # 上述循环中输入的in_time就是wait_time
        task_matrix.gen_wait_time(latest_time=None)

        # 构建auditor matrix
        for cur_auditor in request_data["target_user"]:
            cur_auditor_id = cur_auditor["key"]
            cur_auditor_dict = json.loads(cur_auditor["val"])
            cur_available_indexs = cur_auditor_dict.get("available_task_id", None)
            if cur_available_indexs is not None:
                cur_available_indexs = [task_matrix.task_id_index_dict[x] for x in cur_available_indexs]

            auditor_matrix.append(
                auditor_id=cur_auditor_id,
                text_feature=cur_auditor_dict["text_vector"],
                image_feature=cur_auditor_dict["image_vector"],
                trade_feature=cur_auditor_dict["trade_vector"],
                text_count=cur_auditor_dict["text_count"],
                image_count=cur_auditor_dict["image_count"],
                request_num=cur_auditor_dict["request_num"],
                efficiency_feature=cur_auditor_dict['efficiency_vector'],
                # available_index应该是task矩阵的行号列表 所以要根据可分配的task_id得到可以分配的行号
                available_indexs=cur_available_indexs,
            )

        # 分配
        dist_result, new_auditor_matrix_info, match_score = \
            self.distribution_strategy.distribute(task_matrix, auditor_matrix)

        # 构建要更新的审核员字典
        auditor_matrix_dict_list = auditor_matrix_dict_format(new_auditor_matrix_info)["target_user"]
        new_auditor_matrix_dict = dict()
        for cur_auditor_matrix_dict in auditor_matrix_dict_list:
            cur_auditor_uid = cur_auditor_matrix_dict["key"]
            new_auditor_matrix_dict[cur_auditor_uid] = cur_auditor_matrix_dict["val"]

        return dist_result, new_auditor_matrix_dict, match_score

    def sort(self, sort_list):
        """任务内排序
        """
        sort_result = list()
        for cur_auditor_uid, cur_ad_matrix, cur_info in sort_list:
            sorted_ad_id_list = self.ad_sort_strategy.sort(cur_ad_matrix)
            sort_result.append((cur_auditor_uid, sorted_ad_id_list, cur_info))
        return sort_result


def main():
    """主入口
    """
    dis = LocalDistribution.init_from_config()
    dis.run()


if __name__ == "__main__":
    main()
