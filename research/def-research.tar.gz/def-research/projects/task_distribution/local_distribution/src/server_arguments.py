#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   run_arguments.py
Author:   zhanghao55@baidu.com
Date  :   21/04/14 11:19:18
Desc  :   
"""

import os
import sys
import argparse


def parse_args(args=None):
    """运行参数配置解析
    """
    parser = argparse.ArgumentParser(description = "audit experiment run args")

    # ==================================== default =======================================
    default_group = parser.add_argument_group('default')
    default_group.add_argument("--output_dir", default = "output", help = "输出目录")

    # =================================== run config =====================================
    run_group = parser.add_argument_group('run_config')
    run_group.add_argument("--uniqid", default = "default", help = "当前任务标识")

    # =================================== auditor config =====================================
    auditor_group = parser.add_argument_group('auditor_config')
    auditor_group.add_argument("--auditor_num", type = int, default = 5, help = "审核人员数")
    auditor_group.add_argument("--auditor_vector_path", default = "", help = "审核员线上特征文件")
    auditor_group.add_argument("--trade_map_path", default = "", help = "行业映射文件")
    auditor_group.add_argument("--audit_batch_size", type = int, default = 10, help = "每次请求多少元素进行审核")
    auditor_group.add_argument("--efficiency_filepath", type = str, default = '', help = "历史审核员效率数据文件")

    # ================================== data config =====================================
    data_group = parser.add_argument_group('data_config')
    data_group.add_argument("--task_path", default=None, help = "审核数据输入文件位置")
    data_group.add_argument("--max_num", type = int, default = None, help = "输入数据最大值")
    data_group.add_argument("--encoding", default = "utf-8", help = "输入数据文件的编码")

    # ================================== config end ======================================

    # 解析参数
    pargs_res = parser.parse_args() if args is None else  parser.parse_args(args)

    # 结果输出位置
    pargs_res.distribution_info_path = os.path.join(
            pargs_res.output_dir,
            "server_distribution_info_{}.txt".format(pargs_res.uniqid),
            )

    pargs_res.distribution_res_path = os.path.join(
            pargs_res.output_dir,
            "server_distribution_res_{}.txt".format(pargs_res.uniqid),
            )

    return pargs_res

if __name__ == "__main__":
    args = parse_args()
    print(args)


