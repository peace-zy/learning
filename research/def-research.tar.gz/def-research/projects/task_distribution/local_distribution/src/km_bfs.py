#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   km_bfs.py
Author:   zhanghao55@baidu.com
Date  :   21/07/06 10:05:20
Desc  :   
"""

import sys
import collections
import logging


class KMBFS(object):
    """
    1. 各左集合点新增一个右集合点，该右集合点只与该左集合点相连，权值为-1
    2. 记录各左集合点相连的右集合点，遍历时就不再遍历所有右节点了
    3. 支持左集合点匹配多个右集合点，不再需要将匹配多个的左集合点重复多次了
    """
    def __init__(self, left_node_num, right_node_num, left_match_max=None, pad_weight=-1e13):
        """初始化
        """
        # 左集合点数量
        self.left_node_num = left_node_num
        # 右集合点数量
        self.right_node_num = right_node_num
        # 各左集合点可以匹配的最大量
        self.left_match_max = [1] * self.left_node_num if left_match_max is None else left_match_max
        # 右集合补齐后大小：实际右集合大小 + 各左集合点最大匹配量之和
        self.right_pad_num = sum(self.left_match_max) + self.right_node_num

        # 极大值
        self.inf = float("inf")
        # 补齐边的权值
        self.pad_weight = pad_weight
        # 图数据，None表示不连通 -1表示为补齐而添加的边和右集合点
        self.edges = [[None] * (self.right_pad_num) for _ in range(self.left_node_num)]
        # 记录各左集合点的连通边
        self.left_link = [list() for _ in range(self.left_node_num)]

        # 队列
        self.queue = collections.deque()

        # 如此声明会使得各list指向同一位置
        #self.left_match = [list()] * self.left_node_num
        # 各左集合点匹配结果 初始为空列表 左集合点可匹配多个右集合点
        # self.left_match[i] = [j,k]表示左集合点i与右集合点j和右集合点k的边是匹配边
        self.left_match = [list() for _ in range(self.left_node_num)]
        # 各右集合点匹配结果 None则无匹配 右集合点最多匹配一个左集合点
        self.right_match = [None] * self.right_pad_num
        # 记录交替路中 该右集合点应该反转匹配到的左集合点
        # self.new_right_match[i] = j表示右集合点i与左集合点j的边将变为匹配边
        self.new_right_match = [None] * self.right_pad_num
        # 记录交替路中 该左集合点应该反转其匹配的右集合点列表中的第几个
        # self.replace_left_match[i] = j表示反转时，左集合点i与右集合点self.left_match[self.replace_left_match[i]]的匹配边将变为非匹配边
        self.replace_left_match = [None] * self.left_node_num

        # 每次寻找增广路径时 会记录已访问的左右集合点
        self.left_visit = [False] * self.left_node_num
        self.right_visit = [False] * self.right_pad_num
        # 记录左右集合点的顶标值
        # 左集合点默认为极小值 之后会取其边权值最大的作为其顶标值的初始值
        # 右集合点默认为0
        self.left_value = [-self.inf] * self.left_node_num
        self.right_value = [0] * self.right_pad_num
        # 各右集合点的松弛量 每次松弛时根据该列表选择松弛值
        self.right_slack = [None] * self.right_pad_num

    def add_edge(self, left_node, right_node, weight):
        """添加权值
        """
        self.edges[left_node - 1][right_node - 1] = weight
        if self.pad_weight is None or weight < self.pad_weight:
            self.pad_weight = weight - 1
        # 记录连通的边
        self.left_link[left_node - 1].append(right_node - 1)

    def solve(self):
        """求解二分多重最优匹配
        """
        # 为每个左集合点加-1的权值 该点最大能匹配多少就加多少 方便其反转
        cur_right_index = self.right_node_num
        # 遍历左集合点
        for cur_left_index in range(self.left_node_num):
            # 各左集合点 能匹配多少 就加多少-1的权值节点
            for _ in range(self.left_match_max[cur_left_index]):
                # 边权值为-1
                self.edges[cur_left_index][cur_right_index] = self.pad_weight
                # 连通边
                self.left_link[cur_left_index].append(cur_right_index)
                # 下一个补齐的右集合点
                cur_right_index += 1

        for cur_left_node in range(self.left_node_num):
            # 遍历各左集合点
            for cur_right_node in self.left_link[cur_left_node]:
                # 以相邻边的最大权重初始化左集合点的顶标
                self.left_value[cur_left_node] = max(
                        self.left_value[cur_left_node],
                        self.edges[cur_left_node][cur_right_node],
                        )
                # 如果大于右集合点数 说明已遍历到新增的右集合点上 其边权值和当前遍历到的一样 全为-1 所以可以停止了
                if cur_right_node > self.right_node_num:
                    break
        
        for cur_left_node in range(self.left_node_num):
            # 各点最多匹配几次就重复几次
            for _ in range(self.left_match_max[cur_left_node]):
                # 遍历左集合各点 
                # 宽度优先寻找该点的最优匹配
                self.bfs(cur_left_node)

        score = 0
        for cur_left_node in range(self.left_node_num):
            for cur_right_index, cur_right_node in enumerate(self.left_match[cur_left_node]):
                # 将补齐的各右集合点统一去除
                if cur_right_node >= self.right_node_num:
                    self.left_match[cur_left_node][cur_right_index] = -1
                else:
                    assert self.edges[cur_left_node][cur_right_node] != self.pad_weight
                    score += self.edges[cur_left_node][cur_right_node]

        return score

    def bfs(self, left_index):
        """循环形式
        为当前节点寻找一个匹配
        """
        # 初始化各记录
        self.right_slack = [self.inf] * self.right_pad_num
        # 这两个记录不需要更新 但也可以更新掉
        self.new_right_match = [None] * self.right_pad_num
        self.replace_left_match = [None] * self.left_node_num
        # 各点均为未访问过
        self.left_visit = [False] * self.left_node_num
        self.right_visit = [False] * self.right_pad_num
        # 清空队列
        self.queue.clear()

        # 以当前左集合点作为起始点 加入队列
        self.queue.append(left_index)
        # 记录当前左集合点已访问
        self.left_visit[left_index] = True
        # 每次记录左集合点时 将其已匹配的右集合点也记录为已访问
        # 在check时记录新的左集合点 也要讲其已匹配的右集合点标记为已访问
        # 防止之后匹配到已匹配的边 也方便之后顶标的调整
        # 保持left_value+right_value=wxy
        for cur_right_match in self.left_match[left_index]:
            self.right_visit[cur_right_match] = True
        # 循环直到找到最优匹配????
        # TODO 要提前停止
        while True:
            while len(self.queue) > 0:
                # 寻找增广路
                cur_left_index = self.queue.popleft()
                # 遍历右集合点
                for cur_right_index in self.left_link[cur_left_index]:
                    # 如果已访问过 或是本次已访问的左集合点的匹配点 则跳过 不再重复访问
                    if self.right_visit[cur_right_index]:
                        continue
                    # 记录当前边的权值与当前两点顶标加起来的要求值的差距
                    # 下降该值 则该边将变为相等边
                    delta = self.left_value[cur_left_index] + self.right_value[cur_right_index] \
                            - self.edges[cur_left_index][cur_right_index]

                    #print("left #{}: {}, right #{}: {}, edge: {}, delta: {}".format(
                    #    cur_left_index,
                    #    self.left_value[cur_left_index],
                    #    cur_right_index,
                    #    self.right_value[cur_right_index],
                    #    self.edges[cur_left_index][cur_right_index],
                    #    delta,
                    #))
                    # 记录各右集合点所需的最小松弛量
                    if self.right_slack[cur_right_index] >= delta:
                        # 如果该松弛量小于等于当前右集合点标的松弛量 则更新
                        # new_right_match记录该右集合点达到最小松弛量时 对应的左集合点
                        # 更新交替路信息
                        self.new_right_match[cur_right_index] = cur_left_index
                        # 如果当前松弛量为零 则说明找到了相等边
                        if delta == 0:
                            # 检测当前右集合点i是否可以加入到左集合点的匹配列表self.new_right_match[i]
                            # 若可以 则找到了增广路径
                            # 否则就是交替路 加入队列等待
                            if self.check(cur_right_index):
                                return
                        else:
                            # 如果松弛量不为零 则更新到该右集合点的right_slack中
                            self.right_slack[cur_right_index] = delta
                            
            # 走到这说明以left_index开始的匈牙利树 没有增广路
            # 接下来调整顶标来扩大相等子图
            a = self.inf
            # TODO 这里就可以记录 当前哪些y在调整顶标后会是新的相等边
            # 遍历右集合点
            for j in range(self.right_pad_num):
                # 对于没有访问过的右集合点
                # 只有相等边的右集合点才会被访问
                # 所以没有访问过的右集合点的是right_slack都应该大于0
                # 找最小的松弛量
                if not self.right_visit[j]:
                    a = min(a, self.right_slack[j])

            # 遍历所有集合点 调整顶标 尝试扩大相等子图
            # 即left_index的匈牙利树中的左集合点
            for k in range(self.left_node_num):
                if self.left_visit[k]:
                    # 对于访问过的左集合点 其顶标都下降a
                    self.left_value[k] -= a
            new_equal_edge_list = list()
            for k in range(self.right_pad_num):    
                if self.right_visit[k]:
                    # 对于访问过的右集合点 为保证现有路径符合两点顶标之和不变 则其顶标需要增加a
                    self.right_value[k] += a
                else:
                    # 没有访问过的右集合点 因访问过的左集合点顶标都下降a 因此各右集合点的right_slack也会下降a
                    self.right_slack[k] -= a
                    # 调整松弛量时 就记录调整后出现的新的相等边 之后只遍历新的相等边 试图找到增广路径
                    if self.right_slack[k] == 0:
                        new_equal_edge_list.append(k)

            # 调整顶标后 遍历出现的新相等边
            # 必须调整完顶标后 再处理相等边 不然顶标没有全部更新
            for k in new_equal_edge_list:
                # 对于有新的相等边的右集合点 检测该右集合点是否可加入self.new_right_match[k]
                # 若可以 则找到了增广路径
                # 否则就是交替路 加入队列等待
                if self.check(k):
                    return

    def check(self, right_index):
        """检测是增广路还是交替路
        """
        # 当前左节点的相等边的右节点都会被访问
        # 记录当前右集合点被访问
        self.right_visit[right_index] = True

        # 获取当前右集合点right_index的匹配情况
        cur_left_match = self.right_match[right_index]
        # 左集合点的匹配量大于等于（应该只会等于）规定上限时 则反转
        if cur_left_match is not None and len(self.left_match[cur_left_match]) >= self.left_match_max[cur_left_match]:
            # 如果right_index已被匹配给某左集合点 且该左集合点的匹配上限已到
            # 则当前为交替路 将该节点加入队列 继续寻找增广路径
            self.queue.append(cur_left_match)

            # 记录当前交替路里 right_index对应为是该左集合点的第几个
            self.replace_left_match[cur_left_match] = self.left_match[cur_left_match].index(right_index)
            # 该左集合点所有匹配点都标记为已访问
            # 否则之后会可能会遍历到该点的其他匹配点 但这些点对应的匹配点是已访问过的左节点
            # 增广路径中是没有必要一个左节点出现两次的
            for cur_right_match in self.left_match[cur_left_match]:
                self.right_visit[cur_right_match] = True
            # 记录该左集合点已被访问
            self.left_visit[cur_left_match] = True
            # 表示当前没有找到增广路径
            return False

        # 否则确认了增广路径 根据记录不断反转增广路径上的匹配和非匹配边
        while right_index is not None:
            # 找到当前右集合点需要匹配的左集合点new_left_match
            new_left_match = self.new_right_match[right_index]
            # 将非匹配边变为匹配边
            self.right_match[right_index] = new_left_match 
            if self.replace_left_match[new_left_match] is None:
                # 如果该左集合点没有记录要替换的右集合点 则当前右集合点直接添加到该左集合点的匹配列表
                next_right_index = None
                self.left_match[new_left_match].append(right_index)
            else:
                # 如果该左集合点记录了要替换的右集合点 则替换
                # 记录该左集合点本来匹配的右集合点
                next_right_index = self.left_match[new_left_match][self.replace_left_match[new_left_match]]
                # 将原匹配边的左集合点加入到另一条匹配边
                self.left_match[new_left_match][self.replace_left_match[new_left_match]] = right_index

            # 变为原匹配边的右集合点 进行下一次反转 该右集合点也会在new_right_match中记录相应的可反转的非匹配边
            right_index = next_right_index

        # 表示当前已找到增广路径 并完成反转
        return True


def bfs_match():
    """测试入口
    """
    h = oj_data_load()
    score = h.solve()
    print("{}".format(score))
    print(" ".join(["{}".format([x + 1 for x in h.left_match[i]]) for i in range(h.left_node_num)]))


def local_load(lines):
    """本地读取数据
    """
    edges = None
    for index, line in enumerate(lines.strip("\n").split("\n")):
        parts = line.strip("\n").split()
        if index == 0:
            right_node_num = int(parts[0])
            left_node_num = int(parts[1])
            edges = [[0] * right_node_num for _ in range(left_node_num)]
        else:
            left_node_id = int(parts[0]) - 1
            right_node_id = int(parts[1]) - 1
            edges[left_node_id][right_node_id] = 1
    return edges


def oj_data_load():
    """读取数据
    """
    left_node_num, right_node_num, edge_num = map(int, sys.stdin.readline().strip().split())
    h = KMBFS(left_node_num, right_node_num)

    for _ in range(edge_num):
        left_node, right_node, weight = map(int, sys.stdin.readline().strip().split())
        h.add_edge(left_node, right_node, weight)

    return h


if __name__ == "__main__":
    bfs_match()