#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   base_distribution.py
Author:   zhanghao55@baidu.com
Date  :   21/09/22 15:48:49
Desc  :
"""

import os
import sys
import codecs
import logging
import time

from collections import defaultdict

from utils import gen_matrix, init_request_dict, update_request_dict, cal_seq_sim_score

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log

init_log()


class BaseDistribution(object):
    """分发基类
    """
    def __init__(self, config):
        self.config = config

    def init(self):
        """根据config初始化
        """
        # 生成matrix
        matrix_dict = gen_matrix(
                task_path=self.config.task_path,
                auditor_vector_path=self.config.auditor_vector_path,
                trade_map_path=self.config.trade_map_path,
                efficiency_filepath=self.config.efficiency_filepath,
                auditor_num=self.config.auditor_num,
                audit_batch_size=self.config.audit_batch_size,
                max_num=self.config.max_num,
                )

        task_matrix = matrix_dict["task_matrix"]
        auditor_matrix = matrix_dict["auditor_matrix"]

        self.audit_data_dict = matrix_dict["audit_data_dict"]
        self.task_ad_matrix_dict = matrix_dict["task_ad_matrix_dict"]
        self.left_task_num = task_matrix.size()
        self.request_dict = init_request_dict(auditor_matrix, task_matrix)

    def run(self):
        """开始分配
        """
        # 分配任务 直到待审task为空
        # 记录当前请求批数
        request_id = 0
        # 保存分配记录
        auditor_data_uid_dict = defaultdict(list)
        # 统计任务和物料维度各行业的统计信息
        # auditor_task_trade_count_dict[auditor][trade] = task_count
        auditor_task_trade_count_dict = defaultdict(lambda: defaultdict(int))
        # auditor_task_trade_list_dict[auditor] = list(trade)
        auditor_task_trade_list_dict = defaultdict(list)
        # auditor_data_trade_count_dict[auditor][trade] = ad_count
        auditor_data_trade_count_dict = defaultdict(lambda: defaultdict(int))
        # task_trade_total_count_dict[trade] = task_count
        task_trade_total_count_dict = defaultdict(int)
        # data_trade_total_count_dict[trade] = ad_count
        data_trade_total_count_dict = defaultdict(int)

        # task_auditor_trade_count_dict[trade][auditor] = task_count
        trade_auditor_task_count_dict = defaultdict(lambda: defaultdict(int))

        total_match_score = 0
        distributed_order = 0
        dist_time = 0
        ad_sort_time = 0

        while self.left_task_num > 0:
            logging.info("request #{}".format(request_id))
            request_id += 1

            dist_start_time = time.time()
            res = self.distribution(self.request_dict)
            dist_time += time.time() - dist_start_time

            assert res is not None, "fail at distribution func"
            # dist_result[i] = (auditor_id, task_id, chosen_info)
            # new_auditor_matrix_dict[auditor_id] = {"text_vector":xxx, "image_vector":xxx, "trade_vector":xxx}
            try:
                # local_dist时 res是三元组
                dist_result, new_auditor_matrix_dict, match_score = res
                total_match_score += match_score
            except ValueError as e:
                # server_dist时 res是二元组
                dist_result, new_auditor_matrix_dict = res

            # 处理分配结果
            # 记录当前分配出去的task_uid 之后从task_matrix中去除
            distributed_task_uid_set = set()
            # 记录当前分配的task_id 以及本次分配要排序的任务列表 一次性发送排序请求
            sort_list = list()
            for cur_auditor_uid, cur_task_uid, cur_info in dist_result:
                # 更新已分配的task_uid集合
                distributed_task_uid_set.add(cur_task_uid)
                # 获取该任务的各物料信息
                cur_ad_matrix = self.task_ad_matrix_dict[cur_task_uid]
                # 加入排序请求列表
                sort_list.append((cur_auditor_uid, cur_ad_matrix, cur_info))

            # 一次性请求所有排序 得到所有的排序结果
            ad_sort_start_time = time.time()
            # sort_result[i] = (cur_auditor_id, sorted_ad_id, cur_info)
            sort_result = self.sort(sort_list)
            ad_sort_time += time.time() - ad_sort_start_time

            assert sort_result is not None, "fail at sort func"

            # 遍历每个任务的排序结果
            for cur_auditor_uid, sorted_ad_id_list, cur_info in sort_result:
                # 记录当前任务 物料属于哪个行业标签
                cur_first_trade = None
                for cur_audit_data_uid in sorted_ad_id_list:
                    # 各任务的chosen_info转移到各物料
                    self.audit_data_dict[cur_audit_data_uid].chosen_info = "None" if cur_info is None else cur_info
                    self.audit_data_dict[cur_audit_data_uid].distributed_time = distributed_order
                    distributed_order += 1
                    # 记录分配结果
                    auditor_data_uid_dict[cur_auditor_uid].append(cur_audit_data_uid)
                    # 更新行业统计信息
                    if cur_first_trade is None:
                        cur_audit_data = self.audit_data_dict[cur_audit_data_uid]
                        cur_first_trade = cur_audit_data.trade_list[0] if len(cur_audit_data.trade_list) > 0 else "空"
                        # 任务级别 只记录一次
                        auditor_task_trade_count_dict[cur_auditor_uid][cur_first_trade] += 1
                        auditor_task_trade_list_dict[cur_auditor_uid].append(cur_first_trade)
                        task_trade_total_count_dict[cur_first_trade] += 1
                        trade_auditor_task_count_dict[cur_first_trade][cur_auditor_uid] += 1
                    # 物料级别 各物料都要记录
                    auditor_data_trade_count_dict[cur_auditor_uid][cur_first_trade] += 1
                    data_trade_total_count_dict[cur_first_trade] += 1

            # 移除已分配任务
            # 更新审核员信息
            self.request_dict, self.left_task_num = update_request_dict(
                self.request_dict,
                new_auditor_matrix_dict,
                distributed_task_uid_set,
                self.config.audit_batch_size,
                )

        logging.info("distribute time: {:.4f}s, ad sort: {:.4f}s".format(dist_time, ad_sort_time))

        # 记录分配结果
        with codecs.open(self.config.distribution_res_path, "w", "utf-8") as wf:
            for cur_auditor_uid, audit_data_uid_list in auditor_data_uid_dict.items():
                for cur_audit_data_uid in audit_data_uid_list:
                    cur_audit_data = self.audit_data_dict[cur_audit_data_uid]
                    wf.write("\t".join([
                        str(cur_auditor_uid),
                        cur_audit_data.task_uid,
                        cur_audit_data.userid,
                        cur_audit_data.ad_id,
                        "\x01".join(cur_audit_data.text_list),
                        "\x01".join(cur_audit_data.image_url_list),
                        "|||".join(cur_audit_data.trade_list),
                        str(cur_audit_data.in_time),
                        str(cur_audit_data.distributed_time),
                        cur_audit_data.chosen_info,
                        ]) + "\n")

        # 打印给审核员分配的结果
        with codecs.open(self.config.distribution_info_path, "w", "utf-8") as wf:
            # 匹配得分
            wf.write("=" * 150 + "\n")
            wf.write("total match score = {}\n".format(total_match_score))

            # 任务级别的各审核员各行业占比
            wf.write("=" * 150 + "\n")
            wf.write("任务级别各审核员各行业占比：\n")
            for cur_auditor_uid, cur_trade_count_dict in auditor_task_trade_count_dict.items():
                cur_seq_sim_score = cal_seq_sim_score(auditor_task_trade_list_dict[cur_auditor_uid])
                trade_count = 0
                task_count = 0
                trade_ratio_info = list()
                for cur_trade, cur_count in sorted(cur_trade_count_dict.items(), key=lambda x:x[1], reverse=True):
                    trade_count += 1
                    task_count += cur_count
                    trade_ratio_info.append("{}[{}/{:.2f}%]".format(
                        cur_trade,
                        cur_count,
                        cur_count * 100 / float(task_trade_total_count_dict[cur_trade]),
                        ))
                wf.write("auditor uid = {}, #task = {}, #trade = {}, seq_sim_score = {:.4f}: {}".format(
                    cur_auditor_uid,
                    task_count,
                    trade_count,
                    cur_seq_sim_score,
                    trade_ratio_info,
                    ) + "\n")

            # 任务级别 各行业各审核员占比
            wf.write("=" * 150 + "\n")
            wf.write("任务级别各行业各审核员分布占比：\n")
            for cur_trade, cur_auditor_count_dict in sorted(trade_auditor_task_count_dict.items()):
                auditor_count = 0
                task_count = 0
                auditor_ratio_info = list()
                for cur_auditor, cur_count in sorted(cur_auditor_count_dict.items(), key=lambda x:x[1], reverse=True):
                    auditor_count += 1
                    task_count += cur_count
                    auditor_ratio_info.append("{}[{}/{:.2f}%]".format(
                        cur_auditor,
                        cur_count,
                        cur_count * 100 / float(task_trade_total_count_dict[cur_trade]),
                        ))
                wf.write("trade = {}, #task = {}, #auditor = {}: {}".format(
                    cur_trade,
                    task_count,
                    auditor_count,
                    auditor_ratio_info,
                    ) + "\n")

            # 物料级别的各行业占比
            wf.write("=" * 150 + "\n")
            wf.write("物料级别各审核员各行业分布占比：\n")
            for cur_auditor_uid, cur_trade_count_dict in auditor_data_trade_count_dict.items():
                trade_count = 0
                data_count = 0
                trade_ratio_info = list()
                for cur_trade, cur_count in sorted(cur_trade_count_dict.items(), key=lambda x:x[1], reverse=True):
                    trade_count += 1
                    data_count += cur_count
                    trade_ratio_info.append("{}[{}/{:.2f}%]".format(
                        cur_trade,
                        cur_count,
                        cur_count * 100 / float(data_trade_total_count_dict[cur_trade]),
                        ))
                wf.write("auditor uid = {}, #data = {}, #trade = {}: {}".format(
                    cur_auditor_uid,
                    data_count,
                    trade_count,
                    trade_ratio_info
                    ) + "\n")

    def distribution(self, request_dict):
        """根据dict进行分配
        """
        raise NotImplementedError

    def sort(self, sort_list):
        """处理多个排序请求
        """
        raise NotImplementedError
