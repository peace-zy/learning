#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   server_distribution.py
Author:   zhanghao55@baidu.com
Date  :   21/07/06 10:48:49
Desc  :   
"""

import os
import sys
import json
import logging
import requests


from server_arguments import parse_args
from base_distribution import BaseDistribution

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log

init_log()


class ServerDistribution(BaseDistribution):
    """请求服务端分配类
    """
    @classmethod
    def init_from_config(cls):
        """根据指定config初始化
        """
        config = parse_args()
        new_ins = cls(config)
        new_ins.init()
        return new_ins
    
    def distribution(self, request_dict):
        """分配
        """
        response = requests.post(
            url="http://zhanghao55.bcc-szwg.baidu.com:8000/RecommendService/Recommend",
            data=json.dumps(request_dict))

        if response.status_code != 200:
            logging.warning("distribution response: {}".format(response.text))
            return None

        response = response.json()
        cur_data_result = response["result"][0]["data_result"]
        assert len(cur_data_result) == 1
        cur_data_result = cur_data_result[0]

        auditor_matrix_dict_list = json.loads(cur_data_result["details"])["target_user"]
        new_auditor_matrix_dict = dict()
        for cur_auditor_matrix_dict in auditor_matrix_dict_list:
            cur_auditor_uid = cur_auditor_matrix_dict["key"]
            new_auditor_matrix_dict[cur_auditor_uid] = cur_auditor_matrix_dict["val"]

        # dist_result[i] = (auditor_id, task_id, chosen_info)
        dist_result = list()
        for cur_relation_dict in cur_data_result["recommend_relation"]:
            dist_result.append((
                cur_relation_dict["target"],
                cur_relation_dict["source"],
                None,
            ))
        
        return dist_result, new_auditor_matrix_dict

    def sort(self, sort_list):
        """任务内排序
        """
        # 初始化请求字典
        # elem_array内 一个元素是一个排序的请求
        # elem_combine内是每个请求下的所有物料
        request_dict = {
            "log_id": "11112222",
            "tag_name": ["task_distribution.task_distribution_ad_sort"],
            "elem_array": [],
        }

        for cur_elem_ind, (cur_auditor_uid, cur_ad_matrix, cur_info) in enumerate(sort_list):
            # 构造当前的请求
            cur_request = {
                "elem_id": cur_elem_ind,
                "elem_combine": [],
            }
    
            for cur_ind, cur_ad_id in enumerate(cur_ad_matrix.ad_id_list):
                cur_ad_cont = {
                    "ad_id": cur_ad_id,
                    "text_vector": cur_ad_matrix.text_feature_list[cur_ind],
                    "image_vector": cur_ad_matrix.image_feature_list[cur_ind],
                    "text_count": cur_ad_matrix.text_count_list[cur_ind],
                    "image_count": cur_ad_matrix.image_count_list[cur_ind],
                }
                # 各物料加入该请求
                cur_request["elem_combine"].append({
                    "cont": json.dumps(cur_ad_cont)
                })
        
            request_dict["elem_array"].append(cur_request)
    
        response = requests.post(
            url="http://zhanghao55.bcc-szwg.baidu.com:8000/InferService/Infer",
            data=json.dumps(request_dict),
            )
    
        if response.status_code != 200:
            logging.warning("sort response: {}".format(response.text))
            return None

        response = response.json()
        #logging.info("response: {}".format(response))
    
        sort_result = list()
        cur_data_result = response["result"][0]["elem_tags"]
        for cur_res_ind, (cur_sort_res, (cur_auditor_uid, cur_ad_matrix, cur_info)) \
                in enumerate(zip(cur_data_result, sort_list)):
            cur_sorted_ad_id_list = json.loads(cur_sort_res["entity"][0]["details"][0])["ad_id_sorted_res"]

            assert cur_ad_matrix.size() == len(cur_sorted_ad_id_list), \
                "request ad size({}) != sorted res ad size({})".format(
                    cur_ad_matrix.size(),
                    len(cur_sorted_ad_id_list),
                    )
                
            sort_result.append((
                cur_auditor_uid,
                cur_sorted_ad_id_list,
                cur_info
            ))

        return sort_result


def main():
    """主入口
    """
    dis = ServerDistribution.init_from_config()
    dis.run()


if __name__ == "__main__":
    main()