#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   baijiahao_ori_dist_stat.py
Author:   zhanghao55@baidu.com
Date  :   21/11/1 11:01:25
Desc  :   
"""

import sys
import collections
from tqdm import tqdm

from utils import ADAuditData
from utils import cal_seq_sim_score


def format_dist_stat(format_path, dist_res_path, dist_info_path):
    """将data中的in_time和distribution_time改掉
    """
    # auditor_task_list_dict[auditor] = list(task)
    auditor_task_list_dict = collections.defaultdict(list)
    # 统计任务维度各行业的统计信息
    # auditor_task_trade_count_dict[auditor][trade] = task_count
    auditor_task_trade_count_dict = collections.defaultdict(lambda: collections.defaultdict(int))
    # auditor_task_trade_list_dict[auditor] = list(trade)
    auditor_task_trade_list_dict = collections.defaultdict(list)
    # task_trade_total_count_dict[trade] = task_count
    task_trade_total_count_dict = collections.defaultdict(int)
    # task_auditor_trade_count_dict[trade][auditor] = task_count
    trade_auditor_task_count_dict = collections.defaultdict(lambda: collections.defaultdict(int))
     
    task_list = list()
    with open(format_path, mode="r", encoding="utf-8") as rf:
        for index, line in tqdm(enumerate(rf), desc="load format data"):
            cur_format_data = ADAuditData.init_from_json(line.strip("\n"))
            # 按data的distributed_time字段排序 该字段其实是百家号数据中 各审核员审核完成的时间
            task_list.append((cur_format_data.distributed_time, cur_format_data))
    
    for _, cur_format_data in sorted(task_list):
            cur_auditor = cur_format_data.userid
            # 更新行业统计信息
            cur_first_trade = cur_format_data.trade_list[0] if len(cur_format_data.trade_list) > 0 else "空"
            if cur_first_trade == "\\\\N":
                cur_first_trade = "空"
            # 任务级别 只记录一次
            auditor_task_trade_count_dict[cur_auditor][cur_first_trade] += 1
            auditor_task_trade_list_dict[cur_auditor].append(cur_first_trade)
            auditor_task_list_dict[cur_auditor].append(cur_format_data)
            task_trade_total_count_dict[cur_first_trade] += 1
            trade_auditor_task_count_dict[cur_first_trade][cur_auditor] += 1

    # 记录分配结果
    with open(dist_res_path, mode="w", encoding="utf-8") as wf:
        for cur_auditor, task_list in auditor_task_list_dict.items():
            for cur_audit_data in task_list:
                wf.write("\t".join([
                    cur_auditor,
                    cur_audit_data.task_uid,
                    cur_audit_data.userid,
                    cur_audit_data.ad_id,
                    "\x01".join(cur_audit_data.text_list),
                    "\x01".join(cur_audit_data.image_url_list),
                    "|||".join(cur_audit_data.trade_list),
                    str(cur_audit_data.in_time),
                    str(cur_audit_data.distributed_time),
                    cur_audit_data.chosen_info,
                    ]) + "\n")

    # 打印给审核员分配的结果
    with open(dist_info_path, mode="w", encoding="utf-8") as wf:
        # 任务级别的各审核员各行业占比
        wf.write("=" * 150 + "\n")
        wf.write("任务级别各审核员各行业占比：\n")
        for cur_auditor, cur_trade_count_dict in auditor_task_trade_count_dict.items():
            cur_seq_sim_score = cal_seq_sim_score(auditor_task_trade_list_dict[cur_auditor])
            trade_count = 0
            task_count = 0
            trade_ratio_info = list()
            for cur_trade, cur_count in sorted(cur_trade_count_dict.items(), key=lambda x:x[1], reverse=True):
                trade_count += 1
                task_count += cur_count
                trade_ratio_info.append("{}[{}/{:.2f}%]".format(
                    cur_trade,
                    cur_count,
                    cur_count * 100 / float(task_trade_total_count_dict[cur_trade]),
                    ))
            wf.write("auditor uid = {}, #task = {}, #trade = {}, seq_sim_score = {:.4f}: {}".format(
                cur_auditor,
                task_count,
                trade_count,
                cur_seq_sim_score,
                trade_ratio_info,
                ) + "\n")

        # 任务级别 各行业各审核员占比
        wf.write("=" * 150 + "\n")
        wf.write("任务级别各行业各审核员分布占比：\n")
        for cur_trade, cur_auditor_count_dict in sorted(trade_auditor_task_count_dict.items()):
            auditor_count = 0
            task_count = 0
            auditor_ratio_info = list()
            for cur_auditor, cur_count in sorted(cur_auditor_count_dict.items(), key=lambda x:x[1], reverse=True):
                auditor_count += 1
                task_count += cur_count
                auditor_ratio_info.append("{}[{}/{:.2f}%]".format(
                    cur_auditor,
                    cur_count,
                    cur_count * 100 / float(task_trade_total_count_dict[cur_trade]),
                    ))
            wf.write("trade = {}, #task = {}, #auditor = {}: {}".format(
                cur_trade,
                task_count,
                auditor_count,
                auditor_ratio_info,
                ) + "\n")


if __name__ == "__main__":
    format_path = sys.argv[1]
    dist_res_path = sys.argv[2]
    dist_info_path = sys.argv[3]
    format_dist_stat(
        format_path,
        dist_res_path,
        dist_info_path,
    )