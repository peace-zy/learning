#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
File  :   time_stat.py
Author:   zhanghao55@baidu.com
Date  :   21/05/31 11:51:28
Desc  :   
"""

import sys
import codecs
import json
import time

import collections


def time_stat(uniq_audit_data_path):
    """ͳ�Ƹ�ʱ�ε��˻������ݡ���ҵ���
    """
    time_data_count = collections.defaultdict(int)
    # ��ʱ���˻���
    time_user_set = collections.defaultdict(set)
    # ��ʱ����ҵ��
    time_trade_count = collections.defaultdict(lambda: collections.defaultdict(int))
    # ʱ�μ���
    time_dict = dict()

    with codecs.open(uniq_audit_data_path, "r", "utf-8") as rf:
        for line in rf:
            line = line.strip("\n")
            obj = json.loads(line)
            date = time.localtime(obj["in_time"])
            date_list = [
                "{:0>4d}".format(date.tm_year),
                "{:0>2d}".format(date.tm_mon),
                "{:0>2d}".format(date.tm_mday),
                "{:0>2d}".format(date.tm_hour),
                    ]
            cur_time_str = "-".join(date_list)
            cur_time_int = int("".join(date_list))
            time_dict[cur_time_int] = cur_time_str

            time_data_count[cur_time_int] += 1
            time_user_set[cur_time_int].add(obj["userid"])

            trade = obj["trade_list"][0] if len(obj["trade_list"]) > 0 else "��"
            time_trade_count[cur_time_int][trade] += 1


    print("\t".join([
        "ʱ��",
        "�˻���",
        "������",
        "��ҵ����",
        ]))
    for cur_time_int, cur_time_str in sorted(time_dict.items(), key=lambda x:x[0]):
        cur_data_count = time_data_count[cur_time_int]

        # ��ǰtime����ҵ����
        trade_ratio = list()
        for trade_name, data_count in sorted(time_trade_count[cur_time_int].items(),
                key=lambda x:x[1], reverse=True)[:5]:
            trade_ratio.append("{}({:.2f}%|{})".format(
            trade_name,
            data_count * 100 / float(cur_data_count),
            data_count,
            ))

        print("\t".join([
            cur_time_str,
            str(len(time_user_set[cur_time_int])),
            str(cur_data_count),
            "{}".format(trade_ratio),
            ]))


if __name__ == "__main__":
    uniq_audit_data_path = sys.argv[1]

    time_stat(uniq_audit_data_path)
