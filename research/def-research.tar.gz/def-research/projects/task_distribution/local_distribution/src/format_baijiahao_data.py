#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   format_baijiahao_data.py
Author:   zhanghao55@baidu.com
Date  :   21/10/28 11:58:25
Desc  :   
"""

import os
import sys
import codecs
import copy
import json
import logging
import re
import time

from tqdm import tqdm
from extract_central_content import ExtractCentralContent
from utils import ADAuditData

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log

init_log()


def base_extract(content):
    """只提取汉字
    """
    return "".join(re.findall(r'[\u4e00-\u9fa5]', content))
     

def format_baijiahao_data(src_path, exclude_char_path, format_path,
        text_path, image_path, batch_extract_size=20, uniq=False):
    """将百家号审核数据转为ADAuditData格式的数据
    """
    extractor = ExtractCentralContent(
            host="10.232.210.26",
            port=8595,
            path="/FeatureService/batch_extract",
            exclude_char_path=exclude_char_path,
            )

    uniq_set = set()
    text_set = set([""])
    image_set = set([""])

    data_list = list()
    content_list = list()

    with open(src_path, mode="r", encoding="utf-8") as rf, \
            open(format_path, mode="w", encoding="utf-8") as audit_wf, \
            open(text_path, mode="w", encoding="utf-8") as text_wf, \
            open(image_path, mode="w", encoding="utf-8") as image_wf:

        for index, line in tqdm(enumerate(rf), desc="format baijiahao"):
            parts = line.strip("\n").split("\t")
            #print("parts: {}".format(parts))
            # user_id
            auditor_name = parts[45]
            # task_id
            task_id = "task#{}".format(index)
            # ad_id
            nid = parts[0]

            # image_url_list
            image_url_list = list()
            if parts[14] != "":
                image_url_list.extend(parts[14].split(";"))
            if parts[15] != "\\N":
                image_url_list.extend(parts[15].split(";"))

            # trade_list 包括mola.news_category_v3 mola.news_sub_category_v3 check_type
            trade_list = [x for x in parts[41:44] if x != "\\N"]

            # in_time
            #in_time = int(time.mktime(time.strptime(parts[8], '%Y-%m-%d %H:%M:%S')))
            in_time = int(parts[44])
            # distributed_time
            # 存储审核员完成任务的时间 以此判断各审核员各任务的顺序
            distributed_time = int(parts[47])

            # content
            content = parts[50]
            
            ad_audit_data = ADAuditData(
                    # 该字段记录审核员名字
                    userid = auditor_name,
                    task_uid = task_id,
                    ad_id = nid,
                    image_url_list = image_url_list,
                    # 所有标签放在trade_list
                    trade_list = trade_list,
                    trade_id_list = trade_list,
                    in_time = in_time,
                    distributed_time = distributed_time,
                    )

            data_list.append(ad_audit_data)
            content_list.append(content)
        
        #print("mod content: {}".format(content_list))
        text_list = extractor.batch_extract(content_list, batch_size=batch_extract_size, progress=True)
        assert len(text_list) == len(content_list)
        for cur_ind, (cur_audit_data, cur_text, cur_content) in enumerate(zip(data_list, text_list, content_list)):
            if cur_text is None:
                #logging.warning("extract fail. content:\n{}".format(cur_content))
                logging.warning("extract fail at line #{}".format(cur_ind + 1))
                cur_text = base_extract(cur_content)
                #logging.warning("base extract:\n{}".format(cur_text))
            
            cur_audit_data.text_list = [cur_text]
            
            # 如果该物料为空 则跳过该物料
            if len(cur_audit_data.text_list) == 0 and len(cur_audit_data.image_url_list) == 0:
                logging.warning("empty at line #{}".format(index + 1))
                continue

            # 记录新出现的text和image 并额外存储到单独文件中 方便之后生成对应的向量 并进行聚类
            for cur_text in cur_audit_data.text_list:
                if cur_text in text_set:
                    continue
                text_set.add(cur_text)
                text_wf.write(cur_text + "\n")
            for cur_image in cur_audit_data.image_url_list:
                if cur_image in image_set:
                    continue
                image_set.add(cur_image)
                image_wf.write(cur_image + "\n")

            if uniq:
                # 根据本物料包含的所有text和image生成uniq_key
                uniq_key = "\t".join(cur_audit_data.text_list + cur_audit_data.image_url_list)
                # 只有该物料上整体与历史上某物料一样 才跳过
                if uniq_key in uniq_set:
                    continue
                uniq_set.add(uniq_key)

            # 到这里的数据才写入文件
            audit_wf.write(cur_audit_data.to_json() + "\n")


if __name__ == "__main__":
    src_path = sys.argv[1]
    exclude_char_path = sys.argv[2]
    format_path = sys.argv[3]
    text_path = sys.argv[4]
    image_path = sys.argv[5]
    format_baijiahao_data(
            src_path,
            exclude_char_path,
            format_path,
            text_path,
            image_path,
            batch_extract_size=8,
            uniq=False,
            )