#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
File  :   ad_sort.py
Author:   zhanghao55@baidu.com
Date  :   21/07/06 10:05:20
Desc  :   
"""

import os
import sys
import logging
import pickle
import time
import numpy as np

from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics import pairwise_distances
from sklearn.cluster import AgglomerativeClustering


class ADSort(object):
    """任务分发 接收可分配任务矩阵和审核员矩阵
    """
    def __init__(self,
            text_weight=1.0, image_weight=1.0, 
            epsilon=1e-13,
            ):
        """初始化
        [in]  text_weight: float, 文本相似度权重
              image_weight: float, 图片相似度权重
              epsilon: float, 极小值
        """

        # 配置参数
        self.text_weight = text_weight
        self.image_weight = image_weight
        self.epsilon = epsilon

        logging.info("ADSort init succeed")

    def sort(self, ad_matrix):
        """对任务下的物料进行排序
        """
        def cal_distance(ad_matrix, sim_matrix=None, strict=True):
            """计算各物料指定维度的余弦距离
            """
            try:
                if sim_matrix is not None:
                    ad_matrix = np.dot(ad_matrix, sim_matrix)
                ad_distance = pairwise_distances(ad_matrix, metric="cosine")
            except ValueError as e:
                if strict:
                    logging.warning(e)
                # 失败则距离矩阵全为0
                ad_distance = np.zeros((ad_matrix.shape[0], ad_matrix.shape[0]))
            return ad_distance

        def combine(children_list):
            """合并给定的各子树
            """
            # 因为该树是层次聚类所得 子树内各节点距离一定小于子树间的距离
            # 所以合并子树各节点时 这里不需要考虑两子树各节点间哪组距离最近
            # 为适应审核习惯 将节点更多的子树放在前面
            res_list = list()
            for cur_children in sorted(children_list, key=lambda x:len(x), reverse=True):
                res_list.extend(cur_children)
            return res_list

        def sort_children(children_list, leaf_num):
            """根据层次聚类结果为物料排序
            """
            tree_dict = dict()
            # 叶子节点
            for cur_ind in range(leaf_num):
                tree_dict[cur_ind] = [cur_ind]
            # 聚合
            for cur_ind, cur_children in enumerate(children_list):
                #print("tree_dict: {}".format(tree_dict))
                cur_id = leaf_num + cur_ind
                #print("cur_id: {}".format(cur_ind))
                #print("cur_children: {}".format(cur_children))
                #print("="*100)
                cur_list = list()
                for cur_child in cur_children:
                    cur_list.append(tree_dict[cur_child])
                    del tree_dict[cur_child]
                tree_dict[cur_id] = combine(cur_list)
            assert len(tree_dict) == 1, "tree_dict size = {}: {}".format(len(tree_dict), tree_dict)
            return combine(tree_dict.values())

        if ad_matrix.size() > 2:
            total_begin_time = time.time()

            to_dict_time = time.time()
            ad_matrix_dict = ad_matrix.to_dict()
            to_dict_time = time.time() - to_dict_time

            distance_begin_time = time.time()

            text_distance_time = time.time()
            text_sim_distance = cal_distance(
                    ad_matrix_dict["text_feature_matrix"],
                    )
            text_distance_time = time.time() - text_distance_time

            image_distance_time = time.time()
            image_sim_distance = cal_distance(
                    ad_matrix_dict["image_feature_matrix"],
                    )
            image_distance_time = time.time() - image_distance_time

            count_distance_time = time.time()
            text_image_count_distance = cal_distance(np.concatenate((
                ad_matrix_dict["text_count_matrix"],
                ad_matrix_dict["image_count_matrix"],
                ), axis=-1))
            count_distance_time = time.time() - count_distance_time

            #logging.info("text_image_distance: {}".format(text_image_count_distance))
            #logging.info("text image count cost time: {:.2f}s".format(time.time() - start_time))
            sim_distance = text_sim_distance * self.text_weight \
                    + image_sim_distance * self.image_weight
            sim_distance /= float(self.text_weight + self.image_weight)
            total_distance = sim_distance + text_image_count_distance
            #logging.info("total_distance: {}".format(total_distance))
            #logging.info("combine cost time: {:.2f}s".format(time.time() - start_time))
            distance_end_time = time.time()

            cluster_begin_time = time.time()
            model = AgglomerativeClustering(affinity="precomputed", linkage="complete")
            model.fit(total_distance)
            cluster_end_time = time.time()

            sort_begin_time = time.time()
            sort_ind = sort_children(model.children_, leaf_num=total_distance.shape[0])
            sorted_ad_id_list = [ad_matrix.ad_id_list[ind] for ind in sort_ind]
            sort_end_time = time.time()

            total_end_time = time.time()

            #logging.info("task ad size = {}, time: [total = {:.2f}s, to_dict = {:.2f}s, " \
            #        "distance = {:.2f}s({:.2f}s + {:.2f}s + {:.2f}s), " \
            #        "cluster = {:.2f}s, sort = {:.2f}s]".format(
            #    ad_matrix.size(),
            #    total_end_time - total_begin_time,
            #    to_dict_time,
            #    distance_end_time - distance_begin_time,
            #    text_distance_time,
            #    image_distance_time,
            #    count_distance_time,
            #    cluster_end_time - cluster_begin_time,
            #    sort_end_time - sort_begin_time,
            #    ))
        else:
            sorted_ad_id_list = [x for x in ad_matrix.ad_id_list]

        return sorted_ad_id_list


if __name__ == "__main__":
    pass