#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   format_given_feed_audit_task.py
Author:   zhanghao55@baidu.com
Date  :   21/06/01 14:40:11
Desc  :   
"""

import os
import sys
import codecs
import logging
import time

from tqdm import tqdm
from utils import ADAuditData
_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log

init_log()


def load_user_meg(userid_meg_path, encoding="gb18030"):
    """加载账户行业信息
    """
    user_trade_id_dict = dict()
    user_trade_name_dict = dict()
    with codecs.open(userid_meg_path, "r", encoding) as rf:
        for line in tqdm(rf, desc="load user meg"):
            parts = line.strip("\n").split("\t")
            userid = parts[0]
            first_trade_id = parts[1]
            first_trade_name = parts[2]
            second_trade_id = parts[3]
            second_trade_name = parts[4]
            if first_trade_name == "其他":
                assert second_trade_name == "其他"
                user_trade_name_dict[userid] = [first_trade_name]
            else:
                user_trade_name_dict[userid] = [first_trade_name, second_trade_name]
            user_trade_id_dict[userid] = [first_trade_id, second_trade_id]
    return user_trade_id_dict, user_trade_name_dict


def format_given_feed_audit_task(src_path, user_meg_path, format_path, text_path, image_path, uniq=False):
    """将给定数据格式化为ADAuditData格式的数据 根据给定数据的不同 下面对数据信息提取逻辑可能也需要改变
    """
    user_trade_id_dict, user_trade_name_dict = load_user_meg(user_meg_path)
    uniq_set = set()
    text_set = set([""])
    image_set = set([""])
    with codecs.open(src_path, "r", "utf-8") as rf, \
            codecs.open(format_path, "w", "utf-8") as audit_wf, \
            codecs.open(text_path, "w", "utf-8") as text_wf, \
            codecs.open(image_path, "w", "utf-8") as image_wf:
        for index, line in tqdm(enumerate(rf), desc="format feed audit task"):
            parts = line.strip("\n").split("\t")
            ad_id = parts[0]
            task_id = parts[1]
            user_id = parts[2]
            #in_time = int(parts[3])
            in_time = int(time.mktime(time.strptime(parts[3], '%Y-%m-%d %H:%M:%S')))
            # 136产品线中 text只有一条 因此不用split
            text_list = [parts[4].strip()]
            # 可能有多个图片 空格间隔
            image_url_list = parts[5].strip().split()

            if user_id in user_trade_id_dict:
                assert user_id in user_trade_name_dict
                trade_id_list = user_trade_id_dict[user_id]
                trade_list = user_trade_name_dict[user_id]
            else:
                trade_id_list = []
                trade_list = []

            # 记录新出现的text和image 并额外存储到单独文件中 方便之后生成对应的向量 并进行聚类
            # 如果该物料为空 则跳过该物料
            if len(text_list) == 0 and len(image_url_list) == 0:
                logging.warning("empty at line #{}".format(index + 1))
                continue

            for cur_text in text_list:
                if cur_text in text_set:
                    continue
                text_set.add(cur_text)
                text_wf.write(cur_text + "\n")
            for cur_image in image_url_list:
                if cur_image in image_set:
                    continue
                image_set.add(cur_image)
                image_wf.write(cur_image + "\n")

            if uniq:
                # 根据本物料包含的所有text和image生成uniq_key
                uniq_key = "\t".join(text_list + image_url_list)
                # 只有该物料上整体与历史上某物料一样 才跳过
                if uniq_key in uniq_set:
                    continue
                uniq_set.add(uniq_key)

            ad_audit_data = ADAuditData(
                    userid=user_id,
                    task_uid=task_id,
                    ad_id=ad_id,
                    text_list=text_list,
                    image_url_list=image_url_list,
                    trade_list=trade_list,
                    trade_id_list=trade_id_list,
                    in_time=in_time,
                    )
            audit_wf.write(ad_audit_data.to_json() + "\n")


if __name__ == "__main__":
    src_path = sys.argv[1]
    user_meg_path = sys.argv[2]
    format_path = sys.argv[3]
    text_path = sys.argv[4]
    image_path = sys.argv[5]
    format_given_feed_audit_task(
            src_path,
            user_meg_path,
            format_path,
            text_path,
            image_path,
            False,
            )


