#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   extract_central_content.py
Author:   zhanghao55@baidu.com
Date  :   21/10/27 11:31:25
Desc  :   
"""

import sys
import copy
import json
import re
import requests
import logging
import time
from tqdm import tqdm

# 解决request的log过多的问题 
# 发现设置urllib3的log才有用
#logging.getLogger("requests").setLevel(logging.WARNING)
logging.getLogger("urllib3").setLevel(logging.WARNING)


def load_exclude_char(exclude_char_path):
    """生成特殊字符的模式
    """
    exclude_char_list = list()
    with open(exclude_char_path, mode="r", encoding="utf-8") as rf:
        for line in rf:
            exclude_char_list.append(line.strip("\n"))
    exclude_char_pattern = re.compile("[{}]".format("".join(exclude_char_list)))
    return exclude_char_pattern


class ExtractCentralContent(object):
    """正文提取客户端
    """
    def __init__(
            self,
            host,
            port,
            path="/FeatureService/batch_extract",
            exclude_char_path=None,
            ):
        self.host = host
        self.port = port
        self.path = path
        self.url = "http://{}:{}{}".format(
                self.host,
                self.port,
                self.path,
                )
        self.exclude_char_pattern = None
        if exclude_char_path is not None:
            self.exclude_char_pattern = load_exclude_char(exclude_char_path)

        self.task_template = {
            "url": "null",
            "session_id": "null",
            "state": 0,
            "page_info": {
                "crawl_feature": [
                    {
                        "final_url": "null",
                        "http_code": 200,
                        "uatype": 0,
                        "crawl_time": 0,
                        "page_length": 0,
                        "page_md5": "null"
                    }
                ],
                "page_source": "null",
            },
            "crawl_info": {
                "crawl_result": 0,
                "crawl_type": 0,
            },
            "ua_type": 0
        }

        self.req = {
            "log_id": 0,
            "job": {
                "tasks": [],
            },
        }

    def batch_extract(self, text_iter, batch_size=32, progress=False, max_retry=3):
        """批量提取正文
        """
        def gen_batch(tar_iter):
            """批处理
            """
            cur_batch = list()
            if progress:
                pbar = tqdm(desc="extract text")
            for cur_text in tar_iter:
                if len(cur_batch) >= batch_size:
                    yield cur_batch
                    cur_batch = list()
                cur_batch.append(cur_text)
                if progress:
                    pbar.update(1)
            if progress:
                pbar.close()
            if len(cur_batch) > 0:
                yield cur_batch

        res_list = list()
        for cur_batch in gen_batch(text_iter):
            cur_batch_size = len(cur_batch)
            cur_req = copy.deepcopy(self.req)
            for cur_text in cur_batch:
                cur_task = copy.deepcopy(self.task_template)
                if self.exclude_char_pattern is not None:
                    cur_text, mod_num = self.exclude_char_pattern.subn("", cur_text)
                    if mod_num > 0:
                        logging.warning("remove illegal char num: {}".format(mod_num))
                cur_task["page_info"]["page_source"] = cur_text
                cur_req["job"]["tasks"].append(cur_task)
                #logging.warning("text: {}".format(cur_text))
            
            # 该服务接收的是gb18030的请求
            # 因此json数据要自己变成gb18030的 所以要json.dumps是置ensure_ascii为False 然后字符串转gb18030
            cur_req = json.dumps(cur_req, ensure_ascii=False).encode("gb18030")
            #logging.warning("req data: {}".format(cur_req))
            #print("cur_req type: {}".format(type(cur_req)))
            #logging.warning("req data: {}".format(cur_req))
            cur_response = requests.post(self.url, data=cur_req)
            # 返回的也是gb18030的结果
            # 因此要手动设置结果的encoding
            cur_response.encoding = "gb18030"

            cur_retry_num = 0
            while cur_response.status_code != 200 and cur_retry_num < max_retry:
                logging.warning("post retry #{}. code = {}, info: {}".format(
                    cur_retry_num,
                    cur_response.status_code,
                    cur_response.text,
                    ))
                cur_retry_num += 1
                # 停1秒再请求
                time.sleep(1)

            if cur_response.status_code != 200:
                logging.error("post fail. code = {}, info: {}".format(cur_response.status_code, cur_response.text))
                #logging.error("error batch: {}".format(cur_batch))
                res_list.extend([None] * cur_batch_size)
            else:
                #print("cur_response: {}".format(cur_response))
                #print("cur_response text: {}".format(cur_response.text))
                cur_response_dict = cur_response.json()
                #print("cur_response_dict: {}".format(cur_response_dict))
                for cur_task in cur_response_dict["job"]["tasks"]:
                    cur_feature = cur_task["page_info"]["page_feature"]
                    res_list.append(
                        cur_feature["sem_central_content"]
                        )

        return res_list


def test():
    """测试
    """
    text_list = [
            '与中国贸易额离奇大增，今年将大幅突破1000亿美元。关系最差时，贸易数据反而突破了，出现“脱钩”现象。'
                '</p><p></p><p>1. 早在2010年，温家宝总理就和印度设立了双边贸易额1000亿美元的目标。那时只用10年就从29亿美元增长到617亿美元，'
                '20多倍。感觉到1000亿就是几下的事，再怎么2015年也行了。</p><p></p><p>2. 但是搞来搞去上不去，在700-800亿美元徘徊多年。'
                '印度方面最关注的是逆差太大，总有400多亿美元。莫迪上台后，关系还恶化了，感觉中印贸易遭遇挑战，要麻烦了。</p><p></p><p></p><p>'
                '3. 但是没有料到，2021年中印贸易额大幅暴增，前9月已经达到903亿美元，增长约50%（上半年增长65%），只用9个月就超过了过去一年的。'
                '全年预计增长40%达到1200亿美元，大幅突破。</p><p></p>'
                '<p class="bjh-image-container" data-bjh-caption-id="cap-b5149b09-c358-4b30-9c23-727f8d41b6c3" data-bjh-caption-text="">'
                '<img src="https://pic.rmb.bdstatic.com/bjh/2a09dd4dedbe72e3f8aecfe7ef5b26a5.jpeg" data-bjh-type="IMG"></p>'
                '<p class="bjh-image-caption" data-bjh-caption-for="cap-b5149b09-c358-4b30-9c23-727f8d41b6c3"></p><p></p><p>'
                '4. 印度方面对中国出口大增到200多亿美元，主要是铁矿石出口中国很多，在所有出口商品里一枝独秀。中国主要是电子产品部件、通信产品、'
                '计算机产品等ICT类很多，'
                '还有不少杂项。</p><p>例如小米和OV就在印度手机市场大吃份额，就算在印度组装也得进口手机零部件。'
                '印度人进入IT和移动通信时代就得和中国大做生意，''疫情应该加速了这个需求。</p><p></p>'
                '<p class="bjh-image-container" data-bjh-caption-id="cap-039a494e-437f-47d9-a1fe-d48f9dee9531" data-bjh-caption-text="">'
                '<img src="https://pic.rmb.bdstatic.com/bjh/3bb11dd3c27b3729faae18be10a48eb1.jpeg" data-bjh-type="IMG"></p>'
                '<p class="bjh-image-caption" data-bjh-caption-for="cap-039a494e-437f-47d9-a1fe-d48f9dee9531"></p><p></p><p>'
                '5. 中美贸易也有类似情况，关系最差还大加关税，贸易额反而暴增。也许这是一种“脱钩”，政客和民粹狂骂，但是商人和消费者身体很诚实。</p>'
                '<p>另外一种可能是，关系差，和政府勾结深的商人反而有渠道获得审批，更能赚钱。</p>'
                '<p>拜登和特朗普就都批准了不少许可证以及豁免关税。中印贸易也不可小看了，中国顺差能有700多亿了，仅次于对美顺差。</p><p></p>'
                '<p class="bjh-image-container" data-bjh-caption-id="cap-fb120fd1-4bcd-47af-b4ca-f339d2888819" data-bjh-caption-text="">'
                '<img src="https://pic.rmb.bdstatic.com/45c6a12dd939e3f0eb304e0cc65e4fa7.jpg'
                '@wm_1,k_cGljX2JqaHdhdGVyLmpwZw==" '
                'data-bjh-type="IMG"></p>'
                '<p class="bjh-image-caption" data-bjh-caption-for='
                '"cap-fb120fd1-4bcd-47af-b4ca-f339d2888819"></p><p></p><p></p>',
            '记者从北京大兴区了解到，根据近日北京市新冠肺炎确诊患者的调查情况，涉及在大兴区有如下活动轨迹：'
                '10月19日16时至16时15分，患者曾使用“大兴区京开高速进京方向天宫院街道近六环处中国石油京胜京开东加油站卫生间</p>'
                '<p>[cp]“大兴区京开高速进京方向天宫院街道近六环处中国石油京胜京开东加油站卫生间”。 '
                '导航上有这个地方，名字没这么长，就叫“中国石油京胜京开东加油站。” </p><p></p><p></p>',
            '<p>西藏对于很多人而言都是理想中的圣地，如果你想洗涤自己的心灵，那就来一趟西藏之行吧。</p>'
                '<p><br></p>'
                '<p>截止到目前，人们进西藏的公路主要有八条，比较知名的道路是青藏线和川藏线。</p>'
                '<p><br></p>'
                '<p>然而在这八条线路中，还有一条线路十分适合自驾游，堪称最美进藏路线，它就是新藏线G219。</p>'
                '<p>当你见到珠峰之后，你就已经到达了藏区的最南端，这时候你就要向中国的西南边陲进发了，前面的景色更加静美，'
                    '蓝天白云和雪山松林让你怀疑自己是不是到了瑞士，这里当然不是瑞士，而是我们的雪域江南林芝地区的鲁朗。</p>'
                '<p>离开鲁朗之后，会进入一个十分神秘的少数民族部落僜人部落。</p>'
                '<p><br></p>'
                '<p>这个部落至今没有族称，人口只有一千四百多人，暂未归属五十六个民族中的任何一个。</p>'
                '<p><br></p>'
                '<p>僜人最让男士羡慕的是，他是中国唯一的一夫多妻制度的合法部落，男性拥有越多的牛就能娶越多的老婆，因为在这里牛是财富的象征。</p>'
                '<p>离开察隅地区之后，G219就来到了进藏第七线被称为天险的丙察察。</p>'
                '<p><br></p>'
                '<p>曾经的丙察察被誉为最难进藏路，穿行在山岭、悬崖、江河和峡谷之中，在之前经常会出现事故，后来国家对其进行大力整改，'
                    '并在最危险的地方加上了护栏，如今已经十分安全了。</p>'
                '<p>离开丙察察继续前行就来到了G219的另一个路段，开始进入云南。</p>'
                '<p><br></p>'
                '<p>云南地处我国西南边陲，缅甸、越南、老挝接壤。</p>'
                '<p><br></p>'
                '<p>G219也就是随着边境而建的，当我们沿着中越边境国防小道S325沿边公路走过云南，也就意味着新G219的旅途已经快到达终点。</p>'
                '<p>这一路人们可以直接和越南的山水相望，公路和国境线之间几乎零距离。</p>'
                '<p><br></p>'
                '<p>当我们离开云南来到广西东兴市，这个中国陆地边境线和海岸线的连接点，也就意味着我们G219之旅的结束，'
                    '我们也就完成了从新疆经西藏、云南到广西10860公里的全程，可以说是不虚此行了。</p>',
            # 测试第二个字节为\x5c的汉字能否成功
            '僜',
            '乗',
            '猏',
            '黒',
            '‐',
            '燶',
            ]
    #text_list = ['<p>There is always someone who will make you think the world is worth it.<br>总有那么一个人会让你觉得人间值得.</p><p class="bjh-image-container" data-bjh-caption-id="cap-8559aac3-e356-4a50-902b-ef4bd0e60b55" data-bjh-caption-text="fashion水木"><img src="https://pic.rmb.bdstatic.com/bjh/a1e0dadfd475ac9c54000fb943e61d8e.jpeg@wm_2,t_55m+5a625Y+3L3JlYWznmb7liIbkuYvkuIk=,fc_ffffff,ff_U2ltSGVp,sz_27,x_17,y_17" data-bjh-type="IMG"></p><p class="bjh-image-caption" data-bjh-caption-for="cap-8559aac3-e356-4a50-902b-ef4bd0e60b55">fashion水木</p><p>fashion水木</p><p></p>',
    #]
    #text_list = ['[(12*a我的妈\我的吗\tasd 午后好导师i\b案发\n哦s\raq 啊啥的啊啥企鹅温柔去']
    client = ExtractCentralContent(
            host="10.232.210.26",
            port=8595,
            path="/FeatureService/batch_extract",
            exclude_char_path="data/exclude_char.txt",
            )
    for cur_ind, cur_text in enumerate(text_list):
        res_list = client.batch_extract([cur_text])
        cur_res = res_list[0]
        print("#{}: {}".format(cur_ind, cur_res))


def extract_by_file(file_path=None, output=None, batch_size=1, exclude_char_path=None):
    """对指定文件，提取每行内容的正文
    """
    client = ExtractCentralContent(
            host="10.232.210.26",
            port=8595,
            path="/FeatureService/batch_extract",
            exclude_char_path=exclude_char_path,
            )

    content_list = list()
    if file_path is None:
        for line in sys.stdin:
            line = line.strip("\n")
            content_list.append(line)
    else:
        with open(file_path, mode="r", encoding="utf-8") as rf:
            for line in rf:
                line = line.strip("\n")
                content_list.append(line)

    text_list = client.batch_extract(content_list, batch_size=batch_size, progress=True)

    if output is None:
        for cur_content, cur_text in zip(content_list, text_list):
            if cur_text is None:
                continue
            print(json.dumps({
                "content": cur_content,
                "text": cur_text,
                }, ensure_ascii=False))
    else:
        with open(output, mode="w", encoding="utf-8") as wf:
            for cur_content, cur_text in zip(content_list, text_list):
                if cur_text is None:
                    continue
                wf.write(json.dumps({
                    "content": cur_content,
                    "text": cur_text,
                    }, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description='extract text.')
    parser.add_argument('-f', '--file', default=None, help='input file path')
    parser.add_argument('-b', '--batch_size', type=int, default=8, help='request text batch size')
    parser.add_argument('-o', '--output', default=None, help='output file path')
    parser.add_argument('-e', '--eclude_char_path', default=None, help='output file path')
    args = parser.parse_args()
    #extract_by_file(
    #        file_path=args.file,
    #        output=args.output,
    #        batch_size=args.batch_size,
    #        exclude_char_path=exclude_char_path,
    #        )
    test()
