#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
File  :   distribution_strategy_v2.py
Author:   zhanghao55@baidu.com
Date  :   21/07/06 10:05:20
Desc  :
"""

import os
import sys
import logging
import pickle
import time
import numpy as np
import numpy.ma as ma

from sklearn.metrics.pairwise import cosine_similarity

from km_bfs import KMBFS


def cal_vec_avg(ori_vec, ori_num, inc_vec, inc_num):
    """更新矩阵时，需要对矩阵乘以ori_num求总和，然后平均
       为防止乘积结果过大，决定将
       (ori_vec*ori_num+inc_vec*inc_num)/(ori_num+inc_num)
       转变为
       ori_part+inc_part
       其中：
       ori_part=ori_vec*(ori_num/(ori_num+inc_num))
       inc_part=inc_vec*(inc_num/(ori_num+inc_num))
    [in]  ori_vec: 原矩阵平均值
          ori_num: int, 非负数，原矩阵对应的数量
          inc_vec: 新增矩阵平均值
          inc_num: int, 非负数，新增矩阵对应的数量
    [out] avg_vec: 新的矩阵平均值
          avg_num: 新的矩阵对应的数量
    """
    assert ori_num >= 0 and inc_num >= 0, \
        "ori_num and inc_num cannot be smaller than 0"

    avg_vec = None
    avg_num = None

    if ori_num == 0:
        avg_num = inc_num
        avg_vec = inc_vec.copy()
    elif inc_num == 0:
        avg_num = ori_num
        avg_vec = ori_vec.copy()
    else:
        avg_num = inc_num + ori_num
        avg_vec = ori_vec * (ori_num / float(avg_num)) + \
            inc_vec * (inc_num / float(avg_num))

    return avg_vec, avg_num


def diff_matrix(score_matrix):
    """矩阵变为对比矩阵
    对于矩阵的每一行 该行的每个值=该值-对应列除该行外的最大值
    """
    row_num, col_num = score_matrix.shape
    masked_score_matrix = ma.masked_array(score_matrix, mask=False)

    diff_score_list = list()
    for cur_row_index in range(row_num):
        # 除自身以外，各任务的最高相似度
        masked_score_matrix.mask[cur_row_index] = True
        cur_others_max_score = masked_score_matrix.max(axis=0)
        masked_score_matrix.mask[cur_row_index] = False
        # 自身在各任务的相似度
        cur_own_score = masked_score_matrix[cur_row_index]
        diff_score_list.append(cur_own_score - cur_others_max_score)
    
    diff_score_matrix = np.vstack(diff_score_list)
    return diff_score_matrix


class DistributionStrategyV2(object):
    """任务分发 接收可分配任务矩阵和审核员矩阵
    """
    def __init__(self,
            delay_penalty=1, delay_start=1800.0, delay_max=3600.0,
            text_weight=1.0, image_weight=1.0,
            sim_weight=1.0, trade_weight=1.0, efficiency_weight=1.0,
            epsilon=1e-13,
            ):
        """初始化
        [in]  delay_penalty: int, 1则分配时考虑待审时长，否则不考虑
              delay_start: float, 待审时间得分开始时间
              delay_max: float, 待审时间绝对优势时间
              text_weight: float, 文本相似度权重
              image_weight: float, 图片相似度权重
              sim_weight: float, 相似维度权重
              trade_weight: float, 行业维度权重
              efficiency_weight: float, 效率维度权重
              epsilon: float, 极小值
        """

        # 配置参数
        assert delay_penalty == 0 or delay_penalty == 1, \
            "expect delay_penalty == 0 or 1, actual {}".format(delay_penalty)
        self.delay_penalty = delay_penalty
        self.delay_start = delay_start
        self.delay_max = delay_max
        self.text_weight = text_weight
        self.image_weight = image_weight
        self.sim_weight = sim_weight
        self.trade_weight = trade_weight
        self.efficiency_weight = efficiency_weight
        self.epsilon = epsilon

        logging.info("DistributionStrategyV2 init succeed")

    def cal_count_priority(self, count_matrix, auditor_index):
        """根据计数矩阵计算指定审核员在各类型上的优势得分
        [in]  count_matrix: matrix, 各审核员审核各类型的计数矩阵,
                            count_matrix[ai][cj] = xxx，审核员ai审核过类型cj的数目
              auditor_index: int, 指定审核员在矩阵中的index
        [out] count_priority: vector, 指定审核员在各类型上的优势得分
        """
        # 变为mask array
        count_matrix = ma.masked_array(count_matrix, mask=False)
        # TODO 这里只是简单根据各审核员审核数来确定该审核员在各类型的权重
        # 可以参考tfidf bm25等方案
        # 来确定 哪些类型 对于该审核员最重要
        # 计算各审核员审核各类型的占比
        count_ratio = count_matrix / (count_matrix.sum(axis=0) + self.epsilon)
        # 除指定审核员自身外各审核员在各类型上的最高审核量占比
        count_ratio.mask[auditor_index] = True
        count_ratio_others_max = count_ratio.max(axis=0)
        count_ratio.mask[auditor_index] = False
        # 指定审核员自身在各类型的审核量占比
        count_ratio_self = count_ratio[auditor_index]
        # 指定审核员在各类型上的优势得分(负数则表示该类型上有别的审核员审核比自己更多)
        count_priority = count_ratio_self - count_ratio_others_max
        return count_priority

    def cal_matrix_score(self, task_matrix, auditor_matrix, auditor_index, available_index=None, sim_matrix=None):
        """根据任务和审核员某维度的计数矩阵计算各任务对于指定审核员在该维度上的得分
        [in]  task_matrix: matrix, 各任务各类型的计数矩阵,
              auditor_matrix: matrix, 各审核员各类型的计数矩阵
              auditor_index: int, 指定审核员在矩阵中的index
              available_index: int, 指定审核员可分配的任务
              sim_matrix: matrix, 高相似等效矩阵
        [out] priority: vector, 指定审核员在各类型上的优势得分
        """

        # 只取指定范围的task计算
        if available_index is not None:
            task_matrix = task_matrix[available_index]
        if sim_matrix is not None:
            auditor_matrix = np.dot(auditor_matrix, sim_matrix)
        # 计算指定审核员在各维度上的经验优势得分 得到经验优势得分向量
        auditor_priority = self.cal_count_priority(auditor_matrix, auditor_index).reshape((-1, 1))
        # 各任务的各维度的计数转为在任务中的占比
        task_matrix = task_matrix / (task_matrix.sum(axis=1, keepdims=True) + self.epsilon)
        # 各任务各维度的占比 与 该审核员在各维度的经验优势得分向量 做内积
        # 得到该审核员在各任务上得分
        matrix_score = np.dot(task_matrix, auditor_priority).reshape((-1, 1))
        return matrix_score

    def cal_vec_matrix_score(self, task_vec_matrix, auditor_vec_matrix, auditor_index, available_index=None):
        """任务、审核员向量维度矩阵得分
        """
        # 只取指定范围的task计算
        if available_index is not None:
            task_vec_matrix = task_vec_matrix[available_index]

        # 计算各审核员与各任务的得分
        start_time = time.time()
        auditor_task_sim = cosine_similarity(auditor_vec_matrix, task_vec_matrix)
        #logging.debug("auditor_task_sim time: {:.4f}s, shape: {}".format(
        #    time.time() - start_time,
        #    auditor_task_sim.shape,
        #    ))

        # 变为mask array
        auditor_task_sim = ma.masked_array(auditor_task_sim, mask=False)
        # 除自身以外，各任务的最高相似度
        auditor_task_sim.mask[auditor_index] = True
        auditor_task_sim_others_max = auditor_task_sim.max(axis=0)
        auditor_task_sim.mask[auditor_index] = False
        # 自身在各任务的相似度
        auditor_task_sim_self = auditor_task_sim[auditor_index]
        #logging.info("auditor other max shape: {}".format(auditor_task_sim_others_max.shape))

        # 自身在各任务的相似度优势
        auditor_task_sim_priority = auditor_task_sim_self - auditor_task_sim_others_max
        #logging.info("auditor_task_sim_priority: {}".format(auditor_task_sim_priority))

        return auditor_task_sim_priority.reshape((-1, 1))

    def cal_delay_score(self, wait_time_matrix, available_index=None):
        """任务待审时间得分
        [in]  wait_time_matrix: matrix, 各任务待审时间矩阵
              available_index: list, 可分配任务index列表
        [out] delay_score: matrix, 待审时间得分
        """
        # 只取指定范围的task计算
        if available_index is not None:
            wait_time_matrix = wait_time_matrix[available_index]
        delay_time_matrix = wait_time_matrix - self.delay_start
        # 待审时间得分 时间越长 得分越高
        delay_score =  np.where(delay_time_matrix > 0, delay_time_matrix, 0) / float(self.delay_max)
        return delay_score

    def cal_efficiency_score_matrix(self, task_vec_matrix, auditor_vec_matrix):
        """
        计算任务和审核员历史审核效率得分矩阵
        """
        assert task_vec_matrix.shape[1] == auditor_vec_matrix.shape[1], 'task and auditor must be same size along tradeids axis'
        return (auditor_vec_matrix @ np.array(task_vec_matrix > 0).astype(int).T) / 2.

    def cal_efficiency_score_by_auditor(self, task_vec_matrix, auditor_vec_matrix, auditor_index, available_index=None):
        """
        计算任务和审核员历史审核效率得分矩阵
        """
        if available_index is not None:
            task_vec_matrix = task_vec_matrix[available_index]
        score_matrix = self.cal_efficiency_score_matrix(task_vec_matrix, auditor_vec_matrix)
        return (score_matrix[auditor_index] - np.vstack([score_matrix[:auditor_index],
                                                         score_matrix[auditor_index + 1:]]).max(axis=0)).reshape((-1, 1))

    def norm(self, cur_matrix, axis=None):
        """归一化(全局)
        [in]  cur_matrix: matrix, 输入矩阵
              axis: int, 归一化的轴
        [out] norm_matrix： matrix, 归一化后的矩阵
        """
        # 找出全局的最大值和最小值
        cur_matrix_max = cur_matrix.max(axis=axis)
        cur_matrix_min = cur_matrix.min(axis=axis)
        # 如果最大值等于最小值 则最大值变大一点 防止除数为0
        if cur_matrix_max.ndim > 0:
            cur_matrix_max[cur_matrix_max == cur_matrix_min] += self.epsilon
        elif cur_matrix_max == cur_matrix_min:
            cur_matrix_max += self.epsilon
        norm_matrix = (cur_matrix - cur_matrix_min) / (cur_matrix_max - cur_matrix_min)
        return norm_matrix

    def update_auditor_vec(self, auditor_matrix_dict, task_matrix_dict, auditor_index, chosen_task_index):
        """更新审核员矩阵
        """
        def update_vec(vec_name):
            """更新均值矩阵
            [in]  vec_name: enum("text", "image")，表示更新文本或者图片维度的均值向量矩阵
            """
            ori_vec = auditor_matrix_dict["{}_feature_matrix".format(vec_name)][auditor_index]
            ori_count = auditor_matrix_dict["{}_count_matrix".format(vec_name)][auditor_index]
            inc_vec = task_matrix_dict["{}_feature_matrix".format(vec_name)][chosen_task_index]
            inc_count = task_matrix_dict["{}_count_matrix".format(vec_name)][chosen_task_index]
            new_vec, new_count = cal_vec_avg(ori_vec, ori_count, inc_vec, inc_count)
            #logging.info("ori_count: {}, inc_count: {}, new_count: {}".format(ori_count, inc_count, new_count))
            auditor_matrix_dict["{}_feature_matrix".format(vec_name)][auditor_index] = new_vec
            auditor_matrix_dict["{}_count_matrix".format(vec_name)][auditor_index] = new_count

        # 更新auditor审核矩阵信息
        #auditor_matrix_dict["text_feature_matrix"][auditor_index] += \
        #        task_matrix_dict["text_feature_matrix"][chosen_task_index]
        #auditor_matrix_dict["image_feature_matrix"][auditor_index] += \
        #        task_matrix_dict["image_feature_matrix"][chosen_task_index]
        update_vec("text")
        update_vec("image")
        auditor_matrix_dict["trade_feature_matrix"][auditor_index] += \
                task_matrix_dict["trade_feature_matrix"][chosen_task_index]

    def serially_distribute_task(self, task_matrix_dict, auditor_matrix_dict,
            auditor_index, request_num, available_index):
        """ 为指定审核员在指定范围内分配指定数目任务
        影响因素：
        1. task中包含的text image内容
        2. task中包含的trade
        3. task的待审时长
        找出的task的index是available_index的index
        通过available_index转回整个matrix的index
        不直接计算审核员和任务的矩阵 复杂度太高
        先得到该审核员在审核员维度上各类型的优先级
        然后根据该优先级计算该审核员在各任务的优先级
        [in]  task_matrix_dict: dict, 任务多维度的矩阵
              auditor_matrix_dict: dict, 审核员多维度的矩阵
              auditor_index: int, 当前要分配的审核员在矩阵中的行号
              request_num: int, 要分配的任务数目
              available_index: list, 可以分配给该审核员的任务在矩阵中的行号
        [out] chosen_task_list: list, 分配的任务在矩阵中的行号
        """

        def rank_task_score(top_k=1):
            """任务得分排序
            [in]  top_k: int, 排序结果取top_k个
            [out] top_k_task_list: list, 排序top_k个任务的相关信息
            """
            # 文本维度得分
            text_sim_score = self.cal_vec_matrix_score(
                    task_matrix_dict["text_feature_matrix"],
                    auditor_matrix_dict["text_feature_matrix"],
                    auditor_index=auditor_index,
                    available_index=available_index,
                    )
            # 图片维度得分
            image_sim_score = self.cal_vec_matrix_score(
                    task_matrix_dict["image_feature_matrix"],
                    auditor_matrix_dict["image_feature_matrix"],
                    auditor_index=auditor_index,
                    available_index=available_index,
                    )
            # 行业维度得分
            trade_score = self.cal_matrix_score(
                    task_matrix_dict["trade_feature_matrix"],
                    auditor_matrix_dict["trade_feature_matrix"],
                    auditor_index=auditor_index,
                    available_index=available_index,
                    )
            # 任务待审时间得分
            time_score = self.cal_delay_score(
                    task_matrix_dict["wait_time_matrix"],
                    available_index=available_index,
                    )
            # 审核效率得分
            efficiency_score = self.cal_efficiency_score_by_auditor(
                    task_vec_matrix=task_matrix_dict["trade_feature_matrix"],
                    auditor_vec_matrix=auditor_matrix_dict['efficiency_feature_matrix'],
                    auditor_index=auditor_index,
                    available_index=available_index,
                    )

            # 计算文本、图片内容相似得分
            #logging.info("text_sim_score shape: {}".format(text_sim_score.shape))
            #logging.info("image_sim_score shape: {}".format(image_sim_score.shape))
            # 图片文本得分按比例和权重加和
            text_count_matrix = task_matrix_dict["text_count_matrix"][available_index]
            image_count_matrix = task_matrix_dict["image_count_matrix"][available_index]
            total_count_matrix = (text_count_matrix + image_count_matrix).astype(np.float64)
            # 如果total_count_matrix为0 加上极小值
            total_count_matrix[total_count_matrix == 0] += self.epsilon
            #logging.info("text_count_matrix shape: {}".format(text_count_matrix.shape))
            #logging.info("image_count_matrix shape: {}".format(image_count_matrix.shape))
            #logging.info("total_count_matrix shape: {}".format(total_count_matrix.shape))
            #logging.info("sim score * count matrix shape: {}".format((text_sim_score * text_count_matrix).shape))
            # 按图片和文本在task中的占比及给定的权重给分
            sim_score = self.text_weight * text_sim_score * text_count_matrix \
                    + self.image_weight * image_sim_score * image_count_matrix
            sim_score /= (self.text_weight + self.image_weight) * total_count_matrix
            #logging.info("sim_score shape: {}".format(sim_score.shape))

            # 准备好三个维度的得分矩阵 相似得分和行业得分矩阵进行归一化
            sim_score = sim_score.flatten()
            trade_score = trade_score.flatten()
            time_score = time_score.flatten()
            efficiency_score = efficiency_score.flatten()

            norm_sim_score = self.norm(sim_score)
            norm_trade_score = self.norm(trade_score)
            norm_efficiency_score = self.norm(efficiency_score)

            # 按占比给总得分
            # 相似和行业得分按权重加和 两部分得分最大值为1
            # 这样使得待审时间相差delay_max时，早来的任务绝对优先
            total_score = self.trade_weight * norm_trade_score \
                    + self.sim_weight * norm_sim_score + self.efficiency_weight * norm_efficiency_score
            total_score /= float(self.sim_weight + self.trade_weight + self.efficiency_weight)
            if self.delay_penalty == 1:
                total_score += time_score
            #logging.info("total_score shape: {}".format(total_score.shape))
            #logging.info("trade_score shape: {}".format(trade_score.shape))
            #logging.info("time_score  shape: {}".format(time_score.shape))
            # 只取圈定范围内的任务
            task_index_list =  range(len(total_score)) if available_index is None else available_index
            # TODO 这里要对全部进行排序 其实可以只找出top_k的就可以了
            # 将各任务的各种分数聚合在一起 并根据总分进行排序
            score_pack_sorted_list = sorted(zip(task_index_list, total_score,
                norm_trade_score, trade_score,
                norm_efficiency_score, efficiency_score,
                norm_sim_score, sim_score,
                time_score), key=lambda x:x[1], reverse=True)
            # 得分由高到底排序
            top_k_task_list = list()
            for cur_task_index, cur_total_score, \
                    cur_norm_trade_score, cur_trade_score, \
                    cur_norm_efficiency_score, cur_efficiency_score, \
                    cur_norm_sim_score, cur_sim_score, \
                    cur_time_score in score_pack_sorted_list[:top_k]:
                cur_score_info = "task score:{:.4f}("\
                    "trade:{:.4f}(ori:{:.4f}) + efficiency:{:.4f}(ori:{:.4f}) + sim:{:.4f}(ori:{:.4f}) + time:{:.4f})".format(
                            cur_total_score,
                            cur_norm_trade_score,
                            cur_trade_score,
                            cur_norm_efficiency_score,
                            cur_efficiency_score,
                            cur_norm_sim_score,
                            cur_sim_score,
                            cur_time_score,
                            )
                top_k_task_list.append((cur_task_index, cur_total_score, cur_score_info))

            return top_k_task_list

        chosen_task_list = list()
        # 重复为任务排序 取排名第一的任务分配
        # 直到已分配任务达到指定数目或没有可分配任务
        while len(chosen_task_list) < request_num and len(available_index) > 0:
            # 在当前可选任务范围内选出得分最高的任务分配
            cur_index_score_rank = rank_task_score(top_k=1)
            cur_chosen_task = cur_index_score_rank[0]
            chosen_task_list.append(cur_chosen_task)
            # 将当前分配的任务移除可选的任务范围
            cur_chosen_task_index = cur_chosen_task[0]
            available_index.remove(cur_chosen_task_index)
            # 更新auditor审核矩阵信息
            self.update_auditor_vec(
                auditor_matrix_dict,
                task_matrix_dict,
                auditor_index,
                cur_chosen_task_index,
                )
        return chosen_task_list

    def cal_vec_sim_score(self, auditor_vec_matrix, task_vec_matrix, sim_matrix=None):
        """任务、审核员各维度相似度得分
        """
        if sim_matrix is not None:
            auditor_vec_matrix = np.dot(auditor_vec_matrix, sim_matrix)
        #start_time = time.time()
        #logging.info("auditor matrix shape: {}".format(auditor_vec_matrix.shape))
        #logging.info("task matrix shape: {}".format(task_vec_matrix.shape))
        auditor_task_sim = cosine_similarity(auditor_vec_matrix, task_vec_matrix)
        #logging.info("auditor_task_sim time: {:.4f}s, shape: {}".format(
        #    time.time() - start_time,
        #    auditor_task_sim.shape,
        #    ))
        return auditor_task_sim

    def bipartite_match(self, task_matrix_dict, auditor_matrix_dict, request_info_list):
        """ 二分图排序
        """
        # 获得当前参与匹配的auidtor_index
        auditor_indexs = [x[0] for x in request_info_list]
        #logging.info("auditor_indexs: {}".format(auditor_indexs))

        cal_score_time = time.time()
        # 文本维度得分
        text_sim_score = self.cal_vec_sim_score(
            auditor_matrix_dict["text_feature_matrix"][auditor_indexs],
            task_matrix_dict["text_feature_matrix"],
            )
        # 图片维度得分
        image_sim_score = self.cal_vec_sim_score(
            auditor_matrix_dict["image_feature_matrix"][auditor_indexs],
            task_matrix_dict["image_feature_matrix"],
            )
        # 标签维度得分
        trade_score = self.cal_vec_sim_score(
                auditor_matrix_dict["trade_feature_matrix"][auditor_indexs],
                task_matrix_dict["trade_feature_matrix"],
                )
        # 任务待审时间得分
        time_score = self.cal_delay_score(
                task_matrix_dict["wait_time_matrix"].reshape((1, -1))
                )
        # 历史效率维度得分
        efficiency_score = self.cal_efficiency_score_matrix(
                auditor_vec_matrix=auditor_matrix_dict["efficiency_feature_matrix"][auditor_indexs],
                task_vec_matrix=task_matrix_dict["trade_feature_matrix"],
                )

        #logging.info("text_sim_score shape: {}".format(text_sim_score.shape))
        #logging.info("image_sim_score shape: {}".format(image_sim_score.shape))
        # 图片文本得分按比例和权重加和
        text_count_matrix = task_matrix_dict["text_count_matrix"].reshape((1, -1))
        image_count_matrix = task_matrix_dict["image_count_matrix"].reshape((1, -1))
        total_count_matrix = (text_count_matrix + image_count_matrix).astype(np.float64)
        # 如果total_count_matrix为0 加上极小值
        total_count_matrix[total_count_matrix == 0] += self.epsilon
        #logging.info("text_count_matrix shape: {}".format(text_count_matrix.shape))
        #logging.info("image_count_matrix shape: {}".format(image_count_matrix.shape))
        #logging.info("total_count_matrix shape: {}".format(total_count_matrix.shape))
        #logging.info("sim score * count matrix shape: {}".format((text_sim_score * text_count_matrix).shape))
        # 按图片和文本在task中的占比给分
        sim_score = self.text_weight * text_sim_score * text_count_matrix \
                + self.image_weight * image_sim_score * image_count_matrix
        sim_score /= (self.text_weight + self.image_weight) * total_count_matrix
        #logging.info("sim_score shape: {}".format(sim_score.shape))
        norm_sim_score = self.norm(sim_score, axis=0)
        norm_trade_score = self.norm(trade_score, axis=0)
        norm_efficiency_score = self.norm(efficiency_score, axis=0)

        # 按占比给总得分
        total_score = self.trade_weight * norm_trade_score \
                + self.sim_weight * norm_sim_score + self.efficiency_weight * norm_efficiency_score
        total_score /= float(self.trade_weight + self.sim_weight + self.efficiency_weight)
        assert (total_score <= 1.0001).all()
        #logging.info("total_score min: {}".format(total_score.min()))
        #logging.info("total_score max: {}".format(total_score.max()))

        # TODO experiment
        # 在加待审时长得分前将矩阵变为各审核员的对比矩阵 不然待审时间将没有效果
        # 因为各任务的待审时间对所有审核员都一样
        total_score_diff = diff_matrix(total_score)
        #logging.info("total_score_diff min: {}".format(total_score_diff.min()))
        #logging.info("total_score_diff max: {}".format(total_score_diff.max()))
        assert (total_score_diff <= 1.0001).all()

        if self.delay_penalty == 1:
            total_score_diff += time_score

        #logging.info("total_score shape: {}".format(total_score.shape))
        #logging.info("trade_score shape: {}".format(trade_score.shape))
        #logging.info("sim_score  shape: {}".format(sim_score.shape))
        #logging.info("time_score  shape: {}".format(time_score.shape))
        cal_score_time = time.time() - cal_score_time

        match_time = time.time()
        right_node_num = total_score.shape[1]
        request_num_list = list()
        for _, cur_request_num, _ in request_info_list:
            request_num_list.append(cur_request_num)
        #logging.info("request num: {}".format(request_num_list))

        h = KMBFS(len(auditor_indexs), right_node_num, request_num_list)
        # 构造edges
        edge_num = 0
        for cur_auditor_index, (_, _, cur_available_index) in enumerate(request_info_list):
            #logging.info("link edge max: {}".format(trade_score[cur_auditor_index][cur_available_index].max()))
            #logging.info("not zero edge num: {}".format(np.sum(trade_score[cur_auditor_index][cur_available_index] != 0)))
            for cur_right_node in cur_available_index:
                # label_score当前是行业标签的得分 如果该得分为0
                # 说明该审核员未审核过该行业 则应该单独为其分配任务 而不能直接二分图匹配
                if trade_score[cur_auditor_index][cur_right_node] == 0:
                    continue
                edge_num += 1
                h.add_edge(cur_auditor_index + 1, cur_right_node + 1, total_score_diff[cur_auditor_index][cur_right_node])

        #logging.info("edge_num = {}".format(edge_num))
        score = h.solve()
        match_time = time.time() - match_time

        update_vec_time = 0
        match_res_list = list()
        match_score = 0
        for cur_index, cur_task_index_list in enumerate(h.left_match):
            cur_auditor_index = auditor_indexs[cur_index]
            #logging.info("index: {}, auditor #{}, task: {}".format(cur_index, cur_auditor_index, cur_task_index_list))
            for cur_task_index in cur_task_index_list:
                if cur_task_index == -1:
                    continue
                # 记录当前分配得分信息
                cur_score_info = "total:{:.4f}(trade:{:.4f}(ori:{:.4f}) + efficiency:{:.4f}(ori:{:.4f}) + "\
                        "sim:{:.4f}(ori:{:.4f}) + time:{:.4f})".format(
                            total_score[cur_index][cur_task_index],
                            norm_trade_score[cur_index][cur_task_index],
                            trade_score[cur_index][cur_task_index],
                            norm_efficiency_score[cur_index][cur_task_index],
                            efficiency_score[cur_index][cur_task_index],
                            norm_sim_score[cur_index][cur_task_index],
                            sim_score[cur_index][cur_task_index],
                            time_score[0][cur_task_index],
                            )

                match_score += total_score[cur_index][cur_task_index]
                #top_k_task_list.append((cur_task_index, cur_total_score, cur_score_info))
                match_res_list.append((
                    cur_index,
                    cur_task_index,
                    cur_score_info,
                ))
                # 更新auditor vec信息
                update_start_time = time.time()
                self.update_auditor_vec(
                    auditor_matrix_dict,
                    task_matrix_dict,
                    cur_auditor_index,
                    cur_task_index,
                    )
                update_vec_time += time.time() - update_start_time

        logging.debug("cal score time = {:.4f}s, match time: {:.4f}s,  update vec time: {:.4f}s".format(
            cal_score_time,
            match_time,
            update_vec_time,
            ))
        return match_res_list, match_score

    def distribute(self, task_matrix, auditor_matrix):
        """分发待审数据
        # 各账户先分成任务
        [in]  task_matrix: matrix, 任务信息
              auditor_matrix: matrix, 审核员信息
        [out] dist_res_list: list, 分配结果信息
              auditor_matrix_dict: matrix, 分配后更新的审核员信息
        """
        task_matrix_dict = task_matrix.to_dict()
        auditor_matrix_dict = auditor_matrix.to_dict()
        total_match_score = 0
        dist_res_list = list()
        dist_index_set = set()

        # 初始化审核员的请求量和可分配任务
        request_info_list = list()
        for cur_auditor_index, (cur_request_num, cur_available_index) in enumerate(zip(
                auditor_matrix_dict["request_num_list"],
                auditor_matrix_dict["available_indexs_list"],
                )):
            request_info_list.append([cur_auditor_index, cur_request_num, cur_available_index])

        # 循环 直到
        # 1. 所有审核员的request_num都为0
        # 2. 所有审核员都没有可分配任务
        # 3. 任务已全部分配完(任务本来为空也算)
        while True:
            if task_matrix.size() == len(dist_index_set):
                logging.debug("no task left")
                break
            has_request = False
            has_available = False
            #logging.info("cur_request: {}".format(["#{}({},{})".format(x[0], x[1], len(x[2]) if x[2] is not None else "None") for x in request_info_list]))
            # 查看各审核员的情况
            # 对可分配的任务的label_score为0的审核员先分发一个任务
            next_request_info_list = list()

            distribute_begin_time = time.time()
            # 对没有审核过的人先分配一个任务进行初始化
            for cur_auditor_index, cur_request_num, cur_available_index in request_info_list:
                # 如果不请求任务 则跳过
                if cur_request_num <= 0:
                    continue
                has_request = True
                # 如果cur_availabel_index未指定 则所有的task都可分配
                if cur_available_index is None:
                    cur_available_index = list(range(task_matrix.size()))
                # 本批次已分配给别人的先去除
                cur_available_index = [x for x in cur_available_index if x not in dist_index_set]
                # 如果当前该审核员已无可分配的任务 则打印信息 跳过
                if len(cur_available_index) == 0:
                    logging.info("no available task for auditor {}, left task num: {}".format(
                        auditor_matrix.at(cur_auditor_index),
                        task_matrix.size() - len(dist_index_set),
                        ))
                    continue
                has_available = True
                # 如果当前审核员 其可分配的任务的label_score均为0 则需要为其单独分配一个任务
                # 因为label_score都为0 则各行业的任务对于该审核员来说 都没有区别 此时直接二分图匹配 容易分配各类任务给他
                #if len(cur_text_vec_list) == 0 and len(cur_image_vec_list) == 0:
                #logging.info("distribute label score max: {}".format(auditor_label_score[cur_auditor_index][cur_available_index].max()))
                cur_trade_score = cosine_similarity(
                    [auditor_matrix_dict["trade_feature_matrix"][cur_auditor_index]],
                    task_matrix_dict["trade_feature_matrix"],
                )[0]
                #logging.info("cur_trade_score max: {}".format(cur_trade_score[cur_available_index].max()))
                # 如果与各可分配任务的label score都为0 则单独发一个
                if cur_trade_score[cur_available_index].max() < 1e-10:
                    # 如果该审核员可分配的任务里label_score均为0 则分配一个任务给他进行初始化
                    # 为指定审核员分配指定数量任务
                    chosen_task_list = self.serially_distribute_task(
                            task_matrix_dict=task_matrix_dict,
                            auditor_matrix_dict=auditor_matrix_dict,
                            auditor_index=cur_auditor_index,
                            request_num=1,
                            available_index=cur_available_index)
                    assert len(chosen_task_list) == 1, \
                            "expect task list size 1, actual {}".format(len(chosen_task_list))
                    cur_request_num -= 1
                    # 得到分配给当前审核员的任务uid集合 更新已分配的index记录
                    for cur_task_index, _, cur_info in chosen_task_list:
                        # 添加到已分配的任务记录中 可分配的任务里去除该任务
                        dist_index_set.add(cur_task_index)
                        # 因为可能在serially_distribute_task里 就把cur_available_index改了
                        if cur_task_index in cur_available_index:
                            cur_available_index.remove(cur_task_index)
                        # 当前分配的task 也要更新之前添加到next_request_info_list的信息中
                        for _, _, prev_available_index in next_request_info_list:
                            if cur_task_index in prev_available_index:
                                prev_available_index.remove(cur_task_index)
                        # 记录分配结果
                        cur_auditor_id = auditor_matrix.at(cur_auditor_index)
                        cur_chosen_task_id = task_matrix.at(cur_task_index)
                        dist_res_list.append((cur_auditor_id, cur_chosen_task_id, cur_info))

                    # 打印当前分配信息
                    cur_auditor_end_time = time.time()
                    cur_dist_task_num = len(chosen_task_list)
                    total_dist_task_num = len(dist_index_set)
                    left_task_num = task_matrix.size() - total_dist_task_num
                    cost_time = cur_auditor_end_time - distribute_begin_time
                    dist_speed = total_dist_task_num / float(cost_time)
                    logging.info("assign {} tasks to auditor #{}({}), task left: {}, " \
                            "cost_time: {:.2f}s, speed: {:.2f} dist/s".format(
                        cur_dist_task_num,
                        cur_auditor_index,
                        auditor_matrix.at(cur_auditor_index),
                        left_task_num,
                        cost_time,
                        dist_speed,
                        ))
                next_request_info_list.append([cur_auditor_index, cur_request_num, cur_available_index])

            if not has_request or not has_available:
                break

            request_info_list = next_request_info_list

            bipartite_match_time = time.time()
            # 对所有人进行二分图匹配
            match_res_list, match_score = self.bipartite_match(task_matrix_dict, auditor_matrix_dict, request_info_list)
            total_match_score += match_score
            candidate_task_num = task_matrix.size() - len(dist_index_set)

            # 得到分配给当前审核员的任务uid集合 更新已分配的index记录
            for cur_index, cur_task_index, cur_info in match_res_list:
                # 这里就不用更改cur_availabel_index了
                # 因为下个循环 每个都会去掉dist_index_set中已分发的任务
                dist_index_set.add(cur_task_index)
                request_info_list[cur_index][2].remove(cur_task_index)
                # 请求的审核任务量-1
                request_info_list[cur_index][1] -= 1
                # 记录分配结果
                cur_auditor_index = request_info_list[cur_index][0]
                cur_auditor_id = auditor_matrix.at(cur_auditor_index)
                cur_chosen_task_id = task_matrix.at(cur_task_index)
                dist_res_list.append((cur_auditor_id, cur_chosen_task_id, cur_info))
            cost_time = time.time() - bipartite_match_time
            logging.info("bipartite match between {} auditor and {} task, task match: {}, " \
                    "cost_time: {:.4f}s".format(
                len(request_info_list),
                candidate_task_num,
                len(match_res_list),
                cost_time,
                ))
        #logging.info("dist_res_list: {}".format(dist_res_list))

        return dist_res_list, auditor_matrix_dict, total_match_score


if __name__ == "__main__":
    pass
