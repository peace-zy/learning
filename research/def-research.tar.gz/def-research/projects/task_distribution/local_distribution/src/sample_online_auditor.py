#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   sample_task.py
Author:   liuxing07@baidu.com
Date  :   21/10/11 19:18:14
Desc  :
"""

import os
import sys
import codecs
import logging
import time
import random

from collections import defaultdict
from tqdm import tqdm


def sample_7_auditor(auditor_online_path, auditor_vector_path, output_path,
                     sample_auditor_num=7):
    proxy_auditors = defaultdict(list)
    with codecs.open(auditor_online_path, 'r', "utf-8") as fin:
        for idx, line in enumerate(fin):
            if idx == 0:
                continue
            line = line.strip()
            groupid, auditorid, _ = line.split('\t')
            if groupid == "107":
                proxy_auditors["zhixiao"].append(auditorid)
            elif groupid == "108":
                proxy_auditors["qudao"].append(auditorid)
            else:
                raise ValueError(f"invalid groupid of auditor! {line}")

    auditor_vector_map = defaultdict(str)
    schema = None
    with codecs.open(auditor_vector_path, 'r', "utf-8") as fin:
        for idx, line in enumerate(fin):
            if idx == 0:
                schema = line
                continue

            auditorid = line.split('\t')[0]
            auditor_vector_map[auditorid] = line

    if not os.path.exists(os.path.abspath(output_path)):
        os.makedirs(os.path.abspath(output_path), exist_ok=True)

    for proxy, auditor_list in proxy_auditors.items():
        if len(auditor_list) < sample_auditor_num * 2:
            auditor14 = auditor_list.copy()
        else:
            auditor14 = random.sample(auditor_list, sample_auditor_num * 2)
        output_file_name = os.path.join(output_path, f'{proxy}_A_7auditors_vector')
        with open(output_file_name, 'w') as fout:
            fout.writelines([schema]+[auditor_vector_map[aid] for aid in auditor14[:int(len(auditor14)/2)]])


        output_file_name = os.path.join(output_path, f'{proxy}_B_7auditors_vector')
        with open(output_file_name, 'w') as fout:
            fout.writelines([schema]+[auditor_vector_map[aid] for aid in auditor14[int(len(auditor14)/2):]])

if __name__ == '__main__':
    auditor_online_path = sys.argv[1]
    auditor_vector_path = sys.argv[2]
    output_path = sys.argv[3]
    sample_auditor_num = int(sys.argv[4])
    sample_7_auditor(
        auditor_online_path,
        auditor_vector_path,
        output_path,
        sample_auditor_num,
    )
