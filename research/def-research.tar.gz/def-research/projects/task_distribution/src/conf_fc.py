#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   21/08/18 19:25:25
Desc  :   配置信息
"""
import sys

task_data_prefix = "dwd_mt_taskinfo_day."
mt_data_prefix = "dwd_mt_mtinfo_day."
op_data_prefix = "dwd_mt_opinfo_day."
throughput_data = "throughput_data."
user_info = "effuser.txt"
mt_dequeinfo_data = "dwd_mt_dequeopinfo_day."
mt_deque_negitive_info_data = "dwd_mt_dequeopinfo_negitive_day."

# 产品线范围
# None则是全部
#pid_scope = None

## feed全产品线pid
#pid_scope = set([
#    "27", "28", "40", "54", "55", "57", "60", "61", "58", "62",
#    "63", "64", "59", "87", "88", "89", "96", "119", "120", "136",
#    "159", "160", "163", "175", "238", "257", "286", "318", "319", "105",
#    "106", "144", "220", "288", "356", "362", "363", "112", "308", "309",
#    "340", "359",
#])

## 落地页产品线pid
#pid_scope = set([
#    "93", "94", "95", "104", "121", "122", "123", "124", "125", "149",
#    "150", "154", "155", "166", "168", "169", "170", "171", "172", "173",
#    "179", "180", "195", "196", "197", "208", "209", "213", "214", "215",
#    "218", "233", "237", "254", "255", "258", "259", "262", "269", "270",
#    "274", "279", "280", "281", "282", "283", "287", "291", "292", "293",
#    "298", "299", "300", "306", "321", "323", "324", "325", "330", "336",
#    "341", "349", "353", "355", "368", "371"
#
#])

# 凤巢产品线pid
pid_scope = set([
    "29", "30", "45", "47", "53", "73", "191", "217", "261"
])

# 销售体系范围 None则是全部
sale_system_scope = None
sale_system_scope = set([
    "渠道",
    "直销",
    "KA",
    "其他",
])

# 统计堆积量时(throughput_hourly_stat) 需要考虑的两个限制范围
# 账户限制为：生效（2）、余额为0（3）
throughput_user_status_scope = set(["2", "3"])
# 任务类型限制为：普通（1）、优审（2）
# 其余的状态过滤掉： 搁置（3）、打桩（5）、先发后审（6）、未知（-）
throughput_task_type_scope = set(["1", "2"])

#队列间隔时间
gap_time = 360

# 预处理
preprocess = [
    "auditor_hourly_stat",            # 小时级审核员数据统计
    "mt_audit_time_hourly_stat",      # 小时级物料审核时间统计
    "throughput_hourly_stat",         # 小时级吞吐量统计
    "auditor_trade_daily_stat",       # 天级审核员各行业指标统计
    "auditor_efficiency",             # 审核员效率统计
    #"auditor_window_dequeinfo",       # 审核员间隔时间各指标统计
    #"pid_trade_daily_stat",           # 天级各产品线各行业指标统
    ]

# 监控
monitor = [
    "total_hourly_monitor",     # 小时级数据分析
    "efficiency_daily_monitor", # 天级效率监控
    "auditor_daily_monitor",    # 天级任务分配效果监控
    "mt_daily_monitor",         # 天级物料情况监控
    "trade_daily_monitor",      # 各一级行业情况监控
    "efficiency_statistics",    # 阶段时间内效率统计
    #"pid_daily_monitor",        # 天级各产品线指标统计
]

# 特征提取
feature = {
            "x": {
                "task_feature": [
                    "total_mt_count",
                    "direct_mt_count",
                    "task_first_level_trade",
                    "task_second_level_trade",
                    "task_sale_system",
                    ],

                "auditor_feature": [
                    "auditor_efficiency_first_level_trade",
                    "auditor_mt_per_op_first_level_trade",
                    "auditor_efficiency_second_level_trade",
                    "auditor_mt_per_op_second_level_trade",
                    "auditor_efficiency_sale_system",
                    "auditor_mt_per_op_sale_system",
#                    "auditor_efficiency_pid",
#                    "auditor_mt_per_op_pid",
                    ],

                "context_feature": [
#                    "time_weekday",
                    ]
            },
            "y":
                "audit_op_time"
        }



# 模型训练


# 模型预测


# 模型验证


# 任务分配

