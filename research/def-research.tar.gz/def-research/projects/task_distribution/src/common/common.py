#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   21/08/18 19:33:31
Desc  :   common
"""
import os
import sys
import codecs
import datetime


class Common(object):
    """通用类
    """
    @staticmethod
    def read_file(file_name, fileencoding="utf-8"):
        """读取文件，返回
        """
        with codecs.open(file_name, "r", fileencoding) as rf:
            for index, line in enumerate(rf):
                parts = line.strip("\n").split("\t")
                yield index, parts

    @staticmethod
    def cal_date(begin_date, diff):
        """
        Args:
            begin_date:     开始时间，字符串
            diff:           时间差
        Return:
            date:           计算结果
        """
        beigin_datetime = datetime.datetime.strptime(begin_date, "%Y%m%d")
        delta_datetime = datetime.timedelta(days=diff)
        return (beigin_datetime + delta_datetime).strftime("%Y%m%d")


if __name__ == "__main__":
    pass


