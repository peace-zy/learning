#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
Author:   zhanghao55@baidu.com
Date  :   21/08/24 17:28:03
Desc  :   预处理
"""
import os
import sys
import codecs
import collections
import json
import logging
import numpy as np
import pandas as pd

from datetime import datetime, timedelta
from tqdm import tqdm

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import conf
from utils.stat_info import StatInfo
from utils.trade_id_map import load_trade_id_map, load_trade_id_index
from review_object import review_object
from common import common

sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log
init_log()


def accumulate(tar_dict, src_dict):
    """src_dict的各统计值累加到tar_dict中
    """
    for cur_key, cur_value in src_dict.items():
        tar_dict[cur_key] += cur_value


def divide(first_value, second_value, default_second=1):
    """解决除数为0的问题
    """
    if second_value == 0:
        second_value = default_second
    return first_value / float(second_value)


class Preprocessor(object):
    """预处理类
    """
    def __init__(self, date,
            mtinfo_data_path,
            taskinfo_data_path,
            opinfo_data_path,
            throughput_data_path,
            meg_id_map_path,
            ):
        """init
        """
        self.date = date
        self.mtinfo_data_path = mtinfo_data_path
        self.taskinfo_data_path = taskinfo_data_path
        self.opinfo_data_path = opinfo_data_path
        self.throughput_data_path = throughput_data_path
        self.trade_id_name_dict, _ = load_trade_id_map(meg_id_map_path)
        self.trade_id_index_dict = load_trade_id_index(meg_id_map_path)

        self.mtwise_data = None
        self.taskwise_data = None
        self.optwise_data = None
        self.throughput_data = None
        self.dequeinfo_data = None
        self.dequenegitive_info_data = None

    def load_data(self, data_list, file_path, record_obj):
        """加载日志通用函数
        """
        if data_list is None:
            data_list = list()
            # codecs.open 遇到一行里有特殊字符 例如"\x1c"会忽略掉该字符后的内容 导致加载数据出错
            with open(file_path, "r", encoding="utf-8") as rf:
                for index, line in tqdm(enumerate(rf)):
                    parts = line.strip("\n").split("\t")
                    try:
                        cur_obj = record_obj(parts)
                    except Exception as e:
                        logging.info("wrong line #{} at file: {}".format(index+1, file_path))
                        raise e
                    if conf.sale_system_scope is not None and cur_obj.sale_system not in conf.sale_system_scope:
                        continue
                    if conf.pid_scope is not None and cur_obj.pid not in conf.pid_scope:
                        continue
                    data_list.append(cur_obj)
        return data_list

    def load_deque_data(self, data_list, file_path, record_obj):
        """加载队列日志函数，无需过滤产品线和销售体系
        """
        if data_list is None:
            data_list = list()
            # codecs.open 遇到一行里有特殊字符 例如"\x1c"会忽略掉该字符后的内容 导致加载数据出错
            with open(file_path, "r", encoding="utf-8") as rf:
                for index, line in tqdm(enumerate(rf)):
                    parts = line.strip("\n").split("\t")
                    try:
                        cur_obj = record_obj(parts)
                    except Exception as e:
                        logging.info("wrong line #{} at file: {}".format(index+1, file_path))
                        raise e
                    data_list.append(cur_obj)
        return data_list

    def load_task_human_audit(self):
        """任务维度日志加载
        """
        self.taskwise_data = self.load_data(
            self.taskwise_data,
            self.taskinfo_data_path,
            review_object.TaskHumanAuditResult,
            )

    def load_mt_human_audit(self):
        """物料维度日志加载
        """
        self.mtwise_data = self.load_data(
            self.mtwise_data,
            self.mtinfo_data_path,
            review_object.AdHumanAuditResult,
            )

    def load_opt_human_audit(self):
        """操作维度日志加载
        """
        self.optwise_data = self.load_data(
            self.optwise_data,
            self.opinfo_data_path,
            review_object.OperationHumanAuditResult,
            )

    def load_throughput_data(self):
        """加载堆积、进审信息
        """
        self.throughput_data = self.load_data(
            self.throughput_data,
            self.throughput_data_path,
            review_object.ThroughputRecord,
        )

    def load_dequeinfo_human_data(self, dequeinfo_data_path, dequenegitive_info_data_path):
        """
        """
        self.dequeinfo_data = self.load_deque_data(
                self.dequeinfo_data,
                dequeinfo_data_path,
                review_object.DequeInfoData)

        self.dequenegitive_info_data = self.load_deque_data(
                self.dequenegitive_info_data,
                dequenegitive_info_data_path,
                review_object.DequeInfoData)

    def auditor_hourly_stat(self):
        """小时级审核员数据统计
        """
        self.load_opt_human_audit()
        self.load_task_human_audit()

        # 按顺序
        hour_auditor_stat = StatInfo(stat_attr_list=[
            "auditor_id",
            "time",
            "total_mt_count",
            "direct_mt_count",
            "merge_relate_ratio",
            "merge_mt_count",
            "relate_mt_count",
            "audit_task_num",
            "audit_op_time",
            "audit_op_count",
            "auditor_num",
            "work_hour",
            "saturation",
            "direct_audit_efficiency",
            "direct_mt_num_per_op",
            "time_per_op",
            "dist_task_num",
            "task_seq_sim_score",
            "dist_info",
        ], key_num=2)

        # 统计审核员任务分配的情况
        hour_auditor_trade_count = collections.defaultdict(lambda: collections.defaultdict(lambda: collections.defaultdict(int)))
        hour_auditor_task_count = collections.defaultdict(lambda: collections.defaultdict(int))
        hour_trade_count = collections.defaultdict(lambda: collections.defaultdict(int))
        auditor_hour_trade_list = collections.defaultdict(lambda: collections.defaultdict(list))

        # 这里只能拿到当天已审核完的任务，再根据其被分配的时间进行统计
        # 还存在一些当天已分配 但没审核完的任务 这部分数据没办法在taskwise中拿到
        # 这里按任务分配的时间做了排序 评估该序列的行业一致性
        # TODO 会不会存在 任务完成时间的顺序和任务分配时间顺序不一致的情况？
        # TODO 是否需要按照各审核员实际审核的顺序来评估序列的一致性
        for cur_task in self.taskwise_data:
            cur_auditor_id = cur_task.auditor_front
            cur_trade = self.trade_id_name_dict.get(cur_task.first_level_trade, "未知")
            cur_task_distri_time = datetime.fromtimestamp(int(cur_task.task_distri_time))
            # 不是当天分配的任务则忽略
            if cur_task_distri_time.strftime("%Y%m%d") != self.date:
                continue
            cur_task_distri_hour = "{}:00:00".format(cur_task_distri_time.strftime("%Y-%m-%d %H"))

            # 记录各时段各审核员被分配到各行业的任务数
            hour_auditor_trade_count[cur_task_distri_hour][cur_auditor_id][cur_trade] += 1
            hour_auditor_trade_count["total"][cur_auditor_id][cur_trade] += 1

            # 记录各时段各审核员被分配的任务量
            hour_auditor_task_count[cur_task_distri_hour][cur_auditor_id] += 1
            hour_auditor_task_count["total"][cur_auditor_id] += 1

            # 记录该时段各行业任务被分配的数量
            hour_trade_count[cur_task_distri_hour][cur_trade] += 1
            hour_trade_count["total"][cur_trade] += 1

            # 记录各审核员各时段被分配的任务的顺序
            auditor_hour_trade_list[cur_auditor_id][cur_task_distri_hour].append((cur_task_distri_time, cur_trade))
            auditor_hour_trade_list[cur_auditor_id]["total"].append((cur_task_distri_time, cur_trade))

        # 统计各审核员各小时被分配的任务的情况
        auditor_hour_dist = collections.defaultdict(dict)
        for cur_hour, auditor_task_count in hour_auditor_task_count.items():
            for cur_auditor_id, cur_task_count in auditor_task_count.items():
                cur_trade_count = hour_auditor_trade_count[cur_hour][cur_auditor_id]
                cur_trade_sorted_list = [x[1] for x in sorted(auditor_hour_trade_list[cur_auditor_id][cur_hour])]
                cur_trade_count = sorted(cur_trade_count.items(), key=lambda x:x[1], reverse=True)
                cur_trade_dist_details = list()
                for cur_trade, cur_count in cur_trade_count:
                    cur_hour_trade_count = hour_trade_count[cur_hour][cur_trade]
                    cur_hour_auditor_task_count = hour_auditor_task_count[cur_hour][cur_auditor_id]
                    cur_trade_dist_details.append({
                        "trade": cur_trade,
                        "task_num": cur_count,
                        "ratio_of_trade": cur_count / float(cur_hour_trade_count),
                        "ratio_of_own_task": cur_count / float(cur_hour_auditor_task_count),
                        })
                auditor_hour_dist[cur_auditor_id][cur_hour] = {
                    "dist_task_num": str(cur_task_count),
                    "task_seq_sim_score": "{:.4f}".format(self.cal_seq_sim_score(cur_trade_sorted_list)),
                    "dist_info": json.dumps(cur_trade_dist_details),
                }

        # 统计审核员操作情况
        # auditor_hour_set[auditor_id][hour] = set(opt_minute)
        auditor_hour_set = collections.defaultdict(lambda: collections.defaultdict(set))
        # auditor_stat_dict[auditor_id][cur_hour][stat_attr] = stat_res
        auditor_stat_dict = collections.defaultdict(lambda: collections.defaultdict(lambda: collections.defaultdict(float)))
        # 各审核员各时段操作各任务的记录
        auditor_task_set_dict = collections.defaultdict(lambda: collections.defaultdict(set))

        # 任务、操作数据中 有些操作 由于前端大点bug会导致其pid为-1 导致在统计某些pid的数据时 会遗漏部分操作数据 遗漏部分占比暂时不多
        # 尝试用taskwise数据来替换op中的操作时间、物料量等数据 但好像taskwise的结束时间和各操作的时间不能完全一致
        # 例如在一天最后 该审核员在一个任务里进行了几个操作 但该任务没有审完 则op数据里会有这几个操作 但task数据里不会有 这种对不齐的情况会出现问题
        # 尝试用taskwise中task的pid信息补齐opwise的信息，但发现任务、操作数据中都有这种情况存在
        # 因遗漏的占比少 所以暂时忽略该数据遗漏问题
        for cur_opt in self.optwise_data:
            cur_auditor_id = cur_opt.auditor_front
            try:
                cur_time = datetime.fromtimestamp(int(cur_opt.op_end_time))
            except ValueError as e:
                logging.warning("wrong input: {}".format(e))
                continue
            if cur_time.strftime("%Y%m%d") != self.date:
                logging.warning("op time not in {}, actual: {}".format(self.date, cur_time.strftime("%Y%m%d")))
                continue
            cur_hour = "{}:00:00".format(cur_time.strftime("%Y-%m-%d %H"))
            # 该时间操作审核情况
            cur_stat = auditor_stat_dict[cur_auditor_id][cur_hour]
            cur_stat["total_mt_count"]  += float(cur_opt.op_total_ad_count)
            cur_stat["direct_mt_count"] += float(cur_opt.op_direct_ad_count)
            cur_stat["merge_mt_count"]  += float(cur_opt.op_merge_ad_count)
            cur_stat["relate_mt_count"] += float(cur_opt.op_related_ad_count)
            cur_stat["audit_op_time"]   += float(cur_opt.op_total_time)
            cur_stat["audit_op_count"]  += 1
            # 该时间有操作的分钟
            auditor_hour_set[cur_auditor_id][cur_hour].add(cur_time.minute)
            # 该操作所属任务ID
            auditor_task_set_dict[cur_auditor_id][cur_hour].add(cur_opt.taskid)

        # 获得各审核员各小时的饱和度
        for cur_auditor_id, hour_dict in auditor_hour_set.items():
            for cur_hour, op_minute_set in hour_dict.items():
                cur_stat = auditor_stat_dict[cur_auditor_id][cur_hour]
                cur_stat["saturation_sum"] = len(op_minute_set) / float(60)
                cur_stat["work_hour"] = 1
                cur_stat["auditor_num"] = 1

        # 获取各审核员各小时的审核任务数
        for cur_auditor_id, hour_dict in auditor_task_set_dict.items():
            for cur_hour, cur_task_id_set in hour_dict.items():
                cur_stat = auditor_stat_dict[cur_auditor_id][cur_hour]
                cur_stat["audit_task_num"] = len(cur_task_id_set)

        # 所有auditor各时段的统计结果汇总为total
        # 记录各时段各指标的值
        hour_total_dict = collections.defaultdict(lambda: collections.defaultdict(float))
        # 记录各时段活跃的auditor_id
        hour_auditor_dict = collections.defaultdict(set)
        # 记录总体的各指标的值
        total_dict = collections.defaultdict(int)
        for cur_auditor_id, cur_hour_count_dict in auditor_stat_dict.items():
            # 该auditor各时段的统计结果汇总为该auditor的total
            auditor_total_dict = collections.defaultdict(int)
            work_hour = 0
            for cur_hour, count_dict in cur_hour_count_dict.items():
                # 汇总该auditor各时段的统计结果
                accumulate(auditor_total_dict, count_dict)
                # 汇总该时段各auditor的统计结果
                accumulate(hour_total_dict[cur_hour], count_dict)
                # 将该auditor存入该时段的活跃记录
                hour_auditor_dict[cur_hour].add(cur_auditor_id)
                hour_auditor_dict["total"].add(cur_auditor_id)
            auditor_total_dict["auditor_num"] = 1
            # auditor总体统计加入auditor记录中
            cur_hour_count_dict["total"] = auditor_total_dict
            # 汇总所有auditor各时段的统计结果
            accumulate(total_dict, auditor_total_dict)

        # 添加各时段所有审核员的统计结果
        for cur_hour, count_dict in hour_total_dict.items():
            auditor_stat_dict["total"][cur_hour] = count_dict
        # 所有auditor的统计结果
        auditor_stat_dict["total"]["total"] = total_dict
        # 记录各时间段的活跃人数
        for cur_hour, auditor_set in hour_auditor_dict.items():
            auditor_stat_dict["total"][cur_hour]["auditor_num"] = len(auditor_set)

        # 各auditor统计结果转为StatInfo
        for cur_auditor_id, cur_hour_count_dict in auditor_stat_dict.items():
            #logging.info("dist hours: {}".format(auditor_hour_dist[cur_auditor_id].keys()))
            #logging.info("count hours: {}".format(cur_hour_count_dict.keys()))
            for cur_hour, cur_count_dict in cur_hour_count_dict.items():
                merge_relate_ratio      = "{:.4f}".format(divide(cur_count_dict["total_mt_count"], cur_count_dict["direct_mt_count"]))
                direct_audit_efficiency = "{:.4f}".format(divide(cur_count_dict["direct_mt_count"], cur_count_dict["audit_op_time"]))
                direct_mt_num_per_op    = "{:.4f}".format(divide(cur_count_dict["direct_mt_count"], cur_count_dict["audit_op_count"]))
                time_per_op             = "{:.4f}".format(divide(cur_count_dict["audit_op_time"], cur_count_dict["audit_op_count"]))
                saturation              = "{:.4f}".format(divide(cur_count_dict["saturation_sum"], cur_count_dict["work_hour"]))

                hour_auditor_stat[cur_auditor_id][cur_hour] = {
                    "total_mt_count": "{:.0f}".format(cur_count_dict["total_mt_count"]),
                    "direct_mt_count": "{:.0f}".format(cur_count_dict["direct_mt_count"]),
                    "merge_mt_count": "{:.0f}".format(cur_count_dict["merge_mt_count"]),
                    "relate_mt_count": "{:.0f}".format(cur_count_dict["relate_mt_count"]),
                    "audit_task_num": "{:.0f}".format(cur_count_dict["audit_task_num"]),
                    "audit_op_time": "{:.0f}".format(cur_count_dict["audit_op_time"]),
                    "audit_op_count": "{:.0f}".format(cur_count_dict["audit_op_count"]),
                    "auditor_num": "{:.0f}".format(cur_count_dict["auditor_num"]),
                    "work_hour": "{:.0f}".format(cur_count_dict["work_hour"]),
                    "merge_relate_ratio": merge_relate_ratio,
                    "saturation": saturation,
                    "direct_audit_efficiency": direct_audit_efficiency,
                    "direct_mt_num_per_op": direct_mt_num_per_op,
                    "time_per_op": time_per_op,
                }
                ## 具体审核员的统计结果中 没有活跃审核员数该指标
                #if cur_auditor_id == "total":
                #    hour_auditor_stat[cur_auditor_id][cur_hour]["auditor_num"] = "{:.0f}".format(cur_count_dict["auditor_num"])
                # 可能存在某些时刻审核员有操作 但没有分配记录 因为这些时刻可能没分配任务，或分配了任务但当天没审完，所以没在当天日志里
                if cur_hour in auditor_hour_dist[cur_auditor_id]:
                    hour_auditor_stat[cur_auditor_id][cur_hour].update(auditor_hour_dist[cur_auditor_id][cur_hour])
                else:
                    # 如果审核员当前时间没有被分配任务 则设分配任务数为0
                    hour_auditor_stat[cur_auditor_id][cur_hour]["dist_task_num"] = "0"


        hour_auditor_stat.save("output/auditor_hourly_stat.{}".format(self.date))

    def mt_audit_time_hourly_stat(self):
        """小时级物料的审核时间统计
        """
        self.load_mt_human_audit()

        hour_mt_audit_time_stat = StatInfo(stat_attr_list=[
            "hour",
            "trade",
            "stat_type",
            "tobeassign_time",
            "tobeaudit_time",
            "audit_time",
            "total_time",
        ], key_num=3)

        time_trade_dict = collections.defaultdict(lambda: collections.defaultdict(lambda: collections.defaultdict(list)))

        for cur_mt in self.mtwise_data:
            # 只计算直接审核的物料
            if cur_mt.audit_type2 != "1":
                continue
            cur_time = datetime.fromtimestamp(int(cur_mt.audit_end_time))
            cur_hour = "{}:00:00".format(cur_time.strftime("%Y-%m-%d %H"))

            cur_tobeassign_time = float(cur_mt.tobeassign_time)
            cur_tobeaudit_time = float(cur_mt.tobeaudit_time)
            cur_audit_time = float(cur_mt.audit_total_time)

            if cur_tobeassign_time < 0 \
                    or cur_tobeaudit_time < 0 \
                    or cur_audit_time < 0:
                continue
            
            cur_first_trade = cur_mt.first_level_trade

            time_trade_dict[cur_hour][cur_first_trade]["tobeassign_time"].append(cur_tobeassign_time)
            time_trade_dict[cur_hour][cur_first_trade]["tobeaudit_time"].append(cur_tobeaudit_time)
            time_trade_dict[cur_hour][cur_first_trade]["audit_time"].append(cur_audit_time)
            time_trade_dict[cur_hour]["total"]["tobeassign_time"].append(cur_tobeassign_time)
            time_trade_dict[cur_hour]["total"]["tobeaudit_time"].append(cur_tobeaudit_time)
            time_trade_dict[cur_hour]["total"]["audit_time"].append(cur_audit_time)

        total_dict = collections.defaultdict(lambda: collections.defaultdict(list))
        for cur_hour, cur_trade_dict in time_trade_dict.items():
            for cur_trade, cur_time_dict in cur_trade_dict.items():
                total_dict[cur_trade]["tobeassign_time"].extend(cur_time_dict["tobeassign_time"])
                total_dict[cur_trade]["tobeaudit_time"].extend(cur_time_dict["tobeaudit_time"])
                total_dict[cur_trade]["audit_time"].extend(cur_time_dict["audit_time"])
        time_trade_dict["total"] = total_dict

        def outlier_filter(time_list):
            time_array = np.array(time_list)
            Q1 = np.percentile(time_array, 25)
            Q3 = np.percentile(time_array, 75)
            IQR = Q3 - Q1
            #lower_bound = Q1 - 1.5 * IQR
            #if lower_bound < 0:
            lower_bound = 0
            upper_bound = Q3 + 1.5 * IQR
            #logging.info("lower_bound = {}, upper_bound = {}".format(lower_bound, upper_bound))
            return time_array[np.where(np.logical_and(lower_bound <= time_array, time_array <= upper_bound))]

        def array_stat(cal_func, cur_dict):
            """获得各阶段耗时的统计信息
            """
            tobeassign_res = cal_func(cur_dict["tobeassign_time"])
            tobeaudit_res = cal_func(cur_dict["tobeaudit_time"])
            audit_res = cal_func(cur_dict["audit_time"])
            return {
                "tobeassign_time": "{:.4f}".format(tobeassign_res),
                "tobeaudit_time": "{:.4f}".format(tobeaudit_res),
                "audit_time": "{:.4f}".format(audit_res),
                "total_time": "{:.4f}".format(tobeassign_res + tobeaudit_res + audit_res),
            }

        for cur_hour, cur_trade_dict in sorted(time_trade_dict.items()):
            logging.info("cur_hour: {}".format(cur_hour))
            for cur_trade, cur_dict in sorted(cur_trade_dict.items()):
                # 字典中存在的时刻和行业 其列表长度必不为零
                assert len(cur_dict["tobeassign_time"]) > 0

                #cur_dict["tobeassign_time"] = outlier_filter(cur_dict["tobeassign_time"])
                #cur_dict["tobeaudit_time"] = outlier_filter(cur_dict["tobeaudit_time"])
                #cur_dict["audit_time"] = outlier_filter(cur_dict["audit_time"])

                hour_mt_audit_time_stat[cur_hour][cur_trade]["total"] = array_stat(np.sum, cur_dict)
                hour_mt_audit_time_stat[cur_hour][cur_trade]["max"] = array_stat(np.max, cur_dict)
                hour_mt_audit_time_stat[cur_hour][cur_trade]["min"] = array_stat(np.min, cur_dict)
                hour_mt_audit_time_stat[cur_hour][cur_trade]["mean"] = array_stat(np.mean, cur_dict)
                hour_mt_audit_time_stat[cur_hour][cur_trade]["median"] = array_stat(np.median, cur_dict)
                hour_mt_audit_time_stat[cur_hour][cur_trade]["25_percentile"] = array_stat(lambda x: np.percentile(x, 25), cur_dict)
                hour_mt_audit_time_stat[cur_hour][cur_trade]["75_percentile"] = array_stat(lambda x: np.percentile(x, 75), cur_dict)
                hour_mt_audit_time_stat[cur_hour][cur_trade]["90_percentile"] = array_stat(lambda x: np.percentile(x, 90), cur_dict)
                hour_mt_audit_time_stat[cur_hour][cur_trade]["95_percentile"] = array_stat(lambda x: np.percentile(x, 95), cur_dict)
                hour_mt_audit_time_stat[cur_hour][cur_trade]["99_percentile"] = array_stat(lambda x: np.percentile(x, 99), cur_dict)

        hour_mt_audit_time_stat.save("output/mt_audit_time_hourly_stat.{}".format(self.date))

    def throughput_hourly_stat(self, user_status_scope=None, task_type_scope=None):
        """ 根据每天一开始的堆积量、本小时进审、本小时审核量，来推断下一小时堆积量，会有较大误差
            不如还是用数据里的堆积量

            另，每小时的进审量是前一小时到该小时这个时间段的进审量
            而统计结果中，每个时间点后的进审量表示的是该时间点起一个小时内的进审量
        """
        self.load_throughput_data()
        self.load_opt_human_audit()

        throughput_stat = StatInfo(stat_attr_list=[
            "time",
            "tobeaudit_ad_num_at_begin",
            "in_ad_num",
            "out_ad_num",
            "tobeaudit_ad_num_at_end",
            "direct_out_ad_num",
            "merge_out_ad_num",
            "relate_out_ad_num",
            "total_in_ad_num",
            "total_out_ad_num",
        ], key_num=1)

        # 统计各时间段的人审量 并分清直接审核量和联动聚合量
        total_num_dict = collections.defaultdict(int)
        direct_num_dict = collections.defaultdict(int)
        merge_num_dict = collections.defaultdict(int)
        relate_num_dict = collections.defaultdict(int)
        for cur_opt in self.optwise_data:
            try:
                cur_time = datetime.fromtimestamp(int(cur_opt.op_time))
            except ValueError as e:
                logging.warning("wrong input: {}".format(e))
                continue
            cur_time = "{}:00:00".format(cur_time.strftime("%Y-%m-%d %H"))
            direct_num_dict[cur_time] += int(cur_opt.op_direct_ad_count)
            merge_num_dict[cur_time] += int(cur_opt.op_merge_ad_count)
            relate_num_dict[cur_time] += int(cur_opt.op_related_ad_count)
            total_num_dict[cur_time] += int(cur_opt.op_total_ad_count)

        total_in_ad_num = None
        total_out_ad_num = 0

        prev_time = None
        # prev_time的一个小时前的堆积量
        prev_prev_tobeaudit_ad_num = 0
        # prev_time时的堆积量
        prev_tobeaudit_ad_num = 0
        # prev_time的前一个小时到prev_time这个时间段的进审量
        prev_in_ad_num = 0

        total_stat_dict = collections.defaultdict(int)

        def add_record():
            nonlocal total_in_ad_num, total_out_ad_num, prev_prev_tobeaudit_ad_num
            # 当total_in_ad_num为None时 表示这是第一个时间点 应该是当前0点的堆积量
            # 每天0点只记录堆积量 0点时候的进审量其实是 昨天23点到今天0点的进审量 不需要该数据
            # 每天的进审量是从1点的记录开始的
            if total_in_ad_num is None:
                total_in_ad_num = 0
                total_stat_dict["tobeaudit_ad_num_at_begin"] = prev_tobeaudit_ad_num
                return

            # 到这里表示记录时间为1点～24点

            # 当前是prev_time的数据，但该数据记录的都是prev_time前一个小时内的数据
            # 统计的结果中各时间段是要记录该时间段后一个小时内的数据
            # 所以记录的时间应该是prev_time的前一个小时, 命为key_time
            key_time = datetime.strptime(prev_time, "%Y-%m-%d %H:%M:%S")
            key_time -= timedelta(hours=1)
            key_time = key_time.strftime("%Y-%m-%d %H:%M:%S")

            # 获得key_time一开始的堆积量，即prev_time的一个小时前的堆积量
            # 也就是上一个prev_time，prev_prev_time时的堆积量
            tobeaudit_ad_num_at_begin = prev_prev_tobeaudit_ad_num

            # prev_time前一个小时内的进审量 也就是key_time后一个小时内的进审量
            # 该进审量加入总进审量
            total_in_ad_num += prev_in_ad_num

            # key_time后一小时内的人审量
            prev_out_ad_num = total_num_dict[key_time]
            # 该人审量加入总人审量
            total_out_ad_num += prev_out_ad_num

            # 人审量中 分清直接人审的量 和联动聚合的量
            direct_out_ad_num = direct_num_dict[key_time]
            merge_out_ad_num = merge_num_dict[key_time]
            relate_out_ad_num = relate_num_dict[key_time]

            # key_time结束时堆积量 即prev_time开始时的堆积量
            tobeaudit_ad_num_at_end = prev_tobeaudit_ad_num
            total_stat_dict["in_ad_num"]         += prev_in_ad_num
            total_stat_dict["out_ad_num"]        += prev_out_ad_num
            total_stat_dict["direct_out_ad_num"] += direct_out_ad_num
            total_stat_dict["merge_out_ad_num"]  += merge_out_ad_num
            total_stat_dict["relate_out_ad_num"] += relate_out_ad_num
            total_stat_dict["tobeaudit_ad_num_at_end"] = tobeaudit_ad_num_at_end

            throughput_stat[key_time] = {
                "tobeaudit_ad_num_at_begin": str(tobeaudit_ad_num_at_begin),
                "in_ad_num": str(prev_in_ad_num),
                "out_ad_num": str(prev_out_ad_num),
                "tobeaudit_ad_num_at_end": str(tobeaudit_ad_num_at_end),
                "direct_out_ad_num": str(direct_out_ad_num),
                "merge_out_ad_num": str(merge_out_ad_num),
                "relate_out_ad_num": str(relate_out_ad_num),
                "total_in_ad_num": str(total_in_ad_num),
                "total_out_ad_num": str(total_out_ad_num),
            }

        # 这里要保证throughput_data的记录时按时间顺序进入的
        for cur_record in self.throughput_data:
            # 不在统计范围的则跳过
            if conf.throughput_user_status_scope is not None \
                    and cur_record.user_status not in conf.throughput_user_status_scope:
                continue
            if conf.throughput_task_type_scope is not None \
                    and cur_record.task_type not in conf.throughput_task_type_scope:
                continue

            cur_time = cur_record.time
            if cur_time != prev_time:
                # 确认该遍历是按时间顺序的
                assert prev_time is None or cur_time > prev_time
                if prev_time is not None:
                    add_record()
                # 当prev_time变为下一个小时时
                # prev_time的堆积量 保存为 prev_prev_time的堆积量
                prev_prev_tobeaudit_ad_num = prev_tobeaudit_ad_num
                prev_time = cur_time
                prev_tobeaudit_ad_num = 0
                prev_in_ad_num = 0

            prev_tobeaudit_ad_num += int(cur_record.tobeaudit_ad_num)
            prev_in_ad_num += int(cur_record.in_ad_num)

        if prev_time is not None:
            add_record()

        # 最后添加total
        throughput_stat["total"] = {
                "tobeaudit_ad_num_at_begin": str(total_stat_dict["tobeaudit_ad_num_at_begin"]),
                "in_ad_num": str(total_stat_dict["in_ad_num"]),
                "out_ad_num": str(total_stat_dict["out_ad_num"]),
                "tobeaudit_ad_num_at_end": str(total_stat_dict["tobeaudit_ad_num_at_end"]),
                "direct_out_ad_num": str(total_stat_dict["direct_out_ad_num"]),
                "merge_out_ad_num": str(total_stat_dict["merge_out_ad_num"]),
                "relate_out_ad_num": str(total_stat_dict["relate_out_ad_num"]),
                "total_in_ad_num": str(total_in_ad_num),
                "total_out_ad_num": str(total_out_ad_num),
                
                }

        throughput_stat.save("output/throughput_hourly_stat.{}".format(self.date))

    def cal_seq_sim_score(self, seq_list):
        total_sum = 0
        prev_count = 0
        prev_item = None
        for cur_item in seq_list:
            if cur_item != prev_item:
                if prev_item is not None:
                    total_sum += prev_count * prev_count
                prev_item = cur_item
                prev_count = 0
            prev_count += 1

        if prev_item is not None:
            total_sum += prev_count * prev_count

        score = total_sum / float(len(seq_list))
        return score

    def auditor_trade_daily_stat(self):
        """天级审核员各行业指标统计
        """
        self.load_task_human_audit()

        # 按顺序
        auditor_trade_day_stat = StatInfo(stat_attr_list=[
            "auditor_id",
            "first_level_trade",
            "second_level_trade",
            "total_mt_count",
            "direct_mt_count",
            "merge_mt_count",
            "relate_mt_count",
            "audit_op_time",
            "audit_op_count",
            "direct_audit_efficiency",
            "direct_mt_num_per_op",
        ], key_num=3)

        # auditor_trade_dict[auditor_id][first_trade][second_trade][stat_attr] = stat_res
        auditor_trade_dict = collections.defaultdict(lambda: collections.defaultdict(
            lambda: collections.defaultdict(lambda: collections.defaultdict(float))))

        for cur_task in self.taskwise_data:
            cur_auditor_id = cur_task.auditor_front
            cur_time = datetime.fromtimestamp(int(cur_task.task_end_time))
            cur_time = cur_time.strftime("%Y%m%d")
            if cur_time != self.date:
                logging.warning("task time not in {}, actual: {}".format(self.date, cur_time))
                continue

            # 行业名
            # cur_first_trade = self.trade_id_name_dict.get(cur_task.first_level_trade, "未知")
            # cur_second_trade = self.trade_id_name_dict.get(cur_task.second_level_trade, "未知")
            # 行业ID
            cur_first_trade = cur_task.first_level_trade
            cur_second_trade = cur_task.second_level_trade

            cur_dict = auditor_trade_dict[cur_auditor_id][cur_first_trade][cur_second_trade]

            cur_dict["total_mt_count"]  += float(cur_task.task_mt_count)
            cur_dict["direct_mt_count"] += float(cur_task.task_direct_mt_count)
            cur_dict["merge_mt_count"]  += float(cur_task.task_merge_mt_count)
            cur_dict["relate_mt_count"] += float(cur_task.task_relate_mt_count)
            cur_dict["audit_op_time"]   += float(cur_task.audit_op_time)
            cur_dict["audit_op_count"]  += float(cur_task.audit_op_number)

        # 所有auditor各行业的统计结果汇总为total
        total_dict = collections.defaultdict(float)
        for cur_auditor_id, first_trade_dict in auditor_trade_dict.items():
            # 该aduitor各行业的统计结果汇总为该auditor的total
            auditor_first_total_dict = collections.defaultdict(float)
            for cur_first_trade, second_trade_dict in first_trade_dict.items():
                auditor_second_total_dict = collections.defaultdict(float)
                for cur_second_trade, count_dict in second_trade_dict.items():
                    # 当前count累积到auditor_second_total_dict
                    accumulate(auditor_second_total_dict, count_dict)
                # 二级行业汇总结果记录到对应一级行业的dict中
                second_trade_dict["total"] = auditor_second_total_dict
                # 二级行业汇总结果继续汇总到一级行业上
                accumulate(auditor_first_total_dict, auditor_second_total_dict)
            # 一级行业汇总结果记录到对应的审核员上
            first_trade_dict["total"]["total"] = auditor_first_total_dict
            # 一级行业汇总结果继续汇总到整体审核员上
            accumulate(total_dict, auditor_first_total_dict)
        auditor_trade_dict["total"]["total"]["total"] = total_dict

        # 各auditor统计结果转为StatInfo
        for cur_auditor_id, cur_first_trade_dict in auditor_trade_dict.items():
            for cur_first_trade, cur_second_trade_dict in cur_first_trade_dict.items():
                for cur_second_trade, cur_count_dict in cur_second_trade_dict.items():
                    direct_audit_efficiency = "{:.4f}".format(divide(cur_count_dict["direct_mt_count"], cur_count_dict["audit_op_time"]))
                    direct_mt_num_per_op = "{:.4f}".format(divide(cur_count_dict["direct_mt_count"], cur_count_dict["audit_op_count"]))
                    auditor_trade_day_stat[cur_auditor_id][cur_first_trade][cur_second_trade] = {
                        "total_mt_count": "{:.0f}".format(cur_count_dict["total_mt_count"]),
                        "direct_mt_count": "{:.0f}".format(cur_count_dict["direct_mt_count"]),
                        "merge_mt_count": "{:.0f}".format(cur_count_dict["merge_mt_count"]),
                        "relate_mt_count": "{:.0f}".format(cur_count_dict["relate_mt_count"]),
                        "audit_op_time": "{:.0f}".format(cur_count_dict["audit_op_time"]),
                        "audit_op_count": "{:.0f}".format(cur_count_dict["audit_op_count"]),
                        "direct_audit_efficiency": direct_audit_efficiency,
                        "direct_mt_num_per_op": direct_mt_num_per_op,
                    }

        auditor_trade_day_stat.save("output/auditor_trade_daily_stat.{}".format(self.date))

    def calc_efficiency(self, aspect: str):
        """
        不同方面效率计算基础逻辑
        aspect: [first_level_trade, second_level_trade, sale_system]
        """
        self.load_task_human_audit()

        stat_attr_key = ['auditor_id', aspect]
        stat_attr_value = [
            'audit_time',
            'audit_op_time',
            'audit_op_number',
            'task_mt_count',
            'task_direct_mt_count'
        ]
        stat_attr_value_type = ['mean', 'median', 'max', 'min', 'sum']
        stat_attr_to_calc = ['direct_audit_efficiency',
                             'direct_mt_num_per_op']

        # 保存各个行业的相关数据，为后续计算统计指标服务
        # audit_stat_dict[auditor_id][aspect][aspect_value] = list(value)
        # audit_stat_dict[0001][first_level_trade][task_mt_count] = [1, 3, 7]
        audit_stat_dict = collections.defaultdict(
            lambda: collections.defaultdict(lambda: collections.defaultdict(list)))
        for cur_task in tqdm(self.taskwise_data):
            if float(cur_task.total_audit_time) < 0:
                continue
            cur_auditor_id = cur_task.auditor_front

            for attr_value in stat_attr_value:
                audit_stat_dict[cur_auditor_id][getattr(cur_task, aspect)][attr_value].append(float(getattr(cur_task, attr_value)))
                audit_stat_dict["total"][getattr(cur_task, aspect)][attr_value].append(float(getattr(cur_task, attr_value)))

            cur_direct_audit_efficiency = float(cur_task.task_direct_mt_count) / max(1, float(cur_task.audit_op_time))
            cur_direct_mt_num_per_op = float(cur_task.task_direct_mt_count) / max(1, float(cur_task.audit_op_number))

            audit_stat_dict[cur_auditor_id][getattr(cur_task, aspect)]["direct_audit_efficiency"].append(cur_direct_audit_efficiency)
            audit_stat_dict[cur_auditor_id][getattr(cur_task, aspect)]["direct_mt_num_per_op"].append(cur_direct_mt_num_per_op)
            audit_stat_dict["total"][getattr(cur_task, aspect)]["direct_audit_efficiency"].append(cur_direct_audit_efficiency)
            audit_stat_dict["total"][getattr(cur_task, aspect)]["direct_mt_num_per_op"].append(cur_direct_mt_num_per_op)

        # 计算各个行业的统计指标，如平均数等
        audit_stat_dict_statis = collections.defaultdict(lambda: collections.defaultdict(dict))
        for auditor_id, auditor_stat in audit_stat_dict.items():
            auditor_total = collections.defaultdict(list)
            # auditor_stat[first_level_trade][task_mt_count] = [1, 3, 7]
            for aspect_name, aspect_value in auditor_stat.items():
                # aspect_value[task_mt_count] = [1, 3, 7]
                for statis_type in stat_attr_value_type:
                    for attr_value in stat_attr_value + stat_attr_to_calc:
                        value = float(np.__dict__[statis_type](aspect_value[attr_value]))
                        audit_stat_dict_statis[auditor_id][aspect_name][f'{statis_type}_{attr_value}'] = f'{value:.4f}'
                        auditor_total[f'{statis_type}_{attr_value}'].append(value)

            # 统计各aspect的total,保存在audit_stat_dict_statis[auditor_id]['total']
            for key, item in auditor_total.items():
                value = '{:.4f}'.format(float(np.__dict__[key.split('_')[0]](auditor_total[key])))
                audit_stat_dict_statis[auditor_id]['total'][key] = value

        # auditor统计结果转为StatInfo
        auditor_efficiency = StatInfo(stat_attr_list=stat_attr_key
                                                 + [f'{statis_type}_{attr_value}' for attr_value in stat_attr_value for statis_type in stat_attr_value_type]
                                                 + [f'{statis_type}_{attr_calc}' for attr_calc in stat_attr_to_calc for statis_type in stat_attr_value_type],
                                                 stat_dict = audit_stat_dict_statis,
                                                 key_num = 2)

        auditor_efficiency.save(f'output/auditor_efficiency_{aspect}.{self.date}')


    def auditor_efficiency(self):
        """MEG一二级行业、 销售体系审核效率
        """
        aspects = ["first_level_trade", "second_level_trade", "sale_system", 'pid']
        for aspect in aspects:
            self.calc_efficiency(aspect=aspect)

    def auditor_window_dequeinfo(self):
        """
        审核员在间隔时间内的数据统计
        """
        self.load_task_human_audit()
        self.load_mt_human_audit()
        dequeinfo_data_path = "data/%s%s" % (conf.mt_dequeinfo_data, self.date)
        deque_negitive_info_data_path = "data/%s%s" % (conf.mt_deque_negitive_info_data, self.date)
        self.load_dequeinfo_human_data(dequeinfo_data_path, deque_negitive_info_data_path)

        stat_attr_key = ['auditor_id']

        stat_attr_value = [
            'batch_op_ratio',
            'gap_task_mt_count',
            'gap_task_direct_mt_count',
            'gap_task_merge_mt_count',
            'gap_task_relate_mt_count'
        ]

        stat_attr_info_value = [
            'task_deque_info',
            'deque_mt_count',
            'deque_direct_mt_count',
            'deque_merge_mt_count',
            'deque_relate_mt_count',
            'deque_begin_time',
            'deque_end_time',
            'deque_trade_vector',
            'deque_cost_time',
            'deque_cost_class'
        ]

        task_attr_value = {
            'first_level_trade',
            'second_level_trade',
            'task_mt_count',
            'task_direct_mt_count',
            'task_merge_mt_count',
            'task_relate_mt_count'
        }
        #处理获得任务底下物料信息的数据
        auditor_taskinfo_dict = collections.defaultdict(lambda: collections.defaultdict(list))
        auditor_stat_dict = collections.defaultdict(lambda: collections.defaultdict(float))
        dequeinfo_stat_dict = collections.defaultdict(lambda: collections.defaultdict())
        task_mt_info_dict = collections.defaultdict(lambda: collections.defaultdict(int))

        for cur_taskinfo in tqdm(self.taskwise_data, desc="load task wise data"):
            task_id = cur_taskinfo.taskid
            for task_attr_value_type in task_attr_value:
                task_mt_info_dict[task_id][task_attr_value_type] = int(getattr(cur_taskinfo, task_attr_value_type))

        #对于审核员求平均的思路
        for cur_dequeinfo in tqdm(self.dequeinfo_data, desc="load dequeinfo data"):
            auditor_front = cur_dequeinfo.auditor_front
            task_deque_info = cur_dequeinfo.task_deque_info
            deque_begin_time = cur_dequeinfo.deque_begin_time
            deque_end_time = cur_dequeinfo.deque_end_time
            deque_cost_time = cur_dequeinfo.deque_cost_time
            #类别信息
            deque_cost_class = 1 if int(deque_cost_time) <= conf.gap_time else 0
            auditor_taskinfo_dict[auditor_front]["task_deque_info"].append(task_deque_info)
            auditor_taskinfo_dict[auditor_front]["deque_begin_time"].append(deque_begin_time)
            auditor_taskinfo_dict[auditor_front]["deque_end_time"].append(deque_end_time)
            auditor_taskinfo_dict[auditor_front]["deque_cost_time"].append(deque_cost_time)
            auditor_taskinfo_dict[auditor_front]["deque_cost_class"].append(deque_cost_class)

        for cur_negitive_dequeinfo in tqdm(self.dequenegitive_info_data, desc="load deque_negitive_info data"):
            trade_id_list = [0] * (len(self.trade_id_index_dict) + 1)
            task_deque_info = cur_negitive_dequeinfo.task_deque_info
            deque_begin_time = cur_negitive_dequeinfo.deque_begin_time
            deque_end_time = cur_negitive_dequeinfo.deque_end_time
            deque_cost_time = cur_negitive_dequeinfo.deque_cost_time
            deque_cost_class = 1 if int(deque_cost_time) <= conf.gap_time else 0
            cur_auditor_task_mt_count = 0.0
            cur_auditor_task_direct_mt_count = 0.0
            cur_auditor_task_merge_mt_count = 0.0
            cur_auditor_task_relate_mt_count = 0.0
            taskdeque_list = task_deque_info.split("|")
            #每一个队列的物料数量
            for each_task in taskdeque_list:
                mt_count = float(task_mt_info_dict[each_task]["task_mt_count"])
                direct_mt_count = float(task_mt_info_dict[each_task]["task_direct_mt_count"])
                merge_mt_count = float(task_mt_info_dict[each_task]["task_merge_mt_count"])
                relate_mt_count = float(task_mt_info_dict[each_task]["task_relate_mt_count"])
                cur_auditor_task_mt_count += mt_count
                cur_auditor_task_direct_mt_count += direct_mt_count
                cur_auditor_task_merge_mt_count += merge_mt_count
                cur_auditor_task_relate_mt_count += relate_mt_count
                #这里加判断是为了让那些未知的行业信息加在向量最后一列
                #防止行业id为0的时候真有实际意义，这样未知的也会加在id为0上
                if each_task in task_mt_info_dict:
                    first_level_trade = str(task_mt_info_dict[each_task]["first_level_trade"])
                    second_level_trade = str(task_mt_info_dict[each_task]["second_level_trade"])
                    if first_level_trade in self.trade_id_index_dict:
                        first_trade_index = self.trade_id_index_dict[first_level_trade]
                        trade_id_list[first_trade_index] += 1
                    else:
                        trade_id_list[-1] += 1
                    if second_level_trade in self.trade_id_index_dict:
                        second_trade_index = self.trade_id_index_dict[second_level_trade]
                        trade_id_list[second_trade_index] += 1
                    else:
                        trade_id_list[-1] += 1
                else:
                    trade_id_list[-1] += 1
            trade_id_str_list = [str(x) for x in trade_id_list]
            dequeinfo_stat_dict[task_deque_info]["deque_mt_count"] = str(cur_auditor_task_mt_count)
            dequeinfo_stat_dict[task_deque_info]["deque_direct_mt_count"] = str(cur_auditor_task_direct_mt_count)
            dequeinfo_stat_dict[task_deque_info]["deque_merge_mt_count"] = str(cur_auditor_task_merge_mt_count)
            dequeinfo_stat_dict[task_deque_info]["deque_relate_mt_count"] = str(cur_auditor_task_relate_mt_count)
            dequeinfo_stat_dict[task_deque_info]["deque_begin_time"] = deque_begin_time
            dequeinfo_stat_dict[task_deque_info]["deque_end_time"] = deque_end_time
            dequeinfo_stat_dict[task_deque_info]["deque_cost_time"] = deque_cost_time
            dequeinfo_stat_dict[task_deque_info]["deque_cost_class"] = str(deque_cost_class)
            dequeinfo_stat_dict[task_deque_info]["deque_trade_vector"] = "|".join(trade_id_str_list)

        for each_auditor, auditor_taskinfo_aspect_dict in auditor_taskinfo_dict.items():
            total_auditor_task_mt_count = 0.0
            total_auditor_task_direct_mt_count = 0.0
            total_auditor_task_merge_mt_count = 0.0
            total_auditor_task_relate_mt_count = 0.0
            total_auditor_deque_count = 0
            auditor_aspect_list_length = len(auditor_taskinfo_aspect_dict["task_deque_info"])
            for i in range(auditor_aspect_list_length):
                trade_id_list = [0] * (len(self.trade_id_index_dict) + 1)
                cur_auditor_task_mt_count = 0.0
                cur_auditor_task_direct_mt_count = 0.0
                cur_auditor_task_merge_mt_count = 0.0
                cur_auditor_task_relate_mt_count = 0.0
                each_taskinfo = auditor_taskinfo_aspect_dict["task_deque_info"][i]
                each_deque_begin_time = auditor_taskinfo_aspect_dict["deque_begin_time"][i]
                each_deque_end_time = auditor_taskinfo_aspect_dict["deque_end_time"][i]
                each_deque_cost_time = auditor_taskinfo_aspect_dict["deque_cost_time"][i]
                each_deque_cost_class = auditor_taskinfo_aspect_dict["deque_cost_class"][i]
                taskinfo_list = each_taskinfo.split("|")
                #每一个队列的物料数量
                for each_task in taskinfo_list:
                    mt_count = float(task_mt_info_dict[each_task]["task_mt_count"])
                    direct_mt_count = float(task_mt_info_dict[each_task]["task_direct_mt_count"])
                    merge_mt_count = float(task_mt_info_dict[each_task]["task_merge_mt_count"])
                    relate_mt_count = float(task_mt_info_dict[each_task]["task_relate_mt_count"])
                    cur_auditor_task_mt_count += mt_count
                    cur_auditor_task_direct_mt_count += direct_mt_count
                    cur_auditor_task_merge_mt_count += merge_mt_count
                    cur_auditor_task_relate_mt_count += relate_mt_count
                    if each_task in task_mt_info_dict:
                        first_level_trade = str(task_mt_info_dict[each_task]["first_level_trade"])
                        second_level_trade = str(task_mt_info_dict[each_task]["second_level_trade"])
                        if first_level_trade in self.trade_id_index_dict:
                            first_trade_index = self.trade_id_index_dict[first_level_trade]
                            trade_id_list[first_trade_index] += 1
                        else:
                            trade_id_list[-1] += 1
                        if second_level_trade in self.trade_id_index_dict:
                            second_trade_index = self.trade_id_index_dict[second_level_trade]
                            trade_id_list[second_trade_index] += 1
                        else:
                            trade_id_list[-1] += 1
                    else:
                        trade_id_list[-1] += 1
                trade_id_str_list = [str(x) for x in trade_id_list]
                dequeinfo_stat_dict[each_taskinfo]["deque_mt_count"] = str(cur_auditor_task_mt_count)
                dequeinfo_stat_dict[each_taskinfo]["deque_direct_mt_count"] = str(cur_auditor_task_direct_mt_count)
                dequeinfo_stat_dict[each_taskinfo]["deque_merge_mt_count"] = str(cur_auditor_task_merge_mt_count)
                dequeinfo_stat_dict[each_taskinfo]["deque_relate_mt_count"] = str(cur_auditor_task_relate_mt_count)
                dequeinfo_stat_dict[each_taskinfo]["deque_begin_time"] = each_deque_begin_time
                dequeinfo_stat_dict[each_taskinfo]["deque_end_time"] = each_deque_end_time
                dequeinfo_stat_dict[each_taskinfo]["deque_cost_time"] = each_deque_cost_time
                dequeinfo_stat_dict[each_taskinfo]["deque_cost_class"] = str(each_deque_cost_class)
                dequeinfo_stat_dict[each_taskinfo]["deque_trade_vector"] = "|".join(trade_id_str_list)

                total_auditor_task_mt_count += cur_auditor_task_mt_count
                total_auditor_task_direct_mt_count += cur_auditor_task_direct_mt_count
                total_auditor_task_merge_mt_count += cur_auditor_task_merge_mt_count
                total_auditor_task_relate_mt_count += cur_auditor_task_relate_mt_count
                total_auditor_deque_count += 1

            mean_auditor_task_mt_count = total_auditor_task_mt_count / total_auditor_deque_count
            mean_auditor_task_direct_mt_count = total_auditor_task_direct_mt_count / total_auditor_deque_count
            mean_auditor_task_merge_mt_count = total_auditor_task_merge_mt_count / total_auditor_deque_count
            mean_auditor_task_relate_mt_count = total_auditor_task_relate_mt_count / total_auditor_deque_count
            auditor_stat_dict[each_auditor]["gap_task_mt_count"] = "{:.4f}".format(mean_auditor_task_mt_count)
            auditor_stat_dict[each_auditor]["gap_task_direct_mt_count"] = "{:.4f}".format(mean_auditor_task_direct_mt_count)
            auditor_stat_dict[each_auditor]["gap_task_merge_mt_count"] = "{:.4f}".format(mean_auditor_task_merge_mt_count)
            auditor_stat_dict[each_auditor]["gap_task_relate_mt_count"] = "{:.4f}".format(mean_auditor_task_relate_mt_count)
            
            human_mtinfo_dict = collections.defaultdict(lambda: {"time_set": set(),
                                                                "audit_nums": 0})

        for cur_mtinfo in tqdm(self.mtwise_data, desc="load mt wise data."):
            auditor_front = cur_mtinfo.auditor_front
            audit_begin_time = cur_mtinfo.audit_begin_time
            audit_end_time = cur_mtinfo.audit_end_time
            time_unique = "\x01".join([audit_begin_time, audit_end_time])
            human_mtinfo_dict[auditor_front]["time_set"].add(time_unique)
            human_mtinfo_dict[auditor_front]["audit_nums"] += 1

        for each_auditor, auditor_feature_dict in auditor_stat_dict.items():
            batch_op_nums = len(human_mtinfo_dict[each_auditor]["time_set"])
            audit_nums = human_mtinfo_dict[each_auditor]["audit_nums"]
            batch_op_ratio = float(batch_op_nums) / max(1, audit_nums)
            auditor_feature_dict["batch_op_ratio"] = "{:.4f}".format(batch_op_ratio)
        
        #stat info
        auditor_dequeinfo = StatInfo(stat_attr_list = stat_attr_key + stat_attr_value,
                                                 stat_dict = auditor_stat_dict,
                                                 key_num = 1)
        dequeinfo_feature = StatInfo(stat_attr_list=stat_attr_info_value,
                                     stat_dict = dequeinfo_stat_dict,
                                     key_num = 1)

        auditor_dequeinfo.save(f'output/auditor_dequeinfo_daily.{self.date}')
        dequeinfo_feature.save(f'output/dequeinfo_daily.{self.date}')

    def pid_trade_daily_stat(self):
        """天级各产品线各行业指标统计
        """
        self.load_task_human_audit()

        # 按顺序
        pid_trade_day_stat = StatInfo(stat_attr_list=[
            "pid",
            "first_level_trade",
            "second_level_trade",
            "total_mt_count",
            "direct_mt_count",
            "merge_mt_count",
            "relate_mt_count",
            "audit_op_time",
            "audit_op_count",
            "direct_audit_efficiency",
            "direct_mt_num_per_op",
        ], key_num=3)

        # pid_trade_dict[pid][first_trade][second_trade][stat_attr] = stat_res
        pid_trade_dict = collections.defaultdict(lambda: collections.defaultdict(
            lambda: collections.defaultdict(lambda: collections.defaultdict(float))))

        for cur_task in self.taskwise_data:
            cur_pid = cur_task.pid
            cur_time = datetime.fromtimestamp(int(cur_task.task_end_time))
            cur_time = cur_time.strftime("%Y%m%d")
            if cur_time != self.date:
                logging.warning("task time not in {}, actual: {}".format(self.date, cur_time))
                continue

            # 行业ID
            cur_first_trade = cur_task.first_level_trade
            cur_second_trade = cur_task.second_level_trade

            cur_dict = pid_trade_dict[cur_pid][cur_first_trade][cur_second_trade]

            cur_dict["total_mt_count"]  += float(cur_task.task_mt_count)
            cur_dict["direct_mt_count"] += float(cur_task.task_direct_mt_count)
            cur_dict["merge_mt_count"]  += float(cur_task.task_merge_mt_count)
            cur_dict["relate_mt_count"] += float(cur_task.task_relate_mt_count)
            cur_dict["audit_op_time"]   += float(cur_task.audit_op_time)
            cur_dict["audit_op_count"]  += float(cur_task.audit_op_number)

        # 各产品线各行业的统计结果汇总为total
        total_dict = collections.defaultdict(float)
        for _, first_trade_dict in pid_trade_dict.items():
            # 该aduitor各行业的统计结果汇总为该auditor的total
            auditor_first_total_dict = collections.defaultdict(float)
            for cur_first_trade, second_trade_dict in first_trade_dict.items():
                auditor_second_total_dict = collections.defaultdict(float)
                for cur_second_trade, count_dict in second_trade_dict.items():
                    # 当前count累积到auditor_second_total_dict
                    accumulate(auditor_second_total_dict, count_dict)
                # 二级行业汇总结果记录到对应一级行业的dict中
                second_trade_dict["total"] = auditor_second_total_dict
                # 二级行业汇总结果继续汇总到一级行业上
                accumulate(auditor_first_total_dict, auditor_second_total_dict)
            # 一级行业汇总结果记录到对应的审核员上
            first_trade_dict["total"]["total"] = auditor_first_total_dict
            # 一级行业汇总结果继续汇总到整体审核员上
            accumulate(total_dict, auditor_first_total_dict)
        pid_trade_dict["total"]["total"]["total"] = total_dict

        # 各产品线统计结果转为StatInfo
        for cur_pid, cur_first_trade_dict in pid_trade_dict.items():
            for cur_first_trade, cur_second_trade_dict in cur_first_trade_dict.items():
                for cur_second_trade, cur_count_dict in cur_second_trade_dict.items():
                    direct_audit_efficiency = "{:.4f}".format(divide(cur_count_dict["direct_mt_count"], cur_count_dict["audit_op_time"]))
                    direct_mt_num_per_op = "{:.4f}".format(divide(cur_count_dict["direct_mt_count"], cur_count_dict["audit_op_count"]))
                    pid_trade_day_stat[cur_pid][cur_first_trade][cur_second_trade] = {
                        "total_mt_count": "{:.0f}".format(cur_count_dict["total_mt_count"]),
                        "direct_mt_count": "{:.0f}".format(cur_count_dict["direct_mt_count"]),
                        "merge_mt_count": "{:.0f}".format(cur_count_dict["merge_mt_count"]),
                        "relate_mt_count": "{:.0f}".format(cur_count_dict["relate_mt_count"]),
                        "audit_op_time": "{:.0f}".format(cur_count_dict["audit_op_time"]),
                        "audit_op_count": "{:.0f}".format(cur_count_dict["audit_op_count"]),
                        "direct_audit_efficiency": direct_audit_efficiency,
                        "direct_mt_num_per_op": direct_mt_num_per_op,
                    }

        pid_trade_day_stat.save("output/pid_trade_daily_stat.{}".format(self.date))

    def record(self, func_list):
        """总记录入口
        """
        for cur_func in func_list:
            getattr(self, cur_func)()


if __name__ == "__main__":
    date = sys.argv[1]
    mtinfo_data_path = sys.argv[2]
    taskinfo_data_path = sys.argv[3]
    opinfo_data_path = sys.argv[4]
    throughput_data_path = sys.argv[5]
    meg_id_map_path = sys.argv[6]

    m = Preprocessor(
        date,
        mtinfo_data_path,
        taskinfo_data_path,
        opinfo_data_path,
        throughput_data_path,
        meg_id_map_path,
        )

    m.record(conf.preprocess)
