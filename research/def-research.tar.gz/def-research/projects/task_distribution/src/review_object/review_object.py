#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   21/08/13 14:57:04
Desc  :   
"""
import sys


class BaseHumanAuditResult(object):
    """图灵基础人审日志
    """
    def __init__(self, parts, sep="\x01"):
        """init
        """
        # ------------------ 物料信息 ---------------------
        self.pipe       = parts[0]
        self.product_id = int(parts[1])
        self.user_id    = int(parts[2])
        self.unit_id    = int(parts[3])
        self.plan_id    = int(parts[4])
        self.ad_id      = int(parts[5])
        self.ad_type    = int(parts[6])
        self.ad_version = int(parts[7])
        self.word_list  = parts[8].split(sep)
        self.idea_list  = parts[9].split(sep)
        self.url_list  = parts[10].split(sep)
        self.pic_list  = parts[11].split(sep)
        self.video_list  = parts[12].split(sep)
        # ------------------ 审核信息 ---------------------
        self.audit_channel_type       = int(parts[13])
        self.human_in_start_timestamp = int(parts[14])
        self.human_out_end_timestamp  = int(parts[15])
        self.chk_user                 = int(parts[16])
        # ------------------ 审核结果 ---------------------
        self.review_result    = int(parts[17])
        self.text_pair_result = int(parts[18])
        self.text_result      = int(parts[19])
        self.rev_result_text  = int(parts[20])
        self.reason_array     = parts[21].split(sep)
        self.rsnid            = parts[22].split(sep)
        self.audit_details    = parts[23].split(sep)


class BaseResult(object):
    """数据基类
    """
    def __init__(self, parts):
        if parts is None:
            parts = [None] * len(self.attrs)
        assert len(parts) == len(self.attrs), \
            "parts length({}) != attrs length({})".format(len(parts), len(self.attrs))
        for cur_part, cur_attr in zip(parts, self.attrs):
            setattr(self, cur_attr, cur_part)
    
    def to_str(self):
        """转为str
        """
        return "\t".join([str(getattr(self, x)) for x in self.attrs])


class TaskHumanAuditResult(BaseResult):
    """任务维度基础数据
    """
    attrs = [
        "pid",                  # 0. 产品线ID
        "userid",               # 1. 账户ID
        "taskid",               # 2. 任务ID
        "sale_system",          # 3. 销售体系
        "first_level_trade",    # 4. MEG一级行业
        "second_level_trade",   # 5. MEG二级行业
        "auditor",              # 6. 审核员ID
        "distribution_type",    # 7. 分配方式（1-实时随机分发、2-定时触发分发）
        "total_audit_time",     # 8. 总耗时
        "tobeassign_time",      # 9. 待分配时长
        "tobeaudit_time",       # 10. 已分配待审耗时
        "audit_time",           # 11. 审核耗时
        "audit_op_time",        # 12. 审核操作耗时,和上一个的区别在于真正审核时间
        "audit_op_number",      # 13. 审核操作次数
        "task_add_time",        # 14. 任务添加时间 unixtime
        "task_distri_time",     # 15. 任务分配时间 unixtime
        "task_begin_time",      # 16. 任务开始审核时间 unixtime
        "task_end_time",        # 17. 任务结束审核时间 unixtime
        "auditor_front",        # 18. 任务的操作人（前端打点）
        "task_mt_count",        # 19. 任务物料总量
        "task_direct_mt_count", # 20. 任务直接看到的物料总量
        "task_merge_mt_count",  # 21. 任务聚合物料总量（人审看不到）
        "task_relate_mt_count", # 22. 任务联动物料总量（人审看不到）
    ]


class AdHumanAuditResult(BaseResult):
    """物料纬度基础数据
    物料各阶段时间：
    1. 入审时间    : 5 , ad_begin_time
    2. 分配时间    : 23, task_distri_time
    3. 审核开始时间 : 13, audit_begin_time
    4. 审核结束时间 : 14, audit_end_time
    """
    attrs = [
        "adid",               #0. 物料
        "keyid",              #1. keyID
        "taskid",             #2. 任务ID
        "userid",             #3. 账户ID
        "pid",                #4. 产品线ID
        "ad_begin_time",      #5. 系统中记录的入审时间
        "ad_end_time",        #6. 系统中记录的有审核结论时间
        "auditor_database",   #7. 审核操作人（数据库记录）
        "reject_desc",        #8. 拒绝理由描述
        "reject_reason_id",   #9. 拒绝理由id
        "audit_type1",        #10. 审核方式（逻辑稍微复杂，可不关注）
        "audit_time_front",   #11. 审核时间（前端打点）
        "auditor_front",      #12. 审核操作人（前端打点）
        "audit_begin_time",   #13. 审核开始时间
        "audit_end_time",     #14. 审核结束时间
        "audit_total_time",   #15. 审核操作耗时
        "audit_op_type",      #16. 审核操作方式（部分值待清洗）
        "audit_result",       #17. 审核结果
        "audit_type2",        #18. 审核方式（1-被直接审核、2-被聚合联动、3-被元素联动）重要！！
        "sale_system",        #19. 销售体系
        "first_level_trade",  #20. 一级MEG行业
        "second_level_trade", #21. 二级MEG行业
        "task_add_time",      #22. 所属任务添加时间
        "task_distri_time",   #23. 所属任务分配时间
        "auditor_distri",     #24. 分配审核员
        "distribution_type",  #25. 分配方式（1-实时随机分发、2-定时触发分发）
        "task_begin_time",    #26. 所属任务开始审核时间
        "task_end_time",      #27. 所属任务审核结束时间
        "total_time",         #28. 物料总耗时
        "tobeassign_time",    #29. 物料待分配耗时
        "tobeaudit_time",     #30. 物料已分配待审耗时
    ]


class OperationHumanAuditResult(BaseResult):
    """操作层级基础数据
    """
    attrs = [
        "op_time",             #0. 操作时间
        "taskid",              #1. 所属任务id
        "userid",              #2. userid
        "pid",                 #3. 审核流id
        "auditor_front",       #4. 审核操作人（前端打点）
        "op_type",             #5. 审核操作方式（部分值待清洗）
        "op_result",           #6. 审核结果
        "op_begin_time",       #7. 操作开始时间
        "op_end_time",         #8. 操作结束时间（即操作时间）
        "op_total_time",       #9. 操作耗时
        "op_total_ad_count",   #10. 操作涉及物料总量
        "op_direct_ad_count",  #11. 操作涉及直接操作物料量
        "op_merge_ad_count",   #12. 操作涉及聚合物料量
        "op_related_ad_count", #13. 操作涉及关联物料量
        "task_begin_time",     #14. 任务开始审核时间
        "sale_system",         #15. 销售体系
        "first_level_trade",   #16. 一级MEG行业
        "second_level_trade",  #17. 二级MEG行业
        "task_add_time",       #18. 所属任务添加时间
        "task_distri_time",    #19. 所属任务分配时间
        "auditor",             #20. 分配审核员
        "distribution_type",   #21. 分配方式（1-实时随机分发、2-定时触发分发）
    ]


class AuditorByDay(object):
    """审核员基本数据
    """
    def __init__(self, parts):
        """init
        """
        self.auditor = parts[0]
        # 直接审核量
        self.direct_audit_count = parts[1]
        # 总操作时长
        self.total_audit_time = parts[2]
        # 审核效率
        self.audit_efficiency = parts[3]
        # 审核操作次数
        self.audit_op_count = parts[4]
        # 操作次数/直接审核量
        self.disposable_op = parts[5]


class ThroughputRecord(BaseResult):
    """任务、物料堆积、进审情况
    """
    attrs = [
        "time",               # 0. 当前时间（整点）
        "pid",                # 1. 产品线ID
        "sale_system",        # 2. 销售体系
        "first_level_trade",  # 3. MEG一级行业
        "second_level_trade", # 4. MEG二级行业
        "user_status",        # 5. 账户状态
        "audit_type",         # 6. 审核类型(1：一线审核、2:总部审核，现在应该只有2了)
        "task_type",          # 7. 任务类型(1：普通、2：优审、3：搁置、5：打桩、6:先发后审)
        "tobeaudit_task_num", # 8. 本小时待审任务量
        "tobeaudit_ad_num",   # 9. 本小时待审物料量
        "in_task_num",        # 10. 本小时进审任务量
        "in_ad_num",          # 11. 本小时进审物料量
    ]


class DequeInfoData(BaseResult):
    """审核员、任务队列、队列开始时间、队列结束时间、总耗时、队列任务量
    """
    attrs = [
        "auditor_front",      # 0. 审核员
        "task_deque_info",    # 1. 审核任务队列
        "deque_begin_time",   # 2. 队列开始时间
        "deque_end_time",     # 3. 队列结束时间
        "deque_cost_time",    # 4. 队列耗时
        "task_nums",          # 5. 队列任务数量
    ]


class TaskMttoAuditRecord(BaseResult):
    """任务物料待审情况
    """
    attrs = [
        "time",               # 0. 当前时间（整点）
        "pid",                # 1. 产品线ID
        "user_status",        # 2. 账户状态
        "task_type",          # 3. 任务类型(1：普通、2：优审、3：搁置、5：打桩、6:先发后审)
        "task_group",         # 4. 审核组
        "audit_type",         # 5. 审核类型(1：一线审核、2:总部审核，现在应该只有2了)
        "sale_system",        # 6. 销售体系
        "first_level_trade",  # 7. MEG一级行业
        "second_level_trade", # 8. MEG二级行业
        "tobeaudit_task_num", # 9. 本小时待审任务量
        "tobeaudit_ad_num",   # 10. 本小时待审物料量
    ]


class AuditInRecord(BaseResult):
    """任务或物料进审情况
    """
    attrs = [
        "time",               # 0. 当前时间（整点）
        "pid",                # 1. 产品线ID
        "user_status",        # 2. 账户状态
        "task_type",          # 3. 任务类型(1：普通、2：优审、3：搁置、5：打桩、6:先发后审)
        "task_group",         # 4. 审核组
        "audit_type",         # 5. 审核类型(1：一线审核、2:总部审核，现在应该只有2了)
        "sale_system",        # 6. 销售体系
        "first_level_trade",  # 7. MEG一级行业
        "second_level_trade", # 8. MEG二级行业
        "audit_in_num",       # 9. 本小时进审量
    ]
