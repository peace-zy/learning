#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
Author:   zhanghao55@baidu.com
Date  :   21/08/23 17:28:03
Desc  :   数据监控
"""
import os
import sys
import codecs
import collections
import json
import logging
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
import math

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

from utils.stat_info import StatInfo
from utils.trade_id_map import load_trade_id_map
import review_object.review_object as review_object
import common.common as common
import conf

sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log
init_log()


def divide(first_value, second_value, default_second=1):
    """解决除数为0的问题
    """
    if second_value == 0:
        second_value = default_second
    return first_value / float(second_value)


def dist_info_format(dist_info, top_k=None, auditor_id=None, auditor_trade_eff_dict=None):
    """格式化展示dist_info
    """
    # dist_info[i] = {"trade":xxx, "task_num":xxx, "ratio_of_trade":xxx, "ratio_of_own_task":xxx}
    try:
        dist_info = json.loads(dist_info)
    except Exception as e:
        logging.info("dist_info: {}".format(dist_info))
        raise e

    if top_k is None:
        top_k = len(dist_info)

    format_list = list()

    for cur_dist in dist_info[:top_k]:
        cur_trade_eff_info = ""
        cur_trade = cur_dist["trade"]
        if auditor_trade_eff_dict is not None:
            assert auditor_id is not None, \
                    "auditor id is required when stat trade eff"

            cur_auditor_trade_eff = "None"
            if auditor_id in auditor_trade_eff_dict:
                if cur_trade in auditor_trade_eff_dict[auditor_id]:
                    cur_auditor_trade_eff = "{:.4f}".format(auditor_trade_eff_dict[auditor_id][cur_trade])

            cur_trade_avg_eff = "None"
            if cur_trade in auditor_trade_eff_dict["total"]:
                cur_trade_avg_eff = "{:.4f}".format(auditor_trade_eff_dict["total"][cur_trade])

            cur_trade_eff_info = ",eff:{}/{}".format(
                cur_auditor_trade_eff,
                cur_trade_avg_eff,
                )
        format_list.append("{}({:.0f},trade:{:.2f}%,own:{:.2f}%{})".format(
            cur_trade,
            cur_dist["task_num"],
            cur_dist["ratio_of_trade"] * 100,
            cur_dist["ratio_of_own_task"] * 100,
            cur_trade_eff_info,
            ))
    return "{}".format(format_list)


class Monitor(object):
    """监控类
    """
    def __init__(self, meg_id_map_path, auditor_group_path, start_date, end_date, excel_path=None):
        """init
        """
        self.trade_id_name_dict, _ = load_trade_id_map(meg_id_map_path)
        self.trade_id_name_dict["total"] = "汇总"
        self.auditor_group_dict = self.load_auditor_group(auditor_group_path)
        self.start_date = start_date
        self.end_date = end_date
        self.excel_path = excel_path
        self.first_write = True
    
    def load_auditor_group(self, auditor_group_path):
        """加载审核员审核组信息
        """
        auditor_group_dict = dict()
        with open(auditor_group_path, mode="r", encoding="utf-8") as rf:
            for index, line in enumerate(rf):
                if index == 0:
                    continue
                parts = line.strip("\n").split("\t")
                group_id = parts[0]
                auditor_id = parts[1]
                if auditor_id == "0":
                    continue
                assert auditor_id not in auditor_group_dict, "duplicate auditor({}) in auditor_group".format(auditor_id)
                auditor_group_dict[auditor_id] = group_id
        
        return auditor_group_dict

    def gen_days_iter(self, start_date, end_date):
        """根据起止日期生成迭代日期
        """
        start_date = datetime.strptime(start_date, "%Y%m%d")
        end_date = datetime.strptime(end_date, "%Y%m%d")
        cur_date = start_date
        while cur_date <= end_date:
            yield cur_date
            cur_date += timedelta(days=1)

    def total_hourly_monitor(self):
        """小时级各状态监控
        """
        status_monitor = StatInfo(stat_attr_list=[
            "hour",
            "tobeaudit_ad_num",
            "in_ad_num",
            "out_ad_num",
            "direct_out_ad_num",
            "merge_out_ad_num",
            "relate_out_ad_num",
            "auditor_num",
            "audit_op_time",
            "audit_saturation",
            "max_audit_saturation",
            "Q3_audit_saturation",
            "Q3_expected_auditor_num",
            "audit_efficiency",
            "median_tobeassign_time",
            "median_tobeaudit_time",
            "median_audit_time",
            "median_total_time",
            "mean_tobeassign_time",
            "mean_tobeaudit_time",
            "mean_audit_time",
            "mean_total_time",
        ], key_num=1)

        auditor_hour_stat = None
        mt_audit_time_hour_stat = None
        throughput_hour_stat = None

        def tar_hour_monitor(tar_hour, tar_hour_format=None):
            if tar_hour_format is None:
                tar_hour_format = tar_hour

            #logging.info("cur hour format: {}".format(tar_hour_format))
            cur_monitor = status_monitor[tar_hour_format]

            if throughput_hour_stat is not None and tar_hour in throughput_hour_stat:
                cur_hour_throughput_stat = throughput_hour_stat[tar_hour]
                cur_monitor["tobeaudit_ad_num"] = cur_hour_throughput_stat["tobeaudit_ad_num_at_begin"]
                cur_monitor["in_ad_num"]        = cur_hour_throughput_stat["in_ad_num"]
            
            if auditor_hour_stat is not None and tar_hour in auditor_hour_stat["total"]:
                cur_hour_auditor_stat = auditor_hour_stat["total"][tar_hour]

                # 遍历当前时间各审核员的饱和度 给出最大和75分位的饱和度
                saturation_list = list()
                for auditor_id, cur_hour_stat in auditor_hour_stat.items():
                    if auditor_id != "total" and tar_hour in cur_hour_stat:
                        #print("type: {}".format(type(cur_hour_stat[tar_hour]["saturation"])))
                        saturation_list.append(float(cur_hour_stat[tar_hour]["saturation"]))
                
                # 各时间段 审核人数即工作时长
                # total则不是
                assert len(saturation_list) == int(cur_hour_auditor_stat["auditor_num"]), \
                        "suturation_list size = {}, auditor_num = {}".format(
                                len(saturation_list),
                                cur_hour_auditor_stat["auditor_num"],
                                )

                saturation_list = np.array(saturation_list)
                max_audit_saturation = saturation_list.max()
                Q3_audit_saturation = np.percentile(saturation_list, 75)

                auditor_num = int(cur_hour_auditor_stat["auditor_num"])
                mean_audit_saturation = float(cur_hour_auditor_stat["saturation"])
                
                # 计算饱和度都为75分位时 应该的审核人数
                Q3_expected_auditor_num = math.ceil(auditor_num * mean_audit_saturation / float(Q3_audit_saturation))

                # 一个小时内的work_num 就是有多少审核员在审核
                cur_monitor["auditor_num"]             = cur_hour_auditor_stat["auditor_num"]
                # throughput数据稳定性不高 因此用auidtor_hour_stat中的人审物料量的数据
                # 这两个来源的数据 如果都有 应该是一致的
                cur_monitor["out_ad_num"]              = cur_hour_auditor_stat["total_mt_count"]
                cur_monitor["direct_out_ad_num"]       = cur_hour_auditor_stat["direct_mt_count"]
                cur_monitor["merge_out_ad_num"]        = cur_hour_auditor_stat["merge_mt_count"]
                cur_monitor["relate_out_ad_num"]       = cur_hour_auditor_stat["relate_mt_count"]
                cur_monitor["audit_op_time"]           = cur_hour_auditor_stat["audit_op_time"]
                cur_monitor["audit_saturation"]        = cur_hour_auditor_stat["saturation"]
                cur_monitor["max_audit_saturation"]    = "{:.4f}".format(max_audit_saturation)
                cur_monitor["Q3_audit_saturation"]     = "{:.4f}".format(Q3_audit_saturation)
                cur_monitor["Q3_expected_auditor_num"] = "{:.0f}".format(Q3_expected_auditor_num)
                cur_monitor["audit_efficiency"]        = cur_hour_auditor_stat["direct_audit_efficiency"]

            if mt_audit_time_hour_stat is not None and tar_hour in mt_audit_time_hour_stat:
                cur_hour_mt_median_stat = mt_audit_time_hour_stat[tar_hour]["total"]["median"]
                cur_monitor["median_tobeassign_time"] = cur_hour_mt_median_stat["tobeassign_time"]
                cur_monitor["median_tobeaudit_time"]  = cur_hour_mt_median_stat["tobeaudit_time"]
                cur_monitor["median_audit_time"]      = cur_hour_mt_median_stat["audit_time"]
                cur_monitor["median_total_time"]      = cur_hour_mt_median_stat["total_time"]

                cur_hour_mt_mean_stat = mt_audit_time_hour_stat[tar_hour]["total"]["mean"]
                cur_monitor["mean_tobeassign_time"] = cur_hour_mt_mean_stat["tobeassign_time"]
                cur_monitor["mean_tobeaudit_time"]  = cur_hour_mt_mean_stat["tobeaudit_time"]
                cur_monitor["mean_audit_time"]      = cur_hour_mt_mean_stat["audit_time"]
                cur_monitor["mean_total_time"]      = cur_hour_mt_mean_stat["total_time"]

        for cur_date in self.gen_days_iter(self.start_date, self.end_date):
            logging.info("date: {}".format(cur_date))
            # 吞吐量记录
            cur_hour = cur_date
            cur_date_format = cur_date.strftime("%Y%m%d")

            auditor_hour_stat = None
            mt_audit_time_hour_stat = None
            throughput_hour_stat = None

            auditor_hour_file = os.path.join("output", "auditor_hourly_stat.{}".format(cur_date_format))
            if os.path.exists(auditor_hour_file):
                auditor_hour_stat = StatInfo.load_from_file(auditor_hour_file, key_num=2)
            else:
                logging.warning("file not exists: {}".format(auditor_hour_file))

            mt_audit_time_hour_file = os.path.join("output", "mt_audit_time_hourly_stat.{}".format(cur_date_format))
            if os.path.exists(mt_audit_time_hour_file):
                mt_audit_time_hour_stat = StatInfo.load_from_file(mt_audit_time_hour_file, key_num=3)
            else:
                logging.warning("file not exists: {}".format(mt_audit_time_hour_file))

            throughput_hour_file = os.path.join("output", "throughput_hourly_stat.{}".format(cur_date_format))
            if not os.path.exists(throughput_hour_file):
                logging.warning("file not exists: {}".format(throughput_hour_file))
            else:
                throughput_hour_stat = StatInfo.load_from_file(throughput_hour_file, key_num=1)

            while cur_hour.strftime("%Y%m%d") == cur_date_format:
                cur_hour_format = "{}:00:00".format(cur_hour.strftime("%Y-%m-%d %H"))
                tar_hour_monitor(cur_hour_format)
                cur_hour += timedelta(hours=1)
            tar_hour_monitor("total", "{}".format(cur_date.strftime("%Y-%m-%d")))
        

        status_monitor.save("output/total_hourly_monitor.{}_{}".format(self.start_date, self.end_date))
        self.to_excel(
                status_monitor,
                "total_hourly_monitor",
                )

    def mt_daily_monitor(self):
        """天级物料审核时延监控
        """
        mt_day_monitor = StatInfo(stat_attr_list=[
            "date",
            "mean_tobeassign_time",
            "mean_tobeaudit_time",
            "mean_audit_time",
            "mean_total_time",
            "median_tobeassign_time",
            "median_tobeaudit_time",
            "median_audit_time",
            "median_total_time",
            "tobeaudit_ad_num_at_begin",
            "in_ad_num",
            "out_ad_num",
            "direct_out_ad_num",
            "merge_out_ad_num",
            "relate_out_ad_num",
        ], key_num=1)

        for cur_date in self.gen_days_iter(self.start_date, self.end_date):
            cur_date_format = cur_date.strftime("%Y%m%d")
            cur_date_format2 = cur_date.strftime("%Y-%m-%d")

            mt_hour_stat = None
            throughput_hour_stat = None
            auditor_hour_stat = None

            mt_hour_file = os.path.join("output", "mt_audit_time_hourly_stat.{}".format(cur_date_format))
            if os.path.exists(mt_hour_file):
                mt_hour_stat = StatInfo.load_from_file(mt_hour_file, key_num=3)
            else:
                logging.warning("file not exists: {}".format(mt_hour_file))

            throughput_hour_file = os.path.join("output", "throughput_hourly_stat.{}".format(cur_date_format))
            if os.path.exists(throughput_hour_file):
                throughput_hour_stat = StatInfo.load_from_file(throughput_hour_file, key_num=1)
                if len(throughput_hour_stat.keys()) != 25:
                    logging.warning("file not complete: {}, expect 25 rows, actual {} rows".format(
                        throughput_hour_file, len(throughput_hour_stat.keys())))
                    throughput_hour_stat = None
            else:
                logging.warning("file not exists: {}".format(throughput_hour_file))

            auditor_hour_file = os.path.join("output", "auditor_hourly_stat.{}".format(cur_date_format))
            if os.path.exists(auditor_hour_file):
                auditor_hour_stat = StatInfo.load_from_file(auditor_hour_file, key_num=2)
            else:
                logging.warning("file not exists: {}".format(auditor_hour_file))

            cur_monitor = mt_day_monitor[cur_date_format]

            if mt_hour_stat is not None:
                cur_mean_stat = mt_hour_stat["total"]["total"]["mean"]
                cur_median_stat = mt_hour_stat["total"]["total"]["median"]
                cur_monitor["mean_tobeassign_time"]   = cur_mean_stat["tobeassign_time"]
                cur_monitor["mean_tobeaudit_time"]    = cur_mean_stat["tobeaudit_time"]
                cur_monitor["mean_audit_time"]        = cur_mean_stat["audit_time"]
                cur_monitor["mean_total_time"]        = cur_mean_stat["total_time"]
                cur_monitor["median_tobeassign_time"] = cur_median_stat["tobeassign_time"]
                cur_monitor["median_tobeaudit_time"]  = cur_median_stat["tobeaudit_time"]
                cur_monitor["median_audit_time"]      = cur_median_stat["audit_time"]
                cur_monitor["median_total_time"]      = cur_median_stat["total_time"]
            
            # throughput数据只拿进审量
            # TODO 部分日期的throughput数据可能不完整 进审量数据可能不准确
            if throughput_hour_stat is not None:
                cur_monitor["tobeaudit_ad_num_at_begin"] = \
                    throughput_hour_stat["{} 00:00:00".format(cur_date_format2)]["tobeaudit_ad_num_at_begin"]
                cur_monitor["in_ad_num"] = \
                    throughput_hour_stat["{} 23:00:00".format(cur_date_format2)]["total_in_ad_num"]

            # 出审量从人审数据中拿
            if auditor_hour_stat is not None:
                cur_stat = auditor_hour_stat["total"]["total"]
                cur_monitor["out_ad_num"]        = cur_stat["total_mt_count"]
                cur_monitor["direct_out_ad_num"] = cur_stat["direct_mt_count"]
                cur_monitor["merge_out_ad_num"]  = cur_stat["merge_mt_count"]
                cur_monitor["relate_out_ad_num"] = cur_stat["relate_mt_count"]

        mt_day_monitor.save("output/mt_daily_monitor.{}_{}".format(self.start_date, self.end_date))
        self.to_excel(
                mt_day_monitor,
                "mt_daily_monitor",
                )

    def auditor_daily_monitor(self):
        """天级审核员监控
        """
        auditor_day_monitor = StatInfo(stat_attr_list=[
            "auditor",
            "date",
            "audit_group",             # 审核组ID
            "total_mt_count",
            "direct_mt_count",
            "merge_mt_count",
            "relate_mt_count",
            "audit_task_num",
            "audit_op_time",
            "audit_op_count",
            "work_hour",
            "saturation",
            "audit_efficiency",
            "direct_mt_num_per_op",
            "dist_task_num",
            "task_seq_sim_score",
            "top3_dist_info",
        ], key_num=3)

        for cur_date in self.gen_days_iter(self.start_date, self.end_date):
            cur_date_format = cur_date.strftime("%Y%m%d")
            cur_date_format2 = cur_date.strftime("%Y-%m-%d")

            auditor_hour_stat = None
            auditor_trade_eff_dict = None

            auditor_hour_file = os.path.join("output", "auditor_hourly_stat.{}".format(cur_date_format))
            if os.path.exists(auditor_hour_file):
                auditor_hour_stat = StatInfo.load_from_file(auditor_hour_file, key_num=2)
            else:
                logging.warning("file not exists: {}".format(auditor_hour_file))

            auditor_eff_first_trade_file = \
                    os.path.join("output", "auditor_efficiency_first_level_trade.{}".format(cur_date_format))
            if os.path.exists(auditor_eff_first_trade_file):
                auditor_eff_first_trade_stat = StatInfo.load_from_file(auditor_eff_first_trade_file, key_num=2)
                auditor_trade_eff_dict = collections.defaultdict(dict)
                for cur_auditor_id, cur_trade_stat in auditor_eff_first_trade_stat.items():
                    for cur_trade_id, cur_stat in cur_trade_stat.items():
                        cur_trade = self.trade_id_name_dict.get(cur_trade_id, "未知")
                        auditor_trade_eff_dict[cur_auditor_id][cur_trade] = divide(
                                float(cur_stat["sum_task_direct_mt_count"]),
                                float(cur_stat["sum_audit_op_time"]),
                                )
            else:
                logging.warning("file not exists: {}".format(auditor_eff_first_trade_file))

            if auditor_hour_stat is not None:

                group_stat = collections.defaultdict(lambda: collections.defaultdict(float))
                for cur_auditor_id in auditor_hour_stat.keys():
                    cur_day_stat = auditor_hour_stat[cur_auditor_id]["total"]
                    cur_audit_group = self.auditor_group_dict.get(cur_auditor_id, "None")
                    cur_monitor = auditor_day_monitor[cur_auditor_id][cur_date_format2][cur_audit_group]
                    cur_monitor["total_mt_count"]        = cur_day_stat["total_mt_count"]
                    cur_monitor["direct_mt_count"]       = cur_day_stat["direct_mt_count"]
                    cur_monitor["merge_mt_count"]        = cur_day_stat["merge_mt_count"]
                    cur_monitor["relate_mt_count"]       = cur_day_stat["relate_mt_count"]
                    cur_monitor["audit_task_num"]        = cur_day_stat["audit_task_num"]
                    cur_monitor["audit_op_time"]         = cur_day_stat["audit_op_time"]
                    cur_monitor["audit_op_count"]        = cur_day_stat["audit_op_count"]
                    cur_monitor["work_hour"]             = cur_day_stat["work_hour"]
                    cur_monitor["saturation"]            = cur_day_stat["saturation"]
                    cur_monitor["audit_efficiency"]      = cur_day_stat["direct_audit_efficiency"]
                    cur_monitor["direct_mt_num_per_op"]  = cur_day_stat["direct_mt_num_per_op"]
                    cur_monitor["dist_task_num"]         = cur_day_stat["dist_task_num"]
                    cur_monitor["task_seq_sim_score"]    = cur_day_stat["task_seq_sim_score"]
                    if cur_day_stat["dist_info"] != "None":
                        cur_monitor["top3_dist_info"] = dist_info_format(
                                dist_info=cur_day_stat["dist_info"],
                                top_k=3,
                                auditor_id=cur_auditor_id,
                                auditor_trade_eff_dict=auditor_trade_eff_dict,
                                )
                    #cur_monitor["dist_info"]             = cur_day_stat["dist_info"]

                    # 统计各group的汇总信息
                    if cur_auditor_id != "total":
                        # 加入到group中
                        group_stat[cur_audit_group]["total_mt_count"]  += float(cur_day_stat["total_mt_count"])
                        group_stat[cur_audit_group]["direct_mt_count"] += float(cur_day_stat["direct_mt_count"])
                        group_stat[cur_audit_group]["merge_mt_count"]  += float(cur_day_stat["merge_mt_count"])
                        group_stat[cur_audit_group]["relate_mt_count"] += float(cur_day_stat["relate_mt_count"])
                        group_stat[cur_audit_group]["audit_task_num"]  += float(cur_day_stat["audit_task_num"])
                        group_stat[cur_audit_group]["audit_op_time"]   += float(cur_day_stat["audit_op_time"])
                        group_stat[cur_audit_group]["audit_op_count"]  += float(cur_day_stat["audit_op_count"])
                        group_stat[cur_audit_group]["work_hour"]       += float(cur_day_stat["work_hour"])
                        # TODO 有的是None
                        group_stat[cur_audit_group]["dist_task_num"]   += float(cur_day_stat["dist_task_num"])
                        # 饱和度需要用各审核员的所有工作分钟数 除以总工作时长 所以这里记录总工作分钟数
                        group_stat[cur_audit_group]["saturation_sum"]  += \
                                float(cur_day_stat["work_hour"]) * float(cur_day_stat["saturation"])

                for cur_group, cur_stat in group_stat.items():
                    cur_group_monitor = auditor_day_monitor["total"][cur_date_format2][cur_group]
                    cur_group_monitor["total_mt_count"]        = "{:.0f}".format(cur_stat["total_mt_count"])
                    cur_group_monitor["direct_mt_count"]       = "{:.0f}".format(cur_stat["direct_mt_count"])
                    cur_group_monitor["merge_mt_count"]        = "{:.0f}".format(cur_stat["merge_mt_count"])
                    cur_group_monitor["relate_mt_count"]       = "{:.0f}".format(cur_stat["relate_mt_count"])
                    cur_group_monitor["audit_task_num"]        = "{:.0f}".format(cur_stat["audit_task_num"])
                    cur_group_monitor["audit_op_time"]         = "{:.0f}".format(cur_stat["audit_op_time"])
                    cur_group_monitor["audit_op_count"]        = "{:.0f}".format(cur_stat["audit_op_count"])
                    cur_group_monitor["work_hour"]             = "{:.0f}".format(cur_stat["work_hour"])

                    cur_group_monitor["saturation"]            = "{:.4f}".format(cur_stat["saturation_sum"] / cur_stat["work_hour"])
                    cur_group_monitor["audit_efficiency"]      = "{:.4f}".format(cur_stat["direct_mt_count"] / cur_stat["audit_op_time"])
                    cur_group_monitor["direct_mt_num_per_op"] = "{:.4f}".format(cur_stat["direct_mt_count"] / cur_stat["audit_op_count"])

        auditor_day_monitor.save("output/auditor_daily_monitor.{}_{}".format(self.start_date, self.end_date), sort=True)
        self.to_excel(
                auditor_day_monitor,
                "auditor_daily_monitor",
                )

    def efficiency_daily_monitor(self):
        """总体平均效率
        """
        efficiency_day_monitor = StatInfo(stat_attr_list=[
            "date",
            "in_ad_num",
            "total_mt_count",
            "direct_mt_count",
            "merge_relate_ratio",
            "merge_mt_count",
            "relate_mt_count",
            "audit_op_time",
            "audit_op_count",
            "audit_efficiency",
            "direct_mt_num_per_op",
            "time_per_op",
            "audit_saturation",
            "auditor_num",
            "work_hour",
        ], key_num = 1)

        for cur_date in self.gen_days_iter(self.start_date, self.end_date):
            cur_date_format = cur_date.strftime("%Y%m%d")
            cur_monitor = efficiency_day_monitor[cur_date_format]

            auditor_hour_stat = None
            throughput_hour_stat = None

            cur_auditor_hour_file = os.path.join("output", "auditor_hourly_stat.{}".format(cur_date_format))
            if os.path.exists(cur_auditor_hour_file):
                auditor_hour_stat = StatInfo.load_from_file(cur_auditor_hour_file, key_num=2)
            else:
                logging.warning("file not exists: {}".format(cur_auditor_hour_file))

            throughput_hour_file = os.path.join("output", "throughput_hourly_stat.{}".format(cur_date_format))
            if os.path.exists(throughput_hour_file):
                throughput_hour_stat = StatInfo.load_from_file(throughput_hour_file, key_num=1)
                if len(throughput_hour_stat.keys()) != 25:
                    logging.warning("file not complete: {}, expect 25 rows, actual {} rows".format(
                        throughput_hour_file, len(throughput_hour_stat.keys())))
                    throughput_hour_stat = None
            else:
                logging.warning("file not exists: {}".format(throughput_hour_file))

            if auditor_hour_stat is not None:
                cur_stat = auditor_hour_stat["total"]["total"]
                cur_monitor["total_mt_count"]        = cur_stat["total_mt_count"]
                cur_monitor["direct_mt_count"]       = cur_stat["direct_mt_count"]
                cur_monitor["merge_relate_ratio"]    = cur_stat["merge_relate_ratio"]
                cur_monitor["merge_mt_count"]        = cur_stat["merge_mt_count"]
                cur_monitor["relate_mt_count"]       = cur_stat["relate_mt_count"]
                cur_monitor["audit_op_time"]         = cur_stat["audit_op_time"]
                cur_monitor["audit_op_count"]        = cur_stat["audit_op_count"]
                cur_monitor["audit_efficiency"]      = cur_stat["direct_audit_efficiency"]
                cur_monitor["direct_mt_num_per_op"]  = cur_stat["direct_mt_num_per_op"]
                cur_monitor["time_per_op"]           = cur_stat["time_per_op"]
                cur_monitor["audit_saturation"]      = cur_stat["saturation"]
                cur_monitor["auditor_num"]           = cur_stat["auditor_num"]
                cur_monitor["work_hour"]             = cur_stat["work_hour"]

            if throughput_hour_stat is not None:
                cur_monitor["in_ad_num"] = throughput_hour_stat["total"]["in_ad_num"]

        efficiency_day_monitor.save("output/efficiency_daily_monitor.{}_{}".format(self.start_date, self.end_date))
        self.to_excel(
                efficiency_day_monitor,
                "efficiency_daily_monitor",
                )

    def trade_daily_monitor(self):
        """各行业的天级数据监控
        """
        trade_day_monitor = StatInfo(stat_attr_list=[
            "date",
            "first_level_trade",
            "total_mt_count",
            "direct_mt_count",
            "audit_op_time",
            "audit_op_count",
            "direct_mt_ratio",
            "audit_efficiency",
            "audit_efficiency_liuxing_mean",
            "audit_efficiency_liuxing_median",
            "direct_mt_num_per_op",
            "mean_tobeassign_time",
            "mean_tobeaudit_time",
            "mean_audit_time",
            "mean_total_time",
            "median_tobeassign_time",
            "median_tobeaudit_time",
            "median_audit_time",
            "median_total_time",
            "90%_tobeassign_time",
            "90%_tobeaudit_time",
            "90%_audit_time",
            "90%_total_time",
            "95%_tobeassign_time",
            "95%_tobeaudit_time",
            "95%_audit_time",
            "95%_total_time",
            "99%_tobeassign_time",
            "99%_tobeaudit_time",
            "99%_audit_time",
            "99%_total_time",
        ], key_num = 2)

        for cur_date in self.gen_days_iter(self.start_date, self.end_date):
            cur_date_format = cur_date.strftime("%Y%m%d")
            cur_date_monitor = trade_day_monitor[cur_date_format]

            trade_stat = None
            mt_stat = None

            cur_trade_file = os.path.join("output", "auditor_efficiency_first_level_trade.{}".format(cur_date_format))
            if os.path.exists(cur_trade_file):
                trade_stat = StatInfo.load_from_file(cur_trade_file, key_num=2)
            else:
                logging.warning("file not exists: {}".format(cur_trade_file))

            cur_mt_file = os.path.join("output", "mt_audit_time_hourly_stat.{}".format(cur_date_format))
            if os.path.exists(cur_mt_file):
                mt_stat = StatInfo.load_from_file(cur_mt_file, key_num=3)
            else:
                logging.warning("file not exists: {}".format(cur_mt_file))
            
            if trade_stat is not None:
                total_direct_mt_count = float(trade_stat["total"]["total"]["sum_task_direct_mt_count"])
                for cur_trade_id, cur_trade_stat in sorted(trade_stat["total"].items()):
                    cur_trade = "{}({})".format(self.trade_id_name_dict.get(cur_trade_id, "未知") , cur_trade_id)

                    # 刘星计算逻辑：各行业各任务效率的统计值
                    cur_efficiency_mean = cur_trade_stat["mean_direct_audit_efficiency"]
                    cur_efficiency_median = cur_trade_stat["median_direct_audit_efficiency"]

                    # 张皓计算逻辑：各行业总物料数/总审核时间
                    cur_direct_audit_efficiency = divide(
                        float(cur_trade_stat["sum_task_direct_mt_count"]),
                        float(cur_trade_stat["sum_audit_op_time"]),
                        )

                    cur_direct_mt_num_per_op = divide(
                        float(cur_trade_stat["sum_task_direct_mt_count"]),
                        float(cur_trade_stat["sum_audit_op_number"]),
                        )
                    
                    cur_direct_mt_count = float(cur_trade_stat["sum_task_direct_mt_count"])
                    cur_direct_mt_ratio = divide(
                        cur_direct_mt_count * 100,
                        total_direct_mt_count,
                        )

                    cur_date_monitor[cur_trade] = {
                            "total_mt_count"                  : cur_trade_stat["sum_task_mt_count"],
                            "direct_mt_count"                 : "{:.0f}".format(cur_direct_mt_count),
                            "audit_op_time"                   : cur_trade_stat["sum_audit_op_time"],
                            "audit_op_count"                  : cur_trade_stat["sum_audit_op_number"],
                            "direct_mt_ratio"                 : "{:.2f}%".format(cur_direct_mt_ratio),
                            "audit_efficiency"                : "{:.4f}".format(cur_direct_audit_efficiency),
                            "audit_efficiency_liuxing_mean"   : cur_efficiency_mean,
                            "audit_efficiency_liuxing_median" : cur_efficiency_median,
                            "direct_mt_num_per_op"            : "{:.4f}".format(cur_direct_mt_num_per_op),
                            }

            if mt_stat is not None:
                for cur_trade_id, cur_trade_stat in sorted(mt_stat["total"].items()):
                    cur_trade = "{}({})".format(self.trade_id_name_dict.get(cur_trade_id, "未知") , cur_trade_id)

                    cur_date_monitor[cur_trade]["mean_tobeassign_time"] = "{:.2f}".format(float(cur_trade_stat["mean"]["tobeassign_time"]))
                    cur_date_monitor[cur_trade]["mean_tobeaudit_time" ] = "{:.2f}".format(float(cur_trade_stat["mean"]["tobeaudit_time"]))
                    cur_date_monitor[cur_trade]["mean_audit_time"     ] = "{:.2f}".format(float(cur_trade_stat["mean"]["audit_time"]))
                    cur_date_monitor[cur_trade]["mean_total_time"     ] = "{:.2f}".format(float(cur_trade_stat["mean"]["total_time"]))
                    cur_date_monitor[cur_trade]["median_tobeassign_time"] = "{:.2f}".format(float(cur_trade_stat["median"]["tobeassign_time"]))
                    cur_date_monitor[cur_trade]["median_tobeaudit_time" ] = "{:.2f}".format(float(cur_trade_stat["median"]["tobeaudit_time"]))
                    cur_date_monitor[cur_trade]["median_audit_time"     ] = "{:.2f}".format(float(cur_trade_stat["median"]["audit_time"]))
                    cur_date_monitor[cur_trade]["median_total_time"     ] = "{:.2f}".format(float(cur_trade_stat["median"]["total_time"]))
                    cur_date_monitor[cur_trade]["90%_tobeassign_time"] = "{:.2f}".format(float(cur_trade_stat["90_percentile"]["tobeassign_time"]))
                    cur_date_monitor[cur_trade]["90%_tobeaudit_time" ] = "{:.2f}".format(float(cur_trade_stat["90_percentile"]["tobeaudit_time"]))
                    cur_date_monitor[cur_trade]["90%_audit_time"     ] = "{:.2f}".format(float(cur_trade_stat["90_percentile"]["audit_time"]))
                    cur_date_monitor[cur_trade]["90%_total_time"     ] = "{:.2f}".format(float(cur_trade_stat["90_percentile"]["total_time"]))
                    cur_date_monitor[cur_trade]["95%_tobeassign_time"] = "{:.2f}".format(float(cur_trade_stat["95_percentile"]["tobeassign_time"]))
                    cur_date_monitor[cur_trade]["95%_tobeaudit_time" ] = "{:.2f}".format(float(cur_trade_stat["95_percentile"]["tobeaudit_time"]))
                    cur_date_monitor[cur_trade]["95%_audit_time"     ] = "{:.2f}".format(float(cur_trade_stat["95_percentile"]["audit_time"]))
                    cur_date_monitor[cur_trade]["95%_total_time"     ] = "{:.2f}".format(float(cur_trade_stat["95_percentile"]["total_time"]))
                    cur_date_monitor[cur_trade]["99%_tobeassign_time"] = "{:.2f}".format(float(cur_trade_stat["99_percentile"]["tobeassign_time"]))
                    cur_date_monitor[cur_trade]["99%_tobeaudit_time" ] = "{:.2f}".format(float(cur_trade_stat["99_percentile"]["tobeaudit_time"]))
                    cur_date_monitor[cur_trade]["99%_audit_time"     ] = "{:.2f}".format(float(cur_trade_stat["99_percentile"]["audit_time"]))
                    cur_date_monitor[cur_trade]["99%_total_time"     ] = "{:.2f}".format(float(cur_trade_stat["99_percentile"]["total_time"]))


        trade_day_monitor.save("output/trade_daily_monitor.{}_{}".format(self.start_date, self.end_date))
        self.to_excel(
                trade_day_monitor,
                "trade_daily_monitor",
                )

    def efficiency_statistics(self):
        """
        auditor statistics during duration days
        """
        info_path = 'output'
        duration = 30
        valid_duration = 10
        auditor_valid_durations = collections.defaultdict(set)

        end_day = self.end_date
        start_day = (datetime.strptime(end_day, '%Y%m%d') - timedelta(days=duration - 1)).strftime('%Y%m%d')
        aspects = ['first_level_trade', 'second_level_trade', 'sale_system']
        choice = 'efficiency'

        attr_list = []
        # 统计一段时间之内审核员效率数据
        auditor_data = collections.defaultdict(lambda: collections.defaultdict(
                            lambda: collections.defaultdict(lambda: collections.defaultdict(list))))
        for day_diff in range(duration):
            this_day = (datetime.strptime(end_day, '%Y%m%d')
                        - timedelta(days=day_diff)).strftime('%Y%m%d')
            for aspect in aspects:
                filename = os.path.join(info_path, f'auditor_efficiency_{aspect}.{this_day}')
                if not os.path.exists(filename):
                    logging.warning("{} doesn't exist.".format(filename))
                    continue
                cls = StatInfo.load_from_file(filename, key_num=2)
                if not attr_list:
                    attr_list.extend([item for item in cls.stat_attr_list if choice in item])
                for auditor, auditor_item in cls.items():
                    if len(auditor_valid_durations[auditor]) > valid_duration:
                        continue
                    auditor_valid_durations[auditor].add(this_day)

                    for tradeid, trade_item in auditor_item.items():
                        for key, value in trade_item.items():
                            if choice not in key:
                                continue
                            # 这里后续做异常去除操作
                            # pass
                            auditor_data[aspect][tradeid][auditor][key].append(float(value))


        # 统计一段时间之内审核员效率平均数据
        auditor_statistics = collections.defaultdict(lambda: collections.defaultdict(
                            lambda: collections.defaultdict(lambda: collections.defaultdict(float))))
        for aspect, aspect_item in auditor_data.items():
            for tradeid, trade_item in aspect_item.items():
                # 统计行业中所有审核员的平均，中位数指标
                tradeid_statistics = collections.defaultdict(list)

                for auditor, auditor_item in trade_item.items():
                    for key, value in auditor_item.items():
                        result = float(np.__dict__[key.split('_')[0]](value))
                        auditor_statistics[aspect][tradeid][auditor][key] = '{:.4f}'.format(result)
                        tradeid_statistics[key].append(result)

                # 对于未知审核员，按照行业所有审核员平均水平赋值
                for key, value in tradeid_statistics.items():
                    auditor_statistics[aspect][tradeid]['unkown'][key] = '{:.4f}'.format(float(np.__dict__[key.split('_')[0]](value)))

        out_attr_list = ['aspect', 'tradeid', 'auditorid'] + attr_list

        efficiency_statistics = StatInfo(stat_attr_list=out_attr_list.copy(),
                                         stat_dict = auditor_statistics,
                                         key_num = 3)
        outfile_path = os.path.join(info_path, 'monitor', 'efficiency', f'efficiency_statistics.{start_day}_{end_day}')
        os.makedirs(os.path.dirname(outfile_path), exist_ok=True)
        efficiency_statistics.save(outfile_path)

    def pid_daily_monitor(self):
        """天级各产品线指标监控
        """
        pid_day_monitor = StatInfo(stat_attr_list=[
            "date",
            "pid",
            "total_mt_count",
            "direct_mt_count",
            "merge_mt_count",
            "relate_mt_count",
            "audit_op_time",
            "audit_op_count",
            "direct_audit_efficiency",
            "direct_mt_num_per_op",
        ], key_num = 2)

        for cur_date in self.gen_days_iter(self.start_date, self.end_date):
            cur_date_format = cur_date.strftime("%Y%m%d")
            cur_date_monitor = pid_day_monitor[cur_date_format]

            pid_trade_day_stat = None

            cur_pid_trade_day_file = os.path.join("output", "pid_trade_daily_stat.{}".format(cur_date_format))
            if os.path.exists(cur_pid_trade_day_file):
                pid_trade_day_stat = StatInfo.load_from_file(cur_pid_trade_day_file, key_num=3)
            else:
                logging.warning("file not exists: {}".format(cur_pid_trade_day_file))

            if pid_trade_day_stat is not None:
                for cur_pid, cur_trade_day_stat in pid_trade_day_stat.items():
                    cur_monitor = cur_date_monitor[cur_pid]
                    cur_stat = cur_trade_day_stat["total"]["total"]
                    cur_monitor["total_mt_count"]          = cur_stat["total_mt_count"]
                    cur_monitor["direct_mt_count"]         = cur_stat["direct_mt_count"]
                    cur_monitor["merge_mt_count"]          = cur_stat["merge_mt_count"]
                    cur_monitor["relate_mt_count"]         = cur_stat["relate_mt_count"]
                    cur_monitor["audit_op_time"]           = cur_stat["audit_op_time"]
                    cur_monitor["audit_op_count"]          = cur_stat["audit_op_count"]
                    cur_monitor["direct_audit_efficiency"] = cur_stat["direct_audit_efficiency"]
                    cur_monitor["direct_mt_num_per_op"]    = cur_stat["direct_mt_num_per_op"]

        pid_day_monitor.save("output/pid_daily_monitor.{}_{}".format(self.start_date, self.end_date))
        self.to_excel(
                pid_day_monitor,
                "pid_daily_monitor",
                )

    def to_excel(self, cur_stat_info, sheet_name, attr_list=None):
        """统计结果存入excel中
        """
        if self.excel_path is not None:
            cur_mode = "w" if self.first_write else "a"
            cur_list = cur_stat_info.to_list(attr_list=attr_list)
            if attr_list is None:
                columns = cur_stat_info.stat_attr_list
            else:
                columns = cur_stat_info.stat_attr_list[:cur_stat_info.key_num] + attr_list
            with pd.ExcelWriter(self.excel_path, mode=cur_mode, engine="openpyxl") as writer:
                pd.DataFrame(
                        cur_list,
                        columns=columns,
                        ).to_excel(writer, sheet_name=sheet_name, index=False, encoding="utf-8")

            self.first_write = False

    def record(self, config_list):
        """总记录入口
        """
        for index in range(len(config_list)):
            getattr(self, config_list[index])()


if __name__ == "__main__":
    meg_id_map_path = sys.argv[1]
    auditor_group_path = sys.argv[2]
    start_date = sys.argv[3]
    end_date = sys.argv[4]
    if len(sys.argv) > 5:
        excel_path = sys.argv[5]
    m = Monitor(meg_id_map_path, auditor_group_path, start_date, end_date, excel_path)
    m.record(conf.monitor)
