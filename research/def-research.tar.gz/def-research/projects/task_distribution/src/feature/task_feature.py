#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   21/08/18 19:31:16
Desc  :   任务维度特征提取
"""
import os
import sys

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.review_object as review_object
import conf
import common.common as common


class TaskFeatureExtract(object):
    """任务特征提取类
    """
    def __init__(self, date, window_size):
        """init
        """
        self.date = date
        self.window_size = window_size

    def init(self):
        """init
        """
        if not self.read_task_related_data():
            return False
        return True

    def read_task_related_data(self):
        """计算task维度特征所需的所有数据
        """
        self.current_task_data = dict()
        file_name = "data/%s%s" % (conf.task_data_prefix, self.date)
        try:
            for index, parts in common.Common.read_file(file_name):
                task_human_audit = review_object.TaskHumanAuditResult(parts)
                self.current_task_data[task_human_audit.taskid] = task_human_audit
        except Exception as e:
            sys.stderr.write("TaskFeatureExtract read_task_related_data filed. [{}]\n".format(str(e)))
            return False
        return True

    def total_mt_count(self, taskid):
        """返回物料总量
        """
        return self.current_task_data[taskid].task_mt_count

    def direct_mt_count(self, taskid):
        """返回聚合后物料总量（人审实际看到的物料量）
        """
        return self.current_task_data[taskid].task_direct_mt_count

    def task_first_level_trade(self, taskid):
        """任务MEG一级行业
        """
        return self.current_task_data[taskid].first_level_trade

    def task_second_level_trade(self, taskid):
        """任务MEG二级行业
        """
        return self.current_task_data[taskid].second_level_trade

    def task_sale_system(self, taskid):
        """任务的销售体系
        """
        return self.current_task_data[taskid].sale_system

    def task_prodictid(self, taskid):
        """任务产品线id
        """
        return self.current_task_data[taskid].pid

    def get_task_feature(self, taskid, config_list):
        """根据conf输出相应的task纬度数据
        """
        task_feature = []
        for index in range(len(config_list)):
            task_feature.append(getattr(self, config_list[index])(taskid))
        return task_feature


if __name__ == "__main__":
    pass


