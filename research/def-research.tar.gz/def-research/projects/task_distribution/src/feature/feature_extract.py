#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   21/08/13 14:35:02
Desc  :   特征提取
"""
import os
import sys
import codecs
import datetime
import tqdm

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.review_object as review_object
import common.common as common
import conf
import task_feature
import auditor_feature
import context_feature


class FeatureExtract(object):
    """特征提取类
    """
    def __init__(self, date, window_size=7):
        """init
        Args:
            date:           待预测时间
            window_size:    假设window_size = 7, date = 20210818,
                            那么窗口时间为20210811-20210817
        """
        self.date = date
        self.window_size = window_size

    def init_statis_feature(self, date=None, window_size=None):
        """
        init 统计方面的特征
        """
        if date is None:
            date = self.date
        if window_size == None:
            window_size = self.window_size
        self.auditor_feature_obj = auditor_feature.AuditorFeatureExtract(date, window_size)
        if not self.auditor_feature_obj.init():
            return False
        return True

    def init_attr_feature(self, date=None):
        """
        init 属性特征
        """
        if date is None:
            date = self.date
        self.task_feature_obj = task_feature.TaskFeatureExtract(date, self.window_size)
        if not self.task_feature_obj.init():
            return False

        self.context_feature_obj = context_feature.ContextFeatureExtract(date, self.window_size)
        if not self.context_feature_obj.init():
            return False

        return True

    def init(self):
        """init
        """
        return self.init_statis_feature() and self.init_attr_feature()

    def feature_extract(self, task_human_audit):
        """特征提取入口
        Args:
            task_human_audit:   TaskHumanAuditResult的初始化对象
        """
        # 任务id
        taskid = task_human_audit.taskid
        # 审核员id
        auditor = task_human_audit.auditor
        # 时间戳
        context = task_human_audit.task_begin_time
        # 目标值
        y = getattr(task_human_audit, conf.feature["y"])

        # 提取特征
        task_feature_list = self.task_feature_obj.get_task_feature(taskid,
                                conf.feature["x"]["task_feature"])
        auditor_feature_list = self.auditor_feature_obj.get_auditor_feature(task_human_audit,
                                    conf.feature["x"]["auditor_feature"])
        context_feature_list = self.context_feature_obj.get_context_feature(context,
                                    conf.feature["x"]["context_feature"])

        # 合并
        feature_y_list = []
        feature_y_list.extend(task_feature_list)
        feature_y_list.extend(auditor_feature_list)
        feature_y_list.extend(context_feature_list)
        feature_y_list.append(y)
        return feature_y_list


if __name__ == "__main__":
    if len(sys.argv) < 2:
        date = datetime.datetime.today().strftime('%Y%m%d')
    else:
        date = sys.argv[1]
    day_duration = 1
    auditor_statis_day = date
    fe = FeatureExtract(auditor_statis_day, day_duration)
    if not fe.init_statis_feature('20210829', 7):
        sys.stderr.write("FeatureExtract statis_feature init failed.\n")
        sys.exit(1)

    begin_day = common.Common.cal_date(date, - (day_duration - 1))
    end_day = date

    output_model_data_filename = os.path.join(_cur_dir, '../../model_data', \
                                              f'feature_y_data.{begin_day}-{end_day}.auditor{auditor_statis_day}')
    os.makedirs(os.path.dirname(output_model_data_filename), exist_ok=True)
    if os.path.exists(output_model_data_filename):
        sys.stderr.write(f"data already exists! [{output_model_data_filename}]")
        sys.exit(1)

    fout = open(output_model_data_filename, 'w+')

    for day_diff in range(0, day_duration):
        this_day = common.Common.cal_date(date, - 1 * day_diff)
        file_name = "data/%s%s" % (conf.task_data_prefix, this_day)
        if not os.path.exists(file_name):
            continue

        print(f'processing task data; [{this_day}]\n\ttask data path: [{file_name}]')
        if not fe.init_attr_feature(date=this_day):
            sys.stderr.write("FeatureExtract attr_feature init failed.\n")
            sys.exit(1)

        for index, parts in tqdm.tqdm(common.Common.read_file(file_name)):
            task_human_audit = review_object.TaskHumanAuditResult(parts)
            feature_y_list = fe.feature_extract(task_human_audit)
            fout.write('%s\n' % ('\t'.join(feature_y_list)))
    fout.close()


