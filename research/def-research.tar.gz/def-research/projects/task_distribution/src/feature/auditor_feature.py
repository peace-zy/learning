#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   21/08/23 15:46:31
Desc  :   审核员维度特征提取
"""
import os
import sys
import datetime

import numpy
import collections

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.review_object as review_object
import conf
import common.common as common
from utils.stat_info import StatInfo


class AuditorFeatureExtract(object):
    """审核员特征提取类
    """
    def __init__(self, date, window_size):
        """init
        """
        self.date = date
        self.window_size = window_size

    def init(self):
        """init
        """
        if not self.read_auditor_related_data(
                data_aspects=["first_level_trade", "second_level_trade", "sale_system", 'pid']):
            return False
        return True

    def read_auditor_related_data(self, data_aspects):
        """计算auditor维度特征所需的所有数据
        args:
            data_aspect = choice(["first_level_trade", "second_level_trade", "sale_system"])
        """
        # 计算时间最大间隔
        MAX_DAY = max(self.window_size, 30)

        # 审核员特征
        count = 0
        self.auditor_data = collections.defaultdict(lambda: collections.defaultdict(lambda: collections.defaultdict(
                                                    lambda: collections.defaultdict(list))))
        for day_diff in range(0, MAX_DAY):
            current_day = common.Common.cal_date(self.date, - 1 * day_diff)
            for data_aspect in data_aspects:
                file_name = "output/auditor_efficiency_%s.%s" % (data_aspect, current_day)
                if not os.path.exists(file_name):
                    continue
                try:
                    cls = StatInfo.load_from_file(file_name, key_num=2)
                    for auditor, auditor_item in cls.items():
                        for aspect, aspect_item in auditor_item.items():
                            for key, value in aspect_item.items():
                                self.auditor_data[auditor][data_aspect][aspect][key].append(value)
                    count += 1
                except Exception as e:
                    sys.stderr.write("AuditorFeatureExtract read_auditor_related_data filed. [%s]\n" % str(e))
                    return False

        if count == 0:
            return False

        return True

    def auditor_efficiency(self, task_human_audit, aspect='first_level_trade'):
        """
        审核员审核效率基础逻辑
        """
        if (task_human_audit.auditor_front not in self.auditor_data.keys() \
                or aspect not in self.auditor_data[task_human_audit.auditor_front].keys() \
                or getattr(task_human_audit, aspect) not in self.auditor_data[task_human_audit.auditor_front][aspect].keys()):
            return ["NULL", "NULL"]

        mean_efficiency = numpy.mean([float(i) for i in self.auditor_data[task_human_audit.auditor_front][aspect]
                                      [getattr(task_human_audit, aspect)]['mean_direct_audit_efficiency']])
        median_efficiency = numpy.median([float(i) for i in self.auditor_data[task_human_audit.auditor_front][aspect]
                                      [getattr(task_human_audit, aspect)]['median_direct_audit_efficiency']])
        return [f'{mean_efficiency:.4f}', f'{median_efficiency:.4f}']

    def auditor_efficiency_first_level_trade(self, task_human_audit):
        """审核员审核效率（每秒直接审核物料个数）
        return:     mean median
        """
        return self.auditor_efficiency(task_human_audit, aspect='first_level_trade')

    def auditor_efficiency_second_level_trade(self, task_human_audit):
        """审核员审核效率（每秒直接审核物料个数）
        return:     mean median
        """
        return self.auditor_efficiency(task_human_audit, aspect='second_level_trade')

    def auditor_efficiency_sale_system(self, task_human_audit):
        """审核员审核效率（每秒直接审核物料个数）
        return:     mean median
        """
        return self.auditor_efficiency(task_human_audit, aspect='sale_system')

    def auditor_efficiency_pid(self, task_human_audit):
        """审核员审核效率（每秒直接审核物料个数）
        return:     mean median
        """
        return self.auditor_efficiency(task_human_audit, aspect='pid')


    def auditor_mt_per_op(self, task_human_audit, aspect='first_level_trade'):
        """审核员一次性操作比例
        """
        if (task_human_audit.auditor_front not in self.auditor_data.keys() \
                or aspect not in self.auditor_data[task_human_audit.auditor_front].keys() \
                or getattr(task_human_audit, aspect) not in self.auditor_data[task_human_audit.auditor_front][aspect].keys()):
            return ["NULL", "NULL"]

        mean_efficiency = numpy.mean([float(i) for i in self.auditor_data[task_human_audit.auditor_front][aspect]
                                      [getattr(task_human_audit, aspect)]['mean_direct_mt_num_per_opt']])
        median_efficiency = numpy.median([float(i) for i in self.auditor_data[task_human_audit.auditor_front][aspect]
                                      [getattr(task_human_audit, aspect)]['median_direct_mt_num_per_opt']])
        return [f'{mean_efficiency:.4f}', f'{median_efficiency:.4f}']

    def auditor_mt_per_op_first_level_trade(self, task_human_audit):
        """审核员审核效率（每秒直接审核物料个数）
        return:     mean median
        """
        return self.auditor_mt_per_op(task_human_audit, aspect='first_level_trade')

    def auditor_mt_per_op_second_level_trade(self, task_human_audit):
        """审核员审核效率（每秒直接审核物料个数）
        return:     mean median
        """
        return self.auditor_mt_per_op(task_human_audit, aspect='second_level_trade')

    def auditor_mt_per_op_sale_system(self, task_human_audit):
        """审核员审核效率（每秒直接审核物料个数）
        return:     mean median
        """
        return self.auditor_mt_per_op(task_human_audit, aspect='sale_system')

    def auditor_mt_per_op_pid(self, task_human_audit):
        """审核员审核效率（每秒直接审核物料个数）
        return:     mean median
        """
        return self.auditor_mt_per_op(task_human_audit, aspect='pid')


    def get_auditor_feature(self, auditor, config_list):
        """根据auditor获取特征
        """
        auditor_feature = []
        for index in range(len(config_list)):
            auditor_feature.extend(getattr(self, config_list[index])(auditor))
        return auditor_feature


if __name__ == "__main__":
    cls = AuditorFeatureExtract(date='20210830', window_size=7)
    cls.init()
    pass


