#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   21/08/23 15:57:49
Desc  :   上下文特征
"""
import os
import sys
import datetime

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

import review_object.review_object as review_object
import conf

class ContextFeatureExtract(object):
    """上下文特征提取类
    """
    def __init__(self, date, window_size):
        """init
        """
        self.date = date
        self.window_size = window_size

    def init(self):
        """init
        """
        if not self.read_context_related_data():
            return False
        return True

    def read_context_related_data(self):
        """计算context维度特征所需的所有数据
        """
        return True

    def time_quantum(self, context):
        """时间段（0-24小时的时间段）
        """
        return str(datetime.datetime.fromtimestamp(int(context)).timetuple().tm_hour)

    def time_weekday(self, context):
        """一周中的哪天
        """
        return str(datetime.datetime.fromtimestamp(int(context)).weekday())

    def get_context_feature(self, context, config_list):
        """根据context time获取特征
        """
        context_feature = []
        for index in range(len(config_list)):
            context_feature.append(getattr(self, config_list[index])(context))
        return context_feature


if __name__ == "__main__":
    pass


