#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   21/08/11 17:33:26
Desc  :   
"""
import os
import sys

from review_object import BaseHumanAuditResult
from review_object import AdhumanAuditResult

tar_product = set([
    119, 310, 286, 238, 175, 250, 163, 156, 188, 187,
    340, 159, 257, 308, 309, 319, 160, 118, 334, 120,
    268, 318, 136, 113, 88, 89, 42, 40, 60, 87,
     61, 64, 96, 62, 28, 27, 41, 55, 57, 63,
     26, 59, 58,
     ])

if __name__ == "__main__":
    for eachline in sys.stdin:
        try:
            file_name = os.environ["mapreduce_map_input_file"] if "mapreduce_map_input_file" in \
                    os.environ else os.environ["map_input_file"]
            # 1. feed物料信息 2. 物料层级数据
            which_file = "1"
            if "dwd_mt_mtinfo_day" in file_name:
                which_file = "2"
        except:
            which_file = sys.argv[1]

        if which_file == "1":
            base_human_audit_obj = BaseHumanAuditResult(eachline.strip("\n").split("\t"))
            print "%s\t1\t%s" % (str(base_human_audit_obj.ad_id), eachline.strip("\n"))
        elif which_file == "2":
            ad_human_audit_obj = AdhumanAuditResult(eachline.strip("\n").split("\t"))
            if int(ad_human_audit_obj.pid) not in tar_product:
                continue
            print "%s\t2\t%s" % (ad_human_audit_obj.adid, eachline.decode("utf-8").encode("gb18030").strip("\n"))

