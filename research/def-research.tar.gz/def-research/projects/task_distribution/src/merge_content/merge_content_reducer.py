#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   21/08/13 14:55:15
Desc  :   
"""
import sys

from review_object import BaseHumanAuditResult

if __name__ == "__main__":
    old_adid = None
    append_cont = ""
    seq = "\x01"
    for eachline in sys.stdin:
        line = eachline.strip("\n").split("\t")
        adid = line[0]
        which_file = line[1]
        if which_file == "1":
            old_adid = adid
            base_human_audit_obj = BaseHumanAuditResult(line[2:])
            word = seq.join(base_human_audit_obj.word_list)
            idea = seq.join(base_human_audit_obj.idea_list)
            url = seq.join(base_human_audit_obj.url_list)
            pic = seq.join(base_human_audit_obj.pic_list)
            video = seq.join(base_human_audit_obj.video_list)
            append_cont = "\t".join([word, idea, url, pic, video])
        elif which_file == "2":
            if adid != old_adid:
                print "\t".join(["\t".join(line[2:]), "\t".join([""] * 5)])
            else:
                print "\t".join(["\t".join(line[2:]), append_cont])


