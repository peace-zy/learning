#!/usr/bin/env python3
#coding=UTF-8

#author:    liuxing07@baidu.com
#date:      2021-08-19

import os
import sys
import copy
import ast
import yaml

__all__ = []

_curpath = os.path.dirname(os.path.abspath(__file__))

class AttrDict(dict):
    def __getattr__(self, key):
        return self[key]

    def __setattr__(self, key, value):
        if key in self.__dict__:
            self.__dict__[key] = value
        else:
            self[key] = value

    def __deepcopy__(self, content):
        return copy.deepcopy(dict(self))


def create_attr_dict(yaml_config: AttrDict) -> AttrDict:
    for key, value in yaml_config.items():
        if isinstance(value, dict):
            yaml_config[key] = value = AttrDict(value)
        if isinstance(value, str):
            value = ast.literal_eval(value)
        if isinstance(value, AttrDict):
            create_attr_dict(value)
        else:
            yaml_config[key] = value


def parse_config(cfg_file: str) -> AttrDict:
    with open(cfg_file, 'r') as fin:
        yaml_config = AttrDict(yaml.load(fin, Loader=yaml.SafeLoader))
    create_attr_dict(yaml_config)
    return yaml_config

if __name__ == '__main__':
    pass
else:
    print(f'import module [{os.path.join(_curpath, __name__)}] successfully!')
