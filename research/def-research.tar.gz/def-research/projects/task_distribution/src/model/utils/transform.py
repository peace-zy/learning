#!/usr/bin/env python3
#coding=utf-8

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os
import ast
import numpy


_curpath = os.path.dirname(os.path.abspath(__file__))

class OperatorParamError(ValueError):
    pass

class ExpandDim(object):
    """
    ExpandDim class
    """
    def __init__(self, at_begin=True):
        self.at_begin = at_begin
        if self.at_begin:
            self.dim_position = 0
        else:
            self.dim_position = -1

    def __call__(self, numpy_array):
        return numpy.expand_dims(numpy_array, axis=self.dim_position)


class SqueezeDim(object):
    """
    SqueezeDim class
    """
    def __init__(self, at_begin=True):
        self.at_begin = at_begin
        if self.at_begin:
            self.dim_position = 0
        else:
            self.dim_position = -1

    def __call__(self, numpy_array):
        return numpy.squeeze(numpy_array, axis=self.dim_position)

class Normlize(object):
    """
    Normlization for numpy data
    """
    def __init__(self, scale=None, mean=None, std=None):
        if isinstance(scale, str):
            scale = ast.literal_eval(scale)
        self.scale = numpy.float32(1. / scale if scale is not None else 1 / 255.)
        self.mean = numpy.array(mean if mean is not None else 0, dtype=numpy.float32)
        self.std = numpy.float32(std if std is not None else 1)

    def __call__(self, numpy_data):
        if not isinstance(numpy_data, numpy.ndarray):
            numpy_data = numpy.array(numpy_data)
        return (numpy_data.astype('float32') * self.scale - self.mean) / self.std

class NumpyConcatenate(object):
    """
    operator concatenate for numpy data

    Examples:
    >>    a = np.array([[1, 2], [3, 4]])
    >>    b = np.array([[5, 6]])
    >>    np.concatenate((a, b), axis=0)
    array([[1, 2],
           [3, 4],
           [5, 6]])
    >>    np.concatenate((a, b.T), axis=1)
    array([[1, 2, 5],
           [3, 4, 6]])
    >>    np.concatenate((a, b), axis=None)
    array([1, 2, 3, 4, 5, 6])
    """
    def __call__(self, numpy_datas, axis=1):
        """
        numpy_datas:    list,tuple of numpy data
        """
        return numpy.concatenate(numpy_datas, axis=axis)

class NumpyStack(object):
    """
    numpy stack
    """
    def __call__(self, numpy_datas, axis=0):
        """
        numpy_datas:    list,tuple of numpy data
        """
        return numpy.stack(numpy_datas, axis=axis)


if __name__ == '__main__':
    pass
else:
    print(f'import module [{os.path.join(_curpath, __name__)}] sucessfully!')
