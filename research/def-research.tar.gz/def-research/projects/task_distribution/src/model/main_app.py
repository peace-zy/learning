#!/usr/bin/env python3
#coding=UTF-8

#author:    liuxing07@baidu.com
#date:      2021-08-17

from __future__ import absolute_import
from __future__ import print_function

import os
import sys
import sklearn.model_selection

_curpath = os.path.dirname(os.path.abspath(__file__))
sys.path.append(_curpath)

from arch import LR
from data import dataset_audit_time
from train import sklearn_train
from utils import args
from utils import config

def main() -> None:
    param_str = '--arch Lasso \
                 --train_data_dir data/train_data/train.txt \
                 --eval_data_dir data/eval_data/eval.txt \
                 --fea_mapfile_path data/config_data \
                 --train_ratio 0.8 \
                 --seed 1 \
                 --shuffle \
                 --output_path output \
                 '
    opt = args.Opt().parse(param_str)

    arch = LR.LR(opt.arch).arch()
    train_dataset = dataset_audit_time.DatasetAuditTime(data_dir=opt.train_data_dir,
                                                        fea_mapfile_path=opt.fea_mapfile_path,
                                                        mode='train')
    print(train_dataset)
    #Xtrain, Ytrain = train_dataset.get_data()

    Xtrain, Xtest, Ytrain, Ytest = sklearn.model_selection.train_test_split(*train_dataset.get_data(),
                                                                            train_size=opt.train_ratio,
                                                                            shuffle=opt.shuffle,
                                                                            random_state=opt.seed)

    trainer = sklearn_train.SklearnTrain(arch)
    if not trainer.init(opt):
        print(f'trainer init failed!')
        return False
    if not trainer.train(Xtrain, Ytrain):
        print(f'trainer training process failed!')
        return False

    trainer.val(Xtest, Ytest)

    eval_dataset = dataset_audit_time.DatasetAuditTime(data_dir=opt.eval_data_dir,
                                                       fea_mapfile_path=opt.fea_mapfile_path, mode='eval')
    print(eval_dataset)
    XXtest, YYtest = eval_dataset.get_data()
    print('#' * 100)
    print('custom validation')
    trainer.custom_val(XXtest, YYtest)
    print('#' * 100)
    print('model prediction validation')
    trainer.val(XXtest, YYtest)


    pass

if __name__ == '__main__':
    main()
else:
    print(f'import module [{os.path.join(_curpath, __name__)}] successfully!')

