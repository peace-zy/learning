#!/usr/bin/env python3
#coding=utf-8

#author:    liuxing07@baidu.com

"""
Inference过程基类
"""

import os
import sys
import abc

_curpath = os.path.dirname(os.path.abspath(__file__))

class BaseInfer(object):
    """
    inference 基类
    """
    @abc.abstractmethod
    def init(self, opt):
        """
        init model context
        """
        return True

    @abc.abstractmethod
    def preprocess(self):
        """
        preprocess for model process
        """
        return True

    @abc.abstractmethod
    def inference(self):
        """
        inference process
        """
        return True

    @abc.abstractmethod
    def postprocess(self):
        """
        postprocess for model result
        """
        return True

