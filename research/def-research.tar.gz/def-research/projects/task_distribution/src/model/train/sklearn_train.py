#!/usr/bin/env python3
#coding=utf-8

#author:    liuxing07@baidu.com

import os
import sys
import traceback
import time
import numpy
import collections

import sklearn.metrics

_curpath = os.path.dirname(os.path.abspath(__file__))
sys.path.append(_curpath)
from base_train import BaseTrain


class SklearnTrain(BaseTrain):
    """
    scikit-learn model training function
    """
    def __init__(self, arch_model):
        super().__init__()
        self.arch_model = arch_model

    def __clear__(self):
        self.MAE = float('inf')
        self.MSE = float('inf')
        self.R2_score = float('-inf')

    def init(self, opt=None):
        if 'output_name' not in opt or opt.output_name is None:
            self.output_name = time.strftime('%Y%m%d')
        else:
            self.output_name = opt.output_name

        self.output_path = os.path.join(os.path.abspath(opt.output_path), self.output_name)
        os.makedirs(self.output_path, exist_ok=True)

        return True

    def train(self, Xtrain, Ytrain):
        try:
            self.arch_model.fit(Xtrain, Ytrain)
            print(f'Weight: [{self.arch_model.coef_}]')
            print(f'Weight shape: [{self.arch_model.coef_.shape}]')
            print(f'Intercept: [{self.arch_model.intercept_}]')
            print(f'iterations: [{self.arch_model.n_iter_}]')
            print(f'dual_gap: [{self.arch_model.dual_gap_}]')
            numpy.save(os.path.join(self.output_path, 'LR_weight.npy'), self.arch_model.coef_)

        except Exception as e:
            print(traceback.format_exc())
            return False
        return True

    def val(self, Xtest, Ytest):
        self.__clear__()
        Ypredict = self.arch_model.predict(Xtest)
        MAE = sklearn.metrics.mean_absolute_error(Ytest, Ypredict)
        MSE = sklearn.metrics.mean_squared_error(Ytest, Ypredict)
        R2_score = sklearn.metrics.r2_score(Ytest, Ypredict)
        self.MAE = min(MAE, self.MAE)
        self.MSE = min(MSE, self.MSE)
        self.R2_score = max(R2_score, self.R2_score)
        print(f'MAE: [{self.MAE:.4f}]')
        print(f'MSE: [{self.MSE:.4f}]')
        print(f'R2_score: [{self.R2_score:.4f}]')

    def custom_val(self, Xtest, Ytest):
        # Xtest, Ytest分为几个子部分
        # 1、traide=0的异常部分
        # 2、direct_mt > 50的部分（训练过程剔除的部分）
        # 3、正常部分，模型加载预测
        assert Xtest.shape[0] == Ytest.shape[0]

        eval_dict = collections.defaultdict(list)

        direct_mt_index = 1
        first_tradeid_index = 2
        median_efficiency = -7

        direct_mt_lt50_mask = Xtest[:, direct_mt_index] > 50
        tradeid_equal0_mask = Xtest[:, first_tradeid_index] == 0

        X_abnormal_mask = direct_mt_lt50_mask | tradeid_equal0_mask
        X_normal_mask = numpy.logical_not(X_abnormal_mask)

        X_normal = Xtest[X_normal_mask, :]
        Y_normal = Ytest[X_normal_mask]
        X_normal_predict = self.arch_model.predict(X_normal)
        eval_dict['MAE'].append(sklearn.metrics.mean_absolute_error(Y_normal, X_normal_predict))
        eval_dict['MSE'].append(sklearn.metrics.mean_squared_error(Y_normal, X_normal_predict))
        eval_dict['r2_score'].append(sklearn.metrics.r2_score(Y_normal, X_normal_predict))

        X_abnormal = Xtest[X_abnormal_mask, :]
        Y_abnormal = Ytest[X_abnormal_mask]
        #X_abnormal_predict = numpy.ones_like(Y_abnormal)
        X_abnormal_predict = (X_abnormal[:, direct_mt_index] / numpy.where(X_abnormal[:, median_efficiency] < 20,
                                                                           X_abnormal[:, median_efficiency], 20))
        eval_dict['MAE'].append(sklearn.metrics.mean_absolute_error(Y_abnormal, X_abnormal_predict))
        eval_dict['MSE'].append(sklearn.metrics.mean_squared_error(Y_abnormal, X_abnormal_predict))
        eval_dict['r2_score'].append(sklearn.metrics.r2_score(Y_abnormal, X_abnormal_predict))

        for key, value in eval_dict.items():
            print(f'{key}:\t [{numpy.mean(value):.4f}]')



