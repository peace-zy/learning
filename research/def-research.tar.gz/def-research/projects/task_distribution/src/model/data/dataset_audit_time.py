#!/usr/bin/env python3
"""
author:        liuxing07@baidu.com
"""
#coding=utf-8

from __future__ import absolute_import
from __future__ import print_function

import os
import sys

import numpy
import collections
import tqdm

_curpath = os.path.dirname(os.path.abspath(__file__))
if _curpath not in sys.path:
    sys.path.append(_curpath)
from dataset import Dataset

sys.path.append(os.path.join(_curpath, '..'))
from utils import transform

class DatasetAuditTime(Dataset):
    """
    预估审核时长类
    """
    feature_map_file = {'first_trade': 'meg_first_trade.txt',
                        'second_trade': 'meg_second_trade.txt',
                        'pid':  None,
                        'sale_system': 'sale_system.txt'}

    def __init__(self, data_dir, fea_mapfile_path, mode='train'):
        super(DatasetAuditTime, self).__init__(data_dir=data_dir, mode=mode)
        self.fea_mapfile_path = os.path.abspath(fea_mapfile_path)

        self.fea_mapsets = collections.defaultdict(list)
        for fea_name, map_file in self.feature_map_file.items():
            if map_file is None:
                continue
            self.fea_mapsets[fea_name].extend([line.strip()
                                     for line in open(os.path.join(self.fea_mapfile_path, map_file)).readlines()])
        self.targets = []


    @staticmethod
    def onehot(value, value_set):
        """
        param
            value:  给定特征的某一个值
            value_set:  给定特征取值的所有集合
        return
            one hot vector
        """
        return numpy.array(numpy.array(value_set, dtype=numpy.unicode) == value).astype(int)

    def __read__(self):
        annotation_info = []
        for anno_file in self.anno_txt:
            for line in open(anno_file).readlines():
                if 'NULL' in line:
                    continue

                anno_info_list = line.strip().split('\t')
                if self.mode == 'train':
                    if int(anno_info_list[1]) < 1 \
                        or int(anno_info_list[1]) > 50 \
                        or int(anno_info_list[-1]) > 50:
                        continue
                    if numpy.any(numpy.array(anno_info_list[5:-1], dtype=float) > 20.):
                        continue

                annotation_info.append(line.strip())
        return annotation_info

    def fea2vec(self, anno_info):
        """
        物料量 直接审核量 一级行业 二级行业 销售体系 pid 一次性操作比例 小时段 周几  目标值
        """
        anno_info_list = anno_info.split('\t')

        #material = transform.Normlize(scale=100)(min(100, int(anno_info_list[0])))
        material = int(anno_info_list[0])
        direct_material = int(anno_info_list[1])
        first_trade = self.onehot(anno_info_list[2], self.fea_mapsets['first_trade'])
        second_trade = self.onehot(anno_info_list[3], self.fea_mapsets['second_trade'])
        sale_system = self.onehot(anno_info_list[4], self.fea_mapsets['sale_system'])

        target = int(anno_info_list.pop())
        self.targets.append(target)

        vec_list = [
            material,
            direct_material,
#            first_trade,
#            second_trade,
#            sale_system,
        ]
        vec_list = vec_list + [float(i) for i in anno_info_list[5:]]

        return transform.NumpyConcatenate()(vec_list, axis=None)

    def data_transform(self):
        """
        process of data
        """
        anno_info_vecs = [self.fea2vec(item) for item in tqdm.tqdm(self.annotation)]
        return transform.NumpyStack()(anno_info_vecs, axis=0)

    def target_transform(self):
        """
        process of target data
        """
        target = numpy.array(self.targets, dtype=numpy.float32)
        return target
        #return transform.Normlize(scale=max(self.targets))(target)


def main():
    """
    main function
    """
    param = {'data_dir': sys.argv[1], #'data/origin_data/20210818.txt',
             'fea_mapfile_path': os.path.join(_curpath, '../data/config_data')}
    dataset_audit_time = DatasetAuditTime(**param)
    print(dataset_audit_time)
    print(dataset_audit_time.get_data())
    print(dataset_audit_time.data_transform().shape)
    print(dataset_audit_time.target_transform().shape)

if __name__ == '__main__':
    main()
