#!/usr/bin/env python3
#coding=utf-8

#author:    liuxing07@baidu.com

import os
import sys

import sklearn.linear_model

_curpath = os.path.dirname(os.path.abspath(__file__))
sys.path.append(_curpath)
import base_arch

arch_model = {'LinearReg': None,
              'Ridge': {'alpha': 0.5},
              'Lasso': {'alpha': 0.1, 'warm_start': True, 'max_iter': 100000},
              'ElasticNet': {'alpha': 0.5, 'l1_ratio': 0.5}}

class LR(base_arch.BaseArch):
    """
    LR model defination
    """
    def __init__(self, archname: str):
        super().__init__()
        self.arch_name = archname
        self.arch_params = arch_model[self.arch_name]

    def __model__(self):
        return sklearn.linear_model.__dict__[self.arch_name](**self.arch_params)

    def arch(self):
        return self.__model__()

if __name__ == '__main__':
    pass
else:
    print(f'import module [{os.path.join(_curpath, __name__)}] successfully!')

