#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   audit_time_stat.py
Author:   zhanghao55@baidu.com
Date  :   21/08/17 18:31:08
Desc  :   
"""

import os
import sys
import codecs
import collections
import copy
import decimal
import logging

from datetime import datetime, timedelta
from tqdm import tqdm

import conf
from review_object import review_object
from utils import time_stat
from utils.stat_info import StatInfo

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../../" % _cur_dir)
from lib.common.logger import init_log
init_log()

decimal.getcontext().rounding = "ROUND_HALF_UP"

FIRST_WRITE = True

def load_data(file_path, record_obj):
    """加载日志通用函数
    """
    # codecs.open 遇到一行里有特殊字符 例如"\x1c"会忽略掉该字符后的内容 导致加载数据出错
    with open(file_path, mode="r", encoding="utf-8") as rf:
        for index, line in tqdm(enumerate(rf)):
            parts = line.strip("\n").split("\t")
            try:
                cur_obj = record_obj(parts)
            except Exception as e:
                logging.info("wrong line #{} at file: {}".format(index + 1, file_path))
                raise e
            if conf.sale_system_scope is not None and cur_obj.sale_system not in conf.sale_system_scope:
                continue
            if conf.pid_scope is not None and cur_obj.pid not in conf.pid_scope:
                continue
            yield cur_obj


def decimal_round(number):
    """用decimal进行取整 python自带的round精度不够
    """
    return int(decimal.Decimal(str(number)).quantize(decimal.Decimal("1.")))


class SimulationIn(object):
    """实验模拟类
    """
    @classmethod
    def load_from_file(cls, file_path, max_num=None):
        """加载
        """
        in_num_dict = collections.defaultdict(int)
        dist_num_dict = collections.defaultdict(int)
        audit_start_num_dict = collections.defaultdict(int)
        audit_end_num_dict = collections.defaultdict(int)

        mt_iter = load_data(input_path, review_object.AdHumanAuditResult)
        for index, cur_mt in enumerate(mt_iter):
            # 只计算直接审核的物料
            if cur_mt.audit_type2 != "1":
                continue
            # 直接用各字段作为时间点 结果部分字段时间有问题
            # 现改为以入审时间为准 其他时间点用后几位推算出来
            cur_ad_begin_time   = int(cur_mt.ad_begin_time)
            cur_tobeassign_time = int(cur_mt.tobeassign_time)
            cur_tobeaudit_time  = int(cur_mt.tobeaudit_time)
            cur_audit_time      = int(cur_mt.audit_total_time)

            # 耗时小于0 说明数据有误
            if cur_tobeassign_time < 0 \
                    or cur_tobeaudit_time < 0 \
                    or cur_audit_time < 0:
                continue

            cur_ad_distri_time = cur_ad_begin_time + cur_tobeassign_time
            cur_audit_start_time = cur_ad_distri_time + cur_tobeaudit_time
            cur_audit_end_time = cur_audit_start_time + cur_audit_time
            
            in_num_dict[datetime.fromtimestamp(cur_ad_begin_time)] += 1
            dist_num_dict[datetime.fromtimestamp(cur_ad_distri_time)] += 1
            audit_start_num_dict[datetime.fromtimestamp(cur_audit_start_time)] += 1
            audit_end_num_dict[datetime.fromtimestamp(cur_audit_end_time)] += 1
            
            if max_num is not None and index > max_num - 1:
                break
        
        return cls(
            phase_list=["in", "dist", "audit_start", "audit_end"],
            phase_dict={
                "in": in_num_dict,
                "dist": dist_num_dict,
                "audit_start": audit_start_num_dict,
                "audit_end": audit_end_num_dict,
            }

        )

    def __init__(self, phase_list, phase_dict=None):
        self.phase_list = phase_list
        self.phase_index_dict = {v: k for k, v in enumerate(self.phase_list)}

        self.phase_dict = dict() if phase_dict is None else phase_dict

        for cur_phase in phase_list:
            if cur_phase not in self.phase_dict:
                self.phase_dict[cur_phase] = dict()
    
    def gen_time_list(self):
        """生成各阶段的time_list
        """
        res_dict = dict()
        for cur_phase in self.phase_list:
            res_dict[cur_phase] = [(datetime.timestamp(k), v) for k, v in self.phase_dict[cur_phase].items()]
        return res_dict
    
    def once_in(self, phase, in_num, time, need_check=True):
        """设置一次进入量
        """
        if isinstance(time, str):
            time = datetime.strptime(time, "%Y-%m-%d %H:%M:%S")
        if time not in self.phase_dict[phase]:
            self.phase_dict[phase][time] = 0
        self.phase_dict[phase][time] += in_num
        if need_check:
            self.check(phase)
    
    def multiple_in(self, phase, multiple_num, need_check=True):
        """对某阶段的进入量进行缩放
        """
        logging.info("multiple phase: {}".format(phase))
        for cur_time, cur_num in self.phase_dict[phase].items():
            self.phase_dict[phase][cur_time] = decimal_round(multiple_num * cur_num)
        if need_check:
            self.check(phase)
    
    def check(self, phase):
        """确认指定阶段的进入量合理 即该阶段截止到任一时间的总进入量都需要小于等于前一阶段的总进入量
        """
        cur_phase_index = self.phase_index_dict[phase]
        # 第一阶段的进入量没有约束 不用检查
        if cur_phase_index == 0:
            return 

        # 有前序阶段
        prev_phase = self.phase_list[cur_phase_index - 1]
        #logging.info("prev phase: {}".format(prev_phase))
        # 前序阶段的各时间点进入量 时间点按时间先后逆序排 方便之后pop
        prev_phase_time_list = sorted(self.phase_dict[prev_phase].items(), reverse=True)

        #logging.info("in_num at 0: {}".format(self.phase_dict["in"][datetime.strptime("2021-09-05 00:00:00", "%Y-%m-%d %H:%M:%S")]))

        # 当前阶段的时间点进入量
        cur_phase_time_list = sorted(self.phase_dict[phase].items(), reverse=True)

        # 从起始时间开始 设置每秒的进入量
        # 该阶段截止到任一时间的总进入量都需要小于等于前一阶段的总进入量
        prev_stack_num = 0

        # 总共调整少了多少物料
        mod_num = 0

        while len(cur_phase_time_list) > 0:
            cur_time, cur_num = cur_phase_time_list.pop()

            # 更新前一个阶段到该时刻的进审量 前一阶段的需要小于等于该时刻
            # 该时刻前一阶段的进入量 在本时刻也能到该阶段 此时说明该物料在该阶段没有停留
            while len(prev_phase_time_list) > 0 and prev_phase_time_list[-1][0] <= cur_time:
                prev_time, prev_num = prev_phase_time_list.pop()
                prev_stack_num += prev_num
                #logging.info("cur time: {}, in_num: {}, stack_num: {}".format(prev_time, prev_num, prev_stack_num))
            
            # 确认当前时刻该阶段的进审量
            cur_real_num = min(prev_stack_num, cur_num)
            if cur_real_num != cur_num:
                #logging.debug("cur_phase: {}, time: {}, prev_stack_num = {}, cur_num = {}, real_num = {}".format(
                #    phase,
                #    cur_time,
                #    prev_stack_num,
                #    cur_num,
                #    cur_real_num,
                #    ))
                mod_num += cur_num - cur_real_num
            # 这里直接覆盖该事件的值 而不是累加
            self.phase_dict[phase][cur_time] = cur_real_num

            # 更新前一阶段的堆积量
            prev_stack_num -= cur_real_num
        
        #logging.debug("cur_phase: {}, mod_num = {}".format(
        #    phase,
        #    mod_num,
        #    ))
        
        # 如果该阶段不是最后一个阶段 则调整后 需要保证下一个阶段也没问题
        if cur_phase_index != len(self.phase_list) - 1:
            self.check(self.phase_list[cur_phase_index + 1])
    
    def specified_num_in(self, phase, in_speed, total_in_num, start_time=None, time_delta=None):
        """指定该阶段要增加的物料数 每秒增加的量 起始时间 
           修改该阶段的进入量
        """
        cur_phase_index = self.phase_index_dict[phase]
        in_speed = decimal_round(in_speed)

        real_in_num = 0
        end_time = None

        if time_delta is None:
            time_delta = timedelta(seconds=1)

        if cur_phase_index == 0:
            assert start_time is not None, \
                "start_time is required when set specified_num_in at first phase"
            assert total_in_num is not None, \
                "total_in_num is required when set specified_num_in at first phase"
            if isinstance(start_time, str):
                end_time = datetime.strptime(start_time, "%Y-%m-%d %H:%M:%S")
            while real_in_num < total_in_num:
                if end_time not in self.phase_dict[phase]:
                    self.phase_dict[phase][end_time] = 0
                self.phase_dict[phase][end_time] += in_speed
                end_time += time_delta
        else:
            # 有前序阶段
            prev_phase = self.phase_list[cur_phase_index - 1]
            # 前序阶段的各时间点进入量 时间点按时间先后逆序排 方便之后pop
            prev_phase_time_list = sorted(self.phase_dict[prev_phase].items(), reverse=True)
            # 如果无起始时间 则默认其一直等待
            if start_time is None:
                # 前序阶段开始后的一秒 开始有进入量
                start_time = prev_phase_time_list[-1][0] + timedelta(seconds=1)
            elif isinstance(start_time, str):
                start_time = datetime.strptime(start_time, "%Y-%m-%d %H:%M:%S")
        
            # 从起始时间开始 设置每秒的进入量
            # 该阶段截止到任一时间的总进入量都需要小于等于前一阶段的总进入量
            prev_stack_num = 0
            end_time = start_time
            # 循环 直到
            # 1. 达到指定要增加的量
            # 2. 上一阶段进入的量已消耗完
            while real_in_num < total_in_num and (len(prev_phase_time_list) > 0 or prev_stack_num > 0):
                #logging.info("real_in_num = {}, prev stack num : {}".format(real_in_num, prev_stack_num))
                # 更新前一个阶段到该时刻的进审量 前一阶段的需要小于该时刻
                # 该时刻前一阶段的进入量 至少在下一时刻才能到该阶段
                while len(prev_phase_time_list) > 0 and prev_phase_time_list[-1][0] < end_time:
                    _, cur_num = prev_phase_time_list.pop()
                    prev_stack_num += cur_num

                # 获得本来该时间的进入量
                origin_in_num = self.phase_dict[phase].get(end_time, 0)

                # 在可增加进审量、最大流速和剩余要增加的量三个数之间取最小值 作为该秒要增加的流速
                cur_in_num = min(prev_stack_num - origin_in_num, in_speed, total_in_num)
                # 该值不能为负数
                assert cur_in_num >= 0
                # 当前秒要增加的流速cur_in_num 在原先的基础上增加
                self.phase_dict[phase][end_time] = cur_in_num + origin_in_num
                # 更新要增加的物料总量
                real_in_num += cur_in_num
                # 下一秒
                end_time += time_delta
        
        logging.info("real_in_num = {}, start_time: {}, end_time: {}".format(
            real_in_num,
            start_time.strftime("%Y-%m-%d %H:%M:%S"),
            end_time.strftime("%Y-%m-%d %H:%M:%S"),
            ))
        return real_in_num, end_time

    def continuous_in(self, phase, in_speed, start_time, end_time, time_delta=None, need_check=True):
        """持续进物料
        """
        if time_delta is None:
            time_delta = timedelta(seconds=1)

        if isinstance(start_time, str):
            start_time = datetime.strptime(start_time, "%Y-%m-%d %H:%M:%S")
        if isinstance(end_time, str):
            end_time = datetime.strptime(end_time, "%Y-%m-%d %H:%M:%S")
        cur_time = start_time
        while cur_time <= end_time:
            if cur_time not in self.phase_dict[phase]:
                self.phase_dict[phase][cur_time] = 0
            self.phase_dict[phase][cur_time] += in_speed
            cur_time += time_delta
        
        if need_check:
            self.check(phase)


def stat(cur_simu, output_path=None, sheet_name=None, start_day=None):
    """根据指定的实验参数进行模拟
    """
    global FIRST_WRITE
    #logging.info("test: {}".format(sheet_name))

    stat_dict = time_stat.time_stat(cur_simu.gen_time_list(), phase_list=["in", "audit_start", "audit_end"]) 

    start_time = stat_dict["start_time"]
    end_time = stat_dict["end_time"]
    total_num_dict = stat_dict["total_num_dict"]
    stack_num_dict = stat_dict["stack_num_dict"]
    stack_time_dict = stat_dict["stack_time_dict"]
    stack_trend_dict = stat_dict["stack_trend_dict"]
    accumulate_num_dict = stat_dict["accumulate_num_dict"]

    total_in_num = "{:.0f}".format(total_num_dict["in"])
    total_audit_start_num = "{:.0f}".format(total_num_dict["audit_start"])
    mean_tobeaudit_time = "{:.4f}".format(stack_time_dict["in"] / float(total_num_dict["in"]))
    mean_audit_time = "{:.4f}".format(stack_time_dict["audit_start"] / float(total_num_dict["audit_start"]))

    #logging.info("total in num = {}".format(total_in_num))
    #logging.info("total audit start num = {}".format(total_audit_start_num))
    #logging.info("mean tobeaudit time = {}".format(mean_tobeaudit_time))
    #logging.info("mean audit time = {}".format(mean_audit_time))

    stat_list = [
        sheet_name, 
        total_in_num,
        total_audit_start_num,
        mean_tobeaudit_time,
        mean_audit_time,
    ]
    for cur_phase, cur_num in stack_num_dict.items():
        stat_list.append(str(cur_num))
        #logging.info("phase {} stack num = {}".format(cur_phase, cur_num))
    
    logging.info("\t".join(stat_list))

    if output_path is not None:
        # 打印各阶段的进审出审
        simu_stat = StatInfo(stat_attr_list=[
            "time",
            "in_num",
            "out_num",
            "end_num",
            "accumulate_in_num",
            "accumulate_out_num",
            "accumulate_end_num",
            "stack_in_num",
            "stack_out_num",
            "stack_end_num",
        ], key_num=1)

        cur_time = start_time
        if start_day is not None and start_day > start_time:
            cur_time = start_day

        while cur_time <= end_time:
            cur_stat = simu_stat[cur_time.strftime("%Y-%m-%d %H:%M:%S")]
            cur_stat["in_num"]             = str(cur_simu.phase_dict["in"].get(cur_time, 0))
            cur_stat["out_num"]            = str(cur_simu.phase_dict["audit_start"].get(cur_time, 0))
            cur_stat["end_num"]            = str(cur_simu.phase_dict["audit_end"].get(cur_time, 0))
            cur_stat["accumulate_in_num"]  = str(accumulate_num_dict["in"][cur_time])
            cur_stat["accumulate_out_num"] = str(accumulate_num_dict["audit_start"][cur_time])
            cur_stat["accumulate_end_num"] = str(accumulate_num_dict["audit_end"][cur_time])
            cur_stat["stack_in_num"]       = str(stack_trend_dict["in"][cur_time])
            cur_stat["stack_out_num"]      = str(stack_trend_dict["audit_start"][cur_time])
            cur_stat["stack_end_num"]      = str(stack_trend_dict["audit_end"][cur_time])

            cur_time += timedelta(seconds=1)
    
        mode = "w" if FIRST_WRITE else "a"
        FIRST_WRITE = False

        simu_stat.to_excel(
            output_path,
            sheet_name="{}_time_stat".format(sheet_name),
            mode=mode,
            )

        simu_stat = StatInfo(stat_attr_list=[
            "attr",
            "value",
        ], key_num=1)
    
        simu_stat["total in num"]["value"] = total_in_num
        simu_stat["total audit_start num"]["value"] = total_audit_start_num
        simu_stat["mean tobeaudit time"]["value"] = mean_tobeaudit_time
        simu_stat["mean audit time"]["value"] = mean_audit_time

        for cur_phase, cur_num in stack_num_dict.items():
            simu_stat["phase {} stack num".format(cur_phase)]["value"] = str(cur_num)

        simu_stat.to_excel(
            output_path,
            sheet_name="{}_audit_time".format(sheet_name),
            mode="a",
            )
    
    return total_num_dict, stack_time_dict
    

def efficiency_change(ori_simu_parmas, output_path, start_day):
    """审核员效率提升对耗时的影响
    """
    # test 0
    cur_simu = SimulationIn(**copy.deepcopy(ori_simu_parmas))
    stat(
        cur_simu=cur_simu,
        output_path=output_path,
        sheet_name="baseline",
        start_day=start_day,
        )

    # test 1
    cur_simu = SimulationIn(**copy.deepcopy(ori_simu_parmas))
    # 0点 加大进审量
    cur_simu.once_in("in", 10000, "2021-09-05 00:00:00")
    stat(
        cur_simu=cur_simu,
        output_path=output_path,
        sheet_name="add_in",
        start_day=start_day,
        )

    # test 2
    cur_simu = SimulationIn(**copy.deepcopy(ori_simu_parmas))
    # 0点 加大进审量
    cur_simu.once_in("in", 10000, "2021-09-05 00:00:00")
    # 流速提升
    cur_simu.multiple_in("audit_start", 1.2)
    stat(
        cur_simu=cur_simu,
        output_path=output_path,
        sheet_name="add_in_eff1.2",
        start_day=start_day,
    )

    # test 3
    cur_simu = SimulationIn(**copy.deepcopy(ori_simu_parmas))
    # 0点 加大进审量
    cur_simu.once_in("in", 10000, "2021-09-05 00:00:00")
    # 流速提升
    cur_simu.multiple_in("audit_start", 1.5)
    stat(
        cur_simu=cur_simu,
        output_path=output_path,
        sheet_name="add_in_eff1.5",
        start_day=start_day,
    )

    # test 4
    cur_simu = SimulationIn(**copy.deepcopy(ori_simu_parmas))
    # 0点 加大进审量
    cur_simu.once_in("in", 10000, "2021-09-05 00:00:00")
    # 流速提升
    cur_simu.multiple_in("audit_start", 2)
    stat(
        cur_simu=cur_simu,
        output_path=output_path,
        sheet_name="add_in_eff2",
        start_day=start_day,
        )

    # test 5
    cur_simu = SimulationIn(**copy.deepcopy(ori_simu_parmas))
    # 0点 加大进审量
    cur_simu.once_in("in", 10000, "2021-09-05 00:00:00")
    # 流速提升
    cur_simu.multiple_in("audit_start", 3)
    stat(
        cur_simu=cur_simu,
        output_path=output_path,
        sheet_name="add_in_eff3",
        start_day=start_day,
        )

    # test 6
    cur_simu = SimulationIn(**copy.deepcopy(ori_simu_parmas))
    # 0点 加大进审量
    cur_simu.once_in("in", 10000, "2021-09-05 00:00:00")
    # 流速提升
    cur_simu.multiple_in("audit_start", 5)
    stat(
        cur_simu=cur_simu,
        output_path=output_path,
        sheet_name="add_in_eff5",
        start_day=start_day,
        )


def in_time_change(ori_simu_parmas, output_path, start_day):
    """不同时间增长物料对耗时的影响
    """
    # test 0
    cur_simu = SimulationIn(**copy.deepcopy(ori_simu_parmas))
    # 流速提升
    cur_simu.multiple_in("audit_start", 1.2)
    stat(
        cur_simu=cur_simu,
        output_path=output_path,
        sheet_name="baseline",
        start_day=start_day,
        )

    # test 1
    cur_simu = SimulationIn(**copy.deepcopy(ori_simu_parmas))
    # 0点 加大进审量
    cur_simu.once_in("in", 10000, "2021-09-05 00:00:00")
    # 流速提升
    cur_simu.multiple_in("audit_start", 1.2)
    stat(
        cur_simu=cur_simu,
        output_path=output_path,
        sheet_name="add_in_at_0",
        start_day=start_day,
    )

    # test 2
    cur_simu = SimulationIn(**copy.deepcopy(ori_simu_parmas))
    # 5点 加大进审量
    cur_simu.once_in("in", 10000, "2021-09-05 05:00:00")
    # 流速提升
    cur_simu.multiple_in("audit_start", 1.2)
    stat(
        cur_simu=cur_simu,
        output_path=output_path,
        sheet_name="add_in_at_5",
        start_day=start_day,
    )

    # test 3
    cur_simu = SimulationIn(**copy.deepcopy(ori_simu_parmas))
    # 10点 加大进审量
    cur_simu.once_in("in", 10000, "2021-09-05 10:00:00")
    # 流速提升
    cur_simu.multiple_in("audit_start", 1.2)
    stat(
        cur_simu=cur_simu,
        output_path=output_path,
        sheet_name="add_in_at_10",
        start_day=start_day,
    )

    # test 4
    cur_simu = SimulationIn(**copy.deepcopy(ori_simu_parmas))
    # 15点 加大进审量
    cur_simu.once_in("in", 10000, "2021-09-05 15:00:00")
    # 流速提升
    cur_simu.multiple_in("audit_start", 1.2)
    stat(
        cur_simu=cur_simu,
        output_path=output_path,
        sheet_name="add_in_at_15",
        start_day=start_day,
    )

    # test 5
    cur_simu = SimulationIn(**copy.deepcopy(ori_simu_parmas))
    # 20点 加大进审量
    cur_simu.once_in("in", 10000, "2021-09-05 20:00:00")
    # 流速提升
    cur_simu.multiple_in("audit_start", 1.2)
    stat(
        cur_simu=cur_simu,
        output_path=output_path,
        sheet_name="add_in_at_20",
        start_day=start_day,
    )


def add_auditor(ori_simu_parmas, output_path_prefix, start_day):
    """增加物料后 不同时间增加审核员对耗时的影响
    """
    # 增加物料量
    add_num = 2000
    # 每人每秒审核物料数
    auditor_real_efficiency = 0.0903

    def impl(add_num, add_hour, add_auditor_num, start_hour, work_hour):
        """执行实验
        """
        cur_simu = SimulationIn(**copy.deepcopy(ori_simu_parmas))
        add_time = start_day + timedelta(hours=add_hour)
        start_start_time = start_day + timedelta(hours=start_hour)
        start_end_time = start_day + timedelta(hours=start_hour + work_hour)
        # 审核阶段平均耗时18.9575 所以这里设置多出来的人 每个物料审核耗时约19秒
        end_start_time = start_day + timedelta(hours=start_hour, seconds=19)
        end_end_time = start_day + timedelta(hours=start_hour + work_hour, seconds=19)

        cur_simu.once_in("in", add_num, add_time)
        cur_simu.continuous_in(
            phase="audit_start",
            in_speed=auditor_real_efficiency * add_auditor_num,
            start_time=start_start_time,
            end_time=start_end_time, 
            )
        cur_simu.continuous_in(
            phase="audit_end",
            in_speed=auditor_real_efficiency * add_auditor_num,
            start_time=end_start_time,
            end_time=end_end_time, 
            )

        test_name = "{}_{}_{}_{}".format(add_num, start_hour, add_auditor_num, work_hour)
        output_path = None if output_path_prefix is None else output_path_prefix + "_" + test_name + ".xlsx"
        total_num_dict, stack_time_dict = stat(
            cur_simu=cur_simu,
            output_path=output_path,
            sheet_name=test_name,
            start_day=start_day,
        )

    impl(
        add_num=0,
        add_hour=0,
        add_auditor_num=0,
        start_hour=0,
        work_hour=0,
    )
    
    add_hours = [10, 15, 17]
    auditor_work_hour_list = [
        (0, 0),
        (1, 2),
        (1, 6),
        (1, 8),
        (2, 1),
        (2, 3),
        (2, 4),
        (4, 2),
    ]

    for cur_add_hour in add_hours:
        for cur_add_auditor_num, cur_work_hour in auditor_work_hour_list:
            impl(
                add_num=2000,
                add_hour=cur_add_hour,
                add_auditor_num=cur_add_auditor_num,
                start_hour=cur_add_hour,
                work_hour=cur_work_hour,
            )


def add_auditor_v2(ori_simu_parmas, output_path_prefix, start_day):
    """不同时间增加审核员对耗时的影响
    """
    # 每人每秒审核物料数
    auditor_real_efficiency = 0.0903

    def impl(add_auditor_num, start_hour, work_hour):
        """实验执行
        """
        cur_simu = SimulationIn(**copy.deepcopy(ori_simu_parmas))
        start_start_time = start_day + timedelta(hours=start_hour)
        start_end_time = start_day + timedelta(hours=start_hour + work_hour)
        # 审核阶段平均耗时18.9575 所以这里设置多出来的人 每个物料审核耗时约19秒
        end_start_time = start_day + timedelta(hours=start_hour, seconds=19)
        end_end_time = start_day + timedelta(hours=start_hour + work_hour, seconds=19)
        #logging.info("start_start_time: {}".format(start_start_time.strftime("%Y-%m-%d %H:%M:%S")))
        #logging.info("start_end_time: {}".format(start_end_time.strftime("%Y-%m-%d %H:%M:%S")))
        #logging.info("end_start_time: {}".format(end_start_time.strftime("%Y-%m-%d %H:%M:%S")))
        #logging.info("end_end_time: {}".format(end_end_time.strftime("%Y-%m-%d %H:%M:%S")))

        cur_simu.continuous_in(
            phase="audit_start",
            in_speed=auditor_real_efficiency * add_auditor_num,
            start_time=start_start_time,
            end_time=start_end_time, 
            )
        cur_simu.continuous_in(
            phase="audit_end",
            in_speed=auditor_real_efficiency * add_auditor_num,
            start_time=end_start_time,
            end_time=end_end_time, 
            )
        
        test_name = "{}_{}_{}".format(start_hour, add_auditor_num, work_hour)
        output_path = None if output_path_prefix is None else output_path_prefix + "_" + test_name + ".xlsx"
        total_num_dict, stack_time_dict = stat(
            cur_simu=cur_simu,
            output_path=output_path,
            sheet_name=test_name,
            start_day=start_day,
        )

    impl(
        add_auditor_num=0,
        start_hour=0,
        work_hour=0,
    )
    
    start_hours = [8, 10, 15, 17]
    auditor_work_hour_list = [
        (1, 2),
        (1, 6),
        (1, 8),
        (2, 1),
        (2, 3),
        (2, 4),
        (4, 2),
    ]

    for cur_start_hour in start_hours:
        for cur_add_auditor_num, cur_work_hour in auditor_work_hour_list:
            impl(
                add_auditor_num=cur_add_auditor_num,
                start_hour=cur_start_hour,
                work_hour=cur_work_hour,
            )


def simulation(input_path, start_day=None):
    """模拟计算耗时
    """
    global FIRST_WRITE
    if start_day is not None:
        start_day = datetime.strptime(start_day, "%Y%m%d")

    max_num = 1000
    max_num = None
    ori_simu = SimulationIn.load_from_file(input_path, max_num=max_num)
    ori_simu_parmas = {
        # 只取其中三个阶段
        "phase_list": ["in", "audit_start", "audit_end"],
        "phase_dict": ori_simu.phase_dict,
    }

    # 追加在之前的文件 则置为False

    #efficiency_change(ori_simu_parmas, "lo.xlsx", start_day)

    #in_time_change(ori_simu_parmas, "in_time_change.xlsx", start_day)

    #schedule_change(ori_simu_parmas, "schedule_change.xlsx", start_day)

    # 重新生成文件 则置为True
    FIRST_WRITE = True 
    add_auditor(
        ori_simu_parmas=ori_simu_parmas,
        output_path_prefix="output/exp/add_auditor",
        #output_path_prefix=None,
        start_day=start_day,
        )

    FIRST_WRITE=True
    add_auditor_v2(
        ori_simu_parmas=ori_simu_parmas,
        output_path_prefix="output/exp/add_auditor_v2",
        #output_path_prefix=None,
        start_day=start_day,
        )


if __name__ == "__main__":
    input_path = sys.argv[1]
    start_day = sys.argv[2] if len(sys.argv) > 2 else None
    simulation(input_path, start_day)