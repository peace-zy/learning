#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   trade_dist_stat.py
Author:   zhanghao55@baidu.com
Date  :   21/08/17 18:31:08
Desc  :   
"""

import sys
import codecs
import collections
import logging

from datetime import datetime
from tqdm import tqdm


def load_trade(trade_id_map_path):
    """加载行业信息
    """
    is_first_trade_dict = dict()
    trade_id_name_dict = dict()
    with codecs.open(trade_id_map_path, "r", "utf-8") as rf:
        for line in tqdm(rf):
            parts = line.strip("\n").split("\t")
            trade_id = parts[0]
            trade_name = parts[1]
            is_first_trade = True if parts[2] == "True" else False

            trade_id_name_dict[trade_id] = trade_name
            is_first_trade_dict[trade_id] = is_first_trade

    return trade_id_name_dict, is_first_trade_dict


def format_datetime(date_str):
    """格式化时间
    """
    if date_str == "0000-00-00 00:00:00":
        return None
    else:
        return datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")


class TaskDistInfo(object):
    """任务分配信息结构类
    """
    def __init__(self, parts, trade_dict=None):
        self.task_id = parts[0]
        self.task_status = int(parts[1])
        self.task_type = int(parts[2])
        self.task_group = int(parts[3])
        self.add_time = format_datetime(parts[4])
        self.allocate_time = format_datetime(parts[5])
        self.mod_time = format_datetime(parts[6])
        self.assigner = parts[7]
        self.meg_trade_1 = parts[8]
        self.meg_trade_2 = parts[9]

        self.add_time_stamp = None if self.add_time is None else datetime.timestamp(self.add_time)
        self.allocate_time_stamp = None if self.allocate_time is None else datetime.timestamp(self.allocate_time)
        self.mod_time_stamp = None if self.mod_time is None else datetime.timestamp(self.mod_time)
        if trade_dict is not None:
            self.meg_trade_1 = trade_dict[self.meg_trade_1]
            self.meg_trade_2 = trade_dict[self.meg_trade_2]


def data_loader(data_path, trade_dict=None, duplicate_task=False):
    """加载数据库获取的数据
    """
    task_id_set = set()
    with codecs.open(data_path, "r", "utf-8") as rf:
        for index, line in tqdm(enumerate(rf)):
            if index == 0:
                continue
            parts = line.strip("\n").split("\t")
            cur_obj = TaskDistInfo(parts, trade_dict)

            cur_task_id = cur_obj.task_id
            if not duplicate_task:
                if cur_task_id in task_id_set:
                    logging.warning("duplicate task {}".format(cur_task_id))
                    continue
                task_id_set.add(cur_task_id)

            yield cur_obj


def cal_seq_sim_score(seq_list):
    """计算相似度得分
    """
    total_sum = 0
    prev_count = 0
    prev_item = None
    for cur_item in seq_list:
        if cur_item != prev_item:
            if prev_item is not None:
                total_sum += prev_count * prev_count
            prev_item = cur_item
            prev_count = 0
        prev_count += 1
    
    if prev_item is not None:
        total_sum += prev_count * prev_count
    
    score = total_sum / float(len(seq_list))
    return score


def auditor_ratio_stat(data_path, trade_id_name_dict, task_group):
    """分析审核员任务的行业分布情况
    """

    trade_count = collections.defaultdict(int)
    auditor_task_count = collections.defaultdict(int)
    auditor_trade_count = collections.defaultdict(lambda: collections.defaultdict(int))
    auditor_trade_list = collections.defaultdict(list)

    for cur_task_info in data_loader(data_path, trade_id_name_dict):
        if cur_task_info.task_group != task_group:
            continue
        trade = cur_task_info.meg_trade_1
        trade_count[trade] += 1
        auditor_task_count[cur_task_info.assigner] += 1
        auditor_trade_count[cur_task_info.assigner][trade] += 1
        auditor_trade_list[cur_task_info.assigner].append((
            cur_task_info.allocate_time_stamp,
            trade,
            cur_task_info.allocate_time,
            ))

    print("task group: {}".format(task_group))
    # 分析各审核员审核各行业占比
    for cur_auditor_id, cur_task_count in sorted(auditor_task_count.items(), key=lambda x:x[1], reverse=True):
    #for cur_auditor_id, cur_trade_dict in auditor_trade_count.items():
        cur_trade_dict = auditor_trade_count[cur_auditor_id]
        cur_auditor_info = list()
        cur_trade_count_sorted = sorted(cur_trade_dict.items(), key=lambda x:x[1], reverse=True)
        for cur_trade, cur_count in cur_trade_count_sorted:
            total_count = trade_count[cur_trade]
            cur_auditor_info.append("{}({}/{:.2f}%)".format(
                cur_trade,
                cur_count,
                cur_count * 100 / float(total_count),
                ))

        cur_trade_list = auditor_trade_list[cur_auditor_id]
        sorted_trade_list = sorted(cur_trade_list, key=lambda x:x[0])
        cur_seq_sim_score = cal_seq_sim_score([x[1] for x in sorted_trade_list])
        
        print("auditor {}, #task = {}, score = {:.4f}: {}".format(
            cur_auditor_id,
            cur_task_count,
            cur_seq_sim_score,
            cur_auditor_info))
    print("=" * 150)


def trade_dist_stat(data_path, meg_id_map_path, stat_res_path):
    """分析行业的分配情况
    """
    min_time_stamp = 1629191666
    #min_time_stamp = None

    trade_id_name_dict, is_first_trade_dict = load_trade(meg_id_map_path)

    print("auditor dist ratio stat:")
    auditor_ratio_stat(data_path, trade_id_name_dict, 107)
    auditor_ratio_stat(data_path, trade_id_name_dict, 108)


if __name__ == "__main__":
    input_path = sys.argv[1]
    meg_id_path = sys.argv[2]
    output_path = sys.argv[3]
    trade_dist_stat(
        input_path,
        meg_id_path,
        output_path,
        )