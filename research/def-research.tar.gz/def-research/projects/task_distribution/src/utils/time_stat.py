#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   time_stat.py
Author:   zhanghao55@baidu.com
Date  :   21/08/17 18:31:08
Desc  :   
"""

import os
import sys
import collections
import logging

from datetime import datetime


def date_to_str(tar_time_stamp):
    """datetime转字符串 精确到秒
    """
    return datetime.fromtimestamp(tar_time_stamp).strftime("%Y-%m-%d %H:%M:%S")


def time_stat(time_list_dict, phase_list=None):
    """
    [in]  time_list_dict: dict, 各阶段的各时间点进入量. time_list_dict[phase_name] = [(timestamp1, num1), (timestamp2, num2), ...]
          phase_list: list, 阶段的顺序
    [out] stat_dict: dict, 各统计结果字典
                    1. stat_dict["stack_time_dict"]: 各阶段的总审核耗时
                    2. stat_dict["total_num"]: 物料总数
                    3. stat_dict["stack_trend_dict"]: 各阶段各时刻的堆积情况
    """
    if phase_list is None:
        phase_list = list(time_list_dict.keys())

    # 各阶段当前堆积的量
    stack_num_dict = dict()
    # 各阶段的堆积时间
    stack_time_dict = dict()
    # 各阶段当前累积进来的量
    total_num_dict = dict()
    # 各阶段各时间累积进来的量
    accumulate_num_dict = collections.defaultdict(dict)
    # 各阶段各时刻的堆积量
    stack_trend = collections.defaultdict(dict)

    start_time_stamp = None

    for cur_phase in phase_list:
        # 各阶段按时间点前后顺序排序
        cur_time_list = sorted(time_list_dict[cur_phase], reverse=True)
        assert len(cur_time_list) > 0
        #logging.info("phase {}, time_list size = {}".format(cur_phase, len(cur_time_list)))
        #logging.info("time_list: {}".format(cur_time_list))

        # 记录所有阶段最早的时间点
        if start_time_stamp is None or start_time_stamp > cur_time_list[-1][0]:
            start_time_stamp = cur_time_list[-1][0]

        time_list_dict[cur_phase] = cur_time_list

        # 初始化各阶段的堆积量
        stack_num_dict[cur_phase] = 0

        # 初始化各阶段的总审核时间
        stack_time_dict[cur_phase] = 0

        # 初始化各阶段的累积进入量
        total_num_dict[cur_phase] = 0

    def is_empty():
        """确认各阶段是否还有时间点记录
        """
        for cur_phase in phase_list:
            if len(time_list_dict[cur_phase]) > 0:
                return False
        return True
    
    prev_time = None
    cur_time_stamp = start_time_stamp
    #logging.info("start_time = {}".format(date_to_str(cur_time_stamp)))
    while True:
        # 调整当前时间点各阶段的堆积情况
        # 按阶段遍历
        for cur_index, cur_phase in enumerate(phase_list):
            cur_time_list = time_list_dict[cur_phase]
            # 该阶段的所有早于cur_time_stamp时间点的记录 加入当前阶段的堆积记录 并清除其之前的记录
            while len(cur_time_list) > 0 and cur_time_list[-1][0] <= cur_time_stamp:
                _, cur_num = cur_time_list.pop()
                # 如果该阶段不是第一个阶段 则当前进入的量应该从前一阶段的堆积中去除
                if cur_index > 0:
                    prev_phase = phase_list[cur_index - 1]
                    prev_stack_num = stack_num_dict[prev_phase] - cur_num
                    # stack_num小于0时给出提醒
                    if prev_stack_num < 0:
                        logging.warning("phase {} stack num = {}, it should not be smaller than 0".format(
                            prev_phase, prev_stack_num))
                    stack_num_dict[prev_phase] = prev_stack_num

                # 更新该阶段的进入量
                stack_num_dict[cur_phase] += cur_num
                # 更新该阶段总进入量
                total_num_dict[cur_phase] += cur_num

        # 这里要调整完各阶段堆积后才能更新耗时 因为本阶段还会受下一阶段影响
        # 根据各阶段的堆积情况 记录各阶段的耗时
        # 不需要记录最后一个阶段的 该阶段时审核已完成的阶段 不过也可以记录

        # 记录各阶段各时段的堆积情况
        for cur_phase in phase_list:
            stack_time_dict[cur_phase] += stack_num_dict[cur_phase]
            stack_trend[cur_phase][datetime.fromtimestamp(cur_time_stamp)] = stack_num_dict[cur_phase] 
            # 更新该阶段该时刻的总进入量
            accumulate_num_dict[cur_phase][datetime.fromtimestamp(cur_time_stamp)] = total_num_dict[cur_phase]
        
        # 如果各阶段的时间点记录都为空 则跳出
        #if is_empty():
        # 只观察最后一个阶段 最后一个阶段为空 则统计结束 统计到当前时间为止的审核耗时
        if len(time_list_dict[phase_list[-1]]) == 0:
            #logging.info("end_time = {}".format(date_to_str(cur_time_stamp)))
            break
        # 下一秒
        cur_time_stamp += 1
    
    return {
        "start_time": datetime.fromtimestamp(start_time_stamp), # 统计的起始时间
        "end_time": datetime.fromtimestamp(cur_time_stamp),     # 统计的终止时间
        "accumulate_num_dict": accumulate_num_dict,             # 各阶段各时刻累积进入量
        "stack_num_dict": stack_num_dict,                       # 各阶段在统计终止时间时的堆积量
        "stack_time_dict": stack_time_dict,                     # 各阶段在统计时间范围内总的堆积时长
        "total_num_dict": total_num_dict,                       # 各阶段的总进入量
        "stack_trend_dict": stack_trend,                        # 各阶段各时刻的堆积量
    }