#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
Author:   zhanghao55@baidu.com
Date  :   21/10/13 18:28:03
Desc  :   生成给除RD以外其他人展示的excel
"""

import sys
import pandas as pd


def main(excel_for_rd_path, excel_for_manager_path, excel_for_hy_path):
    """根据完整监控数据 筛选出给其他人展示的数据
    """
    sheets = pd.read_excel(excel_for_rd_path, sheet_name=None, engine="openpyxl")
    print(sheets.keys())

    with pd.ExcelWriter(excel_for_manager_path, mode="w", engine="openpyxl") as writer:
        sheets['auditor_daily_monitor'][[
            "auditor",
            "date",
            "audit_group",
            "saturation",
            "total_mt_count",
            "audit_task_num",
            "audit_efficiency",
            "audit_op_time",
            "top3_dist_info",
            ]].to_excel(writer, sheet_name='auditor_daily_monitor', index=False, encoding="utf-8")

        sheets['trade_daily_monitor'][[
            "date",
            "first_level_trade",
            "audit_op_time",
            "audit_efficiency",
            ]].to_excel(writer, sheet_name='trade_daily_monitor', index=False, encoding="utf-8")

        sheets['total_hourly_monitor'][[
            "hour",
            "auditor_num",
            "Q3_expected_auditor_num",
            ]].to_excel(writer, sheet_name='total_hourly_monitor', index=False, encoding="utf-8")

        cur_sheet = sheets['auditor_daily_monitor']
        cur_sheet = cur_sheet[(cur_sheet["audit_group"].isin(set(["107", "108"]))) & (cur_sheet["auditor"] == "total")]
        cur_sheet[[
            "date",
            "audit_group",
            "saturation",
            "audit_efficiency",
            ]].to_excel(writer, sheet_name='audit_group_daily_monitor', index=False, encoding="utf-8")

    with pd.ExcelWriter(excel_for_hy_path, mode="w", engine="openpyxl") as writer:
        hourly_regex = "\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}"
        hourly_mask = sheets['total_hourly_monitor']["hour"].str.contains(hourly_regex)
        sheets['total_hourly_monitor'][hourly_mask][[
            "hour",
            "out_ad_num",
            "direct_out_ad_num",
            "audit_op_time",
            "audit_efficiency",
            "audit_saturation",
            "max_audit_saturation",
            "Q3_audit_saturation",
            "auditor_num",
            "Q3_expected_auditor_num",
            ]].to_excel(writer, sheet_name='total_hourly_monitor', index=False, encoding="utf-8")

        sheets['total_hourly_monitor'][~hourly_mask][[
            "hour",
            "out_ad_num",
            "direct_out_ad_num",
            "audit_op_time",
            "audit_efficiency",
            "audit_saturation",
            "max_audit_saturation",
            "Q3_audit_saturation",
            "auditor_num",
            "Q3_expected_auditor_num",
            ]].to_excel(writer, sheet_name='total_daily_monitor', index=False, encoding="utf-8")


if __name__ == "__main__":
    excel_for_rd_path = sys.argv[1]
    excel_for_manager_path = sys.argv[2]
    excel_for_hy_path = sys.argv[3]
    main(
        excel_for_rd_path,
        excel_for_manager_path,
        excel_for_hy_path,
        )
