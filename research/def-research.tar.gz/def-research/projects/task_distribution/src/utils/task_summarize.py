#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   task_summarize.py
Author:   zhanghao55@baidu.com
Date  :   21/08/17 18:31:08
Desc  :   
"""

import os
import sys
import codecs
import collections
import logging

from tqdm import tqdm

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

from review_object import review_object

sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log
init_log()


def load_opt_data(data_path):
    """加载操作维度的数据 统计任务维度的信息
    """
    task_summarize_dict = collections.defaultdict(lambda: {
        "auditor_id": None,
        "task_mt_count": 0,
        "task_direct_mt_count": 0,
        "task_merge_mt_count": 0,
        "task_relate_mt_count": 0,
    })
    with codecs.open(data_path, "r", "utf-8") as rf:
        for line in tqdm(rf, desc="load opt data"):
            parts = line.strip("\n").split("\t")
            cur_opt = review_object.OperationHumanAuditResult(parts)
            task_summarize_dict[cur_opt.taskid]["auditor_id"] = cur_opt.auditor_front
            task_summarize_dict[cur_opt.taskid]["task_mt_count"] += int(cur_opt.op_total_ad_count)
            task_summarize_dict[cur_opt.taskid]["task_direct_mt_count"] += int(cur_opt.op_direct_ad_count)
            task_summarize_dict[cur_opt.taskid]["task_merge_mt_count"] += int(cur_opt.op_merge_ad_count)
            task_summarize_dict[cur_opt.taskid]["task_relate_mt_count"] += int(cur_opt.op_related_ad_count)
    
    return task_summarize_dict


def add_summarize_info(data_path, task_summarize_dict, output_path):
    """添加任务维度的统计信息
    """
    task_attr_size = len(review_object.TaskHumanAuditResult.attrs)
    with codecs.open(data_path, "r", "utf-8") as rf, \
            codecs.open(output_path, "w", "utf-8") as wf:
        for line in tqdm(rf, desc="load task data"):
            parts = line.strip("\n").split("\t")[:task_attr_size]
            # 补齐
            parts += [None] * (task_attr_size - len(parts))
            cur_task = review_object.TaskHumanAuditResult(parts)
            if cur_task.taskid not in task_summarize_dict:
                logging.warning("task {} not in opt data".format(cur_task.taskid))
                continue
            #assert cur_task.taskid in task_summarize_dict, \
            #    "task {} not in opt data".format(cur_task.taskid)
            
            cur_task.auditor_front = str(task_summarize_dict[cur_task.taskid]["auditor_id"])
            cur_task.task_mt_count = str(task_summarize_dict[cur_task.taskid]["task_mt_count"])
            cur_task.task_direct_mt_count = str(task_summarize_dict[cur_task.taskid]["task_direct_mt_count"])
            cur_task.task_merge_mt_count = str(task_summarize_dict[cur_task.taskid]["task_merge_mt_count"])
            cur_task.task_relate_mt_count = str(task_summarize_dict[cur_task.taskid]["task_relate_mt_count"])
            wf.write(cur_task.to_str() + "\n")
            

def task_summarize(opt_data_path, task_data_path, output_path):
    """根据操作维度数据，在任务维度数据上添加若干统计信息，存入指定文件
    """
    task_summarize_dict = load_opt_data(opt_data_path)
    add_summarize_info(task_data_path, task_summarize_dict, output_path)


if __name__ == "__main__":
    opt_data_path = sys.argv[1]
    task_data_path = sys.argv[2]
    output_path = sys.argv[3]
    task_summarize(
        opt_data_path,
        task_data_path,
        output_path,
    )
