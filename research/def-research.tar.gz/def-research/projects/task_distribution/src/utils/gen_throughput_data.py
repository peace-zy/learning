#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
Author:   zhanghao55@baidu.com
Date  :   21/08/24 17:28:03
Desc  :   预处理
"""

import os
import sys
import codecs
import collections
import logging

from datetime import datetime, timedelta

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
import review_object.review_object as review_object

sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log
init_log()


def update_record(record_dict, toaudit_data_path, task_in_data_path, ad_in_data_path):
    """根据任务、物料的待审、进审情况更新record字典
    """
    def gen_data_iter(data_path, record_class):
        """生成数据迭代器
        """
        with codecs.open(data_path, "r", "utf-8") as rf:
            for line in rf:
                parts = line.strip("\n").split("\t")
                cur_record = record_class(parts)
                # 前8列为key
                cur_key = "\t".join(parts[:9])
                # 如果该key在record_dict中不存在 表示该key第一次出现
                if cur_key not in record_dict:
                    record_dict[cur_key] = review_object.ThroughputRecord(None)
                    record_dict[cur_key].time = cur_record.time
                    record_dict[cur_key].pid = cur_record.pid
                    record_dict[cur_key].sale_system = cur_record.sale_system
                    record_dict[cur_key].first_level_trade = cur_record.first_level_trade
                    record_dict[cur_key].second_level_trade = cur_record.second_level_trade
                    record_dict[cur_key].user_status = cur_record.user_status
                    record_dict[cur_key].audit_type = cur_record.audit_type
                    record_dict[cur_key].task_type = cur_record.task_type
                yield cur_key, cur_record
    
    for cur_key, cur_toaudit_record in gen_data_iter(toaudit_data_path, review_object.TaskMttoAuditRecord):
        assert record_dict[cur_key].tobeaudit_task_num is None
        assert record_dict[cur_key].tobeaudit_ad_num is None
        record_dict[cur_key].tobeaudit_task_num = cur_toaudit_record.tobeaudit_task_num
        record_dict[cur_key].tobeaudit_ad_num = cur_toaudit_record.tobeaudit_ad_num
    
    for cur_key, cur_in_record in gen_data_iter(task_in_data_path, review_object.AuditInRecord):
        assert record_dict[cur_key].in_task_num is None
        record_dict[cur_key].in_task_num = cur_in_record.audit_in_num

    # ad的记录可能重复
    for cur_key, cur_in_record in gen_data_iter(ad_in_data_path, review_object.AuditInRecord):
        prev_ad_num = record_dict[cur_key].in_ad_num
        if prev_ad_num is None:
            prev_ad_num = "0"
        record_dict[cur_key].in_ad_num = str(int(cur_in_record.audit_in_num) + int(prev_ad_num))
    
    # 有些记录 可能不是全部字段都有
    # 遍历record 将None的字段变为合适的值 
    for cur_record in record_dict.values():
        if cur_record.tobeaudit_task_num is None:
            cur_record.tobeaudit_task_num = "0"
        if cur_record.tobeaudit_ad_num is None:
            cur_record.tobeaudit_ad_num = "0"
        if cur_record.in_ad_num is None:
            cur_record.in_ad_num = "0"
        if cur_record.in_task_num is None:
            cur_record.in_task_num = "0"


def main():
    """主入口
    """
    begin_hour = sys.argv[1]
    end_hour = sys.argv[2]
    toaudit_data_path_prefix  = sys.argv[3]
    task_in_data_path_prefix  = sys.argv[4]
    ad_in_data_path_prefix  = sys.argv[5]
    output_path  = sys.argv[6]

    begin_hour = datetime.strptime(begin_hour, "%Y%m%d%H")
    end_hour = datetime.strptime(end_hour, "%Y%m%d%H")
    cur_hour = begin_hour
    record_dict = dict()
    while cur_hour <= end_hour:
        logging.info("cur hour: {}".format(cur_hour))
        update_record(
            record_dict,
            toaudit_data_path_prefix + cur_hour.strftime("%Y%m%d%H"),
            task_in_data_path_prefix + cur_hour.strftime("%Y%m%d%H"),
            ad_in_data_path_prefix + cur_hour.strftime("%Y%m%d%H"),
        )
        cur_hour += timedelta(hours=1)
    
    with codecs.open(output_path, "w", "utf-8") as wf:
        for _, cur_record in sorted(record_dict.items()):
            wf.write("\t".join([getattr(cur_record, x) for x in cur_record.attrs]) + "\n")


if __name__ == "__main__":
    main()
