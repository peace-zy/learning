#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File  :   trade_id_map.py
Author:   zhanghao55@baidu.com
Date  :   21/08/17 18:31:08
Desc  :   
"""

import sys
import codecs
import collections

from tqdm import tqdm


def load_meg_data(user_trade_path):
    """根据用户meg行业ID信息生成meg_id_map
    """
    is_first_trade_dict = dict()
    trade_id_name_dict = dict()
    with codecs.open(user_trade_path, "r", "gb18030") as rf:
        for line in tqdm(rf):
            parts = line.strip("\n").split("\t")

            first_trade_id = parts[1]
            first_trade_name = parts[2]
            second_trade_id = parts[3]
            second_trade_name = parts[4]

            if second_trade_id not in trade_id_name_dict:
                trade_id_name_dict[second_trade_id] = second_trade_name
                is_first_trade_dict[second_trade_id] = False

            if first_trade_id not in trade_id_name_dict:
                trade_id_name_dict[first_trade_id] = first_trade_name
                is_first_trade_dict[first_trade_id] = True
    
    return trade_id_name_dict, is_first_trade_dict


def gen_trade_id_map(user_trade_path, trade_id_map_path):
    """生成行业ID映射文件
    """
    trade_id_name_dict, is_first_trade_dict = load_meg_data(user_trade_path)
    with codecs.open(trade_id_map_path, "w", "utf-8") as wf:
        for cur_id, cur_trade in sorted(trade_id_name_dict.items()):
            is_first_trade = is_first_trade_dict[cur_id]
            wf.write("\t".join([
                cur_id,
                cur_trade,
                str(is_first_trade),
            ]) + "\n")


def load_trade_id_map(trade_id_map_path):
    """id_name映射/一级行业
    """
    is_first_trade_dict = dict()
    trade_id_name_dict = dict()
    with codecs.open(trade_id_map_path, "r", "utf-8") as rf:
        for line in tqdm(rf):
            parts = line.strip("\n").split("\t")
            trade_id = parts[0]
            trade_name = parts[1]
            is_first_trade = True if parts[2] == "True" else False

            trade_id_name_dict[trade_id] = trade_name
            is_first_trade_dict[trade_id] = is_first_trade

    return trade_id_name_dict, is_first_trade_dict

def load_trade_id_index(trade_id_map_path):
    """
    获得行业id和index映射
    """
    trade_id_index_dict = dict()
    with open(trade_id_map_path, "r", encoding="utf8") as fr:
        for line in tqdm(fr):
            parts = line.strip("\n").split("\t")
            trade_id = parts[0]
            trade_id_index_dict[trade_id] = len(trade_id_index_dict)
    return trade_id_index_dict

if __name__ == "__main__":
    user_trade_path = sys.argv[1]
    trade_id_map_path = sys.argv[2]
    gen_trade_id_map(
        user_trade_path,
        trade_id_map_path,
        )
