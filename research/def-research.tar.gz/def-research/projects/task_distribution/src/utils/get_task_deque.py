#!/usr/bin/env python
# -*- coding: utf8 -*-

"""
  Author: shenhao02@baidu.com
  Date  : 21/10/19 14:16:27
  File  : get_task_deque.py
  Desc  : 
"""
import os
import sys
import collections
import logging

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
import conf
from review_object import review_object

sys.path.append("%s/../../../../" % _cur_dir)
from lib.common.logger import init_log
init_log()

class WindowsDequeInfo(object):
    """
    队列信息类
    """
    def __init__(self, input_file, filter_input_file, positive_file, negitive_file, taskinfo_file):
        """
        init
        """
        self.sortopinfo_file = input_file
        self.sortfilter_opinfo_file = filter_input_file
        self.dequeinfo_file = positive_file
        self.dequeinfo_negitive_file = negitive_file
        self.taskinfo_file = taskinfo_file

    def filter_data_opinfo(self):
        """
        方法是实现将排序后的操作队列，合并连续操作多次的同一任务时间
        例如操作队列A、B、B、C
        操作任务队列应该是A、B、C
        """
        #审核员 \t 任务 \t 操作开始时间 \t 操作结束时间
        unique_key = None
        unique_value = [""]*2
        with open(self.sortopinfo_file, "r", encoding="utf8") as fr, \
                open(self.sortfilter_opinfo_file, "w", encoding="utf8") as fw:
            for line in fr:
                each_parts = line.strip("\n").split("\t")
                op_audit_result = review_object.OperationHumanAuditResult(each_parts)
                auditor_front = op_audit_result.auditor_front
                taskid = op_audit_result.taskid
                op_begin_time = op_audit_result.op_begin_time
                op_end_time = op_audit_result.op_end_time
                sale_system = op_audit_result.sale_system
                pid = op_audit_result.pid
                if conf.sale_system_scope is not None and sale_system not in conf.sale_system_scope:
                    continue
                if conf.pid_scope is not None and pid not in conf.pid_scope:
                    continue
                cur_key = "\t".join([auditor_front, taskid])
                if cur_key != unique_key:
                    if unique_key is not None:
                        fw.write("\t".join([unique_key, "\t".join(unique_value)]) + "\n")
                        unique_value = [""]*2
                    unique_key = cur_key
                    unique_value[0] = op_begin_time
                unique_value[1] = op_end_time
    
            if unique_key is not None:
                fw.write("\t".join([unique_key, "\t".join(unique_value)]) + "\n")

    def get_window_time_task_op(self):
        """
        目标是获得分别以不同任务开始操作时
        指定间隔时间内最多可以操作的任务队列
        例如任务A、B、C、D、E..
        这里是为了选取分别以A/B/C..作为起始任务时的队列信息
        这里没有用滑动窗口简化的思路，原因：
        为了顺序选取以A/B/C作为起始任务的队里，滑动窗口简化的思路适用于最优化
        会漏掉一部分的任务队列
        所以这里直接用两个循环嵌套
        注意：因为会存在A、B、C、B这样操作的顺序，即一个任务间隔多次操作，所以要合并
        即此时在时间内操作的不是4个任务，而是3个任务A、B、C.
        队列开始时间为A开始时间，结束时间为B结束时间
        """
        #从任务表信息中获取任务真实的开始时间和结束时间
        task_info = collections.defaultdict(lambda: {
            "truth_begin":"",
            "truth_end": ""})
        #从任务操作排序队列中获取任务队列
        human_info = collections.defaultdict(lambda: {
            "task_deque": list(),
            "time_deque": list()})
        human_check_info = collections.defaultdict(lambda: list())
        #间隔时间由配置信息决定
        distri_time = conf.gap_time

        with open(self.taskinfo_file, "r", encoding="utf8") as fr:
            for line in fr:
                each_parts = line.strip("\n").split("\t")
                task_audit_result = review_object.TaskHumanAuditResult(each_parts)
                task_id = task_audit_result.taskid
                task_begin_time = task_audit_result.task_begin_time
                task_end_time = task_audit_result.task_end_time
                auditor_id = task_audit_result.auditor_front
                unique_id = "\t".join([auditor_id, task_id])
                task_info[unique_id]["truth_begin"] = task_begin_time
                task_info[unique_id]["truth_end"] = task_end_time
    
        with open(self.sortfilter_opinfo_file, "r", encoding="utf8") as fr:
            for line in fr:
                each_parts = line.strip("\n").split("\t")
                auditor_id = each_parts[0]
                taskid = each_parts[1]
                cur_begin_time = each_parts[2]
                cur_end_time = each_parts[3]
                task_info_dict = human_info[auditor_id]
                task_info_dict["task_deque"].append(taskid)
                task_info_dict["time_deque"].append([cur_begin_time, cur_end_time])
                human_info[auditor_id] = task_info_dict

        #每一个审核员的信息
        for each_key in human_info:
            human_task_info_list = human_info[each_key]["task_deque"]
            human_task_time_list = human_info[each_key]["time_deque"]
            cur_task_info_length = len(human_task_info_list)
            cur_task_time_length = len(human_task_time_list)
            assert cur_task_info_length == cur_task_time_length

            i = 0
            while(i < cur_task_info_length):
                j = i
                while(j < cur_task_info_length):
                    begin_task = human_task_info_list[i]
                    end_task = human_task_info_list[j]
                    deque_begin_time = int(human_task_time_list[i][0])
                    deque_end_time = int(human_task_time_list[j][1])
                    begin_unique = "\t".join([each_key, begin_task])
                    end_unique = "\t".join([each_key, end_task])
                    if begin_unique in task_info:
                        deque_truth_begin_time = int(task_info[begin_unique]["truth_begin"])
                    else:
                        deque_truth_begin_time = int(deque_begin_time)
                    if end_unique in task_info:
                        deque_truth_end_time = int(task_info[end_unique]["truth_end"])
                    else:
                        deque_truth_end_time = int(deque_end_time)

                    #当前队列开始时间并不是一个任务初始状态
                    if deque_begin_time != deque_truth_begin_time:
                        break
                    cur_gap_time = deque_end_time - deque_begin_time
                    if cur_gap_time <= distri_time:
                        j += 1
                        if j >= cur_task_info_length:
                            task_begin = 0
                            task_end = 0
                            task_deque_final_list = []
                            task_deque_time_info = collections.defaultdict(lambda: {
                                "task_begin": "",
                                "task_end": ""})
                            #循环的目的是获得队列中任务开始时间和结束时间
                            k = i
                            while(k < cur_task_info_length):
                                cur_task = human_task_info_list[k]
                                cur_task_time = human_task_time_list[k]
                                cur_task_begin_time = cur_task_time[0]
                                cur_task_end_time = cur_task_time[1]
                                if task_deque_time_info[cur_task]["task_begin"] == "":
                                    task_deque_time_info[cur_task]["task_begin"] = cur_task_begin_time
                                task_deque_time_info[cur_task]["task_end"] = cur_task_end_time
                                k += 1
                            k = i
                            task_set = set()
                            while(k < cur_task_info_length):
                                cur_task = human_task_info_list[k]
                                unique_key = "\t".join([each_key, cur_task])
                                if unique_key in task_info:
                                    cur_truth_begin = task_info[unique_key]["truth_begin"]
                                    cur_truth_end = task_info[unique_key]["truth_end"]
                                else:
                                    cur_truth_begin = task_deque_time_info[cur_task]["task_begin"]
                                    cur_truth_end = task_deque_time_info[cur_task]["task_end"]
                                #队列中任务开始结束时间是否是真实的，即去除那些操作了一部分的数据
                                if task_deque_time_info[cur_task]["task_begin"] == cur_truth_begin and \
                                        task_deque_time_info[cur_task]["task_end"] == cur_truth_end:
                                            if k != (cur_task_info_length - 1):
                                                if cur_task not in task_set:
                                                    task_set.add(cur_task)
                                                    task_deque_final_list.append(cur_task)
                                            else:
                                                if cur_task in task_set:
                                                    task_end = int(task_deque_time_info[cur_task]["task_end"])
                                                else:
                                                    task_set.add(cur_task)
                                                    task_deque_final_list.append(cur_task)
                                k += 1
                            if len(task_deque_final_list) != 0:
                                task_left_begin = task_deque_final_list[0]
                                task_right_end = task_deque_final_list[-1]
                                task_begin = int(task_deque_time_info[task_left_begin]["task_begin"])
                                if task_end == 0:
                                    task_end = int(task_deque_time_info[task_right_end]["task_end"])
                                task_str = "|".join(task_deque_final_list)
                                store_gap_time = task_end - task_begin
                                task_info_str = "\t".join([task_str, str(task_begin), str(task_end), \
                                                          str(store_gap_time)])
                                human_check_info[each_key].append(task_info_str)
                    else:
                        if j > i:
                            j = j - 1
                            while(j >= i):
                                task_right = human_task_info_list[j]
                                task_right_unique = "\t".join([each_key, task_right])
                                task_right_end= int(human_task_time_list[j][1])
                                if task_right_unique in task_info:
                                    task_right_truth_end = int(task_info[task_right_unique]["truth_end"])
                                else:
                                    task_right_truth_end = task_right_end
                                if task_right_end == task_right_truth_end:
                                    #如果队列结尾处的任务正好也是在这个队列中被操作完
                                    #需要拿整个序列
                                    task_begin = 0
                                    task_end = 0
                                    task_deque_final_list = []
                                    task_deque_time_info = collections.defaultdict(lambda: {
                                        "task_begin": "",
                                        "task_end": ""})
                                    k = i
                                    while(k <= j):
                                        cur_task = human_task_info_list[k]
                                        cur_task_time = human_task_time_list[k]
                                        cur_task_begin_time = cur_task_time[0]
                                        cur_task_end_time = cur_task_time[1]
                                        if task_deque_time_info[cur_task]["task_begin"] == "":
                                            task_deque_time_info[cur_task]["task_begin"] = cur_task_begin_time
                                        task_deque_time_info[cur_task]["task_end"] = cur_task_end_time
                                        k += 1
                                    k = i
                                    task_set = set()
                                    while(k <= j):
                                        cur_task = human_task_info_list[k]
                                        unique_key = "\t".join([each_key, cur_task])
                                        if unique_key in task_info:
                                            cur_truth_begin = task_info[unique_key]["truth_begin"]
                                            cur_truth_end = task_info[unique_key]["truth_end"]
                                        else:
                                            cur_truth_begin = task_deque_time_info[cur_task]["task_begin"]
                                            cur_truth_end = task_deque_time_info[cur_task]["task_end"]
                                        if task_deque_time_info[cur_task]["task_begin"] == cur_truth_begin and \
                                                task_deque_time_info[cur_task]["task_end"] == cur_truth_end:
                                                if k != j:
                                                    if cur_task not in task_set:
                                                        task_set.add(cur_task)
                                                        task_deque_final_list.append(cur_task)
                                                else:
                                                    if cur_task in task_set:
                                                        task_end = int(task_deque_time_info[cur_task]["task_end"])
                                                    else:
                                                        task_set.add(cur_task)
                                                        task_deque_final_list.append(cur_task)
                                        k += 1
                                    if len(task_deque_final_list) != 0:
                                        task_left_begin = task_deque_final_list[0]
                                        task_right_end = task_deque_final_list[-1]
                                        task_begin = int(task_deque_time_info[task_left_begin]["task_begin"])
                                        if task_end == 0:
                                            task_end = int(task_deque_time_info[task_right_end]["task_end"])
                                        task_str = "|".join(task_deque_final_list)
                                        store_gap_time = task_end - task_begin
                                        task_info_str = "\t".join([task_str, str(task_begin), str(task_end), \
                                                                   str(store_gap_time)])
                                        human_check_info[each_key].append(task_info_str)
                                    break
                                j -= 1
                        break
                i += 1

        #auditor_id \t 队列信息 \t 队列开始时间 \t 队列结束时间 \t 间隔 \t 任务数量
        with open(self.dequeinfo_file, "w", encoding="utf8") as fw:
            for each_key in human_check_info:
                each_value_list = human_check_info[each_key]
                for each_value in each_value_list:
                    task_str_nums = len(each_value.split("\t")[0].split("|"))
                    fw.write("\t".join([each_key, each_value, str(task_str_nums)]) + "\n")

    def get_window_time_task_negitive_op(self):
        """
        同样的操作，不过取的是[gap_time, 2*gap_time]中的数据
        """
        task_info = collections.defaultdict(lambda: {
            "truth_begin":"",
            "truth_end": ""})
        human_info = collections.defaultdict(lambda: {
            "task_deque": list(),
            "time_deque": list()})
        human_check_info = collections.defaultdict(lambda: list())
        #区间上下
        distri_time_min = conf.gap_time
        distri_time_max = conf.gap_time * 2

        with open(self.taskinfo_file, "r", encoding="utf8") as fr:
            for line in fr:
                each_parts = line.strip("\n").split("\t")
                task_audit_result = review_object.TaskHumanAuditResult(each_parts)
                task_id = task_audit_result.taskid
                task_begin_time = task_audit_result.task_begin_time
                task_end_time = task_audit_result.task_end_time
                auditor_id = task_audit_result.auditor_front
                unique_id = "\t".join([auditor_id, task_id])
                task_info[unique_id]["truth_begin"] = task_begin_time
                task_info[unique_id]["truth_end"] = task_end_time
    
        with open(self.sortfilter_opinfo_file, "r", encoding="utf8") as fr:
            for line in fr:
                each_parts = line.strip("\n").split("\t")
                auditor_id = each_parts[0]
                taskid = each_parts[1]
                cur_begin_time = each_parts[2]
                cur_end_time = each_parts[3]
                task_info_dict = human_info[auditor_id]
                task_info_dict["task_deque"].append(taskid)
                task_info_dict["time_deque"].append([cur_begin_time, cur_end_time])
                human_info[auditor_id] = task_info_dict
        #每一个审核员
        for each_key in human_info:
            human_task_info_list = human_info[each_key]["task_deque"]
            human_task_time_list = human_info[each_key]["time_deque"]
            cur_task_info_length = len(human_task_info_list)
            cur_task_time_length = len(human_task_time_list)
            assert cur_task_info_length == cur_task_time_length
            i = 0
            while(i < cur_task_info_length):
                j = i
                while(j < cur_task_info_length):
                    begin_task = human_task_info_list[i]
                    end_task = human_task_info_list[j]
                    deque_begin_time = int(human_task_time_list[i][0])
                    deque_end_time = int(human_task_time_list[j][1])
                    begin_unique = "\t".join([each_key, begin_task])
                    end_unique = "\t".join([each_key, end_task])
                    if begin_unique in task_info:
                        deque_truth_begin_time = int(task_info[begin_unique]["truth_begin"])
                    else:
                        deque_truth_begin_time = int(deque_begin_time)
                    if end_unique in task_info:
                        deque_truth_end_time = int(task_info[end_unique]["truth_end"])
                    else:
                        deque_truth_end_time = int(deque_end_time)
                    #当前队列开始时间并不是一个任务初始状态
                    if deque_begin_time != deque_truth_begin_time:
                        break
                    cur_gap_time = deque_end_time - deque_begin_time

                    if cur_gap_time <= distri_time_max:
                        j += 1
                        if j >= cur_task_info_length:
                            task_begin = 0
                            task_end = 0
                            task_deque_final_list = []
                            task_deque_time_info = collections.defaultdict(lambda: {
                                "task_begin": "",
                                "task_end": ""})
                            k = i
                            while(k < cur_task_info_length):
                                cur_task = human_task_info_list[k]
                                cur_task_time = human_task_time_list[k]
                                cur_task_begin_time = cur_task_time[0]
                                cur_task_end_time = cur_task_time[1]
                                if task_deque_time_info[cur_task]["task_begin"] == "":
                                    task_deque_time_info[cur_task]["task_begin"] = cur_task_begin_time
                                task_deque_time_info[cur_task]["task_end"] = cur_task_end_time
                                k += 1

                            k = i
                            task_set = set()
                            while(k < cur_task_info_length):
                                cur_task = human_task_info_list[k]
                                unique_key = "\t".join([each_key, cur_task])
                                if unique_key in task_info:
                                    cur_truth_begin = task_info[unique_key]["truth_begin"]
                                    cur_truth_end = task_info[unique_key]["truth_end"]
                                else:
                                    cur_truth_begin = task_deque_time_info[cur_task]["task_begin"]
                                    cur_truth_end = task_deque_time_info[cur_task]["task_end"]
                                if task_deque_time_info[cur_task]["task_begin"] == cur_truth_begin and \
                                        task_deque_time_info[cur_task]["task_end"] == cur_truth_end:
                                            if k != (cur_task_info_length - 1):
                                                if cur_task not in task_set:
                                                    task_set.add(cur_task)
                                                    task_deque_final_list.append(cur_task)
                                            else:
                                                if cur_task in task_set:
                                                    task_end = int(task_deque_time_info[cur_task]["task_end"])
                                                else:
                                                    task_set.add(cur_task)
                                                    task_deque_final_list.append(cur_task)
                                k += 1
                            if len(task_deque_final_list) != 0:
                                task_left_begin = task_deque_final_list[0]
                                task_right_end = task_deque_final_list[-1]
                                task_begin = int(task_deque_time_info[task_left_begin]["task_begin"])
                                if task_end == 0:
                                    task_end = int(task_deque_time_info[task_right_end]["task_end"])
                                task_str = "|".join(task_deque_final_list)
                                store_gap_time = task_end - task_begin
                                #保留在区间范围内的数据
                                if store_gap_time > distri_time_min:
                                    task_info_str = "\t".join([task_str, str(task_begin), str(task_end), \
                                                              str(store_gap_time)])
                                    human_check_info[each_key].append(task_info_str)
                    else:
                        if j > i:
                            j = j - 1
                            while(j >= i):
                                task_right = human_task_info_list[j]
                                task_right_unique = "\t".join([each_key, task_right])
                                task_right_end= int(human_task_time_list[j][1])
                                if task_right_unique in task_info:
                                    task_right_truth_end = int(task_info[task_right_unique]["truth_end"])
                                else:
                                    task_right_truth_end = task_right_end
                                if task_right_end == task_right_truth_end:
                                    #如果队列结尾处的任务正好也是在这个队列中被操作完
                                    #需要拿整个序列
                                    task_begin = 0
                                    task_end = 0
                                    task_deque_final_list = []
                                    task_deque_time_info = collections.defaultdict(lambda: {
                                        "task_begin": "",
                                        "task_end": ""})
                                    k = i
                                    while(k <= j):
                                        cur_task = human_task_info_list[k]
                                        cur_task_time = human_task_time_list[k]
                                        cur_task_begin_time = cur_task_time[0]
                                        cur_task_end_time = cur_task_time[1]
                                        if task_deque_time_info[cur_task]["task_begin"] == "":
                                            task_deque_time_info[cur_task]["task_begin"] = cur_task_begin_time
                                        task_deque_time_info[cur_task]["task_end"] = cur_task_end_time
                                        k += 1
                                    k = i
                                    task_set = set()
                                    while(k <= j):
                                        cur_task = human_task_info_list[k]
                                        unique_key = "\t".join([each_key, cur_task])
                                        if unique_key in task_info:
                                            cur_truth_begin = task_info[unique_key]["truth_begin"]
                                            cur_truth_end = task_info[unique_key]["truth_end"]
                                        else:
                                            cur_truth_begin = task_deque_time_info[cur_task]["task_begin"]
                                            cur_truth_end = task_deque_time_info[cur_task]["task_end"]
                                        if task_deque_time_info[cur_task]["task_begin"] == cur_truth_begin and \
                                                task_deque_time_info[cur_task]["task_end"] == cur_truth_end:
                                                if k != j:
                                                    if cur_task not in task_set:
                                                        task_set.add(cur_task)
                                                        task_deque_final_list.append(cur_task)
                                                else:
                                                    if cur_task in task_set:
                                                        task_end = int(task_deque_time_info[cur_task]["task_end"])
                                                    else:
                                                        task_set.add(cur_task)
                                                        task_deque_final_list.append(cur_task)
                                        k += 1
                                    if len(task_deque_final_list) != 0:
                                        task_left_begin = task_deque_final_list[0]
                                        task_right_end = task_deque_final_list[-1]
                                        task_begin = int(task_deque_time_info[task_left_begin]["task_begin"])
                                        if task_end == 0:
                                            task_end = int(task_deque_time_info[task_right_end]["task_end"])
                                        task_str = "|".join(task_deque_final_list)
                                        store_gap_time = task_end - task_begin
                                        if store_gap_time > distri_time_min:
                                            task_info_str = "\t".join([task_str, str(task_begin), str(task_end), \
                                                                       str(store_gap_time)])
                                            human_check_info[each_key].append(task_info_str)
                                    break
    
                                j -= 1
                        break
                i += 1

        with open(self.dequeinfo_negitive_file, "w", encoding="utf8") as fw:
            for each_key in human_check_info:
                each_value_list = human_check_info[each_key]
                for each_value in each_value_list:
                    task_str_nums = len(each_value.split("\t")[0].split("|"))
                    fw.write("\t".join([each_key, each_value, str(task_str_nums)]) + "\n")
    

if __name__ == "__main__":
    sortopinfo_file = sys.argv[1]
    sortfilter_opinfo_file = sys.argv[2]
    dequeinfo_file = sys.argv[3]
    dequeinfo_negitive_file = sys.argv[4]
    taskinfo_file = sys.argv[5]
    window_deque = WindowsDequeInfo(sortopinfo_file,
                                    sortfilter_opinfo_file,
                                    dequeinfo_file,
                                    dequeinfo_negitive_file,
                                    taskinfo_file)
    window_deque.filter_data_opinfo()
    window_deque.get_window_time_task_op()
    window_deque.get_window_time_task_negitive_op()

