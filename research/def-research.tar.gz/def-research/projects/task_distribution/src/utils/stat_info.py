#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
Author:   zhanghao55@baidu.com
Date  :   21/08/30 17:28:03
Desc  :   统计结果文件
"""

import codecs
import collections
import logging
import pandas as pd
import time


class StatInfo(object):
    """统计结果类
    """
    @classmethod
    def load_from_file(cls, data_path, key_num=1):
        """从文件中加载统计结果
        """
        recursive_dict = lambda: collections.defaultdict(recursive_dict)
        stat_dict = recursive_dict()

        stat_attr_list = None
        with codecs.open(data_path, "r", "utf-8") as rf:
            for index, line in enumerate(rf):
                parts = line.strip("\n").split("\t")
                if index == 0:
                    stat_attr_list = parts
                    continue
                cur_dict = stat_dict
                cur_key_depth = 0
                while cur_key_depth < key_num:
                    cur_dict = cur_dict[parts[cur_key_depth]]
                    cur_key_depth += 1
                for cur_attr, cur_value in zip(stat_attr_list[key_num:], parts[key_num:]):
                    cur_dict[cur_attr] = cur_value
        return cls(stat_attr_list, stat_dict, key_num)

    def __init__(self, stat_attr_list, stat_dict=None, key_num=1):
        self.stat_dict = stat_dict
        if self.stat_dict is None:
            recursive_dict = lambda: collections.defaultdict(recursive_dict)
            self.stat_dict = recursive_dict()
        self.stat_attr_list = stat_attr_list
        self.key_num = key_num
    
    def keys(self):
        """迭代统计结果时需要
        """
        return self.stat_dict.keys()

    def items(self):
        """迭代统计结果时需要
        """
        return self.stat_dict.items()
    
    def __contains__(self, key):
        return key in self.stat_dict
    
    def __size__(self):
        return len(self.stat_dict)

    def __getitem__(self, key):
        return self.stat_dict[key]
    
    def __setitem__(self, key, value):
        self.stat_dict[key] = value
    
    def pop(self, key):
        """弹出统计字典中某键
        """
        return self.stat_dict.pop(key)

    def __delitem__(self, key):
        del self.stat_dict[key]

    def to_list(self, attr_list=None, sort=False, key=None, reverse=False):
        """将字典结果转为list，每个元素为一行
        """
        def recursive_to_list(cur_dict, key_list=None):
            """将嵌套字典中的内容转为list
            """
            nonlocal attr_list
            res_list = list()
            if key_list is None:
                key_list = list()

            if len(key_list) == self.key_num:
                assert isinstance(cur_dict, dict), \
                    "expect cur_dict's type is dict, actual {}".format(type(cur_dict))
                cur_stat = key_list.copy()
                if attr_list is None:
                    attr_list = self.stat_attr_list[self.key_num:]
                # 当前stat所有的attr
                whole_attr_set = set(self.stat_attr_list[self.key_num:])
                # 如果有指定的attr_list则按照指定的顺序
                # 否则按默认的顺序
                for cur_attr in attr_list:
                    if cur_attr in whole_attr_set:
                        cur_stat.append(cur_dict.get(cur_attr, "None"))
                res_list.append(cur_stat)
            else:
                if sort:
                    items = sorted(cur_dict.items(), key=key, reverse=reverse)
                else:
                    items = cur_dict.items()

                for cur_key, cur_sub_dict in items:
                    key_list.append(cur_key)
                    res_list.extend(recursive_to_list(cur_sub_dict, key_list.copy()))
                    key_list.pop()

            return res_list

        return recursive_to_list(self.stat_dict)

    def save(self, output_path, attr_list=None, sort=False, key=None, reverse=False):
        """将统计结果存储到文件中
        """
        with codecs.open(output_path, "w", "utf-8") as wf:
            wf.write("\t".join(self.stat_attr_list) + "\n")
            for cur_stat_list in self.to_list(attr_list, sort, key, reverse):
                wf.write("\t".join(cur_stat_list) + "\n")

    def to_excel(self, excel_path, sheet_name=None, mode=None, verbose=True):
        """统计结果存入excel中
        """
        mode = "w" if mode is None else mode
        start_time = time.time()
        with pd.ExcelWriter(excel_path, mode=mode, engine="openpyxl") as writer:
            pd.DataFrame(
                    self.to_list(),
                    columns=self.stat_attr_list,
                    ).to_excel(writer, sheet_name=sheet_name, index=False, encoding="utf-8")
        if verbose:
            logging.info("write to excel {}. cost time = {:.2f}s. [sheet = {}][mode = {}]".format(
                excel_path,
                time.time() - start_time,
                sheet_name,
                mode,
                ))

    
if __name__ == "__main__":
    StatInfo.load_from_file("output/auditor_hourly_stat.20210905", key_num=2).save("lo")
