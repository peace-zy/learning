# 派单式任务分发策略
## 本地执行
---
1. 环境配置

    修改`bin/util.sh`中LOCAL_PYTHON、HADOOP_HOME

2. 获取账户基本信息(以20210831为例)

    ```sh bin/run.sh -o -u -t 20210831```

3. 获取任务、操作、物料维度数据

    ```sh bin/run.sh -o -h -t 20210831```

4. 获取预处理数据

    ```sh bin/run.sh -o -p -t 20210831```

### TODO
5. 特征提取

    ```python src/feature/feature_extract.py 20210831```

6. 模型训练


## 数据字段
---
### 图灵基础人审数据BaseHumanAuditResult
|序号|字段名|备注|
|:---:|:---:|:---:|
|1|pipe|数据流|
|2|product_id|产品线id|
|3|user_id||
|4|unit_id||
|5|plan_id||
|6|ad_id||
|7|ad_type||
|8|ad_version||
|9|word_list|\x01分割|
|10|idea_list|\x01分割|
|11|url_list|\x01分割|
|12|pic_list|\x01分割|
|13|video_list|\x01分割|
|14|audit_channel_type|1增量 2巡查 3人工一审 4人工二审|
|15|human_in_start_timestamp||
|16|human_out_end_timestamp||
|17|chk_user|审核员id|
|18|review_result|总审核结论 1拒绝 0通过|
|19|text_pair_result||
|20|text_result||
|21|rev_result_text||
|22|reason_array|拒绝理由|
|23|rsnid|拒绝理由id|
|24|audit_details|机器审核时参考这个字段|

### 任务维度基础数据TaskHumanAuditResult
|序号|字段名|备注|
|:---:|:---:|:---:|
|0|pid|产品线ID|
|1|userid|账户ID|
|2|taskid|任务ID|
|3|sale_system|销售体系|
|4|first_level_trade|MEG一级行业|
|5|second_level_trade|MEG二级行业|
|6|auditor|审核员ID|
|7|distribution_type|分配方式（1-实时随机分发、2-定时触发分发）|
|8|total_audit_time|总耗时|
|9|tobeassign_time|待分配时长|
|10|tobeaudit_time|已分配待审耗时|
|11|audit_time|审核耗时|
|12|audit_op_time|审核操作耗时,和上一个的区别在于真正审核时间|
|13|audit_op_number|审核操作次数|
|14|task_add_time|任务添加时间 unixtime|
|15|task_distri_time|任务分配时间 unixtime|
|16|task_begin_time|任务开始审核时间 unixtime|
|17|task_end_time|任务结束审核时间 unixtime|
|18|auditor_front|任务的操作人（前端打点）|
|19|task_mt_count|任务物料总量|
|20|task_direct_mt_count|任务直接看到的物料总量|
|21|task_merge_mt_count|任务聚合物料总量（人审看不到）|
|22|task_relate_mt_count|任务联动物料总量（人审看不到）|

### 物料维度基础数据AdHumanAuditResult
|序号|字段名|备注|
|:---:|:---:|:---:|
|0|adid|物料|
|1|keyid|keyID|
|2|taskid|任务ID|
|3|userid|账户ID|
|4|pid|产品线ID|
|5|ad_begin_time|系统中记录的入审时间|
|6|ad_end_time|系统中记录的有审核结论时间|
|7|auditor_database|审核操作人（数据库记录）|
|8|reject_desc|拒绝理由描述|
|9|reject_reason_id|拒绝理由id|
|10|audit_type1|审核方式（逻辑稍微复杂，可不关注）|
|11|audit_time_front|审核时间（前端打点）|
|12|auditor_front|审核操作人（前端打点）|
|13|audit_begin_time|审核开始时间|
|14|audit_end_time|审核结束时间|
|15|audit_total_time|审核操作耗时|
|16|audit_op_type|审核操作方式（部分值待清洗）|
|17|audit_result|审核结果|
|18|audit_type2|审核方式（1-被直接审核、2-被聚合联动、3-被元素联动）|
|19|sale_system|销售体系|
|20|first_level_trade|一级MEG行业|
|21|second_level_trade|二级MEG行业|
|22|task_add_time|所属任务添加时间|
|23|task_distri_time|所属任务分配时间|
|24|auditor_distri|分配审核员|
|25|distribution_type|分配方式（1-实时随机分发、2-定时触发分发）|
|26|task_begin_time|所属任务开始审核时间|
|27|task_end_time|所属任务审核结束时间|
|28|total_time|物料总耗时|
|29|tobeassign_time|物料待分配耗时|
|30|tobeaudit_time|物料已分配待审耗时|

### 操作维度基础数据OperationHumanAuditResult
|序号|字段名|备注|
|:---:|:---:|:---:|
|0|op_time|操作时间|
|1|taskid|所属任务id|
|2|userid|userid|
|3|pid|审核流id|
|4|auditor_front|审核操作人（前端打点）|
|5|op_type|审核操作方式（部分值待清洗）|
|6|op_result|审核结果|
|7|op_begin_time|操作开始时间|
|8|op_end_time|操作结束时间（即操作时间）|
|9|op_total_time|操作耗时|
|10|op_total_ad_count|操作涉及物料总量|
|11|op_direct_ad_count|操作涉及直接操作物料量|
|12|op_merge_ad_count|操作涉及聚合物料量|
|13|op_related_ad_count|操作涉及关联物料量|
|14|task_begin_time|任务开始审核时间|
|15|sale_system|销售体系|
|16|first_level_trade|一级MEG行业|
|17|second_level_trade|二级MEG行业|
|18|task_add_time|所属任务添加时间|
|19|task_distri_time|所属任务分配时间|
|20|auditor|分配审核员|
|21|distribution_type|分配方式（1-实时随机分发、2-定时触发分发）|

### 任务、物料堆积、进审ThroughputRecord
|序号|字段名|备注|
|:---:|:---:|:---:|
|0|time|当前时间（整点）|
|1|pid|产品线ID|
|2|sale_system|销售体系|
|3|first_level_trade|MEG一级行业|
|4|second_level_trade|MEG二级行业|
|5|user_status|账户状态|
|6|audit_type|审核类型(1：一线审核、2:总部审核，现在应该只有2了)|
|7|task_type|任务类型(1：普通、2：优审、3：搁置、5：打桩、6:先发后审)|
|8|tobeaudit_task_num|本小时待审任务量|
|9|tobeaudit_ad_num|本小时待审物料量|
|10|in_task_num|本小时进审任务量|
|11|in_ad_num|本小时进审物料量|

### 任务物料待审情况TaskMttoAuditRecord
|序号|字段名|备注|
|:---:|:---:|:---:|
|0|time|当前时间（整点）|
|1|pid|产品线ID|
|2|user_status|账户状态|
|3|task_type|任务类型(1：普通、2：优审、3：搁置、5：打桩、6:先发后审)|
|4|task_group|审核组|
|5|audit_type|审核类型(1：一线审核、2:总部审核，现在应该只有2了)|
|6|sale_system|销售体系|
|7|first_level_trade|MEG一级行业|
|8|second_level_trade|MEG二级行业|
|9|tobeaudit_task_num|本小时待审任务量|
|10|tobeaudit_ad_num|本小时待审物料量|

### 任务物料进审情况AuditInRecord
|序号|字段名|备注|
|:---:|:---:|:---:|
|0|time|当前时间（整点）|
|1|pid|产品线ID|
|2|user_status|账户状态|
|3|task_type|任务类型(1：普通、2：优审、3：搁置、5：打桩、6:先发后审)|
|4|task_group|审核组|
|5|audit_type|审核类型(1：一线审核、2:总部审核，现在应该只有2了)|
|6|sale_system|销售体系|
|7|first_level_trade|MEG一级行业|
|8|second_level_trade|MEG二级行业|
|9|audit_in_num|本小时进审量|
