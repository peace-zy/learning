#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   shenhao02@baidu.com
Date  :   20/04/21 11:29:36
Desc  :   get_user_dict
"""
import sys
import os
import pickle

base_path = os.path.abspath(os.curdir)
dict_path = "/".join([base_path, "research_dict"])
task_id = "cae301e53a6a5a5171925c20f1b08b8b" #task_id
task_data = "%s_data.txt" % task_id
data_file = base_path + "/hdfs_data/" + task_data

def save_obj(obj, name ):
    """
    �ֵ䱣��Ϊpickle
    """
    with open(dict_path + "/" + name + '.pkl', 'wb') as f:
        pickle.dump(obj, f, pickle.HIGHEST_PROTOCOL)

if __name__ == "__main__":
    userdict = {}
    if not os.path.exists(dict_path):
        os.makedirs(dict_path)

    with open(data_file, "r")as fr:
        for each_line in fr:
            user_info_list = each_line.strip("\n").split("\t")
            if len(user_info_list)>1:
                userid = user_info_list[0]
                unitid = user_info_list[2]
                if userid not in userdict.keys():
                    userdict[userid] = set()
                    userdict[userid].add(unitid)
                else:
                    userdict[userid].add(unitid)
    save_obj(userdict, task_id + "_userdict")
