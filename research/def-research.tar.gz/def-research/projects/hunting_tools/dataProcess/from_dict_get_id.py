#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   shenhao02@baidu.com
Date  :   20/04/21 11:54:10
Desc  :   
"""
import os
import pickle

base_path = os.path.abspath(os.curdir)
task_id = "cae301e53a6a5a5171925c20f1b08b8b"
#task_id = "aceedd2b387cb6f41d36acbb87b9f029"
dict_file = base_path + "/research_dict/"
id_file = base_path + "/id_file/all_id.txt"

def loads(name):
    """
    �����ֵ�pickle
    """
    with open(dict_file + name + '.pkl', 'rb') as f:
        return pickle.load(f)

if __name__ == "__main__":
    userdict = loads(task_id + "_userdict")

    with open(id_file, "w") as fw:
        for userid in userdict.keys():
            unit_list = userdict[userid]
            for uni in unit_list:
                fw.write("\t".join([userid, uni])+"\n")
