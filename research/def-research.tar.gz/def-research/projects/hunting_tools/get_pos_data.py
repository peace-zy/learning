#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   shenhao02@baidu.com
Date  :   20/05/18 14:40:55
Desc  :   
"""
import sys
import os
import subprocess
import argparse
import logging

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../lib/" % _cur_dir)
import common.common as common

hdfs_path = "hdfs://nmg01-mulan-hdfs.dmop.baidu.com:54310"
file_path = "/app/ecom/aries/fengkong/shenhao02/hunter/hunting_tools_data/database_pos.txt"

def args_func():
    """
    func : ������ȡ
    """
    parser = argparse.ArgumentParser(description = "get data")
    parser.add_argument("-op", "--out_path", help = "�����������ַ", required = True)
    args = parser.parse_args()
    return args

def get_pos_sample(out_path):
    """
    func : ����hdfs��ַ��ȡ������
    """

    # ��ȡ������ȫ������
    if os.path.exists(out_path) == False:
        cmd_str = "hadoop fs -get " + hdfs_path + file_path + " " + out_path
        ret = subprocess.call(cmd_str, shell = True)
        if ret != 0:
            logging.error("from hdfs get positive data failed !")
            sys.exit(1)
    else:
        logging.info("pos data is exist.")

    logging.info("from hdfs get pos data success")

if __name__ == "__main__":
    args = args_func()
    get_pos_sample(args.out_path)
