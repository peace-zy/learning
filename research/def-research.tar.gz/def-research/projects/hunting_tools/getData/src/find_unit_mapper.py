#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   shenhao02@baidu.com
Date  :   20/04/21 12:15:42
Desc  :   
"""
import sys

if __name__ == "__main__":
    all_id_file = sys.argv[1]
    user_list=[]
    with open(all_id_file, "r")as fr:
        for unit_line in fr:
            user_list.append(unit_line.strip("\n"))

    for each_line in sys.stdin:
        each_list = each_line.strip("\n").split("\t")
        userid = each_list[0]
        unitid = each_list[2]
        ideas = each_list[3]
        words = each_list[4]
        ideas_seg = each_list[5]
        words_seg = each_list[6]
        idea_url_list = each_list[7]
        find_key = "\t".join([userid, unitid])
        if find_key in user_list:
            print "\t".join([find_key, ideas, words, ideas_seg, words_seg, idea_url_list])
