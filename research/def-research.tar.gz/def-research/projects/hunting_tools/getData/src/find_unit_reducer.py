#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   shenhao02@baidu.com
Date  :   20/04/21 12:21:43
Desc  :   hadoop cat 
"""
import sys

if __name__ == "__main__":
    for each_line in sys.stdin:
        print "\t".join(each_line.strip("\n").split("\t"))
