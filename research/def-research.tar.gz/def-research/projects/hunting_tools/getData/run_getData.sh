#!/bin/bash

#===================================================
# Copyright (C) 2020 K All rights reserved.
# �ļ����ƣ�run_all.sh
# �� �� �ߣ�shenhao02@baidu.com
# �������ڣ�2020��04��21��
# ��    ����...
#===================================================
cur_dir=$(cd "$(dirname "$0")";pwd)
source ${cur_dir}/tar_up_getData.sh
#hadoop����
queue="fengkong"
cluster="mulan"
HADOOP_HOME="/home/users/shenhao02/worktool/hadoop-client-1.6.2.2/"
HADOOP_PATH="${HADOOP_HOME}hadoop/bin/hadoop --config ${HADOOP_HOME}hadoop/conf-${queue}-${cluster}"
#ʱ��
TODAY=`date +"%Y%m%d" -d "-0 days"`
#��ȡ���ݵ����ڣ������Լ���
DATE=`date +"%Y%m%d" -d "3 day ago"` 
#��Ⱥ��ַ
M_NAME="hdfs://nmg01-mulan-hdfs.dmop.baidu.com:54310/"
K_NAME="hdfs://nmg01-khan-hdfs.dmop.baidu.com:54310/"
work_name="${TODAY}_getData"
Z="${M_NAME}app/ecom/aries/fengkong/shenhao02/H_DATA/hunter/find_unit_data1/${work_name}/"
#�ļ�·��
NOW_FILE="all_id"
FILE_NAME="task/${NOW_FILE}.txt"
#�������·��,����ʹ����������def-user�������unitά������
input="${K_NAME}app/ecom/aries/galaxy/def_model_data/user_label/Z_all/${DATE}-unit-sample/*"
output="${Z}output/${NOW_FILE}/"
PYTHON_PATH="${M_NAME}/app/ecom/aries/fengkong/zhuxiaodong01/python_with_paddle.tar.gz"
function find_unit_ad_by_id()
{
	#find function#
    hadoop_process ${output} ${input} \
        "find_unit_ad_by_id_${NOW_FILE}" "fengkong" \
        src/find_unit_mapper.py \
        src/find_unit_reducer.py \
        1 ${FILE_NAME}
}

function hadoop_process()
{
    #hadoop process#
    OUTPUT=$1
    INPUT=$2
    JOBNAME="shenhao02_${3}"
    QUEUE=$4
    MAPPER=$5
    REDUCER=$6
    REDUCER_NUM=$7
    USE_FILE=$8
    ${HADOOP_PATH} fs -rmr ${OUTPUT}
    ${HADOOP_PATH} fs -test -e ${Z}src.tar.gz
    if [ $? -ne 0 ]; then
        echo "ERROR: src.tar.gz is not exit!"
    fi
    ${HADOOP_PATH} fs -test -e ${Z}task.tar.gz
    if [ $? -ne 0 ]; then
        echo "ERROR: task.tar.gz is not exit!"
    fi
    ${HADOOP_PATH} streaming \
        -D mapred.job.queue.name="${QUEUE}" \
        -D mapred.job.name="${JOBNAME}" \
        -D mapred.job.priority=VERY_HIGH \
        -D stream.memory.limit=7000 \
        -D mapred.job.map.capacity=4000 \
        -D mapred.job.reduce.capacity=500 \
        -D mapred.map.tasks=5000 \
        -D mapred.reduce.tasks=${REDUCER_NUM} \
        -D mapred.textoutputformat.ignoreseparator=true \
        -partitioner org.apache.hadoop.mapred.lib.KeyFieldBasedPartitioner \
        -inputformat org.apache.hadoop.mapred.TextInputFormat \
        -cacheArchive ${PYTHON_PATH}\
        -cacheArchive ${H_DATA}src.tar.gz#src \
        -cacheArchive ${H_DATA}task.tar.gz#task \
        -input "${INPUT}" \
        -output "${OUTPUT}" \
        -mapper "python ${MAPPER} ${USE_FILE}" \
        -reducer "python ${REDUCER}"
    if [ $? -ne 0 ]; then
        echo -e "ERROR: ${INPUT}, ${OUTPUT}, ${JOBNAME}\n"
        return 1
    fi
}
find_unit_ad_by_id



