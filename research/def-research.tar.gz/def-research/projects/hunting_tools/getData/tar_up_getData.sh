#!/bin/bash

#===================================================
# Copyright (C) 2020 K All rights reserved.
# �ļ����ƣ�tar_up_hd.sh
# �� �� �ߣ�shenhao02@baidu.com
# �������ڣ�2020��04��21��
# ��    ����...
#===================================================
function log_info()
{
    info=${1}
    time_now=`date +"%Y%m%d %H:%M:%S"`
    echo -e "INFO, ${time_now}, ${info}!"
}

function put_tar_to_hdfs()
{
    queue="fengkong"
    cluster="mulan"
    TODAY=`date +"%Y%m%d" -d "-0 days"`
    HADOOP_HOME="/home/users/shenhao02/worktool/hadoop-client-1.6.2.2/"
    HADOOP_PATH="${HADOOP_HOME}hadoop/bin/hadoop --config ${HADOOP_HOME}hadoop/conf-${queue}-${cluster}"
    file_name=${1}
    work_name="${TODAY}_getData"
    M="hdfs://nmg01-mulan-hdfs.dmop.baidu.com:54310"
    H_DATA="${M}/app/ecom/aries/fengkong/shenhao02/H_DATA/hunter/find_unit_data1/${work_name}/"
    log_info "put_tar_to_hdfs ${file_name} begin."
    ${HADOOP_PATH} fs -test -e ${H_DATA}
    if [ $? -ne 0 ]; then
        ${HADOOP_PATH} fs -mkdir ${H_DATA}
    fi
    ${HADOOP_PATH} fs -test -e ${H_DATA}/${file_name}
    if [ $? -eq 0 ]; then
        ${HADOOP_PATH} fs -rmr ${H_DATA}/${file_name}
    fi
    ${HADOOP_PATH} fs -put ${file_name} ${H_DATA}/${file_name}
    log_info "put_tar_to_hdfs ${file_name} end."
}

function upload_tar_package()
{
    log_info "upload_tar_package begin."
    BASE_DIR=$(cd "$(dirname "$0")";pwd)
    TASK_DIR="${BASE_DIR}/task/"
    SRC_DIR="${BASE_DIR}/src/"
    cd ${SRC_DIR}
    tar zcvf src.tar.gz * \
        --exclude "*.un~" \
        --exclude "*.tar.gz" \
        --exclude "*.pyc" \
        --exclude "*.orig"
    put_tar_to_hdfs src.tar.gz
    cd -
    cd ${TASK_DIR}
    tar zcvf task.tar.gz *
    put_tar_to_hdfs task.tar.gz
    cd -
}
upload_tar_package
