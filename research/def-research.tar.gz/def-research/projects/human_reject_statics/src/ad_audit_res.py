#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: ad_audit_res.py
Author: shenhao02(shenhao02@baidu.com)
Date: 2021/04/07
Desc: from ad_audit_res.py(zhanghao55@baidu.com)
"""

import sys
import json
from collections import defaultdict

def wrapped_array_strip(wrapped_array):
    """����־��WrappedArray���ֶθ�ʽ��
    """
    if wrapped_array.startswith("WrappedArray(") and wrapped_array.endswith(")"):
        wrapped_array = wrapped_array[13:-1]
    return wrapped_array

def parse_audit_details(audit_details):
    """����ad_audit��audit_details�ֶ�
    """
    audit_res = defaultdict(list)
    for audit_detail in audit_details:
        risk_details = json.loads(audit_detail["risk_details"])
        for risk_detail in risk_details:
            if len(risk_detail["option"]) == 0:
                continue
            option = json.loads(risk_detail["option"])
            cur_audit_detail = dict()
            try:
                if isinstance(option, dict):
                    cur_audit_detail["modelid"] = option["model_id"]
                else:
                    cur_audit_detail["modelid"] = json.loads(option)["model_id"]
            except KeyError as e:
                continue
            cur_audit_detail["sug_result"] = risk_detail["suggestion_result"]
            cur_audit_detail["type"] = audit_detail["type"]
            cur_audit_detail["cont"] = audit_detail["cont"]
            cur_audit_detail["reason"] = risk_detail["reason"]
            cur_audit_detail["risk_id"] = risk_detail["risk_id"]
            cur_audit_detail["rate"] = risk_detail["rate"]
            audit_res[cur_audit_detail["modelid"]].append(cur_audit_detail)
    return audit_res

class AdAuditRes(object):
    """ad_audit��־��¼�ṹ
    """
    def __init__(self):
        pass

    def init_from_line(self, line, sep="\x01"):
        """�����ַ�����ʼ��
        """
        parts = line.strip("\n").split(sep)
        return self.init_from_parts(parts)

    def init_from_parts(self, parts, sep="\x01"):
        """�����б���ʼ��
        """
        if len(parts) != 24:
            return False
        try:
            self.pipe = parts[0]
            self.product_id = parts[1]
            self.user_id = parts[2]
            self.unit_id = parts[3]
            self.plan_id = parts[4]
            self.ad_id = parts[5]
            self.ad_type = parts[6]
            self.ad_version = parts[7]
            self.word_cont_array = parts[8].replace("\x01", "")
            self.text_cont_array = parts[9].replace("\x01", "")
            self.url_array = parts[10].split("\x01")#url�б�[""]
            self.pic_array = parts[11].split("\x01")#picture�б�[""]
            self.vedio_array = parts[12].split("x01")#vedio�б�[""]
            self.ad_channel_type = parts[13] #���ͨ·
            self.human_start_time = parts[14] #��˿�ʼʱ��
            self.human_end_time = parts[15] #��˽���ʱ��
            self.check_user = parts[16] #���Աid
            self.review_result = parts[17] #������˽��
            self.text_pair_result = parts[18] #�����˽��
            self.text_result = parts[19] #������˽��
            self.rev_result_text = parts[20]
            self.reason_array = parts[21].split(sep) #�ܾ�����
            self.rsnid = parts[22].split(sep)
            self.audit_details = parse_audit_details(json.loads("[" + parts[23].replace(sep, ",") + "]"))
            return True
        except Exception as e:
            sys.stderr.write("error at parsing line: {}\n".format("\t".join(parts).encode("gb18030")))
            sys.stderr.write("error: {}\n".format(e))
            return False


class RejectInfo(object):
    """ͳ��ʱ����Ϣ�ṹ
    """
    def __init__(self):
        pass

    def init_from_line(self, line, sep="\t"):
        """�����ַ�����ʼ��
        """
        parts = line.strip("\n").split(sep)
        return self.init_from_parts(parts)

    def init_from_parts(self, parts, sep="\t"):
        """�����б���ʼ��
        """
        try:
            self.pip_info = parts[0]
            self.product_id = parts[1]
            self.user_id = parts[2]
            self.unit_id = parts[3]
            self.plan_id = parts[4]
            self.ad_id = parts[5]
            self.text = parts[6]
            self.url_list = parts[7]
            self.pic_list = parts[8]
            self.vedio_list = parts[9]
            self.review_result = parts[10] #������˽��
            self.text_pair_result = parts[11] #�����˽��
            self.text_result = parts[12] #������˽��
            self.reason = parts[13]
            self.rsnid = parts[14]
            self.audit_details = parts[15]
            self.ad_channel_type = parts[16]
            self.human_reject_info = parts[17]
            return True
        except Exception as e:
            sys.stderr.write("error at parsing line: {}\n".format("\t".join(parts).encode("gb18030")))
            sys.stderr.write("error: {}\n".format(e))
            return False

    def to_dict(self):
        """�����ֵ�ṹ����Ϣ
        """
        return {
                "pip_info": self.pip_info,
                "product_id": self.product_id,
                "user_id": self.user_id,
                "unit_id": self.unit_id,
                "plan_id": self.plan_id,
                "ad_id": self.ad_id,
                "text": self.text,
                "url_list": self.url_list,
                "pic_list": self.pic_list,
                "vedio_list": self.vedio_list,
                "review_result": self.review_result,
                "text_pair_result": self.text_pair_result,
                "text_result": self.text_result,
                "reason": self.reason,
                "rsnid": self.rsnid,
                "audit_details": self.audit_details,
                "ad_channel_type": self.ad_channel_type,
                "human_reject_info": self.human_reject_info
                }

    def to_str(self, sep="\t"):
        """�����ַ�����ʽ����Ϣ
        """
        return "\t".join([
                self.pip_info,
                self.product_id,
                self.user_id,
                self.unit_id,
                self.plan_id,
                self.ad_id,
                self.text,
                self.url_list,
                self.pic_list,
                self.vedio_list,
                self.review_result,
                self.text_pair_result,
                self.text_result,
                self.reason,
                self.rsnid,
                self.audit_details,
                self.ad_channel_type,
                self.human_reject_info
                ])
