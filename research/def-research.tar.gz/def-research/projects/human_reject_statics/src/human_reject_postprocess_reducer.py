#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: shenhao02@baidu.com
  Date  : 21/04/08 14:46:18
  File  : src/human_reject_postprocess_reducer.py
  Desc  : ����ܾ�����,����
"""

import sys

if __name__ == "__main__":
    count_list = list()
    for line in sys.stdin:
        each_list = line.strip().split("\t")
        key = each_list[0]
        if key == "count":
            count_list.append("\t".join(each_list))
        else:
            print("\t".join(each_list))

    for count_data in count_list:
        print(count_data)


