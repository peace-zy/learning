#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   yemin02@baidu.com
Date  :   22/01/05 18:04:14
"""

import sys
reload(sys)
sys.setdefaultencoding("gbk")
import random
import urllib
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../get_click_info" % _cur_dir)
sys.path.append("%s/../common/" % _cur_dir)


def load_userid(file_):
    """load_userid
    """
    user_dict = {}
    with open(file_, "r") as rf:
        for line in rf:
            terms = line.strip("\n").split("\t")
            uid = terms[0]
            user_dict[uid] = ""
            #domain = domain_m.get_domain2(terms[0])
            #site = domain_m.get_site(terms[0])
            #if domain!="":
            #    user_dict[site] = ""
            #if site!="":
            #    user_dict[site] = ""
    return user_dict


def reservoir_sample(sample_num, index_num):
    """reservoir_sample
    """
    cint = -1
    # index_num�� k/m (m>k)�ĸ��ʱ�ѡ��
    rint = random.randint(1, index_num)
    # û��ѡ��
    if rint > sample_num:
        return cint

    # �滻sample_list�еĵ�cint��
    cint = random.randint(1, sample_num) - 1
    return cint


def rand_by_rule(in_stream, sample_num):
    """���ݴ���ȡ������˻�id�����ȡ
    """
    old_key = ""
    sample_list = []
    index = 0
    for eachline in in_stream:
        line = eachline.strip("\n").split("\t")
        key = line[0]
        if old_key == "" or old_key == key:
            index += 1
            if index <= sample_num:
                sample_list.append(line)
            else:
                cint = reservoir_sample(sample_num, index)
                if cint != -1:
                    sample_list[cint] = line
        else:
            for ele in sample_list:
                print "\t".join(ele[1:])
            sample_list = []
            index = 1
            sample_list.append(line)
        old_key = key

    if len(sample_list) > 0:
        for ele in sample_list:
            print "\t".join(ele[1:])
   
def rand(in_stream, sample_num):
    """�������������ȡ
    """
    old_key = ""
    sample_list = []
    index = 0
    for eachline in sys.stdin:
        line = eachline.strip("\n").split("\t")
        index += 1
        if index <= sample_num:
            sample_list.append(line)
        else:
            cint = reservoir_sample(sample_num, index)
            if cint != -1:
                sample_list[cint] = line
        #print "\t".join(line[1:])

    if len(sample_list) > 0:
        for ele in sample_list:
            print "\t".join(ele[1:])


def mapper():
    """mapper
    """
    user_dict = load_userid(sys.argv[2])
    for line in sys.stdin:
        try:
            parts = line.strip("\n").split("\t")
            userid = parts[0]
            url = parts[8]
            if userid not in user_dict:
                continue
            site = parts[9] 
            domain_m = parts[10]
            key = userid + site
            print key + "\t" + "\t".join((parts[0], parts[9], parts[10], parts[7], parts[8]))
        except:
            print len(parts)


def cat():
    """cat
    """
    for line in sys.stdin:
        print line.strip("\n")


if __name__ == "__main__":
    fun_type = sys.argv[1]
    if fun_type == "mapper":
        mapper()
    elif fun_type == "reducer":
        mode = 2
        sample_num = 3
        if mode == 1:        #���������ȡ
            rand(sys.stdin, sample_num)
        elif mode == 2:      #�������ȡ
            rand_by_rule(sys.stdin, sample_num)
    elif fun_type == "cat":
        cat()
