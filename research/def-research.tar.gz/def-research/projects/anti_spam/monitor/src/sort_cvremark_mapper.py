#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: work@baidu.com
  Date  : 21/08/25 21:35:13
  File  : sort_cvremark.py
  Desc  : 
"""

import sys
#import pandas as pd
import datetime


def mapper():
    """mapper
    """
    ori_date = change_date("2018-01-01")
    for line in sys.stdin:
        line = line.decode('utf8', 'ignore').encode('gb18030', 'ignore')
        terms = line.strip("\n").split("\t")
        remark_id = terms[0]
        uid = terms[1]
        source = terms[5]
        if str(source) not in ['1', '2', '3', '5', '6', '7', '8', '13', '14', '15']:
            continue
        pz = terms[3]
        category = terms[4]
        isdel = terms[9]
        del_opid = terms[10]
        mod_time = terms[12]
        mod_time_ = change_date(mod_time)
        if mod_time_ is None or mod_time_ < ori_date:
            continue
        output = [uid, isdel, pz, category, mod_time, remark_id, del_opid]
        print ("\t".join(output))


def change_date(in_date):
    """�ַ���ת���ڣ���ʽ
    """
    try:
        if len(in_date) == 8:
            out_date = datetime.datetime.strptime(in_date, "%Y%m%d")
            return out_date 
        elif len(in_date) == 10:
            out_date = datetime.datetime.strptime(in_date, "%Y-%m-%d")
            return out_date 
        elif len(in_date) == 19:
            out_date = datetime.datetime.strptime(in_date, "%Y-%m-%d %H:%M:%S")
            return out_date
        return None
    except:
        return None


def check_date(s_mod_time, s_begin_date, s_end_date):
    """check_date
    """
    mod_time = change_date(s_mod_time[:10])
    begin_date = change_date(s_begin_date[:10])
    end_date = change_date(s_end_date[:10])
    if mod_time is None or begin_date is None or end_date is None:
        return False
    if mod_time >= begin_date and mod_time <= end_date:
        return True
    return False


def check_is_ys(pz):
    """check_is_ys
    """
    if "ϵͳ�Զ��ܾ�" in pz and "������ȡ������˽" in pz:
        return True
    if "ϵͳ�Զ��ܾ�" in pz and "���ӽٳְٶ�����" in pz:
        return True
    if "��Դ" in pz and "�Ƿ�����" in pz and "Υ������" in pz and "Υ��λ��" in pz:
        return True
    return False


def check_is_xyfj(pz):
    """check���÷��
    """
    if "��Դ:���÷��;�˻��ȼ�" in pz and "���ǰ״̬" in pz and "��ʼΥ���˻�" in pz:
        return True
    return False


def reducer(begin_date, end_date):
    """cat
    """
    for line in sys.stdin:
        terms = line.strip("\n").split("\t")
        [uid, isdel, pz, category, mod_time, remark_id, del_opid] = terms
        is_ys, is_fj = "no_ys", "no_fj"
        check_date_tag = check_date(mod_time, begin_date, end_date)
        if check_is_ys(pz) and check_date_tag:
            is_ys = "is_ys"
        if check_is_xyfj(pz) and check_date_tag:
            is_fj = "is_fj"
        terms += [is_ys, is_fj]
        print "\t".join(terms)


def reducer_1():
    """reducer
    """
    old_key = ""
    key_dict = {}
    for line in sys.stdin:
        terms = line.strip("\n").split("\t")
        key = terms[0]
        mod_time = terms[3]
        if key == old_key or old_key == "":
            key_dict.setdefault(mod_time, [])
            key_dict[mod_time] = terms
        else:
            sort_keys = sorted(key_dict.keys())
            for key in sort_keys:
                print ("\t".join(key_dict[key]))
            key_dict = {}
            key_dict.setdefault(mod_time, [])
            key_dict[mod_time] = terms
        old_key = key

    if key_dict.keys():
        sort_keys = sorted(key_dict.keys())
        for key in sort_keys:
            print ("\t".join(key_dict[key]))


if __name__ == "__main__":
    if sys.argv[1] == "mapper":
        mapper()
    elif sys.argv[1] == "reducer":
        reducer(sys.argv[2], sys.argv[3])
