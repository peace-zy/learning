#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: work@baidu.com
  Date  : 21/08/30 18:00:57
  File  : ../src/get_user_dispatcher_info.py
  Desc  : 
"""

import sys
import pandas as pd
from openpyxl import load_workbook, Workbook


def get_user_dispatcher(dispatcher_type):
    """get_user_dispatcher
    """
    last_key = "" 
    key_list = []
    for line in sys.stdin:
        terms = line.strip("\n").split("\t")
        uid = terms[0]
        site = terms[1]
        user_info = ""
        if dispatcher_type == "site":
            user_info = terms[2]
            tmp_terms = [x for x in terms[3:] if x]
            val = str(round(sum(map(float, tmp_terms)) / len(tmp_terms), 4)) if len(tmp_terms) else ""
            print("\t".join([uid, site, user_info, (",".join(set(tmp_terms)) + "|" + val).strip('|')]))
        elif dispatcher_type == "user":
            tmp_terms = [x for x in terms[2:] if x]
            val = str(round(sum(map(float, tmp_terms)) / len(tmp_terms), 4)) if len(tmp_terms) else ""
            print("\t".join([uid, site, (",".join(set(tmp_terms)) + "|" + val).strip('|')]))
        elif dispatcher_type == "process":
            if last_key == uid or last_key == "":
                key_list.append(terms[1:])
            else:
                tmp_list = []
                for item in key_list:
                    if item[0] == "":
                        continue
                    item_ = item[0] + "_" + item[-1] if item[-1] else item[0] + "_" + "NULL"
                    tmp_list.append(item_)
                site_info = " ||| ".join(tmp_list).strip('_').strip()
                site_info = site_info.strip('|').strip()
                print("\t".join([last_key, key_list[0][1], site_info]))
                key_list = []
                key_list.append(terms[1:])
            last_key = uid
    if len(key_list):
        tmp_list = []
        for item in key_list:
            if item[0] == "":
                continue
            item_ = item[0] + "_" + item[-1] if item[-1] else item[0] + "_" + "NULL"
            tmp_list.append(item_)
        site_info = " ||| ".join(tmp_list).strip('_').strip()
        site_info = site_info.strip('|').strip()
        print("\t".join([last_key, key_list[0][1], site_info]))


def get_crawl_info(file_p1, file_p2, save_file1, save_file2):
    """get_crawl_info
    """
    crawl_data = pd.read_excel(file_p1, sheet_name="δ�ٻ��û��������")
    crawl_data = crawl_data.iloc[2:]
    crawl_data = crawl_data.applymap(cut_url)
    columns = ['userid', '��ץȡ��url����', '��ץȡ��url', 'ץȡ�ɹ���url����', 
            'ץȡ�ɹ���url', '�����ץȡ��url����', '�����ץȡ��url', '���ץȡ�ɹ���url����', 
            '���ץȡ�ɹ���url', "NoneName"]
    crawl_data.columns = columns
    crawl_data.to_csv(save_file1, sep="\t", index=False, header=True)

    #risk_data = pd.read_excel(file_p, sheet_name="����userid�ķ���", header=0)
    risk_data = pd.read_csv(file_p2, sep='\t')
    risk_data.columns = ['userid', 'risk_url_num', 'risk_urls']
    risk_data = risk_data[['userid', 'risk_url_num']]
    risk_data.to_csv(save_file2, sep="\t", index=False, header=True)


def cut_url(item):
    """cut_url
    """
    if type(item) == str:
        items = item.split('|-|')[:5]
        return "||".join(items)
    return item
  

def preprocess(item):
    """preprocess 
    """
    if type(item) == str:
        item = item.replace('|-|', "||")
        item = item.strip('|').strip()
        item = item.strip('_').strip()
        item = item.strip('|').strip()
    return item


def concat_local_info(file1, file2):
    """concat_local_info
    """
    data1 = pd.read_excel(file1, sheet_name=u"δ�ٻ�Υ���˻�����")
    data2 = pd.read_csv(file2, sep="\t", encoding="gb18030", header=None)
    header = ["userid", "site", "���url����", "�������", "user���ȸ���", "site���ȸ���"]
    header += ["��˴���", "����ץȡ����", "���ץȡ����", "ץȡurl", "���ץȡurl", "�Ƿ����", "�Ƿ�Դ��"]
    data2.columns = header
    data_m = pd.merge(data1, data2)
    data_m.applymap(preprocess)

    excel_writer = pd.ExcelWriter(file1, engine="openpyxl", options={'strings_to_urls': False})
    excel_writer.book = load_workbook(excel_writer.path)
    data_m.to_excel(excel_writer, sheet_name='��δ�ٻ�Υ���˻�����', index=False)
    excel_writer.close()


def load_black_tags(filename):
    """��ȡ��ɫ��ǩ���
    ��ǩ��ʽ: tag1.1|tag1.2"\t"tag2.1|tag2.2
    """
    black_tags = []
    black_model = set()
    f = open(filename)
    for line in f.readlines():
        all_tags = line.strip('\n').decode('gb18030', 'ignore').split('\t')
        one_tags = []
        for item in all_tags:
            tags = item.split('|')
            one_tags.append(set(tags))
            m = tags[0].replace('-', '_').split('_')[0]
            l = tags[0].replace('-', '_').split('_')[1]
            black_model.add(m)
        black_tags.append(one_tags)
    f.close()
    return black_tags, black_model


if __name__ == "__main__":
    func = sys.argv[1]
    if func == "dispatcher":
        dispatcher_type = sys.argv[2]
        get_user_dispatcher(dispatcher_type)
    elif func == "crawl":
        local_file_p1 = sys.argv[2]
        local_file_p2 = sys.argv[3]
        save_file1 = sys.argv[4]
        save_file2 = sys.argv[5]
        get_crawl_info(local_file_p1, local_file_p2, save_file1, save_file2)
    elif func == "concat":
        file1 = sys.argv[2]
        file2 = sys.argv[3]
        concat_local_info(file1, file2)
