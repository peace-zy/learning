#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   yemin02@baidu.com
Date  :   22/01/05 18:04:14
"""

import sys
reload(sys)
sys.setdefaultencoding("gbk")
import random
import urllib


def statistic_mapper():
    """statistic_mapper
    """
    for line in sys.stdin:
        terms = line.strip("\n").split("\t")
        uid = terms[0]
        clk = terms[5]
        shw = terms[6]
        print("\t".join([uid, clk, shw]))


def statistic_reducer():
    """statistic_reducer
    """
    last_key = ""
    total_clk, total_shw = 0, 0
    for line in sys.stdin:
        terms = line.strip("\n").split("\t")
        uid = terms[0]
        clk, shw = 0, 0
        try:
            clk = int(terms[1])
            shw = int(terms[2])
        except:
            continue
        if last_key == "" or last_key == uid:
            total_clk += clk
            total_shw += shw
        else:
            print("\t".join([last_key, str(total_clk), str(total_shw)]))
            total_clk, total_shw = 0, 0
            total_clk += clk
            total_shw += shw
        last_key = uid
    if total_clk != 0:
        print("\t".join([last_key, str(total_clk), str(total_shw)]))


if __name__ == "__main__":
    fun_type = sys.argv[1]
    if fun_type == "mapper":
        statistic_mapper()
    elif fun_type == "reducer":
        statistic_reducer()
