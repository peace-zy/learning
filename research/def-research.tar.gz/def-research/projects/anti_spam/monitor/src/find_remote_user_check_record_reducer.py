#!/usr/bin/env python
# -*- coding:gbk -*-
"""
#Author:   gancaizhao@baidu.com
#Date  :   20/04/21 14:56:45
"""

import sys
reload(sys)
sys.setdefaultencoding("gbk")

if __name__ == "__main__":
    key_date = "None"
    tmp_sum_userids = set()
    tmp_sum_sucess_userids = set()
    tmp_sum_urls = set()
    tmp_sum_sucess_urls = set()
    tmp_sum_crawl_number = 0
    tmp_sum_crawl_sucess_number = 0
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        time_date = data[0]
        userids = data[1].split('|-|')
        sucess_userids = data[2].split('|-|')
        urls = data[3].split('|-|')
        sucess_urls = data[4].split('|-|') 
        crawl_number = int(data[5])
        crawl_sucess_number = int(data[6])
        if time_date != key_date and key_date != "None":
            output_str = []
            output_str.append(key_date)
            output_str.append('|-|'.join(tmp_sum_userids))
            output_str.append('|-|'.join(tmp_sum_sucess_userids))
            output_str.append('|-|'.join(tmp_sum_urls))
            output_str.append('|-|'.join(tmp_sum_sucess_urls))
            output_str.append(str(tmp_sum_crawl_number))
            output_str.append(str(tmp_sum_crawl_sucess_number))
            print('\t'.join(output_str)).encode('gb18030')
            tmp_sum_userids = set()
            tmp_sum_sucess_userids = set()
            tmp_sum_urls = set()
            tmp_sum_sucess_urls = set()
            tmp_sum_crawl_number = 0
            tmp_sum_crawl_sucess_number = 0
        key_date = time_date
        for userid in userids:
            if userid == '':
                continue
            tmp_sum_userids.add(userid)
        for url in urls:
            if url == '':
                continue
            tmp_sum_urls.add(url)
        for userid in userids:
            if userid == '':
                continue
            tmp_sum_sucess_userids.add(userid)
        for url in sucess_urls:
            if url == '':
                continue
            tmp_sum_sucess_urls.add(url)
        tmp_sum_crawl_number += crawl_number
        tmp_sum_crawl_sucess_number += crawl_sucess_number
    if key_date != "None":
        output_str = []
        output_str.append(key_date)
        output_str.append('|-|'.join(tmp_sum_userids))
        output_str.append('|-|'.join(tmp_sum_sucess_userids))
        output_str.append('|-|'.join(tmp_sum_urls))
        output_str.append('|-|'.join(tmp_sum_sucess_urls))
        output_str.append(str(tmp_sum_crawl_number))
        output_str.append(str(tmp_sum_crawl_sucess_number))
        print('\t'.join(output_str)).encode('gb18030')

