#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   gancaizhao@baidu.com
Date  :   20/04/12 20:58:27
"""

import sys
reload(sys)
sys.setdefaultencoding("gbk")

def load_black_users(filename):
    """��ȡδ�ٻ��û�
    """
    userids_set = set()
    f = open(filename)
    for line in f.readlines():
        data = line.strip('\n').decode('gb18030', 'ignore').split('\t')
        userid = data[0]
        userids_set.add(userid)
    f.close()
    return userids_set

def load_black_tags(filename):
    """��ȡ��ɫ��ǩ���
    ��ǩ��ʽ: tag1.1|tag1.2"\t"tag2.1|tag2.2
    """
    black_tags = []
    black_model = set()
    f = open(filename)
    for line in f.readlines():
        if line.startswith('#'):
            continue
        all_tags = line.strip('\n').decode('gb18030', 'ignore').split('\t')
        one_tags = []
        for item in all_tags:
            tags = item.split('|')
            one_tags.append(set(tags))
            m = tags[0].replace('-', '_').split('_')[0]
            l = tags[0].replace('-', '_').split('_')[1]
            black_model.add(m)
        black_tags.append(one_tags)
    f.close()
    return black_tags, black_model

if __name__ == "__main__":
    #userids_set = load_black_users(sys.argv[1])
    #check_result = '17|47|12' #sys.argv[2]
    #check_result_set = set(check_result.split('|'))
    black_tags, check_result_set = load_black_tags(sys.argv[1])
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030', 'ignore').split('\t')
        #������ݸ�ʽ:
        #1: session_id 2: url 3: ua_type 4: userid
        #5: ������� 6: ������(request_type) 7: result 8: label 9: ����Դ
        if len(data) <= 7:
            continue
        userid = data[3].strip()
        check_type = data[4]
        request_type = data[5]
        result = data[6].strip()
        label = data[7].strip()
        #if userid in userids_set and label != '0' and result in check_result_set:
        if label != '0' and result in check_result_set:
            print(line.strip('\n'))


