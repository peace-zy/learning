#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   gancaizhao@baidu.com
Date  :   20/04/12 21:10:01
"""

import sys
reload(sys)
sys.setdefaultencoding("gbk")

def load_black_tags(filename):
    """��ȡ��ɫ��ǩ���
    ��ǩ��ʽ: tag1.1|tag1.2"\t"tag2.1|tag2.2
    """
    black_tags = []
    f = open(filename)
    for line in f.readlines():
        if line.startswith("#"):
            continue
        all_tags = line.strip('\n').decode('gb18030', 'ignore').split('\t')
        one_tags = []
        for item in all_tags:
            tags = item.split('|')
            one_tags.append(set(tags))
        black_tags.append(one_tags)
    f.close()
    return black_tags

if __name__ == "__main__":
    black_tags = load_black_tags(sys.argv[1])
    null_tag = "None"
    ssid_key = null_tag
    key_url = null_tag
    key_userid = null_tag
    key_check_time = null_tag
    key_request_type = null_tag
    key_crawl_type = null_tag
    key_ua_type = null_tag
    check_result_set = set()
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030', 'ignore').split('\t')
        #������ݸ�ʽ:
        #1: session_id 2: url 3: ua_type 4: userid
        #5: ������� 6: ������(request_type) 7: result 8: label 9:crawl_type 
        session_id = data[0]
        url = data[1]
        ua_type = data[2]
        userid = data[3]
        check_time = data[4]
        request_type = data[5]
        result = data[6]
        label = data[7]
        crawl_type = data[8]
        crs = result + '_' + label
        if session_id != ssid_key and ssid_key != null_tag:
            is_black = False
            for one_black_tags in black_tags:
                #�������з���
                check_one_black = True
                for gray_tags in one_black_tags:
                    #�����������յ�ÿһ���������
                    #gray_tags��һ��set
                    check_one_item_in_one_black = False
                    for tag_item in check_result_set:
                        #�������е���ص�ÿһ��tag
                        if tag_item in gray_tags:
                            check_one_item_in_one_black = True
                            break
                    if not check_one_item_in_one_black:
                        check_one_black = False
                        break
                if check_one_black:
                    is_black = True
                    break
            if is_black:
                print('\t'.join([ssid_key, key_userid, key_url, key_check_time, \
                        '|'.join(check_result_set), key_request_type, key_crawl_type, key_ua_type])).encode('gb18030')
            check_result_set = set()
        ssid_key = session_id
        key_url = url
        key_ua_type = ua_type
        key_userid = userid
        key_check_time = check_time
        key_request_type = request_type
        key_crawl_type = crawl_type
        check_result_set.add(crs)
    if ssid_key != null_tag:
        is_black = False
        for one_black_tags in black_tags:
            #�������з���
            check_one_black = True
            for gray_tags in one_black_tags:
                #�����������յ�ÿһ���������
                #gray_tags��һ��set
                check_one_item_in_one_black = False
                for tag_item in check_result_set:
                    #�������е���ص�ÿһ��tag
                    if tag_item in gray_tags:
                        check_one_item_in_one_black = True
                        break
                if not check_one_item_in_one_black:
                    check_one_black = False
                    break
            if check_one_black:
                is_black = True
                break
        if is_black:
            print('\t'.join([ssid_key, key_userid, key_url, key_check_time, \
                    '|'.join(check_result_set), key_request_type, key_crawl_type, key_ua_type])).encode('gb18030')

