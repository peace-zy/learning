#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: work@baidu.com
  Date  : 21/09/27 21:58:23
  File  : ../../src/get_audit_risk_data.py
  Desc  : 
"""

import sys

def load_black_tags(filename):
    """��ȡ��ɫ��ǩ���
    ��ǩ��ʽ: tag1.1|tag1.2"\t"tag2.1|tag2.2
    """
    black_tags = []
    black_model = set()
    f = open(filename)
    for line in f.readlines():
        if line.startswith("#"):
            continue
        all_tags = line.strip('\n').decode('gb18030', 'ignore').split('\t')
        tag_first = all_tags[0].split('|')
        tag_second = all_tags[1].split('|') if len(all_tags)==2 else []
        for tag_f in tag_first:
            m = tag_f.replace('-', '_').split('_')[0]
            black_model.add(m)
            black_tag = tag_f
            if tag_second:
                for tag_s in tag_second:
                    m = tag_s.replace('-', '_').split('_')[0]
                    black_model.add(m)
                    black_tag += '|' + tag_s
                    black_tags.append(black_tag)
                    black_tag = tag_f
            else:
                black_tags.append(black_tag)
            black_model.add(m)
    return black_tags, black_model


def check_is_risk(all_risk_set, limit_risks):
    """�ж��Ƿ���ձ�ǩ
    """
    c_risks = []
    black_tag_ = ""
    for black_tag in limit_risks:
        tmp_set = set(black_tag.split('|'))
        if tmp_set.issubset(all_risk_set):
            c_risks.append(black_tag)
            black_tag_ = black_tag if black_tag_ == "" else black_tag_

    return c_risks, black_tag_


def mapper():
    """mapper
    """
    black_tags, black_models = load_black_tags(sys.argv[2])
    for line in sys.stdin:
        terms = line.strip('\n').split("\t")
        userids                = terms[1]
        url                    = terms[2]
        request_types          = terms[3]
        ua_type                = terms[4]
        p_cityid               = terms[5]
        p_cityname             = terms[6]
        ip                     = terms[7]
        refer                  = terms[8]
        query                  = terms[9]
        ids                    = terms[10]
        schedule_tags          = terms[11]
        schedule_types         = terms[12]
        pipelines              = terms[13]
        crawl_types            = terms[14]
        audit_results          = terms[15]
        risk_features          = terms[16]
        difloc_risks           = terms[17]
        safe_risks             = terms[18]
        schedule_time          = terms[19]
        crawl_time             = terms[20]
        audit_time             = terms[21]
        local_info             = terms[22]
        difloc_info            = terms[23]
        safer_info             = terms[24]
        uids = [uid for uid in userids.split(',') if len(uid) <= 10 and uid != '0']
        local_risk_set = set(risk_features.replace('|', ',').split(','))
        difloc_risk_set = set(difloc_risks.replace('|', ',').split(','))
        combine_risks_set = local_risk_set | difloc_risk_set
        loc_, black_tag_a = check_is_risk(local_risk_set, black_tags)
        difloc_, black_tag_b = check_is_risk(difloc_risk_set, black_tags)
        all_risks, black_tag_c = check_is_risk(combine_risks_set, black_tags)
        riskname = "gamble" if "12_" in black_tag_c else "ylwr"
        if not all_risks:
            continue
        local_type = 0
        if loc_ and not difloc_:
            local_type = 1
        elif not loc_ and difloc_:
            local_type = 2
        elif loc_ and difloc_:
            local_type = 3
        try:
            for uid in uids:
                output = [uid, url, request_types, ua_type, p_cityid, refer, crawl_types, \
                        ",".join(all_risks), black_tag_c, str(local_type), audit_time]
                print "\t".join(output)
        except:
            continue


def reducer():
    """reducer
    """
    for line in sys.stdin:
        print line.strip('\n')


if __name__ == "__main__":
    func_type = sys.argv[1]
    if func_type == "mapper":
        mapper()
    elif func_type == "reducer":
        reducer()
