#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
Author:   zhanghao55@baidu.com
Date  :   20/03/17 14:54:40
Desc  :   
"""
import os
import codecs
import sys
import pandas as pd
from collections import defaultdict
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE

import config


illegal_user_extra_stat_path = sys.argv[1]
seconde_judge_path = sys.argv[2]
inspection_reason_path = sys.argv[3]
inspection_evidence_path = sys.argv[4]
pd_version = float('.'.join(pd.__version__.split('.')[:2]))
if pd_version < 0.24:
    raise RuntimeError('pandas requires pandas 0.24.2+, got %s' %
                                   pd.__version__)

df = pd.read_excel(illegal_user_extra_stat_path, sheet_name=u'Υ���˻���Ϣ', na_values=config.empty_value, encoding="gb18030")
# ����δ�ٻص��˻���Ϣ
df = df[df[u'���Է��'] == False]
#df = df[df['���Է��'] == False]


def filter_illegal_char(text):
    """filter_illegal_char
    """
    return ILLEGAL_CHARACTERS_RE.sub(r'', text)

def main():
    """# ��ȡ���Ͷ����Υ���˻�֤��
    """
    get_evidence_data()

    # ����֤����Ϣ
    add_evidence_info()

    # ����
    # ������Ҫpandas�汾>0.24 ����û��mode���� �޷�׷��
    excel_writer = pd.ExcelWriter(illegal_user_extra_stat_path, mode='a')
    df.to_excel(excel_writer, sheet_name=u'δ�ٻ�Υ���˻�����', \
            columns=config.extra_stat_with_evidence_attrs, index=False, encoding="gb18030")
    excel_writer.close()
    print("add evidence done")

def add_evidence_info():
    """add_evidence_info
    """
    user_dict = load_user_evidence()

    def add_reason(row):
        """add_reason
        """
        userid = str(row[u'userid'])
        return filter_illegal_char('|||'.join(user_dict[userid][0])) if userid in user_dict else 'NULL'

    def add_url(row):
        """add_url
        """
        userid = str(row[u'userid'])
        return filter_illegal_char('|||'.join(user_dict[userid][1])) if userid in user_dict else 'NULL'

    def add_evidence(row):
        """add_evidence
        """
        userid = str(row[u'userid'])
        return filter_illegal_char('|||'.join(user_dict[userid][2])) if userid in user_dict else 'NULL'

    df[u'reason'] = df.apply(add_reason, axis=1)
    df[u'url'] = df.apply(add_url, axis=1)
    df[u'evidence'] = df.apply(add_evidence, axis=1)
    return df

def load_user_evidence():
    """load_user_evidence
    """
    # user_dict[userid] = (list(reason), list(url), list(evidence))
    user_dict = defaultdict(lambda:(list(), list(), list()))

    # ���ض���Υ���˻���Ϣ
    with codecs.open(seconde_judge_path, "r", "gb18030") as rf:
        for index, line in enumerate(rf):
            if index == 0:
                continue
            parts = line.strip('\n').split('\t')
            if len(parts) != 4:
                continue
            userid  = parts[0]
            reason  = parts[1]
            url     = parts[2]
            modtime = parts[3]
            if reason != '' and reason != 'NULL':
                user_dict[userid][0].append('%s(%s)' % (reason, modtime))
            if url != '' and url != 'NULL':
                user_dict[userid][1].append('%s(%s)' % (url, modtime))

    # ���ؼ���˻�Υ��ԭ��
    with codecs.open(inspection_reason_path, "r", "gb18030") as rf:
        for index, line in enumerate(rf):
            if index == 0:
                continue
            parts = line.strip('\n').split('\t')
            if len(parts) != 3:
                continue
            userid  = parts[0]
            reason  = parts[1]
            modtime = parts[2]
            if reason != '' and reason != 'NULL':
                user_dict[userid][0].append('%s(%s)' % (reason, modtime))

    # ���ؼ���˻�Υ��֤��
    with codecs.open(inspection_evidence_path, "r", "gb18030") as rf:
        for index, line in enumerate(rf):
            if index == 0:
                continue
            parts = line.strip('\n').split('\t')
            if len(parts) != 4:
                continue
            userid  = parts[0]
            url = parts[1]
            evidence  = parts[2]
            modtime = parts[3]
            if url != '' and url != 'NULL':
                user_dict[userid][1].append('%s(%s)' % (url, modtime))
            if evidence != '':
                user_dict[userid][2].append('%s(%s)' % (evidence, modtime))
    return user_dict

def get_evidence_data():
    """get_evidence_data
    """
    #db_sql = 'mysql --raw -h10.233.31.50 -P7550 -uleizihe -pU3m7Aetf8T %s -e "%s" > %s'
    db_sql = 'mysql --raw -h10.35.169.46 -P3072 -uleizihe -pU3m7Aetf8T %s -e "%s" > %s'
    
    no_inspection_sql_template = "set names gbk; select userid,\
            replace(replace(problemdesc, '\n', ' '), '\t', ' ') as problemdesc,\
            problemurl, modtime from task where userid in (%s) order by modtime desc"
    
    inspection_reason_sql_template = "set names gbk; select user_id, \
            reason, mod_time from task where user_id in (%s) order by mod_time desc"
    
    inspection_evidence_sql_template = "set names gbk; select user_id, url,\
            replace(replace(evidence_content, '\n', ' '), '\t', ' ') as evidence_content,\
            mod_time from suspected_record where user_id in (%s) order by mod_time desc"

    empty_file_template = "cat /dev/null > %s;"
    
    inspection_mask = df[u'�Ƿ���'].isin(set([u'���']))

    # ��ȡ���Ͷ�����˻�id
    print(df[~inspection_mask]['userid'].tolist())
    inspection_userid = [str(x) for x in df[inspection_mask]['userid']]
    second_judge_userid = [str(x) for x in df[~inspection_mask]['userid'].tolist()]
    #second_judge_userid = [x.encode("gbk") for x in df[~inspection_mask]['userid']]

    inspection_userid_num = len(inspection_userid)
    second_judge_userid_num = len(second_judge_userid)

    print("second_judge_userid num : %d" % second_judge_userid_num)
    print("inspection_userid num : %s" % inspection_userid_num)

    # �������洢��seconde_judge_path�� 
    if second_judge_userid_num > 0:
        no_inspection_sql = db_sql % ('DF_Teleport',\
                no_inspection_sql_template % ','.join(second_judge_userid), seconde_judge_path)
        os.system(no_inspection_sql)
    else:
        print("second judge userid empty, create empty file: %s" % seconde_judge_path)
        os.system(empty_file_template % seconde_judge_path)

    # ���ƽ̨�ܾ�����
    if inspection_userid_num > 0:
        inspection_reason_sql = db_sql % ('DF_Inspection',\
                inspection_reason_sql_template % ','.join(inspection_userid), inspection_reason_path)
        os.system(inspection_reason_sql)
        
        # ���ƽ̨֤��
        inspection_evidence_sql = db_sql % ('DF_Inspection',\
                inspection_evidence_sql_template % ','.join(inspection_userid), inspection_evidence_path)
        os.system(inspection_evidence_sql)
    else:
        print("inspection userid empty, create empty file: %s, %s" % (inspection_reason_path, inspection_evidence_path))
        os.system(empty_file_template % inspection_reason_path)
        os.system(empty_file_template % inspection_evidence_path)


if __name__ == "__main__":
    main()

