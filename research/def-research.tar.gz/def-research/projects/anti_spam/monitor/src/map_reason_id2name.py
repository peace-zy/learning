#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: work@baidu.com
  Date  : 21/10/13 19:13:36
  File  : ../src/map_reason_id2name.py
  Desc  : 
"""

import sys

def load_id2name_map(file):
    """load_id2name_map
    """
    map_dict = {}
    with open(file, "r") as rf:
        for line in rf:
            terms = line.strip('\n').split('\t')
            reason_id = terms[0]
            reason_name = terms[1]
            map_dict.setdefault(reason_id, "")
            map_dict[reason_id] = reason_name
    return map_dict


if __name__ == "__main__":
    map_dict = load_id2name_map(sys.argv[1])
    softtext_reasonid = "10021002"
    for line in sys.stdin:
        terms = line.strip('\n').split('\t')
        if terms[0] == "task_id":
            continue
        reason_ids = terms[4].split(',')
        reason_name = ""
        reason_id = reason_ids[0] if softtext_reasonid not in reason_ids else softtext_reasonid
        reason_name = map_dict[reason_id] if reason_id in map_dict else "NULL"
        terms[4] = reason_name
        print ("\t".join(terms))
