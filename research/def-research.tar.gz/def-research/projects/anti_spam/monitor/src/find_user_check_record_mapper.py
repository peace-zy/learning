#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   gancaizhao@baidu.com
Date  :   20/04/10 21:03:13
"""

import sys
reload(sys)
sys.setdefaultencoding("gbk")

def load_black_users(filename):
    """��ȡδ�ٻط����˻�id
    """
    users_set = set()
    f = open(filename)
    for line in f.readlines():
        userid = line.strip('\n').decode('gb18030', 'ignore').split('\t')[0]
        users_set.add(userid)
    f.close()
    return users_set

if __name__ == "__main__":
    users_set = load_black_users(sys.argv[1])
    user_check_url_dict = dict()
    user_crawl_sucess_url_dict = dict()
    user_remote_check_url_dict = dict()
    user_remote_crawl_sucess_url_dict = dict()

    CRAWL_SUCESS = '0'         #��ʶץȡ�ɹ�
    REMOTE_CRAWL_REQUEST = '3' #��ʶ�����ץȡ(��������)
    REMOTE_CRAWL_TYPE = '5'    #��ʶ�����ץȡ(ץȡ����)
    #������ݸ�ʽ:
    #1: session_id 2: url 3: ua_type 4: userid
    #5: ץȡ���(0:sucess, ��0:not sucess) 6: ������(request_type)
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030', 'ignore').split('\t')
        if len(data) < 7:
            continue
        userid = data[3]
        url = data[1]
        session_id = data[0]
        crawl_result = data[4]
        request_type = data[5]
        crawl_type = data[6]
        if userid not in users_set:
            continue
        #δ�ٻ��û��Ƿ�ץȡ��
        if userid not in user_check_url_dict:
            user_check_url_dict[userid] = set()
        user_check_url_dict[userid].add(url)
        #δ�ٻ��û��Ƿ�ץȡ�ɹ�
        if crawl_result.strip() == '0':
            if userid not in user_crawl_sucess_url_dict:
                user_crawl_sucess_url_dict[userid] = set()
            user_crawl_sucess_url_dict[userid].add(url)
        #δ�ٻ��û����Ƿ������ץȡ��¼
        if crawl_type == REMOTE_CRAWL_TYPE:
            if userid not in user_remote_check_url_dict:
                user_remote_check_url_dict[userid] = set()
            user_remote_check_url_dict[userid].add(url)
        #δ�ٻ��û����Ƿ������ץȡ�ɹ��ļ�¼
        if crawl_type == REMOTE_CRAWL_TYPE and crawl_result.strip() == CRAWL_SUCESS: 
            if userid not in user_remote_crawl_sucess_url_dict:
                user_remote_crawl_sucess_url_dict[userid] = set()
            user_remote_crawl_sucess_url_dict[userid].add(url)
    
    for item in user_check_url_dict.items():
        userid = item[0]
        output_str = ""
        #дץȡ����
        output_str += '\t'.join([userid, str(len(item[1])), '|-|'.join(list(item[1]))])
        #дץȡ�ɹ����ֵ�����
        if userid in user_crawl_sucess_url_dict:
            output_str += '\t' + str(len(user_crawl_sucess_url_dict[userid])) 
            output_str += '\t' + '|-|'.join(list(user_crawl_sucess_url_dict[userid]))
        else:
            output_str += '\t' + '0' + '\t' + 'None'
        #д���ץȡ��ץȡ����
        if userid in user_remote_check_url_dict:
            output_str += '\t' + str(len(user_remote_check_url_dict[userid])) 
            output_str += '\t' + '|-|'.join(list(user_remote_check_url_dict[userid]))
        else:
            output_str += '\t' + '0' + '\t' + 'None'
        #д���ץȡ�ĳɹ�ץȡ����
        if userid in user_remote_crawl_sucess_url_dict:
            output_str += '\t' + str(len(user_remote_crawl_sucess_url_dict[userid])) 
            output_str += '\t' + '|-|'.join(list(user_remote_crawl_sucess_url_dict[userid]))
        else:
            output_str += '\t' + '0' + '\t' + 'None'

        print(output_str).encode('gb18030')

