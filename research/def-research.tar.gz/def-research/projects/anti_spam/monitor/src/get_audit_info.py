#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: work@baidu.com
  Date  : 21/08/31 11:44:57
  File  : ../src/get_audit_info.py
  Desc  : 
"""

import sys

def audit_cal_mapper():
    """
    @function: audit_cal_mapper
    """
    for line in sys.stdin:
        try:
            terms = line.strip("\n").split("\t")
            userids = [x for x in terms[1].split(',') if x and x != '0' and len(x)<=10]
            crawl_type = terms[14].split('_')[0]
            for uid in userids:
                print ("\t".join([uid, crawl_type]))
        except:
            continue


def audit_cal_reducer():
    """
    @function: audit_cal_reducer
    """
    yidi_set = set(['5', "17", "33"])
    bendi_set = set(['12', "22", "28", "34", "35"])
    last_uid = ""
    uid_num, bendi_num, yidi_num  = 0, 0, 0
    for line in sys.stdin:
        terms = line.strip("\n").split("\t")
        uid = terms[0]
        crawl_type = terms[1]
        if last_uid == "" or last_uid == uid:
            uid_num += 1
            if crawl_type in yidi_set:
                yidi_num += 1
            if crawl_type in bendi_set:
                bendi_num += 1
        else:
            print ("\t".join([last_uid, str(uid_num), str(bendi_num), str(yidi_num)]))
            uid_num, bendi_num, yidi_num  = 0, 0, 0
            uid_num += 1
            if crawl_type in yidi_set:
                yidi_num += 1
            if crawl_type in bendi_set:
                bendi_num += 1
        last_uid = uid
    
    if uid_num:
        print ("\t".join([last_uid, str(uid_num), str(bendi_num), str(yidi_num)]))


if __name__ == "__main__":
    if sys.argv[1] == "mapper":
        audit_cal_mapper()
    elif sys.argv[1] == "reducer":
        audit_cal_reducer()

