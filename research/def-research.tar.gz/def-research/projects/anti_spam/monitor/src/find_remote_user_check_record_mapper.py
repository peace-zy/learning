#!/usr/bin/env python
# -*- coding:gbk -*-
"""
#Author:   gancaizhao@baidu.com
#Date  :   20/04/10 21:03:13
"""

import sys
reload(sys)
sys.setdefaultencoding("gbk")

def load_black_users(filename):
    """ ��ȡδ�ٻط����˻�id
    """
    users_set = set()
    f = open(filename)
    for line in f.readlines():
        userid = line.strip('\n').decode('gb18030', 'ignore').split('\t')[0]
        users_set.add(userid)
    f.close()
    return users_set

if __name__ == "__main__":
    #users_set = load_black_users(sys.argv[1])
    date_crawl_userid_url_dict = dict()

    CRAWL_SUCESS = '0'         #��ʶץȡ�ɹ�
    REMOTE_CRAWL_REQUEST = '3' #��ʶ�����ץȡ(��������)
    REMOTE_CRAWL_TYPE = '5'    #��ʶ�����ץȡ(ץȡ����)
    #������ݸ�ʽ:
    #1: session_id 2: url 3: ua_type 4: userid
    #5: ץȡ���(0:sucess, ��0:not sucess) 6: ������(request_type)
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030', 'ignore').split('\t')
        if len(data) < 8:
            continue
        userid = data[3]
        url = data[1]
        session_id = data[0]
        crawl_result = data[4]
        request_type = data[5]
        crawl_type = data[6]
        crawl_time = data[7].split(" ")[0]
        
        if crawl_type != REMOTE_CRAWL_TYPE:
            continue
        if crawl_time not in date_crawl_userid_url_dict:
            date_crawl_userid_url_dict[crawl_time] = [set(), set(), set(), set(), 0, 0]
        date_crawl_userid_url_dict[crawl_time][0].add(userid)
        if crawl_result == CRAWL_SUCESS:
            date_crawl_userid_url_dict[crawl_time][1].add(userid)
        date_crawl_userid_url_dict[crawl_time][2].add(url)
        if crawl_result == CRAWL_SUCESS:
            date_crawl_userid_url_dict[crawl_time][3].add(url)
        tmp_number = date_crawl_userid_url_dict[crawl_time][4] + 1
        date_crawl_userid_url_dict[crawl_time][4] = tmp_number
        if crawl_result == CRAWL_SUCESS: 
            tmp_number = date_crawl_userid_url_dict[crawl_time][5] + 1
            date_crawl_userid_url_dict[crawl_time][5] = tmp_number

    for item in date_crawl_userid_url_dict.items():
        output_str = []
        output_str.append(item[0])
        output_str.append('|-|'.join(list(item[1][0])))
        output_str.append('|-|'.join(list(item[1][1])))
        output_str.append('|-|'.join(list(item[1][2])))
        output_str.append('|-|'.join(list(item[1][3])))
        output_str.append(str(item[1][4]))
        output_str.append(str(item[1][5]))
        print('\t'.join(output_str)).encode('gb18030')
