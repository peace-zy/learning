#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: work@baidu.com
  Date  : 21/09/28 00:40:02
  File  : ../../src/remote_grasp_data_deal/deal_function.py
  Desc  : 
"""

import sys
import time
import datetime


REMOTE_CRAWL_TYPE = ['5', '17', '33']

def load_users(filename):
    """��ȡδ�ٻ�userid
    """
    users_set = set()
    f = open(filename)
    for line in f.readlines():
        data = line.strip('\n').split('\t')
        userid = data[0]
        users_set.add(userid)
    f.close()
    return users_set


def load_risk_model(file_path, source):
    """
    ��ȡ��ǰ��Ҫ���ǵķ��ղ��Լ�label������������ϵĲ��ԣ���17-1|18-1
    """
    black_tags = []
    risk_model_dict = {}
    with open(file_path, "r") as rf:
        for line in rf:
            terms = line.strip("\n").split("\t")
            if line.startswith("#"):
                continue
            in_source = terms[0]
            if source != in_source:
                continue
            cross_model = terms[1]
            riskname = terms[2]
            if cross_model.startswith("#"):
                continue
            black_tags.append(cross_model)
            risk_model_dict.setdefault(cross_model, "")
            risk_model_dict[cross_model] = riskname
    return black_tags, risk_model_dict


def check_is_risk(all_risk_set, limit_risk_set):
    """check_is_risk
    """
    c_risks = []
    for tmp_set in limit_risk_set:
        if tmp_set.issubset(all_risk_set):
            c_risks.append('|'.join(tmp_set))
    return c_risks


def check_is_risk_new(all_risk_set, black_tags_list):
    """check_is_risk_new
    """
    c_risks = []
    black_tag_ = ""
    for black_tag in black_tags_list:
        black_tags = set(black_tag.split('|'))
        if black_tags.issubset(all_risk_set):
            c_risks.append(black_tag)
            black_tag_ = black_tag_ if black_tag_ else black_tag
    return c_risks, black_tag_


def load_all_risk_user(file):
    """load_all_risk_user
    """
    all_risk_user_dict = {}
    with open(file, "r") as rf:
        for line in rf:
            terms = line.strip('\n').split('\t')
            uid = terms[0]
            risknames = set(terms[1].split("|"))
            date_set = set(terms[2].split(","))
            all_risk_user_dict.setdefault(uid, [set(), set()])
            all_risk_user_dict[uid][0] = risknames
            all_risk_user_dict[uid][1] = date_set
    return all_risk_user_dict


def save_all_risk_user(file, all_risk_user_dict):
    """save_all_risk_user
    """
    wf = open(file, "w")
    for uid, val in all_risk_user_dict.items():
        riskname = "|".join(val[0])
        dates_list = sorted(list(val[1]))
        dates = ",".join(dates_list)
        wf.write("%s\t%s\t%s\n" % (uid, riskname, dates))
    wf.close()


def func_01():
    """
    @function: ȡ�˻��������� 
    """
    userid_dict = dict()
    for line in sys.stdin:
        data = line.strip('\n').split('\t')
        crawl_types = [x.split('_')[0] for x in data[6].split(',')]
        userid = data[0]
        url = data[1]
        request_type = data[2]
        ua_type = data[3]
        p_cityid = data[4]
        refer = data[5]
        crawl_types = [x.split('_')[0] for x in data[6].split(',')]
        risk_tags = data[7]
        risk_tag = data[8] #��risk_tagsȡ��һ����ǩ
        risk_type = data[9] #1:loc 2:difloc 3:loc&difloc 0:Ĭ��
        if userid not in userid_dict:
            userid_dict[userid] = set()
        if len(userid_dict[userid]) <= 5:
            userid_dict[userid].add(url)
    for item in userid_dict.items():
        print('\t'.join([item[0], str(len(item[1])), '|-|'.join(list(item[1]))]))


def func_0():
    """func_0
    """
    userid_dict = dict()
    all_risk_user_file = sys.argv[2]
    all_risk_user_dict = load_all_risk_user(all_risk_user_file)
    gamble_labels = ['12_2', '12_3', "12_6"]
    for line in sys.stdin:
        data = line.strip('\n').split('\t')
        userid = data[0]
        url = data[1]
        request_type = data[2]
        ua_type = data[3]
        p_cityid = data[4]
        refer = data[5]
        crawl_types = [x.split('_')[0] for x in data[6].split(',')]
        risk_tags = data[7]
        risk_tag = data[8] #��risk_tagsȡ��һ����ǩ
        risk_type = data[9] #1:loc 2:difloc 3:loc&difloc 0:Ĭ��
        date = data[10].split(' ')[0].replace('-', '')
        if userid not in userid_dict:
            userid_dict[userid] = set()
        userid_dict[userid].add(url)

        riskname = "gamble" if risk_tag in gamble_labels else "yl_softtext"
        if userid not in all_risk_user_dict:
            all_risk_user_dict.setdefault(userid, [set(), set()])
        all_risk_user_dict[userid][0].add(riskname)
        all_risk_user_dict[userid][1].add(date)

    for item in userid_dict.items():
        print('\t'.join([item[0], str(len(item[1])), '||'.join(list(item[1]))]))
    save_all_risk_user(all_risk_user_file, all_risk_user_dict)


def func_1():
    """func_1
    """
    userid_dict = dict()
    for line in sys.stdin:
        data = line.strip('\n').split('\t')
        crawl_types = [x.split('_')[0] for x in data[6].split(',')]
        userid = data[0]
        url = data[1]
        request_type = data[2]
        ua_type = data[3]
        p_cityid = data[4]
        refer = data[5]
        crawl_types = [x.split('_')[0] for x in data[6].split(',')]
        risk_tags = data[7]
        risk_tag = data[8] #��risk_tagsȡ��һ����ǩ
        risk_type = data[9] #1:loc 2:difloc 3:loc&difloc 0:Ĭ��
        if set(REMOTE_CRAWL_TYPE).intersection(set(crawl_types)) and risk_type in ["2", "3"]:
            if userid not in userid_dict:
                userid_dict[userid] = set()
            userid_dict[userid].add(url)
    for item in userid_dict.items():
        print('\t'.join([item[0], str(len(item[1])), '|-|'.join(list(item[1]))]))


def func_2():
    """func_2
    """
    userid_dict = dict()
    for line in sys.stdin:
        data = line.strip('\n').split('\t')
        userid = data[0]
        url = data[1]
        request_type = data[2]
        ua_type = data[3]
        p_cityid = data[4]
        refer = data[5]
        crawl_types = [x.split('_')[0] for x in data[6].split(',')]
        risk_tags = data[7]
        risk_tag = data[8] #��risk_tagsȡ��һ����ǩ
        risk_type = data[9] #1:loc 2:difloc 3:loc&difloc 0:Ĭ��
        if len(set(crawl_types) - set(REMOTE_CRAWL_TYPE)) != 0 or risk_type in ['1']:
            if userid not in userid_dict:
                userid_dict[userid] = set()
            userid_dict[userid].add(url)
    for item in userid_dict.items():
        print('\t'.join([item[0], str(len(item[1])), '|-|'.join(list(item[1]))]))


def func_3():
    """func_3
    """
    users_set = load_users(sys.argv[2])
    userid_dict = dict()
    for line in sys.stdin:
        data = line.strip('\n').split('\t')
        userid = data[0]
        url = data[1]
        request_type = data[2]
        ua_type = data[3]
        p_cityid = data[4]
        refer = data[5]
        crawl_types = [x.split('_')[0] for x in data[6].split(',')]
        risk_tags = data[7]
        risk_tag = data[8] #��risk_tagsȡ��һ����ǩ
        risk_type = data[9] #1:loc 2:difloc 3:loc&difloc 0:Ĭ��
        if userid not in users_set:
            continue
        if userid not in userid_dict:
            userid_dict[userid] = set()
        userid_dict[userid].add(url)
    for item in userid_dict.items():
        print('\t'.join([item[0], str(len(item[1])), '|-|'.join(list(item[1]))]))


def func_4():
    """func_4
    """
    users_set = load_users(sys.argv[2])
    userid_dict = dict()
    for line in sys.stdin:
        data = line.strip('\n').split('\t')
        userid = data[0]
        url = data[1]
        request_type = data[2]
        ua_type = data[3]
        p_cityid = data[4]
        refer = data[5]
        crawl_types = [x.split('_')[0] for x in data[6].split(',')]
        risk_tags = data[7]
        risk_tag = data[8] #��risk_tagsȡ��һ����ǩ
        risk_type = data[9] #1:loc 2:difloc 3:loc&difloc 0:Ĭ��
        if userid not in users_set:
            continue
        if set(REMOTE_CRAWL_TYPE).intersection(set(crawl_types)) and risk_type in ["2", "3"]:
            if userid not in userid_dict:
                userid_dict[userid] = set()
            userid_dict[userid].add(url)
    for item in userid_dict.items():
        print('\t'.join([item[0], str(len(item[1])), '|-|'.join(list(item[1]))]))


def func_5():
    """func_5
    """
    users_set = load_users(sys.argv[2])
    userid_dict = dict()
    for line in sys.stdin:
        data = line.strip('\n').split('\t')
        userid = data[0]
        url = data[1]
        request_type = data[2]
        ua_type = data[3]
        p_cityid = data[4]
        refer = data[5]
        crawl_types = [x.split('_')[0] for x in data[6].split(',')]
        risk_tags = data[7]
        risk_tag = data[8] #��risk_tagsȡ��һ����ǩ
        risk_type = data[9] #1:loc 2:difloc 3:loc&difloc 0:Ĭ��
        if userid not in users_set:
            continue
        if len(set(crawl_types) - set(REMOTE_CRAWL_TYPE)) != 0 or risk_type in ['1']:
            if userid not in userid_dict:
                userid_dict[userid] = set()
            userid_dict[userid].add(url)
    for item in userid_dict.items():
        print('\t'.join([item[0], str(len(item[1])), '|-|'.join(list(item[1]))]))


def func_6():
    """func_6
    """
    date_all_userid_dict = dict()
    date_all_url_dict = dict()
    date_remote_userid_dict = dict()
    date_remote_url_dict = dict()
    date_no_remote_userid_dict = dict()
    date_no_remote_url_dict = dict()
    
    for line in sys.stdin:
        data = line.strip('\n').split('\t')
        userid = data[0]
        url = data[1]
        request_type = data[2]
        ua_type = data[3]
        p_cityid = data[4]
        refer = data[5]
        crawl_types = [x.split('_')[0] for x in data[6].split(',')]
        risk_tags = data[7]
        risk_tag = data[8] #��risk_tagsȡ��һ����ǩ
        risk_type = data[9] #1:loc 2:difloc 3:loc&difloc 0:Ĭ��
        check_time = data[10].split(' ')[0]

        if check_time not in date_all_userid_dict:
            date_all_userid_dict[check_time] = set()
        date_all_userid_dict[check_time].add(userid)

        if check_time not in date_all_url_dict:
            date_all_url_dict[check_time] = set()
        date_all_url_dict[check_time].add(url)

        if set(REMOTE_CRAWL_TYPE).intersection(set(crawl_types)) and risk_type in ["2", "3"]:
            if check_time not in date_remote_userid_dict:
                date_remote_userid_dict[check_time] = set()
            date_remote_userid_dict[check_time].add(userid)

            if check_time not in date_remote_url_dict:
                date_remote_url_dict[check_time] = set()
            date_remote_url_dict[check_time].add(url)            
        else:
            if check_time not in date_no_remote_userid_dict:
                date_no_remote_userid_dict[check_time] = set()
            date_no_remote_userid_dict[check_time].add(userid)

            if check_time not in date_no_remote_url_dict:
                date_no_remote_url_dict[check_time] = set()
            date_no_remote_url_dict[check_time].add(url)

    date_all_userid_list = sorted(date_all_userid_dict.items(), key = lambda x:x[0], reverse = True)
    #date_all_url_list = sorted(date_all_url_dict.items(), key = lambda x:x[0], reverse = True)
    #date_remote_userid_list = sorted(date_remote_userid_dict.items(), key = lambda x:x[0], reverse = True)
    #date_remote_url_list = sorted(date_remote_url_dict.items(), key = lambda x:x[0], reverse = True)
    #date_no_remote_userid_list = sorted(date_no_remote_userid_dict.items(), key = lambda x:x[0], reverse = True)
    #date_no_remote_url_list = sorted(date_no_remote_url_dict.items(), key = lambda x:x[0], reverse = True)
    
    print('\t'.join([u'����date', u'���з���userid��', u'���з���url��', u'���ץȡ���ַ���userid��', \
            u'���ץȡ���ַ���url��', u'�����ץȡ���ַ���userid��', u'�����ץȡ���ַ���url��'])).encode('gb18030')
    for item in date_all_userid_list:
        output_str = item[0] + '\t' + str(len(item[1]))
        output_str += '\t' + str(len(date_all_url_dict.get(item[0], set([]))))
        output_str += '\t' + str(len(date_remote_userid_dict.get(item[0], set([]))))
        output_str += '\t' + str(len(date_remote_url_dict.get(item[0], set([]))))
        output_str += '\t' + str(len(date_no_remote_userid_dict.get(item[0], set([]))))
        output_str += '\t' + str(len(date_no_remote_url_dict.get(item[0], set([]))))
        print(output_str)


def func_7():
    """jimuyu risk record preprocess
    """
    black_tags, risk_model_dict = load_risk_model(sys.argv[2], "starlink")
    date = sys.argv[3]
    for line in sys.stdin:
        try:
            data = line.strip('\n').split('\t')
            userid = data[0]
            url = data[7]
            human_reason = data[12].decode('utf8')
            #��������ܾ�
            if u"global_reason" in human_reason:
                continue
            risk_features = ""
            if len(data) == 16:
                risk_features = data[15]
            elif len(data) == 18:
                risk_features = data[17]
            elif len(data) == 19:
                risk_features == data[18]
            risk_set = set(risk_features.replace('|', ',').split(','))
            c_risks, black_tag_ = check_is_risk_new(risk_set, black_tags)
            if black_tag_:
                print line.strip('\n') + "\t" + black_tag_ + "\t" + date
        except:
            continue


def func_8():
    """get jimuyu risk user
    """
    userid_dict = dict()
    black_tags, risk_model_dict = load_risk_model(sys.argv[2], "starlink")
    all_jimu_risk_user_file = sys.argv[3]
    all_jimu_risk_user_dict = load_all_risk_user(all_jimu_risk_user_file)
    gamble_labels = ['1_2', '1_3', "1_6"]
    for line in sys.stdin:
        data = line.strip('\n').split('\t')
        userid = data[0]
        url = data[7]
        ocr_image, all_labels, all_risk_labels, risk_features, date = "", "", "", "", ""
        if len(data) == 18:
            all_labels = data[14]
            #all_risk_label_list = [x for x in all_labels.split(',') if x.split('_')[1] != "0"]
            #all_risk_labels = ",".join(all_risk_label_list)
            all_risk_labels = data[15]
            risk_features = data[16]
            date = data[17]
        elif len(data) == 20:
            ocr_image = data[13]
            all_labels = data[16]
            all_risk_labels = data[17]
            risk_features = data[18]
            date = data[19]
        else:
            continue
        risk_set = set(risk_features.replace('|', ',').split(','))
        c_risks, black_tag_ = check_is_risk_new(risk_set, black_tags)
        if not c_risks:
            continue
        if userid not in userid_dict:
            userid_dict[userid] = set()
        userid_dict[userid].add(url)

        riskname = "gamble" if black_tag_ in gamble_labels else "yl_softtext"
        if userid not in all_jimu_risk_user_dict:
            all_jimu_risk_user_dict.setdefault(userid, [set(), set()])
        all_jimu_risk_user_dict[userid][0].add(riskname)
        all_jimu_risk_user_dict[userid][1].add(date)

    for item in userid_dict.items():
        print('\t'.join([item[0], str(len(item[1])), '||'.join(list(item[1]))]))
    save_all_risk_user(all_jimu_risk_user_file, all_jimu_risk_user_dict)


def func_9():
    """�����ͻ�ȡ��������
    """
    sample_num = 3
    black_tags, risk_model_dict = load_risk_model(sys.argv[2], "LP")
    userid_dict = dict()
    for line in sys.stdin:
        data = line.strip('\n').split('\t')
        userid = data[0]
        url = data[1]
        request_type = data[2]
        ua_type = data[3]
        p_cityid = data[4]
        refer = data[5]
        crawl_type = data[6]
        crawl_types = [x.split('_')[0] for x in data[6].split(',')]
        risk_tags = data[7]
        risk_tag = data[8] #��risk_tagsȡ��һ����ǩ
        risk_type = data[9] #1:loc 2:difloc 3:loc&difloc 0:Ĭ��
        check_time = data[10]
        source = "LP"
        outinfo = [url, request_type, ua_type, refer, p_cityid, crawl_type, risk_type, risk_tag, check_time, source]
        riskname = risk_model_dict.get(risk_tag, "")
        key = userid + "#" + riskname
        if key not in userid_dict:
            userid_dict[key] = set()
        userid_dict[key].add("\t".join(outinfo))

    for key, vals in userid_dict.items():
        [userid, riskname] = key.split('#')
        count = 0
        urls = []
        break_tag = False
        for val in vals:
            val_info = val.split('\t')
            url = val_info[0]
            if count <= sample_num and not break_tag:
                urls.append(url)
            else:
                break_tag = True
            count += 1
        val_info[0] = "||".join(urls)
        print ("\t".join([userid, riskname, str(len(vals)), "\t".join(val_info)]))


def get_chinese(text):
    """get_chinese
    """
    try:
        text_u = text.decode('gb18030')
    except UnicodeDecodeError:
        try:
            text_u = text.decode('utf8')
        except:
            return ""
    chinese_text_list = []
    for uchar in text_u:
        if uchar >= u'\u4e00' and uchar <= u'\u9fa5':
            chinese_text_list.append(uchar)
        if uchar.encode('gb18030') in [',', '?', '!', ';', '��', '��', "��", "��", "��"]:
            chinese_text_list.append(uchar)
    a = "".join(chinese_text_list).encode('gb18030', 'ignore')
    return a


def func_10():
    """preprocess pagesource
    """
    for line in sys.stdin:
        data = line.strip('\n').split('\t')
        userid = data[1]
        url = data[2]
        pagesrc = data[6]
        feature = " ".join(data[7:])
        pagesrc_chinese = get_chinese(pagesrc)
        feature_chinese = get_chinese(feature)
        print ("\t".join((userid, url, pagesrc_chinese, feature_chinese)))


def func_11():
    """ func_11
    """
    sample_num = 3
    black_tags, risk_model_dict = load_risk_model(sys.argv[2], "starlink")
    userid_dict = dict()
    for line in sys.stdin:
        data = line.strip('\n').split('\t')
        userid = data[0]
        url = data[7]
        request_type = data[4]
        ua_type = "0"
        p_cityid = ""
        refer = ""
        crawl_type = ""
        risk_tags, risk_tag = "", ""
        if len(data) == 18:
            risk_tags = data[15]
            risk_tag = data[16] #��risk_tagsȡ��һ����ǩ
        elif len(data) == 20:
            risk_tags = data[17]
            risk_tag = data[18]
        else:
            continue
        risk_type = "1"    #1:loc 2:difloc 3:loc&difloc 0:Ĭ��
        check_time = data[-1]
        source = "jimuyu"
        outinfo = [url, request_type, ua_type, refer, p_cityid, crawl_type, risk_type, risk_tag, check_time, source]
        riskname = risk_model_dict.get(risk_tag, "")
        key = userid + "#" + riskname
        if key not in userid_dict:
            userid_dict[key] = set()
        userid_dict[key].add("\t".join(outinfo))

    for key, vals in userid_dict.items():
        [userid, riskname] = key.split('#')
        count = 0
        #for val in vals:
        #    if count < sample_num:
        #        print ("\t".join([userid, riskname, str(len(vals)), val]))
        #    count += 1
        urls = []
        break_tag = False
        for val in vals:
            val_info = val.split('\t')
            url = val_info[0]
            if count <= sample_num and not break_tag:
                urls.append(url)
            else:
                break_tag = True
            count += 1
        val_info[0] = "||".join(urls)
        print ("\t".join([userid, riskname, str(len(vals)), "\t".join(val_info)]))


def func_12():
    """for test
    """
    black_tags, risk_model_dict = load_risk_model(sys.argv[2], "LP")
    for line in sys.stdin:
        try:
            data = line.strip('\n').split('\t')
            userid = data[0]
            risk_features = data[6]
            risk_set = set(risk_features.replace('|', ',').split(','))
            c_risks, black_tag_ = check_is_risk_new(risk_set, black_tags)
            if black_tag_:
                print line.strip('\n') + "\t" + black_tag_
        except:
            continue


def func_13():
    """jimuyu new cal
    """
    input_date = datetime.datetime.strptime(sys.argv[2], "%Y%m%d")
    input_day = int(sys.argv[3])
    day_ = datetime.timedelta(days=-input_day)
    start_date = (input_date + day_) #.strftime('%Y%m%d')
    total_num, week_num, new_week_num = 0, 0, 0
    tag1, tag2 = False, False
    print "start_date=", start_date, " end_date=", input_date
    print "\t".join(["total_num", "����ʶ������", "��������ʶ������"])
    for line in sys.stdin:
        terms = line.strip('\n').split('\t')
        dates = terms[2].split(',')
        total_num += 1
        for date in dates:
            date = datetime.datetime.strptime(date, "%Y%m%d")
            if date <= input_date and date >= start_date:
                if tag1 == False:
                    week_num += 1
                    tag1 = True
            else:
                tag2 = True
        if tag1 and not tag2:
            new_week_num += 1
            #print line.strip()
        #if tag2:
        #    print line.strip('\n')
        tag1, tag2 = False, False
    out = map(str, [total_num, week_num, new_week_num])
    print "\t".join(out)


def func_14():
    """func_14
    """
    black_tags, risk_model_dict = load_risk_model(sys.argv[2], "starlink")
    all_uids, text_uids, ocr_uids = set(), set(), set()
    text_and_ocr_uid_set = set()
    for line in sys.stdin:
        data = line.strip('\n').split('\t')
        userid = data[0]
        url = data[7]
        risk_features = ""
        text_label_set, image_label_set = set(), set()
        if len(data) == 18:
            text_labels = data[14]
            text_label_set = set(text_labels.split(','))
            risk_features = data[16]
        elif len(data) == 20:
            text_labels, image_labels = data[15].split('||')
            text_label_set = set(text_labels.split(','))
            image_label_set = set(image_labels.split(','))
            risk_features = data[18]
        else:
            continue
        #risk_set = set(risk_features.replace('|', ',').split(','))
        #c_risks, black_tag_ = check_is_risk_new(risk_set, black_tags)
        #if not c_risks:
        #    continue
        image_c_risks, image_black_tag_ = check_is_risk_new(image_label_set, black_tags)
        text_c_risks, text_black_tag_ = check_is_risk_new(text_label_set, black_tags)
        all_uids.add(userid)
        if image_c_risks or text_c_risks:
            if image_c_risks:
                ocr_uids.add(userid)
            if text_c_risks:
                text_uids.add(userid)
        else:
            text_and_ocr_uid_set.add(userid)
    print "���з��ջ�:", len(all_uids)
    print "�����ı����ջ�:", len(text_uids), "  �������ı�:", len(text_uids - ocr_uids)
    print "����ocr���ջ�:", len(ocr_uids), "  ������ocr:", len(ocr_uids - text_uids)
    print "�����ı���ocr�Ļ�:", len(ocr_uids & text_uids)
    print "�����ı�+ocr�Ļ�:", len(text_and_ocr_uid_set)
    for uid_i in (ocr_uids - text_uids):
        print uid_i


if __name__ == "__main__":
    func_type = sys.argv[1]
    if func_type == "func_01":
        func_01()
    elif func_type == "func_0":
        func_0()
    elif func_type == "func_1":
        func_1()
    elif func_type == "func_2":
        func_2()
    elif func_type == "func_3":
        func_3()
    elif func_type == "func_4":
        func_4()
    elif func_type == "func_5":
        func_5()
    elif func_type == "func_6":
        func_6()
    elif func_type == "func_7":
        func_7()
    elif func_type == "func_8":
        func_8()
    elif func_type == "func_9":
        func_9()
    elif func_type == "func_10":
        func_10()
    elif func_type == "func_11":
        func_11()
    elif func_type == "func_12":
        func_12()
    elif func_type == "func_13":
        func_13()
    elif func_type == "func_14":
        func_14()
