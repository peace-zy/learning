#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   gancaizhao@baidu.com
Date  :   20/04/17 17:35:56
"""

import sys
reload(sys)
sys.setdefaultencoding("gbk")

def load_users(filename):
    """��ȡδ�ٻ�userid
    """
    users_set = set()
    f = open(filename)
    for line in f.readlines():
        data = line.strip('\n').decode('gb18030').split('\t')
        userid = data[0]
        users_set.add(userid)
    f.close()
    return users_set

if __name__ == "__main__":
    users_set = load_users(sys.argv[1])
    REMOTE_REQUEST_TYPE = '3'
    REMOTE_CRAWL_TYPE = '5'
    userid_dict = dict()
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        url = data[2]
        userid = data[1]
        request_type = data[5]
        crawl_type = data[6] 
        #if request_type == REMOTE_REQUEST_TYPE:
        #if REMOTE_CRAWL_TYPE == crawl_type:
        if userid not in users_set:
            continue
        if userid not in userid_dict:
            userid_dict[userid] = set()
        userid_dict[userid].add(url)
    for item in userid_dict.items():
        print('\t'.join([item[0], str(len(item[1])), '|-|'.join(list(item[1]))])).encode('gb18030')


