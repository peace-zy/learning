#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   gancaizhao@baidu.com
Date  :   20/04/19 21:35:01
"""

import sys
reload(sys)
sys.setdefaultencoding("gbk")

if __name__ == "__main__":
    date_all_userid_dict = dict()
    date_all_url_dict = dict()
    date_remote_userid_dict = dict()
    date_remote_url_dict = dict()
    date_no_remote_userid_dict = dict()
    date_no_remote_url_dict = dict()
    
    REMOTE_CRAWL_TYPE = '5'

    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        session_id = data[0]
        userid = data[1]
        url = data[2]
        check_time = data[3].split(' ')[0]
        check_result_set = data[4]
        request_type = data[5]
        crawl_type = data[6]

        if check_time not in date_all_userid_dict:
            date_all_userid_dict[check_time] = set()
        date_all_userid_dict[check_time].add(userid)

        if check_time not in date_all_url_dict:
            date_all_url_dict[check_time] = set()
        date_all_url_dict[check_time].add(url)

        if crawl_type == REMOTE_CRAWL_TYPE:
            if check_time not in date_remote_userid_dict:
                date_remote_userid_dict[check_time] = set()
            date_remote_userid_dict[check_time].add(userid)

            if check_time not in date_remote_url_dict:
                date_remote_url_dict[check_time] = set()
            date_remote_url_dict[check_time].add(url)            
        else:
            if check_time not in date_no_remote_userid_dict:
                date_no_remote_userid_dict[check_time] = set()
            date_no_remote_userid_dict[check_time].add(userid)

            if check_time not in date_no_remote_url_dict:
                date_no_remote_url_dict[check_time] = set()
            date_no_remote_url_dict[check_time].add(url)

    date_all_userid_list = sorted(date_all_userid_dict.items(), key = lambda x:x[0], reverse = True)
    #date_all_url_list = sorted(date_all_url_dict.items(), key = lambda x:x[0], reverse = True)
    #date_remote_userid_list = sorted(date_remote_userid_dict.items(), key = lambda x:x[0], reverse = True)
    #date_remote_url_list = sorted(date_remote_url_dict.items(), key = lambda x:x[0], reverse = True)
    #date_no_remote_userid_list = sorted(date_no_remote_userid_dict.items(), key = lambda x:x[0], reverse = True)
    #date_no_remote_url_list = sorted(date_no_remote_url_dict.items(), key = lambda x:x[0], reverse = True)
    
    print('\t'.join([u'����date', u'���з���userid��', u'���з���url��', u'���ץȡ���ַ���userid��', \
            u'���ץȡ���ַ���url��', u'�����ץȡ���ַ���userid��', u'�����ץȡ���ַ���url��'])).encode('gb18030')
    for item in date_all_userid_list:
        output_str = item[0] + '\t' + str(len(item[1]))
        output_str += '\t' + str(len(date_all_url_dict.get(item[0], set([]))))
        output_str += '\t' + str(len(date_remote_userid_dict.get(item[0], set([]))))
        output_str += '\t' + str(len(date_remote_url_dict.get(item[0], set([]))))
        output_str += '\t' + str(len(date_no_remote_userid_dict.get(item[0], set([]))))
        output_str += '\t' + str(len(date_no_remote_url_dict.get(item[0], set([]))))
        print(output_str).encode('gb18030')

