#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   gancaizhao@baidu.com
Date  :   20/04/10 17:09:46
"""

import sys
reload(sys)
sys.setdefaultencoding("gbk")
import xlrd
import tld

def get_subdomain(url):
    """��ȡվ��
    [in] url:str, δ������url, ��http://www.123.baidu.com/index.html
    [out]����url��վ��, �磺www.123.baidu.com
    """
    mod_url = url if url.startswith("http") else "http://" + url
    subdomain = []
    try:
        res = tld.get_tld(mod_url, as_object=True)
        if res.subdomain:
            subdomain.append(res.subdomain)
        if res.fld:
            subdomain.append(res.fld)
        return ".".join(subdomain)
    except tld.exceptions.TldDomainNotFound as e:
        return "/".join(mod_url.split("/")[0:3])
    except ValueError as e:
        return "/".join(mod_url.split("/")[0:3])

def main():
    """main
    """
    illegal_filepath = sys.argv[1]        #ÿ��δ�ٻ������ļ�
    sheet_name = sys.argv[2]              #ÿ��δ�ٻ���ϸ����sheet����
    risk_col_index = int(sys.argv[3])     #����������index
    userid_col_index = int(sys.argv[4])   #userid��index
    risk_info_name = sys.argv[5]          #��Ҫͳ�Ƶķ�������, ��|�ָ����������ƾ���
    url_col_index = int(sys.argv[6])   #url��index
    
    black_userid_set = set()
    risk_info_name_set = set([item.decode('gbk') for item in risk_info_name.split('|')])
    workbook = xlrd.open_workbook(illegal_filepath)
    worksheet = workbook.sheet_by_name(sheet_name)
    #worksheet = workbook.sheet_by_index(5)

    nrows = worksheet.nrows
    ncols = worksheet.ncols

    for row_index in range(nrows):
        if row_index == 0:
            continue
        tmp_risk_info = worksheet.cell_value(row_index, risk_col_index)
        tmp_risk_info = tmp_risk_info.decode('gbk')
        if (tmp_risk_info in risk_info_name_set) or (risk_info_name == "NULL"):
            black_userid = str(int(worksheet.cell_value(row_index, userid_col_index)))
            black_url = str(worksheet.cell_value(row_index, url_col_index)).split('(')[0]
            black_site = get_subdomain(black_url) if black_url.startswith('http') else ""
            black_userid_set.add(black_userid + "_" + black_site)
            print (black_userid + "\t" + black_site)


def func_01():
    """func_01
    """
    for line in sys.stdin:
        terms = line.strip('\n').split('\t')
        userid = terms[0]
        url = terms[1]
        black_site = get_subdomain(url) if url.startswith('http') else ""
        print (userid + "\t" + black_site)

if __name__ == "__main__":
    main()
    #func_01()
