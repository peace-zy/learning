#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhubenchang@baidu.com
Date  :   20/05/29 11:34:29
Desc  :   
"""
import sys
reload(sys)
sys.setdefaultencoding("gb18030")
import os
import json
import codecs

if __name__ == "__main__":
    source_file = "source.json"
    os.popen("curl  -L  http://fengkong.baidu.com/inspection/api/common/systemdict > %s" % ("source.json"))
    with codecs.open(source_file, "r+") as f:
        res = json.load(f)
    first_source = res["data"]["source"]["value"]
    for item in sorted(first_source.items(), key = lambda x: int(x[0])):
        print("\t".join([item[0], item[1]]).encode("gb18030"))



