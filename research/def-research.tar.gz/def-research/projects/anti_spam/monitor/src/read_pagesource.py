#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: work@baidu.com
  Date  : 21/09/28 15:07:14
  File  : ../src/read_pagesource.py
  Desc  : 
"""

import sys
import random

def load_users(filename):
    """��ȡδ�ٻ�userid
    """
    users_set = set()
    f = open(filename)
    for line in f.readlines():
        data = line.strip('\n').split('\t')
        userid = data[0]
        users_set.add(userid)
    f.close()
    return users_set


def preprocess(line):
    """preprocess
    """
    feas = [x.strip() for x in line[6:]]
    if "".join(feas) <= 100:
        return False
    return True


def reservoir_sample(sample_num, index_num):
    """reservoir_sample
    """
    cint = -1
    rint = random.randint(1, index_num)
    if rint > sample_num:
        return cint
    cint = random.randint(1, sample_num) - 1
    return cint


def rand_by_rule(sample_num):
    """���ݴ���ȡ������˻�id�����ȡ
    """
    old_key = ""
    sample_list = []
    index = 0
    for eachline in sys.stdin:
        line = eachline.strip("\n").split("\t")
        key = line[0]
        p_tag = preprocess(line) #Ԥ����
        if old_key == "" or old_key == key:
            index += 1
            if index <= 2: #��֤�г鵽
                sample_list.append(line)
            if index <= sample_num and p_tag:
                sample_list.append(line)
            else:
                cint = reservoir_sample(sample_num, index)
                if cint != -1:
                    sample_list[cint] = line
        else:
            for ele in sample_list:
                print "\t".join(ele[1:])
            sample_list = []
            index = 1
            sample_list.append(line)
        old_key = key

    if len(sample_list) > 0:
        for ele in sample_list:
            print "\t".join(ele[1:])


def mapper():
    """mapper
    """
    users_set = load_users(sys.argv[2])
    for line in sys.stdin:
        data = line.strip('\n').split('\t')
        userid = data[1]
        crawl_type = data[7].split('_')[0]
        crawl_time = data[8].split(':')[0].replace(' ', "_")
        key = "#".join((userid, crawl_time, crawl_type))
        if userid in users_set:
            print key + "\t" + key + "\t" + line.strip('\n')


def cat():
    """reducer
    """
    for line in sys.stdin:
        print line.strip('\n')


if __name__ == "__main__":
    func_type = sys.argv[1]
    if func_type == "mapper":
        mapper()
    elif func_type == "reducer":
        sample_num = 5
        rand_by_rule(sample_num)
    elif func_type == "cat":
        cat()

