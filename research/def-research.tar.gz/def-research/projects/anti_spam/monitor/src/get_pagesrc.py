#!/usr/bin/env python
# -*- coding:gbk -*-
"""
 * @file src/filter.py 
 * @brief
"""

import sys
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
sys.path.append("%s/../protobuf" % _cur_dir)
sys.path.append("%s/../proto" % _cur_dir)
print "%s/../proto" % _cur_dir

import ad_review_service_pb2
import general_ad_field_pb2
import ad_review_util_pb2
import lp_job_pb2 as lpjob
import lp_feature_pb2 as lpfeature
import datetime
import json
import random


def mapper(key, value):
    """mapper
    """
    pb = lpjob.LpJob()
    pb.ParseFromString(value)    
    for task in pb.tasks:
        ###schedule-pipe
        session_id = task.session_id
        url = task.url
        ua_type = task.ua_type
        userid = task.additional_info.userid
        if task.HasField('page_info'):
           page_info = task.page_info
           page_source = page_info.ps.src
           title = page_info.page_feature.title
           realtitle = page_info.page_feature.realtitle
           abstract = page_info.page_feature.abstract
           keywords = page_info.page_feature.keywords
           navigation = page_info.page_feature.navigation
           content = page_info.page_feature.sem_central_content
           copyright = page_info.page_feature.copyright
           links = page_info.page_feature.links
           inner_links = page_info.page_feature.inner_links
           out = [userid, url, ua_type, page_source]
           out += [title, realtitle, abstract, keywords, navigation, content, links, inner_links, copyright]
           emit(session_id, "\t".join(out))


def reducer(key, values):
    """reducer
    """
    for value in values:
        emit(key, value)
