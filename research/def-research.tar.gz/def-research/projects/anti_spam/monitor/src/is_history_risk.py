#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: work@baidu.com
  Date  : 22/01/04 15:09:19
  File  : ../src/is_history_risk.py
  Desc  : 
"""

import sys
import datetime

check_days = 30

def get_history_risk(file_, input_date):
    """get_history_risk
    """
    input_date = datetime.datetime.strptime(input_date, "%Y%m%d")
    day_ = datetime.timedelta(days=-check_days)
    start_date = (input_date + day_) #.strftime('%Y%m%d')
    risk_uid = set()
    with open(file_, "r") as rf:
        for line in rf:
            terms = line.strip('\n').split('\t')
            uid = terms[0]
            riskname = terms[1]
            dates = terms[2].split(',')
            for date_ in dates:
                date_ = datetime.datetime.strptime(date_, "%Y%m%d")
                if date_ <= input_date and date_ >= start_date:
                    risk_uid.add(uid)
                    break
    return risk_uid


if __name__ == "__main__":
    lp_risk_file = sys.argv[1]
    jimuyu_risk_file = sys.argv[2]
    input_date = sys.argv[3]
    risk_lp_user = get_history_risk(lp_risk_file, input_date)
    risk_jimuyu_user = get_history_risk(lp_risk_file, input_date)
    risk_users = risk_lp_user | risk_jimuyu_user
    for line in sys.stdin:
        terms = line.strip('\n').split('\t')
        #userid\t��ץȡ��url����\t��ץȡ��url\tץȡ�ɹ���url����\tץȡ�ɹ���url   
        #�����ץȡ��url����\t�����ץȡ��url\t���ץȡ�ɹ���url����\t���ץȡ�ɹ���url \tNoneName
        userid = terms[0]
        crawl_url = terms[2]
        dif_crawl_url = terms[6]
        if userid in risk_users:
            is_risk = "is_risk"
            print "\t".join([userid, crawl_url, dif_crawl_url, is_risk])
        else:
            print "\t".join([userid, crawl_url, dif_crawl_url, ""])
