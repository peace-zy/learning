#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   gancaizhao@baidu.com
Date  :   20/04/10 21:02:50
"""

import sys
reload(sys)
sys.setdefaultencoding("gbk")

if __name__ == "__main__":
    max_len_sample = 1000
    userid_check_url_dict = dict()
    for line in sys.stdin:
        data = line.strip('\n').decode('gb18030').split('\t')
        userid = data[0]
        
        crawl_url_number = data[1]
        urls = data[2].split('|-|')

        crawl_sucess_url_number = data[3]
        crawl_sucess_urls = data[4].split('|-|')

        crawl_remote_url_number = data[5]
        crawl_remote_urls = data[6].split('|-|')

        crawl_sucess_remote_url_number = data[7]
        crawl_sucess_remote_urls = data[8].split('|-|')

        if userid not in userid_check_url_dict:
            userid_check_url_dict[userid] = [set(), set(), set(), set()]
        for url in urls:
            #if len(userid_check_url_dict[userid]) >= max_len_sample:
            #    continue
            userid_check_url_dict[userid][0].add(url)

        if crawl_sucess_url_number != '0':
            for url in crawl_sucess_urls:
                userid_check_url_dict[userid][1].add(url)

        if crawl_remote_url_number != '0':
            for url in crawl_remote_urls:
                userid_check_url_dict[userid][2].add(url)

        if crawl_sucess_remote_url_number != '0':
            for url in crawl_sucess_remote_urls:
                userid_check_url_dict[userid][3].add(url)

    for item in userid_check_url_dict.items():
        print('\t'.join([item[0], \
                str(len(item[1][0])), '|-|'.join(list(item[1][0])), \
                str(len(item[1][1])), '|-|'.join(list(item[1][1])), \
                str(len(item[1][2])), '|-|'.join(list(item[1][2])), \
                str(len(item[1][3])), '|-|'.join(list(item[1][3]))])).encode('gb18030')

