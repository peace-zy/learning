#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: work@baidu.com
  Date  : 21/08/25 21:35:13
  File  : sort_cvremark.py
  Desc  : 
"""

import sys
#import pandas as pd
import datetime

def change_date(in_date):
    """
    change_date
    """
    s = datetime.datetime.strptime(in_date, "%Y-%m-%d %H:%M:%S")
    #s = str(s)[:10]
    return s


def reducer():
    """reducer
    """
    old_key = ""
    key_dict = {}
    for line in sys.stdin:
        terms = line.strip("\n").split("\t")
        key = terms[0]
        mod_time = terms[3]
        if key == old_key or old_key == "":
            key_dict.setdefault(mod_time, [])
            key_dict[mod_time] = terms
        else:
            sort_keys = sorted(key_dict.keys())
            for key in sort_keys:
                print ("\t".join(key_dict[key]))
            key_dict = {}
            key_dict.setdefault(mod_time, [])
            key_dict[mod_time] = terms
        old_key = key

    if key_dict.keys():
        sort_keys = sorted(key_dict.keys())
        for key in sort_keys:
            print ("\t".join(key_dict[key]))


def mapper():
    """mapper
    """
    for line in sys.stdin:
        line = line.decode('utf8', 'ignore').encode('gb18030', 'ignore')
        terms = line.strip("\n").split("\t")
        remark_id = terms[0]
        uid = terms[1]
        source = terms[5]
        if str(source) not in ['1', '2', '3', '5', '6', '7', '8', '13', '14', '15']:
            continue
        category = terms[4]
        isdel = terms[9]
        del_opid = terms[10]
        mod_time = terms[12]
        output = [uid, isdel, category, mod_time, remark_id, del_opid]
        print ("\t".join(output))


if __name__ == "__main__":
    if sys.argv[1] == "mapper":
        mapper()
    elif sys.argv[1] == "reducer":
        reducer()
