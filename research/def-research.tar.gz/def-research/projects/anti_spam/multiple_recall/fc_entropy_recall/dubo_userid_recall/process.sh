#!/bin/bash
#==================================================================================================#
# Author: work@baidu.com
# Date  : 21/11/26 17:41:57
# File  : processV2.sh
# Description: 
#==================================================================================================#

CUR_DIR=$(cd "$(dirname "$0")";pwd)

source ${CUR_DIR}/util.sh
TMP_DAY=`date +"%Y%m%d" -d "-2 days"`

CLK_FILE=${DATA_DIR}clk_info_${TMP_DAY}.txt
USER2STD_FILE=${DATA_DIR}user2std_${TMP_DAY}.txt
threshold=1.44
OUTPUT_FILE=highrisk_userid_recall_${TMP_DAY}.txt
OUTPUT_AFS=highrisk_userid_recall.txt
TARGET_AFS_DIR=/app/ecom/fengkong/aka/lp/lp_schedule_data

function init_files()
{
    if [ ! -d ${LOG_DIR} ]; then
        mkdir ${LOG_DIR}
    fi

    if [ ! -d output ]; then
        mkdir output
    fi

    if [ ! -d ${DATA_DIR} ]; then
        log_info "mkdir ${DATA_DIR}"
        mkdir ${DATA_DIR}
    fi

    if [ -f ${CLK_FILE} ];then
        log_info "rm ${CLK_FILE}"
        rm ${CLK_FILE}
    fi

    if [ -f ${CLK_FILE}.tmp ];then
        log_info "rm ${CLK_FILE}.tmp"
        rm ${CLK_FILE}.tmp
    fi

    if [ -f ${OUTPUT_FILE} ];then
        log_info "rm ${OUTPUT_FILE}"
        rm ${OUTPUT_FILE}
    fi

    if [ -f ${USER2STD_FILE} ];then
        log_info "rm ${USER2STD_FILE}"
        rm ${USER2STD_FILE}
    fi
}
#init_files
#log_info $TMP_DAY

# hadoops fs -getmerge /app/ecom/fengkong/personal/gancaizhao/cal_fc_feed_uid_click_info/fc_click_data_uid_info/${TMP_DAY} ${CLK_FILE}.tmp

# hadoops fs -getmerge /app/ecom/fengkong/personal/panlingfeng/fc_entropy_recall/${TMP_DAY}/user2std ${USER2STD_FILE}
# log_info "data download done..."

# cat ${CLK_FILE}.tmp | cut -f1 > ${CLK_FILE}
# rm ${CLK_FILE}.tmp

function download_data()
{
    hadoops fs -getmerge /app/ecom/fengkong/personal/gancaizhao/cal_fc_feed_uid_click_info/fc_click_data_uid_info/${YESTODAY} ${CLK_FILE}.tmp

    hadoops fs -getmerge /app/ecom/fengkong/personal/panlingfeng/fc_entropy_recall/${TMP_DAY}/user2std ${USER2STD_FILE}
    log_info "data download done..."

    cat ${CLK_FILE}.tmp | cut -f1 > ${CLK_FILE}
    rm ${CLK_FILE}.tmp
}


# python userid_clk_filter.py ${USER2STD_FILE} ${CLK_FILE} ${threshold} ${OUTPUT_FILE}
# log_info "process done..."
# log_info "recall dubo userids number: `wc -l ${OUTPUT_FILE}`"
# log_info "threshold : ${threshold}"

function clk_filter_recall()
{
    python userid_clk_filter.py ${USER2STD_FILE} ${CLK_FILE} ${threshold} ${OUTPUT_FILE}
    if [ $? -eq 0 ];then
        echo "python run success!"
    else
        echo "##############python run failed##########"
        exit
    fi
    echo "clk userid number: `wc -l ${CLK_FILE}`"
    log_info "process done..."
    log_info "recall dubo userids number: `wc -l ${OUTPUT_FILE}`"
    log_info "threshold : ${threshold}"
}



# cp ${OUTPUT_FILE} ${OUTPUT_AFS}
# hadoops fs -put ${OUTPUT_AFS} ${TARGET_AFS_DIR}/
# log_info "upload afs done, path: ${TARGET_AFS_DIR}/${OUTPUT_AFS}"
# rm ${OUTPUT_AFS}

function upload()
{
    # rm afs file
    hadoops fs -rm ${TARGET_AFS_DIR}/${OUTPUT_AFS}
    log_info "rm ${TARGET_AFS_DIR}/${OUTPUT_AFS}"
    # rm afs md5 file
    hadoops fs -rm ${TARGET_AFS_DIR}/${OUTPUT_AFS}.md5
    log_info "rm ${TARGET_AFS_DIR}/${OUTPUT_AFS}.md5"

    cat ${OUTPUT_FILE} | cut -f1,3 >${OUTPUT_AFS}
    hadoops fs -put ${OUTPUT_AFS} ${TARGET_AFS_DIR}/

    md5sum ${OUTPUT_AFS} > ${OUTPUT_AFS}.md5 
    hadoops fs -put ${OUTPUT_AFS}.md5 ${TARGET_AFS_DIR}/

    log_info "upload afs done, path: ${TARGET_AFS_DIR}/${OUTPUT_AFS}"
    rm ${OUTPUT_AFS}
    rm ${OUTPUT_AFS}.md5
    mv ${OUTPUT_FILE} ./output/${OUTPUT_FILE}
}

function clear_data()
{
    ls
    #input clear
    #output clear
    #log clear
}


main()
{
    init_files
    log_info $TMP_DAY
    echo "${TMP_DAY}"
    download_data
    clk_filter_recall
    upload
}

main




