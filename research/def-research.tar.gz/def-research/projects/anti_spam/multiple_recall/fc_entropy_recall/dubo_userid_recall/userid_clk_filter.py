#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: work@baidu.com
  Date  : 21/11/25 18:09:23
  File  : userid_clk_filter.py
  Desc  : 
"""

import sys
import pandas as pd

def get_df(path, cols):
    """
    get_df
    """
    df = pd.read_csv(path, header=None, sep='\t')
    df.columns = cols
    if 'userid' in cols:
        df.userid = df.userid.astype(str)
    return df


def merge(df1, df2, key='userid'):
    """
    merge two df
    """
    df = pd.merge(df1, df2, how='inner', left_on=key, right_on=key)
    return df


def check_unique(df, key='userid'):
    """
    check userid unique
    """
    userset = set(df[key].to_list())
    assert len(userset) == df.shape[0], '{} is not unique'.format(key)


if __name__ == "__main__":
    user2std_path = sys.argv[1]
    clk_user_path = sys.argv[2]
    threshold = float(sys.argv[3])
    output_file = sys.argv[4]
    
    try:
        # prepare data
        user2std = get_df(user2std_path, ['userid', 'std', 'unit_num'])
        print('prepare user2std data done...')
        clk_user = get_df(clk_user_path, ['userid'])
        print('prepare clk_user data done...')

        # merge data
        df = merge(user2std, clk_user, key='userid')
        print('merge data done...')

        dubo_df = df.loc[df['std']>=threshold][['userid', 'std']]
        dubo_df['p'] = 1.0
        dubo_df = dubo_df.sort_values(by=['std'], ascending=False)
        check_unique(dubo_df, 'userid')

        # number log
        print('all fc users number : {}'.format(user2std.shape[0]))
        print('recall dubo_user number : {}'.format(user2std.loc[user2std['std']>=threshold].shape[0]))
        print('dubo_user number after clk_filter: {}'.format(dubo_df.shape[0]))

        #save
        dubo_df.to_csv(output_file, header=None, index=None, sep='\t')
        sys.exit(0)
    except Exception as e:
        print(e)
        exit(1)
    


