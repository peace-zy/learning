#!/bin/bash

#===================================================
# Copyright (C) 2021 K All rights reserved.
# �ļ����ƣ�util.sh
# �� �� �ߣ�zhangqifan@baidu.com
# �������ڣ�2021��03��11��
# ��    ����...
#===================================================
source ~/.bash_profile


BASE_DIR=$(cd "$(dirname "$0")";pwd)
LOG_DIR="${BASE_DIR}/log/"
SRC_DIR="${BASE_DIR}/"
DATA_DIR="${BASE_DIR}/input/"
OUTPUT_DIR="${BASE_DIR}/output/"


HADOOP_PATH="/home/users/zhukaiwen/software_tool/hadoop-client-1.6.2.2/hadoop/bin/hadoop --config /home/users/zhukaiwen/software_tool/hadoop-client-1.6.2.2/hadoop/conf-fengkong-afs-shaolin"


TODAY=`date +"%Y%m%d" -d "+0 days"`
YESTODAY=`date +"%Y%m%d" -d "-1 days"`
TWO_DAYS_AGO=`date +"%Y%m%d" -d "-2 days"`
# ��־
LOG_FILE="${LOG_DIR}${TODAY}.log"


# ��־����
function exit_error()
{
    info=${1}
    time_now=`date +"%Y%m%d %H:%M:%S"`
    echo -e "ERROR, ${time_now}, ${info}!" >> ${LOG_FILE}
    exit 1
}

function log_warn()
{
    info=${1}
    time_now=`date +"%Y%m%d %H:%M:%S"`
    echo -e "WARNING, ${time_now}, ${info}!" >> ${LOG_FILE}
}

function log_info()
{
    info=${1}
    time_now=`date +"%Y%m%d %H:%M:%S"`
    echo -e "INFO, ${time_now}, ${info}!" >> ${LOG_FILE}
}

# ======���Ŀ¼ B======
function init_dirs()
{
    if [ ! -d ${LOG_DIR} ]; then
        mkdir ${LOG_DIR}
    fi
    cat /dev/null > ${LOG_FILE}

    log_info "init_dirs begin!"
    if [ ! -d ${OUTPUT_DIR} ]; then
        log_info "mkdir ${OUTPUT_DIR}"
        mkdir ${OUTPUT_DIR}
    fi

    if [ ! -d ${DATA_DIR} ]; then
        log_info "mkdir ${DATA_DIR}"
        mkdir ${DATA_DIR}
    fi
    touch ${DATA_DIR}null.txt
    log_info "init_dirs end!"
}
#init_dirs

#hadoop������ǰ׺(�������޸�)
JOB_NAME_PREFIX="plf"
#hadoop��������
QUEUE="fengkong-galaxy-online_normal"
#QUEUE="fengkong-patrol-online_normal"
#��Ⱥǰ׺
S="afs://shaolin.afs.baidu.com:9902/"
#hdfs�ϵ�python��
PYTHON_272="afs://shaolin.afs.baidu.com:9902/app/ecom/fengkong/kg/tools/python2.7.tar.gz"
PYTHON_376="afs://shaolin.afs.baidu.com:9902/app/ecom/fengkong/kg/tools/python.3.7.6.tar.gz"

WORD_SEG="afs://shaolin.afs.baidu.com:9902/app/ecom/fengkong/kg/tools/starlink_wordseg.tar.gz"

function check_ret()
{
    if [ ${1} -ne 0 ]; then
        exit 1
    fi
}

function hadoop_process()
{
    OUTPUT=$1                 #���·��
    INPUT=$2                  #��������Դ·��
    JOBNAME="${JOB_NAME_PREFIX}_$3"
    MAPPER=$4                 #mapִ��py�ļ�
    REDUCER=$5                #reduceִ��py�ļ�
    MAPPER_TASK_NUM=$6        #map���������� 
    MAPPER_NUM=$7             #mapͬʱ��ִ�е������������
    REDUCER_TASK_NUM=$8       #reduce����������
    REDUCER_NUM=$9            #reduceͬʱ��ִ�е������������
    MAPPER_DATA_FILE=${10}    #map �����ļ�
    REDUCER_DATA_FILE=${11}   #reduce �����ļ�

    ${HADOOP_PATH} fs -rmr ${OUTPUT}
    ${HADOOP_PATH} streaming \
        -D mapred.job.queue.name="${QUEUE}" \
        -D mapred.job.name="${JOBNAME}" \
        -D mapred.job.priority=HIGH \
        -D stream.memory.limit=8000 \
        -D mapred.job.map.capacity=${MAPPER_TASK_NUM} \
        -D mapred.job.reduce.capacity=${REDUCER_TASK_NUM} \
        -D mapred.map.tasks=${MAPPER_NUM} \
        -D mapred.reduce.tasks=${REDUCER_NUM} \
        -D mapred.textoutputformat.ignoreseparator=true \
        -D abaci.split.optimize.enable=false \
        -cacheArchive "${PYTHON_376}#python3.7" \
        -cacheArchive "${WORD_SEG}" \
        -file "${SRC_DIR}${MAPPER}" \
        -file "${SRC_DIR}${REDUCER}" \
        -file "${DATA_DIR}${MAPPER_DATA_FILE}" \
        -file "${DATA_DIR}${REDUCER_DATA_FILE}" \
        -input "${INPUT}" \
        -output "${OUTPUT}" \
        -mapper "python3.7/bin/python3 ${MAPPER} ${MAPPER_DATA_FILE}" \
        -reducer "python3.7/bin/python3 ${REDUCER} ${REDUCER_DATA_FILE}"

#    if [ $? -ne 0 ]; then
#        echo -e "ERROR: ${INPUT}, ${OUTPUT}, ${JOBNAME}\n"
#        log_warn "ERROR: ${INPUT}, ${OUTPUT}, ${JOBNAME}\n"
#        return 1
#    fi
}


