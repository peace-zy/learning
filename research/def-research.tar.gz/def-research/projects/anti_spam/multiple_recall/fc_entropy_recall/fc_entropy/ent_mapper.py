#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: mapper.py
Author: zhangqifan(zhangqifan01@baidu.com)
Date: 2021/08/08 15:17:45
"""
import sys
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
sys.path.append("%s/starlink_wordseg/" % _cur_dir)
#from word_seg import WordSeg
#import starlink_wordseg.word_seg as word_seg
import word_seg


def get_users(user_file):
    """
    get users
    """
    user_set = set()
    with open(user_file, 'r') as f:
        for line in f:
            line = line.strip('\n').split('\t')
            userid = line[0]
            user_set.add(userid)
    return user_set


def prepare_entropy_data(line, user_set, ignore=False):
    """
    data mapper for calc unit entropy
    """
    ret = None
    while True:
        #parts = line.strip('\n').decode('utf-8','ignore').lower().split("\t")
        parts = line.strip('\n').lower().split('\t')
        #if len(parts) != 8:
        #    break
        userid                      = parts[3]
        if userid in user_set:
            break
        unitid                      = parts[1]
        text                        = parts[5]
        ret = {
                "userid": userid,
                "unitid": unitid,
                "text": text
                }
        if True:
            break
    return ret


if __name__ == "__main__":
    ws = word_seg.WordSeg('./starlink_wordseg/worddict-1-5-7')
    filter_user = get_users(sys.argv[1])

    for line in sys.stdin:
        ret = prepare_entropy_data(line, filter_user)
        if ret:
            seg_list = ws.seg_words_utf8(ret['text'])
            if seg_list:
                seg_list = [i.strip() for i in seg_list if i]
                seg_text = " ".join(seg_list)
                print("\t".join([
                    ret["userid"] + '+' + ret["unitid"],
                    ret["text"],
                    seg_text
                    ]))
            #print(ret.encode("gb18030"))

