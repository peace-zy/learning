#!/bin/bash
#=======================================================
# Copyright (C) 2021 Baidu.com, Inc. All rights reserved.
# File:   run.sh
# Author: zhangqifan@baidu.com
#=======================================================

CUR_DIR=$(cd "$(dirname "$0")";pwd)

source ${CUR_DIR}/util.sh
lifecycle=7
del_day=`date +"%Y%m%d" -d "-${lifecycle} days"`


function calc_unit2entropy()
{
    log_info "calc unit2entropy start..."
#    input="${S}/app/ecom/fengkong/dw/fengkong_data/dwd_user_login_di_day/time_stamp=20210[4-8]*"
    #input="${S}/app/ecom/fengkong/kg/util_data/merge_idea/20210922-merge-idea/"
    input="${S}/app/ecom/fengkong/aka/bigdata/fcdb58/${TWO_DAYS_AGO}/wordinfo"
    output="${S}/app/ecom/fengkong/personal/panlingfeng/fc_entropy_recall/${TWO_DAYS_AGO}/unit2entropy"
    log_info "unit2entropy input path : ${input}"
    log_info "unit2entropy output path: ${output}"
    
    MAPPER_FILE="ent_mapper.py"
    REDUCER_FILE="ent_reducer.py"
    NULL_FILE="null.txt"
    USERIDS_FILTER="cdc_filter_user.txt"
    hadoop_process "${output}" ${input} "${TWO_DAYS_AGO}_calc_entropy" \
        ${MAPPER_FILE} ${REDUCER_FILE} 5000 5000 1500 1500 ${USERIDS_FILTER} ${NULL_FILE} 

    log_info "calc unit2entropy done..."
}

function calc_user2std()
{
    log_info "calc user2std start..."
#    input="${S}/app/ecom/fengkong/dw/fengkong_data/dwd_user_login_di_day/time_stamp=20210[4-8]*"
    #input="${S}/app/ecom/fengkong/kg/util_data/merge_idea/20210922-merge-idea/"
    input="${S}/app/ecom/fengkong/personal/panlingfeng/fc_entropy_recall/${TWO_DAYS_AGO}/unit2entropy"
    output="${S}/app/ecom/fengkong/personal/panlingfeng/fc_entropy_recall/${TWO_DAYS_AGO}/user2std"
    log_info "user2std input path : ${input}"
    log_info "user2std output path: ${output}"
    
    MAPPER_FILE="std_mapper.py"
    REDUCER_FILE="std_reducer.py"
    NULL_FILE="null.txt"
    USERIDS_FILTER="cdc_filter_user.txt"
    hadoop_process "${output}" ${input} "${TWO_DAYS_AGO}_calc_std" \
        ${MAPPER_FILE} ${REDUCER_FILE} 3000 3000 1500 1500 ${USERIDS_FILTER} ${NULL_FILE}

    log_info "calc user2std done..."
}

function clear_data()
{
    echo "/app/ecom/fengkong/personal/panlingfeng/fc_entropy_recall/${del_day}"
    hadoops fs -rmr /app/ecom/fengkong/personal/panlingfeng/fc_entropy_recall/${del_day}
    echo "clear ${del_day} data done, path: /app/ecom/fengkong/personal/panlingfeng/fc_entropy_recall/${del_day}"
}

main()
{
    calc_unit2entropy
    calc_user2std
    clear_data
}

main


