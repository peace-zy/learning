#!/usr/bin/env python
# -*- coding: gb18030 -*-
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: mapper.py
Author: zhangqifan(zhangqifan01@baidu.com)
Date: 2021/08/08 15:17:45
"""
import sys
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)

def prepare_std_data(line, ignore=False):
    """
    data mapper for calc std
    """
    ret = None
    while True:
        #parts = line.strip('\n').decode('utf-8','ignore').lower().split("\t")
        parts = line.strip('\n').lower().split('\t')
        #if len(parts) != 8:
        #    break
        userid                      = parts[0].split('+')[0]
        unit_entropy                = parts[2]
        ret = {
                "userid": userid,
                "unit_entropy": unit_entropy
                }
        if True:
            break
    return ret


if __name__ == "__main__":
    for line in sys.stdin:
        ret = prepare_std_data(line)
        if ret:
            print("\t".join([
                ret["userid"],
                ret["unit_entropy"]
                ]))
            #print(ret.encode("gb18030"))

