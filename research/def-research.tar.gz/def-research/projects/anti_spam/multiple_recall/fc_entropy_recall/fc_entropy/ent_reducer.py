#!/usr/bin/env python
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: ../src/reducer.py
Author: work(work@baidu.com)
Date: 2020/12/16 19:28:38
"""
import sys
from math import log


def process_text(text_set):
    """
    process text, set2str
    """
    text_list = list(text_set)
    text = ' '.join(text_list)
    return text


def calc_cutted_shannoEnt(cutted_text, sep=" ", avg=False):
    """
    calc shanno entropy
    """
    corpus = cutted_text.split(sep)
    #   统计每个词出现的频率
    word_freq_dict = dict()
    for word in corpus:
        if word not in word_freq_dict:
            word_freq_dict[word] = 1
        else:
            word_freq_dict[word] += 1
    # 将这个词典中的词，按照出现次数排序，出现次数越高，排序越靠前
    word_freq_dict = sorted(word_freq_dict.items(), key=lambda x:x[1], reverse=True)
    # 计算TF概率
#     word_tf = dict()
    # 信息熵
    shannoEnt = 0.0
    # 按照频率，从高到低，开始遍历，并未每个词构造一个id
    for word, freq in word_freq_dict:
        # 计算p(xi)
        prob = freq / len(corpus)
#         word_tf[word] = prob
        shannoEnt -= prob * log(prob, 2)
    if avg:
        return shannoEnt / len(corpus)
    return shannoEnt

if __name__ == "__main__":

    old_key = None
    text_set = set()

    for line in sys.stdin:
        parts = line.strip().split('\t')
        #print(parts)
        key = parts[0]
        seg_text = parts[2]
        if old_key == key:
            text_set.add(seg_text)
        else:
            if old_key:
                text = process_text(text_set)
                ent = calc_cutted_shannoEnt(text)
                print('\t'.join([old_key, text, str(ent)]))
            old_key = key
            text_set = {seg_text}
    if text_set:
        text = process_text(text_set)
        ent = calc_cutted_shannoEnt(text)
        print('\t'.join([old_key, text, str(ent)]))
