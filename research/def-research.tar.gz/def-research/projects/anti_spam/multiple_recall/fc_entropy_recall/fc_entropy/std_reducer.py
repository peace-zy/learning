#!/usr/bin/env python
########################################################################
# 
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: ../src/reducer.py
Author: work(work@baidu.com)
Date: 2020/12/16 19:28:38
"""
import sys
#import numpy as np
import math

def calc_std(ent_list):
    """
    calc std
    """
    if len(ent_list) == 1:
        return 0
    else:
        tmp = sum(ent_list)/len(ent_list)
        var = sum([(i-tmp)**2 for i in ent_list])/(len(ent_list)-1)
        std = math.sqrt(var)
        return std
        #return np.std(ent_list, ddof=1)

if __name__ == "__main__":

    old_key = None
    ent_list = []

    for line in sys.stdin:
        parts = line.strip().split('\t')
        #print(parts)
        key = parts[0]
        unit_ent = float(parts[1])
        if old_key == key:
            ent_list.append(unit_ent)
        else:
            if old_key:
                std = calc_std(ent_list)
                print('\t'.join([old_key, str(std), str(len(ent_list))]))
            old_key = key
            ent_list = [unit_ent]
    if ent_list:
        std = calc_std(ent_list)
        print('\t'.join([old_key, str(std), str(len(ent_list))]))

