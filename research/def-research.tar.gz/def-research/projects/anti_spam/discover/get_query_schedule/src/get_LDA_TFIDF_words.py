#!/usr/bin/env python3
# -*- coding: gbk -*-
"""
  Author: dangjinming@baidu.com
  Date  : 20/10/09 
  Desc  : 
"""

import jieba
import numpy as np
import math
import os
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer, TfidfVectorizer
from sklearn.decomposition import LatentDirichletAllocation
import sys

def get_softmax(scores):
    """softmax"""
    sums = sum(scores)
    scores = [score / sums for score in scores]
    scores_exp = [math.exp(i) for i in scores]
    scores_exp_sum = sum(scores_exp)
    return [score / scores_exp_sum for score in scores_exp]

def topK_words_scores(model, feature_names, n_top_words):
    """top words"""
    topK_words, topK_words_scores = [],[]
    for topic_idx, topic in enumerate(model.components_):
        topic = list(topic)
        topK_words = [feature_names[i] for i in np.argsort(topic)[:-n_top_words-1:-1]]
        topK_words_scores = [topic[i] for i in np.argsort(topic)[:-n_top_words - 1:-1]]
        topK_words_scores_softmax = get_softmax(topK_words_scores)
        return topK_words

def load_query(query_file):
    """load query"""
    all_docs = []
    one_file = ''
    with open(query_file, 'r', encoding='gb18030') as fr:
        for line in fr:
            line = line.strip().split('\t')
            if len(line) != 3:
                continue
            userid, url, query = line
            one_file += ' '.join(jieba.cut(query)) + ' , '
        all_docs.append(one_file)
    return all_docs

def load_stop_words(stop_word_file):
    """load stop words"""
    # 从文件导入停用词�?,将停用词表转换为list
    stpwrdlst = []
    with open(stop_word_file, 'r', encoding='gb18030') as fr:
        stpwrd_content = fr.read()
        stpwrdlst = stpwrd_content.splitlines()
    return stpwrdlst

def get_LDA_word(stop_word_file, query_file):
    """get_LDA_word"""
    corpus = load_query(query_file)
    stpwrdlst = load_stop_words(stop_word_file)
    c_vectorizer = CountVectorizer(stop_words=stpwrdlst)
    cntTf = c_vectorizer.fit_transform(corpus)
    tfidf_vectorizer = TfidfTransformer()
    tfidf_mat = tfidf_vectorizer.fit_transform(cntTf)
    # tf_vector = TfidfVectorizer(stop_words=stpwrdlst)
    # tfidf = tf_vector.fit_transform(corpus)
    lda = LatentDirichletAllocation(n_components=1, learning_offset=50., random_state=0)
    lda.fit(tfidf_mat)
    # docres = lda.fit_transform(tfidf_mat)
    # components_ = lda.components_
    n_top_words = 100
    tf_feature_names = c_vectorizer.get_feature_names()
    topK_words = topK_words_scores(lda, tf_feature_names, n_top_words)
    return topK_words

def get_TFIDF_word(stop_word_file, query_file):
    """get_TFIDF_word"""
    corpus = load_query(query_file)
    stpwrdlst = load_stop_words(stop_word_file)
    tfidf_model = TfidfVectorizer(stop_words=stpwrdlst)
    tfidf = tfidf_model.fit_transform(corpus)
    vsm = tfidf.toarray()
    category_keywords_li = []
    for i in range(vsm.shape[0]):
        sorted_keyword = sorted(zip(tfidf_model.get_feature_names(), vsm[i]), key=lambda x: x[1], reverse=True)
        category_keywords = [w for w in sorted_keyword[:100]]
        category_keywords_li.extend(category_keywords)
    category_keywords_li = sorted(category_keywords_li, key=lambda x:x[1], reverse=True)
    category_keywords_dict = {}
    for word, value in category_keywords_li:
        category_keywords_dict[word] = max(value, category_keywords_dict.get(word, 0))

    words = sorted(category_keywords_dict.items(), key=lambda x:x[1], reverse=True)
    words = [word for word, weight in words[:100]]
    return words

if __name__ == '__main__':
    word_type = sys.argv[1]
    stop_word_file = sys.argv[2]
    query_file = sys.argv[3]
    result_file = sys.argv[4]
    words = []
    if word_type == "LDA":
        words = get_LDA_word(stop_word_file, query_file)
    elif word_type == "TFIDF":
        words = get_TFIDF_word(stop_word_file, query_file)
    else:
        raise ValueError("unknown param %s,  only LDA or TFIDF is legal" % word_type)
    with open(result_file, 'w', encoding='gb18030') as fw:
        for word in words:
            fw.write(word + "\n")








