#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: dangjinming@baidu.com
  Date  : 20/10/09 
  Desc  : 
"""

import os
import urllib
import re
import sys

def get_risk_word(filename):
    """get_risk_word"""
    risk_word = {}
    with open(filename, 'r') as fr:
        for line in fr:
            line = line.strip().decode('gb18030', 'ignore')
            risk_word[line] = risk_word.get(line, 0) + 1
    return risk_word
def mapper():
    """mapper"""
    risk_word = get_risk_word(sys.argv[1])
    rules = set(risk_word.keys())
    pattern = '|'.join(rules)
    pattern = re.compile(pattern)
    for line in sys.stdin:
        parts = line.strip().decode('gb18030', 'ignore').split('\t')
        if len(parts) != 28:
            continue
        userid = parts[0]
        query = parts[10]
        title = parts[13]
        desc1 = parts[14]
        desc2 = parts[15]
        url = parts[24]
        url = urllib.unquote(url)
        res = re.findall(pattern, query)
        if res:
            weights = [risk_word.get(word, 0) for word in res]
            print '\t'.join([userid, query, '|'.join(res), str(sum(weights))]).encode('gb18030')

if __name__ == "__main__":
    mapper()
