#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: dangjinming@baidu.com
  Date  : 20/10/09 
  Desc  : 
"""

import sys
import os
import urllib
import re


def reducer():
    """reducer"""
    for line in sys.stdin:
        line = line.strip().decode('gb18030').split('\t')
        print '\t'.join(line).encode('gb18030')
if __name__ == "__main__":
    filename = sys.argv[1]
    reducer()
