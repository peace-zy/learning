#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: dangjinming@baidu.com
  Date  : 20/10/09 
  Desc  : 
"""

import sys
import os
import urllib

def load_url_file(url_file):
    """
    ����Υ��url
    """
    url_set = set()
    with open(url_file, 'r') as fr:
        for line in fr:
            line = line.strip().decode('gb18030', 'ignore').split('\t')
            if len(line) != 3:
                continue
            url_set.add(line[1])
    return url_set

def mapper():
    """mapper"""
    url_file = sys.argv[1]
    url_set = load_url_file(url_file)
    for line in sys.stdin:
        parts = line.strip().decode('gb18030', 'ignore').split('\t')
        if len(parts) != 28:
            continue
        userid = parts[0]
        query = parts[10]
        url = parts[24]
        if url:
            url_unquote = urllib.unquote(url)
            if url_unquote in url_set:
                print '\t'.join([userid, url, query]).encode('gb18030')

if __name__ == "__main__":
    mapper()
