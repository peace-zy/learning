#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: work@baidu.com
  Date  : 21/09/13 14:54:10
  File  : user_10query.py
  Desc  : 
"""

import sys
def user_n_querys(filename, num_query, num_words, weight_threshold):
    """
    һ��useridֻ����n��query
    """
    pre_user = None
    cur_num = 0
    with open(filename, 'r', encoding='gb18030', errors='ignore') as fr:
        for line in fr:
            line = line.strip().split('\t')
            if len(line) != 4:
                continue
            userid, query, risks, weight = line
            if len(risks.split('|')) < num_words or int(weight) < weight_threshold:
                continue
            if pre_user is None:
                pre_user = userid
                print('\t'.join(line))
                cur_num += 1
            elif pre_user == userid and cur_num < num_query:
                print('\t'.join(line))
                cur_num += 1
            elif pre_user != userid:
                pre_user = userid
                print('\t'.join(line))
                cur_num = 1

if  __name__ == "__main__":
    filename = sys.argv[1]
    num_query = int(sys.argv[2])
    num_words = int(sys.argv[3])
    weight_threshold = int(sys.argv[4])
    user_n_querys(filename, num_query, num_words, weight_threshold)
