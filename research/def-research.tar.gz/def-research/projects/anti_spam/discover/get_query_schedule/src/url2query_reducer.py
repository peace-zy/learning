#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: work@baidu.com
  Date  : 21/11/17 15:47:47
  File  : url2query_reducer.py
  Desc  : 
"""

import sys

def load_file(filename):
    """
    load file
    """
    url_set = set()
    with open(filename, 'r') as fr:
        for line in fr:
            url_set.add(line.strip().decode('gb18030', 'ignore'))
    return url_set

def reducer():
    """reducer"""
    fimename = sys.argv[1]
    for line in sys.stdin:
        line = line.strip().decode('gb18030').split('\t')
        print '\t'.join(line).encode('gb18030')

if __name__ == "__main__":
    reducer()
