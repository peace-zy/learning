#!/usr/bin/env python
# -*- coding: gbk -*-
"""
  Author: work@baidu.com
  Date  : 21/11/12 17:35:31
  File  : calcalte.py
  Desc  : 
"""

import sys
import os
import pandas as pd
import numpy as np
import datetime

def load_assess_user(pre_filename, input_date, input_day):
    """load_assess_user
    """
    input_dates = []
    input_date = datetime.datetime.strptime(input_date, "%Y%m%d")
    input_day = int(sys.argv[3])
    for d in input_day:
       day_ = datetime.timedelta(days=-input_day)


def get_norecall_uid(in_file, out_file):
    """get_norecall_uid
    """
    data1 = pd.read_excel(in_file, sheet_name=u"Υ���˻���Ϣ")
    choose_cols = ['userid', "Υ������", "������", "��עʱ��", "��Դ", "Υ��λ��", "���Ӵ�������Ϣ", "����ʱ��"]
    data2 = data1[choose_cols]
    data2 = data2.loc[data2["Υ������"].str.contains(r"��Ʊ|�Ĳ�|ҽ������|ʹ�÷Ƿ����ݽ�������", na=False)]
    data2['risk_type'] = np.where((data2['Υ������'].str.contains(r"ҽ������|ʹ�÷Ƿ����ݽ�������")), "yl_softtext", "gamble")
    out_cols = ['userid', "risk_type", "Υ������", "��עʱ��", "��Դ", "Υ��λ��", "���Ӵ�������Ϣ", "������", "����ʱ��"]
    data2.to_csv(out_file, header=False, index=0, sep="\t", columns=out_cols, encoding='gb18030')


def get_modelrecall_uid(date, out_file):
    """get_modelrecall_uid
    """
    input_date = datetime.datetime.strptime(date, "%Y%m%d")
    #input_date = input_date + datetime.timedelta(days=+1)
    input_day = 7
    day_ = datetime.timedelta(days=-input_day)
    start_date = (input_date + day_)
    wf = open(out_file, "w")
    print ("input_date=", input_date, "  start_date=", start_date)
    for line in sys.stdin:
        terms = line.strip('\n').split('\t')
        dates = terms[2].split(',')
        for date_ in dates:
            date_ = datetime.datetime.strptime(date_, "%Y%m%d")
            if date_ <= input_date and date_ >= start_date:
                wf.write(line)
                break

def load_file_1(file_):
    """load_file_1
    """
    uid_dict = {}
    with open(file_, "r") as rf:
        for line in rf:
            terms = line.strip('\n').split('\t')
            uid = terms[0]
            meg2 = terms[1]
            manager = terms[2]
            model_trade = terms[3]
            uid_dict.setdefault(uid, [""]*3)
            uid_dict[uid] = [meg2, manager, model_trade]
    return uid_dict


def load_file_2(file_):
    """load_file_2
    """
    uid_dict = {}
    with open(file_, "r") as rf:
        for line in rf:
            terms = line.strip('\n').split('\t')
            uid = terms[0]
            risk_type = terms[1]
            if "softtext" not in risk_type:
                continue
            meg2 = terms[10]
            manager = terms[6]
            model_trade = ""
            uid_dict.setdefault(uid, [""]*3)
            uid_dict[uid] = [meg2, manager, model_trade]
    return uid_dict


def load_file_3(file_):
    """load_file_3
    """
    uid_dict = {}
    with open(file_, "r") as rf:
        for line in rf:
            terms = line.strip('\n').split('\t')
            uid = terms[0]
            risk_type = terms[1]
            if "softtext" not in risk_type:
                continue
            meg2 = terms[6]
            manager = terms[3]
            model_trade = ""
            uid_dict.setdefault(uid, [""]*3)
            uid_dict[uid] = [meg2, manager, model_trade]
    return uid_dict


def load_file_4(file_):
    """load_file_4
    """
    uid_dict = {}
    with open(file_, "r") as rf:
        for line in rf:
            terms = line.strip('\n').split('\t')
            uid = terms[0]
            request_type = terms[2]
            uid_dict.setdefault(uid, set())
            uid_dict[uid].add(request_type)
    return uid_dict


def write_to_file(datas, file_):
    """write_to_file
    """
    wf = open(file_, "w")
    for data in datas:
        wf.write(data + "\n")


def judge_func(root_path, all_assess_uid_f, click_assess_uid_f, norecall_illegal_f, model_recall_f, model_audit_f):
    """judge_func
    """
    all_assess_uid = load_file_1(all_assess_uid_f)
    click_assess_uid = load_file_1(click_assess_uid_f)
    other_illegal_uid = load_file_2(norecall_illegal_f)
    model_recall_uid = load_file_3(model_recall_f)
    model_audit_info = load_file_4(model_audit_f)
    other_assess_cover_set, other_click_cover_set = set(), set()
    other_assess_nocover_set, other_click_nocover_set = set(), set()
    model_assess_cover_set, model_click_cover_set = set(), set()
    model_assess_nocover_set, model_click_nocover_set = set(), set()
    model_click_nocover_req0, model_click_nocover_req1, model_click_nocover_req9 = set(), set(), set()
    for uid in all_assess_uid:
        [meg2, manager, model_trade] = all_assess_uid[uid]
        if uid in other_illegal_uid:
            other_assess_cover_set.add(uid)
            if uid in click_assess_uid:
                other_click_cover_set.add(uid)
            else:
                other_click_nocover_set.add(uid)

        if uid in model_recall_uid:
            model_assess_cover_set.add(uid)
            if uid in click_assess_uid:
                model_click_cover_set.add(uid)
            else:
                model_click_nocover_set.add(uid)
                request_types = model_audit_info.get(uid, None)
                if request_types is None:
                    continue
                if "0" in request_types:
                    model_click_nocover_req0.add(uid)
                elif "1" in request_types:
                    model_click_nocover_req1.add(uid)
                elif request_types and set(['8', '9']):
                    model_click_nocover_req9.add(uid)

    for uid in other_illegal_uid:
        [meg2, manager, model_trade] = other_illegal_uid[uid]
        if uid not in other_assess_cover_set:
            other_assess_nocover_set.add(uid)
        if uid not in other_click_cover_set and uid not in other_assess_nocover_set:
            other_click_nocover_set.add(uid)

    for uid in model_recall_uid:
        [meg2, manager, model_trade] = model_recall_uid[uid]
        if uid not in model_assess_cover_set:
            model_assess_nocover_set.add(uid)
        if uid not in model_click_cover_set and uid not in model_assess_nocover_set:
            model_click_nocover_set.add(uid)
            request_types = model_audit_info.get(uid, None)
            if request_types is None:
                continue
            if "0" in request_types:
                model_click_nocover_req0.add(uid)
            elif "1" in request_types:
                model_click_nocover_req1.add(uid)
            elif request_types and set(['8', '9']):
                model_click_nocover_req9.add(uid)

    write_to_file(other_assess_nocover_set, root_path + "illegal_user_trade_nocover")
    write_to_file(other_click_nocover_set, root_path + "illegal_user_click_nocover")
    write_to_file(model_assess_nocover_set, root_path + "modelrisk_trade_nocver")
    write_to_file(model_click_nocover_set, root_path + "modelrisk_click_nocver")
    write_to_file(model_click_nocover_req0, root_path + "modelrisk_click_nocver.req0")
    write_to_file(model_click_nocover_req1, root_path + "modelrisk_click_nocver.req1")
    write_to_file(model_click_nocover_req9, root_path + "modelrisk_click_nocver.req9")
    other_cover_rate1 = '%.2f%%' % (len(other_assess_cover_set) / len(other_illegal_uid)* 100)
    other_cover_rate2 = '%.2f%%' % (len(other_click_cover_set) / len(other_illegal_uid)* 100)
    model_cover_rate1 = '%.2f%%' % (len(model_assess_cover_set) / len(model_recall_uid)* 100)
    model_cover_rate2 = '%.2f%%' % (len(model_click_cover_set) / len(model_recall_uid)* 100)
    print ("Ȧ��uid����: " + str(len(all_assess_uid)))
    print ("Ȧ���˻�&�е��uid����: " + str(len(click_assess_uid)))
    print ("���������ٻ�uid����: " + str(len(other_illegal_uid)))
    print ("ģ���ٻ�uid����: " + str(len(model_recall_uid)))
    all_uid = model_recall_uid.keys() | other_illegal_uid.keys()
    all_cover_uid = model_assess_cover_set | other_assess_cover_set
    all_cover_uid_rate = '%.2f%%' % (len(all_cover_uid) / len(all_uid)* 100)
    print ("��������+ģ���ٻ�uid����: " + str(len(all_uid)))
    print ("��������+ģ���ٻ�_�����ɸ���uid����: " + str(len(all_cover_uid)) + ", " + all_cover_uid_rate)
    print ("���������ٻ�_�����ɸ���uid����: " + str(len(other_assess_cover_set)) + ", " + other_cover_rate1)
    print ("���������ٻ�_����δ����uid����: " + str(len(other_assess_nocover_set)))
    print ("���������ٻ�_����&�е���ɸ���uid����: " + str(len(other_click_cover_set)) + ", " + other_cover_rate2)
    print ("���������ٻ�_����&���δ����uid����: " + str(len(other_click_nocover_set)))
    print ("ģ���ٻ�_�����ɸ���uid����: " + str(len(model_assess_cover_set))+ ", " + model_cover_rate1)
    print ("ģ���ٻ�_����δ����uid����: " + str(len(model_assess_nocover_set)))
    print ("ģ���ٻ�_����&�е���ɸ���uid����: " + str(len(model_click_cover_set))+ ", " + model_cover_rate2)
    print ("ģ���ٻ�_����&���δ����uid����: " + str(len(model_click_nocover_set)))
    print ("ģ���ٻ�_����&���δ����_req0: " + str(len(model_click_nocover_req0)))
    print ("ģ���ٻ�_����&���δ����_req1: " + str(len(model_click_nocover_req1)))
    print ("ģ���ٻ�_����&���δ����_req9: " + str(len(model_click_nocover_req9)))


if __name__ == "__main__":
    func_type = sys.argv[1]
    if func_type == "get_norecall_uid":
        get_norecall_uid(sys.argv[2], sys.argv[3])
    elif func_type == "get_modelrecall_uid":
        get_modelrecall_uid(sys.argv[2], sys.argv[3])
    elif func_type == "judge":
        root_path = sys.argv[2] + "/"
        all_assess_uid_f = root_path + "all_assess_user"
        click_assess_uid_f = root_path + "click_assess_user"
        norecall_illegal_f = root_path + "norecall_illegal_users"
        model_recall_f = root_path + "model_recall"
        model_audit_f = root_path + "model_audit_info"
        judge_func(root_path, all_assess_uid_f, click_assess_uid_f, 
                norecall_illegal_f, model_recall_f, model_audit_f)
