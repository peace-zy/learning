#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   18/02/05 18:04:14
"""

import os
import sys
reload(sys)
sys.setdefaultencoding("gbk")
import random
import urllib

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../" % _cur_dir)
from common import Common

class YlSofttextSampleAssess(object):
    """YlSofttextSampleAssess
    """
    def __init__(self, limit_trade_conf_f, unlimit_trade_conf_f, prov_city_f):
        """init
        """
        self.limit_meg2_trades, self.limit_imanager_trades, self.limit_model_trades = \
                self.load_trade_conf(limit_trade_conf_f)
        self.unlimit_meg2_trades, self.unlimit_imanager_trades, self.unlimit_model_trades = \
                self.load_trade_conf(unlimit_trade_conf_f)
        self.provn_city_map = self.load_prov_city(prov_city_f)

    def load_trade_conf(self, file_):
        """load_trade_conf
        """
        meg2_trades = set()
        imanager_trades = set()
        defuser_model_trades = set()
        with open(file_, "r") as rf:
            for line in rf:
                terms = line.strip('\n').split('\t')
                if line.startswith("#"):
                    continue
                type = terms[0]
                if type == "MEG":
                    meg2 = terms[2]
                    meg2_trades.add(meg2)
                elif type == "imanager":
                    imanager_trade = terms[1]
                    imanager_trades.add(imanager_trade)
                elif type == "defuser":
                    model_trade = terms[1]
                    defuser_model_trades.add(model_trade)
        return meg2_trades, imanager_trades, defuser_model_trades

    def load_user_org_acs_info(self, user_org_file, ssg_file):
        """load_user_org_acs_info
        """
        user_dict = {}
        with open(user_org_file, "r") as rf:
            for line in rf:
                try:
                    terms = line.strip("\n").split("\t")
                    userid = terms[0]
                    imanager_trade = terms[2]
                    meg2_trade = terms[8]
                    model_trade = "NULL"
                    if meg2_trade in self.limit_meg2_trades:
                        user_dict.setdefault(userid, ["", "", ""])
                        user_dict[userid][0] = meg2_trade
                    #if imanager_trade in self.limit_imanager_trades:
                    for limit_imanager_trade in self.limit_imanager_trades:
                        if limit_imanager_trade in imanager_trade:
                            user_dict.setdefault(userid, ["", "", ""])
                            user_dict[userid][1] = imanager_trade
                            break
                    if model_trade in self.limit_model_trades and meg2_trade not in self.unlimit_meg2_trades:
                        user_dict.setdefault(userid, ["", "", ""])
                        user_dict[userid][2] = model_trade
                except:
                    continue
        with open(ssg_file, "r") as rf:
            for line in rf:
                try:
                    terms = line.strip("\n").split("\t")
                    userid = terms[0]
                    meg2_trade = terms[4]
                    tmp_val = user_dict.get(userid, ["", "", ""])
                    if meg2_trade in self.limit_meg2_trades:
                        tmp_val[0] = meg2_trade
                        user_dict[userid] = tmp_val
                except:
                    continue
        return user_dict
    
    @staticmethod
    def get_users(save_file, userid_dict):
        """get_users
        """
        with open(save_file, "w") as wf:
            for uid, vals in userid_dict.items():
                wf.write(uid + "\t" + "\t".join(vals) + "\n")

    def load_assess_user(self, file_):
        """load_assess_user
        """
        userid_dict = {}
        with open(file_, "r") as rf:
            for line in rf:
                terms = line.strip("\n").split("\t")
                userid = terms[0]
                trades = terms[1:]
                if len(userid)>=1 and userid not in ['0']:
                    userid_dict[userid] = trades
        return userid_dict

    def load_prov_city(self, file):
        """load_prov_city
        """
        prov_city_map = {}
        with open(file, "r") as rf:
            for line in rf:
                terms = line.strip('\n').split('\t')
                prov_id = terms[0]
                city_id = terms[1]
                prov    = terms[2]
                city    = terms[3]
                id = prov_id + "_" + city_id
                city_name = prov + "_" + city
                prov_city_map.setdefault(id, "")
                prov_city_map[id] = city_name
        return prov_city_map

def reservoir_sample(sample_num, index_num):
    """reservoir_sample
    """
    cint = -1
    # index_num�� k/m (m>k)�ĸ��ʱ�ѡ��
    rint = random.randint(1, index_num)
    # û��ѡ��
    if rint > sample_num:
        return cint

    # �滻sample_list�еĵ�cint��
    cint = random.randint(1, sample_num) - 1
    return cint

def rand_by_rule(sample_num):
    """���ݴ���ȡ������˻�id�����ȡ
    """
    old_key = ""
    sample_list = []
    index = 0
    for eachline in sys.stdin:
        line = eachline.strip("\n").split("\t")
        key = line[0]
        if old_key == "" or old_key == key:
            index += 1
            if index <= sample_num:
                sample_list.append(line)
            else:
                cint = reservoir_sample(sample_num, index)
                if cint != -1:
                    sample_list[cint] = line
        else:
            for ele in sample_list:
                print "\t".join(ele[1:])
            sample_list = []
            index = 1
            sample_list.append(line)
        old_key = key

    if len(sample_list) > 0:
        for ele in sample_list:
            print "\t".join(ele[1:])
   
def rand(sample_num):
    """�������������ȡ
    """
    old_key = ""
    sample_list = []
    index = 0
    for eachline in sys.stdin:
        line = eachline.strip("\n").split("\t")
        index += 1
        if index <= sample_num:
            sample_list.append(line)
        else:
            cint = reservoir_sample(sample_num, index)
            if cint != -1:
                sample_list[cint] = line
        #print "\t".join(line[1:])
    if len(sample_list) > 0:
        for ele in sample_list:
            print "\t".join(ele[1:])

def mapper(assess_userids, prov_city_map, input="click"):
    """mapper
    """
    for line in sys.stdin:
        try:
            terms = line.strip("\n").split("\t")
            userid = terms[0] if input == "click" else terms[1]
            url = urllib.unquote(terms[23]) if input == "click" else terms[2]
            target_url = urllib.unquote(terms[24]) if input == "click" else terms[2]
            if input == "click":
                terms[23] = url
                terms[24] = target_url
            prov = terms[25] if input == "click" else terms[5]
            city = terms[26] if input == "click" else terms[6]
            prov_city_id = prov + "_" + city
            prov_city = prov_city_map.get(prov_city_id, prov_city_id)
            host = Common.get_domain(target_url)
            user_trades = assess_userids.get(userid, None)
            if user_trades is None:
                continue
            key = "\x01".join([userid, host])
            print key + "\t" + host + "\t" + prov_city + "\t" + "\t".join(terms) + "\t" + "\t".join(user_trades)
        except:
            continue

def cat(start_col):
    """cat
    """
    for line in sys.stdin:
        term = line.strip('\n').split('\t')
        print "\t".join(term[start_col:])

def random_choose_user(click_file, lp_file, all_choosed_user_f, current_all_user_f, current_choose_user_f):
    """all_user
    """
    uid_dict = {}
    with open(click_file, "r") as rf:
        for line in rf:
            terms = line.strip('\n').split('\t')
            userid = terms[2]
            host = terms[0]
            uid_dict.setdefault(userid, set())
            uid_dict[userid].add(host)
    with open(lp_file, "r") as rf:
        for line in rf:
            terms = line.strip('\n').split('\t')
            userid = terms[3]
            host = terms[0]
            uid_dict.setdefault(userid, set())
            uid_dict[userid].add(host)
    all_choosed_user_set = set()
    with open(all_choosed_user_f, "r") as rf:
        for line in rf:
            terms = line.strip('\n').split('\t')
            userid = terms[0]
            all_choosed_user_set.add(userid)
  
    filter_host = set(["wejianzhan.com", "baidu.com"])
    wf1 = open(current_all_user_f, "w")
    wf2 = open(current_choose_user_f, "w")
    filter_all_user = set()
    for uid, vals in uid_dict.items():
        filter_set = vals - filter_host
        if filter_set:
            wf1.write('\t'.join([uid, ",".join(vals), str(len(vals)), "in"]) + "\n")
            filter_all_user.add(uid)
        else:
            wf1.write('\t'.join([uid, ",".join(vals), str(len(vals)), "out"]) + "\n")
    current_user_diff = list(filter_all_user - all_choosed_user_set)
    current_choose_user_list = random.sample(current_user_diff, 1000)
    for uid in current_choose_user_list:
        wf2.write(uid + "\n")
   

if __name__ == "__main__":
    func_type = sys.argv[1]
    date = ""
    if "|" in func_type:
        func_vals = func_type.split('|')
        func_type = func_vals[0]
        date = func_vals[1]
    limit_trade_conf_f = "../data/limit_trades_conf.txt"
    unlimit_trade_conf_f = "../data/unlimit_trades_conf.txt"
    user_conf_f = "../data/user_org_acs_info.txt"
    ssg_f = "../data/userid_ssg_trade_day.txt"
    assess_user_f = "../data/assess_userids.txt"
    prov_city_f = "../data/provn_city_map.txt"
    if func_type in ["mapper", "reducer"]:
        limit_trade_conf_f = "./data/limit_trades_conf.txt"
        unlimit_trade_conf_f = "./data/unlimit_trades_conf.txt"
        prov_city_f = "./data/provn_city_map.txt"
        assess_user_f = "./data/assess_userids.txt"
    
    if func_type == "mapper":
        ylsofttext_sample = YlSofttextSampleAssess(limit_trade_conf_f, unlimit_trade_conf_f, prov_city_f)
        assess_userids = ylsofttext_sample.load_assess_user(assess_user_f)
        input_type = sys.argv[2]
        mapper(assess_userids, ylsofttext_sample.provn_city_map, input_type)
    elif func_type == "reducer":
        mode = int(sys.argv[2])
        sample_num = int(sys.argv[3])
        if mode == 1:        #���������ȡ
            rand(sample_num)
        elif mode == 2:      #�������ȡ
            rand_by_rule(sample_num)
    elif func_type == "cat":
        cat(int(sys.argv[2]))
    elif func_type == "get_trade_user":
        ylsofttext_sample = YlSofttextSampleAssess(limit_trade_conf_f, unlimit_trade_conf_f, prov_city_f)
        save_file = sys.argv[2]
        userid_dict = ylsofttext_sample.load_user_org_acs_info(user_conf_f, ssg_f)
        ylsofttext_sample.get_users(save_file, userid_dict)
    elif func_type == "choose_user":
        click_file = sys.argv[2]
        lp_file = sys.argv[3]
        all_choosed_user_f = sys.argv[4]
        current_all_user_f = sys.argv[5]
        current_choose_user_f = sys.argv[6]
        random_choose_user(click_file, lp_file, all_choosed_user_f, current_all_user_f, current_choose_user_f)
