#!/bin/bash
#=======================================================
# Copyright (C) 2020 Baidu.com, Inc. All rights reserved.
# File:   2_train.sh
# Author: zhuxiaodong01@baidu.com
# Date:   20200326 18:01:30
# Desc:   ģ��ѵ��ģ��
#=======================================================

if [ $# -ne 1 ]; then
    echo -e "error: sh 2_train.sh [train_type]"
    exit 1
fi

# �ļ��е�ַ
BASE_DIR=$(cd "$(dirname "$0")";pwd)
COMMON_DIR="${BASE_DIR}/../common/"
LOG_DIR="${BASE_DIR}/../log/"
DATA_DIR="${BASE_DIR}/../data/"
MID_DIR="${BASE_DIR}/../mid/"
PREPROCESS_DIR="${BASE_DIR}/../preprocess/"
MODEL_DIR="${BASE_DIR}/../model/"

export CUDA_VISIBLE_DEVICES=0

TRAIN_TYPE=${1}

if [[ ${TRAIN_TYPE} == "LR" ]]; then
    echo "train model type: LR"
    python ${PREPROCESS_DIR}main.py \
        --type "liblinear" \
        --sample_file "${MID_DIR}train.txt" \
        --process_file "${MID_DIR}train_format.txt" \
        --is_train
    python ${PREPROCESS_DIR}main.py \
        --type "liblinear" \
        --sample_file "${MID_DIR}test.txt" \
        --process_file "${MID_DIR}val_format.txt"
    ${MODEL_DIR}liblinear/train -s 0 ${MID_DIR}train_format.txt ${MID_DIR}model.txt
    ${MODEL_DIR}liblinear/predict -b 1 ${MID_DIR}val_format.txt ${MID_DIR}model.txt ${MID_DIR}output.txt

elif [[ ${TRAIN_TYPE} == "BI-LSTM" ]] || \
     [[ ${TRAIN_TYPE} == "BOW" ]] || \
     [[ ${TRAIN_TYPE} == "CNN" ]] || \
     [[ ${TRAIN_TYPE} == "GRU" ]] || \
     [[ ${TRAIN_TYPE} == "TEXTCNN" ]] || \
     [[ ${TRAIN_TYPE} == "LSTM" ]] || \
     [[ ${TRAIN_TYPE} == "ERNIE" ]] || \
     [[ ${TRAIN_TYPE} == "ERNIE+BI-LSTM" ]]
then
    echo "train model type: ${TRAIN_TYPE}"
    network=""
    if [[ ${TRAIN_TYPE} == "BI-LSTM" ]]; then
        network="bilstm_net"
    elif [[ ${TRAIN_TYPE} == "BOW" ]]; then
        network="bow_net"
    elif [[ ${TRAIN_TYPE} == "CNN" ]]; then
        network="cnn_net"
    elif [[ ${TRAIN_TYPE} == "GRU" ]]; then
        network="gru_net"
    elif [[ ${TRAIN_TYPE} == "LSTM" ]]; then
        network="lstm_net"
    elif [[ ${TRAIN_TYPE} == "TEXTCNN" ]]; then
        network="textcnn_net"
    elif [[ ${TRAIN_TYPE} == "ERNIE" ]]; then
        network="ernie_net"
    elif [[ ${TRAIN_TYPE} == "ERNIE+BI-LSTM" ]]; then
        network="ernie_bilstm_net"
    fi
    python ${PREPROCESS_DIR}vocab.py \
        --train_file "${MID_DIR}train.txt" \
        --vocab_file "${MID_DIR}vocab.txt" #--word_seg
    # default off mode for using cuda, if you have gpu, set use_uda true
    python -u ${MODEL_DIR}paddle/run_classifier.py \
        --task_name ${TRAIN_TYPE} \
        --use_cuda false \
        --do_train true \
        --do_val true \
        --do_infer false \
        --batch_size 32 \
        --data_dir ${MID_DIR} \
        --vocab_path ${MID_DIR}vocab.txt \
        --checkpoints ${MID_DIR} \
        --save_steps 200 \
        --validation_steps 200 \
        --epoch 3 \
        --model_type ${network} \
        --num_labels 6 \
        --max_seq_len 256 \
        --skip_steps 10
    # infer demo, revise init_chekpoint for the best step
    #python -u ${MODEL_DIR}paddle/run_classifier.py \
    #    --task_name ${TRAIN_TYPE} \
    #    --use_cuda false \
    #    --do_train false \
    #    --do_val false \
    #    --do_infer true \
    #    --batch_size 10 \
    #    --data_dir ${MID_DIR} \
    #    --vocab_path ${MID_DIR}vocab.txt \
    #    --init_checkpoint ${MID_DIR}step_2000/ \
    #    --model_type ${network} \
    #    --num_labels 6 \
    #    --max_seq_len 256
fi


