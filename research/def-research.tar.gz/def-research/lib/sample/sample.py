#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   20/01/06 10:53:46
Desc  :   
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")

import os
import logging
import datetime
import hashlib
import json

from mysql import MysqlOperation

_cur_dir = os.path.dirname(os.path.abspath(__file__))

timenow = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
logging.basicConfig(level = logging.INFO,
        format = "%(asctime)s %(filename)s %(funcName)s %(levelname)s, %(message)s",
        filename = "%s/../log/%s_log.txt" % (_cur_dir, timenow))
logger = logging.getLogger(__name__)

LABEL_DEPTH = 3
PATH_ROOT = "/home/work/samples/"
CARRIER = ["lp", "ad", "unit", "user", "longtext", "shorttext", "image", "vedio", "audio", "feedtitle"]

class Sample(object):
    """��������
    """
    def __init__(self, local=True):
        """��ʼ�����ݿ��Ѵ��������
        """
        self.carriers = CARRIER
        self.DEPTH = LABEL_DEPTH
        self.sqlop = MysqlOperation()
        self.label_name = self.load_label_name()
        self.label_conf = self.load_label_conf()
        if local:
            self.hash_dict = self.load_hash_sample()

    def load_label_name(self):
        """���ر�ǩ����
        """
        label_name = {}
        sql = "select * from labelname"
        label_name_data = self.sqlop.select(sql)
        for vertex, vname in label_name_data:
            label_name[vertex] = vname
        return label_name

    def load_label_conf(self):
        """���ر�ǩ����
        """
        label_conf = {}
        sql = "select * from labelconf"
        label_conf_data = self.sqlop.select(sql)
        for path, samplenum, _ in label_conf_data:
            label_conf[path] = int(samplenum)
        return label_conf

    def load_hash_sample(self):
        """�������������hashvalue
        """
        hash_dict = {}
        for carrier in self.carriers:
            hash_dict[carrier] = {}
            count = 0
            file_path = PATH_ROOT + carrier + "/index.txt"
            with open(file_path, "r") as f:
                for line in f:
                    count += 1
                    parts = line.strip("\n").split("\t")
                    hash_dict[carrier][parts[0]] = count
        return hash_dict

    def order_cmp(self, o1, o2):
        """�ȽϽڵ���Ⱥ�˳��,��3_1��2_1֮ǰ
        """
        if int(o1[:1]) > int(o2[:1]):
            return -1
        elif int(o1[:1]) < int(o2[:1]):
            return 1
        elif int(o1[-1:]) < int(o2[-1:]):
            return -1
        elif int(o1[-1:]) > int(o2[-1:]):
            return 1
        return 0

    def is_legal_path(self, path):
        """�ж�������ǩ·���Ƿ�Ϸ�
        """
        for vertex in path.split("|"):
            if vertex not in self.label_name:
                logger.info("[vertex: %s] not in label name." % vertex)
                return False

        carrier_set = set([d[:1] for d in path.split("|")])
        if carrier_set != set(map(lambda x:str(x + 1), range(self.DEPTH))):
            logger.info("[path: %s] must be the same depth with self.DEPTH." % path)
            return False

        carrier_count = 0
        for d in path.split("|"):
            if d.startswith("2_"):
                carrier_count += 1
        if carrier_count != 1:
            logger.info("one sample only has one carrier.")
            return False

        return True

    def serialize_path(self, unsorted_path):
        """˳���ַ���
        """
        carrier = None
        for p in unsorted_path.split("|"):
            if p.startswith("2_"):
                carrier = self.label_name[p]
                break
        sorted_path = "|".join(sorted(unsorted_path.split("|"), self.order_cmp))
        return sorted_path, carrier

    def get_path_of_labels(self, labels):
        """��ȡ�����ڵ�����б�ǩ·��
        """
        path_of_labels = []
        count = 0
        for label_path in self.label_conf:
            if set(labels.split("|")).issubset(set(label_path.split("|"))):
                path_of_labels.append(label_path)
                count += self.label_conf[label_path]
        return path_of_labels, count

    def path_combine(self, path, check_path):
        """����·�����
        """
        vset = set()
        count = 0
        for p in path.split("|"):
            vset.add(p)
        for p in check_path.split("|"):
            vset.add(p)
        for p in vset:
            if p.startswith("2_"):
                count += 1
        if count != 1:
            return ""
        return "|".join(sorted(list(vset), self.order_cmp))

    def label_conf_op(self, path, op):
        """�޸�labelconf��
        [in]  path: ����·��
              op: ���ӻ�ɾ��(1: ����, -1: ��С)
        [out] ����path·������������, С��0˵���޸�ʧ��
        """
        label_info = "|".join(map(lambda x:self.label_name[x], path.split("|")))
        label_count_sql = "select count from labelconf where path=\'%s\'" % path
        label_count_ret = self.sqlop.select(label_count_sql)

        if label_count_ret is None:
            logger.info("[sql: %s] execute failed." % label_count_sql)
            return -1

        if len(label_count_ret) == 0:
            if op == -1:
                logger.info("path not in labelconf, del failed.")
                return -1
            elif op == 1:
                count_plus_sql = \
                        "insert into labelconf (path, count, label) values (\'%s\', %d, \'%s\')" \
                        % (path, 1, label_info)
                count_plus_ret = self.sqlop.update(count_plus_sql)
                if count_plus_ret == False:
                    logger.info("[sql: %s] execute failed." % count_plus_sql)
                    return -1
                self.label_conf[path] = 1
                return self.label_conf[path]
        else:
            if path not in self.label_conf:
                logger.info("fatal! check label conf.")
                return -1
            count = self.label_conf[path]
            if op == -1:
                if count > 1:
                    count_sub_sql = "update labelconf set count=count-1 where path=\'%s\'" % path
                    count_sub_ret = self.sqlop.update(count_sub_sql)
                    if count_sub_ret == False:
                        logger.info("[sql: %s] execute failed." % count_sub_sql)
                        return -1
                    self.label_conf[path] -= 1
                    return self.label_conf[path]
                elif count == 1:
                    count_sub_sql = "delete from labelconf where path=\'%s\'" % path
                    count_sub_ret = self.sqlop.update(count_sub_sql)
                    if count_sub_ret == False:
                        logger.info("[sql: %s] execute failed." % count_sub_sql)
                        return -1
                    self.label_conf.pop(path)
                    return 0
            elif op == 1:
                count_plus_sql = "update labelconf set count=count+1 where path=\'%s\'" % path
                count_plus_ret = self.sqlop.update(count_plus_sql)
                if count_plus_ret == False:
                    logger.info("[sql: %s] execute failed." % count_plus_sql)
                    return -1
                self.label_conf[path] += 1
                return self.label_conf[path]
        return -1

    def add_sample(self, path, offset, flag):
        """��������d
        [in]  path: ����·��
              offset: �ı���ƫ�������ý����ļ���
              flag: ��ʾsample����insert����update
        """
        if not self.is_legal_path(path):
            logger.info("[path: %s] is illegal, add sample failed." % path)
            return False

        # ����·��, ����, ����ƫ���� carrier + offsetΨһ��λ����λ��
        # ������Ϣ, �Ƿ�ɾ��
        path, carrier = self.serialize_path(path)
        info = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        isdel = 0

        if flag == "insert":
            insert_sql = \
                    "insert into sample (path, carrier, offset, info, isdel) " + \
                    "values (\'%s\', \'%s\', \'%s\', \'%s\', %d)" % \
                    (path, carrier, offset, info, isdel)
            insert_ret = self.sqlop.update(insert_sql)
            if insert_ret == False:
                logger.info("[sql: %s] execute failed." % insert_sql)
                return False
            if self.label_conf_op(path, 1) > 0:
                return True
            else:
                return False
        elif flag == "update":
            search_path_sql = \
                    "select path from sample where carrier = \'%s\' and offset = \'%s\'" % (carrier, offset)
            search_path_ret = self.sqlop.select(search_path_sql)
            if search_path_ret is None:
                logger.info("[sql: %s] execute failed." % search_path_sql)
                return False
            if len(search_path_ret) != 1:
                logger.info("check Table:sample where carrier = \'%s\' and offset =  \'%s\'" % (carrier, offset))
                return False
            check_path = search_path_ret[0][0]
            if check_path == path:
                logger.info("sample repeate.")
                return True
            else:
                pcombine = self.path_combine(path, check_path)
                if pcombine == "":
                    logger.info("path and check_path must be one carrier.")
                    return False
                update_path_sql = \
                        "update sample set path = \'%s\', info = \'%s\' where carrier = \'%s\' and offset = \'%s\'" \
                        % (pcombine, info, carrier, offset)
                update_path_ret = self.sqlop.update(update_path_sql)
                if update_path_ret == False:
                    logger.info("[sql: %s] execute failed." % update_path_sql)
                    return False
                self.label_conf_op(pcombine, 1)
                self.label_conf_op(check_path, -1)
                return True

    def del_sample(self, sample):
        """ɾ������
        """
        hashsample = hashlib.md5(sample).hexdigest()
        sql_select_sample = \
                "select * from SampleInfo where HashSample = \'%s\'" % hashsample
        select_sample_ret = self.sqlop.select(sql_select_sample)
        if select_sample_ret is None:
            logger.info("[sample: %s] select from Table:SampleInfo failed." % sample)
            return False

        elif len(select_sample_ret) == 0:
            logger.info("[sample: %s] not in Table:SampleInfo, delete failed." % sample)
            return False
            
        elif len(select_sample_ret) > 1:
            logger.info("fatal. delete sample failed. check Table:LabelConf.")
            return False

        else:
            isdel = select_sample_ret[0][4]
            if isdel == 1:
                logger.info("delete [sample: \'%s\'] repeat from Table:LabelConf." % sample)
                return False
            else:
                path = select_sample_ret[0][0]
                info = json.loads(select_sample_ret[0][3])
                info["time_stamp"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                info = json.dumps(info)
                sql_update_sample = \
                        "update SampleInfo set isdel=1 where HashSample = \'%s\'" % hashsample
                if self.sqlop.update(sql_update_sample):
                    if path not in self.label_conf:
                        logger.info("fatal. [Paht: %s] not in Tabel:LabelConf, delete failed." % path)
                        return False

                    samplenum = self.label_conf[path]
                    if samplenum > 1:
                        sql_update_labelconf = \
                                "update LabelConf set SampleNum=%d where Path=\'%s\'" % \
                                (self.label_conf[path] - 1, path)
                        self.sqlop.update(sql_update_labelconf)
                        self.label_conf[path] -= 1
                        logger.info("update LabelConf:SampleNumn where Path=\'%s\'." % path)
                    else:
                        sql_drop_labelconf = \
                                "delete from LabelConf where Path=\'%s\'" % (path)
                        self.sqlop.update(sql_drop_labelconf)
                        self.label_conf.pop(path)
                        logger.info("delete LabelConf:SampleNumn where Path=\'%s\'." % path)
                else:
                    logger.info("delete [sample: \'%s\'] failed from Table:SampleInfo." % sample)
                    return False

        return True

    def select_sample(self, labels, num=-1):
        """���ݽڵ��ѯ����
        """
        path_of_labels, count = self.get_path_of_labels(labels)
        logger.info("%d path and %d samples in database." % (len(path_of_labels), count))

        index = []
        for path in path_of_labels:
            sql = ""
            if num < 0:
                sql = "select offset from sample where path=\'%s\' and isdel=0" % path
            else:
                sql = "select offset from sample where path=\'%s\' and isdel=0 limit %d" % (path, num)
            data = self.sqlop.select(sql)
            for i in range(len(data)):
                index.append(data[i][0])
        return index


if __name__ == "__main__":
    s = Sample()
    print s.path_combine("1_1|2_1|3_1", "1_1|2_2|3_1")
    print s.path_combine("1_1|2_1|3_1", "1_2|2_1|3_1")
    pass

