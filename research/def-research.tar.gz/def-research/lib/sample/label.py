#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   20/01/13 14:34:55
Desc  :   
"""
import os
import sys
from mysql import MysqlOperation

_cur_dir = os.path.dirname(os.path.abspath(__file__))

def truncate_table(mysql_op, table_name):
    """
    Args:
        mysql_op:   mysql���
        table_name: mysql���������ݿ����

    Returns:
        bool
    """
    sql = "truncate table %s" % table_name
    ret = mysql_op.update(sql)
    if ret:
        print "truncate table %s sucss." % table_name
    else:
        print "truncate table %s failed." % table_name
    return ret

def insert_label_name(mysql_op, label, name):
    """
    Args:
        mysql_op: mysql���
        label:    ���������塢��ǩ��label
        name:     label��Ӧ������

    Returns:
        bool
    """
    sql = "insert into labelname (vertex, vname) values(\'%s\', \'%s\')" \
            % (label, name)
    print sql
    ret = mysql_op.update(sql)
    if ret == False:
        print "insert termination. sql: [%s] execute failed." % sql

    return ret


if __name__ == "__main__":
    print "please check label_name.txt carefully."
    print "now update Table:labelname."
    mysql_op = MysqlOperation()
    truncate_table(mysql_op, "labelname")

    label_map_file = os.path.join(_cur_dir, "labelname.txt")
    with open(label_map_file, "r") as f:
        for eachline in f:
            parts = eachline.strip().split("\t")
            insert_label_name(mysql_op, parts[0], parts[1])

