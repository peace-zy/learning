#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   20/01/13 14:35:52
Desc  :   mysql���ݿ����
"""
import sys
import MySQLdb

class MysqlOperation(object):
    """mysql������
    """
    def __init__(self):
        """��ʼ�����ݿ�
        """
        db_config = {
            "host": '10.233.31.41',
            "user": 'zhuxiaodong01',
            "passwd": '123456',
            "db": 'samples',
            "charset": 'gbk'
        }
        try:
            self.conndb = MySQLdb.connect(**db_config)
            self.cursor = self.conndb.cursor()
        except Exception as e:
            print e
            sys.exit(1)

    def select(self, sql):
        """��ѯ���ݿⲢ���������б�
        """
        try:
            self.cursor.execute(sql)
            data = self.cursor.fetchall()
        except Exception as e:
            self.conndb.rollback()
            print e
            return None
        return data

    def update(self, sql):
        """����ɾ���޸����ݿ�
        """
        try:
            self.cursor.execute(sql)
            self.conndb.commit()
        except Exception as e:
            self.conndb.rollback()
            print e
            return False
        return True

    def truncate(self, table_name):
        """���table_name��
        """
        sql = "truncate table %s" % table_name
        self.cursor.execute(sql)
        self.conndb.commit()

    def __del__(self):
        """�ر����ݿ�
        """
        self.cursor.close()
        self.conndb.close()


if __name__ == "__main__":
    sql = "select count from labelconf where path='3_5|2_1|1_1'"
    op = MysqlOperation()
    print op.update(sql)


