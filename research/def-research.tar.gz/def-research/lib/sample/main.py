#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   20/01/13 15:36:02
Desc  :   ���������������,ʾ��
          python main.py --type "insert" --path "��׬|unit|��ҵ" --file "tmp.txt"
"""
import sys
import os
import argparse
import json
import MySQLdb
import time
import hashlib

from sample import Sample

PATH_ROOT = "/home/work/samples/"

def args_func():
    """�������
    """
    parser = argparse.ArgumentParser(description = "sample")
    parser.add_argument("-t", "--type", \
            help = "�����������ͣ���������insert��ɾ��delete���޸�revise������search", \
            default = "insert", \
            required = True)
    parser.add_argument("-p", "--path", \
            help = "������ǩ·������insertʱ����Ϊ���㣬������ǩ�����壬����", \
            required = True)
    parser.add_argument("-f", "--file", \
            help = "�ļ����ļ������ƣ���insertʱΪinfile����searchʱΪoutfile", \
            required = True)
    parser.add_argument("-n", "--num", \
            help = "��ѯ����ʱ����Ĳ���,��ʾ��������,Ĭ�ϲ�ѯǰ10��", default = 10, \
            type = int)

    args = parser.parse_args()
    return args

def os_system(command):
    """ִ�н��״̬
    """
    ret = os.system(command)
    if ret != 0:
        sys.stderr.write("%s\n" % command)
    return ret

def get_carrier(label_ids):
    """��ȡ����
    """
    ids_list = label_ids.split("|")
    carrier_id = ""
    carrier_count = 0
    for ids in ids_list:
        if ids.startswith('2_'):
            carrier_id = ids
            carrier_count += 1

    if carrier_count != 1:
        return None
    return carrier_id

def transfer_path(s_obj, path):
    """��ǩ·��ת��ǩid·��
    """
    label_name = s_obj.label_name
    name_label = dict(zip(label_name.values(), label_name.keys()))
    try:
        label_ids, carrier = s_obj.serialize_path( \
                "|".join((map(lambda x:name_label[x], \
                args.path.decode("gb18030").split("|")))))
    except Exception as e:
        sys.stderr.write("key error: %s\n" % e)
        sys.exit(1)

    if s_obj.is_legal_path(label_ids) == False:
        sys.stdout.error("insert path must legal.\n")
        return None, None
    return label_ids, carrier

def get_file_handle(carrier, op):
    """��ȡ�����ļ�������
    """
    file_name = PATH_ROOT + carrier + "/index.txt"
    try:
        fopen = open(file_name, op)
    except:
        return None
    return fopen

def insert(s_obj, label_ids, file_name, fopen):
    """�������ݿ�
    [in]  labels_ids: ��ǩ·��ids
          file_name: infile name
    [out] None
    """
    carrier_id = get_carrier(label_ids)
    if carrier_id is None:
        sys.stderr.write("sample only has one carrier.")
        sys.exit(1)

    label_name = s_obj.label_name
    hash_dict = s_obj.hash_dict
    carrier = label_name[carrier_id]

    if carrier in set(["lp", "unit", "ad", "user", "feedtitle"]):
        with open(file_name, "r") as f:
            for line in f:
                line = line.strip('\n')
                hashvalue = hashlib.md5(line).hexdigest()
                if hashvalue not in hash_dict[carrier]:
                    if s_obj.add_sample(label_ids, str(len(hash_dict[carrier]) + 1), "insert"):
                        fopen.write("%s\t%s\n" % (hashvalue, line))
                        hash_dict[carrier][hashvalue] = len(hash_dict[carrier]) + 1
                else:
                    s_obj.add_sample(label_ids, str(hash_dict[carrier][hashvalue]), "update")
    else:
        files = os.listdir(file_name)
        if not file_name.endswith("/"): file_name = file_name + "/"
        for file in files:
            command = "mv " + file_name + file + " " + PATH_ROOT + carrier + "/"
            if os_system(command) != 0:
                continue
            ret = s_obj.add_sample(label_ids, file, "insert")
            if ret == False:
                command = "rm " + PATH_ROOT + carrier + "/" + file
                os_system(command)

def search(s_obj, label_ids, file_name, fopen, num):
    """��ѯ���ݿ�
    [in]  s_obj: ����ʵ��
          label_ids: ��ǩ·��ids
          file_name: outfile name
          fopen: �����ļ�
    """
    carrier_id = get_carrier(label_ids)
    if carrier_id is None:
        sys.stderr.write("sample only has one carrier.")
        sys.exit(1)

    label_name = s_obj.label_name
    hash_dict = s_obj.hash_dict
    carrier = label_name[carrier_id]

    if carrier in set(["lp", "unit", "ad", "user"]):
        offset_or_index = set(s_obj.select_sample(label_ids, num))
        with open(file_name, "w") as f:
            for index, line in enumerate(fopen):
                if str(index + 1) in offset_or_index:
                    f.write("%s\n" % "\t".join(line.strip("\n").split("\t")[1:]))
    else:
        if not os.path.exists(file_name):
            os.makedirs(file_name)
        offset_or_index = set(s_obj.select_sample(label_ids, num))
        for index in offset_or_index:
            command = "cp " + PATH_ROOT + carrier + "/" + index + " " + file_name
            if os_system(command) != 0:
                sys.stderr.write("file: %s not in database?" % index)
                sys.exit(1)

def args_parse(args):
    """��������������ִ��
    """
    s_obj = Sample()
    type = args.type
    path = args.path
    file = args.file
    num  = args.num

    if type == "insert":
        if path is None or file is None:
            sys.stdout.error("path and file must be giving.\n")
            sys.exit(1)

        label_ids, carrier = transfer_path(s_obj, path)
        fopen = get_file_handle(carrier, "a")
        if fopen is not  None:
            insert(s_obj, label_ids, file, fopen)
            fopen.close()
        else:
            sys.stdout.error("file open failed.\n")

    elif type == "search":
        if path is None or file is None:
            sys.stdout.error("path and file must be giving.\n")
            sys.exit(1)

        label_ids, carrier = transfer_path(s_obj, path)
        fopen = get_file_handle(carrier, "r")
        if fopen is not None:
            search(s_obj, label_ids, file, fopen, num)
            fopen.close()
        else:
            sys.stdout.error("file read failed.\n")


if __name__ == "__main__":
    args = args_func()
    start = time.time()
    args_parse(args)
    end = time.time()
    print "total time: %f" % (end - start)

