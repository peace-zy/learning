#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   19/04/12 20:24:04
Desc  :   
"""
import sys
reload(sys)
sys.setdefaultencoding("gbk")

import re
import subprocess
import random


class Sampler(object):
    """ͨ�ó����� ��ˮ�س���
    """
    def __init__(self, sample_num):
        """��ʼ�� ָ����������
        Args:
            sample_num : ָ����������
        """
        assert isinstance(sample_num, int), "sample_num must be integer."
        self._sample_num = sample_num
        self._sample_list = list()
        self._count = 0

    def put(self, obj):
        """
        Args:
            obj : ����Ԫ��
        """
        if len(self._sample_list) < self._sample_num:
            self._sample_list.append(obj)
        else:
            index = random.randint(0, self._count)
            if index < self._sample_num:
                self._sample_list[index] = obj
        self._count += 1

    def get_sample_list(self):
        """���ص�ǰ�������
        """
        return self._sample_list

    def clear(self):
        """��ճ����б�
        """
        self._sample_list[:]=[]
        self._count = 0


class Common(object):
    """���÷���
    """
    @staticmethod
    def shell_execute(cmd_str):
        """ִ��shell������
        [in]  cmd_str: str, ������
        [out] ִ�н��
        """ 
        return subprocess.call(cmd_str, shell=True)

    @staticmethod
    def load_word_file(file_name):
        """
        [in]  file_name: str, �ļ���
        [out] word: set, Сд, unicode
        """
        word = set()
        with open(file_name, "r") as f:
            for eachline in f:
                line = eachline.lower().decode("gbk", "ignore").strip("\n")
                word.add(line)
        return word

    @staticmethod
    def load_vocab(file_name, unk=False):
        """CNNģ�͵Ĵʵ�
        [in]  file_name: str, �ļ���
              unk: bool, �Ƿ�����unk
        [out] vocab: dict, unicode
        """
        vocab = {}
        with open(file_name) as f:
            for line in f:
                line = line.strip().decode("gbk", "ignore")
                cols = line.split("\t")
                index = int(cols[0])
                word  = cols[1]
                freq  = cols[2]
                vocab[word] = index
                if unk:
                    vocab[word] = index - 1
        if unk:
            vocab['<unk>'] = len(vocab)
        return vocab

    @staticmethod
    def load_idf_dict(file_name):
        """��ȡģ��idf�ʵ�
        [in]  file_name: str, �ļ���
        [out] idf_dict: dict
        """
        idf_dict = {}
        with open(file_name, "r") as f:
            for line in f:
                line = line.strip().decode("gbk", "ignore")
                cols = line.split("\t")
                index = int(cols[0])
                word = cols[1]
                idf_value = cols[2]
                idf_dict[word] = idf_value
        return idf_dict

    @staticmethod
    def write_vocab(file_name, vocab, idf_vocab, wordcount=True, info=True, is_idf=False):
        """index \t word \t count�ĸ�ʽд���ļ�
           is_idf����count�Ƿ�Ϊidf_valueֵ������idf��dictҲ��ֻ��¼count>=10��ngram��idfֵ
        """
        try:
            with open(file_name, "w") as f:
                count = 0
                for word in vocab:
                    if (wordcount and vocab[word] >= 10) or (not wordcount):
                        count += 1
                        if info:
                            if is_idf:
                                f.write("%d\t%s\t%f\n" % (count, word, idf_vocab[word]))
                            else:
                                f.write("%d\t%s\t%d\n" % (count, word, vocab[word]))
                        else:
                            f.write("%s\n" % word)
        except IOError:
            return False
        return True

    @staticmethod
    def load_class_id_file(file_name):
        """
        [in]  file_name: str, ������id�ļ�, ����, class_id, class_name
        [out] class_dict: dict, str(class_id) -> str(class_name)
        """
        class_dict = {}
        with open(file_name, "r") as f:
            for eachline in f:
                data = eachline.strip().decode("gbk", "ignore").split("\t")
                class_id = data[0]
                class_name = data[1]
                class_dict[class_id] = class_name
        return class_dict

    @staticmethod
    def load_class_thres(file_name):
        """
        [in]  file_name: str, ������id�ļ�, ����������, class_id, class_name, [thres]
        [out] class_thres: dict, str(class_id) -> float(thres) ���Ϊ���У���ʾ��class_id��Ҫ������ֵ
        """
        class_thres = {}
        with open(file_name, "r") as f:
            for eachline in f:
                parts = eachline.strip().decode("gb18030", "ignore").split("\t")
                if len(parts) == 3:
                    class_thres[parts[0]] = float(parts[2])
        return class_thres

    @staticmethod
    def ngram(seg_list, n=3):
        """
        [in]  seg_list: �кôʵ�list
        [out] ngram: set, ��seg_list����ngram
        """
        word_num = len(seg_list)
        ngram = set()
        for i in range(0, word_num):
            for j in range(1, n + 1):
                if i + j > word_num:
                    break
                word = "".join(seg_list[i: i + j])
                if len(word) > 1: #��������unicode���ȴ���1
                    ngram.add(word)
        return ngram

    @staticmethod
    def ngram_without_set(seg_list, n=3):
        """
        [in]  seg_list: �кôʵ�list
        [out] ngram: list, ��seg_list����ngram, ����Ҫͳ�ƴ�Ƶ
        """
        word_num = len(seg_list)
        ngram = list()
        for i in range(0, word_num):
            for j in range(1, n + 1):
                if i + j > word_num:
                    break
                word = "".join(seg_list[i: i + j])
                if len(word) > 1: #����unicode���ȴ���1
                    ngram.append(word)
        return ngram

    @staticmethod
    def ngram_feature(seg_list, stopword, notstopword_set, use_re=False):
        """�д�listתngram
        [in]  seg_list: list, �д��б�
              stopword: set, ͣ�ôʼ���
              notstopword_set: set, ��ͣ�ôʼ���, ��ͣ�ôʼ��ϱ���ΪӢ�ģ���app
              user_re: �Ƿ�ʹ������������Ϊͣ�ôʣ�Ĭ�ϲ�ʹ��
        """
        ngram = set()
        skip_stopword = []
        chinese = re.compile(ur'^[\u4e00-\u9fa5]+$')  #��use_re=Trueʱʹ��
        for x in seg_list:
            if (x in stopword) or (use_re and (not chinese.search(x)) and (x not in notstopword_set)):
                ngram |= Common.ngram(skip_stopword)
                skip_stopword = []
                continue
            skip_stopword.append(x)
        if len(skip_stopword) > 0:
                ngram |= Common.ngram(skip_stopword)
        return ngram

    @staticmethod
    def ngram_feature_without_set(seg_list, stopword, notstopword_set, use_re=False):
        """�д�listתngram
        [in]  seg_list: list, �д��б�
              stopword: set, ͣ�ôʼ���
              notstopword_set: set, ��ͣ�ôʼ���, ��ͣ�ôʼ��ϱ���ΪӢ�ģ���app
              user_re: �Ƿ�ʹ������������Ϊͣ�ôʣ�Ĭ�ϲ�ʹ��
        more: ͳ�ƴ�Ƶ,�Ͳ�����set
        """
        ngram = list()
        skip_stopword = []
        chinese = re.compile(ur'^[\u4e00-\u9fa5]+$')  #��use_re=Trueʱʹ��
        for x in seg_list:
            if (x in stopword) or (use_re and (not chinese.search(x)) and (x not in notstopword_set)):
                ngram.extend(Common.ngram(skip_stopword))
                skip_stopword = []
                continue
            skip_stopword.append(x)
        if len(skip_stopword) > 0:
            ngram.extend(Common.ngram(skip_stopword))
        return ngram

    @staticmethod
    def process_list(word_list, stopword, del_stopword=True, del_nc=True):
        """ȥ���б��е�ͣ�ôʡ�������
        [in]  word_list: �дʺ���ı��б�
              stopword: set,ͣ�ôʼ���
              del_stopword: �Ƿ�ȥ��ͣ�ôʣ�Ĭ��True
              del_nc: �Ƿ�ȥ�������ģ�Ĭ��True
        [out] plist: ��������ı��б�
        """
        plist = word_list
        if del_stopword:
            plist = filter(lambda x:x not in stopword, word_list)
        if del_nc:
            chinese = re.compile(ur'^[\u4e00-\u9fa5]+$')
            plist = filter(lambda x:chinese.search(x), plist)
        return plist

    @staticmethod
    def wget_file(machine, file_path, file_name, dest_path, dest_name):
        """
        Args:
            machine: ������ַ
            file_path: �ļ�·��
            file_name: �ļ�����
            dest_path: Ŀ���ַ
            dest_name: Ŀ��·��
        """
        wget_format = "wget --ftp-user=ftp --ftp-password=defftp171945 ftp://"
        cmd_str = wget_format + machine + file_path + file_name + " -O " + dest_path + dest_name
        return subprocess.call(cmd_str, shell=True)


if __name__ == "__main__":
    pass


