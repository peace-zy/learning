#!/usr/bin/env python
#-*- coding=gb18030 -*-
"""���������д�
"""
import sys
import wordseg
import re


class WordSeg(object):
    """�д���
    Attributes:
        dict_path -- �ʵ�·��
    """
    def __init__(self, dict_path, max_term_num=10240):
        self.max_term_num = max_term_num 
        self.dict_path = dict_path

    def init_wordseg_handle(self):
        """��ʼ���дʾ��
        """
        self.dict_handle = wordseg.scw_load_worddict(self.dict_path)
        self.result_handle = wordseg.scw_create_out(self.max_term_num * 10)
        self.token_handle = wordseg.init_tokens(\
                wordseg.create_tokens(self.max_term_num), self.max_term_num)

    def destroy_wordseg_handle(self):
        """���پ��
        """
        if self.token_handle is not None:
            wordseg.destroy_tokens(self.token_handle)
        if self.result_handle is not None:
            wordseg.scw_destroy_out(self.result_handle)
        if self.dict_handle is not None:
            wordseg.scw_destroy_worddict(self.dict_handle)

    def seg_words(self, line):
        """�������ӷ����д�List
        Args: 
            line   -- string

        Returns:
            tokens -- �дʺ��list

        Raises:
            Exception
        """
        ret = wordseg.scw_segment_words(self.dict_handle, self.result_handle, line, len(line), 1)
        if ret < 0:
            sys.stderr.write("wordseg.scw_segment_words failed!\n")
        token_count = wordseg.scw_get_token_1(self.result_handle, wordseg.SCW_WPCOMP, \
        #token_count = wordseg.scw_get_token_1(self.result_handle, wordseg.SCW_BASIC, \
                self.token_handle, self.max_term_num)
        token_list = wordseg.tokens_to_list(self.token_handle, token_count)

        tokens = []
        for token in token_list:
            tokens.append(token[7])
        return tokens

    def seg_from_file(self, in_file, out_file):
        """�������дʵ��ļ�, ����дʺ���ļ�
        Args:
            in_file  -- �д�ǰ���ļ�
            out_file -- �дʺ���ļ�

        Returns:
            NULL

        Raises:
            Exception
        """
        o_file = open(out_file, "w")
        with open(in_file, "r") as f:
            for eachline in f:
                try:
                    line = eachline.strip("\n").split("\t")
                    userid = line[0]
                    str_line = line[1]
                    ret = wordseg.scw_segment_words(self.dict_handle, self.result_handle, \
                            str_line, len(str_line), 1)
                    if ret < 0:
                        sys.stderr.write("wordseg.scw_segment_words failed!\n")
                        continue

                    token_count = wordseg.scw_get_token_1(self.result_handle, wordseg.SCW_WPCOMP, \
                            self.token_handle, self.max_term_num)
                    token_list = wordseg.tokens_to_list(self.token_handle, token_count)

                    tokens = [userid]
                    for token in token_list:
                        tokens.append(token[7])
                    o_file.write("%s\n" % "\t".join(tokens))
                except Exception as e:
                    sys.stderr.write("WordSeg.seg_from_file, line: %s, %s\n" % (eachline, e))
        o_file.close()


if __name__ == "__main__":
    #if len(sys.argv) != 4:
    #    sys.stderr.write("Usage: python word_seg.py dict_path file_in file_out!\n")
    #    sys.exit(1)

    #dict_path = sys.argv[1]
    #file_in = sys.argv[2]
    #file_out = sys.argv[3]

    #ws = WordSeg(dict_path)
    #ws.init_wordseg_handle()

    #ws = WordSeg("/home/zhukaiwen/disk_500/temp_data/RECOVERED_FILES/git/baidu/personal-code/zhukaiwen/feed_title/lib/chinese_gbk")
    ws = WordSeg("./dict/worddict-1-5-7/chinese_gbk")
    ws.init_wordseg_handle()
    #token_list = ws.seg_words("�Ͼ��� �������Ŷද֢")
    #t = "���ƴ�ʦ�𷨷���ʮ����Ф�������� ���ƴ�ʦ�÷��۹����2017��ʮ����Ф����,�����߽����صı���������,  ��Ƚ���ʮ����Ф����ƶ���Ĺ�ϵ!"
    t = "�����ΰ��������Ƕ��ȽϺ�"
    token_list = ws.seg_words(t)
    print "||".join(token_list)

    ws.destroy_wordseg_handle()
