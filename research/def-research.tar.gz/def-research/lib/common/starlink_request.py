#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   21/11/05 11:10:15
Desc  :   请求starlink, 暂时只写了请求文本和图片的
"""
import sys
import requests
import json

REQUEST_TEXT = 1
REQUEST_IMAGE = 2


class StarlinkRequest(object):
    """请求starlink获取算子结果
    """
    def __init__(self, 
            starlink_http_service="http://qianfan.baidu-int.com",
            starlink_user_token="ac83d235786503d93d87a725be04a7c4"):
        """init
        """
        self.starlink_http_service = starlink_http_service
        self.starlink_user_token = starlink_user_token

    def construct_request(self, request_obj, calculate_tags, request_type):
        """构造请求
        """
        url = ''
        if isinstance(request_obj, list):
            url = self.starlink_http_service + '/starlink/v2/calculate_batch'
            construct_request_list = []
            for r_obj in request_obj:
                input_dict = dict()
                if request_type == REQUEST_TEXT:
                    input_dict = {
                            "input": {
                                    "text_input": {
                                        "content": r_obj
                                    }
                                }
                        }
                elif request_type == REQUEST_IMAGE:
                    input_dict = {
                            "input": {
                                "image_input": {
                                    "url": r_obj
                                }
                            }
                        }
                else:
                    raise Exception("request type [text, image].")
                construct_request_list.append(input_dict)
            data = {
                "log_id": "1234567",
                "calculate_tags": calculate_tags,
                "datas": construct_request_list
            }
        else:
            url = self.starlink_http_service + '/starlink/v2/calculate'
            input_dict = dict()
            if request_type == REQUEST_TEXT:
                input_dict = {
                        "text_input": {
                            "content": request_obj
                        }
                    }
            elif request_type == REQUEST_IMAGE:
                input_dict = {
                        "image_input": {
                            "url": request_obj
                        }
                    }
            else:
                raise Exception("request type [text, image].")
            data = {
                "log_id": "1234567",
                "calculate_tags": calculate_tags,
                "data": {
                    "input": input_dict
                }
            }

        headers = {
            "content-type": "application/json",
            "starlink_user_token": self.starlink_user_token
        }

        result = requests.post(url, data=json.dumps(data, ensure_ascii=False).encode(), headers=headers)
        return result.json()

    def request_text(self, text, calculate_tags):
        """
        Args:
            text:               str或者list, 待请求文本
            calculate_tags:     list, 例如["assisting_tag.word_seg_output", "text_tag.text_novel_porn"]
        Return:
            dict
        """
        return self.construct_request(text, calculate_tags, REQUEST_TEXT)

    def request_image(self, image_url, calculate_tags):
        """
        Args:
            image_url:          str或者list, 待请求图片url
            calculate_tags:     list, 例如["assisting_tag.image_text"]
        Return:
            dict
        """
        return self.construct_request(image_url, calculate_tags, REQUEST_IMAGE)


if __name__ == "__main__":
    sr = StarlinkRequest()

    calculate_tags = ["assisting_tag.word_seg_output", 
            "assisting_tag.tokenizer_output", 
            "text_tag.text_novel_porn"]
    text_list = ["这是一段utf8个文本", "另一段需要测试的文本"]
    result = sr.request_text(text_list, calculate_tags)
    print(json.dumps(result, ensure_ascii=False, indent=2))

    text = "单条文本测试"
    result = sr.request_text(text, calculate_tags)
    print(json.dumps(result, ensure_ascii=False, indent=2))
