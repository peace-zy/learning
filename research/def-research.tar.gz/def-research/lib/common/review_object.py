#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhukaiwen@baidu.com
Date  :   19/04/29 17:00:33
Desc  :   �������ݽṹ
"""
import os
import sys
import json

# def-userģ��ģ��
MODEL_TYPE_AD = 1
MODEL_TYPE_UNIT = 2
MODEL_TYPE_USER = 3
MODEL_TYPE_METEOR = 4
MODEL_TYPE_OTHER = 5
MODEL_TYPE_CLICK_AD = 6
MODEL_TYPE_CLICK_USER = 7
MODEL_TYPE_LP = 8
MODEL_TYPE_METEOR_AD = 9
MODEL_TYPE_URL = 10
MODEL_TYPE_FEED_AD = 11
MODEL_TYPE_FEED_USER = 12

class CheckResultObj(object):
    """ģ��Ԥ������ʽ
    """
    def __init__(self):
        """init"""
        # Ĭ��-100, ��ʾ������������, -10��ʾû��Ԥ��ֵ
        self.label = "-100"
        self.label_name = "None"
        self.label_list = []
        # �Զ�����ֶη���opt��
        self.opt = {}

    def init(self, label, label_name, label_list, opt=None):
        """init"""
        # Ĭ��-100, ��ʾ������������, -10��ʾû��Ԥ��ֵ
        self.label = label
        self.label_name = label_name
        self.label_list = label_list
        self.opt = {} if opt is None else opt

    def init_from_dict(self, check_result):
        """init_from_dict
        """
        self.label = check_result["label"]
        self.label_name = check_result["label_name"]
        self.label_list = check_result["label_list"]
        self.opt = {} if "opt" not in check_result else check_result["opt"]

    def convert_to_dict(self):
        """convert_to_dict
        """
        check_result = {}
        check_result["label"] = self.label
        check_result["label_name"] = self.label_name
        check_result["label_list"] = self.label_list
        check_result["opt"] = self.opt
        return check_result

class CheckAdResultObj(CheckResultObj):
    """����ģ��Ԥ������ʽ
    """
    pass


class CheckUnitResultObj(CheckResultObj):
    """��Ԫģ��Ԥ������ʽ
    """
    pass


class CheckUserResultObj(CheckResultObj):
    """�û�ģ��Ԥ������ʽ
    """
    pass


class CheckClickResultObj(CheckResultObj):
    """���ģ��Ԥ������ʽ
    """
    pass


class CheckFeedResultObj(CheckResultObj):
    """feedģ��Ԥ������ʽ
    """
    pass


class CheckUrlResultObj(CheckResultObj):
    """urlģ��Ԥ������ʽ
    """
    pass


class ReviewObj(object):
    """Base Class
    """
    def __init__(self):
        """init"""
        self.check_result = []

    def add_result(self, model_conf_info, check_result):
        """���ܸ�ģ�ͽ��, �ӵ�check_result��
        [in]  model_conf_info: ģ������
              check_result: ģ�ͽ��
        [out] None
        """
        result = {}
        result["model_id"] = model_conf_info["model_id"]
        result["model_name"] = model_conf_info["model_name"]
        # ģ�ͽ��
        result["model_result"] = check_result
        self.check_result.append(result)


class ReviewAdObj(ReviewObj):
    """unit obj
    """
    def init(self, line, ad_type):
        """��ʼ������
        [in]  line
        [in]  r_obj_type
        [out] None
        """
        self.data_type = MODEL_TYPE_AD
        self.userid = line[0]
        self.planid = line[1]
        self.unitid = line[2]
        self.id = line[3]
        self.version = line[4]
        self.ad_type = ad_type  # �����IDEA����WORD
        self.text = line[5]
        self.text_seg_list = line[6].split("\x02")
        self.url = line[7]
        self.check_result = []

    def init_from_json(self, json_str):
        """json�����obj
        [in]  line
        [out] None
        """
        ad_result = json.loads(json_str)
        info = ad_result["info"]
        self.userid = info["userid"]
        self.planid = info["planid"]
        self.unitid = info["unitid"]
        self.id = info["id"]
        self.version = info["version"]
        self.ad_type = info["ad_type"]  # �����IDEA����WORD
        self.text = info["text"]
        self.text_seg_list = info["text_seg_list"]
        self.url = info["url"]
        self.check_result = ad_result["check_result"]

    def review_result(self):
        """��ʽ��review���
        """
        result = {}
        result["data_type"] = self.data_type
        result["info"] = {}
        result["info"]["userid"] = self.userid
        result["info"]["planid"] = self.planid
        result["info"]["unitid"] = self.unitid
        result["info"]["id"] = self.id
        result["info"]["version"] = self.version
        result["info"]["ad_type"] = self.ad_type
        result["info"]["text"] = self.text
        result["info"]["text_seg_list"] = self.text_seg_list
        result["info"]["url"] = self.url
        result["check_result"] = self.check_result
        return result


class ReviewUnitObj(ReviewObj):
    """unit obj
    """
    def init(self, line):
        """��ʼ������
        [in]  line
        [out] None
        """
        self.data_type = MODEL_TYPE_UNIT
        self.userid = line[0]
        self.planid = line[1]
        self.unitid = line[2]
        self.idea_list = line[3].split("\x01")
        self.word_list = line[4].split("\x01")
        self.idea_seg_list = [x.split("\x02") for x in line[5].split("\x01")]
        self.word_seg_list = [x.split("\x02") for x in line[6].split("\x01")]
        self.idea_url_list = line[7].split("\x01")
        self.word_url_list = line[8].split("\x01")
        self.check_result = []

    def init_from_json(self, json_str):
        """json�����obj
        [in]  line
        [out] 
        """
        unit_result = json.loads(json_str)
        info = unit_result["info"]
        self.userid = info["userid"]
        self.planid = info["planid"]
        self.unitid = info["unitid"]
        self.idea_list = info["idea_list"]
        self.word_list = info["word_list"]
        self.idea_seg_list = None
        self.word_seg_list = None
        self.idea_url_list = info["idea_url_list"]
        self.word_url_list = info["word_url_list"]
        self.check_result = unit_result["check_result"]

    def review_result(self):
        """��ʽ��review���
        """
        result = {}
        result["data_type"] = self.data_type
        result["info"] = {}
        result["info"]["userid"] = self.userid
        result["info"]["planid"] = self.planid
        result["info"]["unitid"] = self.unitid
        result["info"]["word_list"] = self.word_list
        result["info"]["idea_list"] = self.idea_list
        result["info"]["word_url_list"] = self.word_url_list
        result["info"]["idea_url_list"] = self.idea_url_list
        result["check_result"] = self.check_result
        return result


class ReviewUserObj(ReviewObj):
    """user obj
    """
    def init(self, line):
        """��ʼ������
        [in]  line
        [out] None
        """
        self.data_type = MODEL_TYPE_USER
        self.userid = line[0]
        self.idea_list = line[1].split("\x01")
        self.word_list = line[2].split("\x01")
        self.idea_seg_list = [x.split("\x02") for x in line[3].split("\x01")]
        self.word_seg_list = [x.split("\x02") for x in line[4].split("\x01")]
        self.idea_url_list = line[5].split("\x01")
        self.word_url_list = line[6].split("\x01")
        self.check_result = []

    def init_from_json(self, json_str):
        """json�����obj
        [in]  line
        [out] 
        """
        user_result = json.loads(json_str)
        info = user_result["info"]
        self.userid = info["userid"]
        self.idea_list = info["idea_list"]
        self.word_list = info["word_list"]
        self.idea_seg_list = None
        self.word_seg_list = None
        self.idea_url_list = info["idea_url_list"]
        self.word_url_list = info["word_url_list"]
        self.check_result = user_result["check_result"]

    def review_result(self):
        """��ʽ��review���
        """
        result = {}
        result["data_type"] = self.data_type
        result["info"] = {}
        result["info"]["userid"] = self.userid
        result["info"]["word_list"] = self.word_list
        result["info"]["idea_list"] = self.idea_list
        result["info"]["word_url_list"] = self.word_url_list
        result["info"]["idea_url_list"] = self.idea_url_list
        result["check_result"] = self.check_result
        return result


class ReviewClickAdObj(ReviewObj):
    """click obj
    """
    def init(self, line):
        """��ʼ������
        """
        self.data_type = MODEL_TYPE_CLICK_AD
        self.userid = line[0]
        self.planid = line[1]
        self.unitid = line[2]
        self.winfoid= line[3]
        self.ideaid = line[4]
        self.text   = line[5]
        self.text_seg = line[6].split("\x02")
        self.url = line[7]
        self.check_result = []

    def init_from_json(self, json_str):
        """json�����obj
        [in]  line
        [out] 
        """
        click_result = json.loads(json_str)
        info = click_result["info"]
        self.userid = info["userid"]
        self.planid = info["planid"]
        self.unitid = info["unitid"]
        self.winfoid= info["winfoid"]
        self.ideaid = info["ideaid"]
        self.text   = info["text"]
        self.text_seg = info["text_seg"]
        self.url = info["url"]
        self.check_result = click_result["check_result"]

    def review_result(self):
        """��ʽ��review���
        """
        result = {}
        result["data_type"] = self.data_type
        result["info"] = {}
        result["info"]["userid"] = self.userid
        result["info"]["planid"] = self.planid
        result["info"]["unitid"] = self.unitid
        result["info"]["winfoid"]= self.winfoid
        result["info"]["ideaid"] = self.ideaid
        result["info"]["text"] = self.text
        result["info"]["text_seg"] = self.text_seg
        result["info"]["url"] = self.url
        result["check_result"] = self.check_result
        return result

class ReviewMeteorAdObj(ReviewObj):
    """meteor obj
    """
    def init(self, line):
        """��ʼ������
        """
        self.data_type = MODEL_TYPE_METEOR_AD
        self.userid = line[0]
        self.ad_type = line[1]
        self.unitid = line[2]
        self.id = line[3]
        self.version = line[4]
        self.text   = line[5]
        self.text_seg = line[6].split("\x02")
        self.url = line[7]
        self.check_result = []

    def init_from_json(self, json_str):
        """json�����obj
        [in]  line
        [out] 
        """
        meteor_result = json.loads(json_str)
        info = meteor_result["info"]
        self.userid = info["userid"]
        self.ad_type = info["ad_type"]
        self.unitid = info["unitid"]
        self.id= info["id"]
        self.version = info["version"]
        self.text   = info["text"]
        self.text_seg = info["text_seg"]
        self.url = info["url"]
        self.check_result = meteor_result["check_result"]

    def review_result(self):
        """��ʽ��review���
        """
        result = {}
        result["data_type"] = self.data_type
        result["info"] = {}
        result["info"]["userid"] = self.userid
        result["info"]["ad_type"] = self.ad_type
        result["info"]["unitid"] = self.unitid
        result["info"]["id"]= self.id
        result["info"]["version"] = self.version
        result["info"]["text"] = self.text
        result["info"]["text_seg"] = self.text_seg
        result["info"]["url"] = self.url
        result["check_result"] = self.check_result
        return result

class ReviewClickUserObj(ReviewObj):
    """user obj
    """
    def init(self, line):
        """��ʼ������
        [in]  line
        [out] None
        """
        self.data_type = MODEL_TYPE_CLICK_USER
        self.userid = line[0]
        self.idea_list = line[1].split("\x01")
        self.word_list = line[2].split("\x01")
        self.idea_seg_list = [x.split("\x02") for x in line[3].split("\x01")]
        self.word_seg_list = [x.split("\x02") for x in line[4].split("\x01")]
        self.idea_url_list = line[5].split("\x01")
        self.word_url_list = line[6].split("\x01")
        self.check_result = []

    def init_from_json(self, json_str):
        """json�����obj
        [in]  line
        [out] 
        """
        user_result = json.loads(json_str)
        info = user_result["info"]
        self.userid = info["userid"]
        self.idea_list = info["idea_list"]
        self.word_list = info["word_list"]
        self.idea_seg_list = None
        self.word_seg_list = None
        self.idea_url_list = info["idea_url_list"]
        self.word_url_list = info["word_url_list"]
        self.check_result = user_result["check_result"]

    def review_result(self):
        """��ʽ��review���
        """
        result = {}
        result["data_type"] = self.data_type
        result["info"] = {}
        result["info"]["userid"] = self.userid
        result["info"]["word_list"] = self.word_list
        result["info"]["idea_list"] = self.idea_list
        result["info"]["word_url_list"] = self.word_url_list
        result["info"]["idea_url_list"] = self.idea_url_list
        result["check_result"] = self.check_result
        return result


class ReviewUrlObj(ReviewObj):
    """url obj
    """
    def init(self, line):
        """��ʼ������
        """
        self.data_type = MODEL_TYPE_URL
        self.url = line[0]
        self.userid = "0" # ռλ, ��urlԤ����ӳ��Ϊuser���ʱ���
        self.userid_list = line[1].split("|")
        self.src = line[2]
        self.feature_dict = json.loads(line[3])
        self.feature_seg_dict = json.loads(line[4])
        self.check_result = []

    def init_from_json(self, json_str):
        """json�����obj
        [in]  json_str
        [out] 
        """
        user_result = json.loads(json_str)
        info = user_result["info"]
        self.userid = info["userid"]
        self.userid_list = info["userid_list"]
        self.url = info["url"]
        self.src = None
        self.feature_dict = None
        self.feature_seg_dict = None
        self.check_result = user_result["check_result"]

    def review_result(self):
        """��ʽ��review���
        """
        result = {}
        result["data_type"] = self.data_type
        result["info"] = {}
        result["info"]["userid"] = self.userid
        result["info"]["userid_list"] = self.userid_list
        result["info"]["url"] = self.url
        result["check_result"] = self.check_result
        return result


class ReviewFeedAdObj(ReviewObj):
    """feed ad obj
    """
    def init(self, line):
        """��ʼ������
        """
        self.data_type = MODEL_TYPE_FEED_AD
        self.userid = line[0]
        self.planid = line[1]
        self.unitid = line[2]
        self.winfoid= line[3]
        self.ideaid = line[4]
        self.text   = line[5]
        self.text_seg = line[6].split("\x02")
        self.url = line[7]
        self.check_result = []

    def init_from_json(self, json_str):
        """json�����obj
        [in]  line
        [out] 
        """
        click_result = json.loads(json_str)
        info = click_result["info"]
        self.userid = info["userid"]
        self.planid = info["planid"]
        self.unitid = info["unitid"]
        self.winfoid= info["winfoid"]
        self.ideaid = info["ideaid"]
        self.text   = info["text"]
        self.text_seg = info["text_seg"]
        self.url = info["url"]
        self.check_result = click_result["check_result"]

    def review_result(self):
        """��ʽ��review���
        """
        result = {}
        result["data_type"] = self.data_type
        result["info"] = {}
        result["info"]["userid"] = self.userid
        result["info"]["planid"] = self.planid
        result["info"]["unitid"] = self.unitid
        result["info"]["winfoid"]= self.winfoid
        result["info"]["ideaid"] = self.ideaid
        result["info"]["text"] = self.text
        result["info"]["text_seg"] = self.text_seg
        result["info"]["url"] = self.url
        result["check_result"] = self.check_result
        return result


class ReviewFeedUserObj(ReviewObj):
    """feed user obj
    """
    def init(self, line):
        """��ʼ������
        [in]  line
        [out] None
        """
        self.data_type = MODEL_TYPE_FEED_USER
        self.userid = line[0]
        self.text_list = line[1].split("\x01")
        self.text_seg_list = [x.split("\x02") for x in line[2].split("\x01")]
        self.url_list = line[3].split("\x01")
        self.check_result = []

    def init_from_json(self, json_str):
        """json�����obj
        [in]  line
        [out] 
        """
        user_result = json.loads(json_str)
        info = user_result["info"]
        self.userid = info["userid"]
        self.text_list = info["text_list"]
        self.text_seg_list = None
        self.url_list = info["url_list"]
        self.check_result = user_result["check_result"]

    def review_result(self):
        """��ʽ��review���
        """
        result = {}
        result["data_type"] = self.data_type
        result["info"] = {}
        result["info"]["userid"] = self.userid
        result["info"]["text_list"] = self.text_list
        result["info"]["url_list"] = self.url_list
        result["check_result"] = self.check_result
        return result


class ReviewRiskUserObj(object):
    """����ģ��ʶ��ĸ�Σ�˻�
    """
    def __init__(self):
        """init"""
        pass

    def init(self, cols):
        """��ʼ������
        [in]  cols: ��Σ�˻��Ļ�����Ϣ
        """
        self.userid = cols[0]
        self.model_type = int(cols[1])
        self.model_id = int(cols[2])
        self.model_name = cols[3]
        self.label = cols[4]
        self.label_name = cols[5]
        self.evidence = {"word": cols[6].split("||"), "idea": [cols[7]]}
        if len(cols) == 9:
            self.evidence = dict(self.evidence, **{"product": cols[8]})

    def init_from_json(self, json_str):
        """json�����obj
        [in]  line
        [out] 
        """
        risk_user_result = json.loads(json_str)
        self.userid = risk_user_result["userid"]
        self.model_type = risk_user_result["result"]["model_type"]
        self.model_id = risk_user_result["result"]["model_id"]
        self.model_name = risk_user_result["result"]["model_name"]
        self.label_name = risk_user_result["result"]["model_result"]["label_name"]
        self.label = risk_user_result["result"]["model_result"]["label"]
        self.evidence =  risk_user_result["result"]["model_result"]["evidence"]

    def merge_result(self):
        """�ϲ���Σ�˻������dict
        """
        result = {}
        result["model_type"] = self.model_type
        result["model_id"] = self.model_id
        result["model_name"] = self.model_name
        model_result = {}
        model_result["label_name"] = self.label_name
        model_result["label_list"] = []
        model_result["label"] = self.label
        model_result["evidence"] = self.evidence
        result["model_result"] = model_result
        user_result = {}
        user_result["userid"] = self.userid
        user_result["result"] = result
        return user_result


class ReviewUserInfoObj(object):
    """�˻���ϸ��Ϣ
    """
    def __init__(self):
        """init"""
        pass

    def init(self, cols):
        line = "\t".join(cols).decode("gbk", "ignore")
        cols = line.split("\t")
        self.userid  = cols[0]
        self.uname   = cols[1]
        self.ulevel  = cols[2]
        self.ustatus = cols[3]
        self.company = cols[4]
        self.url     = cols[5]
        self.register= cols[6]
        self.isztc   = cols[7]
        self.optids  = cols[8]
        self.opts    = cols[9]
        self.main_lice_ids = cols[10]
        self.main_lices   = cols[11]
        self.consume = "0.0" if len(cols) < 13 else cols[12] # ��һ��Q������

    def get_user_info(self):
        """��ȡ�˻�������Ϣ
        """
        user_info = {}
        user_info["userid"]  = self.userid
        user_info["uname"]   = self.uname
        user_info["ulevel"]  = self.ulevel
        user_info["ustatus"] = self.ustatus
        user_info["company"] = self.company
        user_info["url"]     = self.url
        user_info["register"]= self.register
        user_info["isztc"]   = self.isztc
        user_info["optids"]  = self.optids
        user_info["opts"]    = self.opts
        user_info["main_lice_ids"]  = self.main_lice_ids
        user_info["main_lices"]    = self.main_lices
        user_info["consume"] = self.consume
        return user_info


class MeteorAd(object):
    def __init__(self, line):
        """meteor audit������˽��
        """
        self.data_type = MODEL_TYPE_METEOR
        self.userid = line[0]
        self.productid = line[1]
        self.planid = line[2]
        self.unitid = line[3]
        self.audit_type = line[4]      # word, idea, pair
        self.review_result = line[5]   # APPROVED, DISAPPROVED
        self.is_need_audit = line[6]   # 1.����
        self.haudit_type = line[7]     # -1.����
        self.winfoid = line[8]
        self.wordtext = line[9]
        self.wurl = line[10]
        self.ideaid = line[11]
        self.idea = line[12]
        self.targeturl = line[13]
        self.risk_id = line[14]        # ����id
        self.risk_model_id = line[15]  # ����ģ��id


class MeteorUser(object):
    """meteor���, userά�ȵĻ���ͳ������, ȡ������������ģ�ͽ��
    """
    def __init__(self):
        """init
        """
        self.userid = None
        self.total_ads_num = 0         # �ܻ���������
        self.total_is_need_audit = 0   # �ܻ�������������
        self.total_disapproved = 0     # ����ܾ���
        self.model_result = {}         # ���е�ģ��, �ܾ���, ֤��: modelid -> [num, evidence{}]

    def init_model_result_by_model(self, model):
        """��ʼ��model_result
        """
        model_id = model["model_id"]
        self.model_result[model_id] = {}
        self.model_result[model_id]["opt_args"] = {} if "opt_args" not in model else model["opt_args"]
        self.model_result[model_id]["hit_ad_num"] = 0
        self.model_result[model_id]["model_name"] = model["model_name"]
        self.model_result[model_id]["model_type"] = model["model_type"]
        evidence = {}
        evidence["word"] = set()
        evidence["idea"] = set()
        self.model_result[model_id]["evidence"] = evidence


if __name__ == "__main__":
    """
    a = CheckResultObj()
    a.init("1","None",[])
    print a.opt
    a.opt[1] = 1
    print a.opt
    b = CheckResultObj()
    b.init("1","None",[])
    print b.opt
    """
    pass
