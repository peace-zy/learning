#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
Author:   zhanghao55@baidu.com
Date  :   20/04/09 15:56:22
Desc  :   ����ѵ������
"""

import sys
import argparse
import six
import logging


class ArgParser(object):
    """����������
    """
    def __init__(self):
        """��ʼ��
        """
        parser = argparse.ArgumentParser()

        model_g = ArgumentGroup(parser, "model", "model configuration and paths.")
        model_g.add_arg("config_path", str, None, "Path to the json file for model config.")
        model_g.add_arg("checkpoint_path", str, None, "Init checkpoint to resume training from.")
        model_g.add_arg("ckpt_dir", str, None, "Directory path to save checkpoints")
        model_g.add_arg("task_mode", str, None, "task mode: pairwise or pointwise")

        train_g = ArgumentGroup(parser, "training", "training options.")
        train_g.add_arg("epoch", int, 10, "Number of epoches for training.")
        train_g.add_arg("save_steps", int, 200, "The steps interval to save checkpoints.")
        train_g.add_arg("validation_steps", int, 100, "The steps interval to evaluate model performance.")

        log_g = ArgumentGroup(parser, "logging", "logging related")
        log_g.add_arg("print_steps", int, 100, "The steps interval to print loss.")
        log_g.add_arg("verbose_result", bool, True, "Whether to output verbose result.")
        log_g.add_arg("valid_result_path", str, "test_result", "Directory path to test result.")
        log_g.add_arg("infer_result_path", str, "infer_result", "Directory path to infer result.")

        data_g = ArgumentGroup(parser, "data", "Data paths, vocab paths and data processing options")
        data_g.add_arg("train_data_dir", str, None, "Directory path to training data.")
        data_g.add_arg("valid_data_dir", str, None, "Directory path to testing data.")
        data_g.add_arg("infer_data_dir", str, None, "Directory path to infer data.")
        data_g.add_arg("vocab_path", str, None, "Vocabulary path.")
        data_g.add_arg("batch_size", int, 32, "Total examples' number in batch for training.")

        run_type_g = ArgumentGroup(parser, "run_type", "running type options.")
        run_type_g.add_arg("use_cuda", bool, False, "If set, use GPU for training.")
        run_type_g.add_arg("task_name", str, None, "The name of task to perform siamese model.")
        run_type_g.add_arg("do_train", bool, False, "Whether to perform training.")
        run_type_g.add_arg("do_valid", bool, False, "Whether to perform dev.")
        run_type_g.add_arg("do_test", bool, False, "Whether to perform testing.")
        run_type_g.add_arg("do_infer", bool, False, "Whether to perform inference.")
        run_type_g.add_arg("compute_accuracy", bool, False, "Whether to compute accuracy.")
        run_type_g.add_arg("lamda", float, 0.91, 
                "When task_mode is pairwise, lamda is the threshold for calculating the accuracy.")

        custom_g = ArgumentGroup(parser, "customize", "customized options.")
        self.custom_g = custom_g

        parser.add_argument('--enable_ce', action='store_true', 
                help='If set, run the task with continuous evaluation logs.')

        self.parser = parser

    def add_arg(self, name, dtype, default, descrip):
        """�������ò���
        [in]  name: str, ������
              dtype: type, ��������
              default: Ĭ��ֵ
              descrip: str, ����
        [out] None
        [Author] zhanghao55
        """
        self.custom_g.add_arg(name, dtype, default, descrip)

    def get_args(self):
        """��ò������
        [in]  None
        [out] �����������
        [Author] zhanghao55
        """
        return self.parser.parse_args()


class ArgumentGroup(object):
    """
    �������ø�����
    """
    def __init__(self, parser, title, des):
        """��ʼ��
        [in]  parser: ArgumentParser, ����������
              title: str, ��������
              des: str, ����
        [out] None
        [Author] zhanghao55
        """
        self._group = parser.add_argument_group(title=title, description=des)

    def add_arg(self, name, type, default, help, **kwargs):
        """���Ӳ���
        [in]  name: str, ������
              type: type, ��������
              default: Ĭ��ֵ
              help: str, ������Ϣ
              kwargs: �������
        [out] None
        [Author] zhanghao55
        """
        type = str2bool if type == bool else type
        self._group.add_argument(
            "--" + name,
            default=default,
            type=type,
            help=help + ' Default: %(default)s.',
            **kwargs)


def str2bool(string):
    """�ַ���תbool
    [in]  string: str, �ַ���
    [out] bool, bool���ͽ��
    [Author] zhanghao55
    """
    return string.lower() in ("true", "t", "1")


def print_arguments(args):
    """��ӡ������Ϣ
    [in]  args: ����������Ϣ 
    [out] None
    [Author] zhanghao55
    """
    print('-----------  Configuration Arguments -----------')
    for arg, value in sorted(six.iteritems(vars(args))):
        print('%s: %s' % (arg, value))
    print('------------------------------------------------')


if __name__ == "__main__":
    pass
