#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
Author:   zhanghao55@baidu.com
Date  :   20/04/03 12:04:18
"""

import sys
import paddle.fluid as fluid


class SoftmaxCrossEntropyLoss(object):
    """SoftmaxCrossEntropyLoss������
    """
    def __init__(self, conf_dict):
        """��ʼ��
        [in]  conf_dict: dict, �����ֵ�
        [out] None
        [author] zhanghao55
        """
        pass

    def compute(self, input, label):
        """��ʧ����
        [in]  input: array_like, Ԥ����
              label: array_like, ʵ�ʽ��
        [out] avg_cost: ƽ����ʧ
        [author] zhanghao55
        """
        reduce_mean = ReduceMeanLayer()
        cost = fluid.layers.cross_entropy(input=input, label=label)
        avg_cost = reduce_mean.ops(cost)
        return avg_cost


class HingeLoss(object):
    """HingeLoss������
    """
    def __init__(self, conf_dict):
        """��ʼ��
        [in]  conf_dict: dict, �����ֵ�
        [out] None
        [author] zhanghao55
        """
        self.margin = conf_dict["loss"]["margin"]

    def compute(self, pos, neg):
        """����
        [in]  pos: array_like, �������÷�
              neg: array_like, �������÷�
        [out] loss: ������ʧ
        [author] zhanghao55
        """
        elementwise_max = ElementwiseMaxLayer()
        elementwise_add = ElementwiseAddLayer()
        elementwise_sub = ElementwiseSubLayer()
        constant = ConstantLayer()
        reduce_mean = ReduceMeanLayer()

        ele_sub_with_margin = elementwise_add.ops(
                elementwise_sub.ops(neg, pos),
                constant.ops(neg, neg.shape, "float32", self.margin))

        hinge_res = elementwise_max.ops(
                constant.ops(neg, neg.shape, "float32", 0.0),
                ele_sub_with_margin)

        loss = reduce_mean.ops(hinge_res)

        return loss


class ReduceMeanLayer(object):
    """ReduceMeanLayer��
    """
    def __init__(self):
        """��ʼ��
        """
        pass

    def ops(self, input):
        """����
        """
        mean = fluid.layers.reduce_mean(input)
        return mean


class ElementwiseMaxLayer(object):
    """ElementwiseMaxLayer��
    """
    def __init__(self):
        """��ʼ��
        """
        pass

    def ops(self, x, y):
        """����
        """
        max = fluid.layers.elementwise_max(x, y)
        return max


class ElementwiseAddLayer(object):
    """ElementwiseAddLayer��
    """
    def __init__(self):
        """��ʼ��
        """
        pass

    def ops(self, x, y):
        """����
        """
        add = fluid.layers.elementwise_add(x, y)
        return add


class ElementwiseSubLayer(object):
    """ElementwiseSubLayer��
    """
    def __init__(self):
        """��ʼ��
        """
        pass

    def ops(self, x, y):
        """����
        """
        sub = fluid.layers.elementwise_sub(x, y)
        return sub


class ConstantLayer(object):
    """ConstantLayer����
    """
    def __init__(self):
        """��ʼ��
        """
        pass

    def ops(self, input, shape, dtype, value):
        """����
        """
        constant = fluid.layers.fill_constant_batch_size_like(
                input, shape, dtype, value)
        return constant
