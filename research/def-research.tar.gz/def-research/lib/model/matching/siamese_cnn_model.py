#!/usr/bin/env python
# -*- coding:gb18030 -*-
"""
Author:   zhanghao55@baidu.com
Date  :   20/04/03 11:49:26
"""

import logging
import numpy as np
import os
import sys
import paddle.fluid as fluid
import time

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../../" % _cur_dir)

from common.logger import init_log
init_log("./log/TextSimilarityNet")
from common.data_io import write_to_file
from common.token_encoder import TokenEncoder

from arg_parser import ArgParser, print_arguments
from losses import SoftmaxCrossEntropyLoss
from optimizers import AdamOptimizer
from reader import SimModelReaders
from siamese_cnn_net import SiameseCNN
from utils import get_config, init_checkpoint, import_class, lodtensor_to_list, check_version, check_cuda


def create_model(sim_cnn_model, loss, optimizer, is_inference, is_pointwise):
    """����ģ��ѵ������֤����
    [in]  sim_cnn_model: SiameseCNN����ṹ
          loss: ��ʧ����
          optimizer: �Ż���
          is_inference: �Ƿ�ΪԤ��
          is_pointwise: �Ƿ�Ϊpointwise
    [out] res_dict: �����������빤�ߡ�main_program��startup_program��
                    ģ���������ʧֵ��һϵ��ģ��Ԥ�⡢ѵ��ʱ����Ϣ
    [author] zhanghao55
    """
    res_dict = dict()
    cur_main_prog = fluid.Program()
    cur_startup_prog = fluid.Program()
    res_dict["main_prog"] = cur_main_prog
    res_dict["startup_prog"] = cur_startup_prog

    with fluid.program_guard(cur_main_prog, cur_startup_prog):
        with fluid.unique_name.guard():
            # �����ģ�� ��ͬһ��main_program��ſɼ� ��Ȼ�ᱨ�� Ϊnull
            left = fluid.data(name="left_input", shape=[-1], lod_level=1, dtype='int64')
            right = fluid.data(name="right_input", shape=[-1], lod_level=1, dtype='int64')

    res_dict["input1"] = left
    res_dict["input2"] = right

    # �����Ԥ�⣬��ֻ���������� ���:startup_program, test_program��data_loader��pred���
    if is_inference:
        data_loader = fluid.io.DataLoader.from_generator(
                feed_list=[left, right],
                capacity=64,
                use_double_buffer=True,
                iterable=True)

        with fluid.program_guard(cur_main_prog, cur_startup_prog):
            with fluid.unique_name.guard():
                left_feat, pred = sim_cnn_model.predict(left, right)
                res_dict["pred"] = pred
        cur_main_prog = cur_main_prog.clone(for_test=True)
    else:
    # �����ѵ�� ������������ �����startup_program, train_program, data_loader, loss
        if is_pointwise:
            with fluid.program_guard(cur_main_prog, cur_startup_prog):
                with fluid.unique_name.guard():
                    label = fluid.data(name="label", shape=[-1], dtype='int64')
                    res_dict["label"] = label
                    left_feat, pred = sim_cnn_model.predict(left, right)
                    res_dict["left_feat"] = left_feat
                    res_dict["pred"] = pred
                    avg_cost = loss.compute(pred, label)
                    avg_cost.persistable = True
                    res_dict["loss"] = avg_cost
                    optimizer.ops(avg_cost)

            data_loader = fluid.io.DataLoader.from_generator(
                    feed_list=[left, right, label],
                    capacity=64,
                    use_double_buffer=True,
                    iterable=True)
        else:
            with fluid.program_guard(cur_main_prog, cur_startup_prog):
                with fluid.unique_name.guard():
                    right2 = fluid.data(name="right_input2", shape=[-1], lod_level=1, dtype='int64')
                    res_dict["input3"] = right2
                    left_feat, pos_score = sim_cnn_model.predict(left, right)
                    res_dict["left_feat"] = left_feat
                    res_dict["pred"] = pos_score
                    _, neg_score = sim_cnn_model.predict(left, right2)
                    avg_cost = loss.compute(pos_score, neg_score)
                    avg_cost.persistable = True
                    res_dict["loss"] = avg_cost
                    optimizer.ops(avg_cost)

            data_loader = fluid.io.DataLoader.from_generator(
                    feed_list=[left, right, right2],
                    capacity=64,
                    use_double_buffer=True,
                    iterable=True)

    res_dict["data_loader"] = data_loader
    return res_dict

class SiameseCNNModel():
    """����CNN����
    """
    def __init__(self, args):
        """��ʼ��
        [in]  args: ����ѵ����Ԥ��ʱһϵ�в���
        [out] None
        [author] zhanghao55
        """
        # ��֤paddle�汾
        check_version()

        # ������������
        self.args = args

        # ���������������
        self.conf_dict = get_config(args.config_path)

        # ����token_encoder
        self.token_encoder = TokenEncoder(args.vocab_path, is_file=True, oov=None, encoding="utf8")

        # �������ݼ��غ���
        self.sim_model_reader = SimModelReaders(self.token_encoder)

        self.is_pointwise = False if args.task_mode == "pairwise" else True

        # ���Ӵʵ��С
        self.conf_dict['vocab_size'] = len(self.token_encoder)

        # ��ʼ������ģ��
        self.sim_cnn_model = import_class(
                self.conf_dict["module_path"],
                self.conf_dict["net"]["module_name"],
                self.conf_dict["net"]["class_name"])(self.conf_dict)

        # ������ʧ����
        self.loss = import_class(
                self.conf_dict["module_path"],
                self.conf_dict["loss"]["module_name"],
                self.conf_dict["loss"]["class_name"])(self.conf_dict)
        # �����Ż�
        self.optimizer = import_class(
                self.conf_dict["module_path"],
                self.conf_dict["optimizer"]["module_name"],
                self.conf_dict["optimizer"]["class_name"])(self.conf_dict)

        # ȷ��ִ�л���
        if args.use_cuda:
            check_cuda(True)
            place = fluid.CUDAPlace(0)
            # ȷ�����ݴ�������
            self.data_place = fluid.cuda_places(0)
        else:
            place = fluid.CPUPlace()
            self.data_place = fluid.cpu_places(8)
        self.exe = fluid.Executor(place)

    def run(self):
        """�������
        """
        if self.args.do_train:
            self.train()
        if self.args.do_test:
            self.valid()
        if self.args.do_infer:
            self.infer()

    def train(self):
        """ѵ��
        """
        # ����program
        train_dict = create_model(self.sim_cnn_model, self.loss, self.optimizer, False, self.is_pointwise)
        train_data_loader = train_dict["data_loader"]
        train_prog = train_dict["main_prog"]
        train_startup_prog = train_dict["startup_prog"]
        avg_cost = train_dict["loss"]

        data_input = fluid.io.batch(lambda: self.sim_model_reader.generate_data(
                self.args.train_data_dir,
                self.args.task_mode,
                "train"), batch_size=self.args.batch_size)
        data_input = fluid.io.shuffle(data_input, buf_size=self.args.batch_size * 3)
        train_data_loader.set_sample_list_generator(data_input, places=self.data_place)

        self.exe.run(train_startup_prog)
        if self.args.checkpoint_path is not "":
            init_checkpoint(self.exe, self.args.checkpoint_path, train_startup_prog)

        global_steps = 0
        for epoch_ind in range(self.args.epoch):
            print("epoch {}:".format(epoch_ind))
            for data in train_data_loader():
                loss_value = self.exe.run(program=train_prog, feed=data, fetch_list=[avg_cost.name])
                if global_steps % self.args.print_steps == 0:
                    print("step {}: loss = {}".format(global_steps, loss_value[0]))
                global_steps += 1

            if self.args.do_valid:
                self.valid(need_init=False)

            if not os.path.exists(self.args.ckpt_dir):
                os.makedirs(self.args.ckpt_dir)

            model_path = os.path.join(self.args.ckpt_dir, "epoch_{}".format(epoch_ind + 1))

            feed_var_names = [train_dict["input1"].name, train_dict["input2"].name]
            target_vars = [train_dict["left_feat"], train_dict["pred"]]

            fluid.io.save_inference_model(model_path, feed_var_names,
                                          target_vars, self.exe, train_prog)
            logging.info("saving infer model in %s" % model_path)

    def valid(self, need_init=True):
        """��֤
        [in]  need_init: �Ƿ���Ҫ����ģ��
        [author] zhanghao55
        """
        pred_list, input_list = self.pred("valid", self.args.valid_data_dir, need_init)
        valid_label_list = self.sim_model_reader.get_valid_label(self.args.valid_data_dir)

        valid_label_list = valid_label_list[:len(pred_list)]
        # aucԤ��
        auc_metric = fluid.metrics.Auc(name="auc")
        auc_metric.reset()
        auc_metric.update(pred_list, valid_label_list)
        auc = auc_metric.eval()

        # accԤ��
        # ����Ԥ����
        if self.args.task_mode == "pointwise":
            pred_list = np.array([np.argmax(x) for x in pred_list])
        elif self.args.task_mode == "pairwise":
            pred_list = np.where(pred_list >= self.args.lamda, 1, 0)

        acc = np.mean(pred_list == valid_label_list)

        logging.info("valid res: acc = {}, auc = {}".format(acc, auc))

        def valid_info_generator():
            """��֤�����Ϣ����
            """
            for pred_label, valid_label, (cur_input1, cur_input2) in  zip(pred_list, valid_label_list, input_list):
                input1_str = [self.token_encoder.inverse_transform(x) for x in cur_input1]
                input2_str = [self.token_encoder.inverse_transform(x) for x in cur_input2]
                input1_str = "".join(input1_str)
                input2_str = "".join(input2_str)
                yield "\t".join([str(pred_label), str(valid_label), input1_str, input2_str])

        write_to_file(valid_info_generator(), self.args.valid_result_path)
        logging.info("save valid res into file: {}".format(self.args.valid_result_path))

    def infer(self, need_init=True):
        """Ԥ��
        [in]  need_init: �Ƿ���Ҫ����ģ��
        [author] zhanghao55
        """
        pred_list, input_list = self.pred("infer", self.args.infer_data_dir, need_init)

        # ����Ԥ����
        if self.args.task_mode == "pointwise":
            pred_list = [str(np.argmax(x)) for x in pred_list]
        elif self.args.task_mode == "pairwise":
            pred_list = np.where(pred_list >= self.args.lamda, 1, 0)

        def infer_info_generator():
            """Ԥ������Ϣ����
            """
            for pred_label, (cur_input1, cur_input2) in  zip(pred_list, input_list):
                input1_str = [self.token_encoder.inverse_transform(x) for x in cur_input1]
                input2_str = [self.token_encoder.inverse_transform(x) for x in cur_input2]
                input1_str = "".join(input1_str)
                input2_str = "".join(input2_str)
                yield "\t".join([str(pred_label), input1_str, input2_str])

        write_to_file(infer_info_generator(), self.args.infer_result_path)
        logging.info("save infer res into file: {}".format(self.args.infer_result_path))


    def pred(self, exe_type, data_dir, need_init=True):
        """��֤��Ԥ��ͨ�õ�ģ��Ԥ����
        [in]  exe_type: str, ִ������, valid��infer
              data_dir: str, ���ݵ�ַ
              need_init: bool, �Ƿ���Ҫ����ģ��
        [out] pred_list: array-like, Ԥ��������, ��Ϊ(data_size, 2), ���зֱ���0��1�ĸ���
              input_list: array-like, ��������, ��Ϊ(data_size, 2), ���зֱ���Ԥ������Ե������ַ���
        [author] zhanghao55
        """
        start_time = time.time()
        train_dict = create_model(self.sim_cnn_model, None, None, True, self.is_pointwise)
        data_loader = train_dict["data_loader"]
        main_prog = train_dict["main_prog"]
        startup_prog = train_dict["startup_prog"]
        pred_res = train_dict["pred"]
        input1 = train_dict["input1"]
        input2 = train_dict["input2"]
        logging.debug("creat {} model, cost time: {}s".format(exe_type, time.time() - start_time))

        if need_init:
            start_time = time.time()
            self.exe.run(startup_prog)
            init_checkpoint(self.exe, self.args.checkpoint_path, main_program=main_prog)
            logging.debug("load model from {}, cost time: {}s".format(
                    self.args.checkpoint_path,
                    time.time() - start_time))

        # sim_model_reader.generate_data���ɵ��Ƕ�Ԫ����б�
        # ֱ�Ӵ���data_loader�Ļ�ά����״����
        # ��Ҫbatch����һ��
        # �����޸�generate_data���ɵ����ݸ�ʽ
        # Ԥ��ʱ������
        data_input = fluid.io.batch(lambda: self.sim_model_reader.generate_data(
                data_dir,
                self.args.task_mode,
                exe_type), batch_size=self.args.batch_size)

        data_loader.set_sample_list_generator(data_input, places=self.data_place)

        pred_list = list()
        input_list = list()
        for batch_ind, batch_data in enumerate(data_loader()):
            if batch_ind % 100 == 0:
                print("batch {}".format(batch_ind))
            cur_pred_label, input1_lod, input2_lod = self.exe.run(
                    program=main_prog,
                    feed=batch_data,
                    fetch_list=[pred_res.name, input1.name, input2.name],
                    return_numpy=False)
            cur_pred_label = np.array(cur_pred_label)
            input1_list = lodtensor_to_list(input1_lod)
            input2_list = lodtensor_to_list(input2_lod)
            pred_list.extend(cur_pred_label)
            input_list.extend(zip(input1_list, input2_list))

        # ����Ԥ����
        # ����Ϊ���У��ֱ�Ϊ0��1�ĸ���
        if self.args.task_mode == "pairwise":
            pred_list = (pred_list + 1) / 2
            pred_list = np.hstack((np.ones_like(pred_list) - pred_list, pred_list))
        elif self.args.task_mode == "pointwise":
            pred_list = np.array(pred_list)

        return pred_list, input_list


if __name__ == "__main__":
    args = ArgParser()
    args = args.get_args()

    # չʾ������Ϣ
    print_arguments(args)

    model = SiameseCNNModel(args)
    model.run()
