#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   20/03/27 16:58:04
Desc  :   ��ȡ�ֵ�
          python preprocess/vocab.py --train_file "train.txt" --vocab_file "vocab.txt"
"""
import os
import sys
import argparse
import time

_cur_dir = os.path.dirname(os.path.abspath(__file__))
_dict_dir = "%s/../../dict/" % _cur_dir
# �м��ļ��洢
_mid_dir = "%s/../mid/" % _cur_dir
if not os.path.exists(_mid_dir):
    os.makedirs(_mid_dir)

from preprocess import Preprocess

def args_func():
    """�������
    """
    parser = argparse.ArgumentParser(description = "preprocess")
    parser.add_argument("-fin", "--train_file", help = "�����ļ���ַ", required = True)
    parser.add_argument("-fout", "--vocab_file", help = "�ֵ��ļ���ַ", required = True)
    parser.add_argument("--wordseg", help = "�Ƿ���Ҫ�д�", action = "store_true")

    args = parser.parse_args()
    return args

def args_parse(args):
    """���������ִ��
    """
    seg_dict_path = os.path.join(_dict_dir, "chinese_gbk")
    stopword_path = os.path.join(_dict_dir, "stopword.txt")
    nstopword_path = os.path.join(_dict_dir, "nstopword.txt")

    processor = Preprocess()
    processor.init(seg_dict_path, stopword_path, nstopword_path)
    vocab = dict()
    with open(args.train_file, "r") as f:
        for eachline in f:
            line = eachline.strip("\n").decode("gbk", "ignore").lower()
            cols = line.split("\t")
            label = cols[0]
            text  = cols[1]
            if args.wordseg:
                seg_list = processor.word_seg(text)
            else:
                seg_list = text.split(" ")
            ngram = processor.get_process_list(seg_list, del_stopword=True, del_nc=True)
            for n in ngram:
                if n not in vocab:
                    vocab[n] = 0
                vocab[n] += 1
    processor.write_vocab_dict(args.vocab_file, vocab, wordcount=False, info=False)
    processor.destroy()


if __name__ == "__main__":
    args = args_func()
    start = time.time()
    args_parse(args)
    end = time.time()
    print "total time: %f" % (end - start)


