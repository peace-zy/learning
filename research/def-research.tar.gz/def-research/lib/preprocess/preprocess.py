#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   19/04/12 20:25:45
Desc  :   Ԥ����
"""
import sys
import os

_cur_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append("%s/../common/" % _cur_dir)
from common import Common
import word_seg

class Preprocess(object):
    """����Ԥ����, �������ݱ���Ϊunicode
    """
    def __init__(self):
        """init"""
        pass

    @staticmethod
    def split_train_val(ori_path, train_path, val_path, train_percent=0.8):
        """����ѵ������֤��
        [in]  ori_path: ԭʼ���ݵ�ַ
              train_path: ѵ�������ݵ�ַ
              val_path: ��֤�����ݵ�ַ
              train_percent: ����ѵ�����ݱ�����Ĭ��80%
        """
        import random
        with open(ori_path, "r") as fo:
            with open(train_path, "w") as ft:
                with open(val_path, "w") as fv:
                    for line in fo:
                        randnum = random.random()
                        if randnum < train_percent:
                            ft.write(line)
                        else:
                            fv.write(line)

    def init(self, segdict_path, stopword_path, nstopword_path):
        """��ʼ��Ԥ����
        [in]  segdict_path: �дʴʵ�
              stopword: ͣ�ôʼ���
              nstopword: ��ͣ�ôʼ���
        [out] None
        """
        self.stopword = Common.load_word_file(stopword_path)
        self.nstopword = Common.load_word_file(nstopword_path)
        self.word_segger = word_seg.WordSeg(segdict_path)
        self.word_segger.init_wordseg_handle()

    def word_seg(self, text):
        """�д�
        [in]  text: unicode
        """
        token_list = self.word_segger.seg_words(text.encode("gbk", "ignore"))
        token_list = map(lambda x:x.decode("gbk", "ignore"), token_list)
        return token_list

    def get_ngram_feature(self, seg_list, use_re=False):
        """��ȡδ���������д��б���ngram����
        """
        return Common.ngram_feature(seg_list, self.stopword, self.nstopword, use_re)

    def get_ngram_feature_without_set(self, seg_list, use_re=False):
        """��ȡδ�����������д��б��Ĳ�ʹ��setȥ�ص�ngram���������ڼ���tf��Ƶ����
        """
        return Common.ngram_feature_without_set(seg_list, self.stopword, self.nstopword, use_re)

    def get_process_list(self, seg_list, del_stopword=True, del_nc=True):
        """��ȡδ���������д��б��Ĵ�������б�
        """
        return Common.process_list(seg_list, self.stopword, del_stopword, del_nc)

    def get_vocab_dict(self, vocab_path, unk=False):
        """��ȡ�ʵ�
        """
        return Common.load_vocab(vocab_path, unk)

    def get_idf_dict(self, vocab_path):
        """��ȡidf�ʵ�
        """
        return Common.load_idf_dict(vocab_path)

    def get_tf_dict(self, seg_list):
        """��ȡtf��Ƶ�ʵ�
        """
        word_num = len(seg_list)
        tf_dict = {}
        for seg in seg_list:
            tf_dict[seg] = tf_dict.get(seg, 0.0) + 1.0
        return tf_dict

    def write_vocab_dict(self, vocab_path, vocab, idf_vocab=None, wordcount=True, info=True, is_idf=False):
        """����index \t word \t count�ĸ�ʽд���ļ�
        """
        return Common.write_vocab(vocab_path, vocab, idf_vocab, wordcount, info, is_idf)

    def gramtext_map(self, seg_list, vocab):
        """ngram�ı�תΪliblinear�����ʽ
        [in]  seg_list: ngram list
              vocab: dict, ѵ���������Ĵʵ�
        [out] wids: ngram�ı�ӳ�䵽vocab�ϵ�ids
        """
        wids = []
        for word in seg_list:
            if word in vocab:
                wids.append(vocab[word])
        wids.sort()
        return wids

    def data_map(self, seg_list, vocab):
        """
        Convert word sequence into slot
        """
        unk_id = len(vocab) - 1
        wids = [vocab[x] if x in vocab else unk_id
                        for x in seg_list]
        return wids

    def get_liblinear_format(self, wids):
        """[1,3,4,55] --> 1:1 \t 3:1 \t 4:1 \t 55:1
        """
        return "\t".join(map(lambda x:str(x)+":1", wids))

    def get_tfidf_format(self, wids, index_dict, tfidf_dict):
        """
        [in] index, index_dict, tfidf-dict
        [out] index:tfidf_value ���� 1:0.5 \t 2:0.6
        """
        value_list = []
        for w in wids:
            value_list.append(tfidf_dict[index_dict[w]])
        word_num = len(wids)
        tfidf_list = [str(wids[i]) + ":" + str(value_list[i]) for i in range(word_num)]
        return "\t".join(tfidf_list)


    def destroy(self):
        """
        �ͷ��д�
        """
        self.word_segger.destroy_wordseg_handle()


if __name__ == "__main__":
    pass


