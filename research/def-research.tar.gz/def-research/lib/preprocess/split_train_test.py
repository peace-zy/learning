#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   20/03/27 16:58:04
Desc  :   ��ȡ�ֵ�
          python preprocess/split_train_test.py --file "all.txt" --train "train.txt" --test "test.txt"
"""
import os
import sys
import argparse
import time

_cur_dir = os.path.dirname(os.path.abspath(__file__))

from preprocess import Preprocess

def args_func():
    """�������
    """
    parser = argparse.ArgumentParser(description = "preprocess")
    parser.add_argument("-fin", "--file", help = "���������ļ���ַ", required = True)
    parser.add_argument("-fout1", "--train", help = "ѵ�����ݵ�ַ", required = True)
    parser.add_argument("-fout2", "--test", help = "�������ݵ�ַ", required = True)

    args = parser.parse_args()
    return args

def args_parse(args):
    """���������ִ��
    """
    processor = Preprocess()
    processor.split_train_val(args.file, args.train, args.test)

if __name__ == "__main__":
    args = args_func()
    start = time.time()
    args_parse(args)
    end = time.time()
    print "total time: %f" % (end - start)


