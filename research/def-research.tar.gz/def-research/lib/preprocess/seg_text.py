#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   20/03/30 10:19:04
Desc  :   �����Ҫ�дʣ�ʹ������ļ��������ļ���ʽ: label \t text
          python preprocess/seg_text.py --input_file "mid/file.txt" --output_file "mid/seg_file.txt"
"""
import os
import sys
import argparse
import time

_cur_dir = os.path.dirname(os.path.abspath(__file__))
_dict_dir = "%s/../../dict/" % _cur_dir
# �м��ļ��洢
_mid_dir = "%s/../mid/" % _cur_dir
if not os.path.exists(_mid_dir):
    os.makedirs(_mid_dir)

from preprocess import Preprocess

def args_func():
    """�������
    """
    parser = argparse.ArgumentParser(description = "wordseg")
    parser.add_argument("-fin", "--input_file", help = "�����ļ���ַ", required = True)
    parser.add_argument("-fout", "--output_file", help = "�д��ļ���ַ", required = True)

    args = parser.parse_args()
    return args

def args_parse(args):
    """���������ִ��
    """
    seg_dict_path = os.path.join(_dict_dir, "chinese_gbk")
    stopword_path = os.path.join(_dict_dir, "stopword.txt")
    nstopword_path = os.path.join(_dict_dir, "nstopword.txt")

    processor = Preprocess()
    processor.init(seg_dict_path, stopword_path, nstopword_path)
    with open(args.input_file, "r") as fi:
        with open(args.output_file, "w") as fo:
            for eachline in fi:
                line = eachline.strip("\n").decode("gbk", "ignore").lower()
                cols = line.split("\t")
                label = cols[0]
                text  = cols[1]
                seg_list = processor.word_seg(text)
                fo.write("%s\t%s\n" % (label, " ".join(seg_list)))
    processor.destroy()


if __name__ == "__main__":
    args = args_func()
    start = time.time()
    args_parse(args)
    end = time.time()
    print "total time: %f" % (end - start)


