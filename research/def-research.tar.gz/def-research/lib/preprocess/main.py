#!/usr/bin/env python
# -*- coding:gbk -*-
"""
Author:   zhuxiaodong01@baidu.com
Date  :   20/03/12 15:05:01
Desc  :   python preprocess/main.py --type "liblinear" --sample_file "a.txt" --process_file "b.txt" --ngram_file "c.txt" --vocab_file "d.txt" --wordseg --is_train
"""
import os
import sys
import argparse
import time
import math

_cur_dir = os.path.dirname(os.path.abspath(__file__))
_dict_dir = "%s/../../dict/" % _cur_dir

from preprocess import Preprocess

def args_func():
    """�������
    """
    parser = argparse.ArgumentParser(description = "sample")
    parser.add_argument("-t", "--type", \
            help = "���Ԥ������ʽ��liblinear, onehot�ȷ�ʽ", \
            default = "liblinear", required = True)
    parser.add_argument("-fin", "--sample_file", help = "�����ļ���ַ", required = True)
    parser.add_argument("-fout", "--process_file", help = "Ԥ�����ļ���ַ", required = True)
    parser.add_argument("--ngram_file", help = "ngram���ļ���ַ", required = True)
    parser.add_argument("--vocab_file", help = "�ʵ��ļ���ַ", required = False)
    parser.add_argument("--wordseg", help = "�Ƿ���Ҫ�д�", action = "store_true")
    parser.add_argument("--is_train", help = "�Ƿ���ѵ��������Ԥ����", action = "store_true")

    args = parser.parse_args()
    return args

def args_parse(args):
    """���������ִ��
    """

    seg_dict_path = os.path.join(_dict_dir, "chinese_gbk")
    stopword_path = os.path.join(_dict_dir, "stopword.txt")
    nstopword_path = os.path.join(_dict_dir, "nstopword.txt")

    processor = Preprocess()
    processor.init(seg_dict_path, stopword_path, nstopword_path)
    vocab = dict()
    doc_count = 0 #ͳ��tf-idf�е�doc�������������ı�����
    idf_vocab = dict()
    with open(args.sample_file, "r") as f:
        with open(args.ngram_file, "w") as fm:
            for eachline in f:
                line = eachline.strip("\n").decode("gbk", "ignore").lower()
                cols = line.split("\t")
                label = cols[0]
                text  = cols[1]
                if args.wordseg:
                    seg_list = processor.word_seg(text)
                else:
                    seg_list = text.split(" ")
                if args.type == "liblinear":
                    ngram = processor.get_ngram_feature(seg_list)
                elif args.type == "onehot":
                    ngram = processor.get_process_list(seg_list, del_stopword=False, del_nc=False)
                elif args.type == "tfidf":
                    ngram = processor.get_ngram_feature(seg_list) #��ȡngram
                    all_ngram = processor.get_ngram_feature_without_set(seg_list) #��ȡδ��set��ngram���ں��������Ƶ
                    doc_count += 1 
                else:
                    sys.stderr.write("preprocess type: [liblinear, onehot, tfidf]")
                    break
                for n in ngram:
                    if n not in vocab:
                        vocab[n] = 0
                    vocab[n] += 1
                if args.type != "tfidf":
                    fm.write("%s\t%s\n" % (label, " ".join([x for x in ngram])))
                else:
                    fm.write("%s\t%s\n" % (label, " ".join([x for x in all_ngram])))

    # �ʵ�
    if args.is_train:
        if args.type != "tfidf": 
            processor.write_vocab_dict(args.vocab_file, vocab)
        else: 
            for k, v in vocab.items():
                idf_vocab[k] = math.log(doc_count / (1.0 + v))   # idfֵΪlog(�ĵ�����/��1+�����ض�������ĵ�����)
            processor.write_vocab_dict(args.vocab_file, vocab, idf_vocab, True, True, True) #index \t feature \t idf
    # Ԥ������ʽ
    vocab = {} 
    idf_dict = {} # key:word, value: idf
    seg_list = []
    tf_dict = {} #key: word, value: tf
    tfidf_dict = {} #key: word, value: tfidf
    index_dict = {} #key: index, value: word
    label = ""
    if args.type == "liblinear":
        vocab = processor.get_vocab_dict(args.vocab_file)
    elif args.type == "onehot":
        vocab = processor.get_vocab_dict(args.vocab_file, unk=True)
    elif args.type == "tfidf":
        vocab = processor.get_vocab_dict(args.vocab_file)
        idf_dict = processor.get_idf_dict(args.vocab_file)
        for k, v in vocab.items():
            index_dict[v] = k

    with open(args.ngram_file, "r") as f:
        with open(args.process_file, "w") as fw:
            for eachline in f:
                line = eachline.strip("\n").decode("gbk", "ignore").lower()
                cols = line.split("\t")
                label = cols[0]
                seg_list = cols[1].split(" ")
                if args.type == "liblinear":
                    wids = processor.gramtext_map(seg_list, vocab)
                    fw.write("%s\t%s\n" % (label, processor.get_liblinear_format(wids)))
                elif args.type == "onehot":
                    wids = processor.data_map(seg_list, vocab)
                    fw.write("%s\t%s\n" % (label, "\t".join(map(lambda x:str(x), wids))))
                elif args.type == "tfidf":
                    tf_dict = processor.get_tf_dict(seg_list)
                    for k, v in tf_dict.items():
                        if k in idf_dict:
                            tfidf_dict[k] = float(v) * float(idf_dict[k])  #word, tfidf
                    seg_set = set(seg_list)
                    wids = processor.gramtext_map(seg_set, vocab)
                    fw.write("%s\t%s\n" % (label, processor.get_tfidf_format(wids, index_dict, tfidf_dict)))

    processor.destroy()


if __name__ == "__main__":
    args = args_func()
    start = time.time()
    args_parse(args)
    end = time.time()
    print "total time: %f" % (end - start)

