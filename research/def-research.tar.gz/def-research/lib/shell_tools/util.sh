#!/bin/bash

# ʱ��
TODAY=`date +%Y%m%d`
YESTERDAY=`date -d "-1 day" +%Y%m%d`

#����Ⱥλ��
MULAN="hdfs://nmg01-mulan-hdfs.dmop.baidu.com:54310"
KHAN="hdfs://nmg01-khan-hdfs.dmop.baidu.com:54310"
SHAOLIN="afs://shaolin.afs.baidu.com:9902"
TIANQI="afs://tianqi.afs.baidu.com:9902"

# �������ݼ�λ��
MEG_DATA="${SHAOLIN}/app/ecom/fengkong/dw/fengkong_data/userid_new_ssg_trade_day/"

# --------- HDFS��Ⱥ -------------
# ������Ŀ¼
KG="${SHAOLIN}/app/ecom/fengkong/kg/"
TQ="${TIANQI}/app/ecom/aries/fengkong/"

# �û���Ŀ¼
ZH="${SHAOLIN}/app/ecom/fengkong/personal/zhanghao55/"
SH="${SHAOLIN}/app/ecom/fengkong/personal/shenhao02/"

# ���߰�λ��
TOOLS="${ZH}tools/"

# �����Ŀ¼
PROJECTS="${ZH}projects/"

# Ĭ�ϴ���ѹ����λ��
JOB_ARCHIVES_ROOT="${PROJECTS}/default_job_archives/"

#�дʺ�python��
WORDSEG_PATH="${TOOLS}wordseg.tar.gz"
WORD_SEG_DICT="${TOOLS}chinese_gbk.tar.gz"
HADOOP_PYTHON="${TOOLS}python_zhanghao55.tar.gz"

# ����python��ַ
LOCAL_PYTHON="/home/users/zhanghao55/anaconda2/envs/py37/bin/python"
#����hadoopλ��
HADOOP_HOME="/home/users/zhanghao55/workspace/tools/hadoop-client-1.6.2.2/hadoop/"
HADOOP_CLIENT="${HADOOP_HOME}bin/hadoop --config ${HADOOP_HOME}conf-fengkong-afs-shaolin"

# ����spark��ַ
SPARK_SUMBIT="/home/work/local/spark-2.3.2.9/bin/spark-submit"

# ======���ع���Ŀ¼ BASE_DIR=$(dirname $(readlink -f "$0"))=======
BASE_DIR=$(cd "$(dirname "$0")";pwd)
DATA_DIR="${BASE_DIR}/../data/"
LOCAL_DATA_DIR="${BASE_DIR}/../local_data/"
LOG_DIR="${BASE_DIR}/../log/"
MODEL_DIR="${BASE_DIR}/../model/"
SRC_DIR="${BASE_DIR}/../src/"
OUTPUT_DIR="${BASE_DIR}/../output/"
BIN_DIR="${BASE_DIR}/../bin/"
LOG_FILE="util.log"

function make_dir()
{
    for cur_dir in $@
    do
        if [ ! -d ${cur_dir} ]; then
            echo "creat dir : ${cur_dir}"
            mkdir -p ${cur_dir}
        fi
    done
    }

make_dir ${DATA_DIR} ${LOCAL_DATA_DIR} ${LOG_DIR} ${MODEL_DIR} ${SRC_DIR} ${OUTPUT_DIR}

function make_hdfs_dir()
{
    for hdfs_dir in $@
    do
        ${HADOOP_CLIENT} fs -test -e ${hdfs_dir}
        if [ $? -eq 1 ]; then
            ${HADOOP_CLIENT} fs -mkdir ${hdfs_dir}
        fi
    done
}

function log_info()
{
    info=${1}
    time_now=`date +"%Y%m%d %H:%M:%S"`
    echo -e "INFO, ${time_now}, $info}!" | tee -a ${LOG_DIR}${LOG_FILE}
}

function exit_error()
{
    info=${1}
    time_now=`date +"%Y%m%d %H:%M:%S"`
    echo -e "ERROR, ${time_now}, ${info}!" | tee -a ${LOG_DIR}${LOG_FILE}
    exit 1
}

function WriteLog()
{
    local msg_date=`date +%Y-%m-%d" "%H:%M:%S`
    local msg_begin=""
    local msg_end=""
    if [ $# -eq 1 ]; then
        local msg=$1
        echo "[${msg_date}]${msg}" | tee -a ${LOG_DIR}${LOG_FILE}
    elif [ $# -eq 2 ]
    then
        local msg=$2
        local runstat=$1
        if [ ${runstat} -eq 0 ]; then
            msg_begin="Success"
            msg_end="ok!"
        else
            msg_begin="Error"
            msg_end="fail!"
        fi
        echo "[${msg_date}][${msg_begin}]${msg} ${msg_end}" | tee -a ${LOG_DIR}${LOG_FILE}
        if [ ${runstat} -ne 0 ]; then
            echo "error when Task ${msg} runs at ${msg_date}" | tee -a ${LOG_DIR}${LOG_FILE}
            exit 1
        fi
    else
        echo "WriteLog param num should be 1 or 2, actual $#" | tee -a ${LOG_DIR}${LOG_FILE}
        exit 1
    fi
}

function get_afs_data()
{
    local SRC_PATH=${1}
    local DST_PATH=${2}
    
    ${HADOOP_CLIENT} fs -test -e ${OUTPUT_FILE}
    WriteLog $? "check src path: %{SRC_PATH} if exist"

    if [ -e ${DST_PATH} ]; then
        WriteLog "dst path: ${DST_PATH} already exist"
        if [ -O ${DST_PATH} ]; then
            if [ -d ${DST_PATH} ]; then
                rm -r ${DST_PATH}
                WriteLog $? "rm dst dir: ${DST_PATH}"
            else
                rm ${DST_PATH}
                WriteLog $? "rm dst file: ${DST_PATH}"
            fi
        else
            WriteLog 1 "no privilege to remove dst path: ${DST_PATH}"
        fi
    fi

    ${HADOOP_CLIENT} fs -get ${SRC_PATH} ${DST_PATH}
    WriteLog $? "get ${SRC_PATH} to ${DST_PATH}"
}



function clear_remote_env
{
    if [ "$1"x == ""x ]; then
        echo "remote env path is empty" |tee -a ${LOG_DIR}${LOG_FILE}
        exit 1
    fi

    ${HADOOP_CLIENT} fs -rmr $1
    ${HADOOP_CLIENT} fs -mkdir $1
}

function pack_dir
{
    #��directory�е��ļ������tmp�ļ�����
    local directory=$1
    local tmp_dir=$2

    echo "handling $directory to $tmp_dir"
    #�л���directory�У�����.tar.gz�������ļ������Ȼ���˳��ļ��У����tar.gz������ǰ�����directory ������������tar�ļ��� ������һ�仰���������𣿣�
    cd $directory; tar zcvfh $directory.tar.gz * --exclude "*.tar.gz" --exclude "*.un~" --exclude "*.pyc" --exclude "*/.git*"; cd -
    #��directory�еĴ���õ�tar.gz�ļ��Ƶ�tmp�ļ�����
    mv $directory/$directory.tar.gz $tmp_dir/
}

function prepair_localfile
{

    ARCHIVES_DIR=$1
    if [ "${ARCHIVES_DIR}"x == ""x ]; then
        echo "ARCHIVES_DIR is empty" |tee -a ${LOG_DIR}${LOG_FILE}
        exit 1
    fi
    shift 1
    rm -r tmp
    mkdir tmp

    #�������д�����ļ�����  �������ӵ�tmp�ļ�����
    for directory in $@; do
        pack_dir $directory tmp
    done

    # ����ϴ����������ļ�
    for tar_file in $(ls tmp/*.tar.gz); do
        ${HADOOP_CLIENT} fs -put $tar_file ${ARCHIVES_DIR}
    done
}

function spark_process(){
    #demo: spark_process "yarn" "test_job" "input_path" "output_path" "python file" "executor_num"

    local MASTER=$1
    local TASK_NAME=$2
    local INPUT_FILE=$3
    local PYTHON_FILE=$4
    local EXECUTOR_NUM=$5
    local OUTPUT_FILE=$6
    local OUTPUT_PART_NUM=$7
    
    WriteLog "input file   = ${INPUT_FILE}"
    WriteLog "python file  = ${PYTHON_FILE}"
    WriteLog "executor num = ${EXECUTOR_NUM}"
    WriteLog "output file  = ${OUTPUT_FILE}"
    WriteLog "output parts = ${OUTPUT_PART_NUM}"

    if [[ ! ${OUTPUT_FILE} =~ zhanghao55 ]] ; then
        echo "check your output file :"${OUTPUT_FILE}
        exit 1
    fi

    ${HADOOP_CLIENT} fs -test -e ${OUTPUT_FILE}
    if [ $? -eq 0 ]; then
        ${HADOOP_CLIENT} fs -rmr ${OUTPUT_FILE}
    fi

    ${SPARK_SUMBIT} \
        --master ${MASTER} \
        --queue "spark-fengkong"  \
        ${PYTHON_FILE} \
        ${TASK_NAME} \
        ${INPUT_FILE} \
        ${OUTPUT_FILE} \
        ${EXECUTOR_NUM} \
        ${OUTPUT_PART_NUM}

    WriteLog $? "spark job: ${TASK_NAME}"
}


function hadoop_process(){
    #parameter 1.process name 2.inputfile 3.outputfile 4.mapper name 5.mapper number 6.reducer name 7.reducer number
    ${HADOOP_CLIENT} fs -test -e $3
    if [ $? -eq 0 ]; then
        ${HADOOP_CLIENT} fs -rmr $3
    fi

    if [ "$4"x ==  "cat"x ]; then
        local MAPPER=$4
    else
        local MAPPER="python/bin/python "$4
    fi
    if [ "$6"x == "cat"x ]; then
        local REDUCER=$6
    else
        local REDUCER="python/bin/python "$6
    fi

    local TASK_NAME=$1
    local INPUT_FILE=$2
    local OUTPUT_FILE=$3
    local MAPPER_NUM=$5
    local REDUCER_NUM=$7

    if [[ ! ${OUTPUT_FILE} =~ zhanghao55 ]] ; then
        echo "check your output file :"${OUTPUT_FILE}
        exit 1
    fi

    clear_remote_env ${JOB_ARCHIVES_ROOT}${TASK_NAME}
    shift 7
    local CACHE_ARCHIVES=""
    for cache_archive in $@; do
        cur_cache_dir="${JOB_ARCHIVES_ROOT}${TASK_NAME}/"
        prepair_localfile ${cur_cache_dir} ${cache_archive}
        CACHE_ARCHIVES=${CACHE_ARCHIVES}" -cacheArchive ${cur_cache_dir}${cache_archive}.tar.gz#${cache_archive}"
    done

    WriteLog "input file  = ${INPUT_FILE}"
    WriteLog "output file = ${OUTPUT_FILE}"
    WriteLog "mapper      = ${MAPPER}"
    WriteLog "reducer     = ${REDUCER}"
    ${HADOOP_CLIENT} streaming \
        -D mapred.job.queue.name="fengkong-galaxy-online_normal" \
        -D mapred.job.name=${TASK_NAME} \
        -D mapred.job.map.capacity=3000 \
        -D mapred.map.tasks=${MAPPER_NUM} \
        -D stream.memory.limit=5000 \
        -D mapred.reduce.tasks=${REDUCER_NUM} \
        -D mapred.map.over.capacity.allowed=false \
        -D mapred.job.priority=VERY_HIGH \
        -D abaci.job.base.environment=default \
        -D mapred.textoutputformat.ignoreseparator=true \
        -partitioner org.apache.hadoop.mapred.lib.KeyFieldBasedPartitioner \
        -inputformat org.apache.hadoop.mapred.TextInputFormat \
        -input ${INPUT_FILE} \
        -output ${OUTPUT_FILE} \
        -mapper "${MAPPER}" \
        -reducer "${REDUCER}" \
        -cacheArchive ${HADOOP_PYTHON}#python \
        -cacheArchive ${WORD_SEG_DICT}#dict \
        -cacheArchive ${WORDSEG_PATH}#wordseg \
        ${CACHE_ARCHIVES}

    if [ $? -ne 0 ]
        then
        echo "$1 error"
        exit 1
    fi
}

#function hadoop_process_two_input(){
#    #parameter 1.process name 2.inputfile1 3.inputfile2 4.outputfile 5.mapper name 6.mapper number 7.reducer name 8.reducer number
#    ${HADOOP_CLIENT} fs -test -e $4
#    if [ $? -eq 0 ]; then
#        ${HADOOP_CLIENT} fs -rmr $4
#    fi
#
#    if [ "$5"x ==  "cat"x ]; then
#        local MAPPER=$5
#    else
#        local MAPPER="python/bin/python "$5
#    fi
#    if [ "$7"x == "cat"x ]; then
#        local REDUCER=$7
#    else
#        local REDUCER="python/bin/python "$7
#    fi
#
#    local TASK_NAME=$1
#    local INPUT_FILE1=$2
#    local INPUT_FILE2=$3
#    local OUTPUT_FILE=$4
#    local MAPPER_NUM=$6
#    local REDUCER_NUM=$8
#
#    if [[ ! ${OUTPUT_FILE} =~ zhanghao55 ]] ; then
#        echo "check your output file :"${OUTPUT_FILE}
#        exit 1
#    fi
#    
#    clear_remote_env
#    shift 8
#    local CACHE_ARCHIVES=""
#    for cache_archive in $@; do
#        prepair_localfile ${cache_archive}
#        CACHE_ARCHIVES=${CACHE_ARCHIVES}" -cacheArchive ${JOB_ARCHIVES_ROOT}/${cache_archive}.tar.gz#${cache_archive}"
#    done
#
#    WriteLog "input file1 = "${INPUT_FILE1}
#    WriteLog "input file2 = "${INPUT_FILE2}
#    WriteLog "mapper = "${MAPPER}
#    WriteLog "reducer = "${REDUCER}
#    ${HADOOP_CLIENT} streaming \
#        -D mapred.job.queue.name="fengkong" \
#        -D mapred.job.name=${TASK_NAME} \
#        -D mapred.job.map.capacity=1000 \
#        -D mapred.map.tasks=${MAPPER_NUM} \
#        -D stream.memory.limit=5000 \
#        -D mapred.reduce.tasks=${REDUCER_NUM} \
#        -D mapred.map.over.capacity.allowed=false \
#        -D mapred.job.priority=VERY_HIGH \
#        -D abaci.job.base.environment=default \
#        -input ${INPUT_FILE1} \
#        -input ${INPUT_FILE2} \
#        -output ${OUTPUT_FILE} \
#        -mapper "${MAPPER}" \
#        -reducer "${REDUCER}" \
#        -cacheArchive ${HADOOP_PYTHON}#python \
#        -cacheArchive ${WORDSEG_PATH}#wordseg \
#        ${CACHE_ARCHIVES}
#
#    if [ $? -ne 0 ]
#        then
#        echo "$1 error"
#        exit 1
#    fi
#}
#
#function hadoop_process_with_conf_data_src(){
#    #parameter 1.process name 2.inputfile 3.outputfile 4.mapper name 5.mapper number 6.reducer name 7.reducer number
#    clear_remote_env && prepair_localfile src conf data
#
#    ${HADOOP_CLIENT} fs -test -e $3
#    if [ $? -eq 0 ]; then
#        ${HADOOP_CLIENT} fs -rmr $3
#    fi
#
#    if [ "$4"x ==  "cat"x ]; then
#        local MAPPER=$4
#    else
#        local MAPPER="python/bin/python "$4
#    fi
#    if [ "$6"x == "cat"x ]; then
#        local REDUCER=$6
#    else
#        local REDUCER="python/bin/python "$6
#    fi
#
#    echo "mapper = "${MAPPER}
#    echo "reducer= "${REDUCER}
#    ${HADOOP_CLIENT} streaming \
#        -D mapred.job.queue.name="fengkong" \
#        -D mapred.job.name=$1 \
#        -D mapred.job.map.capacity=1000 \
#        -D mapred.map.tasks=$5 \
#        -D stream.memory.limit=3000 \
#        -D mapred.reduce.tasks=$7 \
#        -D mapred.map.over.capacity.allowed=false \
#        -D mapred.job.priority=VERY_HIGH \
#        -D abaci.job.base.environment=default \
#        -input $2 \
#        -output $3 \
#        -mapper "${MAPPER}" \
#        -reducer "${REDUCER}" \
#        -cacheArchive ${HADOOP_PYTHON}#python \
#        -cacheArchive ${JOB_ARCHIVES_ROOT}/src.tar.gz#src \
#        -cacheArchive ${JOB_ARCHIVES_ROOT}/data.tar.gz#data \
#        -cacheArchive ${JOB_ARCHIVES_ROOT}/conf.tar.gz#conf
#
#    if [ $? -ne 0 ]
#        then
#        echo "$1 error"
#        exit 1
#    fi
#}
#
#function hadoop_process_with_cachefile(){
#    #parameter 1.process name 2.inputfile 3.outputfile 4.mapper name 5.mapper number 6.reducer name 7.reducer number
#    ${HADOOP_CLIENT} fs -test -e $3
#    if [ $? -eq 0 ]; then
#        ${HADOOP_CLIENT} fs -rmr $3
#    fi
#    if [ "$4"x ==  "cat"x ]; then
#        local MAPPER=$4
#    else
#        local MAPPER="python/bin/python "$4
#    fi
#    if [ "$6"x == "cat"x ]; then
#        local REDUCER=$6
#    else
#        local REDUCER="python/bin/python "$6
#    fi
#    local TASK_NAME=$1
#    local INPUT_FILE=$2
#    local OUTPUT_FILE=$3
#    local MAPPER_NUM=$5
#    local REDUCER_NUM=$7
#    shift 7
#    local CACHE_FILE=""
#    for cachefile in $@; do
#        CACHE_FILE=${CACHE_FILE}" -cacheFile "$cachefile
#    done
#
#    ${HADOOP_CLIENT} streaming \
#        -D mapred.job.queue.name="fengkong" \
#        -D mapred.job.name=${TASK_NAME} \
#        -D mapred.job.map.capacity=1000 \
#        -D mapred.map.tasks=${MAPPER_NUM} \
#        -D stream.memory.limit=3000 \
#        -D mapred.reduce.tasks=${REDUCER_NUM} \
#        -D mapred.map.over.capacity.allowed=false \
#        -D mapred.job.priority=VERY_HIGH \
#        -D abaci.job.base.environment=default \
#        -input ${INPUT_FILE} \
#        -output ${OUTPUT_FILE} \
#        -mapper "${MAPPER}" \
#        -reducer "${REDUCER}" \
#        -cacheArchive ${HADOOP_PYTHON}#python \
#        -cacheArchive ${JOB_ARCHIVES_ROOT}/src.tar.gz#src \
#        -cacheArchive ${JOB_ARCHIVES_ROOT}/data.tar.gz#data \
#        -cacheArchive ${JOB_ARCHIVES_ROOT}/conf.tar.gz#conf \
#        ${CACHE_FILE}
#
#    if [ $? -ne 0 ]
#        then
#        echo "${TASK_NAME} error"
#        exit 1
#    fi
#}

get_max_day_of_month()
{
    # ��������YYYYMM������
    local Y=`expr substr $1 1 4`
    local M=`expr substr $1 5 2`
    #ȡ���µ����һ��
    local aa=`cal $M $Y` #����
    local days=`echo $aa | awk '{print $NF}'`
    echo $days
}

last_X_days()
{
    local BEGIN_DATE=$1
    local MAX_DAY_AGO=7
    if [ "$2"x != ""x ]; then
        MAX_DAY_AGO=$2
    fi
    local DAYS_AGO=1
    local RES="{"${BEGIN_DATE}

    while [ ${DAYS_AGO} -lt ${MAX_DAY_AGO} ]; do
        RES=${RES}","`date -d "-${DAYS_AGO} day ${BEGIN_DATE}" +%Y%m%d`
        ((DAYS_AGO=DAYS_AGO+1))
    done
    RES=${RES}"}"

    echo ${RES}
}


last_X_months()
{
    local BEGIN_MONTH=$1
    local MAX_MONTH_AGO=6
    if [ "$2"x != ""x ]; then
        MAX_MONTH_AGO=$2
    fi
    local MONTHS_AGO=1
    local RES="{"${BEGIN_MONTH}

    while [ ${MONTHS_AGO} -lt ${MAX_MONTH_AGO} ]; do
        RES=${RES}","`date -d "-${MONTHS_AGO} month ${BEGIN_MONTH}01" +%Y%m`
        ((MONTHS_AGO=MONTHS_AGO+1))
    done
    RES=${RES}"}"

    echo ${RES}
}

hours_range_array()
{
    # ���ڸ�ʽYYYYMMDDHH
    local start_hour=`date -d "${1:0:8} ${1:8:2}:00:00" +%Y%m%d%H`
    local end_hour=`date -d "${2:0:8} ${2:8:2}:00:00" +%Y%m%d%H`
    local end_hour_timestamp=`date -d "${end_hour:0:8} ${end_hour:8:2}:00:00" +%s`
    
    local hour_list=( "${start_hour}" )
    local cur_hour=${start_hour}
    local cur_hour_timestamp=`date -d "${cur_hour:0:8} ${cur_hour:8:2}:00:00" +%s`
    while [ ${cur_hour_timestamp} -lt ${end_hour_timestamp} ]
    do
        local cur_hour=`date -d "+1 hour ${cur_hour:0:8} ${cur_hour:8:2}:00:00" +%Y%m%d%H`
        local cur_hour_timestamp=`date -d "${cur_hour:0:8} ${cur_hour:8:2}:00:00" +%s`
        hour_list[${#hour_list[@]}]="${cur_hour}"
    done
    echo ${hour_list[@]}
}

days_range_array()
{
    # ���ڸ�ʽYYYYMMDD
    local start_date=`date -d "${1}" +%Y%m%d`
    local end_date=`date -d "${2}" +%Y%m%d`
    local end_date_timestamp=`date -d "${end_date}" +%s`
    
    local date_list=( "${start_date}" )
    local cur_date=${start_date}
    local cur_date_timestamp=`date -d "${cur_date}" +%s`
    while [ ${cur_date_timestamp} -lt ${end_date_timestamp} ]
    do
        local cur_date=`date -d "+1 day ${cur_date}" +%Y%m%d`
        local cur_date_timestamp=`date -d "${cur_date}" +%s`
        date_list[${#date_list[@]}]="${cur_date}"
    done
    echo ${date_list[@]}
}

days_range()
{
    local days_array=`days_range_array $@`
    echo "{`array_join "," ${days_array[@]}`}"
}

function get_file_withmd5()
{
    local ftp_config=""
    if [ $# -eq 6 ]; then
        local ftp_config="--ftp-user=${1} --ftp-password=${2}"
        # ����������λ
        shift 2
    fi
    local ftp_path=${1}
    local ftp_name=${2}
    local dst_path=${3}
    local dst_name=${4}

    WriteLog "get_file_withmd5 ${ftp_name} begin."
    touch ${dst_path}${dst_name}.md5

    # �ȶ�У��, ������У��
    wget -q --limit-rate=30m ${ftp_config} ${ftp_path}${ftp_name}.md5 -O \
        ${dst_path}${dst_name}.md5.new
    WriteLog $? "get ${ftp_name}.md5"

    diff ${dst_path}${dst_name}.md5 ${dst_path}${dst_name}.md5.new \
        > /dev/null
    if [ $? -eq 0 ]; then
        WriteLog "${dst_path}${dst_name} doesn't change"
    else
        wget -q --limit-rate=30m ${ftp_config} ${ftp_path}${ftp_name} -O \
            ${dst_path}${dst_name}
        WriteLog $? "get ${ftp_name}"
    fi
    mv ${dst_path}${dst_name}.md5.new ${dst_path}${dst_name}.md5
    WriteLog "get_file_withmd5 ${ftp_name} end."
}

function get_file_withoutmd5()
{

    local ftp_config=""
    if [ $# -eq 6 ]; then
        local ftp_config="--ftp-user=${1} --ftp-password=${2}"
        # ����������λ
        shift 2
    fi
    local ftp_path=${1}
    local ftp_name=${2}
    local dst_path=${3}
    local dst_name=${4}

    WriteLog "get_file_withoutmd5 ${ftp_name} begin."

    wget --limit-rate=30m ${ftp_config} ${ftp_path}${ftp_name} -O \
        ${dst_path}${dst_name} || \
        exit_error "get ${ftp_name} fail"

    WriteLog "get_file_withoutmd5 ${ftp_name} end."
}

function array_join(){
    # ������
    # 1. ���ӷ�
    # 2. Ҫ���ӵ��ַ���

    # ʾ����
    # 1. ��������: array_join "," ${array}
    # 2. ���ַ�����: array_join "" ${array}

    local sep=${1}
    shift 1
    local res=""
    for cur_str in $@
    do
        if [ "${res}"x != ""x ]; then
            res=${res}${sep}
        fi
        res=${res}${cur_str}
    done
    echo ${res}
}

init()
{

    # ������BIN DATA�ȶ����λ�� ��Ϊ��ʱ��ִ�еĹ��õ�util.sh ������bin/util.sh
    make_dir bin data src log output local_data

    # ��ȡ��ǰִ�е�util���ڵľ���λ�� Ȼ������������ǰλ�õ�bin�ļ���
    ln -s `cd "$(dirname "$0")"; pwd`"/util.sh" "bin/util.sh"

    # ʾ��run.sh��������ǰλ�õ�bin�ļ���
    cp `cd "$(dirname "$0")"; pwd`"/run_demo.sh" "bin/run.sh"
}

if [ "init"x == $1x ]; then
    init
fi
