#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
train Cartoon_Sensitive_Parts model

Author:   hekaiwen@baidu.com
Date  :   21/12/14 11:31:45
Desc  :   
"""
import logging
import os
import argparse
import pdb
import random
import re
import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from PIL import Image
from torch.autograd import Variable
from torch.optim import Adam, lr_scheduler
from torch.utils import data
from torch.utils.data import Dataset
from torchvision import transforms

from iResNet_model import BottleNeck, IresStage

parser = argparse.ArgumentParser(description='PyTorch <Cartoon_Sensitive_Parts model> Training')
parser.add_argument('--txt_path', default="/home/users/hekaiwen/traindata.txt", help='traindata path')  #  数据集txt地址
parser.add_argument('--save_dir', default="/home/users/hekaiwen/Cartoon_Sensitive_parts.pth", help='save path')
parser.add_argument('--gpu', default='1', help='define which gpu device to use : 1~7')  # gpu device number
parser.add_argument('--num_classes', type=int, default=16, help='classes to be classified')  # 分类数量
parser.add_argument('--batch_size', type=int, default=128, help='batch size')  # batch_size
parser.add_argument('--epoch', type=int, default=50, help='epoch')  # epoch
parser.add_argument('--input_size', type=int, default=224, help='input image size')  # input image size

args = parser.parse_args()
txt_path = args.txt_path
checkpoint_dir = args.checkpoint_dir
os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu
num_classes = args.num_classes
batch_size = args.batch_size
epoch = args.epoch
input_size = args.input_size

def decode_image(post_data):
    """read rgb image
    Args:
        post_data: string of request image
    Returns:
        image_np (np.ndarray):  processed RGB image (np.ndarray)
    """
    data = np.frombuffer(post_data, dtype='uint8')
    image_np = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if type(image_np)!=np.ndarray:
        return None
    image_np = cv2.cvtColor(image_np, cv2.COLOR_BGR2RGB)
    image_shape = image_np.shape
    num = len(image_shape)
    if num == 2:
        image_np = cv2.cvtColor(image_np, cv2.COLOR_GRAY2RGB)
    elif num == 3:
        channels = image_shape[2]
        if channels != 3 and channels != 4:
            logging.error("FK_MONITOR_WARING_LOG currency_detection \
                    preprocess image shape is not to be supported [{}]".format(image_shape))
            return None
        elif channels == 4:
            image_np = cv2.cvtColor(image_np, cv2.COLOR_BGRA2RGB)
    else:
        logging.error("FK_MONITOR_WARING_LOG currency_detection preprocess image shape < 2")
        return None
    return image_np


class TxtImage(data.Dataset):
    """
    process images as txt file
    """
    
    def __init__(self, TXTPath, transform=None, input_size=224):
        """ initial image processing function"""
        self.transform = transform
        self.size = (input_size, input_size)
        self.imgList = []
        self.labelList = []
        for IName in TXTPath:
            if len(self.imgList) % 1000 == 0:
                print(len(self.imgList))
            try:

                x = IName.split(' ')
                with open(x[0], 'rb') as f:
                    img_data = f.read()
                    img_data = decode_image(img_data)
                if img_data is None:
                    continue
                if img_data.shape[2]==3 and img_data.shape[0]>0 and img_data.shape[1]>0:
                    img_data = cv2.cvtColor(img_data, cv2.COLOR_BGR2RGB)                                                         
                    self.imgList.append(x[0])
                    self.labelList.append(int(x[1]))
                else:
                    print("cannot be resized")

            except Exception as e:
                print (e)
                continue    

    def __getitem__(self, index):
        """ get image and label list """
        imgPath = self.imgList[index]
        img = cv2.imread(imgPath)
        if self.size is not None:
            img = cv2.resize(img, self.size)
        if self.transform is not None:
            imgs = self.transform(img)
            labels = torch.IntTensor([self.labelList[index]])

        return imgs, labels

    def __len__(self):
        """ get the length of image list """
        return len(self.imgList)


def main():
    """
    train model
    """    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    MODEL_CARTOON = IresStage(BottleNeck, [3, 4, 6, 3]).to(device)
    print(MODEL_CARTOON)
    MODEL_CARTOON.train()

    transform = transforms.Compose([transforms.ToTensor(),
                                    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])])
    criterion = nn.CrossEntropyLoss().to(device)
    optimizer = optim.Adam(MODEL_CARTOON.parameters(), lr=1e-05, betas=(0.9, 0.999), eps=1e-08)

    TXTPath = os.path.join(txt_path)
    with open(TXTPath, 'r') as f:
        TXT = f.readlines()
    dset = TxtImage(TXT, transform)
    dloader = data.DataLoader(dset, batch_size=batch_size, shuffle=True)

    for i, (img, label) in enumerate(dloader):
        print(img.size())
        print(label.size())

    for epoch in range(epoch):

        for i, (img, label) in enumerate(dloader):
            img = img.to(device)
            label = label.squeeze()
            label = label.type(dtype = 'torch.LongTensor')
            label = label.to(device)

            output = MODEL_CARTOON(img)
            output = output.to(device)
            loss = criterion(output, label)
            #开始训练        
            optimizer.zero_grad()
            #反向传播
            loss.backward()
            optimizer.step()

        print("Epoch [{}/{}], Step [{}/{}] Loss: {:.4f}".format(epoch + 1, epoch, i + 1, img.size(), loss.item()))
        exp_lr_scheduler = lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.2)

    torch.save(MODEL_CARTOON.state_dict(), checkpoint_dir)


if __name__ == '__main__':
    main()