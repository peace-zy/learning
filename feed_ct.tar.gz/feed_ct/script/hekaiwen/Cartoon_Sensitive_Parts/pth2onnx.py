#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Author:   hekaiwen@baidu.com
Date  :   21/12/06 14:34:32
Desc  :   
"""

import argparse
import torch
import torch.nn.functional as F
import torch.onnx
import os
import onnx
import numpy
import onnxruntime
from torch import nn

from iResNet_model import BottleNeck, IresStage

_curpath = os.path.dirname(os.path.abspath(__file__))
MODEL_CARTOON = IresStage(BottleNeck, [3, 4, 6, 3])

def Convert_Model_To_ONNX(input_img_size, input_pth_model, Output_Onnx):
    """
    input: Model pth file
    export: Model onnx file with alterable batch size
    """
    batch_size = 1
    input_shape = (3, input_img_size, input_img_size)
    state_dict = torch.load(input_pth_model, map_location='cpu')
    model = MODEL_CARTOON
    model.load_state_dict(state_dict)
    model.eval()

    x = torch.randn(batch_size, *input_shape)

    torch.onnx.export(model,
                      x, 
                      Output_Onnx, 
                      verbose=True, 
                      input_names = ["image"],
                      output_names = ["output_names"],
                      dynamic_axes = {"image":{0:'batch_size'},
                                    "output_names":{0:'batch_size'}})

    #-------check--------#
    with torch.no_grad():
        torch_out = {'output': model(x)}

    session = onnxruntime.InferenceSession(os.path.join(_curpath, Output_Onnx))
    input_name = session.get_inputs()[0].name
    result = session.run([], {input_name: x.numpy()})

    for onnx_result, torch_result in zip(result, torch_out.values()):
        print(onnx_result, torch_result)
        numpy.testing.assert_almost_equal(torch_result.detach().cpu().numpy(), onnx_result, decimal=3)
	
    onnx_model = onnx.load(os.path.join(_curpath, Output_Onnx))
    onnx.checker.check_model(onnx_model)
    print('onnx model check is done!')

if __name__ == '__main__':
    input_img_size = 224
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--input_model_path")
    parser.add_argument("-o", "--output_model_path")
    args = parser.parse_args()
    Convert_Model_To_ONNX(input_img_size, args.input_model_path, args.output_model_path)

