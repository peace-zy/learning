#-*-coding:utf-8-*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了实时舆情分析功能(基于v1-版本舆情发现)。
 
Authors: zhangyan(zhangyan75@baidu.com)
Date:    2021/10/26 10:00:00
"""

import os
import sys
import glob
from datetime import date, timedelta
import traceback
import commands
import csv
import time
import re

risks = {"person": "人物类",
         "organization": "组织机构类"}
site = "http://10.233.31.41:8091"

def post_data(save_file):
    """发送数据到pushgateway"""
    cmd = 'curl -XPOST --data-binary @{} {}/metrics/job/baidu_hotword'.format(save_file, site)
    print(cmd)
    os.system(cmd)

def make_path(path):
    """创建路径"""
    if not os.path.exists(path):
        os.makedirs(path)

def concate_info(risk_info, show_info, cls_name, word):
    """拼接数据"""
    if risk_info:
        risk_info += ", "
    risk_info += "{}: [{}]".format(cls_name, word)
    show_info += ", {}=\"{}\"".format(cls_name, word)
    return (risk_info, show_info)

def convert_format(everyday, analyzed_file, save_path):
    """转成k-v格式"""
    wlines = set([])
    record = []
    with open(analyzed_file, 'r') as f:
        for line in f:
            try:
                line = line.replace('"', '\'')
                fields = line.rstrip().split('\t')
                #列【0-标题 1-描述 2-机构名称 3-人名 4-事件三元组 5-url 6-标题图 7-热搜时间】
                #organization = fields[2]
                #person = fields[3]
                cur_risks = {risks.keys()[0]: fields[3], risks.keys()[1]: fields[2]}
                show_info = """title=\"{}\", desc=\"{}\", url=\"{}\", pic=\"{}\""""\
                                .format(fields[0], fields[1], fields[5], fields[6])
                if show_info in record:
                    continue
                record.append(show_info)
                show_info += """, time=\"{}\"""".format(fields[7])
                risk_info = '' 
                for cls_name, word in cur_risks.items():
                    if word:
                        (risk_info, show_info) = concate_info(risk_info, show_info, cls_name, word)

                if risk_info:
                    wline = show_info + ", merge_public_opinion=\"{}\"".format(risk_info)
                    wlines.add(wline)
 
            except Exception as e:
                traceback.print_exc()
                continue

    make_path(save_path)
    save_file = os.path.join(os.path.abspath(save_path), 'baidu_hotword_' + everyday + '.txt')
    with open(save_file, 'w') as f:
         for line in wlines:
             f.write('baidu_trending' + '{' + line + '} 1\n')
    return save_file

def concat_hanlp_files(pre_part):
    """拼接所有以'hanlp'为后缀的文件"""
    analyzed_file = pre_part + '_all_hanlp.txt'
    cmd = 'cat {} > {}'.format(pre_part + '*_hanlp.txt', analyzed_file)
    print(cmd)
    os.system(cmd)
    return analyzed_file

def process_old_data(inpath, save_path):
    """处理历史数据"""
    all_files = {}
    for everyday in os.listdir(inpath):
        pre_part = os.path.join(inpath, everyday, everyday)
        analyzed_file = concat_hanlp_files(pre_part)
        all_files[everyday] = analyzed_file
    for everyday, analyzed_file in all_files.items():
        if os.path.exists(analyzed_file):
            save_file = convert_format(everyday, analyzed_file, save_path)
            post_data(save_file)
            os.remove(analyzed_file)

def process_today_data(inpath, save_path):
    """处理今天数据"""
    today = time.strftime("%Y-%m-%d", time.localtime())
    #yesterday = (date.today() + timedelta(days=-1)).strftime("%Y-%m-%d")
    pre_part = os.path.join(inpath, today, today)
    analyzed_file = concat_hanlp_files(pre_part)
    if os.path.exists(analyzed_file):
        save_file = convert_format(today, analyzed_file, save_path)
        post_data(save_file)
    os.remove(analyzed_file)

def process_yesterday_data(inpath, save_path):
    """处理昨天数据"""
    yesterday = (date.today() + timedelta(days=-1)).strftime("%Y-%m-%d")
    pre_part = os.path.join(inpath, yesterday, yesterday)
    analyzed_file = concat_hanlp_files(pre_part)
    if os.path.exists(analyzed_file):
        save_file = convert_format(yesterday, analyzed_file, save_path)
        post_data(save_file)
    os.remove(analyzed_file)


def gen_public_opinion_type(save_path):
    """生成舆论类型"""
    save_file = os.path.join(save_path, 'baidu_trending_public_opinion_type.txt')
    with open(save_file, 'w') as f:
        for i, r in enumerate(risks.keys()):
            f.write('baidu_trending_public_opinion' + \
                    '{public_opinion_type="' + r + '", zhn_name="' + risks[r] + '"} ' + str(i) +'\n')
    post_data(save_file)
        #for key, value in risks.items():
        #    f.write('baidu_trending_public_opinion' + '{public_opinion_type="' + key + '"} ' + value +'\n')

def count_public_opinion_old(save_path):
    """统计舆论数量"""
    #public_opinion_num = len(glob.glob(os.path.join(save_path, 'baidu_hotword_*')))
    pre_fixed = 'baidu_hotword_'
    cmd = 'find . -name "{}*" |xargs cat|grep -v ^$|wc -l'.format(pre_fixed)
    status, out = commands.getstatusoutput(cmd)
    if status == 0:
        public_opinion_num = int(out)
    save_file = os.path.join(save_path, 'baidu_trending_public_opinion_number.txt')
    with open(save_file, 'w') as f:
        f.write('baidu_trending_public_opinion_number{public_opinion_num="舆情数量"} '\
                    + str(public_opinion_num) +'\n')
    post_data(save_file)

def convert_to_json(s):
    """转换成json"""
    parts = re.split('[\,{}]', s.rstrip()) # metric, field1, field2, value
    json_info = {}
    json_info['metric'] = parts[0].strip().rstrip()
    json_info['value'] = parts[-1].strip().rstrip()
    fix = '='
    for i, p in enumerate(parts):
        if fix in p:
            p = p.replace('"', '')
            k, v = p.split(fix)
            k = k.strip().rstrip()
            v = v.strip().rstrip()
            json_info[k] = v
    return json_info

def count_public_opinion(save_path, txt_name):
    """统计舆情"""
    pre_fixed = 'baidu_hotword_'
    info_by_day_txt_file = os.path.join(save_path, txt_name)
    txt_content = {}
    public_opinion_num = 0
    if os.path.exists(info_by_day_txt_file):
        with open(info_by_day_txt_file, 'r') as f:
            for line in f:
                json_info = convert_to_json(line)
                #print(json_info)
                filename = '{}{}-{}.txt'.format(pre_fixed, json_info['year'],
                                                   json_info['month_day'])
                txt_content[filename] = json_info

    today = pre_fixed + time.strftime("%Y-%m-%d", time.localtime()) + '.txt'
    for everyday_file in glob.glob(os.path.join(save_path, pre_fixed + '*')):
        everyday_file = os.path.abspath(everyday_file)
        everyday_name = os.path.split(everyday_file)[-1]
        everyday = everyday_name.split('_')[-1].split('.')[0]
        year, month, day = everyday.split('-')
        num = 0
        with open(everyday_file, 'r') as f:
            for index, line in enumerate(f):
                num += 1
        #if everyday_name in today:
        if everyday_name in txt_content:
            txt_content[everyday_name]['value'] = str(num)
        else:
            txt_content[everyday_name] = {'metric': 'baidu_trending_info_by_day',
                                          'year': year,
                                          'month': month,
                                          'day': day,
                                          'month_day': month + '-' + day,
                                          'value': str(num)}

    with open(info_by_day_txt_file, 'w') as f:
        for k in sorted(txt_content.keys()):
            info = txt_content[k]
            public_opinion_num += int(info['value'])
            #f.write('baidu_trending_info_by_day{year=\"{y}", month="{m}", day="{d}" {v}\n'.format(y=info['year'], m=info['month'], d=info['day'], v=info['value']))
            f.write('baidu_trending_info_by_day{year="' + info['year'] + \
                    '", month="' + info['month'] + '", day="' + info['day'] + \
                    '", month_day="' + info['month_day'] + '"} ' + info['value'] + '\n')
    post_data(info_by_day_txt_file)

    '''
    save_file = os.path.join(save_path, 'baidu_trending_public_opinion_number.txt')
    with open(save_file, 'w') as f:
        f.write('baidu_trending_public_opinion_number{public_opinion_num="舆情数量"} '\
                    + str(public_opinion_num) +'\n')
    post_data(save_file)
    '''
    print('舆情数量[{}]'.format(public_opinion_num))


def main():
    """主函数"""
    try:
        mode = int(sys.argv[1]) # 0: old data 1:real-time data
    except Exception as e:
        print("[usage] nohup sh parse_hot_words.py [mode] > update.log &")
        traceback.print_exc()
        return
      
    inpath = '/home/work/changxiaojing/politics_hot_search/data/mid_data'
    save_path = 'baidu_trending'
    make_path(save_path)

    gen_public_opinion_type(save_path)
    info_by_day_txt_name = 'baidu_trending_public_opinion_by_day.txt'
    
    if mode == 0:
        process_old_data(inpath, save_path)
    elif mode == 1:
        process_yesterday_data(inpath, save_path)
    elif mode == 2:
        process_today_data(inpath, save_path)

    count_public_opinion(save_path, info_by_day_txt_name)
    return

if __name__ == '__main__':
    while True:
        main()
        time.sleep(3600)
