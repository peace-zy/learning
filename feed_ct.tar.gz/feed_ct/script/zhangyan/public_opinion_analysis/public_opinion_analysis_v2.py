#-*-coding:utf-8-*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了实时舆情分析功能(基于v2-版本舆情发现)。
 
Authors: zhangyan(zhangyan75@baidu.com)
Date:    2021/11/05 10:00:00
"""

import os
import sys
import glob
from datetime import date, timedelta
import traceback
import commands
import csv
import time
import re
import pypinyin
import json
from collections import OrderedDict

def pinyin(word):
    """不带声调的(style=pypinyin.NORMAL)"""
    s = ''
    for i in pypinyin.pinyin(word, style=pypinyin.NORMAL):
        s += ''.join(i)
    return s

entity = {"person": "人物类",
          "organization": "组织机构类"}
label_dict = {}
concat_labels = []
site = "http://10.233.31.41:8091"
site = "http://10.12.186.173:8091"
everyday_public_opinion_path = 'everyday'


def parse_label_confg(label_config_file):
    """解析标签配置"""
    global label_dict
    with open(label_config_file, 'r') as f:
        skip_line_num = 1
        for n, line in enumerate(f):
            if n < skip_line_num:
                continue
            else:
                fields = line.rstrip().split('\t')
                topic = fields[0]
                emotion = fields[1].split('||')
                for em in emotion:
                    concat_label = fields[0] + '-' + em
                label_dict[concat_label] = fields[3]

def load_label_config(label_config_file):
    """加载标签配置"""
    global label_dict
    with open(label_config_file, 'r') as f:
        label_dict = json.load(f, object_pairs_hook=OrderedDict)

def find_merge_id(query):
    """查找合并label"""
    for first_level, v in label_dict.items():
        for second_level, detail in v.items():
            for d in detail:
                strategy = d['mergeDesc'].split('||')
                merge_id = ''
                for s in strategy:
                    if not merge_id:
                        merge_id = query[s]
                    else:
                        merge_id += '||' + query[s]
                if merge_id == d['mergeID']:
                    return {first_level.encode('utf-8'): second_level.encode('utf-8')}
    return False

def post_data(save_file):
    """发送数据到pushway"""
    cmd = 'curl -XPOST --data-binary @{} {}/metrics/job/baidu_hotword'.format(save_file, site)
    print(cmd)
    os.system(cmd)

def make_path(path):
    """创建路径"""
    if not os.path.exists(path):
        os.makedirs(path)

def  concate_info(risk_info, show_info, cur_entity, merge_info):
    """拼接信息"""
    for entity_name, word in cur_entity.items():
        if word and entity_name in merge_info:
            if risk_info:
                risk_info += ", "
            #print(merge_info[entity_name])
            second_level = merge_info[entity_name]
            risk_info += "{}-{}: [{}]".format(entity_name, second_level, word)
            #risk_info += '{first_level:"' + entity_name + '", second_level:"' + second_level +''
            show_info += ", {}=\"{}-{}\"".format(entity_name, second_level, word)
    return (risk_info, show_info)

def convert_format(everyday, analyzed_file, save_path):
    """转成k-v格式"""
    wlines = set([])
    detail = OrderedDict()
    #detail = {}
    global concat_labels
    for label in concat_labels:
        if label not in detail:
            detail[label] = 0

    record = []
    with open(analyzed_file, 'r') as f:
        for line in f:
            try:
                line = line.replace('"', '\'')
                fields = line.rstrip().split('\t')
                # 列【0-标题 1-描述 2-机构名称 3-人名 4-事件三元组 5-url 6-标题图 7-热搜时间】
                # 列[0-主题分类labelID, 1-主题分类labelname，2-情感分析labelID，3-情感分类labelname，4-组织机构，5-人名，6-事件三元组，7-热搜标题，8-热搜描述，9-URL，10-imgurl，11-时间]
                #organization = fields[2]
                #person = fields[3]
                cur_entity = {entity.keys()[0]: fields[5], entity.keys()[1]: fields[4]}
                query = {'themeID': fields[0], 'sentimentID': fields[2], 'keywordID': '0'}
                show_info = """title=\"{}\", desc=\"{}\", url=\"{}\", pic=\"{}\", topic=\"{}\", emotion=\"{}\""""\
                                .format(fields[7], fields[8], fields[9], fields[10], fields[1], fields[3])
                if show_info in record:
                    continue
                record.append(show_info)
                merge_info = find_merge_id(query)
                #print(query)
                #print(show_info)
                #print(merge_info['person'])

                show_info += """, time=\"{}\"""".format(fields[11])
                risk_info = ''
                (risk_info, show_info) = concate_info(risk_info, show_info, cur_entity, merge_info)

                if risk_info:
                    wline = show_info + ", merge_public_opinion=\"{}\"".format(risk_info)
                    wlines.add(wline)
                    for k, v in merge_info.items():
                        concat_label = k + ':' + v
                        if concat_label not in detail:
                            detail[concat_label] = 1
                        else:
                            detail[concat_label] += 1

            except Exception as e:
                traceback.print_exc()
                continue

    global everyday_public_opinion_path
    save_path = os.path.join(save_path, everyday_public_opinion_path)
    make_path(save_path)
    save_file = os.path.join(os.path.abspath(save_path), 'baidu_hotword_' + everyday + '.txt')
    with open(save_file, 'w') as f:
        for line in wlines:
            f.write('baidu_trending_v2' + '{' + line + '} 1\n')
        for k, v in detail.items():
            first_level, second_level = k.split(':')
            f.write('baidu_trending_v2_every_category{' + \
                    'date="' + everyday + '", ' + \
                    'first_level="' + first_level + '", ' + \
                    'second_level="' + second_level + '"} ' + str(v) + '\n')

    return save_file

def concat_files(pre_part, post_fix='_hanlp.txt'):
    """将指定后缀的文件拼接成一个文件"""
    analyzed_file = pre_part + '_all' + post_fix
    cmd = 'cat {} > {}'.format(pre_part + '*' + post_fix, analyzed_file)
    print(cmd)
    os.system(cmd)
    return analyzed_file

def process_old_data(inpath, save_path):
    """处理历史舆情数据"""
    all_files = {}
    for everyday in os.listdir(inpath):
        pre_part = os.path.join(inpath, everyday, everyday)
        analyzed_file = concat_files(pre_part, '_merge.txt')
        all_files[everyday] = analyzed_file
    for everyday, analyzed_file in all_files.items():
        if os.path.exists(analyzed_file):
            save_file = convert_format(everyday, analyzed_file, save_path)
            #post_data(save_file)
            os.remove(analyzed_file)

def process_today_data(inpath, save_path):
    """处理今天舆情数据"""
    today = time.strftime("%Y-%m-%d", time.localtime())
    #yesterday = (date.today() + timedelta(days=-1)).strftime("%Y-%m-%d")
    pre_part = os.path.join(inpath, today, today)
    analyzed_file = concat_files(pre_part, '_merge.txt')
    if os.path.exists(analyzed_file):
        save_file = convert_format(today, analyzed_file, save_path)
        #post_data(save_file)
    os.remove(analyzed_file)

def process_yesterday_data(inpath, save_path):
    """处理昨天舆情数据"""
    yesterday = (date.today() + timedelta(days=-1)).strftime("%Y-%m-%d")
    pre_part = os.path.join(inpath, yesterday, yesterday)
    analyzed_file = concat_files(pre_part, '_merge.txt')
    if os.path.exists(analyzed_file):
        save_file = convert_format(yesterday, analyzed_file, save_path)
        #post_data(save_file)
    os.remove(analyzed_file)

def gen_public_opinion_type(save_path):
    """生成舆情类型"""
    save_file = os.path.join(save_path, 'baidu_trending_v2_public_opinion_type.txt')
    with open(save_file, 'w') as f:
        idx = 0
        for first_level, v in label_dict.items():
            for second_level, detail in v.items():
                f.write('baidu_trending_v2_public_opinion' + \
                        '{first_level="' + first_level.encode('utf-8') + \
                        '", second_level="' + second_level.encode('utf-8') + \
                        '"} ' + str(idx) + '\n')
                idx += 1
                global concat_labels
                concat_labels.append(first_level.encode('utf-8') + ':' + second_level.encode('utf-8'))
    post_data(save_file)

def convert_to_json(s):
    """转换成json"""
    parts = re.split('[\,{}]', s.rstrip()) # metric, field1, field2, value
    json_info = {}
    json_info['metric'] = parts[0].strip().rstrip()
    json_info['value'] = parts[-1].strip().rstrip()
    fix = '='
    for i, p in enumerate(parts):
        if fix in p:
            p = p.replace('"', '')
            k, v = p.split(fix)
            k = k.strip().rstrip()
            v = v.strip().rstrip()
            json_info[k] = v
    return json_info

def count_public_opinion(save_path, txt_name):
    """统计舆情"""
    pre_fixed = 'baidu_hotword_'
    info_by_day_txt_file = os.path.join(save_path, txt_name)
    txt_content = {}
    public_opinion_num = 0
    if os.path.exists(info_by_day_txt_file):
        with open(info_by_day_txt_file, 'r') as f:
            for line in f:
                json_info = convert_to_json(line)
                #print(json_info)
                filename = '{}{}-{}.txt'.format(pre_fixed, json_info['year'],
                                                   json_info['month_day'])
                txt_content[filename] = json_info

    everyday_save_path = os.path.join(save_path, everyday_public_opinion_path)
    today = pre_fixed + time.strftime("%Y-%m-%d", time.localtime()) + '.txt'
    all_detail = {}
    for everyday_file in glob.glob(os.path.join(everyday_save_path, pre_fixed + '*')):
        everyday_file = os.path.abspath(everyday_file)
        everyday_name = os.path.split(everyday_file)[-1]
        everyday = everyday_name.split('_')[-1].split('.')[0]
        year, month, day = everyday.split('-')
        num = 0
        info = ''
        with open(everyday_file, 'r') as f:
            for index, line in enumerate(f):
                # skip metric [baidu_trending_v2_every_category]
                if 'baidu_trending_v2_every_category' in line:
                    json_info = convert_to_json(line)
                    date = json_info['date']
                    first_level = json_info['first_level']
                    second_level = json_info['second_level']
                    v = json_info['value']
                    if info:
                        info += ','
                    info += first_level + '-' + second_level + ':' + str(v)
                else:
                    num += 1
        all_detail[everyday] = info
        if everyday_name in txt_content:
            txt_content[everyday_name]['value'] = str(num)
        else:
            txt_content[everyday_name] = {'metric': 'baidu_trending_v2_info_by_day',
                                          'year': year,
                                          'month': month,
                                          'month_day': month + '-' + day,
                                          'day': day,
                                          'value': str(num)}

    with open(info_by_day_txt_file, 'w') as f:
        for k in sorted(txt_content.keys()):
            info = txt_content[k]
            public_opinion_num += int(info['value'])
            #f.write('baidu_trending_v2_info_by_day{year=\"{y}", month="{m}", day="{d}" {v}\n'.format(y=info['year'], m=info['month'], d=info['day'], v=info['value']))
            f.write('baidu_trending_v2_info_by_day{year="' + info['year'] + \
                    '", month="' + info['month'] + \
                    '", day="' + info['day'] + \
                    '", month_day="' + info['month_day'] + \
                    '"} ' + info['value'] + '\n')
                    #'", detail="' + all_detail[info['year'] + '-' + info['month'] + '-' + info['day']] + \
    post_data(info_by_day_txt_file)

    print('舆情数量[{}]'.format(public_opinion_num))


def main():
    """主函数"""
    mode = int(sys.argv[1]) # 0: old data 1:yesterday 2:today data
    #inpath = '/home/work/changxiaojing/politics_hot_search/data/mid_data.bk'
    inpath = '/home/work/changxiaojing/politics_hot_search/data/mid_data'
    save_path = 'baidu_trending_v2'
    make_path(save_path)

    #parse_label_confg('/home/work/changxiaojing/politics_hot_search/data/common_data/label_conf.txt')
    #print(label_dict)

    gen_public_opinion_type(save_path)
    info_by_day_txt_name = 'baidu_trending_v2_public_opinion_by_day.txt'

    if mode == 0:
        process_old_data(inpath, save_path)
    elif mode == 1:
        process_yesterday_data(inpath, save_path)
    elif mode == 2:
        process_today_data(inpath, save_path)


    all_day_txt = os.path.join(save_path, 'baidu_trending_v2_all_day.txt')
    cmd = 'cat {} > {}'.format(os.path.join(save_path, everyday_public_opinion_path) + '/*.txt', all_day_txt)
    print(cmd)
    os.system(cmd)
    post_data(all_day_txt)

    count_public_opinion(save_path, info_by_day_txt_name)
    return

if __name__ == '__main__':
    load_label_config('/home/work/changxiaojing/politics_hot_search/data/common_data/conf.json')
    print(label_dict)
    main()
    '''
    while True:
        main()
        time.sleep(3600)
    '''
