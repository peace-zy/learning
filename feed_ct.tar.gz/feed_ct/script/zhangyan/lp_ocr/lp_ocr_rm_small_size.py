"""
Author:   zhangyan75@baidu.com
Date  :   21/12/06 10:34:34
Desc  :   
"""

import cv2
import json
import requests
import numpy as np
import traceback
import os
import hashlib 
import argparse
import copy

def parse_args():
    """解析参数"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--infile", type=str, help="input file")
    parser.add_argument("--save_path", type=str, default="show_images_6_test", help="save path")
    parser.add_argument("--has_loaded", action='store_true', help="whether or not the image is downloaded")
    parser.add_argument("--map_file", type=str, default="../map_file_ori.txt", help="map file")
    parser.add_argument("--region_file", type=str, default="region_ocr_6_test.txt", help="region file")
    return parser.parse_args()
    

def make_path(path):
    """创建路径"""
    if not os.path.exists(path):
        os.makedirs(path)

def is_small_size(charset):
    """基于字符大小进行尺寸判断"""
    WIDTH_THRES = 4
    HEIGHT_THRES = 4
    NUM_THRES = 3
    cnt = 0
    for c in charset:
        #{'width': '17', 'top': '406', 'height': '29', 'left': '17'}
        c_rect = c['rect']
        x = int(c_rect['left'])
        y = int(c_rect['top']) 
        w = int(c_rect['width'])
        h = int(c_rect['height'])
        if w <= WIDTH_THRES or h <= HEIGHT_THRES: 
            cnt += 1
    if cnt >= NUM_THRES:
        return True
    return False
def is_small_size_v2(w, h):
    """基于文本框进行尺寸判断"""
    WIDTH_THRES = 6
    HEIGHT_THRES = 6
    if w <= WIDTH_THRES or h <= HEIGHT_THRES: 
        return True
    return False 

def iou(rect1, rect2):
    """交并比"""
    xmin = max(int(rect1['left']), int(rect2['left']))
    ymin = max(int(rect1['top']), int(rect2['top']))
    xmax = min(int(rect1['left']) + int(rect1['width']), int(rect2['left']) + int(rect2['width']))
    ymax = min(int(rect1['top']) + int(rect1['height']), int(rect2['top']) + int(rect2['height']))
    if xmin >= xmax or ymin >= ymax:
        return 0
    s1 = float(int(rect1['width']) * int(rect1['height']))
    s2 = float(int(rect2['width']) * int(rect2['height']))
    ratio = ((ymax - ymin) * (xmax - xmin)) / (s1 + s2)
    print(ratio)
    return ((ymax - ymin) * (xmax - xmin)) / (s1 + s2)


def main():
    """main"""
    args = parse_args()
    infile = args.infile 
    save_path = args.save_path
    map_file = args.map_file
    make_path(save_path)
    region_ocr_file = args.region_file
    has_loaded = args.has_loaded
    if os.path.exists(region_ocr_file):
        os.remove(region_ocr_file)

    url_local = {}
    if has_loaded:
        with open(map_file) as f:
            for line in f:
                fields = line.rstrip().split('\t')
                url = fields[0]
                local = fields[1]
                url_local[url] = local

    wlines = []
    with open(infile, 'r') as f:
        for line in f:
            fields = line.rstrip().split('\t')
            if len(fields) < 1:
                continue
            try:
                pic_url = fields[1] 
                if not has_loaded:
                    response = requests.get(pic_url)
                    cont = np.array(bytearray(response.content), dtype=np.uint8)
                    fname = hashlib.md5(cont).hexdigest() + '.jpg'
                    image = cv2.imdecode(cont, cv2.IMREAD_COLOR)
                    ori_image = copy.deepcopy(image)
                else:
                    local = '../' + url_local[pic_url]
                    #local = url_local[pic_url]
                    _, fname = os.path.split(local)
                    image = cv2.imread(local)
                    ori_image = copy.deepcopy(image)
                ocr_str = fields[3]
                ocr = json.loads(ocr_str)
                #ocr['originals'][0]['ocr']['paragraphs'][0]['finegrained_poly_location']
                originals = ocr['originals']
                #print('num of originals {}'.format(len(originals)))

                details = ocr['details']
                concat_text = '||'
                all_text = []
                #print('num of details {}'.format(len(details)))

                slow_idx = 0
                flag = False
                region_ocr = []
                for fast_idx, ori in enumerate(originals):
                    if 'ret' not in ori['ocr'] or 'paragraphs' not in ori['ocr']:
                        print('ret or paragraphs does not exists! {}'.format(ori['ocr']))
                        continue

                    if isinstance(ori['ocr'], str):
                        ret = json.loads(ori['ocr'])['ret']
                        paragraphs = json.loads(ori['ocr'])['paragraphs']
                    else:
                        ret = ori['ocr']['ret']
                        paragraphs = ori['ocr']['paragraphs']

                    num_details = len(details)
                    for d in details:
                        if slow_idx >= num_details:
                            break
                        text = d['text']
                        all_text.append(str(slow_idx) + ':' + text)
                        #if word == text and iou(d, r['rect']) > 0.8:
                        for idx, graph in enumerate(paragraphs):
                            num = len(graph['para_idx']['idx'])
                            charset = []
                            word = ''
                            for i in graph['para_idx']['idx']:
                                r = ret[i]
                                charset.extend(r['charset'])
                                word += r['word']
                            if word == text:
                                left = d['left']
                                top = d['top']
                                width = d['width']
                                height = d['height']
                                #cv2.rectangle(image, (left, top), (left + width, top + height),  (0, 255, 0), 1, 4)
                                #if (is_small_size_v2(width, height) and num == 1) \
                                #         or (is_small_size(charset) and num > 1):
                                if is_small_size_v2(width, height):
                                    flag = True
                                    cv2.rectangle(image, (left, top), (left + width, top + height), (255, 0, 255), 1, 4)
                                    cv2.putText(image, str(slow_idx), (left + 2, top), \
                                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 255), 2)
                                    region = ori_image[top:(top + height), left:(left + width)]
                                    part = fname.split('.')
                                    save_region_path = os.path.join(save_path, 'ocr_region')
                                    make_path(save_region_path)
                                    save_file = os.path.join(save_region_path, \
                                            part[0] + '_' + str(slow_idx) + '.' + part[1])
                                    cv2.imwrite(save_file, region)
                                    region_ocr.append('{}:{},w={},h={}'.format(str(slow_idx), text, width, height))

                                    '''
                                    if num > 1:
                                        for i in graph['para_idx']['idx']:
                                            r = ret[i]
                                            poly_location = r['poly_location']
                                            points = np.array([[p['x'], p['y'] + fast_idx * ori['height']] \
                                                    for p in poly_location['points']], np.int32)
                                            cv2.polylines(image, [points], True, (255, 0, 255))

                                        poly_location = graph['finegrained_poly_location']
                                        points = np.array([[p['x'], p['y'] + fast_idx * ori['height']] for p in poly_location['points']], np.int32)
                                        cv2.polylines(image, [points], True, (255, 128, 0))
                                     '''
                                else:
                                    cv2.rectangle(image, (left, top), \
                                            (left + width, top + height), (0, 255, 0), 1, 4)
                                    cv2.putText(image, str(slow_idx), (left + 2, top), \
                                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
                                paragraphs.pop(idx)
                                slow_idx += 1
                                break

                if all_text:
                    concat_text = concat_text.join(all_text)
                if not has_loaded:
                    save_ori_image_path = os.path.join(save_path, 'ori_images')
                    make_path(save_ori_image_path)
                    save_file = os.path.join(save_ori_image_path, fname)
                    cv2.imwrite(save_file, ori_image)
                    wlines.append('{}\t{}\t{}\n'.format(pic_url, save_file, concat_text))

                if flag:
                    save_image_path = os.path.join(save_path, 'images')
                    make_path(save_image_path)
                    save_file = os.path.join(save_image_path, fname)
                    cv2.imwrite(save_file, image)
                    with open(region_ocr_file, 'a+') as wf: 
                        s = '||'
                        s = s.join(region_ocr)
                        wf.write('{}\t{}\t{}\n'.format(pic_url, save_file, s))
                        
                #break

            except Exception as e:
                traceback.print_exc()
                print(pic_url)
                continue
        if not has_loaded:
            with open(map_file, 'w') as f:
                f.writelines(wlines)

    return

if __name__ == '__main__':
    main()
