#-*-coding:utf-8-*-
"""
author:   zhangyan75@baidu.com
date  :   21/12/27 10:34:34
desc  :   
"""

from ocrlib.xvision.ocr_text_filter_new_trial import is_abnormal_typeset
import os
import sys
import json
import copy
import traceback
import argparse
from tqdm import tqdm

def parse_args():
    """解析参数"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--infile", type=str, help="input file")
    parser.add_argument("--anno_file", type=str, default="anno_file.txt", help="annotation file")
    parser.add_argument("--save_path", type=str, default="show_images", help="save path")
    return parser.parse_args()

def make_path(path):
    """创建路径"""
    if not os.path.exists(path):
        os.makedirs(path)

def load_anno_file(anno_file):
    """加载标注文件"""
    anno_dict = {}
    with open(anno_file, 'r') as f:
        for line in f:
            fields = line.rstrip().split('\t')
            region_file = fields[0]
            region_name = os.path.basename(region_file)
            label = fields[1]
            anno_dict[region_name] = int(label)
    return anno_dict

def process(infile, anno_dict, save_path):
    """处理"""
    positive = 0
    tp = 0
    fp = 0
    ab_type_arr = ['normal', 'slash', 'curve']
    tp_lines = []
    fp_lines = []
    fn_lines = []
    wlines = []
    with open(infile, 'r') as f:
        for line in tqdm(f.readlines()):
            try:
                fields = line.rstrip().split('\t')
                if len(fields) < 5:
                    continue
                lp_url = fields[0]
                bos_url = fields[1]
                pic_url = fields[2]
                region_file = fields[3]
                region_name = os.path.basename(region_file)
                label = anno_dict[region_name]
                pos = fields[4].find(',{')
                ocr_str = fields[4][pos + 1:]
                ocr = json.loads(ocr_str)
                addtional = fields[4][:pos]
                pp = addtional.rfind(',')
                part1 = addtional[:pp]
                part2 = addtional[pp + 1:]

                originals = ocr['originals']
                details = ocr['details']
                new_details = []
                '''
                if region_name == '9c744c5013307f2ae91f2e5723216b41_1.jpg':
                    import pdb
                    pdb.set_trace()
                    print(region_file)
                '''
                for ocr_text_item in details:
                    if 'auxiliary' in ocr_text_item:
                        para_idx = ocr_text_item['auxiliary']['para_idx']
                        #cut_img_id = ocr_text_item['auxiliary']['cut_img_id']
                        #ori = originals[cut_img_id]
                        ori = originals[0]
                        
                        if isinstance(ori['ocr'], str):
                            ret = json.loads(ori['ocr'])['ret']
                        else:
                            ret = ori['ocr']['ret']
                        ocr_info = [ret[i] for i in para_idx]
                        text = '' 
                        for i in para_idx:
                            text += ret[i]['word'].encode('utf-8') 
                        #print(text)
                        average_score = ocr_text_item['prob']['average']
                        ab_type = is_abnormal_typeset(ocr_info)['id']
                        name = ab_type_arr[ab_type]
                        if label:
                            positive += 1
                            if ab_type:
                                tp += 1
                                tp_lines.append(line.rstrip() + '\t' + name + '\n')
                            else:
                                fn_lines.append(line.rstrip() + '\t' + name + '\n')
                        else:
                            if ab_type:
                                fp += 1
                                fp_lines.append(line.rstrip() + '\t' + name + '\n')
                        ocr_text_item['low_quality']['is_abnormal_typeset'] = ab_type
                        #print(ocr_text_item['low_quality']['is_abnormal_typeset'])
                        new_details.append(ocr_text_item)
                w_ocr = copy.deepcopy(ocr)
                w_ocr['details'] = details
                w_ocr['originals'] = originals 

                wlines.append('{}\t{}\t{}\t{}\t{}||{}\t{}\n'.format(\
                        lp_url, bos_url, pic_url, region_file, part1, part2, json.dumps(w_ocr)))
            except Exception as e:
                traceback.print_exc()
                import pdb
                pdb.set_trace()
                #continue
                break
    if positive and tp and fp: 
        print('pos={}, tp={}, fp={}, recall={}, precision={}'.format(\
                positive, tp, fp, float(tp) / positive, float(tp) / (tp + fp)))
    with open(os.path.join(save_path, 'abnormal_type.res'), 'w') as wf:
        wf.writelines(wlines)
    with open(os.path.join(save_path, 'tp.txt'), 'w') as wf:
        wf.writelines(tp_lines)
    with open(os.path.join(save_path, 'fp.txt'), 'w') as wf:
        wf.writelines(fp_lines)
    with open(os.path.join(save_path, 'fn.txt'), 'w') as wf:
        wf.writelines(fn_lines)


def main():
    """main"""
    args = parse_args()
    infile = args.infile
    anno_file = args.anno_file
    save_path = args.save_path
    make_path(save_path)
    anno_dict = load_anno_file(anno_file)
    process(infile, anno_dict, save_path)

    return

if __name__ == '__main__':
    main()
