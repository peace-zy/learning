#-*-:coding: utf-8 -*-
"""
Author:   zhangyan75@baidu.com
Date  :   21/12/24 10:34:34
Desc  :   
"""

import cv2
import json
import requests
import numpy as np
import traceback
import os
import hashlib 
import argparse
import copy

def parse_args():
    """解析参数"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--infile", type=str, help="input file")
    parser.add_argument("--save_path", type=str, default="show_images", help="save path")
    parser.add_argument("--has_loaded", action='store_true', help="whether or not the image is downloaded")
    parser.add_argument("--map_file", type=str, default="../map_file_ori.txt", help="map file")
    parser.add_argument("--region_file", type=str, default="region_file.txt", help="region file")
    parser.add_argument("--show_file", type=str, default="show_file.txt", help="show file")
    return parser.parse_args()
    
def make_path(path):
    """创建路径"""
    os.makedirs(path, exist_ok=True)
def rm_file(f):
    """删除文件"""
    if os.path.exists(f):
        os.remove(f)

def main():
    """main"""
    args = parse_args()
    infile = args.infile 
    save_path = args.save_path
    map_file = args.map_file
    make_path(save_path)
    region_file = os.path.join(save_path, args.region_file)
    show_file = os.path.join(save_path, args.show_file)
    has_loaded = args.has_loaded
    rm_file(region_file)
    rm_file(show_file)

    url_local = {}
    if has_loaded:
        with open(map_file) as f:
            for line in f:
                fields = line.rstrip().split('\t')
                url = fields[0]
                local = fields[1]
                url_local[url] = local
    ab_type = ['normal', 'slash', 'curve']

    wlines = []
    with open(infile, 'r') as f:
        for line in f:
            fields = line.rstrip().split('\t')
            if len(fields) < 1:
                continue
            try:
                lp_url = fields[0] 
                pic_url = fields[1] 
                bos_url = fields[2] 
                if not has_loaded:
                    response = requests.get(pic_url)
                    cont = np.array(bytearray(response.content), dtype=np.uint8)
                    fname = hashlib.md5(cont).hexdigest() + '.jpg'
                    image = cv2.imdecode(cont, cv2.IMREAD_COLOR)
                    ori_image = copy.deepcopy(image)
                else:
                    local = url_local[pic_url]
                    #local = url_local[pic_url]
                    _, fname = os.path.split(local)
                    image = cv2.imread(local)
                    ori_image = copy.deepcopy(image)
                ocr_str = fields[3]
                ocr = json.loads(ocr_str)
                originals = ocr['originals']
                details = ocr['details']

                concat_text = '||'
                all_text = []

                region_ocr = []
                flag = False
                for idx, ocr_text_item in enumerate(details):
                    if 'auxiliary' in ocr_text_item and 'low_quality' in ocr_text_item:
                        para_idx = ocr_text_item['auxiliary']['para_idx']
                        cut_img_id = ocr_text_item['auxiliary']['cut_img_id']
                        ori = originals[cut_img_id]

                        left = ocr_text_item['left']
                        top = ocr_text_item['top']
                        width = ocr_text_item['width']
                        height = ocr_text_item['height']
                        text = ocr_text_item['text']
                        all_text.append(text)
                        abnormal_dict = {}
                        low_quality = ocr_text_item['low_quality']
                        abnormal_typeset = low_quality['is_abnormal_typeset']
                        if abnormal_typeset > 0:
                            if isinstance(ori['ocr'], str):
                                ret = json.loads(ori['ocr'])['ret']
                                paragraphs = json.loads(ori['ocr'])['paragraphs']
                            else:
                                ret = ori['ocr']['ret']
                                paragraphs = ori['ocr']['paragraphs']
                            ocr_info = [ret[i] for i in para_idx]
                            flag = True
                            cv2.rectangle(image, (left, top), (left + width, top + height), (255, 0, 255), 1, 4)
                            cv2.putText(image, str(idx), (left + 2, top), \
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 255), 2)
                            region = ori_image[top:(top + height), left:(left + width)]
                            part = fname.split('.')
                            save_region_path = os.path.join(save_path, 'ocr_region')
                            make_path(save_region_path)
                            save_file = os.path.join(save_region_path, \
                                    part[0] + '_' + str(idx) + '.' + part[1])
                            cv2.imwrite(save_file, region)
                            abnormal_dict['details'] = [ocr_text_item] 
                            abnormal_dict['originals'] = [ori] 
                            winfo = '{}:{},{},{}'.format(\
                                    str(idx), text.encode('utf-8'), \
                                    ab_type[abnormal_typeset], json.dumps(abnormal_dict))
                            region_ocr.append(winfo)
                            with open(region_file, 'a+') as wf: 
                                wf.write('{}\t{}\t{}\t{}\t{}\n'.format(lp_url, pic_url, bos_url, save_file, winfo))
                        else:
                            cv2.rectangle(image, (left, top), \
                                    (left + width, top + height), (0, 255, 0), 1, 4)
                            cv2.putText(image, str(idx), (left + 2, top), \
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

                if all_text:
                    concat_text = concat_text.join(all_text)
                if not has_loaded:
                    save_ori_image_path = os.path.join(save_path, 'ori_images')
                    make_path(save_ori_image_path)
                    save_file = os.path.join(save_ori_image_path, fname)
                    cv2.imwrite(save_file, ori_image)
                    wlines.append('{}\t{}\t{}\t{}\t{}\n'.format(lp_url, pic_url, bos_url, save_file, concat_text))

                if flag:
                    save_image_path = os.path.join(save_path, 'images')
                    make_path(save_image_path)
                    save_file = os.path.join(save_image_path, fname)
                    cv2.imwrite(save_file, image)
                    with open(show_file, 'a+') as wf: 
                        s = '||'
                        s = s.join(region_ocr)
                        wf.write('{}\t{}\t{}\t{}\t{}\n'.format(lp_url, pic_url, bos_url, save_file, s))
                        
            except Exception as e:
                traceback.print_exc()
                print(pic_url)
                continue
        if not has_loaded:
            with open(map_file, 'w') as f:
                f.writelines(wlines)

    return

if __name__ == '__main__':
    main()
