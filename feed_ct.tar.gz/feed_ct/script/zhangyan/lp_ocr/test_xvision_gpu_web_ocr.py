#!/usr/bin/env python
#coding=utf-8
"""
author:   zhangyan75@baidu.com
date  :   22/01/05 10:34:34
desc  :   
"""

import base64
import urllib2
import json
import sys
import traceback
import requests
import random
print (sys.getdefaultencoding())

def GetXvisionWebOcrResult(image_bin):
    """获取网图ocr结果"""
    feature_name = "FEATURE_VIS_IMG_OCR_GPU_WEBIMGS2"
    business_name = "tradition_fengkong_meteor_video_and_image_media_ocr_web_gpu_online" 
    url = "http://group.xvision-xvisionproxy.xVision.all.serv:8089/xvision/xvision_sync"
    auth_key = "8e50a5f8-80c6-545b-ab49-e3fb1ad271d9"
    feature_data = json.dumps({
                    'appid': '10005',
                    'logid': random.randint(1000000, 100000000),
                    'format': 'json',
                    'from': 'test-python',
                    'cmdid': '123',
                    'clientip': '0.0.0.0',
                    'data': base64.b64encode("object_type=general_v4&disp_paragraph_poly=true&" \
                                "disp_line_poly=true&type=st_ocrapi_all&appid=分配编号&" \
                                "clientip=x.x.x.x&fromdevice=pc&version=1.0.0&detecttype=LocateRecognize&" \
                                "languagetype=CHN_ENG&locate_type=v4&imgDirection=setImgDirFlag&image=" \
                                + base64.b64encode(image_bin))})


    data_dict = {
                "business_name": business_name, #必填，jobname
                "resource_key": "test.jpg", #用于标记图片
                "auth_key": auth_key, #必填，token
                "feature_name": feature_name, #算子名称
                "data": base64.b64encode(feature_data)
                }
    data = json.dumps(data_dict)
    headers = {"Content-Type": "application/json"}
    request = urllib2.Request(url, data, headers)
    response = urllib2.urlopen(request)
    results = response.read()
    response.close()
    results=json.loads(results)
    return results


def Xvision_FEATURE_VIS_IMG_OCR_GPU_WEBIMGS2(url):
    """网图ocr算子请求"""
    image_bin = requests.get(url).content
    results = GetXvisionWebOcrResult(image_bin) 
    info = ''
    if "feature_result" in results.keys():
        print ("asdfasdfadfa{}".format(results.keys()))
        feature_result = results["feature_result"] 
        try:
            if "value" in feature_result.keys():
                value = json.loads(feature_result["value"])
                print (value.keys())
                if value and "result" in value:
                    result = json.loads(base64.b64decode(value["result"]))
                    print (result.keys())
                    if "ret" in result:
                        ret = result["ret"]
                        for r in ret:
                            info += r["word"].encode('utf-8')
                            
                info += "\n"
                print("Xvision_FEATURE_VIS_IMG_OCR_GPU_WEBIMGS2: " + info)

        except Exception as e:
            traceback.print_exc()
            pass
    return
def main():
    """main"""
    if len(sys.argv) != 2:
        print ('''\033[32m<usage>\n\tpython {} [url]\033[37m:'''.format(__file__))
        return 
    url = sys.argv[1]
    Xvision_FEATURE_VIS_IMG_OCR_GPU_WEBIMGS2(url)
    
    return

if __name__ == "__main__":
    main()
