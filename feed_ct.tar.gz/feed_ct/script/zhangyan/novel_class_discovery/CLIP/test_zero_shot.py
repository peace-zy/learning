# -*- coding: utf-8 -*-
#!/usr/bin/env python3
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了新类别发现(based on clip)功能。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2021/11/11 10:00:00
"""
#refs: https://github.com/openai/CLIP
import os
import clip
import torch
from PIL import Image
from nltk.corpus import wordnet
from tqdm import tqdm
import numpy as np
import sys
words = (list(wordnet.words()))
with open('words.txt', 'w') as f:
    for w in words:
        f.write(w + '\n')

class Model(object):
    def __init__(self, text_features_file='words_np.npy'):
        self.text_features_file = text_features_file

        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model = None
        self.preprocessor = None
        self.image_fea = None
        self.text_fea = None

    def load_model(self):
        """Load the model"""
        self.model, self.preprocssor = clip.load('ViT-B/32', self.device)

    def preprocess(self, image_file):
        """Prepare the inputs"""
        image = Image.open(image_file) 
        image_input = self.preprocssor(image).unsqueeze(0).to(self.device)
        return image_input

    def gen_image_fea(self, image_input):
        """Generate features of image"""
        image_features = self.model.encode_image(image_input)
        image_features /= image_features.norm(dim=-1, keepdim=True)
        return image_features

    def gen_text_fea(self):
        """Generate features of text"""
        if not os.path.exists(self.text_features_file):
            text_features_np = self.save_text_features_np()
        else:
            text_features_np = self.load_text_features_np()

        text_fea = text_features_np / np.linalg.norm(text_features_np, ord=2, axis=-1, keepdims=True)
        text_fea_cpu = torch.from_numpy(text_features_np)
        text_fea_cpu /= text_fea_cpu.norm(dim=-1, keepdim=True)
        print(sum(sum(text_fea - text_fea_cpu.numpy())))

        return text_fea_cpu

    def infer(self, image_input):
        """Calculate features"""
        with torch.no_grad():
            image_features = self.gen_image_fea(image_input)
            image_features_cpu = image_features.cpu()

            text_features_cpu = self.gen_text_fea()

            # Pick the top 5 most similar labels for the image
            similarity = (100.0 * image_features_cpu @ text_features_cpu.T).softmax(dim=-1)
            values, indices = similarity[0].topk(10)

            # Print the result
            print("\n\033[32m[origianl softmax]\033[37m Top predictions:\n")
            for value, index in zip(values, indices):
                    print(f"{words[index]:>16s}: {100 * value.item():.2f}%")

            similarity, indices = (100.0 * image_features_cpu @ text_features_cpu.T).topk(10)
            indices = indices[0]
            values = similarity[0].softmax(dim=-1)


            # Print the result
            # sparse softmax: 取topk,在进行softmax
            # refs: https://kexue.fm/archives/8046#稀疏Softmax
            print("\n\033[32m[Sparse softmax]\033[37m Top predictions:\n")
            for value, index in zip(values, indices):
                    print(f"{words[index]:>16s}: {100 * value.item():.2f}%")

    def load_text_features_np(self):
        """Load pre-saved features of text"""
        text_features_np = np.load(self.text_features_file)
        return text_features_np
        
    def save_text_features_np(self):
        """Save features of text"""
        text_features_np = None
        num = len(words)
        print (num)
        step = 1000
        for i in tqdm(range(0, num, step)):
            text_inputs = torch.cat([clip.tokenize(f"a photo of a {c}") for c in words[i:step + i]]).to(self.device)
            text_features = self.model.encode_text(text_inputs)
            text_features /= text_features.norm(dim=-1, keepdim=True)
            fea_cpu_np = text_features.cpu().numpy()
            if text_features_np is None:
                text_features_np = fea_cpu_np
            else:
                text_features_np = np.concatenate((text_features_np, fea_cpu_np), axis=0)
            print(text_features_np.shape)
        np.save(self.text_features_file, text_features_np)
        return text_features_np

def main():
    """Main
       usage:
       CUDA_VISIBLE_DEVICES=2 python test_zero_shot.py [image_file]
    """ 
    image_file = sys.argv[1]
    model = Model()
    model.load_model()
    image_input = model.preprocess(image_file)
    model.infer(image_input)

if __name__ == '__main__':
    main()
