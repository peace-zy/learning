#-*- coding:utf-8 -*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了热搜榜抓取功能。
目前支持百度热搜、cctv热搜

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2021/07/15 10:00:00
"""

from get_hot_word import *

def func_dec():
    """打印函数说明"""
    import get_hot_word
    print(help(get_hot_word))

if __name__ == '__main__':
    BaseParser.print_info()
    while True:
        print('监控开始 {}'.format(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())))
        start = time.time()
        print('[crawling   ] baidu')
        BaiduParser().run()
        print('\033[32m[         OK]\033[37m\n')
        print('[crawling   ] cctv')
        CCTVParser().run()
        print('\033[32m[         OK]\033[37m\n')
        end = time.time()
        print("elaps time: {}ms".format((end - start) * 1000))
        print('-' * 100)
        # 间隔10s刷新
        time.sleep(10) 
