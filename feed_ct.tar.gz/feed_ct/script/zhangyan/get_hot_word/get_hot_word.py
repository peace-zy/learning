#-*- coding:utf-8 -*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了热搜榜抓取功能。
目前支持百度热搜、cctv热搜

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2021/07/01 10:00:00
"""

import os
import sys
import requests
from lxml import etree
import time
import json
import traceback

class BaseParser(object):
    """页面解析基类"""
    def __init__(self, title, save_name, save_path='json'):
        """初始化
        Args:
            title: 解析标题
            save_name: 解析结果存储成json格式的名称
            save_path: 存储解析结果路径
        """
        
        self.save_path = save_path
        self.make_path(save_path)
        self.save_name = save_name
        self.save_file = os.path.join(save_path, save_name)
        self.json_dict = {'title': title,
                          'time': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()),
                          'data': []} 
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) '\
                                      'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'}

    def run(self): 
        """执行函数接口"""
        self.parse()
        self.write()
         
    def parse(self):
        """解析函数，子类实现"""
        raise NotImplementedError('{}:{}.{} not available'.format(\
                os.path.realpath(__file__), self.__class__.__name__, sys._getframe().f_code.co_name))

    def write(self):
        """存储解析后的json结果"""
        with open(self.save_file, 'w+', encoding='utf-8') as f:
            f.write(json.dumps(self.json_dict, ensure_ascii=False, indent=2, separators=(',', ':')))
  
    @staticmethod   
    def make_path(path):
        """创建目录
        Args:
            path: 待创建路径
        """
        if not os.path.exists(path):
            os.makedirs(path)

    @staticmethod   
    def print_info():
        """打印标题"""
        info = '''
             -----------------------------------------------------------------------
            |   ████████╗██████╗ ███████╗███╗   ██╗██████╗ ██╗███╗   ██╗ ██████╗    |
            |   ╚══██╔══╝██╔══██╗██╔════╝████╗  ██║██╔══██╗██║████╗  ██║██╔════╝    |
            |      ██║   ██████╔╝█████╗  ██╔██╗ ██║██║  ██║██║██╔██╗ ██║██║  ███╗   |
            |      ██║   ██╔══██╗██╔══╝  ██║╚██╗██║██║  ██║██║██║╚██╗██║██║   ██║   |
            |      ██║   ██║  ██║███████╗██║ ╚████║██████╔╝██║██║ ╚████║╚██████╔╝   |
            |      ╚═╝   ╚═╝  ╚═╝╚══════╝╚═╝  ╚═══╝╚═════╝ ╚═╝╚═╝  ╚═══╝ ╚═════╝    | 
             -----------------------------------------------------------------------
        '''                                                                   
        print('\033[32m{}\033[37m'.format(info))



class BaiduParser(BaseParser):
    """解析百度热搜网页"""
    def __init__(self, title='百度实时热点', save_name='baidu.json', save_path='json'):
        super(BaiduParser, self).__init__(title=title,
                                          save_path=save_path,
                                          save_name=save_name)
        self.url = 'http://top.baidu.com/buzz?b=1'

    def parse(self):
        """解析函数"""
        try:
            response = requests.get(self.url, headers=self.headers, timeout=(5, 10))
            #with open('data.html', 'w') as f:
            #    f.write(response.text)
            #response.encoding='gb2312'
            #soup = etree.HTML(response.text.replace("<tr >", "<tr class=\"hideline\">"))
            soup = etree.HTML(response.text.replace('<!--s-data:', '<!--'))
            for soup_a in soup.xpath("//div[@id='sanRoot']"):
                data = json.loads(soup_a[0].text)
                content = data['data']['cards'][0]['content']
                for cnt in content: 
                    blist = {}
                    hot_name = cnt['word']
                    hot_url = cnt['url']
                    blist['name'] = hot_name
                    blist['url'] = hot_url
                    blist['dec'] = cnt['desc']
                    blist['img'] = cnt['img']
                    self.json_dict['data'].append(blist)

        except Exception as e:
            print('\033[31m{}:{}.{} error\033[37m'.format(os.path.realpath(__file__),\
                    self.__class__.__name__, sys._getframe().f_code.co_name))
            traceback.print_exc()

# out-of-date only contains 2019
'''
class CCTVParser(BaseParser):
    """解析央视网"""
    def __init__(self, title='央视要闻', save_name='cctv.json', save_path='json'):
        super(CCTVParser, self).__init__(title=title,
                                          save_path=save_path,
                                          save_name=save_name)
        self.url = 'http://news.cctv.com/data/index.json'
        self.headers['Referer'] = 'https://news.cctv.com/'
     
    def parse(self):
        """解析函数"""
        try:
            response = requests.get(self.url, headers=self.headers, timeout=(5, 10)).text
            data = json.loads(response)
            for cnt in data['rollData']:
                blist = {}
                hot_url = cnt['url']
                hot_name = cnt['title'].replace('\\n', '').\
                               replace('\n', '').replace('\\r', '').replace('\r', '').strip()
                blist['name'] = hot_name
                blist['url'] = hot_url
                blist['dec'] = cnt['description']
                blist['img'] = cnt['image']
                self.json_dict['data'].append(blist)

        except Exception as e:
            print('\033[31m{}:{}.{} error\033[37m'.format(os.path.realpath(__file__),\
                    self.__class__.__name__, sys._getframe().f_code.co_name))
            traceback.print_exc()
'''

class CCTVParser(BaseParser):
    """解析央视网"""
    def __init__(self, title='央视要闻', save_name='cctv.json', save_path='json'):
        super(CCTVParser, self).__init__(title=title,
                                          save_path=save_path,
                                          save_name=save_name)
        self.url = 'http://api.cportal.cctv.com/api/rest/articleInfo/getScrollList'
        self.params = self.set_params() 
     
    def set_params(self, num='1000', page=1):
        """设置参数"""
        return {
            'n': num,    
            'version': '1',
            'p': page}

    def parse(self):
        """解析函数"""
        try:
            response = requests.get(self.url, params=self.params, headers=self.headers, timeout=(5, 10)).text
            data = json.loads(response)
            for cnt in data['itemList']:
                blist = {}
                hot_url = cnt['detailUrl']
                hot_name = cnt['itemTitle']
                blist['name'] = hot_name
                blist['url'] = hot_url
                #blist['dec'] = cnt['description']
                blist['img'] = cnt['itemImage']['imgUrl1']
                self.json_dict['data'].append(blist)

        except Exception as e:
            print('\033[31m{}:{}.{} error\033[37m'.format(os.path.realpath(__file__),\
                    self.__class__.__name__, sys._getframe().f_code.co_name))
            traceback.print_exc()
