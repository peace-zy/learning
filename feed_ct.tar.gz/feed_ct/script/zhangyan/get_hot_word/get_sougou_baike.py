#-*- coding:utf-8 -*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了搜狗百科抓取功能。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2021/07/28 10:00:00
"""

import requests
import json
import traceback
import os

headers = {
    'Accept': '*/*',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'zh-CN,zh;q=0.9',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Content-Length': '8',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Host': 'tupu.baike.sogou.com',
    'Origin': 'http://tupu.baike.sogou.com',
    'Pragma': 'no-cache',
    'Referer': 'http://tupu.baike.sogou.com/',
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_3) '\
                  'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.164 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest'
}
tpid_desc = {
             '155': '党的十九大，主席团都有谁', '157': '知道这些关键词，看懂十九大', '159': '第十九届中央领导名单',
             '171': '九三学社中央委员会', '179': '中国国民党革命委员会', '183': '台湾民主自治同盟',
             '185': '中国农工民主党', '187': '中国致公党', '250': '建国70周年-年代符号', '252': '国家勋章和国家荣誉称号',
             '246': '中国人民解放军现役武器', '209': '中华人民共和国36位军事家', '207': '中国人民解放军发展历程',
             '205': '抗日战争重要战役', '203': '解放战争重要战役', '131': '二战非自动步枪一览', '129': '第二次鸦片战争',
             '127': '第一次世界大战', '125': '第二次世界大战', '123': '中国十大元帅', '121': '中国海军现役舰艇',
             '119': '中国海军领导', '117': '中国解放军军衔分级', '115': '中国人民解放军五大战区', '113': '中国人民解放军组织机构',
             '111': '中国共产党主要领导', '109': '中国共产党机构及代表大会', '107': '坦克大全', '105': '中国警衔职务分级',
             '103': '中国炸弹', '101': '中国地地导弹', '99': '中国地空导弹', '97': '世界自动步枪', '95': '美国火炮',
             '93': '美国海军舰艇', '91': '解放军陆军现役轻武器', '89': '解放军军用航空器', '87': '全球水面舰艇',
            }

def main():
    """主函数"""
    save_path = 'json'
    if not os.path.exists(save_path):
         os.makedirs(save_path)
    # 数据存放地址
    url = 'http://tupu.baike.sogou.com//ajax/detail/online'
    '''
    for tpid, desc in tpid_desc.items():
        data = 'tpid={}'.format(tpid)
        response = requests.post(url, headers=headers, data=data)
        print(response.text)
        content = json.loads(response.text)
    '''
    valid = []
    # 通过id区分百科类型及相应数据
    for tpid in range(500):
        data = 'tpid={}'.format(tpid)
        try:
            print(data)
            response = requests.post(url, headers=headers, data=data)
            if response.status_code != 200:
                continue
            content = json.loads(response.text)
            print(content['data']['describ'], content['data']['tpid'])
            valid.append('{}\n'.format({'tpid': tpid, 'describ': content['data']['describ']}))
            save_file = os.path.join(save_path, content['data']['describ']) + '.json'
            with open(save_file, 'w', encoding='utf-8') as f:
                f.write(response.text)
        
        except Exception as e:
            traceback.print_exc()
            print(response.text)
            continue

    print(valid)
    with open('valid.txt', 'w') as f:
         f.writelines(valid)
    return

if __name__ == '__main__':
    main()
