# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了函数导出功能。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2021/07/15 10:00:00
"""

from distutils.core import setup
from distutils.extension import Extension
from Cython.Build import cythonize
from Cython.Distutils import build_ext
import os

BUILD_PATH = ''
def get_ext_filename_without_platform_suffix(filename):
    """get_ext_filename_without_platform_suffix"""
    filename = filename.split('.')[0] + '.so'
    print('\033[32m{}\033[0m'.format(filename))
    return filename

class BuildExtWithoutPlatformSuffix(build_ext):
    """BuildExtWithoutPlatformSuffix"""
    def get_ext_filename(self, ext_name):
        """get_ext_filename"""
        filename = super().get_ext_filename(ext_name)
        global BUILD_PATH
        BUILD_PATH = self.build_lib
        return get_ext_filename_without_platform_suffix(filename)


def main():
    """main"""
    export_funcs = {
            'get_hot_word': ['get_hot_word.py'],
            }

    extensions = []
    for sub_path, funcs in export_funcs.items():
        for f in funcs:
            import_path = sub_path + '.'
            if '.' in f:
                name = f.split('.')[0]
            else:
                name = f
            import_path += name
            loc_file = os.path.join(sub_path, f)
            print(import_path, loc_file)
            extensions.append(Extension(import_path, [loc_file]))

    setup(name='wrapper',
          cmdclass={'build_ext': BuildExtWithoutPlatformSuffix},
          ext_modules=cythonize(extensions))

if __name__ == '__main__':
    main()
