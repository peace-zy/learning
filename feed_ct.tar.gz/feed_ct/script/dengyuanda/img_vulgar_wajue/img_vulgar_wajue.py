#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Author:   dengyuanda@baidu.com
Date  :   21/07/15 15:32:09
Desc  :   
"""

import os
import argparse
import datetime


def getYesterday():
    """
    get yesterday date
    """ 
    today = datetime.date.today() 
    oneday = datetime.timedelta(days = 1) 
    yesterday = today - oneday  
    return (str(yesterday.year).zfill(4), str(yesterday.month).zfill(2), str(yesterday.day).zfill(2))

yy, ym, yd = getYesterday()
today = datetime.date.today() 
ty, tm, td = (str(today.year).zfill(4), str(today.month).zfill(2), str(today.day).zfill(2))

yesterday_str = yy + ym + yd
today_str = ty + tm + td

parser = argparse.ArgumentParser()
parser.add_argument('--filepath', default = './', help = "file of image log")
parser.add_argument('--start_date', default = yesterday_str, help = "file of image log")
parser.add_argument('--end_date', default = today_str, help = "file of image log")
parser.add_argument('--out_path', default = today_str + '_res.txt', help = "file of image log")


class ImgVulgar(object):
    """
    image vulgar exca
    """
    def __init__(self, filepath, start_date, end_date, out_path):
        self.all_date = self.get_all_date(start_date, end_date)
        self.fp = filepath
        self.r = []
        self.mj = []
        self.uid_cnt = {}
        self.op = out_path
        #self.m_lq = []
    
    def get_all_date(self, st, ed):
        """
        get all date from start to end
        """
        st_y = int(float(st[0:4]))
        st_m = int(float(st[4:6]))
        st_d = int(float(st[6:8]))
        
        ed_y = int(float(ed[0:4]))
        ed_m = int(float(ed[4:6]))
        ed_d = int(float(ed[6:8]))
        
        all_date = []
        if st_y == ed_y:
            if st_m == ed_m:
                for k in range(st_d, ed_d + 1):
                    all_date.append(str(st_y).zfill(4) + str(st_m).zfill(2) + str(k).zfill(2))
            else:
                for m in range(st_m, ed_m + 1):
                    if m == st_m:
                        for k in range(st_d, 32):
                            all_date.append(str(st_y).zfill(4) + str(m).zfill(2) + str(k).zfill(2))
                    elif m == ed_m:
                        for k in range(1, ed_d + 1):
                            all_date.append(str(st_y).zfill(4) + str(m).zfill(2) + str(k).zfill(2))
                    else:
                        for k in range(1, 32):
                            all_date.append(str(st_y).zfill(4) + str(m).zfill(2) + str(k).zfill(2))
        else:
            for y in range(st_y, ed_y + 1):
                if y == st_y:
                    for m in range(st_m, 13):
                        if m == st_m:
                            for k in range(st_d, 32):
                                all_date.append(str(y).zfill(4) + str(m).zfill(2) + str(k).zfill(2))
                        else:
                            for k in range(1, 32):
                                all_date.append(str(y).zfill(4) + str(m).zfill(2) + str(k).zfill(2))
                elif y == ed_y:
                    for m in range(1, ed_m + 1):
                        if m == ed_m:
                            for k in range(1, ed_d + 1):
                                all_date.append(str(y).zfill(4) + str(m).zfill(2) + str(k).zfill(2))
                        else:
                            for k in range(1, 32):
                                all_date.append(str(y).zfill(4) + str(m).zfill(2) + str(k).zfill(2))
                else:
                    for m in range(1, 13):
                        for k in range(1, 32):
                            all_date.append(str(y).zfill(4) + str(m).zfill(2) + str(k).zfill(2))
        return all_date

    def wajue(self):
        """
        exca img url trom log
        """
        m_lq = []
        for d in self.all_date:    
            if os.path.exists('%s/%s_image_info.txt' % (self.fp, d)):
                print ('start %s' % d)
                f = open('%s/%s_image_info.txt' % (self.fp, d))
                lines = f.readlines()
                f.close()
                for i in lines:
                    re = i.split('\t')[5]
                    if re.find('\xe5\x9b\xbe\xe7\x89\x87\xe5\xba\x94\xe6\x80\xa5') >= 0:
                        self.r.append(i)
                print ('end %s' % d)
        for i in self.r:
            if i.split('\t')[4] == 'manual_reject':
                self.mj.append(i)
        for i in self.mj:
            uid = i.split('\t')[2]
            if uid not in self.uid_cnt:
                self.uid_cnt[uid] = 1
            else:
                self.uid_cnt[uid] += 1
        uid_mtf = []
        for i in self.uid_cnt:
            if self.uid_cnt[i] >= 10:
                print ('uid: %s' % i)
                uid_mtf.append(i)
        for d in self.all_date:    
            if os.path.exists('%s/%s_image_info.txt' % (self.fp, d)):
                print ('start %s' % d)
                f = open('%s/%s_image_info.txt' % (self.fp, d))
                lines = f.readlines()
                f.close()
                for i in lines:
                    if i.split('\t')[2] in uid_mtf:
                        m_lq.append(i)
                print ('end %s' % d)
        return m_lq

    def write(self):
        """
        write result to output path
        """
        u = []
        all_res = self.wajue()
        for i in all_res:
            url = i.strip().split('\t')[-1]
            for k in url.split("'"):
                if k.find('http') >= 0:
                    u.append(k)
        u = list(set(u))
        f = open(self.op, 'w')
        for i in u:
            f.write(i + '\n')
        print ('finished')
        f.close()

if __name__ == '__main__':
    args = parser.parse_args()
    m = ImgVulgar(args.filepath, args.start_date, args.end_date, args.out_path)
    m.write()


