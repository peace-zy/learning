#-*-coding:utf-8-*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""  crop character from json result"""

import json
import urllib
import cv2
import os
import sys

def main(output_file, lines):
    """ main function"""
    if os.path.exists(output_file) == False:
        os.mkdir(output_file)
    cnt = 0
    for i in range(len(lines)):
        l = lines[i].strip().split('\t')[-1]
        try:
            urllib.urlretrieve(lines[i].split('\t')[0], '1.jpg')
            im = cv2.imread('1.jpg')
            im_shape = im.shape
            js = json.loads(l)
            for a in js['originals']:
                ret = a['ocr']['ret']
                for r in ret:
                    c = r['charset']
                    for charset in c:
                        print charset
                        rect = charset['rect']
                        top = max(0, int(rect['top']) - 5)
                        left = max(0, int(rect['left']) - 5)
                        down = min(im_shape[0], top + int(rect['height']) + 10)
                        right = min(im_shape[1], left + int(rect['width']) + 10)
                        im_out = im[top:down, left:right, :]
                        cv2.imwrite('%s/%s.jpg' % (output_file, str(cnt).zfill(25)), im_out)
                        cnt += 1
        except Exception as e:
            print e
            #print l
            continue
    return

if __name__ == '__main__':
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    f=open(input_file)
    lines=f.readlines()
    f.close()
    main(output_file, lines)

