#-*-coding:utf-8-*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""  test SVM model and write result"""

import warnings, json, os, random, sys
import numpy as np
from sklearn import svm
from sklearn.externals import joblib

def load_model(model_path):
    """ load saved moel"""
    clf = joblib.load(model_path)
    return clf

def get_result(input_file, clf, mode):
    """ get predict result """
    f = open(input_file)
    l1 = f.readlines()
    f.close()
    u = []
    for i1 in range(len(l1)):
        if i1 % 10000 == 0:
            print ('finish %d lines, find %s images' % (i1, len(u)))
        i = l1[i1]
        i = i.strip()
        js = json.loads(i.split('\t')[-1])
        sub_fea = js['res']
        if mode == 0:
            result = clf.predict([sub_fea])
        else:
            result = clf.predict_proba([sub_fea])
        u.append(i.split('\t')[0] + '\t' + str(result[0]))
    return u

def write_res(u, output_path):
    """write result to output_path"""
    f = open(output_path, 'w')
    for i in u:
        f.write(i + '\t')
    f.close()
    return

if __name__ == '__main__':
    model_path = sys.argv[1]
    input_file = sys.argv[2]
    output_path = sys.argv[3]
    mode = int(float(sys.argv[4]))
    clf = load_model(model_path)
    u = get_result(clf, input_file, mode)
    write_res(u, output_path)
    
