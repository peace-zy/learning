#-*-coding:utf-8-*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""  train the SVM model"""

import warnings, json, os, random, sys
import numpy as np
from sklearn import svm
from sklearn.externals import joblib

warnings.filterwarnings("ignore", category=FutureWarning, module="sklearn", lineno=196)

def train_model(input_file):
    """ train model""" 
    feature = []
    lab = []
    f = open(input_file)
    lines = f.readlines()
    f.close()
    random.shuffle(lines)
    
    for i in lines:
        try:
            l = i.strip()
            js = json.loads(l.split('\t')[-1])
            l_feature = js['res']
            l_lab = int(float(l.split('\t')[1]))
            feature.append(l_feature)
            lab.append(l_lab)
        except Exception as e:
            print e
            continue

    clf = svm.SVC(probability=True)
    clf.fit(feature, lab)
    return clf

def save_model(clf, output_path):
    """ save model to local path"""
    joblib.dump(clf, output_path)
    return

if __name__ == '__main__':
    input_file = sys.argv[1]
    output_path = sys.argv[2]
    clf = train_model(input_file)
    save_model(clf, output_path)


