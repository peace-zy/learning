#-*-coding:utf-8-*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""  get hog feature of images in input_file"""

import numpy as np
import os
import cv2
import json
import sys

def get_all_filename(input_file):
    """ get all file's filename in input_file"""
    fn = []
    for root, dirs, files in os.walk('%s' % (input_file)):
        for f in files:
            fn.append('%s/%s' % (input_file, f))
    return fn

def set_hog():
    """ set parameters for hog descriptor"""
    hog={}
    hog['winSize'] = (64, 64)
    hog['blockSize'] = (16, 16)
    hog['blockStride'] = (8, 8)
    hog['cellSize'] = (8, 8)
    hog['nbins'] = 9
    hog['derivAperture'] = 1
    hog['winSigma'] = 4.
    hog['histogramNormType'] = 0
    hog['L2HysThreshold'] = 2.0000000000000001e-01
    hog['gammaCorrection'] = 0
    hog['nlevels'] = 64
    hog['WinStride'] = (8, 8)
    hog['padding'] = (8, 8)
    hog['locations'] = ((10, 20), )
    return hog

def get_hog_feature(output_txt, fn):
    """ get hog feature of images"""
    f = open(output_txt, 'a')
    u_out = []
    hog_para = set_hog()
    #hog = cv2.HOGDescriptor(hog_para['winSize'], hog_para['blockSize'], hog_para['blockStride'], hog_para['cellSize'], 
        #hog_para['nbins'], hog_para['derivAperture'], hog_para['winSigma'], hog_para['histogramNormType'], 
        #hog_para['L2HysThreshold'], hog_para['gammaCorrection'], hog_para['nlevels'])
    hog = cv2.HOGDescriptor(hog_para['winSize'], hog_para['blockSize'], hog_para['blockStride'], 
        hog_para['cellSize'], hog_para['nbins'])
    for i1 in range(0, len(fn)):
        i = fn[i1]
        img = cv2.imread(i)
        img_r = cv2.resize(img, (64, 64))
        #hist = hog.compute(img_r, hog_para['winStride'], hog_para['padding'], hog_para['locations'])
        hist = hog.compute(img_r)
        h = hist.reshape((-1, ))
        res = {}
        res["res"] = list(h)
        res = str(res).replace("'", '"')
        u_out.append('%s\t%s' % (i, res))
        f.write('%s\t%s\n' % (i, res))
        if len(u_out) % 10000 == 0:
            print ('finish %d' % (len(u_out)))
    f.close()
    return

def main(input_file, output_txt):
    """ main function """
    fn = get_all_filename(input_file)
    get_hog_feature(output_txt, fn)
    return    

if __name__ == '__main__':
    input_file = sys.argv[1]
    output_txt = sys.argv[2]
    main(input_file, output_txt)
