#-*-coding:utf-8-*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""  test CLIP for url txt"""

import json
import os
import clip
import torch
from PIL import Image
from nltk.corpus import wordnet
from tqdm import tqdm
import numpy as np
import sys
import urllib.request
import random

words = (list(wordnet.words()))
with open('words.txt', 'w') as f:
    for w in words:
        f.write(w + '\n')

class Model(object):
    """ The class of CLIP model"""
    def __init__(self, text_features_file='words_np.npy'):
        """ init parameters"""
        self.text_features_file = text_features_file

        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model = None
        self.preprocessor = None
        self.image_fea = None
        self.text_fea = None

    def load_model(self):
        """ load model weights"""
        # Load the model
        self.model, self.preprocssor = clip.load('ViT-B/32', self.device)

    def preprocess(self, image_file):
        """ preprocess input image"""
        # Prepare the inputs
        image = Image.open(image_file) 
        image_input = self.preprocssor(image).unsqueeze(0).to(self.device)
        return image_input

    def gen_image_fea(self, image_input):
        """ generate image feature"""
        image_features = self.model.encode_image(image_input)
        image_features /= image_features.norm(dim=-1, keepdim=True)
        return image_features

    def gen_text_fea(self):
        """ generate text feature"""
        if not os.path.exists(self.text_features_file):
            text_features_np = self.save_text_features_np()
        else:
            text_features_np = self.load_text_features_np()

        text_fea = text_features_np / np.linalg.norm(text_features_np, ord=2, axis=-1, keepdims=True)
        text_fea_cpu = torch.from_numpy(text_features_np)
        text_fea_cpu /= text_fea_cpu.norm(dim=-1, keepdim=True)
        print(sum(sum(text_fea - text_fea_cpu.numpy())))

        return text_fea_cpu

    def infer(self, image_input):
        """ use model to infer"""
        # Calculate features
        with torch.no_grad():
            image_features = self.gen_image_fea(image_input)
            #image_features_cpu = image_features.cpu()
            image_features_cpu = image_features.cpu().float()

            #text_features_cpu = self.gen_text_fea()
            text_features_cpu = self.gen_text_fea().float()

            # Pick the top 5 most similar labels for the image
            similarity = (100.0 * torch.matmul(image_features_cpu, text_features_cpu.T)).softmax(dim=-1)
            #similarity = (100.0 * image_features_cpu @ text_features_cpu.T).softmax(dim=-1)
            values, indices = similarity[0].topk(10)

            # Print the result
            print("\nTop predictions:\n")
            for value, index in zip(values, indices):
                    print("%16s: %.3f" % (words[index], 100 * value.item()))

            #similarity, indices = (100.0 * image_features_cpu @ text_features_cpu.T).topk(10)
            similarity, indices = (100.0 * torch.matmul(image_features_cpu, text_features_cpu.T)).topk(10)
            indices = indices[0]
            values_sft = similarity[0].softmax(dim=-1)


            # Print the result
            print("\nTop predictions:\n")
            for value, index in zip(values_sft, indices):
                    #print(f"{words[index]:>16s}: {100 * value.item():.2f}%")
                    print("%16s: %.3f" % (words[index], 100 * value.item()))
            ret={}
            res=[]
            for i in range(len(values)):
                temp={}
                temp['lab'] = words[indices[i]]
                temp['score'] = float(values[i])
                temp['score_stf'] = float(values_sft[i])
                res.append(temp)
            ret['res']=res
            print (json.dumps(ret))
            return json.dumps(ret) 


    def load_text_features_np(self):
        """load offline text features from .npy"""
        text_features_np = np.load(self.text_features_file)
        return text_features_np
        
    def save_text_features_np(self):
        """save text features to a offline .npy file"""
        text_features_np = None
        num = len(words)
        print (num)
        step = 1000
        for i in tqdm(range(0, num, step)):
            temp = []
            temp = [clip.tokenize("a photo of a %s" % c) for c in words[i:(step + i)]]
            text_inputs = torch.cat(temp).to(self.device)
            #text_inputs = torch.cat([clip.tokenize(f"a photo of a {c}") for c in words[i:step + i]]).to(self.device)
            text_features = self.model.encode_text(text_inputs)
            text_features /= text_features.norm(dim=-1, keepdim=True)
            fea_cpu_np = text_features.cpu().numpy()
            if text_features_np is None:
                text_features_np = fea_cpu_np
            else:
                text_features_np = np.concatenate((text_features_np, fea_cpu_np), axis=0)
            print(text_features_np.shape)
        np.save(self.text_features_file, text_features_np)
        return text_features_np

def write_res(input_file, output_file, pos, model):
    """ read and write url text"""
    f = open(input_file, 'r', encoding = 'gb18030')
    lines = f.readlines()
    f.close()
    f = open(output_file, 'a')
    for l in lines:
        l = l.strip()
        img_num = random.randint(10 ** 6, 10 ** 7)
        try:
            url = l.split('\t')[pos]
            urllib.request.urlretrieve(url, "img_" + str(img_num) + ".jpg")
            image_input = model.preprocess("img_" + str(img_num) + ".jpg")
            res = model.infer(image_input)
            f.write(l + '\t' + res + '\n')
            if os.path.exists("img_" + str(img_num) + ".jpg") == True:
                os.remove("img_" + str(img_num) + ".jpg")
        except Exception as e:
            if os.path.exists("img_" + str(img_num) + ".jpg") == True:
                os.remove("img_" + str(img_num) + ".jpg")
            print (e)
            continue
    f.close()

def main():
    """main function"""
    #image_file = sys.argv[1]
    for i in sys.argv:
        print (i)
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    pos = int(float(sys.argv[3]))
    model = Model()
    model.load_model()
    #image_input = model.preprocess(image_file)
    #model.infer(image_input)
    write_res(input_file, output_file, pos, model)

if __name__ == '__main__':
    main()
