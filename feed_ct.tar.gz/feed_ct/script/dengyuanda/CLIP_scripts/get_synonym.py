#-*-coding:utf-8-*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################

"""  get words synonym"""

import os
import sys
from nltk.corpus import wordnet

def get_syn_ant(input_txt):
    """ use wordnet API to get synonym"""
    f = open(input_txt)
    lines = f.readlines()
    f.close()

    words=[]
    for i in lines:
        words.append(i.strip())

    syn = []
    ant = []
    for word in words:
        for synset in wordnet.synsets(word):
            for lemma in synset.lemmas():
                syn.append(lemma.name())
                if lemma.antonyms():
                    ant.append(lemma.antonyms()[0].name())
    syn = list(set(syn))
    ant = list(set(ant))
    return (syn, ant)

def write_res(output_txt, syn):
    """write result"""
    f = open(output_txt, 'w')
    for i in syn:
        print (i)
        f.write(i + '\n')
    f.close()
    return
    
if __name__ == '__main__':
    arg=sys.argv
    syn, ant = get_syn_ant(arg[1])
    write_res(arg[2], syn)
