#-*-coding:utf-8-*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""  use CLIP to get last 7 days result"""
import os
import datetime
import sys
import random
import threading
import multiprocessing
import concurrent.futures
import concurrent

position = int(float(sys.argv[1]))
local_path = sys.argv[2]

def get15day():
    """ get last 15 days date"""
    res = []
    today = datetime.date.today()
    res.append('%s%s%s' % (str(today.year).zfill(4), str(today.month).zfill(2), str(today.day).zfill(2)))
    for i in range(14): 
        #today=datetime.date.today() 
        oneday = datetime.timedelta(days=1) 
        yesterday = today - oneday  
        res.append('%s%s%s' % (str(yesterday.year).zfill(4), 
            str(yesterday.month).zfill(2), str(yesterday.day).zfill(2)))
        today = yesterday
    return res

def get_oneday_res(input_file, output_file, pos):
    """ get one day's CLIP result """
    print ('%s start' % (input_file))
    os.system('python test_zero_shot_url.py %s %s %d' % (input_file, output_file, pos))
    return

def gene_oneday_task(date):
    """ generate oneday's task """
    ori_input_file = 'data_urls_%s.all.pass.txt' % (date)
    f = open(ori_input_file, encoding = 'utf-8')
    lines = f.readlines()
    if len(lines) == 0:
        return
    f.close()
    random.shuffle(lines)
    lines = lines[0:6 * (10 ** 6)]
    f = open('%s_temp.txt' % (date), 'w')
    for i in lines:
        f.write(i)
    f.close()
    output_file = 'data_urls_%s.all.pass_res.txt' % (date)
    input_file = '%s_temp.txt' % (date)
    global position
    get_oneday_res(input_file, output_file, position)
    return

def main():
    """ main function """
    all_date = get15day()
    global local_path
    for date in all_date:
        os.system('scp %s/data_urls_%s.all.pass.txt ./' % (local_path, date))
    exists_date = []
    for i in all_date:
        ori_file = 'data_urls_%s.all.pass.txt' % (i)
        res_file = 'data_urls_%s.all.pass_res.txt' % (i)
        if os.path.exists(ori_file) == True and os.path.exists(res_file) == False:
            exists_date.append(i)
        if len(exists_date) > 7:
            break
    print (exists_date)
    #executor = concurrent.futures.ThreadPoolExecutor()
    for i in exists_date:
        t1 = threading.Thread(target = gene_oneday_task, args = (i, ))
        t1.start()
    return exists_date

if __name__ == '__main__':
    exists_date = main()
