#-*-coding:utf-8-*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################

""" translate words from en to zh"""
import os
import json
import sys

def main(input_txt, output_txt, ak, sk):
    """ main function """
    f = open(input_txt)
    lines = f.readlines()
    f.close()
    for i2 in range(len(lines)):
        i1 = lines[i2]
        i = i1.strip().replace('_', ' ')
        print (i)
        f = open(output_txt, 'a')
        os.system("curl -i -k 'https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=%s&"\
            "client_secret=%s' > token_temp.txt" % (ak, sk))
        f1 = open('token_temp.txt')
        l1 = f1.readlines()
        f1.close()
        ljs = l1[-1].strip()
        #print (ljs)
        #f.close()
        js = json.loads(ljs)
        token = js['access_token']
        os.system("curl -H " + '"Content-Type: application/json" -X POST -d ' + "'" + '{"q":"%s","from":"en","to":"'\
            'zh"}' % (i) + "'" + ' "https://aip.baidubce.com/rpc/2.0/mt/texttrans/v1?access_token='\
            '%s" > word_zh_temp.txt' % (token))
        f2 = open('word_zh_temp.txt')
        l2 = f2.readlines()
        print (l2[0])
        f2.close()
        f.write(i1.strip() + '\t' + l2[0] + '\n')
        f.close()

if __name__ == '__main__':
    arg = sys.argv
    main(arg[1], arg[2], arg[3], arg[4])
