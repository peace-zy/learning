#!/bin/bash

set -exu

hadoop_bin=/home/users/liuxing07/cloud/hadoop/hadoop-client/hadoop/bin/hadoop
python_bin=/home/users/liuxing07/cloud/miniconda3/bin/python
feed_hadoop_addr=afs://shaolin.afs.baidu.com:9902/app/ecom/fengkong/kg/parse_audit_log
tradetag_hadoop_addr=afs://shaolin.afs.baidu.com:9902/app/ecom/fengkong/dw/fengkong_data/userid_new_ssg_trade_day
tradetag_local_file_name=userid_new_ssg_trade

today=$(date +%Y%m%d)
#${hadoop_bin} dfs -copyToLocal ${tradetag_hadoop_addr}/time_stamp=${today}000000/* ${tradetag_local_file_name}

#begin_day=$(date --date '11 days ago' +%Y%m%d)
#end_day=$(date +%Y%m%d)
begin_day=20210703
end_day=20210713

time_distance=$(expr $(date +%s -d "${end_day}") - $(date +%s -d "${begin_day}"))
day_num=$(expr ${time_distance} / 86400)

enum_dates=()
for(( i=0;i<day_num;i++ ));do
    enum_dates[i]=$(date +%Y%m%d -d "${begin_day} +${i} day")
done

for this_day in ${enum_dates[@]};do
    echo ${this_day}
    time_subpath=parse_feed_audit_log_${this_day}
    feed_audit_path=${feed_hadoop_addr}/${time_subpath}
    #${hadoop_bin} dfs -cat ${feed_audit_path}/*|/bin/grep -E 'mp4|mkv|avi|flv|mpeg'|iconv -f gbk -t utf-8|${python_bin} process_video_tradetag.py ${this_day}
    ${hadoop_bin} dfs -cat ${feed_audit_path}/*|awk -F'\t' '{if(3!="")print $0}'|iconv -f gbk -t utf-8|${python_bin} process_video_tradetag.py ${this_day}
done
