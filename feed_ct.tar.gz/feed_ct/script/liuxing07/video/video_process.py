#!/usr/bin/env python3
#coding=utf-8

from __future__ import print_function

import os
import sys
import rich
import pretty_errors

import requests
import hashlib
import enum
import base64
import traceback

_curpath = os.path.dirname(os.path.abspath(__file__))

IMAGE_EXT = ['jpg', 'png', 'bmp', 'jpeg', 'tiff', 'raw']
VIDEO_EXT = ['mp4', 'avi', 'mkv', 'flv', 'm4v', 'rmvb', 'wmv', 'mov', '3gp']
AUDIO_EXT = ['mp3', 'aac', 'opus', 'wav', 'flac', 'alac']

@enum.unique
class OutFormat(enum.Enum):
    File   = 1
    Base64 = 2
    Binary = 3

attribute = enum.Enum('URLAttribute', ('IMAGE', 'VIDEO', 'AUDIO', 'TEXT', 'WEB'),
                      module=__name__, type=int, start=1)

format_ext_map = {attribute.IMAGE: IMAGE_EXT,
                  attribute.VIDEO: VIDEO_EXT,
                  attribute.AUDIO: AUDIO_EXT}

class ParamError(ValueError):
    pass


class DownloadFromURL(object):
    def __init__(self):
        super().__init__()
        pass

    @classmethod
    def url2file(cls, url, url_attr=attribute.VIDEO):
        """
        description:
            obtain data from url
        params:
            input:
                url:            image url of string format
                out_format:     output format what the caller wants
            output:
                result: return result according to out_format
        """

        response = requests.get(url, stream=True)
        if not response.status_code == requests.codes.ok:
            rich.print(":pile_of_poo: [bold red]Connection failed![/bold red]:smiley:")
            return
        url_ext = url.strip().split('.')[-1]
        ext = format_ext_map[url_attr]
        filename = url.strip().split('/')[-1].split('.')[0]
        if url_attr == attribute.VIDEO:
            file_ext = url_ext if url_ext in ext else 'mp4'
        elif url_attr == attribute.AUDIO:
            file_ext = url_ext if url_ext in ext else 'mp3'
        elif url_attr == attribute.IMAGE:
            file_ext = url_ext if url_ext in ext else 'jpg'
            filename = hashlib.md5(url.encode('UTF-8')).hexdigest()
        else:
            raise ParamError('Wrong parameters!')
        with open(os.path.join(_curpath, filename + '.' + file_ext), 'wb') as f:
            for chunk in response.iter_content(chunk_size=10240):
                f.write(chunk)

    @staticmethod
    def url2image(url, out_format=OutFormat.Base64):
        if out_format == OutFormat.File:
            return DownloadFromURL.url2file(url, attribute.IMAGE)
        else:
            response = requests.get(url)
            if not response.status_code == requests.codes.ok:
                rich.print(":pile_of_poo: [bold red]Connection failed![/bold red]:smiley:")
                return
            if out_format == OutFormat.Binary:
                return response.content
            elif out_format == OutFormat.Base64:
                return base64.b64encode(response.content).decode('UTF-8')
            else:
                rich.print(":thumbs_up: :pile_of_poo: [bold red]Wrong output format![/bold red]:smiley:")
                return

    @staticmethod
    def url2video(url, out_format=OutFormat.File):
        if out_format == OutFormat.File:
            return DownloadFromURL.url2file(url, attribute['VIDEO'])
        else:
            rich.print(":thumbs_up: :pile_of_poo: [bold red]Wrong output format![/bold red]:smiley:")
            return

    @staticmethod
    def url2audio(url, out_format=OutFormat.File):
        if out_format == OutFormat.File:
            return DownloadFromURL.url2file(url, attribute.AUDIO)
        else:
            rich.print(":thumbs_up: :pile_of_poo: [bold red]Wrong output format![/bold red]:smiley:")
            return

import moviepy
import moviepy.editor
def video_browse(video_path) -> None:
    video_clip = moviepy.editor.VideoFileClip(video_path)
    import pdb;pdb.set_trace()
    print(dir(video_clip))
    print(video_clip.duration, video_clip.size, video_clip.fps)

    audio = video_clip.audio
    audio.write_audiofile(os.path.splitext(video_path)[0] + '.mp3')
    clip = video_clip.subclip(0, 10)
    print(clip.duration, clip.size, clip.fps)







def main() -> None:
    video_url = 'http://nadvideo2.baidu.com/2a5a52520b8f07fafac39a6f9890d2a5_1280_720.mp4'
    #DownloadFromURL.url2video(video_url)
    video_path = os.path.join(_curpath, [name for name in os.listdir(_curpath) if name.endswith('.mp4')][0])
    video_browse(video_path)
    pass


if __name__ == '__main__':
    main()
else:
    print(f'import module [{os.path.join(_curpath, __name__)}] success!')
