#!/usr/bin/env python3
#coding=utf-8

from __future__ import print_function

import os
import sys


from rich import print
from rich.progress import track
import tqdm
import pretty_errors
import collections
import hashlib

_curpath = os.path.dirname(os.path.abspath(__file__))

def mapping_from_hadoop() -> None:
    """
    通过shell脚本后python操作函数
    某些列为空的行数据在hadoop dfs -cat后会丢失，导致数据最后列数不同
    """
    trade_tag_file = os.path.join(_curpath, 'userid_new_ssg_trade')
    userid_tradetag_map = {}
    for line in track(open(trade_tag_file).readlines()):
        userid, f_trade_id, f_trade_name, s_trade_id, s_trade_name, _ = line.strip().split('\t')
        userid_tradetag_map[userid] = f'{f_trade_name}({f_trade_id})-{s_trade_name}({s_trade_id})'

    fout_file = os.path.join(_curpath, 'feed_audit_video_tradetag', 'video_tradetag_' + sys.argv[1] + '.txt')
    os.makedirs(os.path.dirname(fout_file), exist_ok=True)
    for line in tqdm.tqdm(sys.stdin):
        with open(fout_file, 'a+') as fout:
            try:
                result = line.strip() + '\t' + userid_tradetag_map[line.split('\t')[2]]
            except:
                result = line.strip() + '\t' + ''
            fout.write('%s\n' % result)

def mapping_from_local() -> None:
    """
    通过本地文件惊醒映射行业信息函数
    """
    local_file = os.path.join(_curpath, "feed_audit_video_tradetag", "feed_pid_uid_videourl_audit.txt")
    trade_tag_file =  os.path.join(_curpath, "feed_audit_video_tradetag", 'userid_new_ssg_trade')
    userid_tradetag_map = {}
    for line in track(open(trade_tag_file).readlines()):
        userid, f_trade_id, f_trade_name, s_trade_id, s_trade_name, _ = line.strip().split('\t')
        userid_tradetag_map[userid] = f'{f_trade_name}({f_trade_id})-{s_trade_name}({s_trade_id})'

    fout_file = os.path.join(_curpath, "feed_audit_video_tradetag", "feed_pid_uid_videourl_audit_tradetag.txt")
    os.makedirs(os.path.dirname(fout_file), exist_ok=True)
    for line in track(open(local_file).readlines()):
        pid, uid, videourl, audit_result, audit_reason = line.rstrip('\n').split('\t')
        with open(fout_file, 'a+') as fout:
            try:
                trade_info = userid_tradetag_map[uid]
            except:
                trade_info = "NULL"

            result = '\t'.join([videourl, trade_info, pid, uid, audit_result, audit_reason])
            fout.write('%s\n' % result)


def video_count_by_tradetag() -> None:
    """
    统计不同行业下视频量
    """
    fin_file = os.path.join(_curpath, "feed_audit_video_tradetag", "feed_pid_uid_videourl_audit_tradetag.txt.reject")
    tradetag_videonum_map = collections.defaultdict(int)
    import rich
    for line in rich.progress.track(open(fin_file).readlines()):
        tradetag_videonum_map[line.rstrip('\n').split('\t')[1].split('-')[0].strip()] += 1
    tagsorted = dict(sorted(tradetag_videonum_map.items(),
                             key=lambda item:item[0].split('(')[-1]))
    print('\n'.join(tagsorted.keys()))
    print('\n'.join([str(i) for i in tagsorted.values()]))

def video_count() -> None:
    fin_file = os.path.join(_curpath, "feed_audit_video_tradetag", "feed_pid_uid_videourl_audit_tradetag.txt.reject")
    fin = open(fin_file, encoding='UTF-8')
    productid_vnum_map = collections.defaultdict(int)
    productid_uniq_videourl_map = collections.defaultdict(set)
    while True:
        fin_lines = fin.readlines(100 * 1024 * 1024)
        if len(fin_lines) <= 0:
            break
        for line in tqdm.tqdm(fin_lines):
            videourl, tradetag, productid, userid, audit_result, audit_reason = line.rstrip('\n').split('\t')
            productid_vnum_map[productid] += 1
            productid_uniq_videourl_map[productid].add(videourl)
    for key in productid_vnum_map.keys():
        print(f'{key}\tvideo_num:{productid_vnum_map[key]}\t \
              uniq_video_num:{len(productid_uniq_videourl_map[key])}\t \
              duplacate_num:{productid_vnum_map[key]*1./len(productid_uniq_videourl_map[key]):.1f}')
    fin.close()





def main() -> None:
    #mapping_from_hadoop()
    #mapping_from_local()
    video_count_by_tradetag()
    #video_count()

    pass

if __name__ == '__main__':
    main()
else:
    print(f'import module [{os.path.join(_curpath, __name__)}] success!')
