#!/usr/bin/env python3
#coding:utf-8

"""
Author: liuxing07@baidu.com
Date:   2021年 12月 13日 星期一 11:02:47 CST
Description:    click button process excel from PM
"""

import os
import sys
import traceback
import json
import re
import tqdm
import requests
import pretty_errors
import random
import shutil
from typing import Union, Optional

_curpath = os.path.dirname(os.path.realpath(__file__))


def file2html(file_path: str,
              separator: str='\t',
              image_id: int=1,
              schema: Optional[list]=None) -> None:
    """
    默认文件第一列为图片url
    """
    assert os.path.exists(file_path), f"invalid file path: [{file_path}]"
    html_lines = []
    html_lines.append('<table border=1 width="100%">\n')

    line_pendix = "<tr>{}</tr>"
    line_head_pendix = "<th width=150>{}</th>"
    line_item_id = "<td width=10>{}</td>"
    line_item_pendix = "<td width=150>{}</td>"
    line_item_image_pendix = '<a href="{}" src="{}"><img src="{}" width=150 border=1 controls></a>'

    if schema:
        schema_line_list = [line_head_pendix.format('id').replace("150", "10")]
        for ik, item in enumerate(schema):
            schema_line_list.append(line_head_pendix.format(item))
        html_lines.append(line_pendix.format(''.join(schema_line_list)))

    lines = [i.strip('\n') for i in filter(None, open(file_path).readlines())]
    for ik, item in enumerate(lines, 1):
        item_list = item.split(separator)
        line_list = [] if not schema else [line_item_id.format(ik)]
        for ic, cell in enumerate(item_list):
            if ic == (image_id - 1):
                html_cell = line_item_image_pendix.format(cell, cell, cell)
            else:
                html_cell = cell
            line_list.append(line_item_pendix.format(html_cell))
        html_lines.append(line_pendix.format(''.join(line_list)))

    html_lines.append('\n</table>')
    html_out_file = os.path.join(os.path.expanduser('~/cloud/share/html'),
                                 os.path.basename(file_path).split('.')[0] + '.html')
    html_out_file = file_path + '.html'
    with open(html_out_file, 'w') as fout:
        fout.writelines([f"{i}\n" for i in html_lines])
    http_addr_prefix = "http://10.12.184.89:8080/"
    html_out_file_abspath = os.path.realpath(html_out_file)
    html_out_file_url = http_addr_prefix + 'feed_ct/' + html_out_file_abspath.split('feed_ct')[-1]


    sys.stdout.write(f"click: {html_out_file_url}\n")


def simple_show(filepath):
    """
    文件中每行为图片url时方可使用
    """
    fout = open(filepath + '.html', 'w')
    for line in tqdm.tqdm(open(filepath).readlines()):
        line = line.strip('\n')
        line = "<img src='" + line + "' height=150>\n"
        fout.write(line)
    fout.close()


def ann2html(filepath, topk=20, rows=2, cols=10):
    assert os.path.exists(filepath)

    if rows * cols < topk:
        rows += 1

    id_width = 10
    image_width = 100
    table_height = 100

    html_lines = []
    html_lines.append('<table border=1 width="100%">\n')

    line_pendix = "<tr>{}</tr>"
    line_head_pendix = "<th width={width}>{value}</th>"
    line_item_pendix = "<td width={width}>{value}</td>"
    line_item_image_pendix = '<a href="{url}" src="{url}"><img src="{url}" width={img_width} height={img_height} border=1 controls>{sim_distance}</a>'


    ori_url = set()
    sim_urls = []
    sim_distances = []
    for ik, line in enumerate(tqdm.tqdm(open(filepath).readlines()), 1):
        origin_url, sim_url, sim_distance = line.strip('\n').split('\t')
        ori_url.add(origin_url)
        assert len(ori_url) == 1
        sim_urls.append(sim_url)
        sim_distances.append(sim_distance)


        if ik % topk == 0:
            #import pdb;pdb.set_trace()
            assert len(sim_urls) == len(sim_distances) == topk
            for i in range(rows):
                row_list = []
                if i == 0:
                    id_item = line_item_pendix.format(width=id_width, value=ik//topk)
                    img_item = line_item_image_pendix.format(url=list(ori_url)[0],
                                                             img_width=image_width,
                                                             img_height=table_height,
                                                             sim_distance="")
                    img_item = line_item_pendix.format(width=image_width, value=img_item)
                else:
                    id_item = line_item_pendix.format(width=id_width, value="")
                    img_item = line_item_pendix.format(width=image_width, value="")
                row_list.append(id_item)
                row_list.append(img_item)

                for j in range(cols):
                    sim_img_item = line_item_image_pendix.format(url=sim_urls[i*cols + j],
                                                                 img_width=image_width,
                                                                 img_height=table_height,
                                                                 sim_distance="{:.6f}".format(float(sim_distances[i*cols + j])))
                    sim_img_item = line_item_pendix.format(width=image_width, value=sim_img_item)
                    row_list.append(sim_img_item)
                img_line_info = line_pendix.format(''.join(row_list))
                html_lines.append(img_line_info)

            sim_urls.clear()
            sim_distances.clear()
            ori_url.clear()


    html_lines.append('\n</table>')
    dir_path, ext = os.path.splitext(filepath)
    html_filepath = dir_path + '.html'
    with open(html_filepath, 'w', encoding='utf-8') as fout:
        fout.writelines([f"{i}\n" for i in html_lines])

    dirname, filename = os.path.split(html_filepath)
    shutil.copy(html_filepath, os.path.expanduser('~/cloud/share/html/'))
    http_addr_prefix = 'http://10.12.184.89:8080/html'
    sys.stdout.write(f"click: {http_addr_prefix}/{filename}\n")


def main():
    #file2html(sys.argv[1], image_id=2, schema=["title", "图片url", "vis-8w分类-top"])
    simple_show(sys.argv[1])


if __name__ == "__main__":
    main()
