#   Copyright (c) 2019 PaddlePaddle Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""BERT pretraining."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import six
import sys
if six.PY2:
    reload(sys)
    sys.setdefaultencoding('utf8')

import io
import os
import time
import argparse
import numpy as np
import logging
import random
import multiprocessing
import requests

import paddle
import paddle.fluid as fluid
from PIL import Image, ImageFile
import base64


def infer_emb_vit(args):
    """ddd"""
    batch_size = args.batch_size
    place = fluid.CUDAPlace(0)
    save_path = r'./data/init_ckpt/paddle_vil_inference'
    executor = fluid.Executor(place)
    program, feed_var_names, fetch_targets = fluid.io.load_inference_model(save_path, executor)
    feeder = fluid.DataFeeder(place=place, feed_list=feed_var_names, program=program)
    fp = r'/ssd3/wenzhoufutu01/trunk/baidu/personal-code/wenzhoufutu01/MMDict/data/eval/image.download.bs64'
    batch_data = []
    keys = []
    with open(fp, 'r') as f:
        for line in f:
            ll = line.strip().split('\t')
            key = ll[0]
            image_fea = ll[1]
            buf = base64.b64decode(image_fea)
            image = Image.open(io.BytesIO(buf))
            resize_img = compose(image)
            # resize_img = np.ones([224, 224, 3])
            batch_data.append([resize_img])
            keys.append(key)
            if len(batch_data) == batch_size:
                outs = executor.run(program, feed=feeder.feed(batch_data), fetch_list=fetch_targets)
                tmp = np.array(outs)
                # print(tmp.shape)
                feas = np.squeeze(tmp)
                for key, fea in zip(keys, feas):
                    # print(fea.shape)
                    fea = fea.tolist()
                    fea = '\t'.join([str(i) for i in fea])
                    print('\t'.join([key, fea]))
                batch_data = []
                keys = []

        if len(batch_data) > 0:
            while len(batch_data) < batch_size:
                batch_data.append(batch_data[0])

            outs = executor.run(
                program, feed=feeder.feed(batch_data), fetch_list=fetch_targets)
            feas = outs[0]

            for key, fea in zip(keys, feas[:len(keys)]):
                fea = fea.tolist()
                fea = '\t'.join([str(i) for i in fea])
                print('\t'.join([key, fea]))
            batch_data = []


def normalize(img, mean, std, data_format='HWC', to_rgb=False):
    """Normalizes a ndarray imge or image with mean and standard deviation.
    Args:
        img (np.array): input data to be normalized.
        mean (list|tuple): Sequence of means for each channel.
        std (list|tuple): Sequence of standard deviations for each channel.
        data_format (str, optional): Data format of img, should be 'HWC' or
            'CHW'. Default: 'CHW'.
        to_rgb (bool, optional): Whether to convert to rgb. Default: False.
    Returns:
        np.array: Normalized mage.
    """

    if data_format == 'CHW':
        mean = np.float32(np.array(mean).reshape(-1, 1, 1))
        std = np.float32(np.array(std).reshape(-1, 1, 1))
    else:
        mean = np.float32(np.array(mean).reshape(1, 1, -1))
        std = np.float32(np.array(std).reshape(1, 1, -1))
    if to_rgb:
        # inplace
        img = img[..., ::-1]

    img = (img - mean) / std
    return img


def center_crop_resize(image):
    """center crop"""
    image_width, image_height = image.size
    crop_height, crop_width = 224, 224
    crop_top = int(round((image_height - crop_height) / 2.0))
    crop_left = int(round((image_width - crop_width) / 2.0))
    image = image.crop(crop_top, crop_left, crop_height, crop_width)
    return image


def compose(image):
    """compose"""
    image = image.resize([224, 224], resample=Image.BICUBIC)
    # image = center_crop_resize(image)
    image = image.convert('RGB')
    image = np.array(image)
    image = image / 255
    image = normalize(
        image,
        mean=(0.48145466, 0.4578275, 0.40821073),
        std=(0.26862954, 0.26130258, 0.27577711))
    return image


def infer_emb_clip():
    """ddd"""
    batch_size = 128
    place = fluid.CPUPlace()
    # place = fluid.CUDAPlace(1)
    save_path = r'./paddle_clip_inference'
    executor = fluid.Executor(place)
    program, feed_var_names, fetch_targets = fluid.io.load_inference_model(save_path, executor)
    feeder = fluid.DataFeeder(place=place, feed_list=feed_var_names, program=program)
    keys = []
    batch_data = []
    for line in sys.stdin:
        ll = line.strip().split('\t')
        key = ll[0:-1]
        image_fea = ll[-1]
        try:
            buf = base64.b64decode(image_fea)
            image = Image.open(io.BytesIO(buf))
            resize_img = compose(image)
        except:
            continue
        batch_data.append([resize_img])
        keys.append(key)
        if len(batch_data) == batch_size:
            outs = executor.run(program, feed=feeder.feed(batch_data), fetch_list=fetch_targets)
            feas = np.squeeze(outs[0])
            for key, fea in zip(keys, feas):
                fea = np.array(fea)
                fea = base64.b64encode(fea).decode('utf-8')
                #fea = '\t'.join([str(i) for i in fea])
                key.append(fea)
                print('\t'.join(key))
            batch_data = []
            keys = []

    if len(batch_data) > 0:
        while len(batch_data) < batch_size:
            batch_data.append(batch_data[0])

        outs = executor.run(
            program, feed=feeder.feed(batch_data), fetch_list=fetch_targets)
        feas = outs[0]

        for key, fea in zip(keys, feas[:len(keys)]):
            #fea = fea.tolist()
            fea = np.array(fea)
            fea = base64.b64encode(fea).decode('utf-8')
            key.append(fea)
            print('\t'.join(key))
            #fea = '\t'.join([str(i) for i in fea])
            #print('\t'.join([key, fea]))
        batch_data = []


def infer_image_emb_clip(image_path):
    """ddd"""
    image_exts = ['jpg', 'png', 'jpeg', 'bmp']
    assert os.path.exists(image_path)
    image_files = []
    if os.path.isfile(image_path):
        ext = image_path.split('.')[-1]
        if ext.lower() in image_exts:
            image_files.append(image_path)
        else:
            image_urls = [i.strip('\n') for i in open(image_path).readlines()]
            image_files.extend(image_urls)
    elif os.path.isdir(image_path):
        for iroot, dirs, files in os.walk(image_path):
            for ifile in files:
                if ifile.split('.')[-1].lower() in image_exts:
                    image_files.append(os.path.join(iroot, ifile))

    place = fluid.CPUPlace()
    # place = fluid.CUDAPlace(1)
    save_path = r'./paddle_clip_inference'
    executor = fluid.Executor(place)
    program, feed_var_names, fetch_targets = fluid.io.load_inference_model(save_path, executor)
    feeder = fluid.DataFeeder(place=place, feed_list=feed_var_names, program=program)

    batch_data = []
    valid_image_files = []
    for image_file in image_files:
        try:
            #buf = base64.b64decode(image_fea)
            if image_file.startswith('http'):
                buf = requests.get(image_file).content
            else:
                buf = open(image_file, 'rb').read()
            image = Image.open(io.BytesIO(buf))
            resize_img = compose(image)
            batch_data.append([resize_img])
            valid_image_files.append(image_file)
        except:
            import traceback
            import sys
            sys.stderr.write(traceback.format_exc())


    batch_size = 128
    import math

    for i in range(int(math.ceil(len(batch_data) * 1. / batch_size))):
        batch_imgs = batch_data[i*batch_size: (i + 1) * batch_size]
        while len(batch_imgs) < batch_size:
            batch_imgs.append(batch_data[0])

        outs = executor.run(program, feed=feeder.feed(batch_imgs), fetch_list=fetch_targets)
        feas = np.squeeze(outs[0])

        valid_batch_image_files = valid_image_files[i * batch_size: (i + 1) * batch_size]
        for image_file, image_vector in zip(valid_batch_image_files, feas.tolist()[:len(valid_batch_image_files)]):
            result = [image_file] + ["{}".format(i) for i in image_vector]
            print('{}'.format('\t'.join(result)))

if __name__ == '__main__':
    #infer_emb_clip()
    image_path = '../ann-feature/crop_icons_image/xunilajitong'
    image_path = 'sample_imgs.url'
    image_path = '../../3C/3C_showcase_imgs'
    infer_image_emb_clip(image_path)
