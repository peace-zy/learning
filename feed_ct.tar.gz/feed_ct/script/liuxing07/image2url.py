"""
author:     liuxing07@baidu.com
description: transform image binary file to url or put image on BOS with generated bos-url
"""
#!/usr/bin/env python2

from baidubce import exception
from baidubce.services import bos
from baidubce.services.bos import canned_acl
from baidubce.services.bos.bos_client import BosClient
from baidubce.bce_client_configuration import BceClientConfiguration
from baidubce.auth.bce_credentials import BceCredentials
import sys
import os
import tqdm
import pypinyin

_curpath = os.path.dirname(os.path.realpath(__file__))


def chinese2pinyin(word, encode_type='utf-8'):
    """
    chinese charactor to pinyin
    """
    if not isinstance(word, unicode):
        word = word.decode(encode_type)
    s = ''
    word_pinyin = pypinyin.pinyin(word, style=pypinyin.NORMAL)
    for i in word_pinyin:
        s += ''.join(i)
    return s.encode(encode_type)


def is_zh(string):
    """
    whether one string contains chinese charactor
    """
    if not isinstance(string, unicode):
        string = string.decode('utf-8')
    for c_str in string:
        if u'\u4e00' <= c_str <= u'\u9fa5':
            return True
    return False


# from leizihe
bucket = 'jubao-test'
endpoint = 'su.bcebos.com'
ak = '8953a1f9f5014d158da417515543dea2'
sk = '159468413ed748c48fa2069b84c83a50'

#from qiudeyang
bucket = "sample-mark"
endpoint = "bj.bcebos.com"
ak = '0418cff92b954617b6efd24180f956ab'
sk = "94b372e63f194ef688677c2e489e7f52"

bos_config = BceClientConfiguration(credentials=BceCredentials(ak, sk), endpoint=endpoint)
bos_client = BosClient(bos_config)


#image_dir = 'youdao-icons-pinqin'
#image_classes = os.listdir(image_dir)
#
#for class_name in image_classes:
#    class_relative_path = image_dir+ '/' + class_name
#    if os.path.isfile(class_relative_path):
#        continue
#    fout = open(image_dir + '/' + class_name + '_bosbj_imgurl.txt', 'w')
#    for image_name in tqdm.tqdm(os.listdir(class_relative_path)):
#        image_path = class_relative_path + '/' + image_name
#        image_abs_path = os.path.join(_curpath, image_path)
#        bos_client.put_object_from_file(bucket, image_path, image_path)
#        url = "https://{}.{}/".format(bucket, endpoint) + image_path
#        fout.write('{}\n'.format(url))
#    fout.close()

# 采用路径拼接的方式来组成图片url，此种方式在某些地方不可访问
url_appendix = 'http://10.12.184.89:8080/feed_ct/models/'


image_dir = 'origin_data_3C/images'
image_classes = os.listdir(image_dir)
for class_name in image_classes:
    class_relative_path = image_dir + '/' + class_name
    if os.path.isfile(class_relative_path):
        continue

    if is_zh(class_name):
        class_name_pinyin = chinese2pinyin(class_name)
    else:
        class_name_pinyin = class_name
        continue

    fout = open(image_dir + '/' + class_name_pinyin + '_bosbj_imgurl.txt', 'w')
    for image_name in tqdm.tqdm(os.listdir(class_relative_path)):
        image_path = class_relative_path + '/' + image_name
        image_path_bos = image_dir + '/' + class_name_pinyin + '/' + image_name
        bos_client.put_object_from_file(bucket, image_path_bos, image_path)
        url = "https://{}.{}/".format(bucket, endpoint) + image_path_bos
        fout.write('{}\n'.format(url))
    fout.close()



#img=sys.argv[1]
#img_name = img.split('/')[-1]
#bos_client.put_object_from_file("sample-mark", img_name, img)
#print(bos_client.generate_pre_signed_url("sample-mark", img_name, expiration_in_seconds=-1))
#print("https://sample-mark.bj.bcebos.com/" + img_name)
