#!/home/users/liuxing07/ssd2/miniconda3/envs/tensorRT/bin/python3
#coding: utf-8

from __future__ import print_function

import os
import torch
import traceback
import numpy

import resnet
import transform

import onnxruntime
import onnx
#import onnxsim

_curpath = os.path.dirname(os.path.abspath(__file__))

model_names = sorted(name for name in resnet.__dict__
                     if name.islower()
                     and not name.startswith("_")
                     and callable(resnet.__dict__[name])
                     and name.startswith("resnet")
                     and not '_' in name)


def build_model(model_params):
    if (torch.cuda.is_available()
            and 'gpu' in model_params
            and int(model_params["gpu"]) >= 0
            and int(model_params["gpu"]) < torch.cuda.device_count()):
        device_type = 'cuda'
        #os.environ['CUDA_VISIBLE_DEVICES'] = str(model_params["gpu"])
        os.putenv('CUDA_VISIBLE_DEVICES', str(model_params["gpu"]))
        map_location = f'{device_type}:{model_params["gpu"]}'

    else:
        device_type = 'cpu'
        map_location = device_type
    device = torch.device(device_type)

    model = resnet.__dict__[model_params['arch']](num_classes=model_params['class_num'],
                               fc2conv=model_params['fc2conv'])

    checkpoint_path = os.path.join(_curpath, model_params['checkpoint_path'])
    if os.path.isdir(checkpoint_path):
        checkpoint_path = os.path.join(checkpoint_path, 'model_best.pth')

    checkpoint = torch.load(checkpoint_path, map_location=map_location)
    model.load_state_dict(checkpoint['state_dict'])
    model = model.to(device).eval()
    return model, device


def preprocess_crop(image_numpy, size, crop_num=8):
    """
    generate crops of image for batch prediction
    """
    crop_ops = [transform.RandomCrop(min(image_numpy.shape[:2])),
                transform.Rescale(size=size),
                transform.ToCHW(),
                transform.Normalize(order='CHW')]
    image_crops = []
    for ic in range(crop_num):
        image_crop = image_numpy.copy()
        for op in crop_ops:
            image_crop = op(image_crop)
        image_crops.append(image_crop)
    return transform.NumpyStack()(image_crops, axis=0)


def pytorch2onnx(model_params):
    batch_size = 1
    image_size = int(model_params['input_shape'])
    input_shape = (3, image_size, image_size)

    model, device = build_model(model_params)

    dummy_input = torch.randn(batch_size, *input_shape,  device=device)
    input_names = [].append(model_params['onnx_input'])
    output_names = [].append(model_params['onnx_output'])
    output_onnx_filename = model_params['onnx_outpath']
    torch.onnx.export(model,
                      dummy_input,
                      output_onnx_filename,
                      verbose=True,
                      input_names=input_names,
                      output_names=output_names,
                      do_constant_folding=True,
                      dynamic_axes={"inputs": {0: "batch_size"}, "outputs": {0: "batch_size"}})


    #-------check--------#
    with torch.no_grad():
        torch_out = {'output': model(dummy_input)}

    session = onnxruntime.InferenceSession(os.path.join(_curpath, output_onnx_filename))
    input_name = session.get_inputs()[0].name
    result = session.run([], {input_name: dummy_input.numpy()})
    for onnx_result, torch_result in zip(result, torch_out.values()):
        print(onnx_result, torch_result)
        numpy.testing.assert_almost_equal(torch_result.detach().cpu().numpy(),
                                          onnx_result,
                                          decimal=3)


    onnx_model = onnx.load(os.path.join(_curpath, output_onnx_filename))
    onnx.checker.check_model(onnx_model)
    print('onnx model check is done!')

def onnx2trt(model_params):
    onnx_filepath = os.path.abspath(model_params['onnx_outpath'])
    input_name = model_params['onnx_input']
    output_name = model_params['onnx_output']
    cmd = f'/opt/compiler/gcc-4.8.2/lib64/ld-linux-x86-64.so.2 --library-path /opt/compiler/gcc-4.8.2/lib64:/home/users/liuxing07/ssd3/media/TensorRT-7.1.3.4/targets/x86_64-linux-gnu/lib:/home/users/liuxing07/ssd3/media/cuda-10.2/lib64:/home/users/liuxing07/ssd3/media/cudnn-8.0/cuda/lib64 \
        /home/users/liuxing07/ssd3/media/TensorRT-7.1.3.4/targets/x86_64-linux-gnu/bin/trtexec \
        --onnx={onnx_filepath} \
        --saveEngine={os.path.basename(os.path.abspath(onnx_filepath)) + ".fp32.trt"} \
        --minShapes={input_name}:1x3x224x224,{output_name}:1x1x1x1 \
        --optShapes={input_name}:4x3x224x224,{output_name}:4x1x1x1 \
        --maxShapes={input_name}:8x3x224x224,{output_name}:8x1x1x1 \
        --device={model_params["gpu"]} \
        --verbose \
        --buildOnly'
    result = os.popen(cmd)
    print(result.read())


def main():
    model_params = {"class_num": 1,
                    "gpu": 0,
                    "arch": 'resnet34',
                    "fc2conv": True,
                    "checkpoint_path": 'out/checkpoint/resnet34_samesize_ratio1-2_patchnum5_target_normalize_smoothL1/20210508/checkpoint_epoch300.pth',
                    "input_shape": 224,
                    "onnx_outpath": 'stretch_model.onnx',
                    "onnx_input": 'inputs',
                    "onnx_output": 'outputs'}
    pytorch2onnx(model_params)
    onnx2trt(model_params)
    pass

if __name__ == '__main__':
    main()
else:
    print(f'import module [{os.path.join(_curpath, __file__)}] successfully!')
