#!/usr/bin/env python3
#coding: utf-8

import os
import sys
import pretty_errors
import traceback
import shutil

_curpath  = os.path.realpath(os.path.dirname(__file__))

def urlfile2html(urlfile: str) -> None:
    if not os.path.isabs(urlfile):
        urlfile = os.path.abspath(urlfile)
    if not os.path.exists(urlfile):
        print(f"Input urlfile does not exists! [{urlfile}]")
        sys.exit(1)
    if not os.path.isfile(urlfile):
        print(f"Input urlfile is directory! [{urlfile}]")
        sys.exit(1)

    html_out = []
    image_html_format = "<a href='{url}' src='{url}'><img src='{url}' height=150 control></a>"
    urls = [i.strip('\n') for i in filter(None, open(urlfile).readlines())]

    for ik, url in enumerate(urls):
        url = url.split('\t')[0]
        html_out.append(image_html_format.format(url=url))

    html_out_file = urlfile + '.html'
    with open(html_out_file, 'w') as fout:
        fout.writelines(f'{i}\n' for i in html_out)
    shutil.copy(html_out_file, os.path.expanduser('~/cloud/share/show_url/'))
    http_addr_prefix = "http://10.12.184.89:8080/show_url/"
    sys.stdout.write(f"click to open: {http_addr_prefix}{os.path.basename(html_out_file)}\n")


def main():
    filenames = ['hongbao/train_pos_pic_url',
                 'shouji/train_pos_pic_url',
                 'tanchuang/pm_eval_data_pos',
                 'tanchuang/train_data_pos',
                 ]
    filepaths = [os.path.join(_curpath, 'for_jiaojie', filename) for filename in filenames]
    for filename in filepaths:
        urlfile2html(filename)

if __name__ == '__main__':
    #main()
    if len(sys.argv) == 2:
        urlfile2html(sys.argv[1])
    else:
        sys.stdout.write(f"please run this script as the follow format:  \
                         \n\t python {sys.argv[0]} target_urlfile\n\n")

else:
    print(f"import module [{os.path.join(_curpath, __file__)}] successfully!")
