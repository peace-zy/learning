#!/usr/bin/env python3
#coding: utf-8

import os
import sys
import traceback
import requests
import tqdm
import json
import base64
import pretty_errors
from typing import Optional, Union

_curpath = os.path.dirname(os.path.realpath(__file__))


ADDR = "http://cms.baidu-int.com/api/image_service/image_app/image_matting_dpa_plus"
TOKEN = "69d548e3b00a8c0bb33fb32d4ff852ef"


def imagepath2bin(url: str) -> Optional[bytes]:
    image_bin = None
    if url.startswith("http"):
        try:
            response = requests.get(url)
            if response.status_code == requests.codes.ok:
                image_bin = response.content
        except Exception as e:
            print(traceback.format_exc())
    else:
        if os.path.exists(url):
            image_bin = open(url, 'rb').read()
        else:
            print(f"image not exists! [{url}]")
    return image_bin


def bin2base64(binary: bytes) -> str:
    return base64.b64encode(binary).decode()


def make_request(img_b64: bytes):
    header = {"token": TOKEN}
    #body = {"req_id": "1234567", "data": "{}".format(img_b64)}
    body = {"req_id": "1234567", "data": img_b64}

    return {"header": header, "body": body}
    #return body


def send_request(req_data):
    res = requests.post(ADDR, json=req_data)
    if res.status_code != requests.codes.ok or res.json() is None:
        print(json.dumps(res.json()))
        return None
    return res.json()


def check_res(res_json, out_file):
    code = res_json["header"]["failures"]["code"]
    msg = res_json["header"]["failures"]["message"]
    print(f"code: {code}\nmsg: {msg}")
    if code != 0:
        return msg
    js = res_json["body"]
    print(js.keys())
    print(js["msg"])

    if js["code"] != 0:
        return js["msg"]

    front_image_b64 = js["data"]
    buff = base64.b64decode(front_image_b64)
    with open(out_file, 'wb') as fout:
        fout.write(buff)
    return "success"


def get_image_front(image_path: str, out_image_path: str):
    res = None

    image_bin = imagepath2bin(image_path)
    if image_bin is None:
        return res

    request_data = make_request(bin2base64(image_bin))
    res_json = send_request(request_data)
    if res_json is None:
        return res

    if check_res(res_json, out_image_path) != "success":
        return res

    return "ok"



def process():
    filepath = os.path.join(_curpath, "front_saliency")
    url_file_list = ["test_img_url.txt"]

    custom_url_prefix = "http://10.12.184.89:8080/feed_ct"

    output_dir = os.path.join(_curpath, "front_saliency")
    os.makedirs(output_dir, exist_ok=True)

    img_out_filepath_info = os.path.join(output_dir, "oriimg_saliencyimg_url.txt")
    fout = open(img_out_filepath_info, 'w', encoding='utf-8')

    for url_file in url_file_list:
        url_file_name = url_file.split('.')[0]
        outfile_path = os.path.join(output_dir, url_file_name)
        os.makedirs(outfile_path, exist_ok=True)

        url_file = os.path.join(filepath, url_file)
        for line in tqdm.tqdm(open(url_file).readlines()):
            url = line.strip('\n').split('\t')[0]
            img_hash, img_ext = url.split('/')[-1].split('.')
            image_front_saliency_file_path = os.path.join(outfile_path, img_hash + ".png")
            if get_image_front(url, image_front_saliency_file_path) != "ok":
                image_front_saliency_file_custom_url = ""
            else:
                image_front_saliency_file_custom_url = custom_url_prefix + image_front_saliency_file_path.split('feed_ct')[-1]
            fout.write("{}\n".format('\t'.join([url, image_front_saliency_file_custom_url])))

    fout.close()
    file2html(img_out_filepath_info)


def file2html(filepath: str,
              separator: str='\t'):
    assert os.path.exists(filepath)

    html_lines = []
    html_lines.append('<table border=1 width="100%">\n')

    line_pendix = "<tr>{}</tr>"
    line_head_pendix = "<th width={width}>{value}</th>"
    line_item_pendix = "<td width={width}>{value}</td>"
    line_item_image_pendix = '<a href="{url}" src="{url}"><img src="{url}" width=200 border=1 controls></a>'

    id_width = 15
    image_width = 150

    schema = ["Id", "origin_image", "saliency_detect"]
    schema_html_list = []
    for s_schema in schema:
        width = image_width
        if s_schema == "Id":
            width = id_width
        schema_html_list.append(line_head_pendix.format(width=width, value=s_schema))

    html_lines.append(line_pendix.format(''.join(schema_html_list)))

    for ik, line in enumerate(open(filepath).readlines(), 1):
        url1, url2 = line.strip('\n').split('\t')
        url1_image_content = line_item_image_pendix.format(url=url1)
        if url2:
            url2_image_content = line_item_image_pendix.format(url=url2)
        else:
            url2_image_content = ""

        id_content = line_item_pendix.format(width=id_width, value=ik)
        url1_content = line_item_pendix.format(width=image_width, value=url1_image_content)
        url2_content = line_item_pendix.format(width=image_width, value=url2_image_content)

        line_content = line_pendix.format(''.join([id_content, url1_content, url2_content]))
        html_lines.append(line_content)
    html_lines.append('\n</table>')

    dir_path, ext = os.path.splitext(filepath)
    html_filepath = dir_path + '.html'
    with open(html_filepath, 'w', encoding='utf-8') as fout:
        fout.writelines([f"{i}\n" for i in html_lines])

    http_addr_prefix = "http://10.12.184.89:8080/"
    sys.stdout.write(f"click: {http_addr_prefix}/{filepath[filepath.find('feed_ct'):].replace('.txt', '.html')}\n")


def main():
    #process()
    img_out_filepath_info = os.path.join(_curpath, "front_saliency", "oriimg_saliencyimg_url.txt")
    file2html(img_out_filepath_info)

    pass

if __name__ == '__main__':
    main()
