#!/usr/bin/env python3
#coding: UTF-8

import sys
import os

try:
    import icrawler
except ImportError:
    sys.stdout.write(f"please make sure module [icrawler] has been installed!"
                     f"if not installed, run command: [pip install icrawler]")
    sys.exit(1)


import argparse
from icrawler.builtin import BaiduImageCrawler,BingImageCrawler,GoogleImageCrawler,GreedyImageCrawler,UrlListCrawler
from tqdm import tqdm

import base64
from six.moves.urllib.parse import urlparse
from icrawler import ImageDownloader
import traceback
import hashlib

import distutils.sysconfig

python_lib_path = distutils.sysconfig.get_python_lib()
modify_file_name = os.path.join(python_lib_path, 'icrawler/parser.py')

replace_str = str("headers = {'Accept-Language': 'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',"
                          "'Connection': 'keep-alive',"
                          "'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0',"
                          "'Upgrade-Insecure-Requests': '1',"
                          "'Referer': base_url}")

sys.stdout.write("continue as follows for Baidu engine crawler best!\n"
                 f"replace header info at line: [96] in file [{modify_file_name}] with follow info!\n\n{replace_str}\n\n")



def parse_cmd(args_str=""):
    parser = argparse.ArgumentParser()
    parser.add_argument("--type", type=str, default="Baidu", help="Baidu, Bing, Google, UrlList, Greedy")
    parser.add_argument("--input", default=None, help="input")
    parser.add_argument("--save_path", default=None, help="save path")
    parser.add_argument("--max_num", type=int, default=2000, help="max_num")
    parser.add_argument("--save_url", action="store_true", default=False, help="save_url")
    parser.add_argument("--single_url_file", action="store_true", default=False, help="save url to one single file")
    parser.add_argument("--appendix", type=str, default="", help="keyword appendix for search")
    parser.add_argument("--parser_threads", type=int, default=5, help="parser threads")
    parser.add_argument("--downloader_threads", type=int, default=10, help="downloader threads")
    parser.add_argument("--switch", action="store_true", default=False,
                        help="switch for second crawler")
    if not args_str:
        return parser.parse_args()
    else:
        args_list = args_str.split()
        return parser.parse_args(args_list)

class PrefixNameDownloader(ImageDownloader):

    def get_filename(self, task, default_ext):
        filename = super(PrefixNameDownloader, self).get_filename(
            task, default_ext)
        return 'prefix_' + filename

def write_url_file(url_file, winfo):
    with open(url_file, "a") as f:
        f.write(winfo)

class Md5NameDownloader(ImageDownloader):

    def get_filename(self, task, default_ext):
        url_path = urlparse(task['file_url'])[2]
        if '.' in url_path:
            extension = url_path.split('.')[-1]
            if extension.lower() not in ['jpg', 'jpeg', 'png', 'bmp', 'tiff', 'ppm', 'pgm']:
                extension = default_ext
        else:
            extension = default_ext
        # works for python 3
        filename = hashlib.md5(url_path.encode('UTF-8')).hexdigest()
        global save_url
        if save_url:
            global url_file
            winfo = task['file_url'] + "\n"
            write_url_file(url_file, winfo)
        return '{}.{}'.format(filename, extension)

class UrlAppendixNameDownloader(ImageDownloader):

    def get_filename(self, task, default_ext):
        url_path = urlparse(task['file_url'])[2]
        if '.' in url_path:
            extension = url_path.split('.')[-1]
            if extension.lower() not in ['jpg', 'jpeg', 'png', 'bmp', 'tiff', 'ppm', 'pgm']:
                extension = default_ext
        else:
            extension = default_ext
        # works for python 3
        #filename = hashlib.md5(url_path.encode('UTF-8')).hexdigest()
        filename = url_path.split('/')[-1].split('.')[0].strip()
        global save_url
        if save_url:
            global url_file
            winfo = task['file_url'] + "\n"
            write_url_file(url_file, winfo)
        return '{}.{}'.format(filename, extension)

class Base64NameDownloader(ImageDownloader):

    def get_filename(self, task, default_ext):
        url_path = urlparse(task['file_url'])[2]
        if '.' in url_path:
            extension = url_path.split('.')[-1]
            if extension.lower() not in ['jpg', 'jpeg', 'png', 'bmp', 'tiff', 'ppm', 'pgm']:
                extension = default_ext
        else:
            extension = default_ext
        # works for python 3
        filename = base64.b64encode(url_path.encode()).decode()
        global save_url
        if save_url:
            global url_file
            winfo = task['file_url'] + "\n"
            write_url_file(url_file, winfo)
        return '{}.{}'.format(filename, extension)

class UrlNameDownloader(ImageDownloader):

    def get_filename(self, task, default_ext):
        url_path = urlparse(task['file_url'])[2]
        if '.' in url_path:
            extension = url_path.split('.')[-1]
            if extension.lower() not in ['jpg', 'jpeg', 'png', 'bmp', 'tiff', 'ppm', 'pgm']:
                extension = default_ext
        else:
            extension = default_ext
        # works for python 3
        filename = url_path
        global save_url
        if save_url:
            global url_file
            winfo = task['file_url'] + "\n"
            write_url_file(url_file, winfo)
        return '{}.{}'.format(filename, extension)
# ref: https://www.jianshu.com/p/839fb07a7aac
def get_registered_func():
    registered_func = {}
    registered_func["Baidu"] = "BaiduImageCrawler"
    registered_func["Bing"] = "BingImageCrawler"
    registered_func["Google"] = "GoogleImageCrawler"
    registered_func["UrlList"] = "UrlListCrawler"
    registered_func["Greedy"] = "GreedyImageCrawler"
    return registered_func

#图片爬虫
def image_crawler(args, keyword, func):
    save_path = os.path.join(args.save_path, keyword)
    storage = {'root_dir': save_path}
    crawler = eval(func)(downloader_cls=Md5NameDownloader,
                               parser_threads=args.parser_threads,
                               downloader_threads=args.downloader_threads,
                               storage=storage)
    crawler.crawl(keyword=keyword + ' ' + args.appendix, max_num=args.max_num)

def crawl_image_from_search_engine(args):
    '''
    crawl image from Baidu or Bing or Google
    '''
    infile = args.input
    with open(infile, "r") as f:
        print("\033[32m")
        for line in tqdm(f.readlines()):
            keyword = line.strip('\n').rstrip()
            if 'negtive' in keyword:
                continue
            if args.switch:
                keyword_savepath = os.path.join(args.save_path, '..', keyword)
                if os.path.exists(keyword_savepath):
                    print('omitting[{}]'.format(keyword_savepath))
                    continue
            global url_file
            url_file = os.path.join(args.save_path, keyword + ".txt")
            if args.single_url_file:
                project_name = args.save_path.split('/')[1]
                url_file = os.path.join(args.save_path, project_name + ".txt")
            print("\033[32mcrawling image with keyword [{}]\033[37m".format(keyword))
            if args.type in registered_func.keys():
                func = registered_func[args.type]
                print("\033[41mcrawl image from [{}]\033[40m".format(func))
                image_crawler(args, keyword, func)
            else:
                print("\033[32mnot support search engine [{}]\033[37m".format(args.type))

            print("\033[32m")

def get_file_list(source_input):
    file_list = []
    if os.path.isfile(source_input):
        file_list.append(source_input)
    elif os.path.isdir(source_input):
        for root, dirs, files in os.walk(source_input):
            if len(files) > 0:
                for per_file in files:
                    if per_file.find(".txt") != -1:
                        file_list.append(os.path.join(root, per_file))
    return file_list

def crawl_image_from_urllist(args):
    infile = args.input
    print(infile)
    file_list = get_file_list(infile)
    print(len(file_list))
    for per_file in file_list:
        #keyword = os.path.splitext(os.path.basename(per_file))[0]
        #global url_file
        #url_file = os.path.join(args.save_path, keyword + ".txt")
        #print("\033[32mcrawling image with keyword [{}]\033[37m".format(keyword))
        #save_path = os.path.join(args.save_path, keyword)
        save_path = os.path.abspath(args.save_path)
        storage = {'root_dir': save_path}
        urllist_crawler = UrlListCrawler(downloader_cls=UrlAppendixNameDownloader,
                                         downloader_threads=args.downloader_threads,
                                         storage=storage)
        #输入url的txt文件
        urllist_crawler.crawl(url_list = per_file,
                                max_num = args.max_num)

def crawl_image_greedy(args):
    storage = {'root_dir': args.save_path}
    global url_file
    url_file = os.path.join(args.save_path, args.input + ".txt")
    #greedy_crawler = GreedyImageCrawler(downloader_cls=Base64NameDownloader,
    greedy_crawler = GreedyImageCrawler(
                                        downloader_threads=args.downloader_threads,
                                        storage=storage)

    greedy_crawler.crawl(domains=args.input,
                         max_num=args.max_num)

if __name__ == "__main__":
    sys.exit(0)
    args_str = "--type Baidu \
                --input media_punish_type.txt \
                --save_path data \
                --save_url "
    args_str = "--type UrlList \
                --input data/tanchuang_jiaojie.txt \
                --save_path data/tanchuang_jiaojie"
    registered_func = get_registered_func()
    args = parse_cmd(args_str)
    global save_url
    save_url = args.save_url
    print(args)
    if not os.path.exists(args.save_path):
        os.makedirs(args.save_path, exist_ok=True)
    if args.type == "UrlList":
        crawl_image_from_urllist(args)
    elif args.type == "Greedy":
        crawl_image_greedy(args)
    else:
        crawl_image_from_search_engine(args)
