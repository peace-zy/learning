import os
import tqdm

def replace_path(ipath):
    if "\\" in ipath:
        isystem = "windows"
        ipath = ipath.replace("\\\\", "/")
    elif '/' in ipath:
        isystem = 'linux'

    istrs = {"linux": "v_yangjianbo/Desktop/data1",
             "windows": "D:/待完成任务/data2"}

    ostrs = {"linux": "liuxing07/Downloads/data",
             "windows": "/Users/liuxing07/Downloads/data"}

    opath = ipath.replace(istrs[isystem], ostrs[isystem])
    return opath

def check_output(mode="json"):
    dir_path = os.path.expanduser("~/biaozhuxinxi-final/")
    class_names = os.listdir(dir_path)
    for class_name in tqdm.tqdm(class_names):
        name_ipath = os.path.join(dir_path, class_name, mode, "outputs")
        for perfile in os.listdir(name_ipath):
            oresult = ""
            perfile = os.path.join(name_ipath, perfile)
            with open(perfile, encoding='utf-8') as fin:
                try:
                    oresult = replace_path(fin.read())
                except Exception as e:
                    print(perfile)
                    raise e
            name_opath = perfile.replace("final", "final-done")
            os.makedirs(os.path.dirname(name_opath), exist_ok=True)
            with open(name_opath, 'w', encoding="utf-8") as fout:
                fout.write(oresult)
def main():
    check_output()

if __name__ == "__main__":
    main()
