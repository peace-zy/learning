#!/usr/bin/env python3
"""
author:     liuxing07@baidu.com
description:    从多模态的图搜数据中拿去图片以及相似向量特征
"""
#coding:utf-8

import os
import sys
import tqdm
import base64

_curpath = os.path.dirname(os.path.realpath(__file__))

image_save_path = os.path.join(_curpath, 'tusou_image/images')
csids_old = set()
csids_new = set()

image_csid_file = os.path.join(image_save_path, '..', 'image_csids.txt')
csids_old.update([i.strip('\n') for i in open(image_csid_file).readlines()])


def get_image_from_hadoop():
    """
    从多模态的图搜数据中拿去图片
    """
    for line in tqdm.tqdm(sys.stdin):
        try:
            csid, imageb64 = line.strip('\n').split('\t')[:2]
            if csid in csids_old:
                continue
            if csid in csids_new:
                continue

            image_file_name = os.path.join(image_save_path, csid + '.jpg')
            with open(image_file_name, 'wb') as fout:
                fout.write(base64.b64decode(imageb64))

            csids_new.add(csid)
        except:
            continue


def main():
    """
    main function
    """
    get_image_from_hadoop()
    results = ["http://10.12.184.89:8080/tusou_images/images/" + i + '.jpg\n' for i in csids_new]
    with open(os.path.join(image_save_path, '..', 'image_urls.txt'), 'a+', encoding='utf-8') as fout:
        fout.writelines(results)

    with open(image_csid_file, 'a+', encoding='utf-8') as fout:
        fout.writelines(["{}\n".format(i) for i in csids_new])

    pass

if __name__ == '__main__':
    main()
