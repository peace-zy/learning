#!/usr/bin/env python3
#coding:UTF-8

import os
import sys
import requests
import time
import traceback
import base64
import tqdm
import json
import pretty_errors
import collections
import random
import tqdm
import itertools

if sys.version_info >= (3, 2):
    from concurrent import futures
else:
    raise RuntimeError('concurrent.future must be with pyton version higher than python3.2')

assert sys.version_info >= (3, 6), 'f-string character must be with python3.6 or higher!'

IMG_EXT = ['jpg', 'png', 'bmp', 'jpeg']

TAG_SERVER_ONLINE_BNS = "group.opera-tagserveronline-tagserver2-000-sz.FENGKONG.all"

_curpath = os.path.dirname(os.path.abspath(__file__))


def get_bns_addrs(bns):
    """
    get server addresses and port of this bns
    """
    tagserver_query = "http://{}/ImageQueryTagService/query"
    server_port_status = os.popen('get_instance_by_service -i -p -s {}'.format(bns)).readlines()
    server_port_status = [addr.strip().split(' ') for addr in server_port_status]
    server_ip_port = ['{}:{}'.format(item[1], item[2]) for item in server_port_status if item[-1] == '0']
    server_query_addr = [tagserver_query.format(item) for item in server_ip_port]
    return server_query_addr


def list_groups(init_list, children_list_len=None, children_list_num=None):
    """
    spplit list to sublists
    init_list:          original list
    children_list_len:  length of sublist
    children_list_num:  number of sublist
    """
    if children_list_num is not None:
        if len(init_list) % children_list_num == 0:
            children_list_len = int(len(init_list) // children_list_num)
        else:
            children_list_len = int(len(init_list) // (children_list_num - 1))
    if children_list_len == 0:
        return init_list
    list_of_groups = zip(*(iter(init_list),) *children_list_len)
    end_list = [list(i) for i in list_of_groups]
    count = len(init_list) % children_list_len
    end_list.append(init_list[-count:]) if count != 0 else end_list
    return end_list


def file2b64(filepath):
    """
    image file to base64
    """
    if filepath.startswith("http"):
        b64_data = base64.b64encode(requests.get(filepath).content)
    else:
        with open(filepath, 'rb') as fin:
            b64_data = base64.b64encode(fin.read())
    return b64_data.decode('UTF-8')


def make_request(imgurl=None, imgb64=None, tagpaths=[], item_count=1):
    """
    generate parameters for tagserver request
    """
    logid = int(time.time() * 1e6)
    param = {"logid": logid, "items": []}
    for idx in range(0, item_count):
        item = {"id": idx, "userid": 0, "biz_src_id": 1, "is_deliver": True, "tag_paths": []}
        item["tag_paths"].extend(tagpaths)
        if (imgurl is None and imgb64 is None):
            raise Exception("imgurl and imgb64 are None at the same time")
        if imgurl is not None:
            item["req_url"] = imgurl
        if (imgb64 is not None):
            item["req_cont"] = imgb64
            item["is_req_cont_base64"] = True
        param["items"].append(item)
    return param


def get_request(content=None, tagpaths=[], mode='IMAGE_DATA_TYPE_B64'):
    """
    content: image data in
    mode   : image data in type including three types
             1: IMAGE_DATA_TYPE_B64 (content = imgb64_data)
             2: IMAGE_DATA_TYPE_BIN (content = imgfile absolute path)
             3: IMAGE_DATA_TYPE_URL (content = url)
    """
    if mode == "IMAGE_DATA_TYPE_B64":
        return make_request(imgb64 = content, tagpaths=tagpaths)
    elif mode == "IMAGE_DATA_TYPE_BIN":
        with open(content, 'rb') as fin:
            imgb64_data = base64.b64encode(fin.read()).decode('UTF-8')
        return make_request(imgb64 = imgb64_data, tagpaths=tagpaths)
    elif mode == "IMAGE_DATA_TYPE_URL":
        assert content.startswith('http'), 'url must be startwith http!'
        return make_request(imgurl = content, tagpaths=tagpaths)
    else:
        print('content image data type is not supported!')
        return None


def get_taginfo_by_tagpath(image_tag, tag_paths):
    """
    parse taginfo by tagpath
    """
    tagpath_results = []
    for tagpath in tag_paths:
        tagpath_names = tagpath.strip().split('.')
        result = ''
        taginfo = image_tag
        for ik, tagpath_name in enumerate(tagpath_names, 1):
            if not tagpath_name in taginfo:
                continue
            if ik == len(tagpath_names):
                if isinstance(taginfo[tagpath_name], list):
                    result = taginfo[tagpath_name][0]
                    if "name" not in result:
                        result["name"] = tagpath_names[1]
                elif isinstance(taginfo[tagpath_name], float):
                    result = f'{tagpath_names[1]}:{taginfo[tagpath_name]:.5f}'
                elif isinstance(taginfo[tagpath_name], str):
                    result = f'{tagpath_names[1]}:{taginfo[tagpath_name]}'
                else:
                    result = '{}:{}'.format(tagpath_names[1], taginfo[tagpath_name])
                if isinstance(result, dict):
                    result = json.dumps(result, ensure_ascii=False, separators=(',', ':'))
                break
            taginfo = taginfo[tagpath_name]
        result = result.replace('\t', ';').replace('|', ';')
        tagpath_results.append(result)
    assert len(tagpath_results) == len(tag_paths), 'tagpaths results is not according to tagpaths'
    return '|'.join(tagpath_results)


def post_process_model(response, tagpaths_map):
    """
    post_process_model
    """
    response.encoding = "GBK"
    newtagpaths = [f'{tagpath}.{key}' for key, value in tagpaths_map.items() for tagpath in value]
    if response.status_code == requests.codes.ok:
        tag_json = json.loads(response.text, encoding="GBK")
        if not tag_json['res_status'] == 0:
            result = ""
        image_taginfo = tag_json['items'][0]['image_taginfo']
        result = get_taginfo_by_tagpath(image_taginfo, newtagpaths)
    else:
        result = ''
    return result

def single_query_tagserver(image_path, tagpaths, server_addr, timeout=10):
    """
    single process for query
    """
    imgb64 = file2b64(image_path)
    param = get_request(content=imgb64, tagpaths=tagpaths, mode='IMAGE_DATA_TYPE_B64')
    response = requests.post(server_addr, json=param, timeout=timeout)
    response.encoding = "GBK"
    return response


def base_worker(line_info, tagpaths_map, server_addr, timeout=10, parse=True):
    """
    base worker for multiprocess
    """
    image_path = line_info.split('\t')[-1]
    tagpaths = [tag for tagpath in tagpaths_map.keys() for tag in tagpath]
    response = single_query_tagserver(image_path, tagpaths, server_addr)
    parse = int(sys.argv[-2])
    if not parse:
        if response.status_code == requests.codes.ok:
            return response.text
        else:
            return ''
    return post_process_model(response, tagpaths_map)


def thread_worker(ttasks, tagpaths_map, server_addr, tworker_num=5, timeout=10):
    """
    thread worker for multiprocessing
    """
    with futures.ThreadPoolExecutor(max_workers=tworker_num) as t_executor:
        for ttask in tqdm.tqdm(ttasks):
            task_future = t_executor.submit(base_worker, ttask, tagpaths_map, server_addr, timeout)
            task_future.arg = {'task_info': ttask}
            task_future.add_done_callback(call_back)


def process_worker(ptasks, tagpaths_map, server_addrs, pworker_num=1, tworker_num=10):
    """
    process worker for multiprocessing
    """
    if pworker_num is None:
        pworker_num = os.cpu_count() or 1
    if len(ptasks) < pworker_num:
        pworker_num = len(ptasks)
    tasks_lists = list_groups(ptasks, children_list_num=pworker_num)
    p_executor = futures.ProcessPoolExecutor(max_workers=pworker_num)
    task_futures = [p_executor.submit(thread_worker, ptask, tagpaths_map,
                                      random.choice(server_addrs), tworker_num) for ptask in tasks_lists]
    p_executor.shutdown(wait=True)



def call_back(future):
    """
    call_back function for multiprocessing
    """
    task_info = future.arg['task_info']
    if future.cancelled():
        print('process failed! cancelled! [{}]'.format(future.arg))
    elif future.done():
        error = future.exception()
        if error:
            print('process failed! [{}] return error:{}'.format(future.arg, error))
        else:
            fresult = future.result()
            result = task_info + '\t' + fresult
            fout_file = sys.argv[-1]
            with open(fout_file, 'a+', encoding='UTF-8') as fout:
                fout.write('{}\n'.format(result))


def multi_query(image_path_file, tagpaths_map, server_addrs, process_num=2, thread_num=10):
    """
    multi_query main function
    """
    fin = open(image_path_file, encoding='utf-8')
    hint_size = 50 * 1024 * 1024
    while True:
        input_data = [item.strip() for item in fin.readlines(hint_size)]
        if len(input_data) <= 0:
            break
        process_worker(input_data, tagpaths_map, server_addrs, process_num, thread_num)
    fin.close()


def main():
    """
    main function
    """

    print(sys.argv)
    server_addrs = get_bns_addrs(TAG_SERVER_ONLINE_BNS)


    # map key=array:处理proto中EntityArray标签数据
    # map key=content:处理proto中String，Float类型标签数据
    tagpaths_map = collections.defaultdict(list)

    array_tagpaths = ['idl_tag.idl_nsz', 'idl_tag.watermark']
    content_tagpaths = ['xvision_tag.gpu_web_ocr_text']

    tagpaths_map['array'].extend(array_tagpaths)
    tagpaths_map['content'].extend(content_tagpaths)


    if len(sys.argv) <= 1 :
        msg = f'script usage:\n \
                \timage file:\t[python {sys.argv[0]} path_to_image] \
                \timage  url:\t[python {sys.argv[0]}] "url_to_image" \
                \tfile contains image address:\t[python {sys.argv[0]} path_to_file]'
        print(msg)
    elif len(sys.argv) == 2:
        image_path = sys.argv[1].strip()
        if image_path.startswith('http') or image_path.split('.')[-1].lower() in IMG_EXT:
            response = single_query_tagserver(image_path,
                                              list(itertools.chain(*tagpaths_map.values())),
                                              random.choice(server_addrs))
            result = post_process_model(response, tagpaths_map)
            print(result)
        else:
            fout_file = os.path.abspath(image_path) + '.taginfos'

            # wether to parse taginfo: True=1,False=0
            parse_flag = 1
            sys.argv.append(parse_flag)
            sys.argv.append(fout_file)
            print(sys.argv)

            multi_query(image_path, tagpaths_map, server_addrs, process_num=2, thread_num=10)



if __name__ == '__main__':
    filein = '/home/users/liuxing07/ssd3/data/data_fengkong/fengkong_feeds_image_url_20210501_20210512.txt.sample100K.tmp'
    filein = 'https://feed-image.baidu.com/0/pic/99957bfbc9288e0747912dd50831f068.jpg'
    sys.argv.append(filein)
    main()
else:
    print(f"import module [{os.path.join(_curpath, __name__)}] success!")

