#!/bin/bash

export JAVA_HOME=/ssd3/huxu/java/jdk-11.0.13/
export NEO4J_HOME=/ssd3/huxu/neo4j-chs/neo4j-chs-community-4.3.7-unix/
export PATH=/ssd3/huxu/java/jdk-11.0.13/bin:$PATH

PYTHON_PATH=/home/users/huxu01/.jumbo/bin/python3
SCRIPT_PATH=/ssd3/huxu/neo4j-chs/knowledge_graph.py
NEO_BIN=$NEO4J_HOME/bin/neo4j
IMPORT_BIN=$NEO4J_HOME/bin/neo4j-admin

function remove_database() {
    echo "********** removing existing database **********"
    DATABASE_DIR=$NEO4J_HOME/data/databases/neo4j/
    TRANS_DIR=$NEO4J_HOME/data/transactions/neo4j/

    $NEO_BIN stop

    if [ -d "$DATABASE_DIR" ]; then
        rm -rf $DATABASE_DIR
    fi
    if [ -d "$TRANS_DIR" ]; then
        rm -rf $TRANS_DIR
    fi
}

function parse_excel() {
    for each in $@; do
        if [ ! -f "$each" ]; then
            echo "$1 does not exist!"
            exit 1
        fi
    done

    echo "********** parsing excel files **********"
    for each in $@; do
        if [[ $each =~ "低俗" ]]; then
            trade_num=6
        else
            trade_num=1
        fi
        $PYTHON_PATH $SCRIPT_PATH --input $each --trade $trade_num
    done
}

function import_database() {
    nodes=""
    for each in $@; do
        file=${each%.*}_nodefiles/import_node.data
        if [ -f "$file" ]; then
            nodes="$nodes $(cat $file)"
        else
            echo "$file dose not exist!"
        fi
    done

    echo "********** importing new database **********"
    $IMPORT_BIN import --database=neo4j $nodes
}

function start_neo4j() {
    echo "********** starting neo4j client **********"
    $NEO_BIN start
}

function main() {
    remove_database
    parse_excel $@
    if [ $? -eq 0 ]; then
        import_database $@
        start_neo4j
    fi
    echo "********** IMPORT COMPLETED **********"
}

main $@