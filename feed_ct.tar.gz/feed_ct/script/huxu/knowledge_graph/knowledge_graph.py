# !/usr/bin/env python3
'''
知识库excel 可视化解析脚本
'''
from py2neo import Graph, Node, Relationship, ogm
import pandas as pd
import uuid
import os
import argparse
from tqdm import tqdm

parser = argparse.ArgumentParser(description='knowledge graph visualization')
parser.add_argument('--input', default='', help='输入 excel 文件路径')
parser.add_argument('--trade', type=int, default=1, help='行业分类数量，默认无')
parser.add_argument('--title', default='知识库', help='知识库标题')
# parser.add_argument('--neopath', default='/ssd3/huxu/neo4j-chs/neo4j-chs-community-4.3.7-unix/bin/neo4j-admin', 
#                     help='neo4j 数据库路径')
parser.add_argument('--l1', default='一级标签', help='知识库一级标签名称')
parser.add_argument('--l2', default='二级标签', help='知识库二级标签名称')
parser.add_argument('--l3', default='三级标签', help='知识库三级标签名称')
args = parser.parse_args()


# class Movie(Model):
#     __primarylabel__ = 'Movie'
#     __primarykey__ = 'title'

#     title = Property()
#     tag_line = Property()
#     release = Property()
#     restricted = Label()

#     actors = RelatedFrom("Person", "ACTED_IN")
#     directors = RelatedFrom("Person", "DIRECTED")
#     producers = RelatedFrom("Person", "PRODUCED")

# class Person(Model):
#     __primarykey__ = 'name'

#     name = Property()
#     acted_in = RelatedTo(Movie)

class Politic_Graph():
    """
    python 接口操作neo数据库
    """
    def __init__(self):
        """
        init
        """
        self.graph = Graph(
            "http://10.255.120.17:8070",
            user = "neo4j",
            password = "qwerty"
            )

    def clear(self):
        """
        清空数据
        """
        self.graph.delete_all()

    def create_node(self):
        """
        创建节点
        """
        tx = self.graph.begin()
        worker_1 = {"name": "allen", "age":13, "company": "google inc"}
        worker_2 = {"name": "john", "age": 24, "company": "microsoft inc"}
        node_1 = Node("WORKER", **worker_1)
        node_2 = Node("WORKER", **worker_2)
        rel_1_2 = Relationship(node_1, "CO_WORKER", node_2)
        tx.merge(node_1)
        tx.merge(node_2)
        tx.merge(rel_1_2)
        tx.commit()
        
    def create_nodes(self):
        """
        批量创建节点
        """
        tx = self.graph.begin()
        # in loop mode
        worker_list = [
            {"name": "allen", "age": 13, "company": "google inc"},
            {"name": "john", "age": 24, "company": "microsoft inc"}
        ]
        for worker in worker_list:
            node = Node("WORKER", **worker)
            tx.merge(node)
        node1 = Node(name="allen")
        node2 = Node(name="john")
        rel = Relationship(node1, "CO_WORKER", node2)
        tx.merge(rel)
        tx.commit()

class Excel2Csv():
    """
    解析数据库的 excel 文件，转换成适合导入 neo4j 的 csv 格式
    """
    def __init__(self, excel_path, db_name='知识库', 
                #  neo_path, 
                 l1='一级标签', l2='二级标签', l3='三级标签'):
        """
        init
        """
        if not excel_path:
            raise IOError('empty input excel')
        if not os.path.exists(excel_path):
            raise IOError('invalid input excel path')
        self.excel_path = os.path.abspath(excel_path)
        self.save_path = os.path.splitext(self.excel_path)[0] + '_nodefiles'
        if not os.path.exists(self.save_path):
            os.makedirs(self.save_path)
        # self.neo_path = neo_path
        self.db_name = db_name
        self.db_id = self._create_uid()
        self.l1 = l1
        self.l2 = l2
        self.l3 = l3
        self.import_file = os.path.join(self.save_path, 'import_node.data')

        self._remove_node_csv()
        self._save_title()

    def _remove_node_csv(self):
        """
        移除旧的节点及关系文件
        """
        for each in os.listdir(self.save_path):
            if each.endswith('node') or each.endswith('attr') or each.endswith('rlat'):
                os.remove(os.path.join(self.save_path, each))

    def make_import_file(self):
        """
        生成包含所有节点及关系的导入文件
        """
        with open(self.import_file, 'w') as f:
            # w_lines = ['{} import --database=neo4j'.format(self.neo_path)]
            w_lines = []
            for each in os.listdir(self.save_path):
                if each.endswith('node') or each.endswith('attr'):
                    w_lines.append('--nodes=%s' % os.path.join(self.save_path, each))
                elif each.endswith('rlat'):
                    w_lines.append('--relationships=%s' % os.path.join(self.save_path, each))
            f.write(' '.join(w_lines))

    @staticmethod
    def _create_uid():
        """
        生成 uid
        """
        return str(uuid.uuid1())

    def _save_csv(self, df, save_name, mode='node'):
        """
        保存 DataFrame 为 csv 文件
        """
        save_name = '{}.{}'.format(save_name, mode)
        file_path = os.path.join(self.save_path, save_name)
        df.to_csv(file_path, index=False)
    
    @staticmethod
    def remove_illegal_char(strings):
        if type(strings) is str:
            strings = strings.replace('\n', '_')
            return strings
    
    @classmethod
    def preprocess(cls, data):
        for key, df in data.items():
            data[key] = df.applymap(cls.remove_illegal_char)
        
        return data

    def _save_title(self):
        """
        保存包含知识图谱标题的 node 文件
        """
        node_data = pd.DataFrame([[self.db_id, self.db_name, '数据库标题']],
                                 columns=['标签_id:ID', '标签名称', '层级:LABEL'])
        self._save_csv(node_data, self.db_name, 'node')

    def parse_data(self, trade):
        """
        解析知识库（可分行业）
        """
        excel_data = pd.read_excel(self.excel_path, sheet_name=None)
        excel_data = self.preprocess(excel_data)
        sheets = list(excel_data.keys())
        sheet_names = sheets[trade:]

        if trade == 1:
            ctlg_name = sheets[0]
            l2_id_dict = self.parse_ctlg_sheet(excel_data[ctlg_name], ctlg_name)
            for sheet_name in tqdm(sheet_names, desc=f'文件\t{self.excel_path}\t处理进度'):
                self.parse_data_sheet(excel_data[sheet_name], sheet_name, ctlg_name, l2_id_dict)
        else:
            ctlg_names = sheets[:trade]
            l2_dict = {}
            for ctlg_name in ctlg_names:
                l2_dict[ctlg_name] = self.parse_ctlg_sheet(excel_data[ctlg_name], ctlg_name)
            for sheet_name in tqdm(sheet_names, desc=f'文件\t{self.excel_path}\t处理进度'):
                ctlg_name = sheet_name.split('_')[0]
                l2_id_dict = l2_dict[ctlg_name]
                self.parse_data_sheet(excel_data[sheet_name], sheet_name, ctlg_name, l2_id_dict)

    def _build_label_dict(self, label_data, label_name, id_dict, node_data, rlat_data):
        """
        生成对应上级标签的 label_dict
        """
        label_dict = dict.fromkeys(pd.DataFrame(label_data.groupby(label_name))[0])
        for label in label_dict.keys():
            label_dict[label] = self._create_uid()
        # 后续可以改成根据DF 来扩充的形式
        for label, label_id in label_dict.items():
            tmp_node = pd.Series([label_id, label, label_name], index=node_data.columns)
            node_data = node_data.append(tmp_node, ignore_index=True)
            tmp_rlat = pd.Series([id_dict[label], label_id, label_name], index=rlat_data.columns)
            rlat_data = rlat_data.append(tmp_rlat, ignore_index=True)
        
        return label_dict, node_data, rlat_data

    def parse_ctlg_sheet(self, ctlg_data, ctlg_name):
        """
        解析 excel 文件中的目录sheet
        """
        ctlg_data = ctlg_data.dropna(how='all').fillna(method='ffill')

        db_id = self._create_uid()
        node_data = pd.DataFrame([[db_id, ctlg_name, '行业分类']], columns=[
                                    '标签_id:ID({})'.format(ctlg_name), '标签名称', '层级:LABEL'])
        rlat_data = pd.DataFrame(columns=[':START_ID({})'.format(
            ctlg_name), ':END_ID({})'.format(ctlg_name), ':TYPE'])

        trade_rlat_data = pd.DataFrame([[self.db_id, db_id, '行业']], columns=[
                                        ':START_ID', ':END_ID({})'.format(ctlg_name), ':TYPE'])
        save_trade_name = '{}_trade'.format(ctlg_name)
        self._save_csv(trade_rlat_data, save_trade_name, mode='rlat')

        l1_to_l0_id = dict.fromkeys(pd.DataFrame(ctlg_data.groupby(self.l1))[0], db_id)
        l1_id_dict, node_data, rlat_data = self._build_label_dict(label_data=ctlg_data, label_name=self.l1, 
                                                id_dict=l1_to_l0_id, node_data=node_data, rlat_data=rlat_data)

        l2_to_l1 = ctlg_data.set_index(self.l2)[self.l1].to_dict()
        l2_to_l1_id = {}
        for each_key in l2_to_l1.keys():
            l2_to_l1_id[each_key] = l1_id_dict[l2_to_l1[each_key]]
        l2_id_dict, node_data, rlat_data = self._build_label_dict(label_data=ctlg_data, label_name=self.l2, 
                                                id_dict=l2_to_l1_id, node_data=node_data, rlat_data=rlat_data)

        self._save_csv(node_data, ctlg_name, 'node')
        self._save_csv(rlat_data, ctlg_name, 'rlat')
        return l2_id_dict

    def parse_data_sheet(self, sheet_data, sheet_name, ctlg_name, l2_id_dict):
        """
        解析 excel 文件中的数据 sheet
        """
        sheet_data = sheet_data.dropna(axis=1, how='all')
        sheet_data = sheet_data.dropna(axis=0, subset=[sheet_data.columns[0]])
        id_name = '{}_id:ID({})'.format(sheet_name, ctlg_name)

        node_id_dict = sheet_data.set_index(self.l3)[self.l2].to_dict()
        node_to_l2_id = {}
        for key in node_id_dict.keys():
            node_to_l2_id[key] = l2_id_dict[node_id_dict[key]]
            node_id_dict[key] = self._create_uid()

        for each_key in sheet_data.columns:
            if '图片' in each_key:
                sheet_data.rename(columns={each_key:'image'}, inplace=True)
                break
        attrs = list(sheet_data.columns)

        # 保存实体 node
        sheet_data.insert(0, id_name, [node_id_dict[i] for i in sheet_data[self.l3]])
        entity_name = sheet_name.split('_')[-1]
        sheet_data.loc[:, ':LABEL'] = [entity_name] * sheet_data.shape[0]
        self._save_csv(sheet_data, sheet_name, 'node')
        # 保存 node 连接至目录的关系
        self._save_rlat(sheet_data, id_name, self.l3, node_to_l2_id, ctlg_name, sheet_name, is_attr=False)

        #（略过 image 标签，将作为条目的头像显示）
        if 'image' in attrs:
            attrs.remove('image')

        # 分别保存每个属性,和对应关系为 csv, （略过一二三级标签，因为已经连接完毕） 
        for attr_name in attrs[3:]:
            # 提取属性类别
            attr_col = pd.DataFrame(sheet_data.groupby(attr_name))[0]
            attr_name_id = '{}_id:ID({})'.format(attr_name, ctlg_name)
            attr_name_id_col = [self._create_uid() for i in range(attr_col.shape[0])]
            node_label = attr_name.split('_')[-1]
            node_label_col = [node_label] * attr_col.shape[0]
            attr_label = '{}_{}'.format(sheet_name, attr_name)
            attr_data = pd.DataFrame({attr_name_id:attr_name_id_col, attr_name:attr_col, ':LABEL':node_label_col})
            self._save_csv(attr_data, attr_label, 'attr')

            # 生成关系
            attr2id_dict = attr_data.set_index(attr_name)[attr_name_id].to_dict()
            self._save_rlat(sheet_data, id_name, attr_name, attr2id_dict, ctlg_name, sheet_name, is_attr=True)

    def _save_rlat(self, rlat_data, id_name, label_name, id_dict, ctlg_name, sheet_name, is_attr=False):
        """
        保存DataFrame 中的关系为 csv 文件
        """
        rlat_data = rlat_data[[id_name, label_name]]
        rlat_data = rlat_data.dropna(subset=[label_name])
        rlat_data.loc[:, ':END_ID({})'.format(ctlg_name)] = [id_dict[i] if i else None for i in rlat_data[label_name]]
        rlat_data.loc[:, ':TYPE'] = [label_name] * rlat_data.shape[0]
        # 不改变关系的方向
        # rename_dict = {id_name:':START_ID({})'.format(ctlg_name)}
        # rlat_data.rename(columns=rename_dict, inplace=True)

        # 改变关系的箭头方向
        if is_attr:
            rename_dict = {id_name:':START_ID({})'.format(ctlg_name)}
        else:
            rename_dict = {':END_ID({})'.format(ctlg_name):':START_ID({})'.format(
                ctlg_name), id_name:':END_ID({})'.format(ctlg_name)}
        rlat_data.rename(columns=rename_dict, inplace=True)

        del rlat_data[label_name]
        save_name = '{}_{}'.format(sheet_name, label_name)
        self._save_csv(rlat_data, save_name, 'rlat')

if __name__ == '__main__':
    if args.input:
        # e2c = Excel2Csv(args.input, args.neopath, db_name=args.title)
        e2c = Excel2Csv(args.input, db_name=args.title)
        e2c.parse_data(trade=args.trade)
        e2c.make_import_file()
    else:
        parser.print_help()
