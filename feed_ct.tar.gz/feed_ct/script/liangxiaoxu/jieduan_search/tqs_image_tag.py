#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Author:   liangxiaoxu@baidu.com
Date  :   2020/09/14 11:35:10
Desc  :   图片样本数据入库前info 数据生成，同时推送线上标签库，保存线上key
"""
import json
import traceback
import glob
import sys
import os
import os.path
import urllib2
import glob
import base64
import random
import time
import logging
import commands
import argparse
reload(sys)
sys.setdefaultencoding('gbk')
import threading
import multiprocessing
import concurrent.futures
import concurrent
import json

class ImgInfoOnline(object):
    """
       获取线上图片key，url 信息   
    """
    def __init__(self):
        """init
        """
        self.bns_node = 'group.opera-tagserveronline-tagserver2-all-sz.FENGKONG.all'
    
    def access_tqs(self, serverurl, req_url=None, req_cont_b64=None, item_count=1):
        """ access_tqs
        """
        logid = int(time.time() * 1000)
        #print("_server_url:", serverurl, "logid:", logid)
        param = {}
        param["logid"] = logid
        param["items"] = []
        for idx in range(0, item_count):
            item = {}
            item["id"] = idx
            item["userid"] = 0
            item["biz_src_id"] = 1
            item["is_deliver"] = True
            item["tag_paths"] = []
            item["tag_paths"].append("xvision_tag.gpu_web_ocr_text")
            item["tag_paths"].append("xvision_tag.gpu_web_ocr_location")
            if (req_url is None and req_cont_b64 is None):
                raise Exception("req_url and req_cont_b64 are None at the same time")
            if (req_url is not None):
                item["req_url"] = req_url
            if (req_cont_b64 is not None):
                item["req_cont"] = req_cont_b64
                item["is_req_cont_base64"] = True
            param["items"].append(item)
        req = urllib2.Request(serverurl)
        req.add_data(json.dumps(param, encoding='GBK'))
        req.add_header("Content-Type", "application/json") #<=r31987
        st = time.time()
        f = urllib2.urlopen(req)
        difft = time.time() - st
        res_str = f.read()
        res = json.loads(res_str.encode('utf-8'))
        return res

    def _get_server_url(self):
        cmd = 'get_instance_by_service -ip %s' % self.bns_node
        (s, o) = commands.getstatusoutput(cmd)
        url = None
        if int(s) == 0:
            iparr = o.split("\n")
            final_ip_port = random.choice(iparr)
            arr = final_ip_port.split(" ")
            if len(arr) == 3:
                url = 'http://%s:%s/ImageQueryTagService/query' % (arr[1], arr[2])
            elif len(arr) == 2:
                url = 'http://%s:%s/ImageQueryTagService/query' % (arr[0], arr[1])
        #print url
        return url

    def _query_tag(self, mode, img_url):
        server_url = self._get_server_url()
        if (mode == 0 or mode == 1):
            result = self.access_tqs(server_url, req_url=img_url)
        if (mode == 2):
            with open(img_url, "rb") as fin:
                req_cont_b64 = base64.b64encode(fin.read())
            result = self.access_tqs(server_url, req_url=None, req_cont_b64=req_cont_b64)
        return result

    def unique_key_image_online(self, mode, img_path):
        """
        返回 key,url
        实际为往线上推送数据流程,   
        返回图片线上key 和标签库存储url 地址
        """
        key = -1
        try:
            result = self._query_tag(mode, img_path)
            #print result["items"][0]
            key = result["items"][0]["key"]
            http = result["items"][0]["url"]
        except Exception as e:
            logging.exception(str(e))
        return key, http

    def get_image_ocr(self, img_path):
        """
            返回 gpu_web_ocr_text.content
        """
        
        mode = 2
        if "http" in img_path:
            mode = 1
        else:
            mode = 2
        k = 0
        ocr_text = ""
        while 1:
            try:
                k += 1
                result = self._query_tag(mode, img_path.strip())
                #key = result["items"][0]["key"]
                #http = result["items"][0]["url"]
                ocr_text = result["items"][0]["image_taginfo"]["xvision_tag"]["gpu_web_ocr_text"]["content"]
                break
            except Exception as e:
                logging.exception(str(e))
                if k > 10:
                    break
        return ocr_text
    
    def get_ocr_location(self, url):
        """
            input: url
            oitput: orc_location 数据 
        """
        img_path = url.strip()
        mode = 2
        if "http" in img_path:
            mode = 1
        else:
            mode = 2
        k = 0
        ocr_location = []
        while 1:
            try:
                k += 1
                result = self._query_tag(mode, img_path.strip())
                ocr_location = {}
                xvision_tag = result["items"][0]["image_taginfo"]["xvision_tag"]
                version = xvision_tag["gpu_web_ocr_location"]["version"]
                if "array" in xvision_tag["gpu_web_ocr_location"]:
                    ocr_location = xvision_tag["gpu_web_ocr_location"]
                break
            except Exception as e:
                logging.exception(str(e))
                if k > 20:
                    break
        return ocr_location    
      
    def get_ocr_location_files(self, img_path):
        """
        批量获取ocr_location , 图片存储路径/ url列表 txt
        """
        if os.path.exists(img_path):
            files = glob.glob(img_path + "*")
        else:
            files = open(img_path).readlines()
        for f in files:
            self.get_ocr_location(f)


def parse_args():
    """解析参数"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--label", type=str, default="", help="insert data label") 
    parser.add_argument("--image_path", type=str, default="", help="data file")
    parser.add_argument("--annotation_path", type=str, default="", help="annotation_path")
    parser.add_argument("--model_tag", type=str, default="", help="model tag insert")
    parser.add_argument("--file_name", type=str, default="", help="file save text name")    
    return parser.parse_args()


def mul_thread_tag(file_path):
    """
        多线程获取标签
    """
    result = []
    obj = ImgInfoOnline()
    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
        with  open(file_path) as lines:
            for res in executor.map(obj.get_ocr_location, lines):
                result.append(res)
                print res


def read_feed_data(filename):
    """
    获取feed 数据
    """
    files = glob.glob(filename) 
    urls = {}
    for f in files:
        #print f
        for line in open(f):
            url = line.split("\t")[1]
            img_base64 =  line.split("\t")[2]
            urls[url] = img_base64
            if len(urls) >= 5000:
                urls = random.sample(urls.keys(), 200)
                urls = {}
    return urls
    
if __name__ == "__main__":    
    
    args = parse_args()
    filename = args.file_name
    obj = ImgInfoOnline()
    ocr_locs = obj.get_ocr_location(filename)
    print ocr_locs
    #for loc in ocr_locs:
    #    print loc["name"]
    #mul_thread_tag(filename)
    #urls = read_feed_data(filename)
    #print len(urls)
    
