#! / usr / bin / env python
# - * - coding: utf - 8 - * - 
"""
Author: liangxiaoxu@baidu.com
Date: 20 / 12 / 09 11: 18: 28
Desc: 
"""
import sys
import cv2
import time
import glob
import json
import os
from tqs_image_tag import ImgInfoOnline 
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import urllib
import requests
import traceback
import tqs_qianfan


def saliency_detect(img):
    """
        二值化
    """ 
    major_version = cv2.__version__.split('.')[0]
    saliency = cv2.saliency.StaticSaliencyFineGrained_create()
    (success, saliencyMap) = saliency.computeSaliency(img)
    #print (saliencyMap)
    if major_version == '4': 
        saliencyMap = (saliencyMap * 255).astype("uint8")
    elif major_version == '3': 
        saliencyMap = (saliencyMap * 1).astype("uint8")
    threshMap = cv2.threshold(saliencyMap, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
    return threshMap


def draw_min_rect_circle(img_bit, img_box): 
    """
        二值化图片进行绘画最小外接矩阵
    """
    #img_bit = cv2.Canny(img, 128, 256)
    #cnts, hierarchy = cv2.findContours(img_bit, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    major_version = cv2.__version__.split('.')[0]
    if major_version == '4' or major_version == '2': 
        cnts, hierarchy = cv2.findContours(img_bit, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    elif major_version == '3': 
        image, cnts, hierarchy = cv2.findContours(img_bit, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    temp = np.ones(img_bit.shape, np.uint8) * 255
    cv2.drawContours(temp, cnts, - 1, (0, 255, 0), cv2.FILLED) 
    cnts_list = cnts[0]
    for cnt in cnts: 
        cnts_list = np.concatenate((cnts_list, cnt), axis=0)
    rect = cv2.minAreaRect(cnts_list) # 得到最小外接矩形的（中心(x, y), (宽, 高), 旋转角度）
    min_rect = np.int0(cv2.boxPoints(rect))
    return temp, rect[2]


def hist_biaray_hsv(frame):
    """
        基于hsv的颜色划分
    """ 
    while(True): 
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        height, width, c = frame.shape
        #inRange()函数用于图像颜色分割
        edged = cv2.inRange(hsv, (0, 0, 0), (180, 255, 255))
        edged = cv2.dilate(edged, None, iterations=2)
        edged = cv2.erode(edged, None, iterations=2)
        mask_black = cv2.inRange(hsv, (0, 0, 0), (180, 255, 46))
        mask_gray = cv2.inRange(hsv, (0, 0, 46), (180, 43, 220))
        mask_white = cv2.inRange(hsv, (0, 0, 221), (180, 43, 255))
        mask_red1 = cv2.inRange(hsv, (0, 43, 46), (10, 255, 255))
        mask_orange = cv2.inRange(hsv, (11, 43, 46), (25, 255, 255))
        mask_yellow = cv2.inRange(hsv, (26, 43, 46), (34, 255, 255))
        mask_green = cv2.inRange(hsv, (35, 43, 46), (77, 255, 255))
        mask_cyan = cv2.inRange(hsv, (78, 43, 46), (99, 255, 255))
        mask_blue = cv2.inRange(hsv, (100, 43, 46), (124, 255, 255))
        mask_purple = cv2.inRange(hsv, (125, 43, 46), (155, 255, 255))
        mask_red2 = cv2.inRange(hsv, (156, 43, 46), (180, 255, 255))
        mask_red = cv2.bitwise_or(mask_red1, mask_red2)
        mask = {"green": mask_green, "blue": mask_blue, "red": mask_red, \
                "black": mask_black, "white": mask_white, "gray": mask_gray, \
                "orange": mask_orange, "purple": mask_purple, "yellow": mask_yellow, "cyan": mask_cyan}
        hsv_list = {}
        hsv_top = {}
        max_rate = 0.0
        max_key = ""
        all_rate = 0
        for key, value in mask.items(): 
            rate = float(value.sum()) / 255.0 / height / width
            if rate > 0.01: 
                hsv_list[key] = rate
            if rate > 0.1: 
                hsv_top[key] = rate
            all_rate += rate
        return hsv_list, hsv_top


def hist_biaray(img): 
    """
        二值化
    """
    ret1, th1 = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)
    # Otsu's thresholding
    ret2, th2 = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    # Otsu's thresholding after Gaussian filtering
    ret3, th3 = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return th3


def getVProjection(image):
    """
        文字框分割
    """ 
    vProjection = np.zeros(image.shape, np.uint8)
    #图像高与宽
    (h, w) = image.shape
    #长度与图像宽度一致的数组
    w_ = [0] * w
    h_ = [0] * h
    #循环统计每一列白色像素的个数
    for x in range(w): 
        w_[x] = float(h - np.bincount(image[:, x])[0]) / float(h)
    #绘制垂直平投影图像
    for y in range(h): 
        h_[y] = float(w - np.bincount(image[y, :])[0]) / float(w)
    return w_, h_


def is_Chinese(ch):
    """
        是否是中文字符
    """ 
    if u'\u4e00' <= ch <= u'\u9fff': 
        return True
    return False


def rect_cut_x(img_bit, img, sep=10): 
    """
        x轴方向分割
    """
    Position = []
    #水平投影
    h, w, c = img.shape
    #进行列分割并保存分割位置
    cropImg = img_bit
    #对行图像进行垂直投影
    W, H = getVProjection(cropImg)
    pos_init = {"x": -1, "y": -1, "width": -1, "height": -1}
    pos = {"x": -1, "y": -1, "width": -1, "height": -1}
    sep = 0
    for j in range(len(W)): 
        if (W[j] > 0.01) and (pos == pos_init): 
            pos["x"] = j
        if (W[j] <= 0.01 and pos != pos_init): 
            pos["width"] = j - pos['x']
        if (pos["width"] != - 1 and pos["x"] != - 1): 
            pos["height"] = h
            pos["y"] = 0
            if pos['width'] > 5: 
                Position.append(pos)
            pos = {"x": -1, "y": -1, "width": -1, "height": -1}
            if len(Position) > 1: 
                sep = Position[1]['x'] - Position[0]['x'] - Position[0]['width']
        if j == len(W) - 1 and pos != pos_init and j != pos["x"]: 
            pos["width"] = j - pos["x"]
            pos['y'] = 0 
            pos['height'] = h
            if pos['width'] > 4: 
                Position.append(pos)
    return Position, img


def rect_cut_y(img_bit, img, sep=10): 
    """
        y轴方向分割
    """
    Position = []
    h, w, c = img.shape
    #进行行分割并保存分割位置
    cropImg = img_bit
    W, H = getVProjection(cropImg)
    pos_init = {"x": -1, "y": -1, "width": -1, "height": -1}
    pos = {"x": -1, "y": -1, "width": -1, "height": -1}
    #print pos
    sep = 0
    for j in range(len(H)): 
        if (H[j] > 0) and (pos == pos_init): 
            if len(Position) > 1: 
                pass
            pos["y"] = j
        if (H[j] <= 0 and pos != pos_init and pos["y"] != -1): 
            pos["height"] = j - pos["y"]
        if (pos["height"] != -1 and pos["y"] != -1): 
            pos['x'] = 0
            pos['width'] = w
            Position.append(pos)
            pos = {"x": -1, "y": -1, "width": - 1, "height": -1}
            if len(Position) > 1: 
                sep = Position[1]['y'] - (Position[0]['y'] + Position[0]['height'])
        if j == len(H) - 1 and pos != pos_init: 
            pos["height"] = j - pos["y"]
            pos["width"] = w
            pos['x'] = 0
            Position.append(pos)
    #根据确定的位置分割字符
    return Position, img


def check_deal(img, boundary): 
    """
        截断预处理
    """
    height, width, c = img.shape
    try: 
        img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        img_hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    except: 
        print ("cvtColor error: ", img.shape)
        return 0
    height, width, c = img.shape
    #print img.shape
    img_hist_bit = hist_biaray(img_gray)
    for i in range(2): 
        rect = cv2.vconcat(img_hist_bit[0: 1, 0: width], img_hist_bit[height - 1: height, 0: width])
        back = np.argmax(np.bincount(np.array(rect).reshape(rect.shape[0] * rect.shape[1])))
        if back == 255: 
            img_hist_bit = cv2.bitwise_not(img_hist_bit)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    img_hist_bit_erode = cv2.erode(img_hist_bit, kernel)
    w_, h_ = getVProjection(img_hist_bit)
    Pos_x, img = rect_cut_x(img_hist_bit, img)
    Pos_y, img = rect_cut_y(img_hist_bit, img)
    result = {"img_hist_bit": img_hist_bit, "w_": w_, "h_": h_, "Pos_x": Pos_x, "Pos_y": Pos_y, "img": img}
    return result


def y_check(img_hist_bit, bit_h, Pos_x, Pos_y, img_cut, ocr_text, mode): 
    """
        y轴方向截断检测
    """
    # mode 0 代表最上方截断 - 1代表最下侧截断
    height, width, c = img_cut.shape
    rate_white = 0.0
    if mode == 0: 
        rect = img_hist_bit[height - 2: height, 0: width]
        rect_size = rect.shape[0] * rect.shape[1]
        rate_white = 1.0 - np.bincount(np.array(rect).reshape(rect_size))[0] / float(rect_size)
    if mode == 1: 
        rect = img_hist_bit[0: 2, 0: width]
        rect_size = rect.shape[0] * rect.shape[1]
        rate_white = 1.0 - np.bincount(np.array(rect).reshape(rect_size))[0] / float(rect_size)
    if  0.1 < rate_white < 0.8: 
        if 1: 
            width_word = []
            for  pos in Pos_x: 
                width_word.append(float(pos["width"]))
            if  1.5 < np.mean(width_word) / height < 3 and \
                    len(Pos_x) > len(ocr_text) and  1 < np.std(width_word) ** 2 < 100: 
                return 1
    return 0


def x_check(img_box, bound_x, ocr_text, mode): 
    """
        x轴方向截断检测
    """
    # mode 0 代表最左侧截断 - 1代表最右侧截断
    result_check_deal = check_deal(img_box, bound_x)
    img_hist_bit = result_check_deal["img_hist_bit"]
    bit_w = result_check_deal["w_"]
    bit_h = result_check_deal["h_"]
    Pos_x = result_check_deal["Pos_x"]
    Pos_y = result_check_deal["Pos_y"]
    img = result_check_deal["img"]
    mode_dict = {0: "x", -1: "width"}
    height, width, c = img.shape
    if mode == 0: 
        rect = img_hist_bit[0: height, 0: 2]
        rect_size = rect.shape[0] * rect.shape[1]
        rate_white = 1.0 - np.bincount(np.array(rect).reshape(rect_size))[0] / float(rect_size)
    if mode == - 1: 
        rect = img_hist_bit[0: height, width - 2: width]
        rect_size = rect.shape[0] * rect.shape[1]
        rate_white = 1.0 - np.bincount(np.array(rect).reshape(rect_size))[0] / float(rect_size)
    if mode == 0: 
        rate_white_1 = max(bit_w[: bound_x])
    if mode == - 1: 
        rate_white_1 = max(bit_w[width - bound_x:])

    if max(bit_w) == 1.0: 
        return 0  
    ret = 1
    if rate_white_1 <= 0.05 or rate_white_1 >= 0.95: 
        return 0
    width_word = []
    for  pos in Pos_x: 
        width_word.append(float(pos["width"]))
    if width * 2 < height: 
        return 0
    if float(sum(width_word)) / height > 1.5 * len(ocr_text): 
        return 0
    if float(width) / height > 2 * len(ocr_text): 
        return 0
    
    if rate_white >= 0.2 and len(Pos_x) > 1: 
        pos = Pos_x[mode]
        pos_second = Pos_x[mode * 3 + 1]
        width_word.pop(mode) 
        if len(Pos_x) == len(ocr_text)  or len(Pos_x) == len(ocr_text) + 1: 
            if pos['width'] < np.mean(width_word) * 0.75 and is_Chinese(ocr_text[mode]): 
                hsv_bian, hsv_bian_top = hist_biaray_hsv( \
                        img_box[:, max(0, pos['x'] - 1): min(pos['x'] + pos['width'] + 1, width)])
                hsv_second, hsv_second_top = hist_biaray_hsv(
                        img_box[:, max(0, pos_second['x'] - 1): min(pos_second['x'] + pos_second['width'] + 1, width)])
                if len(hsv_bian) == 1: 
                    return 0
                if len(ocr_text) == 1: 
                    return 0
                if hsv_bian_top.keys() != hsv_second_top.keys() and \
                        len(set(hsv_bian_top.keys()).intersection(set(hsv_second_top.keys()))) < 2: 
                    return 0
                return 1
        
    return 0


def read_img_from_url(url):
    """
        从url 读取图片
    """ 
    kv={'user-agent': 'Mozilla/5.0'}
    r=requests.get(url, timeout=300, headers=kv)
    r.raise_for_status()
    path = "./imgs/" + url.split('/')[-1] + '.jpg'
    if not os.path.exists(path): 
        with open(path, 'wb') as f: 
            f.write(r.content)
    return path

    
def ocr_truncature_check(args):
    """
        截断检测
    """ 
    (id_x, mode, line, aimed_path) = args
    if mode == "2": 
        obj = ImgInfoOnline()
        url = line.strip().split('\t')[3]
        #ocr_locations = obj.get_ocr_location(url)
        ocr_locations = tqs_qianfan.get_ocr_location(url)
        if len(ocr_locations) == 0: 
            return (id_x, False, line)
    try: 
        path = read_img_from_url(url)
        img_origin = cv2.imread(path)
        img = img_origin
        height, width, ch = img.shape
        img_gray = cv2.cvtColor(img_origin, cv2.COLOR_RGB2GRAY)
        roi = []
        cut_flag = 0
        ocr_locations = ocr_locations["tag_item"]
    except Exception as e: 
        print ("read img error")
        return (id_x, False, line)
    small_aimed_num = 0
    result_end = False
    
    for id, ocr_loc in enumerate(ocr_locations): 
        small_flag = 0 
        position = ocr_loc["position"]
        x = position['x']
        y = position['y']
        w = position['width']
        h = position['height']
        ocr_text = ""
        ocr_text = ocr_loc["label_content"]
        #print len(ocr_text), ocr_text, position
        pixes = 1
        if ocr_text == "": 
            continue
        bound_x = max(3, int(min(w / len(ocr_text), h) * 0.3))
        bound_y = 8
        small_th = 6
        if x <= bound_x: 
            cut_flag = 1
            img_box = img_origin[max(0, y - 1): y + h, 0: x + w]
            if (float(w) / width < 0.08 and float(h) / height < 0.08) \
                    or (h < 10 and w < 10) or float(w) / width < 0.05 or float(h) / height < 0.05: 
                small_flag = 1
            result_check_deal = check_deal(img_box, bound_x)
            img_hist_bit = result_check_deal["img_hist_bit"]
            bit_w = result_check_deal["w_"]
            bit_h = result_check_deal["h_"] 
            Pos_x = result_check_deal["Pos_x"]
            Pos_y = result_check_deal["Pos_y"]
            img_gray = result_check_deal["img"]
            
            ret = x_check(img_box, bound_x, ocr_text, 0)
            if ret and small_flag != 1: 
                ret = 0
                saliency = saliency_detect(img)
                saliency_box = saliency[max(0, y - 1): y + h, 0: x + w]
                saliency_box = saliency_box[:, Pos_x[0]['x']: Pos_x[0]['x'] + Pos_x[0]['width']]
                black_num = np.bincount(np.array(saliency_box).reshape(saliency_box.size))[0]
                rate_white = 1 - float(black_num) / saliency_box.size
                if rate_white > 0.2: 
                    ret = 1
            if ret and small_flag != 1: 
                ret = 0 
                img_bit, rect_cir = draw_min_rect_circle(img_hist_bit, img_box)
                if not -88 < rect_cir < -2: 
                    ret = 1
            if ret  and small_flag == 1: 
                small_aimed_num += 1
            if ret  and small_flag != 1: 
                result_end = True
                continue
        
        if width <= (x + w + bound_x): 
            img_box = img_origin[max(0, y - 1): y + h, x: width]
            if (float(w) / width < 0.08 and float(h) / height < 0.08)  \
                    or float(w) / width < 0.05 or float(h) / height < 0.05: 
                small_flag = 1
            result_check_deal = check_deal(img_box, bound_x)
            img_hist_bit = result_check_deal["img_hist_bit"]
            bit_w = result_check_deal["w_"]
            bit_h = result_check_deal["h_"] 
            Pos_x = result_check_deal["Pos_x"]
            Pos_y = result_check_deal["Pos_y"]
            img_cut_gray = result_check_deal["img"]
            ret = x_check(img_box, bound_x, ocr_text, - 1)
            if ret and small_flag != 1: 
                ret = 0
                saliency = saliency_detect(img)
                saliency_box = saliency[max(0, y - 1): y + h, x: width]
                saliency_box = saliency_box[:, Pos_x[0]['x']: Pos_x[0]['x'] + Pos_x[0]['width']]
                black_num = np.bincount(np.array(saliency_box).reshape(saliency_box.size))[0]
                rate_white = 1 - float(black_num) / saliency_box.size
                if rate_white > 0.2: 
                    ret = 1
            if ret and small_flag != 1: 
                ret = 0
                img_bit, rect_cir = draw_min_rect_circle(img_hist_bit, img_box)
                if not -89.0 < rect_cir < -1.0: 
                    ret = 1
            if ret  and small_flag == 1: 
                small_aimed_num += 1
            if ret  and small_flag != 1: 
                result_end = True 
                continue

        if y <= bound_y: 
            img_box = img_origin[0: y + h, x: x + w]
            img_cut = img_origin[max(0, y - bound_y): \
                    min(height, y + h + bound_y), max(0, x - bound_x): min(width, x + w)]        
            if (float(w) / width < 0.08 and float(h) / height < 0.08) \
                    or float(w) / width < 0.05 or float(h) / height < 0.05: 
                small_flag = 1
                continue
            result_check_deal = check_deal(img_box, bound_y)
            img_hist_bit = result_check_deal["img_hist_bit"]
            bit_w = result_check_deal["w_"]
            bit_h = result_check_deal["h_"] 
            Pos_x = result_check_deal["Pos_x"]
            Pos_y = result_check_deal["Pos_y"]
            img_cut = result_check_deal["img"]
            ret = y_check(img_hist_bit, bit_h, Pos_x, Pos_y, img_cut, ocr_text, 0)
            if ret  and small_flag == 1: 
                small_aimed_num += 1
            if ret  and (small_flag != 1 or small_aimed_num >= small_th): 
                result_end = True 
                continue
        
        if height <= (y + h + bound_y): 
            img_box = img_origin[y: height, x: min(width, x + w)]
            img_cut = img_origin[max(0, y - bound_y): \
                    min(height, y + h + bound_y), max(0, x - bound_x): min(width, x + w)]        
            if (float(w) / width < 0.08 and float(h) / height < 0.08) \
                    or float(w) / width < 0.06 or float(h) / height < 0.06: 
                small_flag = 1
                continue
            result_check_deal = check_deal(img_box, bound_y)
            img_hist_bit = result_check_deal["img_hist_bit"]
            bit_w = result_check_deal["w_"]
            bit_h = result_check_deal["h_"] 
            Pos_x = result_check_deal["Pos_x"]
            Pos_y = result_check_deal["Pos_y"]
            img_cut = result_check_deal["img"]
            ret = y_check(img_hist_bit, bit_h, Pos_x, Pos_y, img_box, ocr_text, 1)
            if ret  and small_flag == 1: 
                small_aimed_num += 1
            if ret  and (small_flag != 1 or small_aimed_num >= small_th): 
                result_end = True 
    return (id_x, result_end, line.strip())


import time
import concurrent.futures


if __name__ == "__main__": 
    path = sys.argv[1]
    aimed_path = "./"
    mode = sys.argv[2] # 1：  文件获得tag 2: 线上获取单图
    #print(is_Chinese("中".decode("utf - 8")))
    if mode == "2": 
        paths = open(path).readlines()
    t1 = time.time()
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor: 
        args = []
        for id in range(len(paths)): 
            path_list = paths[id].strip().split(', ')
            for path in path_list: 
                if 'http' not in path: 
                    continue 
                else: 
                    args.append((id, mode, path, aimed_path))
        try: 
            for res in executor.map(ocr_truncature_check, args): 
                (id, res_bool, line) = res
                if res_bool: 
                    print line.strip() + "\t" + "jieduan_aimed"
                else: 
                    print line.strip() + "\t" + "jieduan_not_aimed"
        except: 
            traceback.print_exc()
    t2=time.time()
    print t2 - t1
