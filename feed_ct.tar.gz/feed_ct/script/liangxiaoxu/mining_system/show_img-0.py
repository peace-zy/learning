#!/usr/bin/env python
#-*- coding=utf8 -*-
"""
    图片视图展示
"""

#import http.cookiejar
import sys
import json
import time
import urllib
import cookielib
import MySQLdb
import logging
import argparse
import datetime
import string
import traceback

taskdate = datetime.date.today().strftime("%Y%m%d")
parser = argparse.ArgumentParser()
parser.add_argument('--taskname', default=taskdate, 
                    help="taskname default operate date, which split data into different page of web")
parser.add_argument('--riskname', default='illness', help="riskname of images")
parser.add_argument('--input', default='input.txt', help="input files of images urls")
parser.add_argument('--remove', default="Flase", help="remove the existed sql")
parser.add_argument('--label', default="", help="input/output")


class Monitor(object):
    """
        图片数据入库、展示、标注
    """
    def __init__(self, riskname, taskname, inputfile, remove):
        self.conn = MySQLdb.connect(host="10.255.120.17", port=3306, user="root", passwd="123456", db="imgtagdb")
        logging.basicConfig(level = logging.INFO, format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger(__name__)
        self.riskname = riskname
        self.taskname = taskname
        self.inputfile = inputfile
        self.remove= remove  
    
    def get_data(self):
        """
            获取解析数据
        """
        datadesc = []
        with open(self.inputfile, 'r') as tf:
            for line in tf:
                try:
                    #fields = line.strip().split('||')[1].split("\t")
                    #url = line.strip().split('||')[-1].strip()
                    fields = line.strip().split("\t")[0].split('||')
                    url = line.strip().split("||")[1].strip().split("|--|")[-1]
                    if 'http' not in url:
                        print ('error', url)
                        continue
                    if len(fields) > 1:
                        query = fields[0]
                        desc = fields[1]
                    else:
                        query = self.riskname
                        desc = 1
                    
                    query = self.riskname
                    query = desc
                    #url = urllib.unquote(url.decode('utf-8', 'replace'.encode('gbk', 'replace')))                    
                    #url, query, status , taskname, desciption
                    datadesc.append((url, query, 0, self.taskname, desc))
                except Exception as e:
                    traceback.print_exc()
        return datadesc

    def parse(self):
        """
            图片解析 入库
        """
        sqldata = self.get_data()
        if "True" == self.remove:
            clearsql = 'delete from tasks_imagemodel where taskname="%s";' % self.taskname
            #cursor = conn.cursor()
            cursor = self.conn.cursor()
            cursor.execute(clearsql)
            self.conn.commit()
            self.logger.info("delete succ[taskname:%s][riskname:%s]" % (self.taskname, self.riskname))
            return 
        insertsql = "insert into tasks_imagemodel(url, query, status, taskname, description) values(%s, %s, %s, %s, %s)"
        cursor = self.conn.cursor()
        cursor.executemany(insertsql, sqldata)
        self.conn.commit()
        self.logger.info("insert succ[taskname:%s][riskname:%s]" % (self.taskname, self.riskname))
        taskurl = "http://10.255.120.17:8282/task/?taskname=%s" % self.taskname
        print(taskurl)

    def get_dataset_data(self):
        """
            从数据库获取已标注数据,获取结果
        """
        result = []
        sql = 'select * from %s where taskname = "%s"' % ('tasks_imagemodel', self.taskname)
        cursor = self.conn.cursor()
        cursor.execute(sql)
        res = cursor.fetchall()
        for r in res:
            if r[3] == 1L:
                result.append(r[1].strip())
        return result


def file_parse(file, result):
    """
        文件解析
    """
    input_lines=open(file).readlines()
    for url in result:
        for line in input_lines:
            if url in line:
                print (line).strip()
                #print (line.split('||')[1])

if __name__ == '__main__':
    args = parser.parse_args()
    
    if args.label == "input":
        m = Monitor(args.riskname, args.taskname, args.input, args.remove)
        m.parse()
    if args.label == "output":
        m = Monitor(args.riskname, args.taskname, args.input, args.remove)
        result = m.get_dataset_data()
        file_parse(args.input, result)
