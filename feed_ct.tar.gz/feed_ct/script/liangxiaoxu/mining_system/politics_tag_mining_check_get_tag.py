#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Author:   liangxiaoxu@baidu.com
Date  :   2020/09/14 11:35:10
Desc  :   图片获取图片标签库标签饼存储
"""
import json
import traceback
import glob
import sys
import os
import os.path
import urllib2
import glob
import base64
import random
import time
import logging
import commands
import argparse
reload(sys)
sys.setdefaultencoding('gbk')
import threading
import multiprocessing
import concurrent.futures
import concurrent
import json
from PIL import Image

from io import BytesIO

class ImgInfoOnline(object):
    """
       获取线上图片key, url 信息   
    """
    def __init__(self):
        """init
        """
        self.bns_node = 'group.opera-tagserveronline-tagserver2-all-sz.FENGKONG.all'
        self.ocr_text=""
        self.class970 = {}
        self.politics_mark = {}
        self.badge_tag = {}
        self.sensitive_flag = {}
        self.starface = {}
        self.currency = {}
        self.weapon = {}
        self.landmark = {}
        self.chinamap = {}  
 
    def access_tqs(self, serverurl, req_url=None, req_cont_b64=None, item_count=1):
        """ access_tqs
        """
        logid = int(time.time() * 1000)
        #print("_server_url:", serverurl, "logid:", logid)
        param = {}
        param["logid"] = logid
        param["items"] = []
        for idx in range(0, item_count):
            item = {}
            item["id"] = idx
            item["userid"] = 0
            item["biz_src_id"] = 1
            item["is_deliver"] = True
            item["tag_paths"] = []
            item["tag_paths"].append("xvision_tag.gpu_web_ocr_text")
            item["tag_paths"].append("xvision_tag.gpu_web_ocr_location")
            item["tag_paths"].append("idl_tag.idl_nsz")
            item["tag_paths"].append("rcpt_tag.politics_mark")
            item["tag_paths"].append("rcpt_tag.badge")
            item["tag_paths"].append("idl_tag.sensitive_flag")
            item['tag_paths'].append('xvision_tag.starface')
            item['tag_paths'].append('rcpt_tag.currency')
            item['tag_paths'].append('rcpt_tag.weapon')
            item['tag_paths'].append('xvision_tag.landmark')
            item['tag_paths'].append('xvision_tag.chinamap')

            if (req_url is None and req_cont_b64 is None):
                raise Exception("req_url and req_cont_b64 are None at the same time")
            if (req_url is not None):
                item["req_url"] = req_url
            if (req_cont_b64 is not None):
                item["req_cont"] = req_cont_b64
                item["is_req_cont_base64"] = True
            param["items"].append(item)
        req = urllib2.Request(serverurl)
        req.add_data(json.dumps(param, encoding='GBK'))
        req.add_header("Content-Type", "application/json") #<=r31987
        #req.add_header("Content-Type", "application/proto") #>=r34740
        st = time.time()
        f = urllib2.urlopen(req)
        difft = time.time() - st
        res_str = f.read()
        res = json.loads(res_str.encode('utf-8'))
        return res

    def _get_server_url(self):
        cmd = 'get_instance_by_service -ip %s' % self.bns_node
        (s, o) = commands.getstatusoutput(cmd)
        url = None
        if int(s) == 0:
            iparr = o.split("\n")
            final_ip_port = random.choice(iparr)
            arr = final_ip_port.split(" ")
            if len(arr) == 3:
                url = 'http://%s:%s/ImageQueryTagService/query' % (arr[1], arr[2])
            elif len(arr) == 2:
                url = 'http://%s:%s/ImageQueryTagService/query' % (arr[0], arr[1])
        #print url
        return url

    def _query_tag(self, mode, img_url):
        server_url = self._get_server_url()
        if (mode == 0 or mode == 1):
            result = self.access_tqs(server_url, req_url=img_url)
        if (mode == 2):
            img = Image.open(img_url)
            #print img.mode
            with open(img_url, "rb") as fin:
                req_cont_b64 = base64.b64encode(fin.read())
            result = self.access_tqs(server_url, req_url=None, req_cont_b64=req_cont_b64)
        return result

    def unique_key_image_online(self, mode, img_path):
        """
        返回 key, url
        实际为往线上推送数据流程,   
        返回图片线上key 和标签库存储url 地址
        """
        key = -1
        try:
            result = self._query_tag(mode, img_path)
            #print result["items"][0]
            key = result["items"][0]["key"]
            http = result["items"][0]["url"]
        except Exception as e:
            pass
            #logging.exception(str(e))
        return key, http

    def get_img_info(self, img_path):
        """
            返回 gpu_web_ocr_text.content
        """
        mode = 2
        if "http" in img_path:
            mode = 1
        else:
            mode = 2
        k = 0
        img_info = {}
        while 1:
            try:
                k += 1
                img_path = img_path.split('\t')[0]
                #img_path = img_path.split(', ')[0]
                #print img_path
                result = self._query_tag(mode, img_path.strip())
                img_info = result["items"][0]["image_taginfo"]
                #print img_info
                self.class970 = self.get_970_class(img_info)
                self.politics_mark = self.get_politics_mark(img_info) #person_check(img, class970)
                self.ocr_text = self.get_ocr_text(img_info)
                self.badge_tag = self.get_badge(img_info)
                self.sensitive_flag = self.get_sensitive_flag(img_info)   
                self.starface = self.get_starface(img_info)             
                self.currency = self.get_currency(img_info)
                self.weapon = self.get_weapon(img_info)
                self.chinamap = self.get_chinamap(img_info)
                self.landmark = self.get_landmark(img_info)
                #print self.sensitive_flag, self.politics_mark
                break
            except Exception as e:
                #logging.exception(str(e))
                if k > 3:
                    break
        return 

    def get_ocr_text(self, img_info):
        """
            返回 gpu_web_ocr_text.content
        """
        ocr_text = img_info["xvision_tag"]["gpu_web_ocr_text"]["content"]
        return ocr_text
    
    def get_ocr_location(self, img_path):
        """
            获取ocr location
        """
        mode = 2
        if "http" in img_path:
            mode = 1
        else:
            mode = 2
        k = 0
        ocr_location = []
        while 1:
            try:
                k += 1
                result = self._query_tag(mode, img_path.strip())
                #print result
                ocr_location = {}
                xvision_tag = result["items"][0]["image_taginfo"]["xvision_tag"]
                if "array" in xvision_tag["gpu_web_ocr_location"]:
                    #print img_path.strip(), "|", json.dumps(xvision_tag["gpu_web_ocr_location"])["array"], "\n"
                    ocr_location = xvision_tag["gpu_web_ocr_location"]
                    #print img_path.strip() + " | " + json.dumps(ocr_location) + "\n"
                #ocr_location = result["items"][0]["image_taginfo"]["idl_tag"]["ocr_location"]#["array"]
                ocr_location = ocr_location["array"]
                break
            except Exception as e:
                #logging.exception(str(e))
                if k > 20:
                    break
        return ocr_location 
          
    def get_politics_mark(self, img_info):
        """
            获得敏感标志物标签
        """
        if 1:
        #try:
            ocr_location = {}
            xvision_tag = img_info["rcpt_tag"]
            politics_mark = xvision_tag["politics_mark"]
            version = politics_mark["version"]
        #except Exception as e:
            #logging.exception(str(e))
            #return false, {}
        return politics_mark
    
    def get_sensitive_flag(self, img_info):
        """
            获得敏感旗帜标签
        """
        #try:
        if 1:
            xvision_tag = img_info["idl_tag"]
            politics_mark = xvision_tag["sensitive_flag"]
            version = politics_mark["version"]
        #except Exception as e:
        #    logging.exception(str(e))
        #    return false, {}
        return politics_mark

    def get_starface(self, img_info):
        """
        获得明星脸标签
        """
        starface = {}
        if 1:
        #try:
            xvision_tag = img_info["xvision_tag"]
            starface = xvision_tag["starface"]
            version = starface["version"]
        #except Exception as e:
        #    logging.exception(str(e))
        #    return false, {}
        return starface
    
    def get_currency(self, img_info):
        """
            获得钱币标签
        """
        currency = {}
        if 1:
        #try:
            rcpt_tag = img_info["rcpt_tag"]
            currency = rcpt_tag["currency"]
            version = currency["version"]
        #except Exception as e:
        #    logging.exception(str(e))
        #    return false, {}
        return currency
    
    def get_weapon(self, img_info):
        """
            军事武器标签
        """
        weapon = {}
        if 1:
        #try:
            xvision_tag = img_info["rcpt_tag"]
            weapon = xvision_tag["weapon"]
            version = weapon["version"]
        #except Exception as e:
        #    logging.exception(str(e))
        #    return false, {}
        return weapon
    
    def get_badge(self, img_info):
        """
            敏感徽章
        """
        politics_mark = {}
        if 1:
        #try:
            xvision_tag = img_info["rcpt_tag"]
            politics_mark = xvision_tag["badge"]
            version = politics_mark["version"]
        #except Exception as e:
        #    logging.exception(str(e))
        #    return false, {}
        return politics_mark
    
    def get_landmark(self, img_info):
        """
            敏感地点
        """
        landmark = {}
        if 1:
        #try:
            xvision_tag = img_info["xvision_tag"]
            landmark = xvision_tag["landmark"]
            version = landmark["version"]
        #except Exception as e:
        #    logging.exception(str(e))
        #    return false, {}
        return landmark

    def get_chinamap(self, img_info):
        """
           中国地图
        """
        chinamap = {}
        if 1:
        #try:
            xvision_tag = img_info["xvision_tag"]
            chinamap = xvision_tag["chinamap"]
            version = chinamap["version"]
        #except Exception as e:
        #    logging.exception(str(e))
        #    return false, {}
        return chinamap
    
    def get_970_class(self, img_info):
        """
            通用970 分类
        """
        #try:
        if 1:
            array_970_class = {}
            idl_tag = img_info["idl_tag"]
            vresion = idl_tag["idl_nsz"]['version']
            if "array" in idl_tag["idl_nsz"]:
                class_970 = idl_tag["idl_nsz"]['array']
                for arr in class_970:
                    if "type" in arr:
                        array_970_class[int(arr['type'])] = arr['confidence']
                    if "id" in arr:
                        array_970_class[int(arr['id'])] = arr['confidence']
            #except Exception as e:
            #    logging.exception(str(e))
            #    return false, array_970_class
        return array_970_class 

    def get_ocr_location_files(self, img_path):
        """
            ocr location files
        """
        if os.path.exists(img_path):
            files = glob.glob(img_path + "*")
        else:
            files = open(img_path).readlines()
        for f in files:
            self.get_ocr_location(f)
    

def get_tag(f):
    """
        获取标签
    """
    obj = ImgInfoOnline()
    try:
        img = f.strip().split('\t')[0]
        obj.get_img_info(img)     
        politics_mark_str = json.dumps(obj.politics_mark)
        badge_tag_str = json.dumps(obj.badge_tag)
        ocr_text_str = obj.ocr_text
        class_970_str = json.dumps(obj.class970)
        sensitive_flag_str = json.dumps(obj.sensitive_flag) 
        starface_str = json.dumps(obj.starface)
        currency_str = json.dumps(obj.currency)
        weapon_str = json.dumps(obj.weapon)
        chinamap_str = json.dumps(obj.chinamap)
        landmark_str = json.dumps(obj.landmark)
        return "{}||{}||{}||-{}||{}||{}||{}||{}||{}||{}||{}".format(f.strip(), 
                politics_mark_str, badge_tag_str, ocr_text_str, class_970_str, 
                sensitive_flag_str, starface_str, currency_str, weapon_str, chinamap_str, landmark_str) 
    except Exception as e:
        traceback.print_exc()
    return ""


def multil_get_tag(filename, output):
    """
        多线程获取标签
    """
    f = open(output, "a")
    file_input = open(filename)
    lines = file_input.readlines()
    print (len(lines))
    file_input.close()
    lines_dict = {}
    for line in lines:
        url = line.strip().split('\t')[3]
        if url not in lines_dict:
            lines_dict[url] = [line.strip()]
        else:
            lines_dict[url].append(line.strip())

    result = []
    print (len(lines_dict))
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=8)
    for res in executor.map(get_tag, lines_dict.keys()):
        if res != "":
            for line_sep in lines_dict[res.split("||")[0]]:
                try:
                    res_str = line_sep + "|--|" + res.strip()
                    f.write("{}\n".format(res_str))
                except:
                    pass
    f.close()

def parse_args():
    """解析参数"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--label", type=str, default="", help="get_tag // check") 
    parser.add_argument("--input_file", type=str, default="", help="input file name")
    parser.add_argument("--output_file", type=str, default="", help="file save text")    
    return parser.parse_args()


if __name__ == "__main__":    
    t1 = time.time() 
    args = parse_args()
    input_file = args.input_file
    output_file = args.output_file
    label = args.label
    if label == "get_tag":
        multil_get_tag(input_file, output_file)
    t2 = time.time()
    print t2 - t1
