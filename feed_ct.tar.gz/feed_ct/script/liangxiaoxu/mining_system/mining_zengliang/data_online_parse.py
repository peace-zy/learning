#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Author:   liangxiaoxu@baidu.com
Date  :   21/07/15 15:32:09
Desc  :   
"""
import sys
import pandas as pd
import traceback
import time
import random

def read_file(file_path, 
            product_id=-1, 
            audit_channel=-1, 
            review_result=-1, 
            save_path="./tt",
            lines_num=10000000):
    """
    product_id : 产品线id ，不做筛选时默认-1
    audit_channel:  不做筛选时默认 -1  ，1 增量， 2 巡查， 3 人工一审， 4 人工二审
    review_result: 不做筛选时默认-1；最终审核结果， 1 拒绝， 0 通过
    输出:product_id, ad_id, user_id, url, audit_channel, review_result  
    """ 
    lines = open(file_path).readlines()
    line_dict = {}
    error_num = 0
    for line in lines:
        try:
            line_list = line.split('\t')
            ad_id = str(line_list[3])
            user_id = str(line_list[2])
            audit_channel_tmp = int(line_list[5])
            dict_key = ad_id + "+" + user_id
            if dict_key in line_dict:
                if (audit_channel_tmp > line_dict[dict_key]):
                    line_dict[dict_key] = audit_channel_tmp
            else:
                line_dict[dict_key] = audit_channel_tmp
        except:
            error_num += 1
            #traceback.print_exc()
            continue
    error_num = 0
    result = []
    for line in lines:
        line = line
        line_list = line.split('\t') 
        try:
            product_id_tmp = int(line_list[1])
            user_id = int(line_list[2])
            ad_id = int(line_list[3]) 
            pic_list = line_list[4]
            audit_channel_tmp = int(line_list[5])
            review_result_tmp = int(line_list[6])
            dict_key = str(ad_id) + "+" + str(user_id)
            if (line_dict[dict_key]) > audit_channel_tmp:
                continue        
            
            if (((product_id_tmp in product_id) or product_id == [-1]) 
                    and (audit_channel_tmp == audit_channel or audit_channel == -1) 
                    and (review_result == -1 or review_result == review_result_tmp)):
                for url in pic_list.split("\x01"):
                    result_line = "{}\t{}\t{}\t{}\t{}\t{}".format(
                            str(product_id_tmp), 
                            str(ad_id), 
                            str(user_id),
                            str(url), str(audit_channel_tmp), str(review_result_tmp))
                    result.append(result_line)
        except:
            error_num += 1
            continue
    result = list(set(result))
    random.shuffle(result)
    if len(result) > lines_num:
        result_print=result[:lines_num]
    else:
        result_print=result
    f = open(save_path, 'w')
    print len(result_print)
    lists = [line + "\n" for line in result_print]
    f.writelines(lists)
    f.close()
    return result


if __name__ == "__main__":
    """
        example: python data_online_parse.py  data_all/data_all_20210713.txt data_urls/data_urls_20210713
        argv[1] :输入数据， argv[2] 输出保存文件地址名称
    """
    t1 = time.time()
    file_path = sys.argv[1]
    save_path = sys.argv[2]
    lines_num = int(sys.argv[3])
    #df = read_file(file_path, [-1], -1, 0, save_path + ".pass.txt")
    #df = read_file(file_path, -1, -1, 1, save_path + ".reject.txt")
    #df = read_file(file_path, -1, -1, -1, save_path + ".all.txt")
    #fengchao pass
    fengchao_product_id=[31, 35, 153, 130, 72, 67, 29, 229, 186, 273, 193, 192, 174, 210, 351, 29, 267, 320, 53, 276, 314]
    #df = read_file(file_path, fengchao_product_id, -1, 0, save_path + "fengchao.pass.txt")
    feed_product_id=[136, 40, 120,87,89,257,88,55,286,160,28]
    #df = read_file(file_path, feed_product_id + fengchao_product_id, -1, 0, save_path + ".fc_feed.pass.txt",lines_num)
    df = read_file(file_path, [-1], -1, 0, save_path + ".all.pass.txt",lines_num)
    #feed pass
    
    t2 = time.time()
    print(t2 - t1)
