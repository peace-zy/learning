check_file() {
    input=$1
    output=$2
    nohup ~/liangxiaoxu/anaconda3/envs/python2/bin/python2 /home/users/liangxiaoxu/data_search/risk_data_mining/data_reduction/mining_normal/politics_tag_mining_check_new_10_01.py --label=check --input_file=${input} --output_file=${output} &
}

get_tag() {
    filename=$1
    output_file=$2
    k=20000
    k1=$(($k*1))
    k2=$(($k*2))
    k3=$(($k*3))
    k4=$(($k*4))
    k5=$(($k*5))

    sed -n '1,'${k1}'p' $filename > ${filename}_1
    sed -n ${k1}','${k2}'p' $filename > ${filename}_2
    sed -n ${k2}','${k3}'p' $filename > ${filename}_3
    sed -n ${k3}','${k4}'p' $filename > ${filename}_4
    sed -n ${k4}','${k5}'p' $filename > ${filename}_5
    date
    nohup ~/liangxiaoxu/anaconda3/envs/python2/bin/python2 politics_tag_mining_check_get_tag.py --label=get_tag --input_file=${filename}_1 --output_file=${output_file}_1 &
    nohup ~/liangxiaoxu/anaconda3/envs/python2/bin/python2 politics_tag_mining_check_get_tag.py --label=get_tag --input_file=${filename}_2 --output_file=${output_file}_2 &
    nohup ~/liangxiaoxu/anaconda3/envs/python2/bin/python2 politics_tag_mining_check_get_tag.py --label=get_tag --input_file=${filename}_3 --output_file=${output_file}_3 &
    nohup ~/liangxiaoxu/anaconda3/envs/python2/bin/python2 politics_tag_mining_check_get_tag.py --label=get_tag --input_file=${filename}_4 --output_file=${output_file}_4 &
    ~/liangxiaoxu/anaconda3/envs/python2/bin/python2 politics_tag_mining_check_get_tag.py --label=get_tag --input_file=${filename}_5 --output_file=${output_file}_5 
   
}
date

path_all=$1
output=$2
let num=`cat ${path_all} |wc -l`
cat ${path_all} |wc -l
sep_start=0
sep_end=15
sep_end=$((${num}/100000))
if [${sep_end}>60]; then
    sep_end=60
fi

k_sep=100000
for ((i=(($sep_start)); i<((${sep_end})); i++))
    do
        echo ${i}
        k1_sep=$((((${k_sep}*${i})) + 1))
        k2_sep=$((${k_sep}*((${i}+1))))
        echo ${k1_sep},${k2_sep}
        echo ${path_all}_${i}  ${output}_${i}
        sed -n ${k1_sep}','${k2_sep}'p' ${path_all} > ${path_all}_${i}
        get_tag  ${path_all}_${i}  ${output}_${i}
        sleep 60
    done
    
rm ${path_all}_*
cat ${output}_* >> ${output}
rm ${output}_*
output_name=`echo $output | cut -d \/ -f 2`
check_file /home/users/liangxiaoxu/data_search/risk_data_mining/data_reduction/data_urls/${output_name} /home/users/liangxiaoxu/data_search/risk_data_mining/data_reduction/mining_normal/data_result_new/${output_name}_result
