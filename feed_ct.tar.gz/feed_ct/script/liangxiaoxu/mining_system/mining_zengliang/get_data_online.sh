
all_img_fun_load(){
    hadoop fs -get afs://shaolin.afs.baidu.com:9902/app/ecom/fengkong/kg/parse_audit_log/parse_ad_audit_log_${now_date}/part-$part_id  ./parse_ad_audit_log_${now_date}/
    #echo ${now_date}
    awk -F "\t" '($12!="") {print "'$part_id'\t"$2"\t"$3"\t"$6"\t"$12"\t"$14"\t"$18"\t"$21"\t"$22"\n"}' ./parse_ad_audit_log_${now_date}/part-$part_id >> ./data_all/data_all_${now_date}.txt
    #cat ./data_fengchao/fengchao_${now_date}.txt|wc -l
    rm parse_ad_audit_log_${now_date}/part-$part_id
}

echo `date`
#start_seconds=$(date --date="$starttime" +%s);
now_date=$1
for ((i=1; i<=1; i++))
    do
        now_date=`date -d $now_date" 0 days" "+%Y%m%d"`
        rm ./data_all/data_all_${now_date}.txt
        touch ./data_all/data_all_${now_date}.txt
        mkdir ./parse_ad_audit_log_${now_date}/
        echo ${now_date}
        
        for ((k=0; k < 50; k++))
        do {
            echo $k
            for ((m=0; m<40; m++))
                do {
                    j=$(($k*40+$m))
                    part_id=`printf "%05d\n" $j`
                    all_img_fun_load 
                }& 
                done
            wait
            echo `date`
            echo "data_all:"
            cat ./data_all/data_all_${now_date}.txt|wc -l
        
        } done  
        now_date=`date -d $now_date" 1 days" "+%Y%m%d"`
    done
    iconv -f latin1 -t UTF-8 ./data_all/data_all_${now_date}.txt > ./data_all/data_all_${now_date}_bei.txt  
    cat ./data_all/data_all_${now_date}.txt|wc -l
    cat ./data_all/data_all_${now_date}_bei.txt |tr -s '\n' > ./data_all/data_all_${now_date}.txt
   
    #rm ./parse_ad_audit_log_${now_date}/ -rf
    #cat ./data_all/data_all_${now_date}.txt|wc -l
    #rm ./data_all/data_all_${now_date}_bei.txt 
       


echo `date`
