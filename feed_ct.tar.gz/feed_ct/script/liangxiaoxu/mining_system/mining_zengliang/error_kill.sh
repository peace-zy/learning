date_str=20211102
enddate=20220201
while [[ $date_str -lt $enddate ]]
do
{
    ps -eo pid,etime,command|grep politics_tag_mining_check_new.py --label=get_tag|awk -F " " 'length($2)>5  { print "kill -9 " $1}' > tt.sh
    sh tt.sh
    sleep 20m
}
done
