#sh get_data_online.sh ${date_str} 
#/liangxiaoxu/anaconda3/envs/python2/bin/python data_online_parse.py  data_all/data_all_${date_str}.txt data_urls/data_urls_${date_str}
#nohup /liangxiaoxu/anaconda3/envs/python2/bin/python politics_tag_mining_check_new.py --label=get_tag --input_file=data_urls/data_urls_${date_str}.fc_feed.pass.txt --output_file=data_urls/data_urls_${date_str}.fc_feed.pass_tag_output.txt &

date=`date -d "-1 day $date" +%Y%m%d`
date_str=20211128
enddate=20220120
while [[ $date_str -lt $enddate ]]
    do
        date_str=`date -d "+1 day $date_str" +%Y%m%d`
        echo $date_str
        sh get_data_online.sh ${date_str}
        ~/liangxiaoxu/anaconda3/envs/python2/bin/python2 data_online_parse.py  data_all/data_all_${date_str}.txt data_urls/data_urls_${date_str} 4059000
        nohup sh  get_tag_files.sh  data_urls/data_urls_${date_str}.all.pass.txt  data_urls/data_urls_${date_str}.all.pass.output.txt &
        sleep 24h
        #date=`date -d "+1 day $date " +%Y%m%d`
    done
