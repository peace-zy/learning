#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Author:   liangxiaoxu@baidu.com
Date  :   21/11/10 11:35:41
Desc  :   
"""
import sys
import pandas as pd
import json
import traceback
import demjson
import ast
import jsonpath
import urllib
import time

def read_data(path):
    """
        读取图灵平台数据
    """
    name = str("event_day,event_hour,event_minute,show,click,query," \
            + "title,desc1,desc2,show_url,msa_ad_url,target_url_sign,target_url," \
            + "url,refer,adv_targeting_url,pluto_trigger_url,img_url_select,ac_url," \
            + "mc_id,mt_id,kdomain_ki,ps_target_url_list,ps_show_url_list," \
            + "image_ads_info,xiangui_image_url,dynamic_image_para," \
            + "ct_material_all_item_sign,ct_material_image_text,json").split(',')
    #df = pd.read_csv(path, sep = "\t", names = name)
    #print len(df['json'])
    lines = open(path).readlines()
    #for id,value in df.iterrows():
    result_dict = {}
    for line in lines:
        try:
            line = urllib.unquote(line)
            key_lists = line.split("\001")
            
            event_day = key_lists[0]
            event_hour = key_lists[1]
            event_minute = key_lists[2]
            click = key_lists[4]
            query = key_lists[5]
            title = key_lists[6]
            desc1 = key_lists[7]
            desc2 = key_lists[8]
            json_line = key_lists[-1].strip()
            json_lists = json_line.replace("WrappedArray(", "")[:-1].split(", ")   
            #print json_lists
            image_result = []
            for j in json_lists:
                jj = j.strip().replace('\\', '').replace("'", '"').replace('\r',
                         '\\r').replace('\n', '\\n').replace('"{', '{').replace('}"', '}')
                jj_json = json.loads(jj)
                key_search_list = ['image', 'image_url', 'image_link', 'pic_url', 'img_src']
                for key in key_search_list:
                    image_search = jsonpath.jsonpath(jj_json, '$..' + key)
                    if type(image_search) == type([]):
                        image_result += image_search
            if image_result != []:    
                for url in image_result:
                    line_result = "{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}".format(
                            event_day, event_hour, event_minute, click, query, title, desc1, desc2, url)
                    print line_result
                    if url not in result_dict:
                        result_dict[url] = [line_result]
                    else:
                        result_dict[url].append(line_result)
                
        except:
            pass
            #traceback.print_exc()
            #print json_line
    #for url in result_dict:
    #    print "||||".join(result_dict[url]), '\t\t\t', url
    print len(result_dict)
 
if __name__ == "__main__":
    t1 = time.time()
    path = sys.argv[1]
    read_data(path)
    t2 = time.time()
    print (t2 - t1)

