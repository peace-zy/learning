check_file() {
    input=$1
    output=$2
    nohup ~/liangxiaoxu/anaconda3/envs/python2/bin/python2 ./politics_tag_mining_check_new_10_01.py --label=check --input_file=${input} --output_file=${output} &
}


date=20211205
enddate=20211230
while [[ $date -lt $enddate ]]
    do
        date=`date -d "+1 day $date" +%Y%m%d`
        echo ${date}
        tuling_data/turing-client/hadoop/bin/hadoop fs -get userpath.fc_ad_def_model_lxx/data_pc_${date}/  tuling_data/data_pc_${date}
        cat tuling_data/data_pc_${date}/part-* > tuling_data/data_pc/datas_pc_${date}.txt
        rm tuling_data/data_pc_${date}/ -rf
        cat tuling_data/data_pc/datas_pc_${date}.txt|shuf |head -n 460100 > tuling_data/data_pc/datas_pc_${date}_30w_sample-origin
        sh get_tag_files.sh tuling_data/data_pc/datas_pc_${date}_30w_sample tuling_data/data_pc/datas_pc_${date}_30w_sample-tag
        check_file  tuling_data/data_pc/datas_pc_${date}_30w_sample-tag  ./data_result/datas_pc_${date}_30w_sample_result
        sleep 24h
    done
