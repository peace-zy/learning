#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Author:   liangxiaoxu@baidu.com
Date  :   2020/09/14 11:35:10
Desc  :   图片样本数据入库前info 数据生成, 同时推送线上标签库, 保存线上key
"""
import json
import traceback
import glob
import sys
import os
import os.path
import urllib2
import glob
import base64
import random
import time
import logging
import commands
import argparse
reload(sys)
sys.setdefaultencoding('gbk')
import threading
import multiprocessing
import concurrent.futures
import concurrent
import json
from PIL import Image

from io import BytesIO

class ImgInfoOnline(object):
    """
       获取线上图片key, url 信息   
    """
    def __init__(self):
        """init
        """
        self.bns_node = 'group.opera-tagserveronline-tagserver2-all-sz.FENGKONG.all'
        self.ocr_text = ""
        self.class970 = {}
        self.politics_mark = {}
        self.badge_tag = {}
        self.sensitive_flag = {}
        self.starface = {}
        self.currency = {}
        self.weapon = {}
        self.landmark = {}


def car_check(img, class970, ocr_text):
    """
        警车check
    """
    key_words = ["POLICE", "警察", "公安", "police", "司法", "派出所", "交警"]
    key_ids = range(227, 237, 1) 
    key_ids += range(262, 278, 1)
    if class970 == {}:
        return ""
    for class_id in class970:
        if (class_id in key_ids) and class970[class_id] > 0.2:
            for key in key_words:
                if key in ocr_text.encode('utf-8'):
                    return  "car"    
    return ""


def building_check(img, class970, ocr_text):
    """
        建筑
    """
    key_words = ["交管", "POLICE", "警察", "公安", "police", "司法", "交警", "派出所"]
    key_ids = [330, 843, 840, 49, 38] 
    key_ids += []
    if class970 == {}:
        return ""
    for class_id in class970:
        #if 1:
        if (int(class_id) in key_ids) and class970[class_id] > 0.2:
            for key in key_words:
                if key in ocr_text.encode('utf-8'):
                    #print img, key, class_id , class970[class_id]
                    return "building"     
    return ""


def parse_gflag(gflag_str):
    """
        参数解析
    """
    gflags = []
    for line in  gflag_str.split('|'):
        class_dict = {}
        
        class_dict['id'] = int(line.split(', ')[0])
        class_dict['name'] = line.split(', ')[1].decode('utf-8')
        class_dict['violated'] = float(line.split(', ')[2])
        class_dict['manual'] = float(line.split(', ')[3])
        gflags.append(class_dict)
    return gflags


def check_entity(url, online_tag, gflag_str, check_key="id"):
    """
        entity check
    """
    ret_online = 0
    result_tag =  ""
    gflags = {}
    gflags = parse_gflag(gflag_str)
    class_name = "__"
    score = 0.0
    if "array" not in online_tag:
        ret_online = 0
    else:
        for gflag in gflags:
            if ret_online == 2:
                break
            for tag in online_tag['array']:
                #print tag[check_key], tag['confidence']
                if tag[check_key]  == gflag[check_key]:
                    if ret_online == 0 and tag['confidence'] > gflag['manual']:
                        ret_online = 1
                        class_name = str(gflag['name'])
                        score  = tag['confidence']
                    if tag['confidence'] >= gflag['violated']:
                        ret_online = 2
                        class_name = str(gflag['name'])
                        score = tag['confidence']
    return ret_online, class_name, score


def  politics_mark_check(img, politic_mark, ocr_text):
    """
        politics_mark_check
    """
    key_words = ["雷锋", "疫情", "签证服务", "POLICE", "公安", "警察", "检察", "派出所", \
             "被告人", "安全局", "司法", "签证服务", "党卫军", "司法", "签证服务", "党"]
    gflag_str = "1, 国徽, 0.9, 0.8|2, 国旗, 1.0, 0.5|11, 国旗五角星, 0.95, 0.5" + \
                "|3, 解放军军旗, 1.0, 0.4|4, 党徽, 1.0, 0.3|5, 军徽, 1.0, 0.5|" + \
                "6, 香港区旗, 1.0, 0.5|7, 澳门区旗, 1.0, 0.4|8, 台独旗帜, 1.0, 0.5" + \
                "|9, 国民党旗, 1.0, 0.5|10, 日本国旗, 1.0, 0.6"
    ret_online, class_name, score = check_entity(img, politic_mark, gflag_str)
    for key in key_words:
        if key in ocr_text.encode('utf-8'):
            if ret_online != 0:
                return "politics_mark + word_key + " + key
                #print img, key, class_name, score 
    return ""


def  politics_mark_check_hongqi(img, politic_mark, sensitive_flag, ocr_text):
    """
        红旗
    """
    gflag_str_wujiaoxing = "11, 国旗五角星, 0.95, 0.6"
    gflag_str_hongqi = "2, 国旗, 1.0, 0.5|6, 香港区旗, 1.0, 0.5"
    ret_wujiaoxing, class_name_wujiaoxing, score_wujiaoxing = check_entity(img, politic_mark, gflag_str_wujiaoxing)
    ret_hongqi, class_name_hongqi, score_hongqi = check_entity(img, politic_mark, gflag_str_hongqi)
    gflag_str_qizhi = "1, 中国国旗, 0.95, 0.75|2, 党旗, 0.95, 0.85|" \
            "3, 澳门区旗帜, 0.95, 0.8|4, 香港区旗帜, 0.95, 0.7|5, 港独1_1, 0.95, 0.8"
    ret_qizhi, class_name_qizhi, score_qizhi = check_entity(\
            img, sensitive_flag, gflag_str_qizhi, "name")
    if ret_wujiaoxing != 0  and (ret_hongqi != 0 or ret_qizhi != 0):
        return "wujiaoxing + hongqi" + str(score_wujiaoxing) 
    return ""


def  sensitive_flag_check(img, politic_mark, ocr_text):
    """
         敏感旗帜check
    """
    key_words = ["雷锋", "疫情", "签证服务", "POLICE", "公安", "警察", "检察", "派出所", 
            "被告人", "安全局", "司法", "签证服务", "党卫军", "司法", "签证服务", "党"]
    gflag_str_wujiaoxing = "1, 党徽, 0.9, 0.75|2, 警徽, 0.9, 0.75|3, 中国国旗, 0.95, 0.75" \
            "|4, 党旗, 0.95, 0.85|5, 澳门区旗帜, 0.95, 0.8|6, 香港区旗帜, 0.95, 0.7|" + \
             "7, 港独1_1, 0.95, 0.8|8, 法西斯, 0.98, 0.8"
    ret_wujiaoxing, class_name_wujiaoxing, score_wujiaoxing = check_entity(\
            img, politic_mark, gflag_str_wujiaoxing, "name") 
    #if ret_wujiaoxing == 2:
    #    return "sensitive_flag_党旗 + " + str(score_wujiaoxing)
    for key in key_words:
        if key in ocr_text.encode('utf-8'):
            if ret_wujiaoxing != 0:
                return "sensitive_flag + word_key + " + key
    return ""


def  sensitive_flag_nacui_check(img, sensitive_flag, ocr_text):
    """
        敏感旗帜纳粹check
    """
    key_words = ["安全局", "司法", "签证服务", "党卫军", '党']
    gflag_str_nacui = "1, 港独1_1, 0.95, 0.8|2, 法西斯, 0.98, 0.8"
    ret_nacui, class_name_nacui, score_nacui = check_entity(img, sensitive_flag, gflag_str_nacui, "name") 
    for key in key_words:
        if key in ocr_text.encode('utf-8'):
            if ret_nacui != 0:
                return "sensitive_flag_纳粹 + ".decode('utf-8') + str(score_nacui)
    return ""


def  star_face_check(img, star_face, file):
    """
        明星脸check
    """
    gflag_str = "0, 吴亦凡, 0.3, 0.3|1, 张哲瀚, 0.6, 0.4|2, 赵薇, 0.5, 0.3"
    gflag_str = "0, 习近平, 0.5, 0.3"
    words = open(file).readlines()
    for ii, name in enumerate(words):
        gflag_str = gflag_str + "|" + str(ii) + ", " + name.strip().split("\t")[0] + ", 0.6, 0.3" 
    ret, class_name, score = check_entity(img, star_face, gflag_str, "name") 
    if ret != 0: 
        return "star face: " + class_name
    return ""


def star_face_name(img, star_face):
    """
        人脸名称获取
    """
    name = ""
    if "array" not in star_face:
        return name
    for tag in star_face['array']:
        name = name + tag['name'] + "\t"
    return name


def  badge_check(img, badge, ocr_text):
    """
        徽章check
    """
    key_words = ["中国", "司法", "签证服务", "党", "警", "检察", "团", "警察", "军"]
    gflag_str = "0, 警徽, 0.95, 0.3|1, 检察院, 0.99, 0.3|2, 法院, 0.99, 0.95|" + \
                "3, 团徽, 0.99, 0.5|4, 少先队徽, 0.99, 0.5|5, 司法徽, 0.99, 0.5|" + \
                "6, 警察臂章, 0.99, 0.5|7, 军队臂章, 1.0, 0.5|8, 华表, 0.99, 0.5|9, 军徽, 0.99, 0.8"
    ret_online, class_name, score = check_entity(img, badge, gflag_str)
    for key in key_words:
        if key in ocr_text.encode('utf-8'):
            if ret_online != 0:
                return "badge + word_key + " + class_name.encode('utf-8') + str(score)
    return ""


def word_check(img, ocr_text, file):
    """
       ocr word check
    """
    key_words = open(file).readlines()
    try:
        for key in key_words:
            if key.strip() in ocr_text.encode('utf-8'):
                return key
    except:
        traceback.print_exc()
    return ""


def search_check(para, check_lists):
    """
       标签解析、执行挖掘算子
    """
    f = para
    root_dir = "/home/users/liangxiaoxu/data_search/risk_data_mining/data_reduction/mining_normal/"
    #mode = para.split('||')[1]
    mode = "not_online"
    obj = ImgInfoOnline()
    if mode == "online":
        img = f.strip()
        obj.get_img_info(img)
    else:
        #print f.split("||")
        try:
            img = f.split("||")[0]
            obj.politics_mark = json.loads(f.split("||")[1])
            obj.badge_tag = json.loads(f.split("||")[2])
            obj.ocr_text = f.split("||")[3]
            obj.class970 = json.loads(f.split("||")[4])
            obj.sensitive_flag = json.loads(f.split("||")[5])
            obj.starface = json.loads(f.split("||")[6])
            obj.landmark = json.loads(f.split("||")[-1])
        except Exception as e:
            pass
            #logging.exception(str(e))
    try:
        if '4' in check_lists:
            ret_sensitive_flag = sensitive_flag_check(
                    img, obj.sensitive_flag, obj.ocr_text)
            if ret_sensitive_flag != "":
                return '4_sensitive_flag||{}||{}'.format(img, ret_sensitive_flag)
        
        if '3' in check_lists:
            ret_sensitive_flag_nacui = sensitive_flag_nacui_check(
                    img, obj.sensitive_flag, obj.ocr_text)
            if ret_sensitive_flag_nacui != "" and obj.ocr_text != "-":
                return '3_nacui||{}||{}'.format(img, ret_sensitive_flag_nacui)
        
        if '5' in check_lists:
            ret_politics_mark = politics_mark_check(img, obj.politics_mark, obj.ocr_text)
            if ret_politics_mark != "":
                return '5_politics_mark||{}||{}'.format(img, ret_politics_mark)
        
        if '6' in  check_lists:
            ret_badge = badge_check(img, obj.badge_tag, obj.ocr_text)
            if ret_badge != "":
                return '6_badge||{}||{}'.format(img, ret_badge)
        
        if  '1' in check_lists:
            ret_car = car_check(img, obj.class970, obj.ocr_text)
            if ret_car != "":
                return '1_car||{}||{}'.format(img, ret_car)
            
        if  '2' in check_lists:
            ret_building = building_check(img, obj.class970, obj.ocr_text)
            if ret_building != "":
                return '2_building||{}||{}'.format(img, ret_building)
           
        if  '7' in check_lists: 
            ret_word_check = word_check(img, 
                    obj.ocr_text, root_dir + "./key_words_normal.txt")
            if ret_word_check != "":
                return '7_key_word||{}||{}'.format(img, ret_word_check)
        
        if  '8' in check_lists:
            ret_starface = star_face_check(img, obj.starface, root_dir + "./person_normal.txt")
            if ret_starface != "":
                return '8_starface||{}||{}'.format(img, ret_starface.encode('utf-8'))
            
        if  '9' in check_lists:
            ret_word_check = word_check(img, obj.ocr_text, root_dir + "./person_f")
            if ret_word_check != "":
                return '9_key_word_of_yuqing||{}||{}'.format(img, ret_word_check)
        
        if  '10' in check_lists:
            ret_starface = star_face_check(img,
                    obj.starface, root_dir + "./person_918.txt")
            if ret_starface != "":
                return '10_starface_of_918||{}||{}'.format(img, 
                        ret_starface.encode('utf-8'))
        
        if  '11' in check_lists:
            ret_starface = star_face_check(img, 
                    obj.starface, root_dir + "./rule_xiaojing_918_name.txt")
            if ret_starface != "":
                return '11_starface_of_918||{}||{}'.format(img, 
                        ret_starface.encode('utf-8'))
        
        if  '12' in check_lists:
            ret_starface = star_face_check(img, obj.starface,
                     root_dir + "./knowledge_graph/10.01_politics_name.txt")
            if ret_starface != "":
                return '12_starface_of_10.1_government_leader||{}||{}'.format(img, 
                        ret_starface.encode('utf-8'))
    
        if  '13' in check_lists:
            ret_hongqi = politics_mark_check_hongqi(img, 
                    obj.politics_mark, obj.sensitive_flag, obj.ocr_text)
            if ret_hongqi != "":
                return "13_hongqi||{}||{}".format(img, ret_hongqi.encode('utf-8'))    
        
        if  '14' in check_lists:
            ret_starface = star_face_check(img, 
                    obj.starface, root_dir + "./knowledge_graph/politics_name_yuqing")
            if ret_starface != "":
                return '14_starface_of_yuqing||{}||{}'.format(img, ret_starface.encode('utf-8'))
        
        if  '15' in check_lists:
            ret_word_check = word_check(img, obj.ocr_text,
                    root_dir + "./knowledge_graph/politics_name_yuqing")
            if ret_word_check != "":
                return '15_starface_word_of_yuqing||{}||{}'.format(img, ret_word_check)

       
        if 'all_star_face' in check_lists: 
            ret_starface = star_face_name(img, obj.starface)
            if ret_starface != "":
                return "all_star_face || {}||{}".format(img, ret_starface.encode('utf-8'))
        
        if "all_text" in check_lists:        
            if len(obj.ocr_text) > 2:
                return "all_ocr_text||{}||{}".format(img, obj.ocr_text.encode('utf-8'))
        
        if 'all_landmark' in check_lists: 
            ret_landmark = star_face_name(img, obj.landmark)
            if ret_landmark != "":
                return "all_landmark || {}||{}".format(img, ret_landmark.encode('utf-8'))
        
    except:
        traceback.print_exc() 
    return ""


def get_tag(f):
    """
        获取标签
    """
    obj = ImgInfoOnline()
    try:
        img = f.strip().split('\t')[0]
        obj.get_img_info(img)     
        politics_mark_str = json.dumps(obj.politics_mark)
        badge_tag_str = json.dumps(obj.badge_tag)
        ocr_text_str = obj.ocr_text
        class_970_str = json.dumps(obj.class970)
        sensitive_flag_str = json.dumps(obj.sensitive_flag) 
        starface_str = json.dumps(obj.starface)
        currency_str = json.dumps(obj.currency)
        weapon_str = json.dumps(obj.weapon)
        return "{}||{}||{}||-{}||{}||{}||{}||{}||{}".format(f.strip(), \
                politics_mark_str, badge_tag_str, ocr_text_str, class_970_str, \
                sensitive_flag_str, starface_str, currency_str, weapon_str) 
    except Exception as e:
        pass
    return ""


def multil_get_tag(filename, output):
    """
        多线程获取标签
    """
    f = open(output, "a")
    file_input = open(filename)
    lines = file_input.readlines()
    print (len(lines))
    file_input.close()
    lines_dict = {}
    for line in lines:
        url = line.strip().split('\t')[3]
        if url not in lines_dict:
            lines_dict[url] = [line.strip()]
        else:
            lines_dict[url].append(line.strip())

    result = []
    print (len(lines_dict))
    executor =  concurrent.futures.ThreadPoolExecutor(max_workers = 30)
    for res in executor.map(get_tag, lines_dict.keys()):
        if res != "":
            for line_sep in lines_dict[res.split("||")[0]]:
                res_str = line_sep + "|--|" + res.strip()
                f.write("{}\n".format(res_str))
    f.close()


def mining_search(file, output):
    """
        挖掘
    """
    lines = open(file).readlines()
    #executor = concurrent.futures.ProcessPoolExecutor(5)
    for line in lines:# executor.map(search_check, lines):
        check_list = [str(i + 1) for i in range(15)] + ['all_star_face', 'all_text']
        check_list = ['all_landmark']
        res = search_check(line, check_list)
        if res != "":
            file_name = output + "_" + res.split("||")[0].strip()
            save_file = open(file_name, 'a + ')            
            save_file.write(res + "\n")
            save_file.close()


def parse_args():
    """解析参数"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--label", type = str, default = "", help = "get_tag // check") 
    parser.add_argument("--input_file", type = str, default = "", help = "input file name")
    parser.add_argument("--output_file", type = str, default = "", help = "file save text")    
    return parser.parse_args()


if __name__ == "__main__":    
    t1 = time.time() 
    args = parse_args()
    input_file = args.input_file
    output_file = args.output_file
    label = args.label
    if label == "get_tag":
        multil_get_tag(input_file, output_file)
    if label == "check":
        mining_search(input_file, output_file)
    t2 = time.time()
    print t2 - t1
