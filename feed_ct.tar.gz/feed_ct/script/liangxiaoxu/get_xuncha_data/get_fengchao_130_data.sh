date
all_img_fun_load(){
    now_date=$2
    part_id=$1
    hadoop fs -get  afs://shaolin.afs.baidu.com:9902/app/ecom/fengkong/aka/davinci/test/wujie11/DYNAMICIMAGE/${now_date}/part-$part_id  ./xuncha_130/xuncha_log_${now_date}/
    echo ${now_date} ${part_id}
    cat ./xuncha_130/xuncha_log_${now_date}/part-$part_id |wc -l
}

echo `date`
#start_seconds=$(date --date="$starttime" +%s);
now_date="20210710"
for ((i=0; i< 1 ; i++))
    do
        #touch ./xuncha_130/xuncha_log_${now_date}.txt
        mkdir ./xuncha_130/xuncha_log_${now_date}/
        echo ${now_date}
        for ((k=0; k < 10; k++))
        do {
            echo $k
            for ((m=0; m<20; m++))
                do {
                
                    j=$(($k*20+$m))
                    part_id=`printf "%05d\n" $j`
                    all_img_fun_load ${part_id} ${now_date} 
                }& 
                done
            wait
            echo `date`
        } done 
        now_date=`date -d $now_date" 1 days" "+%Y%m%d"`   
    done


#cat ./data_fengchao/fengchao_${now_date}.txt|wc -l
#cat ./data_feed/feed_${now_date}.txt|wc -l
echo `date`
#echo "本次运行时间： "$((end_seconds-start_seconds))"s"
