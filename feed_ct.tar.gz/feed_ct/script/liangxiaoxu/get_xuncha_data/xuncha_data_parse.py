#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Author:   liangxiaoxu@baidu.com
Date  :   21/07/06 14:43:48
Desc  :   
"""
import sys
import glob
import json
import time
import traceback

def xuncha_get_130_urls(input_data_path, output_path):
    """
    #输入:巡查审核日志下载目录 
    #输出:巡查物料输出路径
    输出:product_id, ad_id, user_id, url, audit_channel,review_result   
    获取数据获取地址：http://aka.baidu-int.com/adhoc/list
    结果格式：
    {
        "result":{
            "audit_time":1625958118,"audit_channel_type":"kAd_AutoPatrolAudit",
            "review_result":"kAd_APPROVED","res_attribute":[],"audit_user":0,
            "audit_type":"kAd_FirstAudit"
        },
        "productid":130,
        "unitid":0,
        "planid":0,
        "text":{},
        "media":[
            {"ad_cont_id":"1566532384",
            "kMedia_Image":"http://t12.baidu.com/it/u=960102902,313317610&fm=77"}
            ],
        "version":1625890291,
        "userid":1411920324,
        "url":{},
        "ideaid":3518705296
    }
    """
    result_pass = []
    result_reject = []
    files = glob.glob(input_data_path + "*")
    for f in files:
        lines = open(f).readlines()
        for line in lines:
            try:
                line_json = json.loads(line.strip())
                res = line_json['result']['review_result']
                for id in range(len(line_json['media'])):
                    url = line_json['media'][id]['kMedia_Image']
                    ad_id = str(line_json['media'][id]['ad_cont_id'])
                    user_id = str(line_json['userid'])
                    product_id = str(line_json['productid'])
                    audit_channel = line_json['result']['audit_channel_type']
                    review_result = res
                    print_line = '{}\t{}\t{}\t{}\t{}\t{}'.format(
                            product_id, ad_id, user_id, url, 
                            audit_channel, review_result)
                    if (review_result == "kAd_APPROVED"):
                        result_pass.append(print_line)
                    else:
                        result_reject.apped(print_line)
            except:
                traceback.print_exc()
                continue
    f = open(output_path + ".pass.txt", "w")
    lists = [line + "\n" for line in result_pass]
    f.writelines(lists)
    f.close()
    
    f = open(output_path + ".reject.txt", "w")
    lists = [line + "\n" for line in result_reject]
    f.writelines(lists)
    f.close()


def xuncha_get_222_urls(input_path, output_path):
    """
    #输入:巡查审核日志下载目录 
    #输出:巡查物料输出路径
    audit_channel 2: 巡查， review_result : 0 通过 1 拒绝
    输出:product_id, ad_id, user_id, url, audit_channel,review_result   
    "222\t1232334\t13334433\thttp:xxx\t2\t1
    input:
    xuncha_222/xuncha_20210713_input/part-image-00000
    2015980816  14      https://t10.baidu.com/it/u1=3510815934&u2=4083873542&fm=76
    output:
    xuncha_222/xuncha_20210713_output/images_result
    30433484    14      https://f11.baidu.com/it/u1=30986749&u2=2008258218&fm=76    1   kAd_TEXTDISAPPROVED 2001    危害国家安全:非法交易(云矿);配图质量差:图片包含水印    {"image_detail":[{"img":"https://f11.baidu.com/it/u1=30986749&u2=2008258218&fm=76","text":"图片内容可能包含政治敏感信息（非法交易(云矿)）"}]}    
    """
    result_pass = []
    result_reject = []
    reject_lines = open(output_path + "images_result").readlines()
    for line in reject_lines:
        url = line.split('\t')[3].strip()
        result_reject.append(url)
    pass_urls = []
    files_input = glob.glob(input_path + "part-image*")
    for f in files_input:
        lines = open(f).readlines()
        for line in lines:
            try:
                line_list = line.split('\t')
                url = line_list[3].strip()
                ad_id = line_list[0]
                user_id = line_list[1]
                product_id = "222"
                audit_channel = "2"
                review_result = "0"
                print_line = '{}\t{}\t{}\t{}\t{}\t{}'.format(
                        product_id, ad_id, user_id, url, 
                        audit_channel, review_result)
                if url  in result_reject:
                    continue    
                pass_urls.append(url)
                result_pass.append(print_line)
            except:
                traceback.print_exc()
                continue
    
    f = open(output_path + "images.urls.pass.txt", "w")
    lists = [line + "\n" for line in result_pass]
    f.writelines(lists)
    f.close()
    print (len(result_pass))

if __name__ == "__main__":
    t1 =time.time()
    input_data_path = sys.argv[1]
    output_path = sys.argv[2]
    xuncha_get_130_urls(input_data_path, output_path)
    xuncha_get_222_urls(input_data_path, output_path)
    t2 = time.time()
    print (t2 - t1)
