LUxuncha_input_load(){
    #now_date=$2
    #part_id=$1
    hadoop fs -get  afs://tianqi.afs.baidu.com:9902/app/ecom/fengkong/aka/davinci/input/LU/PATROL/222_text_image/${now_date}/*  ./xuncha_222/xuncha_${now_date}_input/
    #echo ${now_date} ${part_id}
}

LUxuncha_output_load(){
    #now_date=$2
    #part_id=$1
    hadoop fs -get  afs://tianqi.afs.baidu.com:9902/app/ecom/fengkong/aka/davinci/output/LU/PATROL/222_text_image/${now_date}/*  ./xuncha_222/xuncha_${now_date}_output/
    cat ./xuncha_222/xuncha_${now_date}_output/part* |grep "http" > xuncha_222/xuncha_${now_date}_output/images_result
    #echo ${now_date} ${part_id}
}

echo `date`
#start_seconds=$(date --date="$starttime" +%s);
now_date="20210713"
for ((i=0; i< 1 ; i++))
    do
        mkdir ./xuncha_222/xuncha_${now_date}_input/
        mkdir ./xuncha_222/xuncha_${now_date}_output/
        echo ${now_date}
        LUxuncha_input_load #${part_id} ${now_date} 
        LUxuncha_output_load #${part_id} ${now_date}
        now_date=`date -d $now_date" 1 days" "+%Y%m%d"`   
    done


#cat ./data_fengchao/fengchao_${now_date}.txt|wc -l
#cat ./data_feed/feed_${now_date}.txt|wc -l
echo `date`
#echo "本次运行时间： "$((end_seconds-start_seconds))"s"
