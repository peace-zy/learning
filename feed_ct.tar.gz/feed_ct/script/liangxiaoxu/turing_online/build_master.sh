#!/bin/bash
set -ex
PWD=$(cd "$(dirname "$0")";pwd)
tarPaths=$1
rm -rf ./output
[[ ! -d "./output" ]] && mkdir ./output
function log_fatal()
{
    local content=[`date +%m-%d_%H:%M:%S`]
    echo -e "\033[1;31m[Fatal]\033[0m ${content} ($$): $*"
}
function log_warning()
{
    local content=[`date +%m-%d_%H:%M:%S`]
    echo -e "\033[1;31m[Warning]\033[0m ${content} ($$): $*"
}
function log_notice()
{
    local content=[`date +%m-%d_%H:%M:%S`]
    echo -e "\033[1;31m[Notice]\033[0m ${content} ($$): $*"
}
## tar file directory
function tar_file_directory(){
    local folder="./${sec_direct_name_without_white}"
    rm -rf ./output
    log_notice "start to tar ${folder}"
    tar czf ${sec_direct_name_without_white}.tar ${folder}
    [[ ! -d "./output" ]] && mkdir ./output
    mv ${sec_direct_name_without_white}.tar ./output
    log_notice "end to tar ${folder}"
}
## call their own packager sh build.sh
function call_packager(){
    local folder="./$1"
    [[ $1 == "" ]] && folder="."
    [[ $1 == "None" ]] && exit 1
    cd ${folder}
    if [ -f "build.sh" ];then
      sh build.sh
      cd -
      cp -r ${folder}/*.tar.gz ./output/
      log_notice "end to call ${folder}/build.sh"
    else
      cd -
      log_notice "Ignore ${folder}, build.sh not found in ${folder}"
    fi
}
## main
dir=$(ls -l ${PWD} |awk '/^d/ {print $NF}')
#IFS=',' arr=($tarPaths)
for tarPath in $dir; do
    echo $tarPath
    call_packager $tarPath
done