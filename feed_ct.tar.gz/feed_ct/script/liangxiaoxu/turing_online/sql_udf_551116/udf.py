#!/usr/bin/env python 
#-*- coding:utf-8 -*- 
""" 
定义sql中需要用到的udf，必须通过函数的方式定义 
请务必正确填写udf的返回类型 
""" 
