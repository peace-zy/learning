#########################################################################
#
# Copyright (c) 2018 Baidu.com, Inc. All Rights Reserved
#
# File: build.sh
# Author: turing-rd(turing-rd@baidu.com)
# Date: 2019-10-01 10:59:22
#
#########################################################################
#!/bin/bash
set -x
package_dir="./* .no_test"
shell_path=`pwd`/$0
package_name=`echo $shell_path | awk -F"/" '{print $(NF-1)}'`
echo $package_name
tar zcf $package_name.tar.gz --exclude=build.sh $package_dir
echo `pwd`/$package_name.tar.gz
