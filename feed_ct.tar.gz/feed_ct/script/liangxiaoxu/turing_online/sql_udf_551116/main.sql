select
ad_id,
ad_type,
product_id,
event_day,
review_result,
rsnid,
reason_array,
pic_url_array,
video_url_array,
rev_result_image,
regexp_replace(regexp_replace(concat_ws('||||', audit_details), '\n' , ''),'\t','') as audit_details
from fengkong.ad_audit_log t1
where
TURING_DATE
and product_id==256
