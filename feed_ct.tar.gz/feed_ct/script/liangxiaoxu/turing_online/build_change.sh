#!/bin/bash
echo "this file do nothing, just for local bcloud"
