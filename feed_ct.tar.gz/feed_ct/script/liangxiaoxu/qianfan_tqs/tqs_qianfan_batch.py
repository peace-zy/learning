#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Author:   liangxiaoxu@baidu.com
Date  :   21/09/09 20:34:34
Desc  :   
"""
import sys
import os
import json
import requests
import multiprocessing
import concurrent.futures
import concurrent
import numpy as np

def cal_tag_qianfan(server_url, urls, tag_list):
    """
        构造batch 批量请求数据
    """
    post_data={
        "log_id": "test_log_id", 
        "calculate_tags": tag_list, 
        "datas": [],
         "user_info": {
            "user_token": "95759011c79ba0548fb3b89bd35adb69"
         }
    }
    for url in urls:
        input = {        
            "input": {
                "image_input": {
                    "url": url
                  }
            }
        }
        post_data['datas'].append(input)
    
    headers={'Content-Type': 'application/json'}
    return_=requests.post(server_url, headers=headers, data = json.dumps(post_data))
    return_=json.loads(return_.content.decode())
    return return_

def result_parse(result, tag):
    """
    结果解析
    """
    result_data = result['datas']
    result = []
    for output in result_data: 
        result_tag = output['image_tag']
        
        img_url = output['input']['image_input']['url']
        print_line = "{}||{}".format(img_url, json.dumps(result_tag[tag]))      
        result.append(print_line)
    return result
    
def files_get_tag(file, tag, save_file):
    """
    文件url lists 获取标签
    """
    lines = open(file).readlines()
    save_lines = open(save_file, 'w')
    result = []
    input_lines=[]
    lines = np.array(lines)
    for i in range(len(lines)):
        lines[i] = lines[i].strip()
    num = int(len(lines)/10)*10 
    lines = lines[:num].reshape(-1, 10)
    lines =lines.tolist()
    executor =  concurrent.futures.ThreadPoolExecutor(max_workers=2)
    for res in executor.map(get_tags, lines):
        try:
            result += res
        except:
            pass
    for res in result:
        save_lines.write(res + "\n")      
    return result

def get_tags(lines):
    """
    批量batch 请求
    """
    server_url =  "http://10.255.120.17:8988/StarlinkService/calculate_batch"
    img_urls = lines
    tag = "fk_sensitive_person" 
    k = 0
    while 1:
        try:
            result = cal_tag_qianfan(server_url, img_urls, ["image_tag.fk_sensitive_person"])
            res = result_parse(result, tag)
        except:
            k += 1
            if k > 3:
                break
        break    
    return res

import time

def th_check(result, file_save, thre='1,0.999||2,0.94'):
    """
    阈值判断check
    """
    th_dict = {}
    for th in thre.split("||"):
        label_id = int(th.split(',')[0])
        label_th = float(th.split(',')[1])
        th_dict[label_id] = label_th

    if len(result) == 0:
        result = open(file_save).readlines()
    result_url_dict = []
    for res in result:
        url = res.split("||")[0]
        tag = res.split("||")[1].strip()
        tag_json = json.loads(tag.strip())
        if 'tag_item' not in tag_json:
            continue
        for tag_item in tag_json['tag_item']:
            item_id = tag_item['label_id']
            item_score = tag_item['confidence']
            if item_id in th_dict:
                if th_dict[item_id] < item_score:
                    result_url_dict.append(url + "||" + str(item_score) + "||" + str(item_id))
                    print (result_url_dict[-1])
                    break
    return result_url_dict
 
if __name__ == "__main__":
    t1 = time.time()
    file = sys.argv[1]
    save_file = sys.argv[2]
    result = []
    result = files_get_tag(file, 'fk_sensitive_person', save_file)
    #res_violated = th_check(result, save_file, '7,0.9997||8,0.999')
    #res_manual = th_check(result, save_file, '7,0.95||8,0.85')
    t2 = time.time()
    #print (len(res_violated), len(res_manual))
    print (t2 - t1)
