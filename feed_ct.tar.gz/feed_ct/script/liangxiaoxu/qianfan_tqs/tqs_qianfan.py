#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Author:   liangxiaoxu@baidu.com
Date  :   21/09/09 20:34:34
Desc  :   
"""
import sys
import os
import json
import requests
import multiprocessing
import concurrent.futures
import concurrent
import traceback

def cal_tag_qianfan(server_url, url, tag_list):
    """
        获取千帆体系图像标签
    """
    post_data={
        "log_id": "test_log_id", 
        "calculate_tags": tag_list, 
        "data": {
            "input": {
                "image_input": {
                    "url": url
                  }
                }
         },
         "user_info": {
            "user_token": "95759011c79ba0548fb3b89bd35adb69"
         }
    }
    headers = {'Content-Type': 'application/json'}
    return_ = requests.post(server_url, headers=headers, data=json.dumps(post_data))
    #print return_.content 
    return_ = json.loads(return_.content)#.decode())
    return return_


def result_parse(result, tag):
    """
    结果解析
    """
    tag_path = tag.split('.')[0]
    tag_name = tag.split('.')[1]
    result_tag = result['data'][tag_path] 
    img_url = result['data']['input']['image_input']['url']
    return "{}||{}".format(img_url, json.dumps(result_tag[tag_name])), result_tag[tag_name]      


def files_get_tag(file, tag, save_file):
    """
    文件url list 获取标签,文件保存
    """
    lines = open(file).readlines()
    save_lines = open(save_file, 'w')
    result = []
    line_input = []
    for i in range(len(lines)):
        try:
            line_input.append((lines[i].strip().split("\t")[3], tag))
        except:
            pass
            traceback.print_exc()
    print len(lines), len(line_input)
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=5)
    for res, tag in executor.map(get_tag, line_input):
        try:
            save_lines.write(res + "\n")
            result.append(res)
        except:
            pass
    return result


def get_tag((img_url, tag)):
    """
    单行获取标签
    """
    server_url = "http://10.255.120.17:8900/StarlinkService/calculate"
    k = 0
    res = img_url
    res_tag = {"if_error":True}
    while 1:
        try:
            result = cal_tag_qianfan(server_url, img_url, [tag])
            res, res_tag = result_parse(result, tag)
                        
        except:
            traceback.print_exc()
            k += 1
            if k > 3:
                break
        break
    return res, res_tag

import time


def th_check(result, file_save, thre='1,0.999||2,0.94'):
    """
    阈值check
    """
    th_dict = {}
    for th in thre.split("||"):
        label_id = int(th.split(',')[0])
        label_th = float(th.split(',')[1])
        th_dict[label_id] = label_th
    if len(result) == 0:
        result = open(file_save).readlines()
    result_url_dict = []
    for res in result:
        try:
            url = res.split("||")[0]
            tag = res.split("||")[1].strip()
            tag_json = json.loads(tag.strip())
            if 'tag_item' not in tag_json:
                continue
            for tag_item in tag_json['tag_item']:
                item_id = tag_item['label_id']
                item_score = tag_item['confidence']
                if item_id in th_dict:
                    if th_dict[item_id] < item_score:
                        result_url_dict.append(url + "||" + str(item_score) + "||" + str(item_id))
                        print (result_url_dict[-1])
                        break
        except:
            traceback.print_exc()
    return result_url_dict


def get_ocr_location(url):
    """
        获取ocr location
    """
    str_ocr_loc, ocr_loc = get_tag((url, "image_tag.xvision_web_ocr_tag"))
    #print url
    return ocr_loc

 
if __name__ == "__main__":
    t1 = time.time()
    file = sys.argv[1]
    save_file = sys.argv[2]
    result = []
    result = files_get_tag(file, 'image_tag.cspd_image_text_truncation', save_file)
    #result = files_get_tag(file, 'image_tag.xvision_web_ocr_tag', save_file)
    #th_check(result, save_file, "0,0.9")
    t2 = time.time()
    print (t2 - t1)
