# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件注册添加的模块。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/03/23 13:00:00
"""

########################### READER ###########################
from dataset.classification_reader import ClassificationReader
from dataset.voc_reader import VOCReader
from dataset.yolov3_tf_reader import Yolov3TfReader
from dataset.paddle_det_reader import PaddleDetReader
##############################################################

######################### TRANSFORM ##########################
#single image transform
from transform.augmentater import Augmentater 
from transform.mix_up import MixUp

#multiple image transform
from transform.mask_paster import MaskPaster
from transform.image_concater import ImageConcater

from transform.mask_paster_nofill import MaskPasterNofill
from transform.mask_paster_outline import MaskPasterOutline
##############################################################

########################### WRITER ###########################
from dataset.voc_writer import VOCWriter
from dataset.classification_writer import ClassificationWriter
from dataset.yolov3_tf_writer import Yolov3TfWriter
##############################################################

######################### EVALUATOR ##########################
from tools.det_evaluator import DetEvaluator
from tools.classify_evaluator import ClassifyEvaluator
##############################################################
