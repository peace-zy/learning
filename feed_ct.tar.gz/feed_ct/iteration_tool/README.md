# model_iterator
## 文档教程

- [安装](#安装)
- [样本库](#样本库)
- 数据
    - [标准数据格式](#标准数据格式)
    - [读取](#读取)
    - [存储](#存储)
    - [自定义数据解析和存储](#自定义数据解析和存储)
- 预处理
    - [数据增广](#数据增广)
    - [自定义数据增广](#自定义数据增广)
- [训练](#模型训练)
- [评估](#模型评估)
- [运行示例](#运行示例)
- [扩展]
    - [图像抓取](#图像抓取)

## 安装
   * [依赖imgaug](https://github.com/aleju/imgaug)
## 样本库  
......
## 数据
### 标准数据格式  
   ![图片名称](./tutorials/getting_started/reader/标准数据格式.png)      
### 读取
   目前支持voc格式、yolov3_tf格式解析，解析代码在dataset实现，[base_reader.py](./def_media_offline/dataset/base_reader.py)定义了数据解析基类，所有类型解析继承DataSet  

| 方法 | 输入 | 输出 | 备注 | 配置 | 示例 |
|:------------- |:-------------|:-------------| :-----|
| get_annotations | 无 | 标准数据格式 list[dict] | 获取标准数据格式 list[dict] |
| get_image_dir | 无 | 图像路径 str | 获取图像路径 str|
| get_label_map_file | 无 | 标签和类别映射文件 str | 获取标签和类别映射文件 str |
| get_label_map | 无 | 标签和类别映射 dict | 获取标签和类别映射 dict |
| load_annotations | 无 | list[dict] | 将输入数据格式转成标注数据格式，由子类实现 |
### 存储
   将标准格式存储成指定格式，目前支持分类任务（classification_writer.py）及voc格式（voc_writer.py）存储。[base_writer.py](./def_media_offline/dataset/base_writer.py)定义了数据存储基类，新增需继承该类。  

| 方法        | 输入           | 输出  | 备注   |
|:------------- |:-------------| :-----| :-----|
| write_out | annotation标准数据格式dict | True/False | 将标准数据格式转换成指定格式进行存储及显示 |
| write_annotation | annotation标准数据格式dict | True/False | 将标准数据格式转换成指定格式进行存储，由子类实现 |
| visualize | annotation标准数据格式dict | 无 | 获取标签和类别映射文件 str |
### 自定义数据解析和存储
* [自定义数据解析](./tutorials/custom/自定义数据解析.txt)
* [自定义数据存储](./tutorials/custom/自定义数据存储.txt)
## 预处理
### 数据增广
    目前支持单图数据增广及多图数据增广，[base_operator.py](./def_media_offline/transform/base_operator.py)定义了数据增广基类，新增需继承该基类
#### 单图数据增广(实现augmentater.py；配置文件conf/conf_sequential.py)  
![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/示例图.png)  

| 方法 | 配置 | 示例 | | 方法 | 配置 | 示例 |
|:------------- |:-------------| :-----| :-----|:------------- |:-------------| :-----|
| 左、右翻转 | iaa.Fliplr | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/01-image2020-3-17_18-49-35.png) | | 浮雕 | iaa.Emboss | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/12-image2020-3-17_18-57-13.jpg) |
| 上、下翻转 | iaa.Flipud | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/02-image2020-3-17_18-49-35.jpg) | | 单型噪声 | iaa.BlendAlphaSimplexNoise | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/13-image2020-3-17_18-57-19.jpg) |
| 剪切 | iaa.CropAndPad | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/03-image2020-3-17_18-49-48.jpg) | | 高斯噪声 | iaa.AdditiveGaussianNoise | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/14-image2020-3-17_18-57-25.jpg) |
| 缩放 | iaa.Affine: scale | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/04-image2020-3-17_18-49-53.jpg) | | 随机像素置零 | iaa.Dropout | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/15-image2020-3-17_18-57-30.jpg) |
| 平移 | iaa.Affine: translate_percent | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/05-image2020-3-17_18-49-58.jpg) | | 遮挡 | iaa.CoarseDropout iaa.Cutout(大面积遮挡) | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/16-image2020-3-17_18-57-35.jpg) |
| 旋转 | iaa.Affine: rotate | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/06-image2020-3-17_18-50-3.jpg) | | 亮度（加）| iaa.Add | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/17-image2020-3-17_18-57-39.jpg) |
| 错切 | iaa.Affine: shear | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/07-image2020-3-17_18-50-9.jpg) | | 颜色扰动 | iaa.Multiply | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/18-image2020-3-17_18-57-44.jpg) |
| 高斯滤波 | iaa.GaussianBlur | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/08-image2020-3-17_18-50-17.jpg) | | 亮度（乘）| iaa.CropAndPad | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/19-image2020-3-17_18-57-48.jpg) |
| 均值滤波 | iaa.AverageBlur | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/09-image2020-3-17_18-50-22.jpg) | | 对比度 | iaa.LinearContrast | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/20-image2020-3-17_18-57-52.jpg) |
| 中值滤波 | iaa.MedianBlur | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/10-image2020-3-17_18-50-27.jpg) | | 灰度化 | iaa.Grayscale | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/21-image2020-3-17_18-57-56.jpg) |
| 锐化 | iaa.Sharpen | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/11-image2020-3-17_18-50-38.jpg) | | 透视变换 | iaa.PerspectiveTransform | ![图片名称](./tutorials/getting_started/preprocess/augmentation/single_image/22-image2020-3-17_18-58-0.jpg) |

#### 多图数据增广  

| 算法 | 说明 | 示例 |
|:------------- |:-------------| :-----|
| 图像拼接 image_concater.py | 同大小（支持正、负混合拼接）| ![图片名称](./tutorials/getting_started/preprocess/augmentation/multi_image/同大小拼接.jpg) |
| | 不同大小 正例位于左上；支持拼接方式：9（3x3，正例占4个单元）| ![图片名称](./tutorials/getting_started/preprocess/augmentation/multi_image/不同大小拼接9.jpg) |
| | 16（4x4，正例占9个单元）| ![图片名称](./tutorials/getting_started/preprocess/augmentation/multi_image/不同大小拼接16.jpg) |
| 前景粘贴 mask_paster.py | 支持多个mask拼接到同一背景 | ![图片名称](./tutorials/getting_started/preprocess/augmentation/multi_image/多mask单背景.jpg) |
| | 背景支持多张图拼接 | ![图片名称](./tutorials/getting_started/preprocess/augmentation/multi_image/多mask多背景.jpg) |
| | 支持mask嵌套 object为最外层mask（根据粘贴位置自动生成标准信息）gun为mask中嵌套的子mask（需外部输入相对坐标文件，进行坐标系转换）| ![图片名称](./tutorials/getting_started/preprocess/augmentation/multi_image/mask嵌套.jpg) |
| mix up | 检测mix up，保持混合前类别 | ![图片名称](./tutorials/getting_started/preprocess/augmentation/multi_image/检测任务mixup.jpg) |
| | 分类mix up，混合图像标签（混合标签为浮点值）| ![图片名称](./tutorials/getting_started/preprocess/augmentation/multi_image/分类任务mixup.jpg) |
### 自定义数据增广
* [自定义数据增广方法](./tutorials/custom/自定义数据增广算法.txt)  
新增单图数据增广算法需根据输入的sample处理当前次变换。  
多图增广算法需要打包好每次需要处理的数据，根据输入参数idx，进行相应数据包处理  
## 模型训练
* [paddle分类任务](./def_media_offline/framework/paddle/PaddleClas/task/README.md)
* [paddle检测任务](./def_media_offline/framework/paddle/PaddleDetection/task/README.md)
## 模型评估
目前支持检测任务准确率和召回率评估及分类任务准确率及召回率评估，base_evaluator.py实现了评估基类，新增评估基类需继承该类  

| 方法        | 输入           | 输出  | 备注   |
| :------------- | :-------------| :-----| :-----|
| evaluate | 真值gt_annos, 预测值pre_annos | 无 | 性能评估 |
| eval_for_task | 真值gt_annos, 预测值pre_annos | True/False | 根据任务实现不同评估方法，由子类实现 |
| get_gt_annos | 无 | 真值 | 获取标准数据格式的真值 |
| evaluate | 无 | 预测值 | 获取标准数据格式的预测值 |
| evaluate | 无 | 标签类别映射文件 | 获取标签类别映射文件 |
| evaluate | 无 | 标签类别映射 | 获取标签类别映射 |
### 自定义评估方法
* [自定义评估方法](./tutorials/custom/自定义评估方法.txt) 注：自定义新的模块后需在conf/factory.py进行注册  
* [自定义模块注册](./tutorials/custom/自定义模块注册.png)
## 运行示例
通过yaml进行配置，配置文件中主要以已定义好的类进行配置，输入参数为类所需的初始化参数。
### 检测任务示例（conf/iterative_tool_detection.yml）
* [检测任务示例](./tutorials/getting_started/eval/检测任务评估.png)  
GtDataset 数据解析方式 按需指定  
PreDataset 数据解析方式 按需指定  
Transform 数据增广方式按配置表顺序执行，按需指定一种或多种  
Output 数据存储格式按需指定  
Evaluation 评估方式根据任务指定  
### 分类任务示例（conf/iterative_tool_classification.yml）
* [分类任务示例](./tutorials/getting_started/eval/分类任务评估.png)
与检测任务不同的地方在于数据解析方式、数据存储方式及评估方式
### 输入格式转换成指定格式
* [分类任务示例](./tutorials/getting_started/preprocess/convert_anno_format/voc-like2voc/输入格式转换成指定格式1.png)
* [分类任务示例](./tutorials/getting_started/preprocess/convert_anno_format/voc-like2voc/输入格式转换成指定格式2.png)
### 运行（iterative_tool.py）
python iterative_tool.py -c ${conf} --process_num ${process_num}  
根据不同任务选取相应的配置文件。  
关于开源增广模块的说明：  
可以运行conf/conf_sequential.py，查看各增广算法示例，根据需求调整各增广算法参数  
python conf/conf_sequential.py image_file save_path  
指定支持的输入格式和输出格式，若需要拷贝图像，将load_image置为True  
## 图像抓取
* [执行脚本](./extention/crawler/crawler.sh)
## 导出.so  
python setup.py build_ext  
