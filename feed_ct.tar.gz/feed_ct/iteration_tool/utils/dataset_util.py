# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了基本输入输出函数。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/03/16 13:00:00
"""

import yaml
def load_label_map(label_map_file):
    """获取标签和类别名映射
       {label: name}
    """

    label_map = {}
    with open(label_map_file, "r") as f:
        label_map = yaml.load(f, Loader=yaml.FullLoader)
    print("\033[32mlabel_map: {}\033[37m".format(label_map))
    return label_map
