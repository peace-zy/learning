# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了transform使用函数。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/04/07 13:00:00
"""

import sys

def refine_anno(anno, refine_param):
    """适配目标标注信息
    Args:
        anno: 标注信息 
        refine_param: 适配参数{"shift_x": shift_x, 
                               "shift_y": shift_y,
                               "scale_x": scale_x,
                               "scale_y": scale_y}
    Returns:
        Python dict 适配后的标注信息 
    """

    refined_anno = {}
    if "bndboxes" in anno:
        # refine bndbox
        refined_anno["bndboxes"] = []
        for bbx in anno["bndboxes"]:
            xmin = bbx["xmin"] / refine_param["scale_x"] + refine_param["shift_x"]
            ymin = bbx["ymin"] / refine_param["scale_y"] + refine_param["shift_y"]
            xmax = bbx["xmax"] / refine_param["scale_x"] + refine_param["shift_x"] 
            ymax = bbx["ymax"] / refine_param["scale_y"] + refine_param["shift_y"] 
            name = bbx["name"]
            refined_anno["bndboxes"].append({
                    "xmin": xmin,
                    "ymin": ymin,
                    "xmax": xmax,
                    "ymax": ymax,
                    "name": name})

    if "keypoints" in anno:
        refined_anno["keypoints"] = []
        for kps in anno["keypoints"]:
            points = []
            pts = kps["points"]
            for pt in pts:
                x = pt["x"] / refine_param["scale_x"] + refine_param["shift_x"]
                y = pt["y"] / refine_param["scale_y"] + refine_param["shift_y"]
                points.append({"x": x, "y": y})
            refined_anno["keypoints"].append({"points": points})
    if "label" in anno:
        refined_anno["label"] = anno["label"]
    return refined_anno

def print_processed(prefix, finished):
    """打印完成度"""
    finished *= 100
    info = prefix + '>' * int(finished) + ' ' * (100 - int(finished))
    sys.stdout.write('\r' + info + '[{0:.2f}%]'.format(finished))
    sys.stdout.flush()
    if finished == 1:
        sys.stdout.write('\r\n')
        sys.stdout.flush()
        return
