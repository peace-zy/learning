# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了迭代工具相关函数。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/03/23 13:00:00
"""
import yaml
import logging
import traceback
from conf.factory import *
from tqdm import tqdm
import multiprocessing
import random
import time

def process_single_image(reader=None, transforms=None, writer=None, process_num=1):
    """单张图增广流程"""
    annotations = []
    # read data
    if reader is not None:
        annotations = reader.get_annotations()
        if annotations:
            random.shuffle(annotations)

    print("\033[32m" + 40 * ">" + " [Start] Processing single image " + 40 * "<" + "\n\033[37m")
    logging.info("the number of image: [{}]".format(len(annotations)))

    start = time.time()
    idx = 0
    global run_flag
    run_flag = {}
    # transform data
    if transforms is not None:
        # transform data with operator
        for operator in transforms:
            if operator not in run_flag:
                run_flag[operator] = True
    anno_packages = [annotations[i: i + process_num] for i in range(0, len(annotations), process_num)]
    for anno_pkg in tqdm(anno_packages):
        if transforms is not None:
            processes = []
            q = multiprocessing.Queue()
            # transform data with operator
            for i in range(len(anno_pkg)):
                try:
                    anno = anno_pkg[i]
                    process = multiprocessing.Process(target=worker, args=(transforms, writer, anno, idx, q))
                    idx += 1
                    process.start()
                    processes.append(process)
                except Exception as e:
                    print('Error: unable to start process-{}'.format(str(i)))
                    traceback.print_exc()
            for t in processes:
                t.join()
            #print ("Exiting Main Process")
            results = [q.get() for i in processes]
            if sum(results) != len(results):
                break
    end = time.time()
    print("\n\033[32m" + 40 * "=" + " [End] Processing single image Elapse time=[{0:.2f}s]" \
            .format(end - start) + 40 * "=" + "\n\033[37m")


def process_multiple_image(reader=None, transforms=None, writer=None, process_num=1):
    """多张图增广流程"""

    annotations = []
    # read data
    if reader is not None:
        annotations = reader.get_annotations()
        if annotations:
            random.shuffle(annotations)

    print("\033[32m" + 40 * ">" + " [Start] Processing multiple image " + 40 * "<" + "\n\033[37m")
    start = time.time()
    idx = 0
    global run_flag
    run_flag = {}
    # transform data
    if transforms is not None:
        # transform data with operator
        for operator in transforms:
            if operator not in run_flag:
                run_flag[operator] = True
    if transforms is not None:
        # transform data with operator
        while (True): 
            q = multiprocessing.Queue()
            processes = []
            for i in range(process_num):
                try:
                    process = multiprocessing.Process(target=worker, args=(transforms, writer, annotations, idx, q))
                    idx += 1
                    process.start()
                    processes.append(process)
                except Exception as e:
                    print('Error: unable to start process-{}'.format(str(i)))
                    traceback.print_exc()
            for t in processes:
                t.join()
            #print ("Exiting Main Process")
            results = [q.get() for i in processes]
            if sum(results) != len(results):
                break
    end = time.time()
    print("\n\033[32m" + 40 * "=" + " [End] Processing multiple image Elapse time=[{0:.2f}s]" \
            .format(end - start) + 40 * "=" + "\n\033[37m")

def convert_format(reader=None, writer=None):
    """输入数据类型转换成指定的输出类型"""
    annotations = []
    # read data
    if reader is not None:
        annotations = reader.get_annotations()
    print("\033[32m" + 40 * ">" + " [Start] Convert format " + 40 * "<" + "\n\033[37m")
    logging.info("the number of image: [{}]".format(len(annotations)))
    start = time.time()
    if writer is not None:
        for anno in tqdm(annotations):
            writer.write_out(anno)
    end = time.time()
    print("\n\033[32m" + 40 * "=" + " [End] Convert format Elapse time=[{0:.2f}s]"\
            .format(end - start) + 40 * "=" + "\n\033[37m")


def evaluate(gt_reader=None, pre_reader=None, evaluator=None):
    """评估流程"""
    gt_annos = []
    pre_annos = []
    if gt_reader is not None:
        gt_annos = gt_reader.get_annotations()
    if pre_reader is not None:
        pre_annos = pre_reader.get_annotations()
    print("\033[32m" + 40 * ">" + " [Start] Evaluation " + 40 * "<" + "\n\033[37m")
    logging.info("the number of gt: [{}] | the number of pre: [{}]".format(len(gt_annos), len(pre_annos)))
    evaluator.evaluate(gt_annos, pre_annos)
    print("\033[32m" + 40 * "=" + " [End] Evaluation " + 40 * "=" + "\n\033[37m")

def worker(transforms, writer, annotations, idx, q):
    """进程函数"""
    global run_flag
    is_running = False
    for operator in transforms:
        if run_flag[operator]:
            trans_annos = operator(annotations, idx)
            if not trans_annos:
                run_flag[operator] = False 
                continue
            is_running = True
            # write data to xml
            if writer is not None and trans_annos:
                for anno in trans_annos:
                    writer.write_out(anno)
    q.put(is_running)

def parse_config(config_file):
    """解析配置文件

    Args:
        config_file: 配置文件

    Returns:
        param: python dict 配置参数
    """
    param = {}
    with open(config_file, "r") as f:
        config = yaml.load(f, Loader=yaml.FullLoader)
        logging.info("config:{}".format(config))
        print("\033[33m" + 100 * "-" + "\n[CONFIG]\n{}\n".format(config) + 100 * "-" + "\033[37m")
        param = get_iter_param(config)
    return param 

def get_ops(trans_def, key):
    """获取增广算子实例"""
    operators = []
    if key in trans_def:
        ops = trans_def[key]
        for op in ops:
            name = list(op.keys())[0]
            inputs = op[name]
            print(100 * "=")
            print(name, inputs)
            operator = eval(name)(**inputs)
            operators.append(operator)
    return operators

def get_processor(key, config):
    """获取参数实例"""
    processor = None
    if key in config:
        gt_data_def = config[key]
        name = list(gt_data_def.keys())[0]
        inputs = gt_data_def[name]
        processor = eval(name)(**inputs)
    return processor

def get_iter_param(config):
    """获取配置参数"""
    gt_reader = None
    pre_reader = None
    transforms = {}
    writer = None
    evaluator = None
    try:
        key = "GtDataset"
        gt_reader = get_processor(key, config)
        key = "PreDataset" 
        pre_reader = get_processor(key, config)

        if "Transforms" in config:
            trans_def = config["Transforms"]
            key = "SingleImage"
            ops = get_ops(trans_def, key)
            if ops:
                transforms[key] = ops 

            key = "MultipleImage"
            ops = get_ops(trans_def, key)
            if ops:
                transforms[key] = ops 

        key = "Output" 
        writer = get_processor(key, config)
        key = "Evaluation" 
        evaluator = get_processor(key, config)

    except Exception as e:
        traceback.print_exc()
    return {"gt_reader": gt_reader,
            "pre_reader": pre_reader,
            "transforms": transforms,
            "writer": writer,
            "evaluator": evaluator}
