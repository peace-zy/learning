# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了评估类相关函数。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/04/03 10:00:00
"""
import os
import logging

################################# detection ##############################
def make_det_dict(annos):
    """image_name: bndbonxes"""
    anno_dict = {}
    for anno in annos:
        image_file = anno["image_file"]
        bndboxes = anno["bndboxes"]
        image_name = os.path.basename(image_file)
        if image_name not in anno_dict:
            anno_dict[image_name] = bndboxes
    return anno_dict

def load_labels(label_file):
    """加载标签文件
    """
    labels = [] 
    with open(label_file, "r") as f:
        for line in f:
            name = line.rstrip()
            if name:
                labels.append(name)
    logging.info("names={}".format(labels))
    return labels

def iou(det_box, gt_box):
    """iou
    Args:
        det_box: {"xmin":, "ymin":, "xmax":, "ymax":, "name":, "score":}
        gt_box: {"xmin":, "ymin":, "xmax":, "ymax":, "name":, "score":}
    Returns:
        iou得分
    """

    xmin = max(det_box["xmin"], gt_box["xmin"])
    ymin = max(det_box["ymin"], gt_box["ymin"])
    xmax = min(det_box["xmax"], gt_box["xmax"])
    ymax = min(det_box["ymax"], gt_box["ymax"])
    if xmin >= xmax or ymin >= ymax:
        return 0

    intersection_area = (xmax - xmin) * (ymax - ymin)
    union_area = (det_box["xmax"] - det_box["xmin"]) * (det_box["ymax"] - det_box["ymin"]) + \
                 (gt_box["xmax"] - gt_box["xmin"]) * (gt_box["ymax"] - gt_box["ymin"]) - intersection_area\
                 
    return float(intersection_area) / union_area

def get_specified_class_bndbox(annos, class_name):
    """获取指定类别框
    Args:
        annos: 所有标注信息 
             [{"xmin":, "ymin":, "xmax":, "ymax":, "name":, "score":,}]
        class_name: 类别名
    Returns:
        boundboxs 指定类别检测框 
    """

    bndboxes = [anno for anno in annos if class_name == anno["name"]]
    return bndboxes
##########################################################################

################################# classification ##############################
def make_classify_dict(annos):
    """image_name: {"label":
                    "confidence":}"""
    anno_dict = {}
    for anno in annos:
        image_file = anno["image_file"]
        label = anno["label"]
        confidence = anno["confidence"]
        image_name = os.path.basename(image_file)
        if image_name not in anno_dict:
            anno_dict[image_name] = {
                    "label": label,
                    "confidence": confidence}
    return anno_dict
