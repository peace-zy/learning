# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了基本输入输出函数。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/03/16 13:00:00
"""
import os
import cv2
import logging
import hashlib

def cv_imread_and_check(image_file):
    """检查图像格式
    Args:
        image_file: 图像文件
    Returns:
        cv2 numpy 成功返回检验后的图片
                  失败返回 None
    """
    if not os.path.exists(image_file):
        logging.warning("the image [{}] does not exists!".format(image_file))
        return None
    image = cv2.imread(image_file)
    if image is None:
        logging.warning("the image [{}] is None!".format(image_file))
        return None

    image_shape = image.shape
    num = len(image_shape)
    if num == 2:
        #image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    elif num == 3:
        channels = image_shape[2]
        if channels != 3 and channels != 4:
            logging.error("image shape is not to be supported [{}]".format(image_shape))
            return None
        elif channels == 4:
            #image = cv2.cvtColor(image, cv2.COLOR_BGRA2RGB)
            image = cv2.cvtColor(image, cv2.COLOR_BGRA2BGR)
    else:
        logging.error("image shape < 2")
        return None
    return image

def cv_imwrite(save_file, image):
    """基于opencv存储图像

    Args:
        save_file: 存储名称 
        image: 图像内容 
    """
    cv2.imwrite(save_file, image)

def make_path(path):
    """创建路径
    args:
        path: 路径 

    returns:
    """
    if not os.path.exists(path):
        os.makedirs(path)

def save_image_and_anno(save_path, save_info):
    """存储图像及标注信息
    Args:
        save_path: 存储路径
        save_info：{"image": 存储图像,
                    "annotation": 适配后的标注信息}
    Returns:

    标注文件存储格式:
                      _________________
        bounding box:| x1 y1 x2 y2 name |
                     | x1 y1 x2 y2 name |
                     |_________________ |
                      __________________
        joints:      | x1,y1 x2,y2 x3,y3 |
                     | x1,y1 x2,y2 x3,y3 |
                     |__________________ |

    """
    image = save_info["image"]
    annotation = save_info["annotation"]
    objects = annotation["object"]
    image_file = annotation["image_path"]
    image_name = os.path.basename(image_file)

    # 存储图像
    save_image_path = os.path.join(save_path, "augmentated_images")
    make_path(save_image_path)
    save_file = os.path.join(save_image_path, image_name)
    cv_imwrite(save_file, image)

    # 存储标注文件
    image_name_without_post_fixed = os.path.splitext(image_name)[0]
    w_bbx = []
    w_kps = []
    for obj in objects:
        # bndbox
        if "bndbox" in obj:
            bbx = obj["bndbox"] 
            wline = "{} {} {} {} {}\n".format(int(bbx["x1"]), \
                                              int(bbx["y1"]), \
                                              int(bbx["x2"]), \
                                              int(bbx["y2"]), \
                                              bbx["name"])
            w_bbx.append(wline)

        # keypoints 
        if "keypoints" in obj:
            kps = obj["keypoints"]
            wline = ""
            for pt in kps:
                wline += "{},{} ".format(int(pt[0]), int(pt[1]))
            wline = wline.rstrip() + "\n"
            w_kps.append(wline)
    
    if w_bbx:
        save_bbx_path = os.path.join(save_path, "bndboxes")
        make_path(save_bbx_path)
        save_bbx_file = os.path.join(save_bbx_path, image_name_without_post_fixed + ".txt")
        with open(save_bbx_file, "w") as f:
            f.writelines(w_bbx)
    if w_kps:
        save_kps_path = os.path.join(save_path, "keypoints")
        make_path(save_kps_path)
        save_kps_file = os.path.join(save_kps_path, image_name_without_post_fixed + ".txt")
        with open(save_kps_file, "w") as f:
            f.writelines(w_kps)

def cv_draw_on_image(save_path, draw_info):
    """存储图像及标注信息
    Args:
        draw_info：{"image": 图像,
                    "annotation": 标注信息}
    Returns:
    """
    image = draw_info["image"]
    annotation = draw_info["annotation"]
    objects = annotation["object"]
    image_file = annotation["image_path"]
    image_name = os.path.basename(image_file)
    for obj in objects:
        # bndbox
        if "bndbox" in obj:
            bbx = obj["bndbox"] 
            x1 = int(bbx["x1"])
            y1 = int(bbx["y1"])
            x2 = int(bbx["x2"])
            y2 = int(bbx["y2"])
            name = bbx["name"]
            cv2.rectangle(image, (x1, y1), (x2, y2), (255, 0, 255), 2)
            font = cv2.FONT_HERSHEY_SIMPLEX
            n = len(name)
            cv2.rectangle(image, (x1, y1), (x1 + n * 15, y1 + 20), (255, 0, 0), thickness=-1)
            image = cv2.putText(image, name, (x1 + 5, y1 + 10), font, 0.5, (255, 255, 255), 2)

        # keypoints 
        if "keypoints" in obj:
            kps = obj["keypoints"]
            for pt in kps:
                cv2.circle(image, (int(pt[0]), int(pt[1])), 1, (0, 255, 0), 4)
    save_draw_path = os.path.join(save_path, "draw_images")
    make_path(save_draw_path) 
    
    save_file = os.path.join(save_draw_path, image_name)
    cv_imwrite(save_file, image)

def get_image_list(src_in):
    """获取图像列表
    Args:
        src_in: 图像路径or图像路径列表文件 

    Returns:
        Python list 包含图像路径列表
    """

    image_list = []
    if not src_in:
        return image_list 
    if os.path.isdir(src_in):
        for root, dirs, files in os.walk(src_in):
            if len(files) == 0:
                continue
            for per_file in files:
                image_file = os.path.join(root, per_file)
                image_list.append(image_file)
    else:
        with open(src_in, "r") as f:
            for line in f:
                image_list.append(line.rstrip())
    return image_list

def get_det(det_file):
    """获取检测信息

    Args:
        det_file: 检测文件 

    Returns:
        Python dict: 图像名及对应标注信息
    """
    from PIL import Image

    det_dict = {}
    with open(det_file, "r") as f:
        for line in f:
            try:
                line_info = line.rstrip().split(" ")
                image_path = line_info[0]
                image_name = os.path.basename(image_path)
                class_name = line_info[1]
                score = float(line_info[2])
                fxmin = float(line_info[3])
                fymin = float(line_info[4])
                fxmax = float(line_info[5])
                fymax = float(line_info[6])

                xmin = int(fxmin)
                ymin = int(fymin)
                xmax = int(fxmax)
                ymax = int(fymax) 
                # normalized 
                if fxmin <= 1 and fymin <= 1 or fxmax <= 1 or fymax <= 1:
                    image = Image.open(image_path)
                    width, height = image.size
                    xmin = int(fxmin * width)
                    ymin = int(fymin * height)
                    xmax = int(fxmax * width)
                    ymax = int(fymax * height) 
                if image_name not in det_dict:
                    det_dict[image_name] = {"image_path":image_path, "det_info":[]} 
                det_dict[image_name]["det_info"].append({"score": score, \
                        "bndbox": {"x1": xmin, "y1": ymin, "x2": xmax, "y2": ymax, "name": class_name}})
            except Exception as e:
                #print(traceback.print_exc(e))
                continue
    return det_dict

def get_md5(data):
    """获取md5"""
    if data is None:
        return "" 

    md5 = hashlib.md5()
    md5.update(data)
    md5sum = md5.hexdigest()
    return md5sum 
