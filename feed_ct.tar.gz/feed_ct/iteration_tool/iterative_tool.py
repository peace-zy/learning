# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了一个迭代工具。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/03/23 13:00:00
"""

import argparse
import traceback
from utils import iterative_tool_util
import logging

def parse_args():
    """解析参数"""
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", help="The configure file")
    parser.add_argument("--process_num", type=int, default=1, help="multiple thread num")
    return parser.parse_args()


def main():
    """main"""
    args = parse_args()
    config_file = args.c
    param = iterative_tool_util.parse_config(config_file)
    gt_reader = param["gt_reader"]
    pre_reader = param["pre_reader"]
    transforms = param["transforms"]
    writer = param["writer"]
    print("\033[32m" + 100 * "-" + "\n[PARAM]\n{}\n".format(param) + 100 * "-" + "\033[37m")
     
    # single image 
    if "SingleImage" in transforms:
        ops = transforms["SingleImage"]
        iterative_tool_util.process_single_image(reader=gt_reader,
                transforms=ops, writer=writer, process_num=args.process_num)

    # multiple image 
    if "MultipleImage" in transforms:
        ops = transforms["MultipleImage"]
        iterative_tool_util.process_multiple_image(reader=gt_reader,
                transforms=ops, writer=writer, process_num=args.process_num)

    # convert input data format to specified data format
    if "SingleImage" not in transforms and "MultipleImage" not in transforms:
        iterative_tool_util.convert_format(reader=gt_reader, writer=writer)

    # evaluation
    evaluator = param["evaluator"]
    if evaluator is not None:
        iterative_tool_util.evaluate(gt_reader, pre_reader, evaluator)

if __name__ == "__main__":
    main()
