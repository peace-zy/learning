# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了mix-up。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/03/16 10:00:00
"""

import os
from tqdm import tqdm
import cv2
import traceback
import numpy as np
import random
import math
import logging
import copy
from utils import io, log, transform_util
from transform import base_operator

class MixUp(base_operator.BaseOperator):
    """多图拼接类
       正例在左上不同大小
       正例和负例 同大小
       lamda: None 每次随机生成lamda
              设定值 按照定值mixup
    """
    def __init__(self, lamda=None, alpha=None, mix_label=False):
        """初始化"""
        super(MixUp, self).__init__()
        log.init_log(os.path.join("log", os.path.basename(__file__).split(".")[0]))
        self.lamda = lamda
        self.alpha = alpha
        self.mix_label = mix_label
        self.indexes = []

    def __call__(self, sample=None, idx=None):
        """ Process a sample.
        Args:
            sample (dict or list): 标准格式 单个或多个eg: 
            idx: 记录处理次数
        Returns:
            result (dict or list): a processed sample
                   需填充image 字段进行增广图保存
        """
        annotations = []

        if not sample:
            logging.warning("the number of sample is 0")
            return annotations
        if not self.indexes:
            self.indexes = [i for i in range(len(sample))]
            random.shuffle(self.indexes)
        if idx >= len(sample):
            return annotations
        anno = sample[idx]
        mix_anno = sample[self.indexes[idx]]
        annotations = self.mix_up(anno, mix_anno)
        transform_util.print_processed(self.get_pre_fix(), float(idx + 1) / len(sample))

        return annotations 

    def mix_up(self, anno, mix_anno):
        """存储粘贴后图像及标注文件
        Args:
            anno: 第一个图像信息 
            mix_anno: 拼接图像信息 
        Returns:
            拼接后的标注信息 
        """
        mixup_annotations = []
        #print("\033[33m" + 40 * "-" + " Processing mix up" + 40 * "-" + "\033[37m")
        lamda = self.lamda
        if not lamda:
            if not self.alpha:
                raise ValueError("the lamda and alpha not be set, one of them sholud be set")
            lamda = np.random.beta(self.alpha, self.alpha)
        mixup_anno = self.mix_image_and_label(anno, mix_anno, lamda)
        mixup_annotations.append(mixup_anno)

        #print("\033[33m" + 110 * "-" + "\n\033[37m")
        return mixup_annotations

    def mix_image_and_label(self, anno, mix_anno, lamda):
        """存储粘贴后图像及标注文件
        Args:
            anno: 原始标准格式 
            mix_anno: 待混合标准格式
            lamda: 混合系数
        Returns:
            cv2 numpy 增广后的图片
        """
        image_file = anno["image_file"]
        image = io.cv_imread_and_check(image_file)
        mix_file = mix_anno["image_file"]
        mix_image = io.cv_imread_and_check(mix_file)
        if image is None or mix_image is None:
            logging.warning("image or mix_image is None")
            return

        mixup_image_height = max(image.shape[0], mix_image.shape[0])
        mixup_image_width = max(image.shape[1], mix_image.shape[1])

        norm_image = cv2.resize(image, (mixup_image_width, mixup_image_height))
        norm_mix_image = cv2.resize(mix_image, (mixup_image_width, mixup_image_height))
        """
        mixup_image = np.zeros((mixup_image_height, mixup_image_width, 3), np.uint8)
        mixup_image_cp = np.copy(mixup_image) 
        mixup_image[:image.shape[0], :image.shape[1]] = image
        mixup_image_cp[:mix_image.shape[0], :mix_image.shape[1]] = mix_image
        """
        #mixup_image = lamda * mixup_image + (1 - lamda) * mixup_image_cp
        #cv2.imshow("mixup_image_bf", mixup_image)
        #cv2.imshow("mixup_image_cp", mixup_image_cp)
        #mixup_image = cv2.addWeighted(mixup_image, lamda, mixup_image_cp, 1 - lamda, 0)
        mixup_image = cv2.addWeighted(norm_image, lamda, norm_mix_image, 1 - lamda, 0)
        #cv2.imshow("mixup_image", mixup_image)
        #cv2.waitKey()

        refine_param = {"shift_x": 0, "shift_y": 0,
                        "scale_x": float(image.shape[1]) / mixup_image_width,
                        "scale_y": float(image.shape[0]) / mixup_image_height}
        
        refined_anno = transform_util.refine_anno(anno, refine_param)

        refine_param = {"shift_x": 0, "shift_y": 0,
                        "scale_x": float(mix_image.shape[1]) / mixup_image_width,
                        "scale_y": float(mix_image.shape[0]) / mixup_image_height}

        refined_mix_anno = transform_util.refine_anno(mix_anno, refine_param)

        mixup_anno = copy.deepcopy(refined_anno) 
        key = "bndboxes"
        if key not in refined_anno:
            mixup_anno[key] = []
        if key in refined_mix_anno:
            mixup_anno[key].extend(refined_mix_anno[key])
        key = "keypoints"
        if key not in refined_anno:
            mixup_anno[key] = []
        if key in refined_mix_anno:
            mixup_anno[key].extend(refined_mix_anno[key])
        if self.mix_label:
            key = "label"
            if key not in refined_anno:
                mixup_anno[key] = None 
            if key in refined_mix_anno:
                if mixup_anno[key] is not None and \
                        isinstance(mixup_anno[key], int) and \
                        isinstance(refined_mix_anno[key], int):
                    mixup_anno[key] = lamda * mixup_anno[key] + (1 - lamda) * refined_mix_anno[key]

        mixup_anno["image_file"] = self.get_unique_name(mixup_image)
        mixup_anno["width"] = mixup_image_width 
        mixup_anno["height"] = mixup_image_height
        mixup_anno["image"] = mixup_image

        return mixup_anno

