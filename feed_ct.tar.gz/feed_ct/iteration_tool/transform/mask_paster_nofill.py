# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了一个mask粘贴到背景图类。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/03/13 10:00:00
"""

import os
from tqdm import tqdm
import cv2
import traceback
import numpy as np
import copy
import random
import math
import logging
from conf import conf_sequential
import imgaug as ia
from imgaug.augmentables.bbs import BoundingBox, BoundingBoxesOnImage
from imgaug.augmentables.segmaps import SegmentationMapsOnImage
from utils import io, log, dataset_util, transform_util
from transform import base_operator
from transform import mask_paster

class MaskPasterNofill(mask_paster.MaskPaster):
    """
    粘贴mask到背景
    继承MaskPaster类的基本功能，
    区别：在于目标框内的背景为自定义纯色背景
    应用：如党徽。目标背景多为浅色纯色，直接选取贴图背景过于复杂、面积过大，与实际分布不符
    """
    
    def paste_mask_on_bg(self, mask_pkg, bg_pkg):
        """粘贴mask到背景

        Args:
            mask_pkg: mask 打包数据 
            bg_pkg: 背景打包数据

        Returns:
            bool: 成功返回True 
                  参数非法返回False
        """

        w_min = self.BOUNDARY 
        w_max = self.CONCAT_WIDTH - self.BOUNDARY 
        h_min = self.BOUNDARY 
        h_max = self.CONCAT_HEIGHT - self.BOUNDARY 
        #self.debug = True
        #print("\033[33m" + 40 * "-" + " Processing mask paster " + 40 * "-" + "\033[37m")
        annotations = []
        # 拼接背景图像
        concated_image = self.concated_images_by_list(bg_pkg)
        cat_shape = concated_image.shape
        bg_height = cat_shape[0]
        bg_width = cat_shape[1]
        # 读取mask
        pasted_img = copy.deepcopy(concated_image)
        anno = {}
        bndboxes = []
        if self.mask_ceil_size:
            paste_pos = self.mask_ceil_size["paste_pos"]
            random.shuffle(paste_pos)
        for i in range(len(mask_pkg)):
            try:
                mask_file = None
                mask_info = mask_pkg[i]
                name = self.name
                boxes = []
                if isinstance(mask_info, str):
                    mask_file = mask_info 
                elif isinstance(mask_info, dict):
                    mask_file = mask_info["image_file"]
                    if "bndboxes" in mask_info:
                        boxes = mask_info["bndboxes"]
                    if "label" in mask_info and self.label_map:
                        for n, l in self.label_map.items():
                            if mask_info["label"] == l:
                                name = n

                mask_img = io.cv_imread_and_check(mask_file)
                if mask_img is None:
                    continue
                # 根据拼接背景大小缩放mask
                rescaled_mask_img = self.rescale_mask(mask_img, cat_shape, mask_img.shape)
                h_ratio = float(rescaled_mask_img.shape[0]) / mask_img.shape[0]
                w_ratio = float(rescaled_mask_img.shape[1]) / mask_img.shape[1]

                # 增广mask
                aug_res = self.augment(rescaled_mask_img, boxes, h_ratio, w_ratio)
                mask_aug = aug_res["image_aug"]
                segmap_aug = aug_res["segmap_aug"]
                bbs_aug = aug_res["bbs_aug"]
                # 获取增广后的前景区域
                contours, hierarchy = cv2.findContours(segmap_aug, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
                areas = []
                for cnt in contours:
                    areas.append(cv2.contourArea(cnt))
                max_idx = np.argmax(np.array(areas))
                # cv2.drawContours(segmap_aug, contours, max_idx, 255, cv2.FILLED)
                # 剪切变换后的mask
                x, y, w, h = cv2.boundingRect(contours[max_idx])
                after_mask = copy.deepcopy(segmap_aug[y:y + h, x:x + w])
                #after_mask = after_mask * 255
                after_mask_aug = copy.deepcopy(mask_aug[y:y + h, x:x + w])

                # 取反
                mask_inv = cv2.bitwise_not(after_mask)
                #cv2.drawContours(mask, contours, max_idx, 0, cv2.FILLED)

                '''
                image_after = bbs_aug.draw_on_image(mask_aug, size=2, color=[0, 0, 255])
                ia.imshow(image_after)
                '''

                # mask 粘贴位置
                mask_height, mask_width = after_mask.shape
                 # 整张图位置随机
                if self.whole_image_random:
                    xmin = random.randint(w_min, w_max - mask_width) 
                    ymin = random.randint(h_min, h_max - mask_height) 
                    xmax = min(xmin + mask_width, bg_width) 
                    ymax = min(ymin + mask_height, bg_height) 
                # 根据mask数量按区域随机
                else:
                    mask_ceil_height = self.mask_ceil_size["height"]
                    mask_ceil_width = self.mask_ceil_size["width"]
                    n = self.mask_ceil_size["num"]
                    # 顺序
                    # row_idx = i // n 
                    # col_idx = i % n 
                    # 随机
                    row_idx = paste_pos[i][0]
                    col_idx = paste_pos[i][1]     
                    x_start = w_min + col_idx * mask_ceil_width
                    x_end = min(x_start + int(mask_ceil_width / self.space), w_max - mask_width)
                    if x_start >= x_end:
                         x_start = x_end - 1
                    xmin = random.randint(x_start, x_end) 
                    y_start = h_min + row_idx * mask_ceil_height
                    y_end = min(y_start + int(mask_ceil_height / self.space), h_max - mask_height)
                    if y_start >= y_end:
                         y_start = y_end - 1
                    ymin = random.randint(y_start, y_end)
                             
                    xmax = min(xmin + mask_width, bg_width) 
                    ymax = min(ymin + mask_height, bg_height) 

                bx= min(random.randint(5, 40), xmin, ymin)
                rand_pix_1 = [random.randint(200, 255), random.randint(200, 255), random.randint(200, 255)]
                rand_pix_2 = rand_pix_1
                rand_pix_2 = [random.randint(10, 60), random.randint(10, 60), random.randint(200, 255)]
                rand_pix = random.sample([rand_pix_1, rand_pix_2], 1)[0]

                pasted_img[ymin - bx:ymax + bx, xmin - bx:xmax + bx, 0] = rand_pix[0]
                pasted_img[ymin - bx:ymax + bx, xmin - bx:xmax + bx, 1] = rand_pix[1]
                pasted_img[ymin - bx:ymax + bx, xmin - bx:xmax + bx, 2] = rand_pix[2]

                paste_roi = pasted_img[ymin:ymax, xmin:xmax]
                
                fg_roi = cv2.bitwise_and(after_mask_aug, after_mask_aug, mask=after_mask)
                bg_roi = cv2.bitwise_and(paste_roi, paste_roi, mask=mask_inv)
                dst = cv2.add(bg_roi, fg_roi)
                
                conf = conf_sequential.Conf()
                seq = conf.get_user_sequential()
                #seq = conf.get_user_sequential_outline_second(1.0, 1.0)
                seed = random.randint(0, 1000)
                ia.seed(seed)
                dst = seq(image=dst)
                #cv2.imwrite(os.path.join(save_path, "dst_164.jpg"), dst)

                pasted_img[ymin:ymax, xmin:xmax] = dst

                '''
                '''
                # bbs适配剪切后的mask 
                if bbs_aug:
                    for box in bbs_aug: 
                        bndboxes.append({
                            "xmin": int(box.x1) + xmin - x,
                            "ymin": int(box.y1) + ymin - y,
                            "xmax": int(box.x2) + xmin - x,
                            "ymax": int(box.y2) + ymin - y,
                            "name": box.label 
                            })
                bndboxes.append({
                    "xmin": xmin,
                    "ymin": ymin,
                    "xmax": xmax,
                    "ymax": ymax,
                    "name": name 
                })

                # debug
                if self.debug:
                    save_path = "debug"
                    io.make_path(save_path)
                    cv2.imwrite(os.path.join(save_path, "concated_image.jpg"), concated_image)
                    cv2.imwrite(os.path.join(save_path, "rescaled_mask_img.jpg"), rescaled_mask_img)
                    cv2.imwrite(os.path.join(save_path, "mask_aug.jpg"), mask_aug)
                    cv2.imwrite(os.path.join(save_path, "mask.jpg"), after_mask)
                    cv2.imwrite(os.path.join(save_path, "mask_inv.jpg"), mask_inv)
                    cv2.imwrite(os.path.join(save_path, "paste_roi.jpg"), paste_roi)
                    cv2.imwrite(os.path.join(save_path, "bg_roi.jpg"), bg_roi)
                    cv2.imwrite(os.path.join(save_path, "fg_roi.jpg"), fg_roi)
                    cv2.rectangle(pasted_img, (xmin, ymin), (xmax, ymax), (0, 0, 255), 4)
                    cv2.rectangle(pasted_img, (w_min, h_min), \
                            (w_max - mask_width, h_max - mask_height), (0, 255, 0), 2)
                    cv2.imwrite(os.path.join(save_path, "pasted_img.jpg"), pasted_img)
            except Exception as e:
                traceback.print_exc()
                continue
        if bndboxes:
            anno["image_file"] = self.get_unique_name(pasted_img)
            anno["image"] = pasted_img
            anno["height"] = cat_shape[0]
            anno["width"] = cat_shape[1]
            anno["bndboxes"] = bndboxes
        annotations.append(anno)

        #print("\033[33m" + 110 * "-" + "\n\033[37m")
        return annotations
    
    def augment(self, image=None, boxes=[], h_ratio=1.0, w_ratio=1.0):
        """增广mask图像
        Args:
            image: 待增广图像 
        Returns:
            image_aug 增广后的图片
            segmap_aug 增广后的mask
            bbs_aug 增广后的boundingbox
        """
        conf = conf_sequential.Conf()
        seq = conf.get_user_sequential_guohui_1(0.05, 0.12)
        seed = random.randint(0, 1000)
        ia.seed(seed)
        # 准备粘贴mask
        image_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        # fb is 1, bg is 0 
        _, segmap = cv2.threshold(image_gray, 0, 1, cv2.THRESH_BINARY)
        #ia.imshow(segmap)
        # 图像开运算 erode->dilate
        kernel = np.ones((3, 3), np.uint8)
        segmap = cv2.morphologyEx(segmap, cv2.MORPH_OPEN, kernel)
        #ia.imshow(segmap)
        '''
        bbs = BoundingBoxesOnImage([
            BoundingBox(x1=0, y1=0, x2=image.shape[1], y2=image.shape[0]),
        ], shape=image.shape)
        '''
        segmap = SegmentationMapsOnImage(segmap, shape=image.shape)
        bndboxes = []
        if boxes:
            for box in boxes:
                bndboxes.append(BoundingBox(
                        x1 = box["xmin"] * w_ratio,
                        y1 = box["ymin"] * h_ratio,
                        x2 = box["xmax"] * w_ratio,
                        y2 = box["ymax"] * h_ratio,
                        label = box["name"]))
        bbs = BoundingBoxesOnImage(bndboxes, shape=image.shape)
        image_aug, segmap_aug, bbs_aug = seq(image=image,
                                    segmentation_maps=segmap,
                                    bounding_boxes=bbs)
        #empty_image = np.zeros((image_aug.shape[0], image_aug.shape[1]), dtype=np.uint8)
        empty_image = np.zeros(image_aug.shape, dtype=np.uint8)
        segmap_aug = segmap_aug.draw_on_image(empty_image)[0]
        _, segmap_aug = cv2.threshold(segmap_aug[:, :, 0], 0, 255, cv2.THRESH_BINARY)
        #print(segmap_aug[:,:,0] == segmap_aug[:,:,1])
        #segmap_aug = cv2.cvtColor(segmap_aug, cv2.COLOR_BGR2GRAY)
        #ia.imshow(segmap_aug)
        return {"image_aug": image_aug,
                "segmap_aug": segmap_aug,
                "bbs_aug": bbs_aug}

