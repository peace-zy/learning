# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了一个数据增广基类。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/04/01 13:00:00
"""

from utils import io

class BaseOperator(object):
    """数据增广基类
    子类实现__call__
        sample: 标准格式(单张图输入dict或者多图增广输入list)
    """

    def __init__(self, name=None):
        """初始化"""
        if name is None:
            name = self.__class__.__name__
        self.pre_fix = name

    def __call__(self, sample=None, idx=None):
        """ Process a sample.
        Args:
            sample (dict or list): 标准格式 单个或多个eg: 
                      {"image_file": "图像文件绝对路径 (required)",
                        "width": "图像宽 int", 
                        "height": "图像高 int",
                        "image": "opencv格式(optional)",
                        "bndboxes":[
                          { "xmin": "左上x int",
                            "ymin": "左上y int",
                            "xmax": "右下x int",
                            "ymax": "右下y int",
                            "name": "类别名"
                            "score": "得分", # 检测评估用
                          },  #(optional-检测任务)
                        ], 
                        "keypoints": [
                          {"points": [{
                            "x": "x坐标 int", 
                            "y": "y坐标 int",
                            },]
                          }, 
                        ], #(optional-关键点检测任务)
                        "label": "(optional-分类任务)"
                        "confidence": "分类评估用"
                      }
            idx: 记录处理次数

        Returns:
            result (dict or list): a processed sample
                   需填充image 字段进行增广图保存
        """
        return sample

    def get_pre_fix(self):
        """获取类名供图片存储"""
        return str(self.pre_fix) + "_"

    def get_unique_name(self, image):
        """获取存储md5名"""
        md5sum = self.get_pre_fix() + io.get_md5(image)
        return md5sum
