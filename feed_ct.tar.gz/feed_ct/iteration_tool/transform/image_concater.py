# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了一个多图拼接类
       正例在左上不同大小
       正例和负例 同大小

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/03/16 10:00:00
"""

import os
from tqdm import tqdm
import cv2
import traceback
import numpy as np
import random
import math
import logging
import copy
from utils import io, log, transform_util
from transform import base_operator

class ImageConcater(base_operator.BaseOperator):
    """多图拼接类
    """
    def __init__(self,
            concat_num=9,
            same_size=False,
            bg_in=None,
            bg_concat_num=0,
            concat_width=750,
            concat_height=750,
            boundary=50): 
        """初始化"""
        super(ImageConcater, self).__init__()
        log.init_log(os.path.join("log", os.path.basename(__file__).split(".")[0]))
        self.concat_num = concat_num 
        self.same_size = same_size
        self.bg_in = bg_in 
        self.bg_concat_num = bg_concat_num 
        self.CONCAT_WIDTH = concat_width 
        self.CONCAT_HEIGHT = concat_height 
        self.BOUNDARY = boundary 
        self.bg_packages = self.get_bg_packages()
        self.num_bg_pkg = len(self.bg_packages)

    def __call__(self, sample=None, idx=None):
        """ Process a sample.
        Args:
            sample (dict or list): 标准格式 单个或多个eg: 
        Returns:
            result (dict or list): a processed sample
                   需填充image 字段进行增广图保存
        """
        annotations = []
        if not sample:
            logging.warning("the number of sample is 0")
            return annotations
        # 同大小拼接, 可能存在多个正例
        mul_pos_idx = 0
        if self.same_size:
            fg_concat_num = self.concat_num - self.bg_concat_num
            mul_pos_idx = idx * fg_concat_num
        if max(idx, mul_pos_idx) >= len(sample):
            return annotations
        fg_pkg = self.get_fg_pkg(sample, idx)
        bg_pkg = []
        if self.num_bg_pkg:
            bg_pkg = self.bg_packages[idx % self.num_bg_pkg]
        anno = {}
        try:
            if self.same_size:
                anno = self.concat_image_in_same_size(fg_pkg=fg_pkg, bg_pkg=bg_pkg)
            else:
                anno = self.concat_image_in_diff_size(fg_pkg=fg_pkg, bg_pkg=bg_pkg)
        except Exception as e:
            traceback.print_exc()
            return annotations 
        annotations.append(anno)
        transform_util.print_processed(self.get_pre_fix(), float(max(idx, mul_pos_idx) + 1) / len(sample))
        return annotations 

    def get_bg_packages(self):
        """将背景按拼接数量打包"""
        bg_packages = []
        bg_list = []
        if self.bg_in is not None:
            bg_list = io.get_image_list(self.bg_in)
            if len(bg_list) == 0:
                logging.warning("the number of background file is 0!")
            random.shuffle(bg_list)
        if self.same_size:
            if self.bg_concat_num:
                if self.bg_concat_num > self.concat_num:
                    raise ValueError("the bg_concat_num {} should lower than concat_num {}"\
                            .format(self.bg_concat_num, self.concat_num))
                bg_packages = [bg_list[i:i + self.bg_concat_num] for i in range(0, len(bg_list), self.bg_concat_num)]

        else:
            bg_num = self.get_bg_num()
            bg_packages = [bg_list[i:i + bg_num] for i in range(0, len(bg_list), bg_num)]
        return bg_packages

    def get_fg_pkg(self, fg_annos, idx):
        """将前景按拼接数量打包"""
        if self.same_size:
            fg_concat_num = self.concat_num - self.bg_concat_num
            fg_packages = fg_annos[idx * fg_concat_num:(idx + 1) * fg_concat_num]
        else:
            fg_packages = fg_annos[idx]
        return fg_packages

        #print("\033[33m" + 40 * "-" + " Processing concater in same size" + 40 * "-" + "\033[37m")
        #print("\033[33m" + 110 * "-" + "\n\033[37m")

    def concat_image_in_same_size(self, fg_pkg, bg_pkg):
        """存储粘贴后图像及标注文件
        Args:
            bg_pkg: 背景图像路径列表 
            fg_pkg: 前景图像信息列表
        Returns:
            Python dict

        """
        bg_num = len(bg_pkg)
        fg_num = len(fg_pkg)
        pos = [i for i in range(self.concat_num)]
        random.shuffle(pos)
        bg_insert_pos = []
        if bg_num:
            bg_insert_pos = pos[:bg_num] 
        fg_insert_pos = pos[bg_num:]

        n = math.ceil(math.sqrt(self.concat_num)) # n * n concat images

        ROI_W = self.CONCAT_WIDTH - 2 * self.BOUNDARY
        ROI_H = self.CONCAT_HEIGHT - 2 * self.BOUNDARY

        every_width = ROI_W // n 
        every_height = ROI_H // n
        concat_image = np.zeros((self.CONCAT_HEIGHT, self.CONCAT_WIDTH, 3), np.uint8)

        for i in range(bg_num):
            image_file = bg_pkg[i]
            idx = bg_insert_pos[i]
            image = io.cv_imread_and_check(image_file)
            if image is None:
                continue

            norm_image = cv2.resize(image, (every_width, every_height))
            row_idx = idx // n 
            col_idx = idx % n 
            concat_image[self.BOUNDARY + row_idx * every_height:self.BOUNDARY + (row_idx + 1) * every_height, \
                    self.BOUNDARY + col_idx * every_width:self.BOUNDARY + (col_idx + 1) * every_width] = norm_image 

        refined_anno = {}
        for i in range(fg_num):
            image_file = fg_pkg[i]["image_file"]
            idx = fg_insert_pos[i]
            image = io.cv_imread_and_check(image_file)
            if image is None:
                continue

            norm_image = cv2.resize(image, (every_width, every_height))
            row_idx = idx // n 
            col_idx = idx % n 
            concat_image[self.BOUNDARY + row_idx * every_height:self.BOUNDARY + (row_idx + 1) * every_height, \
                    self.BOUNDARY + col_idx * every_width:self.BOUNDARY + (col_idx + 1) * every_width] = norm_image 
            refine_param = {"shift_x": self.BOUNDARY + col_idx * every_width,
                            "shift_y": self.BOUNDARY + row_idx * every_height,
                            "scale_x": float(image.shape[1]) / every_width,
                            "scale_y": float(image.shape[0]) / every_height}
            
            single_anno = transform_util.refine_anno(fg_pkg[i], refine_param)
            key = "bndboxes"
            if key in single_anno:
                if key not in refined_anno:
                    refined_anno[key] = []
                refined_anno[key].extend(single_anno[key])
            key = "keypoints"
            if key in single_anno:
                if key not in refined_anno:
                    refined_anno[key] = []
                refined_anno[key].extend(single_anno[key])
        refined_anno["image_file"] = self.get_unique_name(concat_image)
        refined_anno["width"] = self.CONCAT_WIDTH
        refined_anno["height"] = self.CONCAT_HEIGHT
        refined_anno["image"] = concat_image
        return refined_anno 

    def concat_image_in_diff_size(self, fg_pkg, bg_pkg):
        """存储粘贴后图像及标注文件
        Args:
            bg_pkg: 背景图像路径列表 
            fg_pkg: 前景图像信息列表
        Returns:
            Python dict

        """
        insert_idx = 0 
        image_file = fg_pkg["image_file"]
        bg_num = len(bg_pkg)
        n = math.ceil(math.sqrt(self.concat_num)) # n * n concat images

        ROI_W = self.CONCAT_WIDTH - 2 * self.BOUNDARY
        ROI_H = self.CONCAT_HEIGHT - 2 * self.BOUNDARY
        FG_WIDTH = ROI_W * (n - 1) // n 
        FG_HEIGHT = ROI_H * (n - 1) // n 
        BG_WIDTH = ROI_W // n 
        BG_HEIGHT = ROI_H // n 

        every_width = BG_WIDTH 
        every_height = BG_HEIGHT
        concat_image = np.zeros((self.CONCAT_HEIGHT, self.CONCAT_WIDTH, 3), np.uint8)
        fg_image = io.cv_imread_and_check(image_file)
        if fg_image is None:
            logging.warning("the image [{}] read error!".format(image_file))
            return {}

        # [height, width, channels]
        refine_param = {"shift_x": self.BOUNDARY,
                        "shift_y": self.BOUNDARY,
                        "scale_x": float(fg_image.shape[1]) / FG_WIDTH,
                        "scale_y": float(fg_image.shape[0]) / FG_HEIGHT}
        refined_anno = transform_util.refine_anno(fg_pkg, refine_param)
        insert_pos = self.get_insert_pos()
        norm_fg_image = cv2.resize(fg_image, (FG_WIDTH, FG_HEIGHT))
        concat_image[self.BOUNDARY:self.BOUNDARY + FG_HEIGHT, \
                self.BOUNDARY:self.BOUNDARY + FG_WIDTH] = norm_fg_image

        for i in range(bg_num):
            image_file = bg_pkg[i]
            idx = insert_pos[i]
            image = io.cv_imread_and_check(image_file)
            if image is None:
                continue

            norm_image = cv2.resize(image, (every_width, every_height))
            row_idx = idx // n 
            col_idx = idx % n 
            concat_image[self.BOUNDARY + row_idx * every_height:self.BOUNDARY + (row_idx + 1) * every_height, \
                    self.BOUNDARY + col_idx * every_width:self.BOUNDARY + (col_idx + 1) * every_width] = norm_image 

        refined_anno["image_file"] = self.get_pre_fix() + io.get_md5(concat_image)
        refined_anno["width"] = fg_pkg["width"] 
        refined_anno["height"] = fg_pkg["height"] 
        refined_anno["image"] = concat_image
        return refined_anno 

    def get_bg_num(self):
        """获取背景图像数量
        Returns:
            int 背景数量    
        """
        if self.concat_num == 4:
            return 3 
        if self.concat_num == 9:
            return 5 
        elif self.concat_num == 16:
            return 7 
        else:
            logging.warning("the number of concat [{}]is not \
                    supported! using the default concat num [9]".formart(self.concat_num))
            self.concat_num = 9
            return 5

    def get_insert_pos(self):
        """存储粘贴后图像及标注文件
        Returns:
            python list 
        """
        pos = []
        if self.concat_num == 4: 
            '''
             [ 0,  1]
             [ 2,  3]
            '''
            pos = [1, 2, 3]

        if self.concat_num == 9: 
            '''
             [ 0,  1,  2]
             [ 3,  4,  5]
             [ 6,  7,  8]
            '''
            pos = [2, 5, 6, 7, 8]

        elif self.concat_num == 16:
            '''
             [ 0,  1,  2,  3]
             [ 4,  5,  6,  7]
             [ 8,  9, 10, 11]
             [12, 13, 14, 15]
            '''
            pos = [3, 7, 11, 12, 13, 14, 15]

        return pos 
