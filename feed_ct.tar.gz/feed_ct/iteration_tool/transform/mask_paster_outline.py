# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了一个mask粘贴到背景图类。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/03/13 10:00:00
"""

import os
from tqdm import tqdm
import cv2
import traceback
import numpy as np
import copy
import random
import math
import logging
from conf import conf_sequential
import imgaug as ia
from imgaug.augmentables.bbs import BoundingBox, BoundingBoxesOnImage
from imgaug.augmentables.segmaps import SegmentationMapsOnImage
from utils import io, log, dataset_util, transform_util
from transform import base_operator
from transform import mask_paster

class MaskPasterOutline(mask_paster.MaskPaster):
    """
    主要应用：如户口本、结婚证等证件封皮等国徽样式
    mask 原形为国徽轮廓，背景构造目标框背景底色为暗灰等证件纯色，前景为偏亮色国徽轮廓
    """
    def paste_mask_on_bg(self, mask_pkg, bg_pkg):
        """粘贴mask到背景

        Args:
            mask_pkg: mask 打包数据 
            bg_pkg: 背景打包数据

        Returns:
            bool: 成功返回True 
                  参数非法返回False
        """

        w_min = self.BOUNDARY 
        w_max = self.CONCAT_WIDTH - self.BOUNDARY 
        h_min = self.BOUNDARY 
        h_max = self.CONCAT_HEIGHT - self.BOUNDARY 
        #print("\033[33m" + 40 * "-" + " Processing mask paster " + 40 * "-" + "\033[37m")
        annotations = []
        # 拼接背景图像
        concated_image = self.concated_images_by_list(bg_pkg)
        cat_shape = concated_image.shape
        bg_height = cat_shape[0]
        bg_width = cat_shape[1]
        # 读取mask
        pasted_img = copy.deepcopy(concated_image)
        anno = {}
        bndboxes = []
        for i in range(len(mask_pkg)):
            try:
                mask_file = None
                mask_info = mask_pkg[i]
                name = self.name
                boxes = []
                if isinstance(mask_info, str):
                    mask_file = mask_info 
                elif isinstance(mask_info, dict):
                    mask_file = mask_info["image_file"]
                    if "bndboxes" in mask_info:
                        boxes = mask_info["bndboxes"]
                    if "label" in mask_info and self.label_map:
                        for n, l in self.label_map.items():
                            if mask_info["label"] == l:
                                name = n

                mask_img = io.cv_imread_and_check(mask_file)
                if mask_img is None:
                    continue
                # 根据拼接背景大小缩放mask
                rescaled_mask_img = self.rescale_mask(mask_img, cat_shape, mask_img.shape)
                #print(rescaled_mask_img.shape)
                h_ratio = float(rescaled_mask_img.shape[0]) / mask_img.shape[0]
                w_ratio = float(rescaled_mask_img.shape[1]) / mask_img.shape[1]

                # 增广mask
                aug_res = self.augment_outline(rescaled_mask_img, boxes, h_ratio, w_ratio)
                mask_aug = aug_res["image_aug"]
                segmap_aug = aug_res["segmap_aug"]
                save_path = "debug"
                _, segmap_aug = cv2.threshold(segmap_aug, 30, 255, cv2.THRESH_BINARY)
                # 获取增广后的前景区域
                contours, hierarchy = cv2.findContours(segmap_aug, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
                areas = []
                for cnt in contours:
                    areas.append(cv2.contourArea(cnt))
                max_idx = np.argmax(np.array(areas))
                # 剪切变换后的mask
                x, y, w, h = cv2.boundingRect(contours[max_idx])

                after_mask = copy.deepcopy(segmap_aug[y:y + h, x:x + w])
                after_mask_aug = copy.deepcopy(mask_aug[y:y + h, x:x + w])
                '''
                image_after = bbs_aug.draw_on_image(mask_aug, size=2, color=[0, 0, 255])
                ia.imshow(image_after)
                '''
                # mask 粘贴位置
                mask_height, mask_width = after_mask.shape
                # 整张图位置随机
                if self.whole_image_random:
                    xmin = random.randint(w_min, w_max - mask_width) 
                    ymin = random.randint(h_min, h_max - mask_height) 
                    xmax = min(xmin + mask_width, bg_width) 
                    ymax = min(ymin + mask_height, bg_height) 
                # 根据mask数量按区域随机
                else:
                    mask_ceil_height = self.mask_ceil_size["height"]
                    mask_ceil_width = self.mask_ceil_size["width"]
                    n = self.mask_ceil_size["num"]
                    row_idx = i // n 
                    col_idx = i % n 
                    x_start = w_min + col_idx * mask_ceil_width
                    x_end = min(x_start + int(mask_ceil_width / self.space), w_max - mask_width)
                    if x_start >= x_end:
                         x_start = x_end - 1
                    xmin = random.randint(x_start, x_end) 
                    y_start = h_min + row_idx * mask_ceil_height
                    y_end = min(y_start + int(mask_ceil_height / self.space), h_max - mask_height)
                    if y_start >= y_end:
                         y_start = y_end - 1
                    ymin = random.randint(y_start, y_end)
                             
                    xmax = min(xmin + mask_width, bg_width) 
                    ymax = min(ymin + mask_height, bg_height) 
                  
                #paste_roi = concated_image[ymin:ymax, xmin:xmax]
                bx = min(random.randint(20, 40), xmin)
                cor = [random.randint(100, 240), random.randint(100, 240), random.randint(100, 240)]
                cor_ex = [random.randint(50, 100), random.randint(50, 100), random.randint(50, 150)]
                pasted_img[ymin - bx:ymax + bx, xmin - bx:xmax + bx][:, :, 0] = cor_ex[0]
                pasted_img[ymin - bx:ymax + bx, xmin - bx:xmax + bx][:, :, 1] = cor_ex[1]
                pasted_img[ymin - bx:ymax + bx, xmin - bx:xmax + bx][:, :, 2] = cor_ex[2]
                paste_roi = pasted_img[ymin:ymax, xmin:xmax]

                after_mask_aug[:, :, 0] = cor[0]
                after_mask_aug[:, :, 1] = cor[1]
                after_mask_aug[:, :, 2] = cor[2]
                
                _, after_mask = cv2.threshold(after_mask, 30, 255, cv2.THRESH_BINARY)
                mask_inv = cv2.bitwise_not(after_mask)
                #_, mask_inv = cv2.threshold(mask_inv, 20, 255, cv2.THRESH_BINARY)

                fg_roi = cv2.bitwise_and(after_mask_aug, after_mask_aug, mask=after_mask)
                #_, after_mask = cv2.threshold(after_mask, 40, 255, cv2.THRESH_BINARY)
                bg_roi = cv2.bitwise_and(paste_roi, paste_roi, mask=mask_inv)
                
                dst = cv2.add(bg_roi, fg_roi)
                cv2.imwrite(os.path.join(save_path, "dst_164.jpg"), dst) 
                pasted_img[ymin:ymax, xmin:xmax] = dst

                '''
                '''
                bndboxes = []
                bndboxes.append({
                    "xmin": xmin,
                    "ymin": ymin,
                    "xmax": xmax,
                    "ymax": ymax,
                    "name": name 
                })
                # debug
                if self.debug:
                    save_path = "debug"
                    io.make_path(save_path)
                    cv2.imwrite(os.path.join(save_path, "concated_image.jpg"), concated_image)
                    cv2.imwrite(os.path.join(save_path, "rescaled_mask_img.jpg"), rescaled_mask_img)
                    cv2.imwrite(os.path.join(save_path, "mask_aug.jpg"), mask_aug)
                    cv2.imwrite(os.path.join(save_path, "mask.jpg"), after_mask)
                    cv2.imwrite(os.path.join(save_path, "mask_inv.jpg"), mask_inv)
                    cv2.imwrite(os.path.join(save_path, "paste_roi.jpg"), paste_roi)
                    cv2.imwrite(os.path.join(save_path, "bg_roi.jpg"), bg_roi)
                    cv2.imwrite(os.path.join(save_path, "fg_roi.jpg"), fg_roi)
                    cv2.rectangle(pasted_img, (xmin, ymin), (xmax, ymax), (0, 0, 255), 4)
                    cv2.rectangle(pasted_img, (w_min, h_min), \
                            (w_max - mask_width, h_max - mask_height), (0, 255, 0), 2)
                    cv2.imwrite(os.path.join(save_path, "pasted_img.jpg"), pasted_img)
            except Exception as e:
                traceback.print_exc()
                continue
        if bndboxes:
            anno["image_file"] = self.get_unique_name(pasted_img)
            anno["image"] = pasted_img
            anno["height"] = cat_shape[0]
            anno["width"] = cat_shape[1]
            anno["bndboxes"] = bndboxes
        annotations.append(anno)

        #print("\033[33m" + 110 * "-" + "\n\033[37m")
        return annotations
    
    #生成户口本封皮式的国徽使用方法
    #与mask_paste 的区别在于 mask 图只保留线条轮廓
    def augment_outline(self, image=None, boxes=[], h_ratio=1.0, w_ratio=1.0):

        """
        增广mask图像
        Args:
            image: 待增广图像 
        Returns:
            image_aug 增广后的图片
            segmap_aug 增广后的mask
            bbs_aug 增广后的boundingbox        
        """
        conf = conf_sequential.Conf()
        seq = conf.get_user_sequential()
        #seq = conf.get_user_sequential_outline(0.15, 0.4)
        seed = random.randint(0, 1000)
        ia.seed(seed)
        # 准备粘贴mask
        _, image = cv2.threshold(image, 30, 255, cv2.THRESH_BINARY_INV)
        image_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        segmap = image_gray
        '''
        bbs = BoundingBoxesOnImage([
            BoundingBox(x1=0, y1=0, x2=image.shape[1], y2=image.shape[0]),
        ], shape=image.shape)
        '''
        #segmap = SegmentationMapsOnImage(segmap, shape=image.shape)
        #cv2.imwrite(os.path.join(save_path, "mask_aug_241.jpg"), segmap)
        image_aug = seq(image=image)
        #segmap_aug = image_aug
        #cv2.imwrite(os.path.join(save_path, "image_aug_230.jpg"), image_aug)
        segmap_aug = cv2.cvtColor(image_aug, cv2.COLOR_BGR2GRAY)
        
        #print ("segmap_aug.shape",segmap_aug.shape,image_aug.shape)
        #_,segmap_aug_2 = cv2.threshold(segmap_aug, 40, 255, cv2.THRESH_BINARY_INV)
        #cv2.imwrite(os.path.join(save_path, "image_aug_232.jpg"), segmap_aug)
        """
        contours, hierarchy = cv2.findContours(segmap_aug, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        areas = []
        for cnt in contours:
            areas.append(cv2.contourArea(cnt))
        max_idx = np.argmax(np.array(areas))
        # cv2.drawContours(segmap_aug, contours, max_idx, 255, cv2.FILLED)
        # 剪切变换后的mask
        x, y, w, h = cv2.boundingRect(contours[max_idx])
        segmap_aug = copy.deepcopy(segmap_aug[y:y + h, x:x + w])
        """        
        #cv2.imwrite(os.path.join(save_path, "after_mask_243.jpg"), segmap_aug)
        return {"image_aug": image_aug,
                "segmap_aug": segmap_aug}
