# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了一个mask粘贴到背景图类。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/03/13 10:00:00
"""

import os
from tqdm import tqdm
import cv2
import traceback
import numpy as np
import copy
import random
import math
import logging
from conf import conf_sequential
import imgaug as ia
from imgaug.augmentables.bbs import BoundingBox, BoundingBoxesOnImage
from imgaug.augmentables.segmaps import SegmentationMapsOnImage
from utils import io, log, dataset_util, transform_util
from transform import base_operator


class MaskPaster(base_operator.BaseOperator):
    """粘贴mask到背景"""
    def __init__(self,
            bg_concat_num=1,
            mask_num=1,
            mask_in=None,
            bg_in=None,
            name=None,
            label_map_file=None,
            whole_image_random=True,
            space=2,
            concat_width=640,
            concat_height=640,
            boundary=50): 
        """初始化"""
        super(MaskPaster, self).__init__()
        log.init_log(os.path.join("log", os.path.basename(__file__).split(".")[0]))
        self.bg_concat_num = bg_concat_num 
        if self.bg_concat_num <= 0:
            raise ValueError("bg_concat_num [{}] should bigger than 0".format(self.bg_concat_num))
        self.mask_num = mask_num
        self.mask_in = mask_in 
        self.bg_in = bg_in 
        self.name = name
        if name is None:
            logging.warning("the class_name does not be set. the default class_name is [{}]!".format(name))
            self.name = "object"

        self.label_map_file = label_map_file
        self.label_map =  None
        if self.label_map_file is not None:
            self.label_map = dataset_util.load_label_map(self.label_map_file)
        self.whole_image_random = whole_image_random
        self.space = space 
        if self.space <= 0:
            raise ValueError("space [{}] should bigger than 0".format(self.space))

        self.CONCAT_WIDTH = concat_width 
        self.CONCAT_HEIGHT = concat_height 
        self.BOUNDARY = boundary 
        self.debug = False 
        self.bg_packages = self.get_bg_packages()
        self.mask_list = []
        if self.mask_in:
            self.mask_list = io.get_image_list(self.mask_in)
            if len(self.mask_list) == 0:
                logging.warning("the number of mask file is 0!")
            random.shuffle(self.mask_list)
        self.bg_ceil_size = self.get_ceil_size(self.bg_concat_num)
        self.mask_ceil_size = {}
        if not self.whole_image_random:
            self.mask_ceil_size = self.get_ceil_size(self.mask_num)

    def __call__(self, sample=None, idx=None):
        """ Process a sample
        Args:
            sample (dict or list): 标准格式 单个或多个eg: 
            idx: 记录处理次数
        Returns:
            result (dict or list): a processed sample
                   需填充image 字段进行增广图保存
        """
        annotations = []
        if not sample and not self.mask_in or not self.bg_in:
            logging.warning("the number of sample is 0 or bg is 0")
            return annotations
        if idx >= len(self.bg_packages):
            return annotations
        bg_pkg = self.bg_packages[idx]
        mask_pkg = self.get_mask_pkg(mask_annos=sample, idx=idx)
        annotations = self.paste_mask_on_bg(mask_pkg=mask_pkg, bg_pkg=bg_pkg)
        transform_util.print_processed(self.get_pre_fix(), float(idx + 1) / len(self.bg_packages))
        return annotations 

    def get_bg_packages(self):
        """将背景按拼接数量打包"""
        bg_packages = []
        bg_list = []
        if self.bg_in is not None:
            bg_list = io.get_image_list(self.bg_in)
            if len(bg_list) == 0:
                logging.warning("the number of background file is 0!")
                return bg_packages
            random.shuffle(bg_list)
        bg_packages = [bg_list[i:i + self.bg_concat_num] for i in range(0, len(bg_list), self.bg_concat_num)]
        return bg_packages

    def get_mask_pkg(self, mask_annos, idx):
        """将mask按拼接数量打包"""
        mask_pkg = []
        if self.mask_list:
            i = (idx * self.mask_num) % len(self.mask_list)  
            mask_pkg = self.mask_list[i: i + self.mask_num]
        elif mask_annos:
            i = (idx * self.mask_num) % len(mask_annos)  
            mask_pkg = mask_annos[i: i + self.mask_num]
        return mask_pkg

    def paste_mask_on_bg(self, mask_pkg, bg_pkg):
        """粘贴mask到背景

        Args:
            mask_pkg: mask 打包数据 
            bg_pkg: 背景打包数据

        Returns:
            bool: 成功返回True 
                  参数非法返回False
        """

        w_min = self.BOUNDARY 
        w_max = self.CONCAT_WIDTH - self.BOUNDARY 
        h_min = self.BOUNDARY 
        h_max = self.CONCAT_HEIGHT - self.BOUNDARY 

        #print("\033[33m" + 40 * "-" + " Processing mask paster " + 40 * "-" + "\033[37m")
        annotations = []
        # 拼接背景图像
        concated_image = self.concated_images_by_list(bg_pkg)
        cat_shape = concated_image.shape
        bg_height = cat_shape[0]
        bg_width = cat_shape[1]
        # 读取mask
        pasted_img = copy.deepcopy(concated_image)
        anno = {}
        bndboxes = []
        if self.mask_ceil_size:
            paste_pos = self.mask_ceil_size["paste_pos"]
            random.shuffle(paste_pos)
        for i in range(len(mask_pkg)):
            try:
                mask_file = None
                mask_info = mask_pkg[i]
                name = self.name
                boxes = []
                if isinstance(mask_info, str):
                    mask_file = mask_info 
                elif isinstance(mask_info, dict):
                    mask_file = mask_info["image_file"]
                    if "bndboxes" in mask_info:
                        boxes = mask_info["bndboxes"]
                    if "label" in mask_info and self.label_map:
                        for n, l in self.label_map.items():
                            if mask_info["label"] == l:
                                name = n

                mask_img = io.cv_imread_and_check(mask_file)
                if mask_img is None:
                    continue
                # 根据拼接背景大小缩放mask
                rescaled_mask_img = self.rescale_mask(mask_img, cat_shape, mask_img.shape)
                h_ratio = float(rescaled_mask_img.shape[0]) / mask_img.shape[0]
                w_ratio = float(rescaled_mask_img.shape[1]) / mask_img.shape[1]

                # 增广mask
                aug_res = self.augment(rescaled_mask_img, boxes, h_ratio, w_ratio)
                mask_aug = aug_res["image_aug"]
                segmap_aug = aug_res["segmap_aug"]
                bbs_aug = aug_res["bbs_aug"]
                # 获取增广后的前景区域
                version = int(cv2.__version__.split(".")[0])
                if version == 3:
                    _, contours, hierarchy = cv2.findContours(segmap_aug, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
                elif version == 2 or version == 4:
                    contours, hierarchy = cv2.findContours(segmap_aug, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
                areas = []
                for cnt in contours:
                    areas.append(cv2.contourArea(cnt))
                max_idx = np.argmax(np.array(areas))
                # cv2.drawContours(segmap_aug, contours, max_idx, 255, cv2.FILLED)
                # 剪切变换后的mask
                x, y, w, h = cv2.boundingRect(contours[max_idx])
                after_mask = copy.deepcopy(segmap_aug[y:y + h, x:x + w])
                #after_mask = after_mask * 255
                after_mask_aug = copy.deepcopy(mask_aug[y:y + h, x:x + w])

                # 取反
                mask_inv = cv2.bitwise_not(after_mask)
                #cv2.drawContours(mask, contours, max_idx, 0, cv2.FILLED)

                '''
                image_after = bbs_aug.draw_on_image(mask_aug, size=2, color=[0, 0, 255])
                ia.imshow(image_after)
                '''

                # mask 粘贴位置
                mask_height, mask_width = after_mask.shape
                
                # 整张图位置随机
                if self.whole_image_random:
                    xmin = random.randint(w_min, w_max - mask_width) 
                    ymin = random.randint(h_min, h_max - mask_height) 
                    xmax = min(xmin + mask_width, bg_width) 
                    ymax = min(ymin + mask_height, bg_height) 
                # 根据mask数量按区域随机
                else:
                    mask_ceil_height = self.mask_ceil_size["height"]
                    mask_ceil_width = self.mask_ceil_size["width"]
                    n = self.mask_ceil_size["num"]
                    # 顺序
                    # row_idx = i // n 
                    # col_idx = i % n 
                    # 随机
                    row_idx = paste_pos[i][0]
                    col_idx = paste_pos[i][1]
                    x_start = w_min + col_idx * mask_ceil_width
                    x_end = min(x_start + int(mask_ceil_width / self.space), w_max - mask_width)
                    if x_start >= x_end:
                         x_start = x_end - 1
                    xmin = random.randint(x_start, x_end) 

                    y_start = h_min + row_idx * mask_ceil_height
                    y_end = min(y_start + int(mask_ceil_height / self.space), h_max - mask_height)
                    if y_start >= y_end:
                         y_start = y_end - 1
                    ymin = random.randint(y_start, y_end)
                             
                    xmax = min(xmin + mask_width, bg_width) 
                    ymax = min(ymin + mask_height, bg_height) 
                  

                paste_roi = pasted_img[ymin:ymax, xmin:xmax]
                
                fg_roi = cv2.bitwise_and(after_mask_aug, after_mask_aug, mask=after_mask)
                bg_roi = cv2.bitwise_and(paste_roi, paste_roi, mask=mask_inv)
                dst = cv2.add(bg_roi, fg_roi)
                pasted_img[ymin:ymax, xmin:xmax] = dst

                '''
                '''
                # bbs适配剪切后的mask 
                if bbs_aug:
                    for box in bbs_aug: 
                        bndboxes.append({
                            "xmin": int(box.x1) + xmin - x,
                            "ymin": int(box.y1) + ymin - y,
                            "xmax": int(box.x2) + xmin - x,
                            "ymax": int(box.y2) + ymin - y,
                            "name": box.label 
                            })
                bndboxes.append({
                    "xmin": xmin,
                    "ymin": ymin,
                    "xmax": xmax,
                    "ymax": ymax,
                    "name": name 
                })

                # debug
                if self.debug:
                    save_path = "debug"
                    io.make_path(save_path)
                    cv2.imwrite(os.path.join(save_path, "concated_image.jpg"), concated_image)
                    cv2.imwrite(os.path.join(save_path, "rescaled_mask_img.jpg"), rescaled_mask_img)
                    cv2.imwrite(os.path.join(save_path, "mask_aug.jpg"), mask_aug)
                    cv2.imwrite(os.path.join(save_path, "mask.jpg"), after_mask)
                    cv2.imwrite(os.path.join(save_path, "mask_inv.jpg"), mask_inv)
                    cv2.imwrite(os.path.join(save_path, "paste_roi.jpg"), paste_roi)
                    cv2.imwrite(os.path.join(save_path, "bg_roi.jpg"), bg_roi)
                    cv2.imwrite(os.path.join(save_path, "fg_roi.jpg"), fg_roi)
                    cv2.rectangle(pasted_img, (xmin, ymin), (xmax, ymax), (0, 0, 255), 4)
                    cv2.rectangle(pasted_img, (w_min, h_min), \
                            (w_max - mask_width, h_max - mask_height), (0, 255, 0), 2)
                    cv2.imwrite(os.path.join(save_path, "pasted_img.jpg"), pasted_img)
            except Exception as e:
                traceback.print_exc()
                continue
        if bndboxes:
            anno["image_file"] = self.get_unique_name(pasted_img)
            anno["image"] = pasted_img
            anno["height"] = cat_shape[0]
            anno["width"] = cat_shape[1]
            anno["bndboxes"] = bndboxes
        annotations.append(anno)

        #print("\033[33m" + 110 * "-" + "\n\033[37m")
        return annotations

    def concated_images_by_list(self, bg_pkg):
        """拼接背景图像
        Args:
            bg_pkg: 待拼接背景图像路径列表 

        Returns:
            cv2 numpy 拼接好图片
        """

        bg_concat_num = len(bg_pkg)
        every_width = self.bg_ceil_size["width"] 
        every_height = self.bg_ceil_size["height"] 
        n = self.bg_ceil_size["num"]
        concated_image=np.zeros((self.CONCAT_HEIGHT, self.CONCAT_WIDTH, 3), np.uint8)

        for i in range(bg_concat_num):
            image_file = bg_pkg[i]
            image = io.cv_imread_and_check(image_file)
            if image is None:
                continue
            norm_image = cv2.resize(image, (every_width, every_height))
            row_idx = i // n 
            col_idx = i % n 
            concated_image[row_idx * every_height:(row_idx + 1) * every_height, \
                           col_idx * every_width:(col_idx + 1) * every_width] = norm_image 
        return concated_image

    def rescale_mask(self, mask_img, cat_shape, mask_img_shape):
        """根据背景图像大小保持比例缩放mask
        Args:
            mask_img: mask 图像 
            cat_shape: 背景拼接图像大小(height, width)
            mask_img_shape: mask图像大小(height, width)

        Returns:
            cv2 numpy 缩放好的图片
        """
        bg_height = cat_shape[0]
        bg_width = cat_shape[1]
        mask_img_height = mask_img_shape[0]
        mask_img_width = mask_img_shape[1]
        ori_ratio = mask_img_width / float(mask_img_height)
        DOUBLE = 2 * self.BOUNDARY
        if ori_ratio > 1:
            mask_img_width = bg_width - DOUBLE
            mask_img_height = int(mask_img_width / ori_ratio)
        else:
            mask_img_height = bg_height - DOUBLE - 1
            mask_img_width = int(mask_img_height * ori_ratio)
        '''
        DOUBLE = 2 * self.BOUNDARY
        if mask_img_width >= bg_width - DOUBLE:
            mask_img_width = bg_width - DOUBLE - 1
            mask_img_height = int(mask_img_width / ori_ratio)
        if mask_img_height >= bg_height - DOUBLE:
            mask_img_height = bg_height - DOUBLE - 1
            mask_img_width = int(mask_img_height * ori_ratio)
        '''
        rescaled_mask_img = cv2.resize(mask_img, (mask_img_width, mask_img_height), interpolation=cv2.INTER_NEAREST)

        return rescaled_mask_img

    def augment(self, image=None, boxes=[], h_ratio=1.0, w_ratio=1.0):
        """增广mask图像
        Args:
            image: 待增广图像 

        Returns:
            image_aug 增广后的图片
            segmap_aug 增广后的mask
            bbs_aug 增广后的boundingbox
        """
        conf = conf_sequential.Conf()
        seq = conf.get_user_sequential()
        seed = random.randint(0, 1000)
        ia.seed(seed)
        # 准备粘贴mask
        image_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        # fb is 1, bg is 0 
        _, segmap = cv2.threshold(image_gray, 0, 1, cv2.THRESH_BINARY)
        #ia.imshow(segmap)

        # 图像开运算 erode->dilate
        kernel = np.ones((3, 3), np.uint8)
        segmap = cv2.morphologyEx(segmap, cv2.MORPH_OPEN, kernel)
        #ia.imshow(segmap)

        '''
        bbs = BoundingBoxesOnImage([
            BoundingBox(x1=0, y1=0, x2=image.shape[1], y2=image.shape[0]),
        ], shape=image.shape)
        '''
        segmap = SegmentationMapsOnImage(segmap, shape=image.shape)
        bndboxes = []
        if boxes:
            for box in boxes:
                bndboxes.append(BoundingBox(
                        x1 = box["xmin"] * w_ratio,
                        y1 = box["ymin"] * h_ratio,
                        x2 = box["xmax"] * w_ratio,
                        y2 = box["ymax"] * h_ratio,
                        label = box["name"]))

        bbs = BoundingBoxesOnImage(bndboxes, shape=image.shape)
        image_aug, segmap_aug, bbs_aug = seq(image=image,
                                    segmentation_maps=segmap,
                                    bounding_boxes=bbs)
        #empty_image = np.zeros((image_aug.shape[0], image_aug.shape[1]), dtype=np.uint8)
        empty_image = np.zeros(image_aug.shape, dtype=np.uint8)
        segmap_aug = segmap_aug.draw_on_image(empty_image)[0]
        _, segmap_aug = cv2.threshold(segmap_aug[:, :, 0], 0, 255, cv2.THRESH_BINARY)
        #print(segmap_aug[:,:,0] == segmap_aug[:,:,1])
        #segmap_aug = cv2.cvtColor(segmap_aug, cv2.COLOR_BGR2GRAY)
        #ia.imshow(segmap_aug)

        return {"image_aug": image_aug,
                "segmap_aug": segmap_aug,
                "bbs_aug": bbs_aug}

    def get_ceil_size(self, num):
        """根据拼接数量返回每个子图大小
        Returns:
            子图大小及开方后个数
        """

        n = math.ceil(math.sqrt(num)) # n * n concat images
        every_width = self.CONCAT_WIDTH // n 
        every_height = self.CONCAT_HEIGHT // n 
        paste_pos = [(i, j) for i in range(n) for j in range(n)] 
        return {"num": n,
                "height": every_height,
                "width": every_width,
                "paste_pos": paste_pos}
