# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了一个单图数据增广类。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/03/03 13:06:46
"""

import numpy as np
from imgaug.augmentables.bbs import BoundingBox, BoundingBoxesOnImage
from imgaug.augmentables import Keypoint, KeypointsOnImage
from imgaug.augmentables.batches import UnnormalizedBatch
from conf import conf_sequential
import os
import traceback
import random
import logging
from utils import io, log
from transform import base_operator

conf = conf_sequential.Conf()
sequential = conf.get_default_sequential()

class Augmentater(base_operator.BaseOperator):
    """单图数据增广类"""
    def __init__(self, processes, task_name="detection", aug_num=1, safe_mode=False, keypoints_num=4):
        """初始化"""
        super(Augmentater, self).__init__()
        log.init_log(os.path.join("log", os.path.basename(__file__).split(".")[0]))
        self.processes = processes     # the number of precessing 

        # the augmentated number for single image
        self.aug_num = aug_num               

        # task setting 
        self.support_task = ["classification", "detection", "keypoints", "detection_with_keypoints"]
        self.task_name = task_name
        self.safe_mode = safe_mode 

        # processing the bounding box out of image
        self.remove_outside_bndbox_method = "fraction"
        self.outside_bndbox_fraction_rate = 0.9
        """ direct: Remove all BBs that are fully outside of the image.
            clip: Remove all BBs that are fully outside of the image and partially outside is clip by image boundary.
            fraction: Remove all BBs with an out of image fraction of at least fraction_rate and clip by image boundary.
        """
        self.support_bndbox_remove_method = ["direct", "clip", "fraction"]

        # keypoint setting
        self.keypoints_num = keypoints_num 
        if "keypoints" in self.task_name:
            logging.info("Reminding: don't forget set the number of keypoints! [default={}]".format(self.keypoints_num))
         
        # member of batch
        self.images = []              # the list of images [type:numpy]
        self.bndboxes = []            # the list of bnding boxes of images
        self.keypoints = []           # the list of keypoints of images
        self.batches = None           # the batches for augmentation 
        self.annotations = []         # the annotations of images 

        # switch for drawing annotation on augmented images
        self.draw_anno = False

    def __call__(self, sample=None, idx=None):
        """ Process a sample.
        Args:
            sample (dict or list): 标准格式 单个或多个eg: 
                      {"image_file": "图像文件绝对路径 (required)",
                        "width": "图像宽 int", 
                        "height": "图像高 int",
                        "image": "opencv格式(optional)",
                        "bndboxes":[
                          { "xmin": "左上x int",
                            "ymin": "左上y int",
                            "xmax": "右下x int",
                            "ymax": "右下y int",
                            "name": "类别名"
                          },  #(optional-检测任务)
                        ], 
                        "keypoints": [
                          {"points": [{
                            "x": "x坐标 int", 
                            "y": "y坐标 int",
                            },]
                          }, 
                        ], #(optional-关键点检测任务)
                        "label": "(optional-分类任务)"
                      }

            context (dict or list): 根据需求填充 
        Returns:
            result (dict or list): a processed sample
                   需填充image 字段进行增广图保存
        """
        annotations = []
        if self.make_batches(sample):
            annotations = self.multicore_process()
        return annotations 

    def set_aug_num(self, aug_num):
        """设置单张图增广后数量
        [default] = 1 

        Args:
            aug_num: 单张图增广数量

        Returns:
            bool: 成功返回True 
                  参数非法返回False
        """
        if aug_num < 1: 
            logging.error("augmented image number should be bigger than 1")
            return False
        self.aug_num = aug_num
        return True

    def set_task_name(self, task_name):
        """设置任务名称
        支持的任务类型: ["classification", "detection", "keypoints", "detection_with_keypoints"]
        [default] = "classification"

        Args:
            task_name: 任务名称 

        Returns:
            bool: 成功返回True 
                  参数非法返回False
        """
        if task_name not in self.support_task:
            logging.error(("<{}> task is not supported now! support task {}".format(self.task_name, self.support_task)))
            return False 
        self.task_name = task_name
        return True

    def set_keypoints_num(self, num):
        """设置关键点个数
        [default] = 4

        Args:
            num: 关键点个数 

        Returns:
            bool: 成功返回True 
                  参数非法返回False
        """
        if num < 1: 
            logging.error("number of keypoints should be bigger than 1")
            return False
        self.keypoints_num = num
        return True

    def set_remove_outside_bndbox_method(self, method):
        """设置越界bounding box 处理方法
        支持的处理方法: ["direct", "clip", "fraction"]
        direct: 移除完全越界的bonding box, 部分越界的不做处理直接输出; 
        clip: 移除完全越界的bonding box, 部分越界的基于图像边界进行剪切;
        fraction: 移除完全越界和越界比例大于fraction_rate的bonding box, 部分越界的基于图像边界进行剪切;
        [default] = "fraction" 

        Args:
            method: 越界bounding box处理方法 

        Returns:
            bool: 成功返回True 
                  参数非法返回False
        """
        if method not in self.support_bndbox_remove_method:
            logging.error("does not support {} method! support support_bndbox_remove_method={}"\
                    .format(method, self.support_bndbox_remove_method))
            return False
        if method == "fraction":
            logging.info("Reminding: the fraction_rate is {} that can satisfy your requirement?\
                    You can change by set_outside_bndbox_fraction_rate()".format(self.outside_bndbox_fraction_rate))
        self.remove_outside_bndbox_method = method 
        return True
    
    def set_outside_bndbox_fraction_rate(self, fraction_rate):
        """设置"fraction"越界bounding box方法的比例
        [default] = 0.9 

        Args:
            fraction_rate: 越界比例 

        Returns:
            bool: 成功返回True 
                  参数非法返回False
        """
        if fraction_rate < 0 or fraction_rate > 1:
            logging.error("unvalid fraction {}".format(fraction_rate))
            return False 
        self.outside_bndbox_fraction_rate = fraction_rate
        return True

    def make_fake_bndbox(self, image_shape, label):
        """为分类和关键点任务构造默认bounding box存储图像路径和label
        [default] = 4

        Args:
            image_shape: 图像的shape 
            label: 图像路径和标签信息 

        Returns:
            bbs
        """
        bbs = BoundingBoxesOnImage([
            BoundingBox(x1=image_shape[1]/4,
                        y1=image_shape[0]/4,
                        x2=image_shape[1]/2,
                        y2=image_shape[0]/2,
                        label=label),], shape=image_shape)
        return bbs

    def parse_anno_for_classification(self):
        """解析分类任务标注文件
        读取图像和并构造假的bounding box
        """
        for single_anno in self.annotations:
            if "image_file" not in single_anno and "lable" not in single_anno:
                continue
            image_path = single_anno["image_file"]
            if not os.path.exists(image_path):
                logging.warning("{} does not exists!".format(image_path))
                continue
            label = single_anno["label"]
            image = io.cv_imread_and_check(image_path)
            if image is None:
                logging.info("cv2 read image [{}]fail!".format(image_path))
                continue
            image_shape = image.shape
            image_name = os.path.basename(image_path)

            bbs = self.make_fake_bndbox(image_shape, str(label) + " " + image_name)
            self.images.append(image)
            self.bndboxes.append(bbs)

    def parse_bndbox(self, single_anno):
        """解析bounding box

        Args:
            single_anno: 图像的标注信息

        Returns:
            成功: 返回BoudingBox实例
            失败：返回[]
        """
        bndboxes = []
        if "bndboxes" not in single_anno:
            logging.info("does not contain bndbox! [{}]".format(single_anno))
            return bndboxes 
        boxes = single_anno["bndboxes"]
        if len(boxes) == 0:
            logging.info("number of bndbox is 0! [{}]".format(single_anno))
            return bndboxes

        for bndbox in boxes:
            name = bndbox["name"]
            bndboxes.append(BoundingBox(
                               x1=bndbox["xmin"],
                               y1=bndbox["ymin"],
                               x2=bndbox["xmax"],
                               y2=bndbox["ymax"],
                               label=name + " " + os.path.basename(single_anno["image_file"])))
        return bndboxes

    def parse_keypoints(self, single_anno):
        """解析关键点

        Args:
            single_anno: 图像的标注信息

        Returns:
            list: 成功返回points
                  失败返回[]
        """
        keypoints = [] 
        if "keypoints" not in single_anno:
            logging.info("does not contain keypoints! [{}]".format(single_anno))
            return keypoints 
        kps = single_anno["keypoints"]
        if len(kps) == 0:
            logging.info("the number of keypoints is 0! [{}]".format(single_anno))
            return keypoints 
        for kp in kps:
            pts = kp["points"]
            real_kps_num = len(pts)
            if real_kps_num != self.keypoints_num:
                logging.error("The set kps num {} is not equal real kps num {}" \
                        .format(self.keypoints_num, real_kps_num))
                return keypoints
            for pt in pts:
                #keypoints.append(Keypoint(x=int(pt["x"]), y=int(pt["y"])))
                keypoints.append(Keypoint(x=pt["x"], y=pt["y"]))
        return keypoints 

    def parse_anno_for_detection_with_keypoints(self):
        """解析目标检测和关键点检测标注文件
        读取图像、bounding box、joints
        """
        for single_anno in self.annotations:
            if "image_file" not in single_anno \
                    and "bndboxes" not in single_anno\
                    and "keypoints" not in single_anno:
                logging.info("annotation lack key! [{}]".format(single_anno))
                continue

            image_path = single_anno["image_file"]
            if not os.path.exists(image_path):
                logging.warning("{} does not exists!".format(image_path))
                continue
            image = io.cv_imread_and_check(image_path)

            if image is None:
                logging.info("cv2 read image [{}]fail!".format(image_path))
                continue
            image_shape = image.shape
            image_name = os.path.basename(image_path)

            bndboxes = []
            keypoints = [] 
            # bounding box
            bndboxes = self.parse_bndbox(single_anno)
            # keypoints 
            keypoints = self.parse_keypoints(single_anno)

            # bounding box
            bbs = self.make_fake_bndbox(image_shape, image_name)
            if len(bndboxes) > 0:
                bbs = BoundingBoxesOnImage(bndboxes, shape=image_shape)
            self.bndboxes.append(bbs)

            # keypoints 
            kps = KeypointsOnImage(keypoints, shape=image.shape)
            self.keypoints.append(kps)
            self.images.append(image)

    def make_batches(self, annotations):
        """根据不同任务构造批处理列表

        Args:
            annotations: 解析后的annotations 

        Returns:
            bool: 成功返回True 
                  参数非法返回False
        """
        try:
            #logging.info("The task_name is <{}>".format(self.task_name))
            if not annotations:
                logging.error("annotations is empty!")
                return False 

            # 输入为单个样本
            self.annotations = [annotations]
            if self.annotations is not None:
                if self.task_name == "classification":
                    self.parse_anno_for_classification()
                    self.batches = [UnnormalizedBatch(images=self.images,
                                                     bounding_boxes=self.bndboxes) for _ in range(self.aug_num)]
                else:
                    self.parse_anno_for_detection_with_keypoints()
                    if self.task_name == "detection":
                        self.batches = [UnnormalizedBatch(images=self.images,
                                                         bounding_boxes=self.bndboxes) for _ in range(self.aug_num)]

                    if self.task_name == "keypoints" or \
                            self.task_name == "detection_with_keypoints":
                        self.batches = [UnnormalizedBatch(images=self.images,
                                                         bounding_boxes=self.bndboxes, 
                                                         keypoints=self.keypoints) for _ in range(self.aug_num)]
            return True
        except Exception as e:
            traceback.print_exc()

    def create_generator(self, lst):
        """创建生成器

        Args:
            lst: 迭代器列表  

        """
        for list_entry in lst:
            yield list_entry

    def modify_label(self, bbs_aug):
        """解析图像增广后的bounding box获取图像名称和类别名

        Args:
            bbs_aug: 增广后的bounding box 

        Returns:
            image_name: 图像名 
            modified_bbs_aug: 修改bounding box的类别名 
        """
        modified_bbs_aug = bbs_aug 
        image_name = None
        for single_bndbox in modified_bbs_aug:
            dec_info = single_bndbox.label.split(" ")
            label = None
            if len(dec_info) == 1:
                image_name = dec_info[0]
            elif len(dec_info) == 2:
                label = dec_info[0]
                image_name = dec_info[1]
            #bndbox = single_bndbox.deepcopy()
            single_bndbox.label = label
            #modified_bbs_aug.append(bndbox)
        return image_name, modified_bbs_aug 

    def draw_on_image(self, showimg, kps_aug, bbs_aug, save_file):
        """在增广后的图像上显示标注

        Args:
            showimg: 显示图像 
            kps_aug: 增广后的关键点 
            bbs_aug: 增广后的bounding box 
            save_file: 存储名称 
        """
        if kps_aug is not None:
            showimg = kps_aug.draw_on_image(showimg)
        if bbs_aug is not None:
            showimg = bbs_aug.draw_on_image(showimg)
        #showimg = showimg[..., ::-1]
        io.cv_imwrite(save_file, showimg)

    def process_outside_bndbox(self, bbs):
        """根据越界bounding box处理方法进行处理

        Returns:
            bbs: 处理后的bounding box 
        """
        if self.remove_outside_bndbox_method == "direct":
            bbs = bbs.remove_out_of_image()
        elif self.remove_outside_bndbox_method == "clip":
            bbs = bbs.remove_out_of_image().clip_out_of_image()
        elif self.remove_outside_bndbox_method == "fraction":
            bbs = bbs.remove_out_of_image_fraction(self.outside_bndbox_fraction_rate).clip_out_of_image()
        return bbs

    def convert_to_stand_format(self, batches_aug):
        """存储增广后的图像和标注文件
        存储路径: <save_path>/<task_name>/<type>

        type:
            增广图片: augmentated_images
            关键点: keypoints
            bounding box: bndboxes
            增广图片显示标注: draw_images

        classification: 按照类别名存储

        注:
           标注越界:
           bounding box 提供了越界处理方法供选
           joints 未提供越界处理办法，若去除后会影响关键点顺序, 由使用方处理越界点。 

        Args:
            batches_aug: 增广后的信息 
        """
        annotations = []
        for i, batch_aug in enumerate(batches_aug):
            for j in range(len(batch_aug.images_aug)):
                image_name, modified_bbs_aug  = self.modify_label(batch_aug.bounding_boxes_aug[j])
                aug_image = batch_aug.images_aug[j]
                kps_aug = None
                bbs_aug = None
                anno = {}
                if "classification" in self.task_name:
                    label = modified_bbs_aug[0].label
                    anno["label"] = label

                if "keypoints" in self.task_name:
                    kps_aug = batch_aug.keypoints_aug[j]
                    kps_num = len(kps_aug)
                    keypoints = []
                    points = []
                    for idx in range(kps_num):
                        point = kps_aug[idx]
                        points.append({"x": point.x, "y": point.y})
                        if (idx + 1) % self.keypoints_num == 0:
                            keypoints.append({"points": points})
                            points = []
                    if keypoints:
                        anno["keypoints"] = keypoints

                if "detection" in self.task_name:
                    bbs_aug = self.process_outside_bndbox(modified_bbs_aug)
                    bndboxes = []
                    for box in bbs_aug:
                        bndboxes.append({
                            "xmin": box.x1,
                            "ymin": box.y1,
                            "xmax": box.x2,
                            "ymax": box.y2,
                            "name": box.label
                        })
                    if bndboxes:
                        anno["bndboxes"] = bndboxes

                if not anno:
                    continue

                anno["image_file"] = self.get_unique_name(aug_image)
                shape = aug_image.shape
                anno["image"] = np.copy(aug_image)
                anno["height"] = shape[0] 
                anno["width"] = shape[1] 
                #io.cv_imwrite(save_file, aug_image[..., ::-1])
                #io.cv_imwrite(save_file, aug_image)

            annotations.append(anno)
        return annotations 

    def multicore_process(self):
        """多进程进行数据增广
        根据设置的进程数量和打包好的批量标注信息进行多进程增广
        """
        my_generator = self.create_generator(self.batches)
        seed = random.randint(0, 1000)
        #seed = 10
        annotations = []
        with sequential.pool(processes=self.processes, seed=seed) as pool:
            #batches_aug = pool.imap_batches(my_generator)
            if self.safe_mode:
                batches_aug = pool.map_batches(self.batches)
            else:
                batches_aug = pool.imap_batches_unordered(my_generator)
            #self.save_aug_image_and_anno(batches_aug)
            annotations.extend(self.convert_to_stand_format(batches_aug))
        return annotations
