# PaddleDetection
- github  
      https://github.com/PaddlePaddle/PaddleDetection
- paddle安装  
      https://www.paddlepaddle.org.cn/install/quick
- 配置  
    将“task”文件夹放到“PaddleDetection”路径下，如：{path}/PaddleDetection/task

## [train]

### 一、自动训练
#### 1、数据准备
    将整理好的VOC格式数据放到"dataset/voc"路径下，如：数据文件夹名称为“yourdata”
#### 2、配置文件
    根据需求选取合适检测网络配置文件，如：“configs/dcn/yolov3_r50vd_dcn_db_iouloss_obj365_pretrained_coco.yml”
#### 3、执行脚本
    sh task/script.sh auto_train {cfg} {yourdata}
### 二、分步进行
#### 1. 数据准备
    整理好的VOC格式数据放到"dataset/voc"路径下,执行下述脚本生成训练数据和验证数据

    sh task/script.sh data {yourdata}

    执行上面脚本后，会在{yourdata}所在目录生成，“train.txt、eval.txt、label_list.txt”
    注：默认训练和验证数据比例9：1

#### 2. 配置文件修改
    配置文件修改详见PaddleDetecion官方使用文档。
    由于官方版本默认使用coco数据格式，现通过下述脚本给定数据信息自动修改配置文件中数据相关的设置，来支持VOC数据格式。

    sh task/script.sh cfg {cfg} {yourdata}

    执行上面脚本后，会在"task"路径下生成支持VOC格式输入的配置文件
    如：cfg=configs/dcn/yolov3_r50vd_dcn_db_iouloss_obj365_pretrained_coco.yml
    会在task路径下生成,task/configs/dcn/yolov3_r50vd_dcn_db_iouloss_obj365_pretrained_coco.yml

#### 3. 训练
    sh task/script.sh train {cfg}
    如果是通过上面分步进行，cfg为task路径下修改过的cfg
    若已手动修改过cfg，则直接指定手动修改过的cfg即可。

## [eval]
    训练结束后，可以通过以下脚本进行批量评估
    sh task/script.sh infer {cfg} {infer_dir} {weights}
    infer_dir 为评估图像的根目录

## [deploy]
    模型达到预期后，需要对训练好的模型进行参数冻结，冻结后的模型会有一定程度的速度提升

    sh task/script.sh freeze {cfg} {weights}

    模型参数冻结后，可以通过下面脚本进行测试，测试的同时也可以验证冻结前后模型的检测结果是否一致。
    sh task/script.sh deploy {model_dir} {image_file}

    上线的模型部署可以参考"deploy/python/infer.py"，进行封装或修改。

## [note]
    执行sh task/script.sh  打印功能
    <生成训练、验证文件列表及标签列表>
    sh task/script.sh data {yourdata}

    <生成支持voc格式训练数据的配置文件, 存储到task路径下>
    sh task/script.sh cfg {cfg} {yourdata}

    <训练>
    sh task/script.sh train {cfg}

    <自动训练>
    sh task/script.sh auto_train {cfg} {yourdata}

    <评估>
    sh task/script.sh infer {cfg} {infer_dir} {weights}

    <冻结模型参数>
    sh task/script.sh freeze {cfg} {weights}

    <使用冻结模型进行预测>
    sh task/script.sh deploy {model_dir} {image_file}

## [tensorrt]
迭代工具中自动拷贝依赖库，部署时需将lib和set_env.sh拷到部署环境中
   ### 1. 说明
   - paddle版本1.8以上，安装时建议使用conda
   - tensorrt版本需与cuda、paddle版本兼容
   - glibc版本2.14以上
   ### 2. 环境配置
   - paddle=1.8.5、CUDA=10.0，cuDNN=7.3+（自行安装）
   - tensorrt=6.0.1.5、glibc=2.14

   ### 3. batch测试
    paddle检测模型模型默认支持batch_size=1，为了测试batchsize > 1，单gpu加速和tensorrt加速需修改代码以支持batch输入
    在"deploy/python/infer.py" create_inputs函数中进行修改.
   :bug::bug::bug:***经测试后，检测模型tensorrt加速时不支持batch输入。但可以测试单gpu在batch输入时的加速情况***
   - 第一处
   ```python
   inputs['image'] = im
   ```
   修改为
   ```python
   batch_size = 10
   im = np.repeat(im, batch_size, axis=0).copy()
   inputs['image'] = im
   ```
   - 第二处
   ```python
   if 'YOLO' in model_arch:
       im_size = np.array([origin_shape]).astype('int32')
   ```
   修改为
   ```python
   if 'YOLO' in model_arch:
       im_size = np.array([origin_shape for i in range(batch_size)]).astype('int32')
   ```
   ### 4. 运行
   ```bash
   sh task/test_ppdet_with_trt.sh
   ```
