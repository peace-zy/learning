# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了paddle检测配置文件修改以voc格式训练数据。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/08/10 10:00:00
"""

import os, sys
# add python path of PadleDetection to sys.path
parent_path = os.path.abspath(os.path.join(__file__, *(['..'] * 2)))
if parent_path not in sys.path:
    sys.path.append(parent_path)

from ppdet.core.workspace import load_config, merge_config, create, AttrDict

from ppdet.utils.cli import ArgsParser
from ppdet.utils.check import check_gpu, check_version, check_config
from ppdet.data.source.voc import VOCDataSet
from ppdet.data.source.dataset import * 
import yaml

def main():
    """main"""
    cfg = load_config(FLAGS.config)
    use_default_label = False 
    #with_background=True
    with_background = False

    '''
    class VOCDataSet(DataSet):
        Notes:
        `anno_path` must contains xml file and image file path for annotations.

        Args:
            dataset_dir (str): root directory for dataset.
            image_dir (str): directory for images.
            anno_path (str): voc annotation file path.
            sample_num (int): number of samples to load, -1 means all.
            use_default_label (bool): whether use the default mapping of
                label to integer index. Default True.
            with_background (bool): whether load background as a class,
                default True.
            label_list (str): if use_default_label is False, will load
                mapping between category and class index.
    '''
    cfg['metric'] = 'VOC'
    num_classes = 0
    label_list = os.path.join(FLAGS.image_dir, 'label_list.txt')
    train_anno_path = os.path.join(FLAGS.image_dir, 'train.txt')
    eval_anno_path = os.path.join(FLAGS.image_dir, 'eval.txt')
    with open(os.path.join(FLAGS.dataset_dir, label_list), 'r') as f:
        num_classes = len(f.readlines())
    if num_classes:
        cfg['num_classes'] = num_classes

    cfg['TrainReader']['dataset'] = VOCDataSet(
                 dataset_dir=FLAGS.dataset_dir,
                 image_dir=FLAGS.image_dir,
                 anno_path=train_anno_path,
                 sample_num=-1,
                 use_default_label=use_default_label,
                 with_background=with_background,
                 label_list=label_list)

    cfg['EvalReader']['dataset'] = VOCDataSet(
                 dataset_dir=FLAGS.dataset_dir,
                 image_dir=FLAGS.image_dir,
                 anno_path=eval_anno_path,
                 sample_num=-1,
                 use_default_label=use_default_label,
                 with_background=with_background,
                 label_list=label_list)

    '''
    class ImageFolder(DataSet):
        Args:
            dataset_dir (str): root directory for dataset.
            image_dir(list|str): list of image folders or list of image files
            anno_path (str): annotation file path.
            samples (int): number of samples to load, -1 means all
    '''
    cfg['TestReader']['dataset'] = ImageFolder(
            dataset_dir=FLAGS.dataset_dir,
            anno_path=label_list,
            with_background=with_background)

    merge_config(FLAGS.opt)
    pure_cfg = AttrDict()
    for k, v in cfg.items():
        if not v:
            continue
        pure_cfg[k] = v
    #print(pure_cfg)

    check_config(pure_cfg)
    if not FLAGS.save_path:
        pos = FLAGS.config.find('configs')
        subdir = os.path.dirname(FLAGS.config[pos:])
        FLAGS.save_path = os.path.join(os.path.dirname(__file__), '..', subdir)
        print(FLAGS.save_path)
    if not os.path.exists(FLAGS.save_path):
        os.makedirs(FLAGS.save_path)
    with open(os.path.join(FLAGS.save_path, os.path.basename(FLAGS.config)), 'w') as f:
        yaml_obj = yaml.dump(pure_cfg, f, allow_unicode=True, sort_keys=False)

if __name__ == '__main__':
    parser = ArgsParser()
    parser.add_argument('--dataset_dir', type=str, default='', help='dataset_dir')
    parser.add_argument('--image_dir', type=str, default='', help='image_dir')
    parser.add_argument('--save_path', type=str, default='', help='save_path')
    FLAGS = parser.parse_args()
    main()
