# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了voc格式训练集、测试集划分及label_list生成。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/08/10 10:00:00
"""

import os
import sys
import random
import traceback
import xml.etree.ElementTree as ET

def main():
    """main"""
    inpath = sys.argv[1]
    save_path = sys.argv[2]
    wlines = []
    FRATE = 0.9

    label_list=set([])
    for root, dirs, files in os.walk(inpath):
        if len(files) == 0 or 'JPEGImages' not in root:
            continue
        for f in files:
            try:
                image_file = os.path.join(root, f)
                non_post_fix = os.path.splitext(f)[0]
                rel_image_file = image_file[len(inpath) + 1:]

                xml_file = os.path.join(root.replace('JPEGImages', 'Annotations'), non_post_fix + ".xml") 
                rel_xml_file = xml_file[len(inpath) + 1:]

                if not os.path.exists(xml_file):
                    print ("{} does not exist!".format(xml_file))
                    continue
                tree = ET.parse(xml_file)
                objs = tree.findall('object')
                for obj in objs:
                    cls_name = obj.find('name').text.strip().rstrip()
                    label_list.add(cls_name)

                wlines.append("{} {}\n".format(rel_image_file, rel_xml_file))
            except Exception as e:
                traceback.print_exc()
                continue

    random.shuffle(wlines) 
    left = int(round(len(wlines) * FRATE + 0.5))
    train = wlines[:left]
    eval = wlines[left:]
    print('all_data = [{}], train_data = [{}], val_data = [{}], names = [{}]'.format(
                len(wlines), len(train), len(eval), len(label_list)))
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    with open(os.path.join(save_path, "label_list.txt"), "w") as f:
        for label in label_list:
            f.write('{}\n'.format(label))
    with open(os.path.join(save_path, "train.txt"), "w") as f:
        f.writelines(train)
    with open(os.path.join(save_path, "eval.txt"), "w") as f:
        f.writelines(eval)

    return
if __name__ == "__main__":
    main()
