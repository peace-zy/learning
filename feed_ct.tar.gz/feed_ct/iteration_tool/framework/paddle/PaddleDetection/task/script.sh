#!/bin/bash
set -e
export PYTHONPATH=$PYTHONPATH:.

function start()
{
    echo -e "\e[32m[ start    ]\e[0m $1"
}

function end()
{
    echo -e "\e[32m[       OK ]\e[0m $1"
}

function kill()
{
    ps -ef |grep tools/train.py |awk '{print $2}' |xargs -i kill -9 {}
}

dataset_dir=dataset/voc
# generate file list for training and validation
function gen_data()
{
    yourdata=$1
    start generate_train_eval
    python task/utils/generate_train_eval.py $dataset_dir/$yourdata $dataset_dir/$yourdata
    end generate_train_eval
}

# generate cfg file
function gen_cfg()
{
    cfg=$1
    yourdata=$2
    start generate_cfg
    python task/utils/generate_cfg.py -c $cfg \
                     --dataset_dir $dataset_dir \
                     --image_dir $yourdata
    end generate_cfg
}

# train
function train()
{
    start train
    CUDA_VISIBLE_DEVICES=3,5 python tools/train.py -c $1 \
                                                       --use_tb True --tb_log_dir train_log 
    end train
}

# auto train
function auto_train()
{
    cfg=$1
    yourdata=$2
    gen_data $yourdata
    gen_cfg $cfg $yourdata
    train task/$cfg
}

# eval with trained model
function infer()
{
    cfg=$1
    infer_dir=$2
    weights=$3
    output_dir=$4
    draw_threshold=0.1
    start infer 
    CUDA_VISIBLE_DEVICES=0 python -u tools/infer.py \
                    -c $cfg \
                    --infer_dir=$infer_dir \
                    --output_dir=$output_dir \
                    --draw_threshold=$draw_threshold \
                    -o weights=$weights
    end infer 
}

# freeze trained model
function freeze()
{
    cfg=$1
    weights=$2
    output_dir=$3
    start freeze
    CUDA_VISIBLE_DEVICES=0 python tools/export_model.py \
        -c $cfg \
        --output_dir=$output_dir \
        -o weights=$weights \
        #TestReader.inputs_def.image_shape=[3,416,416]
    end freeze
}

# inference with frozen model
function deploy()
{
    model_dir=$1
    image_file=$2
    start deploy 
    CUDA_VISIBLE_DEVICES=0 python deploy/python/infer.py \
                       --model_dir=$model_dir \
                       --image_file=$image_file \
                       --use_gpu True 
    end deploy 
}

function usage()
{
    echo -e """usage:\e[32m
        <生成训练、验证文件列表及标签列表>
        sh task/script.sh data {yourdata}
        
        <生成支持voc格式训练数据的配置文件, 存储到task路径下>
        sh task/script.sh cfg {cfg} {yourdata}

        <训练>
        sh task/script.sh train {cfg}

        <自动训练>
        sh task/script.sh auto_train {cfg} {yourdata}

        <评估>
        sh task/script.sh infer {cfg} {infer_dir} {weights}

        <冻结模型参数>
        sh task/script.sh freeze {cfg} {weights}

        <使用冻结模型进行预测>
        sh task/script.sh deploy {model_dir} {image_file}
        \e[0m
        """
}
#===========================
#   MAIN SCRIPT
#===========================

#yourdata=version_6_self_train
#cfg=configs/dcn/yolov3_r50vd_dcn_db_iouloss_obj365_pretrained_coco.yml

if [ $# -eq 0 ];
then
    usage
    exit
fi

func=$1
echo "run: "$func
if [ "$func" = "kill" ];then
    $func 
elif [ "$func" = "data" ];then
    yourdata=$2
    echo "param: "$yourdata
    gen_data $yourdata 
elif [ "$func" = "cfg" ];then
    cfg=$2
    yourdata=$3
    echo "param: "$cfg" "$yourdata
    gen_cfg $cfg $yourdata 
elif [ "$func" = "train" ];then
    cfg=$2
    echo "param: "$cfg
    $func $cfg
elif [ "$func" = "auto_train" ];then
    cfg=$2
    yourdata=$3
    echo "param: "$cfg" "$yourdata
    $func $cfg $yourdata 
elif [ "$func" = "infer" ];then
    cfg=$2
    infer_dir=$3
    weights=$4
    output_dir=eval_results
    echo "param: "$cfg" "$infer_dir" "$weights" "$output_dir
    infer $cfg $infer_dir $weights $output_dir
elif [ "$func" = "freeze" ];then
    cfg=$2
    weights=$3
    output_dir=inference_model
    echo "param: "$cfg" "$weights" "$output_dir
    $func $cfg $weights $output_dir
elif [ "$func" = "deploy" ];then
    model_dir=$2
    image_file=$3
    echo "param: "$model_dir" "image_file
    $func $model_dir $image_file
else
    echo "invalid input param"
fi
