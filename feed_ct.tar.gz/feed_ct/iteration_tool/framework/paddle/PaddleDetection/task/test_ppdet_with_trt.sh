#!/usr/bin/env bash
###############################################################
# note:
#     迭代工具中自动拷贝依赖库，部署时需将lib和set_env.sh拷到部署环境中

depends=("libc_2_14" "trt_6_0_1_5")
if [ ! -d "lib" ]; then
    mkdir "lib"
fi
for lib in ${depends[*]}
do
    cp -r ../../../lib/${lib} ./lib
done
cp ../../set_env.sh ./

###############################################################

set -e
source $(pwd)/set_env.sh

function start()
{
    echo -e "\e[32m[ start    ]\e[0m ${1}"
}

function end()
{
    echo -e "\e[32m[       OK ]\e[0m ${1}\n"
}

export PYTHONPATH=${PWD}:${PYTHONPATH}

model_name=yolov3_r50vd_dcn_obj365_dropblock_iouloss
pretrained_path=./pretrained
pretrained_model=${pretrained_path}/${model_name}
frozen_path=./frozen
frozen_model=${frozen_path}/"yolov3_r50vd_dcn_db_iouloss_obj365_pretrained_coco"

if [ ! -d ${pretrained_model} ]; then
    mkdir -p ${pretrained_path}
    start "Downloading "${model_name}
    url="https://paddlemodels.bj.bcebos.com/object_detection/yolov3_r50vd_dcn_obj365_dropblock_iouloss.tar"
    wget -O ${pretrained_model}".tar" ${url} --no-check-certificate
    tar -xf ${pretrained_model}".tar" -C ${pretrained_path}
    #rm -rf $pretrained_model".tar"
    end "Downloaded "${model_name}
else
    echo -e "\e[33m[Warning] The "${model_name}" has been existed!\e[0m\n"
fi

start "Freezing "${model_name}
CUDA_VISIBLE_DEVICES=2 python tools/export_model.py \
        -c configs/dcn/yolov3_r50vd_dcn_db_iouloss_obj365_pretrained_coco.yml \
        --output_dir=${frozen_path} \
        -o weights=${pretrained_model} \
        TestReader.inputs_def.image_shape=[3,416,416]
end "Frozen "${model_name}

batchsize=1
image_file=task/test.jpg
export CUDA_VISIBLE_DEVICES=2 

start "Test inference time with "${batchsize}
echo "without tensorrt"
python deploy/python/infer.py \
        --model_dir ${frozen_model} \
        --image_file ${image_file} \
        --use_gpu True \
        --run_benchmark True

echo "with tensorrt"
python deploy/python/infer.py \
        --model_dir ${frozen_model} \
        --image_file ${image_file} \
        --run_mode trt_fp32 \
        --use_gpu True \
        --run_benchmark True

echo "with tensorrt"
python deploy/python/infer.py \
        --model_dir ${frozen_model} \
        --image_file ${image_file} \
        --run_mode trt_fp16 \
        --use_gpu True \
        --run_benchmark True
end "Finish testing inference time with "${batchsize}
