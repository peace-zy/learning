#!/bin/bash
echo -e "\e[32m[ start    ] \e[0mSetting dependencies"${model_name}
libc=$(pwd)/lib/libc_2_14/libc.so.6
echo ${libc}
export LD_PRELOAD=${libc}

libtrt=$(pwd)/lib/trt_6_0_1_5
echo ${libtrt}
export LD_LIBRARY_PATH=${libtrt}:${LD_LIBRARY_PATH}
echo -e "\e[32m[       OK ] \e[0mSet dependencies"${model_name}"\n"
