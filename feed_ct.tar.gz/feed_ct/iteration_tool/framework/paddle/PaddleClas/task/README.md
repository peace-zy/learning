# PaddleCls
- github (新的分类分支)  
      https://github.com/PaddlePaddle/PaddleClas 
- paddle安装  
      https://www.paddlepaddle.org.cn/install/quick
- 配置  
    将“task”文件夹放到“PaddleCls”路径下，如：{path}/PaddleCls/task

## [train]

### 1. 数据准备
    整理好的数据放到"dataset/{yourdata}"路径下,执行下述脚本生成训练数据和验证数据

    sh task/script.sh data {data_dir/anno_list} {save_path}  

    data_dir: 数据根目录,以标签创建文件夹"0/, 1/"  
    anno_list: 标注文件  
    执行上面脚本后，会在{save_path}所在目录生成，“train.txt、eval.txt”  
    注：默认训练和验证数据比例9：1  
  
### 2. 训练
    sh task/script.sh train {cfg}  
    手动修改过cfg  

## [deploy]
    模型达到预期后，需要对训练好的模型进行参数冻结，冻结后的模型会有一定程度的速度提升

    sh task/script.sh freeze {model} {pretrained_model} {output_path}

    模型参数冻结后，可以通过下面脚本进行测试
    sh task/script.sh deploy {model_file} {param_file} {image_file}
   
    上线的模型部署可以参考"tools/infer/predict.py"，进行封装或修改。

## [tutorial]
    执行sh task/script.sh  打印功能
    <生成训练、验证文件列表及类别数量>
    sh task/script.sh data {data_dir/anno_list} {save_path}
    
    <训练>
    sh task/script.sh train {cfg}

    <冻结模型参数>
    sh task/script.sh freeze {model} {pretrained_model} {output_path}

    <使用冻结模型进行预测>
    sh task/script.sh deploy {model_file} {param_file} {image_file}

## [tensorrt]
迭代工具中自动拷贝依赖库，部署时需将lib和set_env.sh拷到部署环境中  
   ### 1. 说明
   - paddle版本1.8以上，安装时建议使用conda  
   - tensorrt版本需与cuda、paddle版本兼容  
   - glibc版本2.14以上  
   ### 2. 环境配置
   - paddle=1.8.5、CUDA=10.0，cuDNN=7.3+（自行安装）  
   - tensorrt=6.0.1.5、glibc=2.14  
   ### 3. batch测试  
   为了测试batchsize > 1情况下的单独gpu inference速度，需"tools/infer/predict.py"中104行"assert args.use_tensorrt is True"注释掉  
   ### 4. 运行
   ```bash
   sh task/test_ppcls_with_trt.sh   
   ```
