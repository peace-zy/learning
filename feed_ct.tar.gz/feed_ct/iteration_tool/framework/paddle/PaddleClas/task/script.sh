#!/bin/bash
set -e
export PYTHONPATH=$PYTHONPATH:.

function start()
{
    echo -e "\e[32m[ start    ]\e[0m $1"
}

function end()
{
    echo -e "\e[32m[       OK ]\e[0m $1"
}

function kill()
{
    ps -ef |grep tools/train.py |awk '{print $2}' |xargs -i kill -9 {}
}

#dataset_dir=dataset
# generate file list for training and eval 
function gen_data()
{
    input=$1
    save_path=$2
    start generate_train_eval
    #python task/utils/generate_train_eval.py --input $dataset_dir/$yourdata --save_path $dataset_dir/$yourdata
    python task/utils/generate_train_eval.py --input $input --save_path $save_path
    end generate_train_eval
}

# train
function train()
{
    cfg=$1
    start train
    CUDA_VISIBLE_DEVICES=0 python -m paddle.distributed.launch \
        --selected_gpus="0" \
        tools/train.py \
        -c $cfg \
        --vdl_dir=./scalar/
    end train
}

# freeze trained model
function freeze()
{
    model=$1
    pretrained_model=$2
    output_path=$3
    clss_dim=1000
    img_size=224
         
    start freeze
    CUDA_VISIBLE_DEVICES=0 python tools/export_model.py \
         --model=$model \
         --pretrained_model=$pretrained_model \
         --output_path=$output_path \
         --class_dim=$clss_dim \
         --img_size=$img_size
    end freeze
}

# inference with frozen model
function deploy()
{
    model_file=$1
    param_file=$2
    image_file=$3
    start deploy 
    CUDA_VISIBLE_DEVICES=0 python tools/infer/predict.py \
        -m $model_file \
        -p $param_file \
        -i $image_file \
        --use_gpu=1 \
        --batch_size=1
    end deploy 
}

function usage()
{
    echo -e """usage:\e[32m
        <生成训练、验证文件列表及类别数量>
        sh task/script.sh data {data_dir/anno_list} {save_path}
        
        <训练>
        sh task/script.sh train {cfg}

        <冻结模型参数>
        sh task/script.sh freeze {model} {pretrained_model} {output_path}

        <使用冻结模型进行预测>
        sh task/script.sh deploy {model_file} {param_file} {image_file}
        \e[0m
        """
}
#===========================
#   MAIN SCRIPT
#===========================


if [ $# -eq 0 ];
then
    usage
    exit
fi

func=$1
echo "run: "$func
if [ "$func" = "kill" ];then
    $func 
elif [ "$func" = "data" ];then
    yourdata=$2
    save_path=$3
    echo "param: "$yourdata" "$save_path
    gen_data $yourdata $save_path 
elif [ "$func" = "train" ];then
    cfg=$2
    architecture_name=$3
    pretrained_model=$4
    echo "param: "$cfg" "$architecture_name" "$pretrained_model
    $func $cfg $architecture_name $pretrained_model
elif [ "$func" = "freeze" ];then
    model=$2
    pretrained_model=$3
    output_path=inference_model
    echo "param: "$model" "$pretrained_model" "$output_path
    $func $model $pretrained_model $output_path
elif [ "$func" = "deploy" ];then
    model_file=$2
    param_file=$3
    image_file=$4
    echo "param: "$model_file" "param_file" "$image_file
    $func $model_file $param_file $image_file
else
    echo "invalid input param"
fi
