#!/usr/bin/env bash
###############################################################
# note:
#     迭代工具中自动拷贝依赖库，部署时需将lib和set_env.sh拷到部署环境中

depends=("libc_2_14" "trt_6_0_1_5")
if [ ! -d "lib" ]; then
    mkdir "lib"
fi
for lib in ${depends[*]}
do
    cp -r ../../../lib/${lib} ./lib
done
cp ../../set_env.sh ./
###############################################################

set -e
source $(pwd)/set_env.sh

function start()
{
    echo -e "\e[32m[ start    ]\e[0m ${1}"
}

function end()
{
    echo -e "\e[32m[       OK ]\e[0m ${1}\n"
}
export PYTHONPATH=${PWD}:${PYTHONPATH}

model_name=ResNet50_vd
pretrained_path=./pretrained
pretrained_model=${pretrained_path}/${model_name}"_pretrained"
frozen_path=./frozen
frozen_model=${frozen_path}/${model_name}

if [ ! -d ${pretrained_model} ]; then
    start "Downloading "${model_name}
    python tools/download.py -a ${model_name} -p ${pretrained_path} -d 1
    end "Downloaded "${model_name}
else
    echo -e "\e[33m[Warning] The "${model_name}" has been existed!\e[0m\n"
fi

start "Freezing "${model_name}
python tools/export_model.py \
        -m ${model_name} \
        -p ${pretrained_model} \
        -o ${frozen_model}
end "Frozen "${model_name}

batchsize=100
image_file=task/test.jpg
export CUDA_VISIBLE_DEVICES=2 

start "Test inference time with "${batchsize}
echo "without tensorrt"
python tools/infer/predict.py \
        -i ${image_file} \
        -m ${frozen_model}/model \
        -p ${frozen_model}/params \
        -b ${batchsize} \
        --model_name ${frozen_model} \
        --use_gpu true \
        --enable_benchmark true

echo "with tensorrt"
python tools/infer/predict.py \
        -i ${image_file} \
        -m ${frozen_model}/model \
        -p ${frozen_model}/params \
        -b ${batchsize} \
        --model_name ${frozen_model} \
        --use_gpu true \
        --use_tensorrt true \
        --enable_benchmark true

python tools/infer/predict.py \
        -i ${image_file} \
        -m ${frozen_model}/model \
        -p ${frozen_model}/params \
        -b ${batchsize} \
        --model_name ${frozen_model} \
        --use_gpu true \
        --use_tensorrt true \
        --enable_benchmark true \
        --use_fp16 true

end "Finish testing inference time with "${batchsize}
