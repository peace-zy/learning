#!/bin/bash
###############################################################
depends=("libc_2_14" "trt_7_0_0_11" "cudnn_7_6_4_38")
if [ ! -d "lib" ]; then
    mkdir "lib"
fi
for lib in ${depends[*]}
do
    cp -r ../../lib/${lib} ./lib
done
###############################################################
set -e

echo -e "\e[32m[ start    ] \e[0mSetting dependencies"
libc=$(pwd)/lib/libc_2_14/libc.so.6
echo ${libc}
export LD_PRELOAD=${libc}
libtrt=$(pwd)/lib/trt_7_0_0_11
echo ${libtrt}
export LD_LIBRARY_PATH=${libtrt}:$LD_LIBRARY_PATH
libcudnn=$(pwd)/lib/cudnn_7_6_4_38
echo ${libcudnn}
export LD_LIBRARY_PATH=${libcudnn}:$LD_LIBRARY_PATH
echo -e "\e[32m[       OK ] \e[0mSet dependencies\n"
