# pytorch转onnx、onnx基于onnxruntime/tensorrt运行示例

## 安装
- pytorch、torchvision  
   conda install pytorch==1.4.0 torchvision==0.5.0 torchaudio cudatoolkit=10.0 -c https://mirrors.bfsu.edu.cn/anaconda/cloud/pytorch
- onnx  
   pip install onnx==1.8.1 -i https://pypi.tuna.tsinghua.edu.cn/simple
- onnxruntime  
    pip install onnxruntime==1.4.0 or pip install onnxruntime-gpu==1.4.0
- [tensorrt安装说明](https://docs.nvidia.com/deeplearning/tensorrt/install-guide/index.html#installing-pycuda)  
    1.安装pycuda  
    pip install 'pycuda>=2019.1.1'  
    2.tensorrt、cudnn  
    [tensorrt](https://developer.nvidia.com/compute/machine-learning/tensorrt/secure/7.0/7.0.0.11/tars/TensorRT-7.0.0.11.CentOS-7.6.x86_64-gnu.cuda-10.0.cudnn7.6.tar.gz)  
    [cudnn](https://developer.nvidia.com/compute/machine-learning/cudnn/secure/7.6.4.38/Production/10.0_20190923/cudnn-10.0-linux-x64-v7.6.4.38.tgz)  
    [glibc-2.14]  
    已提供的下载好的库，可以通过source set_env.sh，进行拷贝和环境变量设置  

- opencv  
   pip install opencv-python==3.4.9.33 -i https://pypi.tuna.tsinghua.edu.cn/simple  
## pytorch模型转onnx

python convert2onnx.py

## 使用tensorrt运行onnx模型

python test_onnx_with_trt.py

## Todo
  1.pytorch转onnx后会存在冗余op的情况，可以通过[onnx-simpler](https://github.com/daquexian/onnx-simplifier)处理，目前尚未测试。  
  2.test_onnx_with_trt.py按照tensorrt运行流程整理代码  
  3.int8量化测试  
