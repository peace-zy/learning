# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了onnx基于onnxruntime和tensorrt运行示例
并与原始pytorch模型输出进行对比

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2021/02/25 10:00:00
"""

import pycuda.autoinit
import numpy as np
import pycuda.driver as cuda
import tensorrt as trt
import torch
import torch.nn as nn
import os
import time
from PIL import Image
import cv2
import torchvision

os.environ['CUDA_VISIBAL_DEVICES'] = '6'
filename = './cat.jpg'
max_batch_size = 16  # batch size 
#max_batch_size = 1  # batch size 
onnx_model_path = 'resnet50.onnx'

TRT_LOGGER = trt.Logger()  # This logger is required to build an engine

def get_img_np_nchw(filename):
    """生成网络输入数据
    Args:
        filename: 本地图像路径名称
    Returns:
        numpy: [1, c, h, w] rgb格式 
    """
    image = cv2.imread(filename, flags=cv2.IMREAD_COLOR)
    image_cv = cv2.resize(image, (224, 224))
    image_cv = cv2.cvtColor(image_cv, cv2.COLOR_BGR2RGB)
    miu = np.array([0.485, 0.456, 0.406])
    std = np.array([0.229, 0.224, 0.225])
    img_np = np.array(image_cv, dtype=float) / 255.
    r = (img_np[:, :, 0] - miu[0]) / std[0]
    g = (img_np[:, :, 1] - miu[1]) / std[1]
    b = (img_np[:, :, 2] - miu[2]) / std[2]
    img_np_t = np.array([r, g, b])
    img_np_nchw = np.expand_dims(img_np_t, axis=0)
    return img_np_nchw

def get_img_np_nchw_new(filename):
    """生成网络输入数据新方式[较第一种慢]
    测试100次取均值
       get_image_v1: 8.837542533874512ms
       get_image_v2: 9.595723152160645ms
    Args:
        filename: 本地图像路径名称
    Returns:
        numpy: [1, c, h, w] rgb格式 
    """
    image = cv2.imread(filename, flags=cv2.IMREAD_COLOR)
    image_cv = cv2.resize(image, (224, 224))
    image_cv = cv2.cvtColor(image_cv, cv2.COLOR_BGR2RGB)
    img_np = image_cv.astype(np.float32, copy=False)
    miu = np.array([0.485, 0.456, 0.406])[np.newaxis, np.newaxis, :]
    std = np.array([0.229, 0.224, 0.225])[np.newaxis, np.newaxis, :]
    img_np = img_np / 255.
    img_np -= miu
    img_np /= std
    img_np = img_np.transpose((2, 0, 1)).copy()
    img_np_nchw = np.expand_dims(img_np, axis=0)
    return img_np_nchw

class HostDeviceMem(object):
    """cpu gpu内存"""
    def __init__(self, host_mem, device_mem):
        """Within this context, host_mom means the cpu memory and device means the GPU memory
        """
        self.host = host_mem
        self.device = device_mem

    def __str__(self):
        return "Host:\n" + str(self.host) + "\nDevice:\n" + str(self.device)

    def __repr__(self):
        return self.__str__()


def allocate_buffers(engine):
    """内存申请: 整个engine涉及到的内存 
    Args:
        engine: tensorrt engine
    Returns:
        Dict
            inputs: 网络输入cpu gpu内存
            outpus: 网络输出cpu gpu内存
            bindings: 网络需要的所有内存
            stream: cuda流
    """
    inputs = []
    outputs = []
    bindings = []
    stream = cuda.Stream()
    for binding in engine:
        #size = trt.volume(engine.get_binding_shape(binding)) * engine.max_batch_size
        size = trt.volume(engine.get_binding_shape(binding))
        dtype = trt.nptype(engine.get_binding_dtype(binding))
        # Allocate host and device buffers
        host_mem = cuda.pagelocked_empty(size, dtype)
        device_mem = cuda.mem_alloc(host_mem.nbytes)
        # Append the device buffer to device bindings.
        bindings.append(int(device_mem))
        # Append to the appropriate list.
        if engine.binding_is_input(binding):
            inputs.append(HostDeviceMem(host_mem, device_mem))
        else:
            outputs.append(HostDeviceMem(host_mem, device_mem))

    return {'inputs': inputs,
            'outputs': outputs,
            'bindings': bindings,
            'stream': stream}


global num_classes
# [default] imagenet 1000
num_classes = 1000
def get_engine(max_batch_size=1, onnx_file_path="", engine_file_path="", \
               fp16_mode=False, int8_mode=False, save_engine=False,
               ):
    """Attempts to load a serialized engine if available, otherwise builds a new TensorRT engine and saves it."""

    def build_engine(max_batch_size, save_engine):
        """Takes an ONNX file and creates a TensorRT engine to run inference with"""
        explicit_batch = 1 << (int)(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH)
        with trt.Builder(TRT_LOGGER) as builder, \
                builder.create_network(explicit_batch) if int(trt.__version__[0]) > 6 \
                                                       else builder.create_network() as network, \
                builder.create_builder_config() as config, \
                trt.OnnxParser(network, TRT_LOGGER) as parser:

            builder.max_workspace_size = 1 << 30  # Your workspace size
            builder.max_batch_size = max_batch_size
            # pdb.set_trace()
            builder.fp16_mode = fp16_mode  # Default: False
            builder.int8_mode = int8_mode  # Default: False
            if int8_mode:
                # To be updated
                raise NotImplementedError

            # Parse model file
            if not os.path.exists(onnx_file_path):
                quit('ONNX file {} not found'.format(onnx_file_path))

            print('Loading ONNX file from path {}...'.format(onnx_file_path))
            with open(onnx_file_path, 'rb') as model:
                print('Beginning ONNX file parsing')
                parser.parse(model.read())

            print('Completed parsing of ONNX file')
            print('Building an engine from file {}; this may take a while...'.format(onnx_file_path))

            output_shape = network.get_layer(network.num_layers - 1).get_output(0).shape
            print('shape of output is [{}]!'.format(output_shape))
            global num_classes
            if len(output_shape) == 1:
                num_classes = network.get_layer(network.num_layers - 1).get_output(0).shape[0] 
            elif len(output_shape) == 2:
                num_classes = network.get_layer(network.num_layers - 1).get_output(0).shape[1] 
            else:
                raise
            print('number of category is [{}]!'.format(num_classes))
            last_layer = network.get_layer(network.num_layers - 1)
            # Check if last layer recognizes it's output
            if not last_layer.get_output(0):
                # If not, then mark the output using TensorRT API
                network.mark_output(last_layer.get_output(0))
                                      
            engine = builder.build_cuda_engine(network)
            print("Completed creating Engine")

            if save_engine:
                with open(engine_file_path, "wb") as f:
                    f.write(engine.serialize())
            return engine

    if os.path.exists(engine_file_path):
        # If a serialized engine exists, load it instead of building a new one.
        print("Reading engine from file {}".format(engine_file_path))
        with open(engine_file_path, "rb") as f, trt.Runtime(TRT_LOGGER) as runtime:
            engine = runtime.deserialize_cuda_engine(f.read())
            num_bindings = engine.num_bindings
            if num_bindings > 2:
                print ('num_bindings > 2, can not get [num_classes] automatically')
                raise  
            global num_classes
            # 0: input, 1: output 
            output_shape = engine.get_binding_shape(1)
            if len(output_shape) == 1:
                num_classes = output_shape[0] 
            elif len(output_shape) == 2:
                num_classes = output_shape[1] 
            else:
                raise
            print('number of category is [{}]!'.format(num_classes))
            return engine 
    else:
        return build_engine(max_batch_size, save_engine)


def do_inference(context, bindings, inputs, outputs, stream, batch_size=1):
    """预测
    Args:
        context:
        bindings: 网络需要的所有内存
        inputs: 网络输入cpu gpu内存
        outpus: 网络输出cpu gpu内存
        stream: cuda流
        batch_size: 批处理大小
    Returns:
        将网络输出拷贝到cpu 
    """

    # Transfer data from CPU to the GPU.
    [cuda.memcpy_htod_async(inp.device, inp.host, stream) for inp in inputs]
    # Run inference.
    context.execute_async(batch_size=batch_size, bindings=bindings, stream_handle=stream.handle)
    # Transfer predictions back from the GPU.
    [cuda.memcpy_dtoh_async(out.host, out.device, stream) for out in outputs]
    # Synchronize the stream
    stream.synchronize()
    # Return only the host outputs.
    return [out.host for out in outputs]

def postprocess_the_outputs(h_outputs, shape_of_output):
    """将网络运行输出结果适配到网络输出的形状"""
    h_outputs = h_outputs.reshape(*shape_of_output)
    return h_outputs

if __name__ == '__main__':
    img_np_nchw = get_img_np_nchw(filename)
    img_np_nchw = img_np_nchw.astype(dtype=np.float32)

    ############################# inference with trt #############################
    # 整体流程分两个阶段：build和runtime
    # build: ILogger->IBuilder->INetworkDefiniton->IParser->ICudaEngine->serialize成IHostMemory
    # runtime: IRuntime->ICudaEngine->IExecutionContext

    # These two modes are dependent on hardwares
    fp16_mode = False
    int8_mode = False
    trt_engine_path = './model_fp16_{}_int8_{}.trt'.format(fp16_mode, int8_mode)
    # Build an engine
    engine = get_engine(max_batch_size, onnx_model_path, trt_engine_path, fp16_mode, int8_mode, save_engine=True)
    # Create the context for this engine
    context = engine.create_execution_context()
    #context.active_optimization_profile = 1
    # Allocate buffers for input and output
    buffers = allocate_buffers(engine) # input, output: host # bindings
    inputs = buffers['inputs']
    outputs = buffers['outputs']
    bindings = buffers['bindings']
    stream = buffers['stream'] 

    # Do inference
    shape_of_output = (max_batch_size, num_classes)
    shape_of_output = (16, num_classes)
    print (shape_of_output)
    # Load data to the buffer
    inputs[0].host = img_np_nchw.reshape(-1)

    # inputs[1].host = ... for multiple input
    test_num = 10
    trt_elaps = 0
    torch_elaps = 0
    for i in range(0, test_num + 10):
        start = time.time()
        img_np_nchw = get_img_np_nchw(filename)
        #img_np_nchw = get_img_np_nchw_new(filename)
        img_np_nchw = img_np_nchw.astype(dtype=np.float32)
        img_np_nchw = img_np_nchw.repeat(max_batch_size, 0)
        inputs[0].host = img_np_nchw.reshape(-1)
        '''
        '''
        trt_outputs = do_inference(context, bindings=bindings, inputs=inputs,\
                                   outputs=outputs, stream=stream, batch_size=max_batch_size) # numpy data
        trt_out = postprocess_the_outputs(trt_outputs[0], shape_of_output)
        end = time.time()
        if i >= 10:
            trt_elaps += (end - start) 

    print('TensorRT ok')

    ############################# inference with torch #############################
    device = torch.device("cuda:" + os.environ['CUDA_VISIBAL_DEVICES'] \
                          if torch.cuda.is_available() else "cpu")
    print (device)
    model = torchvision.models.resnet50(pretrained=True).to(device)
    resnet_model = model.eval()

    #input_for_torch = torch.from_numpy(img_np_nchw).to(device)
    with torch.no_grad():
        for i in range(0, test_num + 10):
            start = time.time()
            img_np_nchw = get_img_np_nchw(filename)
            #img_np_nchw = get_img_np_nchw_new(filename)
            img_np_nchw = img_np_nchw.astype(dtype=np.float32)
            img_np_nchw = img_np_nchw.repeat(max_batch_size, 0)
            input_for_torch = torch.from_numpy(img_np_nchw).to(device)
            '''
            '''
            torch_out = resnet_model(input_for_torch)
            torch_out = torch_out.cpu().data.numpy()
            end = time.time()
            if i >= 10:
                torch_elaps += (end - start) 
    print('Pytorch ok!')

    ############################# inference with onnxruntime #############################
    import onnx
    import onnxruntime as ort
    ort_elaps = 0
    ort_session = ort.InferenceSession(onnx_model_path)
    for i in range(0, test_num + 10):
        start = time.time()
        img_np_nchw = get_img_np_nchw(filename)
        img_np_nchw = img_np_nchw.astype(dtype=np.float32)
        img_np_nchw = img_np_nchw.repeat(max_batch_size, 0)
        ort_out = ort_session.run(None, {'input': img_np_nchw})
        end = time.time()
        if i >= 10:
            ort_elaps += (end - start) 

    ############################# difference between trt/onnxruntime and torch #############################
    mse = np.mean((trt_out - torch_out)**2)
    mse1 = np.mean((ort_out[0] - torch_out)**2)
    print("Batch size: {}".format(max_batch_size))
    print("Inference time with the TensorRT engine: {}ms".format(1000 * trt_elaps / test_num / max_batch_size))
    print("Inference time with the PyTorch model: {}ms".format(1000 * torch_elaps / test_num / max_batch_size))
    print("Inference time with the onnxruntime: {}ms".format(1000 * ort_elaps / test_num / max_batch_size))
    print('MSE Error between trt and torch= {}'.format(mse))
    print('MSE Error between onnxruntime and torch= {}'.format(mse1))

    print('All completed!')
