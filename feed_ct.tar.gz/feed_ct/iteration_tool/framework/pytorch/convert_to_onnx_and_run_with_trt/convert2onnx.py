# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了将torch模型转换成onnx

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2021/02/24 10:00:00
"""

import torchvision
import torch
from torch.autograd import Variable
import onnx
import tensorrt
print(torch.__version__)

# 指定输入和输出名称
input_name = ['input']
output_name = ['output']
max_batch_size = 16
input = Variable(torch.randn(max_batch_size, 3, 224, 224)).cuda()
#input = Variable(torch.randn(1, 3, 224, 224)).cuda()
model = torchvision.models.resnet50(pretrained=True).cuda()
onnx_file = 'resnet50.onnx'
if int(tensorrt.__version__[0]) > 6:
    torch.onnx.export(model, input, onnx_file, verbose=True,\
                  input_names=input_name, output_names=output_name, export_params=True)
else:
    torch.onnx.export(model, input, onnx_file, verbose=True,\
                      input_names=input_name, output_names=output_name, dynamic_axes={"input":[0], "output":[0]})

net = onnx.load(onnx_file)  # 加载onnx 计算图
onnx.checker.check_model(net)  # 检查文件模型是否正确
print(onnx.helper.printable_graph(net.graph))  # 输出onnx的计算图
