# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了约定格式以voc格式存储。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/03/31 13:00:00
"""
import os
import logging
import traceback
import lxml.builder
import lxml.etree
from utils import io, log 
from dataset import base_writer

class VOCWriter(base_writer.Writer):
    """voc 格式存储"""
    def __init__(self, save_path=None, vis=False, crop_region=False):
        """初始化"""
        log.init_log(os.path.join("log", os.path.basename(__file__).split(".")[0]))
        super(VOCWriter, self).__init__(
                save_path=save_path,
                vis=vis,
                crop_region=crop_region)

    def write_annotation(self, annotation):
        """将标准格式存储成voc格式文件
        Args:
              annotation: 标准格式 
              self.save_path: 存储路径

        Returns:
                bool: 成功返回True 
                      参数非法返回False
        """

        save_path = self.save_path

        try:
            save_image_path = os.path.join(save_path, "JPEGImages")
            io.make_path(save_image_path)
            save_xml_path = os.path.join(save_path, "Annotations")
            io.make_path(save_xml_path)

            image_file = annotation["image_file"]
            width = annotation["width"]
            height = annotation["height"]

            bndboxes = []
            keypoints = []
            if "bndboxes" not in annotation and "keypoints" not in annotation:
                logging.warning("the image [{}] has no object and keypoints!".format(image_file))
                return False
            if "bndboxes" in annotation:
                bndboxes = annotation["bndboxes"]
            if "keypoints" in annotation:
                keypoints = annotation["keypoints"]

            if not bndboxes and not keypoints:
                logging.warning("the image [{}] has no object and keypoints!".format(image_file))
                return False 

            image_path, image_name = os.path.split(image_file)
            base_name = os.path.splitext(image_name)[0]
            xml_name = base_name + ".xml"

            maker = lxml.builder.ElementMaker()
            xml = maker.annotation(
                maker.folder(os.path.basename(image_path)),
                maker.filename(image_name),
                maker.source(
                    maker.database("Unknown"),    # e.g., The VOC2007 Database
                    maker.annotation(),  # e.g., Pascal VOC2007
                    maker.image(),       # e.g., flickr
                ),
                maker.size(
                    maker.height(str(height)),
                    maker.width(str(width)),
                    maker.depth(str(3)),
                ),
                maker.segmented("0"),
            )

            for bndbox in bndboxes:
                xmin = bndbox["xmin"]
                ymin = bndbox["ymin"]
                xmax = bndbox["xmax"]
                ymax = bndbox["ymax"]
                name = bndbox["name"]
                score = 0.0 
                if "score" in bndbox:
                    score = bndbox["score"]
                xml.append(
                    maker.object(
                        maker.name(name),
                        maker.pose("Unspecified"),
                        maker.truncated("0"),
                        maker.difficult("0"),
                        maker.bndbox(
                            maker.xmin(str(int(xmin))),
                            maker.ymin(str(int(ymin))),
                            maker.xmax(str(int(xmax))),
                            maker.ymax(str(int(ymax))),
                        ),
                        maker.score(str(score))
                    )
                )

            for group in keypoints:
                points = group["points"]
                kps = maker.keypoints()
                for point in points:
                    x = point["x"]
                    y = point["y"]
                    kps.append(
                        maker.point(
                            maker.x(str(int(x))),
                            maker.y(str(int(y)))
                        )
                    )
                
                xml.append(kps)
            out_xml_file = os.path.join(save_xml_path, xml_name)
            with open(out_xml_file, 'wb') as f:
                f.write(lxml.etree.tostring(xml, pretty_print=True))
            if "image" in annotation:
                image = annotation["image"]
                if image is not None:
                    image_name = os.path.splitext(image_name)[0] + ".jpg"
                    out_image_file = os.path.join(save_image_path, image_name)
                    io.cv_imwrite(out_image_file, image)
        except Exception as e:
            traceback.print_exc()
            return False
        return True
