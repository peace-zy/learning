# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了约定格式以voc格式存储。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/03/31 13:00:00
"""
import os
import logging
import traceback
from utils import io, log
from dataset import base_writer

class ClassificationWriter(base_writer.Writer):
    """分类格式存储"""
    def __init__(self, save_path=None, vis=False):
        """初始化"""
        log.init_log(os.path.join("log", os.path.basename(__file__).split(".")[0]))
        super(ClassificationWriter, self).__init__(
                save_path=save_path,
                vis=vis)

    def write_annotation(self, annotation):
        """将标准格式存储成voc格式文件
        Args:
              annotation: 标准格式 
              self.save_path: 存储路径

        Returns:
                bool: 成功返回True 
                      参数非法返回False
        """

        save_path = self.save_path

        try:
            save_image_path = os.path.join(save_path, str(annotation["label"]))
            io.make_path(save_image_path)
            image_file = annotation["image_file"]
            image_path, image_name = os.path.split(image_file)
            image_name = os.path.splitext(image_name)[0] + ".jpg"
            
            if "image" in annotation:
                image = annotation["image"]
                if image is not None:
                    image_name = os.path.splitext(image_name)[0] + ".jpg"
                    out_image_file = os.path.join(save_image_path, image_name)
                    io.cv_imwrite(out_image_file, image)
                with open(os.path.join(save_path, "anno_info.txt"), "a") as f:
                    f.write(image_file + " " + str(annotation["label"]) + "\n")
        except Exception as e:
            traceback.print_exc()
            return False
        return True
