# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了yolov3_tensorflow格式转换成规定格式类。

xxx.txt
image_path1 x_min,y_min,x_max,y_max,class_id  x_min,y_min,...,class_id
image_path2 x_min,y_min,x_max,y_max,class_id  x_min,y_min,...,class_id

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/04/01 10:00:00
"""
import os
from dataset import base_reader
from utils import log
import logging
from lxml import etree
import traceback
from tqdm import tqdm
import cv2

class Yolov3TfReader(base_reader.DataSet):
    """加载yolov3tf数据源
    Args:
        dataset_dir: 数据集根目录 
        image_dir: 图像路径子目录 (绝对路径=dataset_dir + "/" + image_dir)
                   或绝对路径(按需求)
        anno_dir: 标注文件路径子目录 (绝对路径=dataset_dir + "/" + image_dir)
                  或绝对路径(按需求)
        label_map_file: 存储类别id及类别名(根据需求自己定义解析)
    """
    def __init__(self, dataset_dir=None, image_dir=None,
            anno_dir=None, label_map_file=None, load_image=False, keep=False):
        """初始化"""
        log.init_log(os.path.join("log", os.path.basename(__file__).split(".")[0]))
        super(Yolov3TfReader, self).__init__(
                dataset_dir=dataset_dir,
                image_dir=image_dir,
                anno_dir=anno_dir,
                label_map_file=label_map_file,
                load_image=load_image)
        self.keep = keep

    def load_annotations(self):
        """加载图像路径和标注文件并按照规定格式返回
        annotations=list(dict)
        annotations=[
          {"image_file": "图像文件绝对路径 (required)",
            "width": "图像宽 int", 
            "height": "图像高 int",
            "bndboxes":[
              { "xmin": "左上x int",
                "ymin": "左上y int",
                "xmax": "右下x int",
                "ymax": "右下y int",
                "name": "类别名"
              },  #(optional-检测任务)
            ], 
            "keypoints": [
              {"points": [{
                "x": "x坐标 int", 
                "y": "y坐标 int",
                },]
              }, 
            ], #(optional-关键点检测任务)
            "label": "(optional-分类任务)"
          }
        ]

        标注文件类型各异(xml、txt、json等)子类自己实现

        Returns:
            list: annotations 
        """
        label_map = None
        if not self.keep:
            if self.label_map_file is None:
                logging.warning("you should input the label map!")
                return
            label_map = self.get_label_map()

        anno_file = self.anno_dir
        image_dir = self.image_dir

        if self.dataset_dir is not None:
            anno_file = os.path.join(self.dataset_dir, self.anno_dir)
            if self.image_dir is not None:
                image_dir = os.path.join(self.dataset_dir, self.image_dir)
        annotations = load_yolov3_tf_annotations(anno_file, image_dir, label_map, self.load_image)
        self.annotations = annotations

def load_yolov3_tf_annotations(anno_file, image_dir, label_map, load_image=False):
    """加载yolov3_tf转标准格式

    Args:
        anno_file: 标注文件
        image_dir: 图像路径
        label_map: 标签map 
        load_image: 是否加载图像

    Returns:
        Python list: 标准格式 
    """
    annotations = []
    with open(anno_file, "r") as f:
        for line in tqdm(f.readlines()):
            try:
                line_info = line.rstrip().split(" ")
                n = len(line_info)
                if n == 0:
                    continue
                image_file = line_info[0]
                if image_dir is not None:
                    image_file = os.path.join(image_dir, image_file)

                if not os.path.exists(image_file):
                    logging.warning("[{}] does not exisit!".format(image_file))
                    continue
                image = cv2.imread(image_file)
                shape = image.shape
                bndboxes = []
                for idx in range(1, n):
                    str_box = line_info[idx]
                    box_info = str_box.split(",")
                    xmin = box_info[0]
                    ymin = box_info[1]
                    xmax = box_info[2]
                    ymax = box_info[3]
                    name = box_info[4]
                    if label_map is not None:
                        name = label_map[box_info[4]]
                    bndboxes.append({"xmin": int(xmin),
                                     "ymin": int(ymin),
                                     "xmax": int(xmax),
                                     "ymax": int(ymax),
                                     "name": name})
                standard_anno = {}
                standard_anno["image_file"] = image_file
                standard_anno["height"] = int(shape[0])
                standard_anno["width"] = int(shape[1])
                if bndboxes:
                    standard_anno["bndboxes"] = bndboxes
                if load_image:
                    standard_anno["image"] = image 
                annotations.append(standard_anno)
            except Exception as e:
                traceback.print_exc()
                continue
    return annotations
