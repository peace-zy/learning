# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了数据源存储基类,新增数据存储源需继承该类。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/04/02 10:00:00
"""

from utils import io 
import numpy as np
import os
import cv2

class Writer(object):
    """数据源基类
    Args:
        save_path: 存储路径
        vis: 标注文件可视化(optional) 
        crop_region: 剪切目标区域(optional)，以类别名创建文件名存储
    """
    
    def __init__(self, save_path=None, vis=False, crop_region=False):
        """初始化"""
        self.save_path = save_path
        self.vis = vis 
        self.crop_region = crop_region

    def write_out(self, annotation):
        """获取标注信息"""
        if annotation is None:
            raise ValueError("the annotation is None!")

        if not self.write_annotation(annotation):
            return False
        if self.vis:
            self.visualize(annotation)
        if self.crop_region:
            self.crop(annotation)
        return True

    def write_annotation(self, annotation):
        """将标准格式存储成指定格式文件

        标注文件类型各异(xml、txt、json等)子类自己实现

        Returns:
                bool: 成功返回True 
                      参数非法返回False
        """
        raise NotImplementedError('{}.write_annotation not available'.format(self.__class__.__name__))

    def visualize(self, annotation):
        """存储图像及标注信息
        Args:
            annotation: 标准格式
        Returns:
        """
        image = np.copy(annotation["image"])
        image_file = annotation["image_file"]
        image_name = os.path.basename(image_file)
        image_name = os.path.splitext(image_name)[0] + ".jpg"

        bndboxes = []
        if "bndboxes" in annotation:
            bndboxes = annotation["bndboxes"]

        keypoints = []
        if "keypoints" in annotation:
            keypoints = annotation["keypoints"]

        # bndbox
        for bbx in bndboxes:
            x1 = int(bbx["xmin"])
            y1 = int(bbx["ymin"])
            x2 = int(bbx["xmax"])
            y2 = int(bbx["ymax"])
            name = bbx["name"]
            cv2.rectangle(image, (x1, y1), (x2, y2), (255, 0, 255), 2)
            font = cv2.FONT_HERSHEY_SIMPLEX
            n = len(name)
            cv2.rectangle(image, (x1, y1), (x1 + n * 15, y1 + 20), (255, 0, 0), thickness=-1)
            image = cv2.putText(image, name, (x1 + 5, y1 + 10), font, 0.5, (255, 255, 255), 2)

        # keypoints 
        for kps in keypoints:
            points = kps["points"]
            for pt in points: 
                cv2.circle(image, (int(pt["x"]), int(pt["y"])), 1, (0, 255, 0), 4)
        save_draw_path = os.path.join(self.save_path, "AnnotationVisualization")
        io.make_path(save_draw_path) 
        
        save_file = os.path.join(save_draw_path, image_name)
        io.cv_imwrite(save_file, image)

    def crop(self, annotation):
        """存储图像及标注信息
        Args:
            annotation: 标准格式
        Returns:
        """
        image = np.copy(annotation["image"])
        image_file = annotation["image_file"]
        image_name = os.path.basename(image_file)
        image_name = os.path.splitext(image_name)[0] + ".jpg"

        bndboxes = []
        if "bndboxes" in annotation:
            bndboxes = annotation["bndboxes"]

        save_root_path = os.path.join(self.save_path, "CropImage")

        # bndbox
        for idx, bbx in enumerate(bndboxes):
            x1 = int(bbx["xmin"])
            y1 = int(bbx["ymin"])
            x2 = int(bbx["xmax"])
            y2 = int(bbx["ymax"])
            name = bbx["name"]
            region = image[y1:y2, x1:x2]
            save_crop_path = os.path.join(save_root_path, name)
            io.make_path(save_crop_path) 
            save_file = os.path.join(save_crop_path, str(idx) + '_' + image_name)
            io.cv_imwrite(save_file, region)
