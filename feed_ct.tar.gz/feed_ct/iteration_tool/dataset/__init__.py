# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了初始化路径配置

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/04/07 10:00:00
"""

import os
import sys

this_dir = os.path.dirname(__file__)

root_path = os.path.join(this_dir, '..')
if root_path not in sys.path:
    sys.path.insert(0, root_path)
