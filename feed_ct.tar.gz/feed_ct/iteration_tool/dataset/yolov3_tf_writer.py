# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了约定格式以voc格式存储。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/04/13 10:00:00
"""
import os
import logging
import traceback
from utils import io, log, dataset_util
from dataset import base_writer

class Yolov3TfWriter(base_writer.Writer):
    """yolov3tf 格式存储"""
    def __init__(self, save_path=None, vis=False, label_map_file=None, keep=False, crop_region=False):
        """初始化"""
        log.init_log(os.path.join("log", os.path.basename(__file__).split(".")[0]))
        super(Yolov3TfWriter, self).__init__(
                save_path=save_path,
                vis=vis,
                crop_region=crop_region)
        self.label_map_file = label_map_file
        self.label_map = None
        self.keep = keep
        if not self.keep:
            if not self.label_map_file:
                raise ValueError("label_map_file [{}] dones not exists!".format(self.label_map_file))
            self.label_map = dataset_util.load_label_map(self.label_map_file)

    def write_annotation(self, annotation):
        """将标准格式存储成voc格式文件
        Args:
              annotation: 标准格式 
              self.save_path: 存储路径

        Returns:
                bool: 成功返回True 
                      参数非法返回False
        """
        
        save_path = self.save_path
        anno_info = []

        try:
            save_image_path = os.path.join(save_path, "JPEGImages")
            io.make_path(save_image_path)

            image_file = annotation["image_file"]
            width = annotation["width"]
            height = annotation["height"]

            bndboxes = []
            if "bndboxes" not in annotation:
                logging.warning("the image [{}] has no bndboxes!".format(image_file))
                return False
            if "bndboxes" in annotation:
                bndboxes = annotation["bndboxes"]

            if not bndboxes:
                logging.warning("the image [{}] has no bndboxes!".format(image_file))
                return False 

            image_path, image_name = os.path.split(image_file)

            if "image" in annotation:
                image = annotation["image"]
                if image is not None:
                    image_name = os.path.splitext(image_name)[0] + ".jpg"
                    out_image_file = os.path.join(save_image_path, image_name)
                    io.cv_imwrite(out_image_file, image)

            info = os.path.join(save_image_path, image_name)

            for bndbox in bndboxes:
                xmin = bndbox["xmin"]
                ymin = bndbox["ymin"]
                xmax = bndbox["xmax"]
                ymax = bndbox["ymax"]
                name = bndbox["name"]
                label = name
                if self.label_map is not None:
                    label = self.label_map[name]
                info += " {},{},{},{},{}".format(xmin, ymin, xmax, ymax, label)
            info += "\n"
            anno_info.append(info)
        except Exception as e:
            traceback.print_exc()
            return False
        with open(os.path.join(save_path, "yolov3_tf_anno.txt"), "a") as f:
            f.writelines(anno_info)
        return True
