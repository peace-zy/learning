# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了分类任务txt格式转换成规定格式类。

xxx.txt
image_path1 class_id/class_name confidence(optional)
image_path2 class_id/class_name confidence(optional)

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/03/30 10:00:00
"""
import os
from dataset import base_reader
from utils import log
import logging
from tqdm import tqdm 
import cv2
import traceback

class ClassificationReader(base_reader.DataSet):
    """加载分类数据源txt
    Args:
        dataset_dir: 数据集根目录 
        image_dir: 图像路径子目录 (绝对路径=dataset_dir + "/" + image_dir)
                   或绝对路径(按需求)
        anno_dir: 标注文件路径子目录 (绝对路径=dataset_dir + "/" + image_dir)
                  或绝对路径(按需求)
        load_image: 是否加载图像(按需求，只做输入格式到指定格式转换且需要拷贝图像的时候，设置为True)
    """
    def __init__(self, dataset_dir=None, anno_dir=None, load_image=False):
        """初始化"""
        log.init_log(os.path.join("log", os.path.basename(__file__).split(".")[0]))
        super(ClassificationReader, self).__init__(
                dataset_dir=dataset_dir,
                anno_dir=anno_dir,
                load_image=load_image)

    def load_annotations(self):
        """加载图像路径和标注文件并按照规定格式返回
        annotations=list(dict)
        annotations=[
          {"image_file": "图像文件绝对路径 (required)",
            "width": "图像宽 int", 
            "height": "图像高 int",
            "image": "opencv格式(optional)",
            "bndboxes":[
              { "xmin": "左上x int",
                "ymin": "左上y int",
                "xmax": "右下x int",
                "ymax": "右下y int",
                "name": "类别名",
                "score": "得分", # 检测评估用
              },  #(optional-检测任务)
            ], 
            "keypoints": [
              {"points": [{
                "x": "x坐标 int", 
                "y": "y坐标 int",
                },]
              }, 
            ], #(optional-关键点检测任务)
            "label": "(optional-分类任务)",
            "confidence": "分类评估用"
          }
        ]

        标注文件类型各异(xml、txt、json等)子类自己实现

        Returns:
            list: annotations 

        """
        dataset_dir = self.dataset_dir
        anno_dir = self.anno_dir 
        annotations = load_classification_annotations(dataset_dir=dataset_dir,
                                                      anno_file=anno_dir,
                                                      load_image=self.load_image)
        self.annotations = annotations

def load_classification_annotations(dataset_dir, anno_file, load_image=False):
    """加载voc格式转标准格式

    Args:
        anno_dir: 标注文件地址

    Returns:
        Python list: 约定格式 
    """
    annotations = []
    with open(anno_file, "r") as f:
        for line in tqdm(f.readlines()):
            try:
                line_info = line.rstrip().split(" ")
                n = len(line_info)
                if n == 0:
                    continue
                image_file = os.path.join(dataset_dir, line_info[0])
                if not os.path.exists(image_file):
                    logging.warning("[{}] does not exisit!".format(image_file))
                    continue

                label = int(line_info[1])
                confidence = 0.0
                if n > 2:
                    confidence = float(line_info[2])

                standard_anno = {
                        "image_file": image_file,
                        "label": label,
                        "confidence": confidence}
                if load_image:
                    image = cv2.imread(image_file)
                    shape = image.shape
                    standard_anno["image"] = image 
                annotations.append(standard_anno)

            except Exception as e:
                traceback.print_exc()
                continue
    return annotations 
