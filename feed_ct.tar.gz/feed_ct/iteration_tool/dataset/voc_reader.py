# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了voc格式转换成规定格式类。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/03/30 10:00:00
"""
import os
from dataset import base_reader
from utils import io, log
import logging
from lxml import etree
import traceback

class VOCReader(base_reader.DataSet):
    """加载VOC数据源
    Args:
        dataset_dir: 数据集根目录 
        image_dir: 图像路径子目录 (绝对路径=dataset_dir + "/" + image_dir)
                   或绝对路径(按需求)
        anno_dir: 标注文件路径子目录 (绝对路径=dataset_dir + "/" + image_dir)
                  或绝对路径(按需求)
        load_image: 是否加载图像(按需求，只做输入格式到指定格式转换且需要拷贝图像的时候，设置为True)
    """
    def __init__(self, dataset_dir=None, image_dir="JPEGImages", anno_dir="Annotations", load_image=False):
        """初始化"""
        log.init_log(os.path.join("log", os.path.basename(__file__).split(".")[0]))
        super(VOCReader, self).__init__(
                dataset_dir=dataset_dir,
                image_dir=image_dir,
                anno_dir=anno_dir,
                load_image=load_image)

    def load_annotations(self):
        """加载图像路径和标注文件并按照规定格式返回
        annotations=list(dict)
        annotations=[
          {"image_file": "图像文件绝对路径 (required)",
            "width": "图像宽 int", 
            "height": "图像高 int",
            "image": "opencv格式(optional)",
            "bndboxes":[
              { "xmin": "左上x int",
                "ymin": "左上y int",
                "xmax": "右下x int",
                "ymax": "右下y int",
                "name": "类别名",
                "score": "得分", # 检测评估用
              },  #(optional-检测任务)
            ], 
            "keypoints": [
              {"points": [{
                "x": "x坐标 int", 
                "y": "y坐标 int",
                },]
              }, 
            ], #(optional-关键点检测任务)
            "label": "(optional-分类任务)",
            "confidence": "分类评估用"
          }
        ]

        标注文件类型各异(xml、txt、json等)子类自己实现

        Returns:
            list: annotations 

        """
        image_dir = os.path.join(self.dataset_dir, self.image_dir)
        anno_dir = os.path.join(self.dataset_dir, self.anno_dir)
        annotations = load_voc_annotations(image_dir, anno_dir, self.load_image)
        self.annotations = annotations

def load_voc_annotations(image_dir, anno_dir, load_image=False):
    """加载voc格式转标准格式

    Args:
        image_dir: 图像地址 
        anno_dir: 标注文件地址
        load_image: 是否加载图像

    Returns:
        Python list: 约定格式 
    """
    annotations = []
    for root, dirs, files in os.walk(image_dir):
        if len(files) == 0:
            continue
        logging.info(root)
        tmp = []
        for f in files:
            img_file = os.path.join(root, f)
            img_dir, img_name = os.path.split(img_file)
            anno_name = img_name[0:img_name.find(".")] + ".xml"
            anno_file = os.path.join(anno_dir, anno_name)
            if not os.path.exists(anno_file):
                logging.warning("\033[31mThe {} does not existed\033[37m".format(anno_file))
                continue
            standard_anno = get_xml_anno(anno_file)
            if standard_anno:
                standard_anno.update({"image_file": img_file})
                if load_image:
                    image = io.cv_imread_and_check(img_file)
                    standard_anno.update({"image": image})
                annotations.append(standard_anno)
    return annotations 

def get_xml_anno(anno_file):
    """获取标注信息

    Args:
        anno_file: 标注文件物理地址

    Returns:
        Python dict: 存储标注信息
                     {
                       "width": width,
                       "height": height,
                       "object": []
                       "keypoints": []
                     }
    """
    # ['folder', 'filename', 'path', 'source', 'size', 'segmented', 'object']
    with open(anno_file, "r") as f:
        xml_str = f.read()
        #print("\033[32m{}\033[37m".format(xml_str))
    anno_info = {}
    bndboxes = [] 
    keypoints = []
    try:
        xml = etree.fromstring(xml_str)
        annotation = recursive_parse_xml_to_dict(xml)["annotation"]
        img_size = annotation["size"]
        width = int(img_size["width"])
        height = int(img_size["height"])
        if "object" not in annotation and "keypoints" not in annotation:
            print("\033[31m{} does not contain target object\033[32m".format(annotation["filename"]))
            return anno_info 

        object_node = []
        if "object" in annotation:
            object_node = annotation["object"]

        kps_node = []
        if "keypoints" in annotation:
            kps_node = annotation["keypoints"]

        if not object_node and not kps_node:
            logging.warning("the image [{}] has no object and keypoints!")
            return anno_info 

        for per_object in object_node:
            obj_info = {}
            class_name = per_object["name"]
            bndbox = per_object["bndbox"]
            score = 0.0
            if "score" in per_object:
                score = float(per_object["score"])

            xmin = int(bndbox["xmin"])
            ymin = int(bndbox["ymin"])
            xmax = int(bndbox["xmax"])
            ymax = int(bndbox["ymax"])
            if xmin < 0 or xmin > width or \
                    xmax < 0 or xmax > width or \
                    ymin < 0 or ymin > height or \
                    ymax < 0 or ymax > height:
                print("coordiate is error", anno_file, xmin, xmax, ymin, ymax)
                continue

            xmin = max(xmin, 0)
            ymin = max(ymin, 0)
            xmax = min(xmax, width - 1)
            ymax = min(ymax, height - 1)

            bndboxes.append({"xmin": xmin,
                             "ymin": ymin,
                             "xmax": xmax,
                             "ymax": ymax,
                             "name": class_name,
                             "score": score})

        keypoints = kps_node

        if bndboxes:
            anno_info["width"] = width
            anno_info["height"] = height
            anno_info["bndboxes"] = bndboxes 
        if keypoints:
            anno_info["keypoints"] = []
            for kps in keypoints:
                points = kps["point"]
                pts = []
                for pt in points:
                    x = int(pt["x"])
                    y = int(pt["y"])
                    pts.append({"x": x, "y": y})
                anno_info["keypoints"].append({"points": pts}) 

    except Exception as e:
        traceback.print_exc()
        return anno_info 

    return anno_info 

def recursive_parse_xml_to_dict(xml):
    """递归将xml解析成dict

    Args:
       xml: xml tree obtained by parsing XML file contents using lxml.etree

    Returns:
       Python dictionary holding XML contents.
    """
    if not xml:
        return {xml.tag: xml.text}
    result = {}
    for child in xml:
        child_result = recursive_parse_xml_to_dict(child)
        if child.tag != 'object':
            if child.tag != 'keypoints':
                if child.tag != "point":
                    result[child.tag] = child_result[child.tag]
                else:
                    if child.tag not in result:
                        result[child.tag] = []
                    result[child.tag].append(child_result[child.tag])
            else:
                if child.tag not in result:
                    result[child.tag] = []
                result[child.tag].append(child_result[child.tag])

        else:
            if child.tag not in result:
                result[child.tag] = []
            result[child.tag].append(child_result[child.tag])

    return {xml.tag: result}
