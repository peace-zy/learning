# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了数据源基类,新增数据源需继承该类。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/03/30 10:00:00
"""
from utils import dataset_util

class DataSet(object):
    """数据源基类
    Args:
        dataset_dir: 数据集根目录 
        image_dir: 图像路径子目录 (绝对路径=dataset_dir + "/" + image_dir)
                   或绝对路径(按需求)
        anno_dir: 标注文件路径子目录 (绝对路径=dataset_dir + "/" + image_dir)
                  或绝对路径(按需求)
        label_map_file: 存储类别id及类别名(根据需求自己定义解析)
        load_image: 是否加载图像(按需求，只做输入格式到指定格式转换且需要拷贝图像的时候，设置为True)
    """
    
    def __init__(self,
            dataset_dir=None,
            image_dir=None,
            anno_dir=None,
            label_map_file=None,
            load_image=False):
        """初始化"""
        self.dataset_dir = dataset_dir
        self.image_dir = image_dir
        self.anno_dir = anno_dir
        self.label_map_file = label_map_file 
        self.load_image = load_image 
        self.label_map = None
        self.annotations = None

    def get_annotations(self):
        """获取标注信息"""
        if self.annotations is None:
            self.load_annotations() 
        return self.annotations

    def get_anno_dir(self):
        """获取标注文件路径"""
        return self.anno_dir

    def get_image_dir(self):
        """获取图像路径"""
        return self.image_dir

    def get_label_map_file(self):
        """获取标签映射表文件路径"""
        return self.label_map_file

    def get_label_map(self):
        """获取标签映射表"""
        if not self.label_map_file:
            raise ValueError("label_map_file [{}] dones not exists!".format(self.label_map_file))
        self.label_map = dataset_util.load_label_map(self.label_map_file)
        return self.label_map

    def __str__(self):
        annotations=[
          {"image_file": "图像文件绝对路径 (required)",
            "width": "图像宽 int", 
            "height": "图像高 int",
            "image": "opencv格式(optional)",
            "bndboxes":[
              { "xmin": "左上x int",
                "ymin": "左上y int",
                "xmax": "右下x int",
                "ymax": "右下y int",
                "name": "类别名",
                "score": "得分", # 检测评估用
              },  #(optional-检测任务)
            ], 
            "keypoints": [
              {"points": [{
                "x": "x坐标 int", 
                "y": "y坐标 int",
                },]
              }, 
            ], #(optional-关键点检测任务)
            "label": "(optional-分类任务)",
            "confidence": "分类评估用"
          }
        ]
        return "\033[32mstandard format: \n{}\033[37m".format(annotations)

    def load_annotations(self):
        """加载图像路径和标注文件并按照规定格式返回
        annotations=list(dict)
        定义见__str__

        标注文件类型各异(xml、txt、json等)子类自己实现

        Returns:
            list: annotations 
        """
        raise NotImplementedError('{}.load_annotations not available'.format(self.__class__.__name__))
