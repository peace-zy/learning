# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了yolov3_tensorflow格式转换成规定格式类。

xxx.txt
cls_name x_min,y_min,width,height
cls_name x_min,y_min,width,height

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2021/06/03 10:00:00
"""
import os
from dataset import base_reader
from utils import io, log
import logging
from lxml import etree
import traceback
from tqdm import tqdm
import cv2

class PaddleDetReader(base_reader.DataSet):
    """加载yolov3tf数据源
    Args:
        dataset_dir: 数据集根目录 
        image_dir: 图像路径子目录 (绝对路径=dataset_dir + "/" + image_dir)
                   或绝对路径(按需求)
        anno_dir: 标注文件路径子目录 (绝对路径=dataset_dir + "/" + image_dir)
                  或绝对路径(按需求)
        label_map_file: 存储类别id及类别名(根据需求自己定义解析)
    """
    def __init__(self, dataset_dir=None, image_dir=None,
            anno_dir=None, load_image=False):
        """初始化"""
        log.init_log(os.path.join("log", os.path.basename(__file__).split(".")[0]))
        super(PaddleDetReader, self).__init__(
                dataset_dir=dataset_dir,
                image_dir=image_dir,
                anno_dir=anno_dir,
                load_image=load_image)

    def load_annotations(self):
        """加载图像路径和标注文件并按照规定格式返回
        annotations=list(dict)
        annotations=[
          {"image_file": "图像文件绝对路径 (required)",
            "width": "图像宽 int", 
            "height": "图像高 int",
            "bndboxes":[
              { "xmin": "左上x int",
                "ymin": "左上y int",
                "xmax": "右下x int",
                "ymax": "右下y int",
                "name": "类别名"
              },  #(optional-检测任务)
            ], 
            "keypoints": [
              {"points": [{
                "x": "x坐标 int", 
                "y": "y坐标 int",
                },]
              }, 
            ], #(optional-关键点检测任务)
            "label": "(optional-分类任务)"
          }
        ]

        标注文件类型各异(xml、txt、json等)子类自己实现

        Returns:
            list: annotations 
        """
        image_dir = self.dataset_dir
        anno_dir = self.dataset_dir
        annotations = load_paddle_det_annotations(image_dir, anno_dir, self.load_image)
        self.annotations = annotations

def load_paddle_det_annotations(image_dir, anno_dir, load_image=False):
    """加载paddle_det转标准格式

    Args:
        image_dir: 图像路径
        anno_dir: 标注文件地址
        load_image: 是否加载图像

    Returns:
        Python list: 标准格式 
    """
    annotations = []

    images = set()
    image_dir = os.path.abspath(image_dir)
    exts = ['.jpg', '.jpeg', '.png', '.bmp']
    exts += [ext.upper() for ext in exts]
    for root, dirs, files in os.walk(image_dir):
        for f in files:
            for ext in exts:
                if ext in f:
                    images.add(os.path.join(root, f))
                    break
    images = list(images)

    for image_file in images:
        try:
            img_dir, img_name = os.path.split(image_file)
            image_name, post_fix = os.path.splitext(image_file)
            anno_file = image_name + '.txt'
            if not os.path.exists(anno_file):
                logging.warning("\033[31mThe {} does not existed\033[37m".format(anno_file))
                continue
            image = io.cv_imread_and_check(image_file)
            shape = image.shape
            bndboxes = []
            with open(anno_file, 'r') as anno_f:
                for line in anno_f:
                    fields = line.rstrip().split(' ')
                    if len(fields) < 6:
                        continue
                    name = fields[0]
                    if name == 'person':
                        xmin = int(float(fields[-4]))
                        ymin = int(float(fields[-3]))
                        xmax = xmin + int(float(fields[-2]))
                        ymax = ymin + int(float(fields[-1]))
                        bndboxes.append({"xmin": int(xmin),
                                         "ymin": int(ymin),
                                         "xmax": int(xmax),
                                         "ymax": int(ymax),
                                         "name": name})
            standard_anno = {}
            standard_anno["image_file"] = image_file
            standard_anno["height"] = int(shape[0])
            standard_anno["width"] = int(shape[1])
            if bndboxes:
                standard_anno["bndboxes"] = bndboxes
            if load_image:
                logging.info(load_image)
                standard_anno["image"] = image 
            annotations.append(standard_anno)
        except Exception as e:
            traceback.print_exc()
            continue
    return annotations

