#-*- coding: utf-8 -*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了基于TSNE特征降维并显示
Authors: zhangyan(zhangyan75@baidu.com)
Date:    2021/02/22 10:00:00
"""

import numpy as np
import matplotlib.pyplot as plt
import json
from sklearn.manifold import TSNE
from time import time

def gen_sample_data():
    """生成样例数据
    Returns:
        存储的json名 {'feature': [N x fea_dim], 'label': [N x 1]}
    """
    from sklearn.datasets.samples_generator import make_blobs
    fea_dim = 100
    # feature为样本特征，label为样本簇类别， 共1000个样本，每个样本100个特征，共3个簇
    # 簇中心在[-1,-1], [1,1], [2,2]， 簇方差分别为[0.4, 0.5, 0.2]
    feature, label = make_blobs(n_samples=1000, n_features=fea_dim,\
                     centers=[[-1 for i in range(fea_dim)], [1 for i in range(fea_dim)], [2 for i in range(fea_dim)]],\
                     cluster_std=[0.4, 0.5, 0.2])
    
    with open('data.json', 'w') as f:
        json.dump({'feature': feature.tolist(), 'label': label.tolist()}, f)
    return 'data.json'

def plot_embedding(feature, label, title):
    """显示特征 
    Args: 
        feature(numpy): 输入特征[N x fea_dim] N:样本个数；fea_dim: 特征维度 
        label(numpy): 输入特征对应的标签 [N x 1]
        title: 标题
    Returns:
        fig: plt.figure()
    """
    x_min, x_max = np.min(feature, 0), np.max(feature, 0)
    feature = (feature - x_min) / (x_max - x_min)

    fig = plt.figure()
    ax = plt.subplot(111)
    record = {}
    for i in range(feature.shape[0]):
        plt.text(feature[i, 0], feature[i, 1], str(label[i]),
                 color=plt.cm.Set1(label[i]),
                 fontdict={'weight': 'bold', 'size': 10})
        if label[i] not in record:
            record[label[i]] = plt.cm.Set1(label[i] / 10.)
    print (record)
    plt.xticks([])
    plt.yticks([])
    plt.title(title)
    return fig

def main(emb_filename):
    """
    Args: 
        emb_filename: json文件名 
                      json数据格式{'feature': [N x fea_dim], 'label': [N x 1]}
    """

    model = json.load(open(emb_filename, 'r')) 
    feature = np.array(model['feature'])
    label = np.array(model['label'])
    '''t-SNE'''
    tsne = TSNE(n_components=2,
            init='pca',
            random_state=None,
            method='barnes_hut',
            perplexity=30.0,
            early_exaggeration=12.0,
            learning_rate=200.0,
            n_iter=1000,
            n_iter_without_progress=300,
            min_grad_norm=1e-07,
            metric='euclidean',
            verbose=0,
            angle=0.5,
            n_jobs=None)
    t0 = time()
    feature_tsne = tsne.fit_transform(feature)
    print(feature.shape)
    print(feature_tsne.shape)
    print(label.shape)
    print("Org data dimension is {}.Embedded data dimension is {}".format(feature.shape[-1], feature_tsne.shape[-1]))

    '''嵌入空间可视化'''

    fig = plot_embedding(feature, label,
                     't-SNE embedding of the digits (time %.2fs)'
                     % (time() - t0))
    plt.savefig('view_data_in_low_dim.jpg')
if __name__ == '__main__':
    emb_filename = gen_sample_data()
    main(emb_filename)
