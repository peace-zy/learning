# 图像爬虫工具 
## 教程
<百度搜索引擎>
sh crawl_image.sh Baidu {input}

<Bing搜索引擎>
sh crawl_image.sh Bing {input}

<Google搜索引擎>
sh crawl_image.sh Google {input}
