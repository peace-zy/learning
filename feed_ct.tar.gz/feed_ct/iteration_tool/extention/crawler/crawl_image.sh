#!/bin/bash

function search_engine()
{
    input=$1
    func=$2
    if [ "$func" == "Google" ];then
        export https_proxy=https://agent.baidu.com:8118
        export http_proxy=http://agent.baidu.com:8118
    fi
    save_path=$func
    parser_threads=4
    parser_threads=1
    downloader_threads=5
    downloader_threads=1
    python crawl_image.py --input $input \
                          --save_path $save_path \
                          --save_url \
                          --parser_threads $parser_threads \
                          --downloader_threads $downloader_threads \
                          --func $func
}

function usage()
{
    echo -e """usage:\e[32m
        <百度搜索引擎>
        sh crawl_image.sh Baidu {input}

        <Bing搜索引擎>
        sh crawl_image.sh Bing {input}

        <Google搜索引擎>
        sh crawl_image.sh Google {input}
        \e[0m
        """
}

#===========================
#   MAIN SCRIPT
#===========================

if [ $# -eq 0 ];
then
    usage
    exit
fi

func=$1
echo "run: "$func
if [ "$func" = "Baidu" ];then
    input=$2
    search_engine $input $func
elif [ "$func" = "Bing" ];then
    input=$2
    search_engine $input $func
elif [ "$func" = "Google" ];then
    input=$2
    search_engine $input $func
else
    echo "invalid input param"
fi
