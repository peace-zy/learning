import os
import sys

this_dir = os.path.dirname(__file__)

aug_path = os.path.join(this_dir, '..')
if aug_path not in sys.path:
    sys.path.insert(0, aug_path)
