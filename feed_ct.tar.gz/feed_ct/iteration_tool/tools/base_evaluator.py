# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了一个评估基类。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/04/03 10:00:00
"""

from utils import dataset_util

class Evaluator(object):
    """评估基类
    Args:
        gt_in:  真值数据集输入(按需求)
        pre_in: 预测值数据集输入(按需求)
        star_thres: 起始阈值 
        end_thres: 终止阈值 
        thres_step: 阈值步长
        label_map_file: 存储类别id及类别名(根据需求自己定义解析)
        output_dir: 评估结果存储地址 
    """
    def __init__(self,
            gt_in=None,
            pre_in=None, 
            start_thres=0.5,
            end_thres=1.0,
            thres_step=0.1,
            label_map_file=None,
            output_dir=None):
        """初始化"""
        self.gt_in = gt_in
        self.pre_in = pre_in
        self.start_thres = start_thres
        self.end_thres = end_thres
        self.thres_step = thres_step
        self.label_map_file = label_map_file 
        self.label_map = None
        self.output_dir = output_dir

        self.gt_annos = None
        self.pre_annos = None

    def evaluate(self, gt_annos=None, pre_annos=None):
        """根据任务实现不同评估方法
        gt_anno: list(dict)  标准格式
        pre_anno: list(dict) 标准格式
        """
        if gt_annos is not None:
            self.gt_annos = gt_annos
        else:
            self.gt_annos = self.get_gt_annos()
        if pre_annos is not None:
            self.pre_annos = pre_annos
        else:
            self.pre_annos = self.get_pre_annos()

        if self.gt_annos is None or self.pre_annos is None:
            raise ValueError('{}.eval gt_annos or pre_annos is empty'.format(self.__class__.__name__))
        self.eval_for_task()
        
    def eval_for_task(self):
        """根据任务实现不同评估方法
        gt_annos=list(dict)
        pre_annos=list(dict)
        标准格式
        子类实现评估方式及存储评估结果

        """
        raise NotImplementedError('{}.eval_for_task not available'.format(self.__class__.__name__))

    def get_gt_annos(self):
        """按需求子类可实现自己获取真值方式 gt_in"""
        return self.gt_annos

    def get_pre_annos(self):
        """按需求子类可实现自己获取预测值方式 pre_in"""
        return self.pre_annos

    def get_label_map_file(self):
        """获取标签映射表文件路径"""
        return self.label_map_file

    def get_label_map(self):
        """获取标签映射表"""
        if not self.label_map_file:
            raise ValueError("label_map_file [{}] dones not exists!".format(self.label_map_file))
        self.label_map = dataset_util.load_label_map(self.label_map_file)
        return self.label_map
