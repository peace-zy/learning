# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了一个检测评估类。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/04/03 10:00:00
"""
import os
from tqdm import tqdm
import numpy as np
import logging
from utils import io, log, eval_util
from tools import base_evaluator

INFO="\033[32m[INFO] | {}\033[37m"

class DetEvaluator(base_evaluator.Evaluator):
    """评估类"""
    def __init__(self, 
            iou_thres=0.35,
            start_thres=0.5,
            end_thres=1.0,
            thres_step=0.1,
            label_map_file=None,
            output_dir="eval_det_outputs"):
        """初始化"""
        log.init_log(os.path.join("log", os.path.basename(__file__).split(".")[0]))
        super(DetEvaluator, self).__init__(
                start_thres=start_thres,
                end_thres=end_thres,
                thres_step=thres_step,
                label_map_file=label_map_file,
                output_dir=output_dir)

        self.iou_thres = iou_thres 

    def eval_for_task(self):
        """根据任务实现不同评估方法
        gt_annos=list(dict)
        pre_annos=list(dict)
        标准格式
        子类实现评估方式及存储评估结果
        """
        self.label_map = self.get_label_map()
        if not self.gt_annos or not self.pre_annos or not self.label_map.keys():
            logging.error("invalid input [gt_annos]:{}, [pre_annos]:{}, [label_map.keys()]:{}"\
                    .format(len(self.gt_annos), len(self.pre_annos), len(self.label_map.keys())))
            return False

        gt_dict = eval_util.make_det_dict(self.gt_annos)
        pre_dict = eval_util.make_det_dict(self.pre_annos)
        if not self.eval_rec_prec(gt_dict, pre_dict):
            raise ValueError("eval error")

    def eval_rec_prec(self, gt_dict, pre_dict):
        """评估召回率和准确率
        Returns:
            bool: 成功返回True 
                  参数非法返回False
        """

        result = self.calc_by_score_thres(gt_dict, pre_dict)
        if not result:
            logging.warning("results is empty")
            return True
        self.write_result(result)
        return True

    def write_result(self, result):
        """存储结果
        Args:
            result: Python dict评估结果 
                    {cls: [{"score_thres": 0.5, 
                    "image_level":{"pos": 0, "tp": 0, "fp": 0, "recall": 0.4, "precision": 0.7, "image_paths"},
                    "object_level": {"pos": 0, "tp": 0, "fp": 0, "recall": 0.4, "precision": 0.7}}]} 
        Returns:
        """

        io.make_path(self.output_dir)
        save_file = os.path.join(self.output_dir, "eval_result.txt")
        N = 15
        with open(save_file , "w") as f:
            for cls in self.label_map.keys():
                wline = "{0:=^76}\n{1:10}{2:-^33}{3:-^33}\n".format(cls, "", "object_level", "image_level")
                wline += "{0:^10}|{1:^10}|{2:^10}|{3:^10}|{4:^10}|{5:^10}|{6:^10}\n".format(
                         "thres", "recall", "precision", "F1_score", "recall", "precision", "F1_score")
                for per_cls_result in result[cls]:
                    score_thres = per_cls_result["score_thres"]
                    object_level_result = per_cls_result["object_level"]
                    ob_recall = object_level_result["recall"]
                    ob_precision = object_level_result["precision"]
                    if ob_recall + ob_precision == 0:
                        ob_F1_score = 0
                    else:
                        ob_F1_score = 2 * ob_recall * ob_precision / (ob_recall + ob_precision)
                    image_level_result = per_cls_result["image_level"]
                    im_recall = image_level_result["recall"]
                    im_precision = image_level_result["precision"]
                    if im_recall + im_precision == 0:
                        im_F1_score = 0
                    else:
                        im_F1_score = 2 * im_recall * im_precision / (im_recall + im_precision)
                    wline += "{0:^10.2f}|{1:^10.2f}|{2:^10.2f}|{3:^10.2f}|{4:^10.2f}|{5:^10.2f}|{6:^10.2f}\n".format(
                             score_thres, ob_recall, ob_precision, ob_F1_score, im_recall, im_precision, im_F1_score)
                f.write(wline)
                print(wline)

        for cls in self.label_map.keys():
            for per_cls_result in result[cls]:
                score_thres = per_cls_result["score_thres"]
                image_level_result = per_cls_result["image_level"]
                save_det_image_file = os.path.join(self.output_dir, cls + "_" + str(score_thres) + "_image.txt")
                with open(save_det_image_file, "w") as f:
                    image_paths = image_level_result["image_paths"]
                    for image_path in image_paths:
                        f.writelines(image_path + " " + cls + "\n")

    def calc_by_score_thres(self, gt_dict, pre_dict):
        """根据阈值计算评估结果
        Returns:
            result: Python dict评估结果 
                    {cls: [{"score_thres": 0.5, 
                           "image_level":{"pos": 0, "tp": 0, "fp": 0, "recall": 0.4, "precision": 0.7, "image_paths"},
                           "object_level": {"pos": 0, "tp": 0, "fp": 0, "recall": 0.4, "precision": 0.7}}]} 
        """

        result = {} 

        print("\033[33m"+ 40 * "-" + " Evaluating for detection " + 40 * "-" + "\033[37m")
        logging.info("the number of postive image: [{}] | the number of detected image: [{}]"\
                .format(len(gt_dict), len(pre_dict)))
        for cls in tqdm(self.label_map.keys()):
            for score_thres in np.arange(self.start_thres, self.end_thres, self.thres_step):
                per_cls_result = self.calc_per_cls_result(cls, gt_dict, pre_dict, score_thres)
                # calculate object level recall&precision
                object_level_result = self.calc_recall_precision(per_cls_result["object_level"])
                per_cls_result["object_level"] = object_level_result

                # calculate image level recall&precision
                image_level_result = self.calc_recall_precision(per_cls_result["image_level"])
                per_cls_result["image_level"] = image_level_result
                per_cls_result["score_thres"] = score_thres 

                if cls not in result:
                    result[cls] = [] 
                result[cls].append(per_cls_result) 
        print("\033[33m" +110 * "-" + "\n\033[37m")
        return result

    def calc_per_cls_result(self, cls, gt_dict, pre_dict, score_thres):
        """根据阈值计算每一类评估结果
        Args:
            cls: 类别
            score_thres: 阈值
        Returns:
            result: Python dict每一类评估结果 
                    {"image_level":{"pos": 0, "tp": 0, "fp": 0, "image_paths"}, "object_level": {"pos": 0, "tp": 0, "fp": 0}}]} 
        """

        per_cls_result = {"object_level":{"pos": 0, "tp": 0, "fp": 0},
                               "image_level":{"pos": 0, "tp": 0, "fp": 0, "image_paths":[]}}
        for image_name, dets in pre_dict.items():
            if image_name not in gt_dict:
                continue
            gts = gt_dict[image_name]
            gt_bndboxes = eval_util.get_specified_class_bndbox(gts, cls)

            if not gt_bndboxes:
                continue 

            per_cls_result["object_level"]["pos"] += len(gt_bndboxes)
            specified_dets = eval_util.get_specified_class_bndbox(dets, cls)
            image_level_flag = "" 
            for per_det in specified_dets: 
                score = per_det["score"]
                if score < score_thres:
                    continue
                image_level_flag = "fp"
                ious = np.array([eval_util.iou(per_det, gt_bndbox) for gt_bndbox in gt_bndboxes])
                if ious[np.argmax(ious)] >= self.iou_thres:
                    per_cls_result["object_level"]["tp"] += 1        
                    image_level_flag = "tp"
                else:
                    per_cls_result["object_level"]["fp"] += 1        

            per_cls_result["image_level"]["pos"] += 1 
            if image_level_flag == "tp":
                per_cls_result["image_level"]["tp"] += 1 
                per_cls_result["image_level"]["image_paths"].append(image_name) 
            elif image_level_flag == "fp":
                per_cls_result["image_level"]["fp"] += 1 

                #print(INFO.format("\t".join([str(ious[np.argmax(ious)]), cls, str(score)])))
        return per_cls_result

    def calc_recall_precision(self, cls_result):
        """计算召回率和准确率
        Args:
            cls_result: 
                    {"pos": 0, "tp": 0, "fp": 0, "image_paths"} or
                    {"pos": 0, "tp": 0, "fp": 0}

        Returns:
            计算后的召回率和准确率
        """

        pos_num = float(cls_result["pos"])
        cls_result["recall"] = 0 if (pos_num == 0) else cls_result["tp"] / pos_num * 100

        det_num = float(cls_result["tp"] + cls_result["fp"])
        cls_result["precision"] = 0 if det_num == 0 else cls_result["tp"] / det_num * 100 
        return cls_result

