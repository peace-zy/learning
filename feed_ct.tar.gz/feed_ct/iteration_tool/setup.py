# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了函数导出功能。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2021/05/11 10:00:00
"""

from distutils.core import setup
from distutils.extension import Extension
from Cython.Build import cythonize
from Cython.Distutils import build_ext
import os
import shutil

BUILD_PATH = ''
def get_ext_filename_without_platform_suffix(filename):
    """get_ext_filename_without_platform_suffix"""
    filename = filename.split('.')[0] + '.so'
    print('\033[32m{}\033[0m'.format(filename))
    return filename

class BuildExtWithoutPlatformSuffix(build_ext):
    """BuildExtWithoutPlatformSuffix"""
    def get_ext_filename(self, ext_name):
        """get_ext_filename"""
        filename = super().get_ext_filename(ext_name)
        global BUILD_PATH
        BUILD_PATH = self.build_lib
        return get_ext_filename_without_platform_suffix(filename)


def main():
    """main"""
    copy_funcs = {
            'conf': ['__init__.py', 'factory.py'],
            'dataset': ['__init__.py', 'base_reader.py', 'base_writer.py'],
            'transform': ['__init__.py', 'base_operator.py'],
            }

    export_funcs = {
            'conf': ['conf_sequential.py'],
            'transform': ['mask_paster.py', 'augmentater.py'],
            'dataset': ['classification_reader.py', 'voc_reader.py', 'classification_writer.py', 'voc_writer.py'],
            'utils': ['dataset_util.py', 'io.py', 'log.py', 'iterative_tool_util.py', 'transform_util.py']
            }

    extensions = []
    for sub_path, funcs in export_funcs.items():
        for f in funcs:
            import_path = sub_path + '.'
            if '.' in f:
                name = f.split('.')[0]
            else:
                name = f
            import_path += name
            loc_file = os.path.join(sub_path, f)
            print(import_path, loc_file)
            extensions.append(Extension(import_path, [loc_file]))

    setup(name='wrapper',
          cmdclass={'build_ext': BuildExtWithoutPlatformSuffix},
          ext_modules=cythonize(extensions))

    for sub_path, funcs in copy_funcs.items():
        for f in funcs:
            loc_file = os.path.join(sub_path, f)
            save_path = os.path.join(BUILD_PATH, sub_path)
            if not os.path.exists(save_path):
                os.makedirs(save_path)
            save_file = os.path.join(save_path, f)
            shutil.copy(loc_file, save_file)

if __name__ == '__main__':
    main()
