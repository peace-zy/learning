#!/usr/bin/env python
# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Setup script.

Authors: zhangyan75(zhangyan75@baidu.com)
Date:    2021/02/24 14:48:52
"""

import setuptools

setuptools.setup()

