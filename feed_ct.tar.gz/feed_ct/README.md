Feed Ct
===
feed例行任务

快速开始
---
如何构建、安装、运行

测试
---
如何执行自动化测试

如何贡献
---
贡献patch流程及质量要求

版本信息
---
本项目的各版本信息和变更历史可以在[这里][changelog]查看。

维护者
---
### owners
* zhangyan75(zhangyan75@baidu.com)

### committers
* zhangyan75(zhangyan75@baidu.com)

讨论
---
百度Hi交流群：群号


[changelog]: http://icode.baidu.com/repos/baidu/fengkong/feed_ct/blob/master:CHANGELOG.md
