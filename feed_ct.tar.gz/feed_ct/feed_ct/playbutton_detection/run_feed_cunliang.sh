#!/bin/bash
#coding:UTF-8

#set -e

source /etc/profile
source /home/users/liuxing07/.bash_profile
source /home/users/liuxing07/.bashrc

task_modelname="qipai"
task_num=4
start_hour=$1


CURPATH="/home/users/liuxing07/cloud/online/paddle/qipai/feed_output"
LOCAL_DATAIN=${CURPATH}/${task_modelname}/input
LOCAL_DATAOUT=${CURPATH}/${task_modelname}/output
LOCAL_DATALOG=${CURPATH}/${task_modelname}/log

#DATA_ADDR="afs://tianqi.afs.baidu.com:9902/app/ecom/native-ad-price/feedads-quality/gaoyongchun/image_tmp/${task_modelname}"
DATA_ADDR="afs://tianqi.afs.baidu.com:9902/app/ecom/native-ad-price/feedads-quality/gaoyongchun/image_tmp/qipai"
AFS_DATAIN=${DATA_ADDR}/input
AFS_DATAOUT=${DATA_ADDR}/output

HADOOP_HOME="/home/users/liuxing07/cloud/hadoop/hadoop-client/hadoop"
PYTHON_HOME="/home/users/liuxing07/cloud/miniconda3/envs/paddle"

hadoop=${HADOOP_HOME}/bin/hadoop
python_bin=${PYTHON_HOME}/bin/python
python_script=${CURPATH}/ct_feed_${task_modelname}.py

function makedir()
{
    dir_path=$1
    if [ ! -d ${dir_path} ];then
        /bin/mkdir -p ${dir_path}
    fi
}

function info_echo()
{
    msg=$1
    echo -e "\e[32m[ $(date '+%Y-%m-%d %H:%M:%S') ]\e[0m" ${msg}
}

function check_local_dir()
{
    local_path=$1
    if [ ! -d ${local_path} ];then
        info_echo "[local] dir not exists![${local_path}]"
        return 22
    fi
    return 0
}

function check_local_file()
{
    local_file=$1
    if [ ! -f ${local_file} ];then
        info_echo "[local] file not exists![${local_file}]"
        return 22
    fi
    return 0
}

function check_local()
{
    local_path=$1
    check_local_dir ${local_path} && check_local_file ${local_path}/done && check_local_file ${local_path}/data
    if [ $? -ne 0 ];then
        info_echo "[local] data missing![${local_path}]"
        return 22
    fi
    return 0
}

function check_afs()
{
    afs_hour_file=$1
    ${hadoop} fs -D hadoop.job.ugi=fcr-tianqi-d,absUPEwUB7nc -test -e ${afs_hour_file}
    if [ $? -ne "0" ];then
        info_echo "[afs] hour directory not exist![${afs_hour_file}]"
        return 22
    fi
    ${hadoop} fs -D hadoop.job.ugi=fcr-tianqi-d,absUPEwUB7nc -test -e ${afs_hour_file}/done
    if [ $? -ne "0" ];then
        info_echo "[afs] data is not done![${afs_hour_file}]"
        return 22
    fi
    ${hadoop} fs -D hadoop.job.ugi=fcr-tianqi-d,absUPEwUB7nc -test -e ${afs_hour_file}/data
    if [[ $? -ne "0" ]];then
        info_echo "[afs] done file exists but data file not exists![${afs_hour_file}]"
        return 22
    fi
    return 0
}

function process_hour_data()
{
    this_day=$1
    this_hour=$2
    afs_output_date_hour=${AFS_DATAOUT}/${this_day}/${this_hour}
    check_afs ${afs_output_date_hour}
    if [ $? -eq 0 ];then
        return 0
    fi
    local_output_date_hour=${LOCAL_DATAOUT}/${this_day}/${this_hour}
    check_local ${local_output_date_hour}
    if [ $? -eq 0 ];then
        ${hadoop} fs -D hadoop.job.ugi=fcr-tianqi-d,absUPEwUB7nc -mkdir -p ${afs_output_date_hour}
        ${hadoop} fs -D hadoop.job.ugi=fcr-tianqi-d,absUPEwUB7nc -copyFromLocal ${local_output_date_hour}/data ${afs_output_date_hour}
        ${hadoop} fs -D hadoop.job.ugi=fcr-tianqi-d,absUPEwUB7nc -copyFromLocal "${local_output_date_hour}/done" ${afs_output_date_hour}
        #${hadoop} fs -D hadoop.job.ugi=fcr-tianqi-d,absUPEwUB7nc -touchz "${afs_output_date_hour}/done"
        return 0
    fi

    afs_input_date_hour=${AFS_DATAIN}/${this_day}/${this_hour}
    check_afs ${afs_input_date_hour}
    if [ $? -ne 0 ];then
        return 22
    fi
    ${hadoop} fs -D hadoop.job.ugi=fcr-tianqi-d,absUPEwUB7nc -test -z ${afs_input_date_hour}/data
    if [ $? -eq 0 ];then
        makedir ${local_output_date_hour}
        /bin/touch ${local_output_date_hour}/data
    else
        local_input_date=${LOCAL_DATAIN}/${this_day}
        local_input_date_hour=${local_input_date}/${this_hour}
        check_local ${local_input_date_hour}
        if [ $? -ne 0 ];then
            makedir ${local_input_date}
            ${hadoop} fs -D hadoop.job.ugi=fcr-tianqi-d,absUPEwUB7nc -copyToLocal ${afs_input_date_hour} ${local_input_date}
            if [[ $? -ne 0 ]];then
                info_echo "[afs] get file failed![${afs_input_date_hour}]"
                /bin/rm -rf ${local_input_date_hour}
                return 22
            fi
        fi

        check_local_file ${local_output_date_hour}/data
        if [ $? -eq 0 ];then
            info_echo "output data is generating by other process!"
            return 0
        fi
        makedir ${local_output_date_hour}
        python_log="${LOCAL_DATALOG}/${this_day}/feed_${task_modelname}_${this_day}_${this_hour}_python.log"
        makedir ${python_log%/*}
        echo "processing data [${local_input_date_hour} ...]"
        ${python_bin} ${python_script} ${local_input_date_hour}/data ${local_output_date_hour}/data ${python_log} ${task_modelname}
    fi
    /bin/touch ${local_output_date_hour}/done
    check_local ${local_output_date_hour}
    if [ $? -ne 0 ];then
        info_echo "process data(including data/done file) failed![${local_output_date_hour}]"
        /bin/rm -rf ${local_output_date_hour}
        return 22
    fi

    ${hadoop} fs -D hadoop.job.ugi=fcr-tianqi-d,absUPEwUB7nc -test -e ${afs_output_date_hour}
    if [ $? -eq 0 ];then
        ${hadoop} fs -D hadoop.job.ugi=fcr-tianqi-d,absUPEwUB7nc -rmr ${afs_output_date_hour}
    fi
    ${hadoop} fs -D hadoop.job.ugi=fcr-tianqi-d,absUPEwUB7nc -mkdir ${afs_output_date_hour}
    ${hadoop} fs -D hadoop.job.ugi=fcr-tianqi-d,absUPEwUB7nc -copyFromLocal ${local_output_date_hour}/data ${afs_output_date_hour}
    ${hadoop} fs -D hadoop.job.ugi=fcr-tianqi-d,absUPEwUB7nc -copyFromLocal ${local_output_date_hour}/done ${afs_output_date_hour}
    #${hadoop} fs -D hadoop.job.ugi=fcr-tianqi-d,absUPEwUB7nc -touchz ${afs_output_date_hour}/done
    check_afs ${afs_output_date_hour}
    if [ $? -ne 0 ];then
        return 22
    fi
    echo "processing data [${local_input_date_hour} done!]"
    return 0
}

function process_during_data()
{
    #定时任务启动脚本数量，每个任务负责一段小时内处理任务，中台最迟等待5小时内,定时任务每两小时启动一次
    task_num=$1
    hour_during=$[24/task_num]
    start_hour=$2

    this_day=$(date +%Y%m%d --date today)
    yesterday=$(date +%Y%m%d --date last-day)
    day_before_yesterday=$(date +%Y%m%d --date '2 day ago')
    check_days={$yesterday,$this_day}

    #for (( hour=${start_hour};hour<24;hour=hour+${hour_during} ))
    for hour in $(seq -w ${start_hour} ${task_num} 23)
    do
        for day in {$yesterday,$this_day}
        do
            process_hour_data ${day} ${hour}
        done
    done
}

# script-1: 00 04 08 12 16 20
# script-2: 01 05 09 13 17 21
# script-3: 02 06 10 14 18 22
# script-4: 03 07 11 15 19 23

#process_during_data ${task_num} $start_hour

function process_cunliang()
{
    begin_day=20201230
    end_day=20201230
    begin_second=$(date -d ${begin_day} +%s)
    end_second=$(date -d ${end_day} +%s)

    if [[ ${begin_second} > ${end_second} ]];then
        echo "The end_date < begin_date"
        exit 1
    fi

    for (( i=${begin_second};i<=${end_second};i=i+86400 ))
    do
        this_day=$(date -d @${i} +%Y%m%d)
        hours="01,04"
        for hour in $(echo ${hours}|awk -F',' '{for(i=1;i<=NF;i=i+1) print $i}')
        #for hour in $(seq -w 15 23)
        do
            echo ${this_day}-${hour}
            process_hour_data ${this_day} ${hour}
        done
    done
}

function remove_10day_before_data()
{
    remove_dir=$1
    /bin/find ${remove_dir} -mtime +10 |xargs /bin/rm -rf
}
process_cunliang
#process_during_data ${task_num} ${start_hour}
#remove_10day_before_data ${LOCAL_DATAIN}
