"""
filename:   play_button_recgnition.py
description:    play_button_recgnition (circle/triangle recgnition by custom CV technique)
author:     liuxing07@baidu.com
"""

#!/usr/bin/env python
#coding:UTF-8

import os
import sys

_curpath = os.path.dirname(os.path.abspath(__file__))

assert sys.version_info.major == 3, "python3.x script!"

import numpy as np
import hashlib
from scipy import ndimage
import collections
import logging
import json
import requests
import cv2

sobel_x_kernel = np.array([[-1, 0, 1],
                           [-2, 0, 2],
                           [-1, 0, 1]])
sobel_y_kernel = np.array([[-1, -2, -1],
                           [0, 0, 0],
                           [1, 2, 1]])
sobel_45_kernel = np.array([[-1, -2, 0],
                            [-1, 0, 1],
                            [0, 1, 2]])
sobel_135_kernel = np.array([[0, -1, -2],
                             [1, 0, -1],
                             [2, 1, 0]])

def calculate_line_formula(endpoint):
    """
    endpoint: np.array([[x1,y1,x2,y2]], dtype=np.float32)
    return: A, B, C
    """
    if isinstance(endpoint, np.ndarray):
        x1, y1, x2, y2 = np.split(endpoint, endpoint.shape[1], axis=1)
    else:
        x1, y1, x2, y2 = endpoint
    #     k = (y2 - y1) / (x2 - x1 + 1e-6)
    #     b = np.mean(np.array([y1, y2]) - np.array([x1, x2]) * k)
    #     return k, b
    A = y2 - y1
    B = x1 - x2
    C = -0.5 * (A * x1 + B * y1 + A * x2 + B * y2)

    return np.hstack((A, B, C))


def calculate_cross_point(line1, line2):
    """
    line: (k, b)
    return: crossing point corordidate:(x, y)
    """
    #     A1, B1, C1 = line1
    #     A2, B2, C2 = line2
    A1, B1, C1 = line1
    A2, B2, C2 = line2

    x = -1 * (C1 * B2 - C2 * B1) / (A1 * B2 - A2 * B1 + 1e-6)
    y = -1 * (C1 * A2 - C2 * A1) / (B1 * A2 - B2 * A1 + 1e-6)
    return x, y


def is_point_in_poly(point, point_list):
    """
    point: input point which needs to be calculate
    point_list: points with clock order of poly
    """
    isum = 0
    point_x, point_y = point
    icount = len(point_list)

    if icount < 3:
        return False
    for i in range(icount):
        p_start_x, p_start_y = point_list[i]
        if i == icount - 1:
            p_end_x, p_end_y = point_list[0]
        else:
            p_end_x, p_end_y = point_list[i + 1]
    if ((p_end_y > point_y) and (point_y >= p_start_y)) or ((p_end_y < point_y) and (point_y <= p_start_y)):
        A, B, C = calculate_line_formula((p_start_x, p_start_y, p_end_x, p_end_y))
        if not A == 0:
            point_x_infer = -1 * (B * point_y + C)/A
            if point_x_infer < point_x:
                isum += 1
    if isum % 2 != 0:
        return True
    else:
        return False

def point_line_distance(point, line):
    """
    point: (x, y)
    line:  (A, B, C)直线方程参数
    """
    x, y = point
    if isinstance(line, np.ndarray):
        A, B, C = np.split(line, line.shape[1], axis=1)
    else:
        A, B, C = line

    #     return np.abs(A*x + B*y + C) / (np.sqrt(A*A + B*B))

    return np.abs(A * x + B * y + C) / (np.linalg.norm(np.hstack((A, B)), axis=1)[:, np.newaxis] + 1e-6)

def is_ZH(image_file):
    """
    '包含汉字的返回TRUE'
    'ord(c_str) > 255 的字符均为中文'
    """
    for c_str in image_file:
        if '\u4e00' <= c_str <= '\u9fa5':
            return True
    return False


def cv_imread_check(image_file):
    """
    read image from url or local file
    """
    if image_file.startswith("http"):
        image = cv2.imdecode(np.frombuffer(requests.get(image_file).content, dtype=np.uint8), cv2.IMREAD_COLOR)
    else:
        if not os.path.exists(image_file):
            print('image not exists![{}]'.format(image_file))
            return None
        if not is_ZH(image_file):
            image = cv2.imread(image_file, cv2.IMREAD_COLOR)
        else:
            image = cv2.imdecode(np.fromfile(image_file, dtype=np.uint8), cv2.IMREAD_COLOR)
    image_shape = image.shape
    num = len(image_shape)
    if num == 2:
        print('gray image file![{}]'.format(image_file))
        # image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    elif num == 3:
        channels = image_shape[-1]
        if channels == 4:
            image = cv2.cvtColor(image, cv2.COLOR_BGRA2BGR)
        elif not channels == 3:
            print('image shape not supported![{}]'.format(image_shape))
            return None

    else:
        print('image shape error![{}]'.format(image_shape))
        return None
    return image


def button_recgnition(image_origin=None, button_detection_taginfo=""):
    """
    button_recgnition main function
    """
    result = {"label": "play_button", "result":[]}
    if image_origin is None or button_detection_taginfo == "":
        return result

    pixl_error = 5  # button检测框向外延伸长度
    taginfo_dict = json.loads(button_detection_taginfo, encoding="GBK")
    confidence = taginfo_dict["confidence"]
    x = max(0, int(taginfo_dict["position"]["x"]) - pixl_error)
    y = max(0, int(taginfo_dict["position"]["y"]) - pixl_error)
    width = int(taginfo_dict["position"]["width"])
    height = int(taginfo_dict["position"]["height"])
    x1 = min(image_origin.shape[1], int(taginfo_dict["position"]["x"]) + width + pixl_error)
    y1 = min(image_origin.shape[0], int(taginfo_dict["position"]["y"]) + height + pixl_error)
    image_data_button = image_origin[y:y1, x:x1, :]

    image_data_gray = cv2.cvtColor(image_data_button, cv2.COLOR_RGB2GRAY)
    #    image_data_gray_binblur = cv2.bilateralFilter(src=image_data_gray, d=3, sigmaColor=100, sigmaSpace=20)
    #    image_data_canny_edges_min20 = cv2.Canny(image=image_data_gray, threshold1=20, threshold2=150, apertureSize=3, L2gradient=False)
    image_data_gray_binblur = image_data_gray.copy()
    image_data_sobel_edges_45 = cv2.filter2D(src=image_data_gray_binblur,
                                             ddepth=cv2.CV_32F,
                                             kernel=sobel_45_kernel,
                                             anchor=(-1, -1),
                                             delta=0,
                                             borderType=cv2.BORDER_DEFAULT)
    image_data_sobel_edges_135 = cv2.filter2D(src=image_data_gray_binblur,
                                              ddepth=cv2.CV_32F,
                                              kernel=sobel_135_kernel,
                                              anchor=(-1, -1),
                                              delta=0,
                                              borderType=cv2.BORDER_DEFAULT)
    image_data_sobel_edges_h = cv2.Sobel(src=image_data_gray_binblur,
                                         ddepth=cv2.CV_32F,
                                         dx=1,
                                         dy=0,
                                         ksize=3,
                                         scale=1,
                                         delta=0,
                                         borderType=cv2.BORDER_DEFAULT)
    #     image_data_sobel_edges = cv2.magnitude(x=image_data_sobel_edges_h, y=image_data_sobel_edges_v)#.astype(np.uint8)
    image_data_sobel_edges_combine = np.abs(image_data_sobel_edges_45) * 0.4 + \
                                    np.abs(image_data_sobel_edges_135) * 0.4 + \
                                    np.abs(image_data_sobel_edges_h) * 0.2
    image_data_sobel_edges_combine_scale = cv2.convertScaleAbs(src=image_data_sobel_edges_combine, alpha=1.0, beta=0.0)
    image_data_circle = cv2.HoughCircles(image=image_data_sobel_edges_combine_scale,
                                         method=cv2.HOUGH_GRADIENT,
                                         dp=1,
                                         minDist=int(min(width, height) / 2),
                                         param1=100,
                                         param2=30,
                                         minRadius=int(min(width, height) / 4),
                                         maxRadius=int(min(width, height) / 2))
    if image_data_circle is None:
        return result
    logging.info("Hough circle done!")
    circles = image_data_circle[0, :, :]
    # 圆心距离检测框边界很近，判定此圆为缺损圆，非完整圆，忽略
    circle_tmp = [i for i in circles[:] if min(x1 - x - i[0], y1 - y - i[1]) > i[2]]
    if len(circle_tmp) < 1:
        return result

    # 挑选最靠近中心点的圆
    distance_circle_dict = {np.linalg.norm(np.array([x1 - x, y1 - y]) / 2.
                                           - np.array([item[0], item[1]])): item for item in circle_tmp}
    image_data_circle_valid = sorted(distance_circle_dict.items(), key=lambda x: x[0], reverse=False)[0]


    # 凸现纹理，放大进行腐蚀
    image_data_sobel_edges_use_thresh = np.sqrt(10 * cv2.mean(image_data_sobel_edges_combine_scale)[0])
    ret, image_data_sobel_edges_combine_scale_thresh = cv2.threshold(src=image_data_sobel_edges_combine_scale,
                                                                     thresh=image_data_sobel_edges_use_thresh,
                                                                     maxval=255,
                                                                     type=cv2.THRESH_BINARY)
    resize_ratio = 2
    image_data_sobel_edges_aftermask_resize_up = cv2.resize(src=image_data_sobel_edges_combine_scale_thresh,
                                                            dsize=(0, 0),
                                                            fx=resize_ratio,
                                                            fy=resize_ratio,
                                                            interpolation=cv2.INTER_LINEAR)
    morph_kernel = cv2.getStructuringElement(shape=cv2.MORPH_RECT, ksize=(3, 3))  #cv.MORPH_CROSS, cv.MORPH_ELLIPSE
    image_data_sobel_edges_aftermask_erode = cv2.erode(src=image_data_sobel_edges_aftermask_resize_up,
                                                       kernel=morph_kernel,
                                                       iterations=1)
    image_data_sobel_edges_aftermask_resize_down = cv2.resize(src=image_data_sobel_edges_aftermask_erode,
                                                              dsize=(0, 0),
                                                              fx=1. / resize_ratio,
                                                              fy=1. / resize_ratio,
                                                              interpolation=cv2.INTER_LINEAR)
    image_data_sobel_edges_use = image_data_sobel_edges_aftermask_resize_down
    logging.info("crop image erode done!")


    # 遮挡圆形之外的无效内容
    image_circle_distance_tmp = np.ones_like(image_data_sobel_edges_use)
    circle_x, circle_y, circle_r = image_data_circle_valid[1]
    image_circle_distance_tmp[int(circle_y), int(circle_x)] = 0
    image_circle_distance = ndimage.distance_transform_edt(input=image_circle_distance_tmp)
    image_data_circle_mask = np.where(image_circle_distance > circle_r * 0.5, 0, 255).astype(np.uint8)
    image_data_sobel_edges_aftermask = cv2.bitwise_and(image_data_sobel_edges_use,
                                                       image_data_sobel_edges_use,
                                                       mask=image_data_circle_mask)


    houghlinep_param = min(image_data_button.shape[:2]) / 10.0
    image_data_linep = cv2.HoughLinesP(image=image_data_sobel_edges_aftermask,
                                       rho=1.0,
                                       theta=np.pi / 180,
                                       threshold=15,
                                       minLineLength=houghlinep_param * 1.3,
                                       maxLineGap=houghlinep_param * 0.8)
    if image_data_linep is None:
        return result

    logging.info("Hough linep done!")
    lines_v   = {'direction_angle': np.pi / 2, 'angle': [], 'line_point':[], 'line_param':[], 'line_circle_dis':[]}
    lines_45  = {'direction_angle': np.pi / 4, 'angle': [], 'line_point':[], 'line_param':[], 'line_circle_dis':[]}
    lines_135 = {'direction_angle': -np.pi / 4, 'angle': [], 'line_point':[], 'line_param':[], 'line_circle_dis':[]}

    lines_mat = image_data_linep.squeeze(axis=1)
    lines_mat_ABC = calculate_line_formula(lines_mat)
    lines_mat_circle_distance = point_line_distance((circle_x, circle_y), lines_mat_ABC)

    theta_epsilon = np.pi / 18 * 1
    distance_epsilon = 2 * circle_r / 10
    valid_thetas = [np.pi / 6, np.pi / 4, np.pi / 3]

    logging.info("begin to select valid lines")
    for ikl in range(image_data_linep.shape[0]):
        x1, y1, x2, y2 = image_data_linep[ikl, 0, :]
        A, B, C = lines_mat_ABC[ikl, :]
        line_circle_distance = lines_mat_circle_distance[ikl, 0]

        line_k = -A / (B + 1e-6)
        theta = np.arctan(line_k)

        # 去除近似横向直线
        if A == 0 or np.abs(theta - 0) < theta_epsilon:
            continue

        # 筛选圆左侧竖直线
        if B == 0 or (np.abs(theta - np.pi / 2) < theta_epsilon) \
                  or (np.abs(theta + np.pi / 2) < theta_epsilon):
            # 竖直线在圆心左边位置条件
            if (max(x1, x2) < circle_x) and (min(x1, x2) > circle_x - circle_r * 3 / 4):
                #竖直线需要贯穿中心位置，全在上面或者全部在下面都需要滤除
                if min(y1, y2) - distance_epsilon < circle_y and max(y1, y2) + distance_epsilon > circle_y:
                        lines_v['angle'].append(theta)
                        lines_v['line_point'].append((x1, y1, x2, y2))
                        lines_v['line_param'].append((A, B, C))
                        lines_v['line_circle_dis'].append(line_circle_distance)
                else:
                    continue

        for ik_theta, valid_theta in enumerate(valid_thetas, 1):
            # 正向角度，135°方向直线在圆的下半部分,图像坐标系与直观坐标系有区别，图像算出来45°为平常所说的135度直线
            if (np.abs(theta - valid_theta) < theta_epsilon):
                if (y2 + y1) / 2. - circle_y < 0:
                    #斜线需要贯穿中心位置，斜线全在圆心左边或者右边都需要滤除
                    if min(x1, x2) - distance_epsilon < circle_x and max(x1, x2) + distance_epsilon > circle_x:
                        lines_45['angle'].append(theta)
                        lines_45['line_point'].append((x1, y1, x2, y2))
                        lines_45['line_param'].append((A, B, C))
                        lines_45['line_circle_dis'].append(line_circle_distance)

            # 负向角度，45°方向直线在圆的上半部分
            elif (np.abs(theta + valid_theta) < theta_epsilon):
                if (y2 + y1) / 2. - circle_y > 0:
                    #斜线需要贯穿中心位置，斜线全在圆心左边或者右边都需要滤除
                    if min(x1, x2) - distance_epsilon < circle_x and max(x1, x2) + distance_epsilon > circle_x:
                        lines_135['angle'].append(theta)
                        lines_135['line_point'].append((x1, y1, x2, y2))
                        lines_135['line_param'].append((A, B, C))
                        lines_135['line_circle_dis'].append(line_circle_distance)
            else:
                continue


    lines_v_index = {key:ikv for ikv, key in enumerate(lines_v['angle'])}
    lines_v_index_sort = collections.OrderedDict([(key, lines_v_index[key]) \
                                                  for key in sorted(lines_v_index.keys(),
                                                                    key=lambda x: np.abs(x - np.pi / 2),
                                                                    reverse=False)])

    #lines_v_circle_dis_mean = np.mean(lines_v['line_circle_dis']) if len(lines_v['line_circle_dis']) > 0 else None
    #lines_45_circle_dis_mean = np.mean(lines_45['line_circle_dis']) if len(lines_45['line_circle_dis']) > 0 else None
    #lines_135_circle_dis_mean = np.mean(lines_135['line_circle_dis']) if len(lines_135['line_circle_dis']) > 0 else None

    triangle_lines = []
    circle_point_ratio = 1
    logging.info("begin to judge triangle")
    for angle_v, angle_v_idx in lines_v_index_sort.items():
        ABC_v = lines_v['line_param'][angle_v_idx]
        line_v_circle_distance = lines_v['line_circle_dis'][angle_v_idx]

        for ik_45, angle_45 in enumerate(lines_45['angle'], 0):
            ABC_45 = lines_45['line_param'][ik_45]
            line_45_circle_distance = lines_45['line_circle_dis'][ik_45]
#             if (lines_45_circle_dis_mean is not None) and line_45_circle_distance < lines_45_circle_dis_mean:continue

            cross_point_v_45 = calculate_cross_point(ABC_45, ABC_v)
            cross_point_v_45_circlepoint_distance = np.linalg.norm([circle_x - cross_point_v_45[0],
                                                                    circle_y - cross_point_v_45[1]])
            # 交点超出圆范围，滤除
            if cross_point_v_45_circlepoint_distance > circle_r * circle_point_ratio:
                continue

            for ik_135, angle_135 in enumerate(lines_135['angle'], 0):
                ABC_135 = lines_135['line_param'][ik_135]
                line_135_circle_distance = lines_135['line_circle_dis'][ik_135]

                cross_point_45_135 = calculate_cross_point(ABC_45, ABC_135)
                cross_point_v_135  = calculate_cross_point(ABC_v, ABC_135)
                cross_points = np.vstack((cross_point_v_45, cross_point_45_135, cross_point_v_135))
                circle_center_point = np.repeat(np.array([[circle_x, circle_y]]), cross_points.shape[0], axis=0)

                cross_points_circlepoint_distance = np.linalg.norm(cross_points - circle_center_point, axis=1)
                if not max(cross_points_circlepoint_distance) < circle_r * circle_point_ratio:
                    continue

                if not is_point_in_poly((circle_x, circle_y),
                                        [cross_point_v_45, cross_point_45_135, cross_point_v_135]):
                    continue

                triangle_lines.append([angle_v, angle_45, angle_135])
                break
            if len(triangle_lines) > 0:
                break
        if len(triangle_lines) > 0:
            break
    # 没有检测出三角形，返回
    if len(triangle_lines) == 0:
        return result

    logging.info("begin to judge center position alias")
    image_origin_shape = image_origin.shape
    image_origin_center_x = image_origin_shape[1] / 2.
    image_origin_center_y = image_origin_shape[0] / 2.
    button_center_x = taginfo_dict["position"]["x"] + 0.5 * taginfo_dict["position"]["width"]
    button_center_y = taginfo_dict["position"]["y"] + 0.5 * taginfo_dict["position"]["height"]
    button_x_bias = np.abs(button_center_x - image_origin_center_x)
    button_y_bias = np.abs(button_center_y - image_origin_center_y)
    if min(button_x_bias, button_y_bias) > circle_r * 1:
        return result

    result['result'].append({"name": "triangle_button", "confidence": 0.95, "position": taginfo_dict["position"]})
    return result

def main():
    filein = "202012_feed_all.taginfo.button.0.96-0.99.bak"
    for line in open(filein).readlines():
        url, taginfo = line.strip().split('\t')
        image_data = cv_imread_check(url)
        result = button_recgnition(image_data, taginfo)
        print(result)


if __name__ == "__main__":
    main()

