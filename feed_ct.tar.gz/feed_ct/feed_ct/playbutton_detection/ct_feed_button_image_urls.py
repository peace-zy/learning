#!/usr/bin/env python
#coding=utf-8
"""
filename:       ct_feed_button.py
author:         liuxing07@baidu.com
"""

import os
import sys
import time
import requests
import pypinyin
import logging
import logging.handlers
import json
import demjson
import traceback
import collections
import random
import base64
import tqdm

import numpy as np
import cv2

from play_button_recgnition import button_recgnition

if sys.version_info.major == 3:
    from concurrent import futures
else:
    logging.info('make sure futures module installed! [pip install futures]')
    exit(0)
assert sys.version_info.major == 3, 'python3.x script!'
assert sys.version_info.minor >= 2, 'concurrent.future must be with \
                                pyton version higher than python3.2'

BUTTON_ONLINE_BNS = "group.opera-xforce-BRPTDPmsImageButtonHd-all-hd.SC-GPU.all"
TAG_SERVER_ONLINE_BNS = "group.opera-tagserveronline-tagserver2-000-sz.FENGKONG.all"
_curpath = os.path.dirname(os.path.abspath(__file__))


def getlogger(file_name):
    """
        initailize logger
    """
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    fh = logging.handlers.TimedRotatingFileHandler(filename = file_name, when = "midnight",
                                          interval = 1, backupCount = 10)
    fh.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s")
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    return logger

def chinese2pinqin(word):
    """
    transform Chinese charactor to pinyin format
    """
    s = ''
    word_pinyin = pypinyin.pinyin(word, style=pypinyin.NORMAL)
    for i in word_pinyin:
        s += ''.join(i)
    return s

def get_bns_addrs(bns):
    """
    get server addresses and port of this bns
    """
    tagserver_query = "http://{}/ImageQueryTagService/query"
    server_port_status = os.popen('get_instance_by_service -i -p -s {}'.format(bns)).readlines()
    server_port_status = [addr.strip().split(' ') for addr in server_port_status]
    server_ip_port = ['{}:{}'.format(item[1], item[2]) for item in server_port_status if item[-1] == '0']
    server_query_addr = [tagserver_query.format(item) for item in server_ip_port]
    return server_query_addr

def list_groups(init_list, children_list_len=None, children_list_num=None):
    """
    spplit list to sublists

    init_list:          original list
    children_list_len:  length of sublist
    children_list_num:  number of sublist
    """
    if children_list_num is not None:
        if len(init_list) % children_list_num == 0:
            children_list_len = int(len(init_list) // children_list_num)
        else:
            children_list_len = int(len(init_list) // (children_list_num - 1))
    if children_list_len == 0:
        return init_list
    list_of_groups = zip(*(iter(init_list),) *children_list_len)
    end_list = [list(i) for i in list_of_groups]
    count = len(init_list) % children_list_len
    end_list.append(init_list[-count:]) if count != 0 else end_list
    return end_list

def file2b64(filepath):
    """
    image file to base64
    """
    if filepath.startswith("http"):
        b64_data = base64.b64encode(requests.get(filepath).content)
    else:
        b64_data = base64.b64encode(open(filepath, 'rb').read())
    return b64_data.decode('UTF-8')

def make_request(imgurl=None, imgb64=None, tagpaths=[], item_count=1):
    """
    generate parameters for tagserver request
    """
    logid = int(time.time() * 1e6)
    param = {"logid": logid, "items": []}
    for idx in range(0, item_count):
        item = {"id": idx, "userid": 0, "biz_src_id": 1, "is_deliver": True, "tag_paths": []}
        item["tag_paths"].extend(tagpaths)
        if (imgurl is None and imgb64 is None):
            raise Exception("imgurl and imgb64 are None at the same time")
        if (imgurl is not None):
            item["req_url"] = imgurl
        if (imgb64 is not None):
            item["req_cont"] = imgb64
            item["is_req_cont_base64"] = True
        param["items"].append(item)
    return param

def get_request(content=None, tagpaths=[], mode='IMAGE_DATA_TYPE_B64'):
    """
    content: image data in
    mode   : image data in type including three types
             1: IMAGE_DATA_TYPE_B64 (content = imgb64_data)
             2: IMAGE_DATA_TYPE_BIN (content = imgfile absolute path)
             3: IMAGE_DATA_TYPE_URL (content = url)
    """
    if mode == "IMAGE_DATA_TYPE_B64":
        return make_request(imgb64 = content, tagpaths=tagpaths)
    elif mode == "IMAGE_DATA_TYPE_BIN":
        with open(content, 'rb') as fin:
            imgb64_data = base64.b64encode(fin.read())
        return make_request(imgb64 = imgb64_data, tagpaths=tagpaths)
    elif mode == "IMAGE_DATA_TYPE_URL":
        assert content.startswith('http'), 'url must be startwith http!'
        return make_request(imgurl = content, tagpaths=tagpaths)
    else:
        logging.warning('content image data type is not supported!')
        return None

def get_taginfo_by_tagpath(image_tag, tag_paths):
    """
    parse taginfo by tagpath
    """
    tagpath_results = []
    for tagpath in tag_paths:
        tagpath_names = tagpath.strip().split('.')
        result = ''
        taginfo = image_tag
        for ik, tagpath_name in enumerate(tagpath_names, 1):
            if not tagpath_name in taginfo:
                return result
            if ik == len(tagpath_names):
                if isinstance(taginfo[tagpath_name], list):
                    result = taginfo[tagpath_name][0]
                    if "name" not in result:
                        result["name"] = tagpath_names[1]
                else:
                    result = '{}'.format(taginfo[tagpath_name])
                if isinstance(result, dict):
                    result = json.dumps(result, ensure_ascii=False, separators=(',', ':'))
                break
            sub_taginfo = taginfo[tagpath_name]
            taginfo = sub_taginfo
        result = result.replace('\t', ';')
        result = result.replace('|', ';')
        tagpath_results.append(result)
    assert len(tagpath_results) == len(tag_paths), 'tagpaths results is not according to tagpaths'
    return '|'.join(tagpath_results)

class Parse(object):
    """
    parse button recgnition
    """
    def __init__(self):
        self.button_output = {"button": []}
        self.detection_confidence_thresh = 0.96

    def post_process_button(self, valid_taginfo, imgb64):
        """
        recgnize play-button
        """
        if valid_taginfo == "":
            return json.dumps(self.button_output)
        button_result = demjson.decode(valid_taginfo)
        if len(button_result) < 1:
            return json.dumps(self.button_output)
        name = button_result["name"]
        score = float(button_result["confidence"])
        if score < self.detection_confidence_thresh:
            return json.dumps(self.button_output)

        logging.info("button detection result: {}".format(valid_taginfo))
        image_data = cv2.imdecode(np.frombuffer(base64.b64decode(imgb64), dtype=np.uint8), cv2.IMREAD_COLOR)
        button_recgnition_result = button_recgnition(image_origin=image_data, button_detection_taginfo=valid_taginfo)
        logging.info("button recgnition result: {}".format(button_recgnition_result))
        if len(button_recgnition_result['result']) < 1:
            return json.dumps(self.button_output)
        button_feed_name = "按钮_播放按钮_三角形"
        score = float(button_recgnition_result['result'][0]['confidence'])
        button_feed_name_pinyin = chinese2pinqin(button_feed_name)
        self.button_output["button"].append({"name": button_feed_name_pinyin, "score": score, "version": 1})
        return json.dumps(self.button_output)

    def post_process_button1(self, valid_taginfo, imgb64):
        """
        recgnize center-position play-button
        """
        if not valid_taginfo == "":
            return json.dumps(self.button_output)
        button_result = demjson.decode(valid_taginfo)
        if len(button_result) < 1:
            return json.dumps(self.button_output)
        name = button_result["name"]
        score = float(button_result["confidence"])
        if score < self.detection_confidence_thresh:
            return json.dumps(self.button_output)

        x = int(button_result["position"]["x"])
        y = int(button_result["position"]["y"])
        width = int(button_result["position"]["width"])
        height = int(button_result["position"]["height"])

        image_data = cv2.imdecode(np.frombuffer(base64.b64decode(imgb64), dtype=np.uint8), cv2.IMREAD_COLOR)

        image_center = np.array(image_data.shape[:2][::-1]) / 2.0
        button_center = np.array(x + width / 2.0, y + height / 2.0)

        distance = np.linalg.norm(image_center - button_center)
        norm_distance = distance / np.min(image_data.shape[:2])
        if norm_distance < 0.05:
            button_feed_name = "按钮_播放按钮_居中"
            button_feed_name_pinyin = chinese2pinqin(button_feed_name)
            self.button_output["button"].append({"name": button_feed_name_pinyin, "score": score, "version": 1})
        return json.dumps(self.button_output)


def post_process_model(valid_taginfos, tagpaths, imgb64):
    """
    post_process_model
    """
    post_results = []
    valid_taginfo_list = valid_taginfos.strip().split('|')
    for valid_taginfo, tagpath in zip(valid_taginfo_list, tagpaths):
        tagname = tagpath.strip().split('.')[1]
        post_func_name = "post_process_{}".format(tagname)
        parse = Parse()
        result = getattr(parse, post_func_name)(valid_taginfo, imgb64)
        logging.info("[post_process_model] func result:{}".format(result))
        post_results.append(result)
    return '|'.join(post_results)

def process_model(imgb64, tagpaths, server_addr, timeout=10):
    """
    process_model
    """
    param = get_request(content=imgb64, tagpaths=tagpaths, mode='IMAGE_DATA_TYPE_B64')
    response = requests.post(server_addr, json=param, timeout=timeout)
    response.encoding = "GBK"
    if response.status_code == requests.codes.ok:
        logging.info("[process_model] tagserver response:{}".format(response.text))
        tag_json = json.loads(response.text, encoding="GBK")
        if not tag_json['res_status'] == 0:
            result = ""
        image_taginfo = tag_json['items'][0]['image_taginfo']
        newtagpaths = ["{}.array".format(tagpath) for tagpath in tagpaths]
        result = get_taginfo_by_tagpath(image_taginfo, newtagpaths)
    else:
        result = ''
    return post_process_model(result, tagpaths, imgb64)


def base_worker(line_info, server_addr, modelname='button', timeout=10):
    """
    base worker for multiprocessing
    """
    url = line_info.strip().split('\t')[-1]
    imgb64 = file2b64(url)

    tagpaths = ["rcpt_tag.{}".format(modelname)]

    return process_model(imgb64, tagpaths, server_addr, timeout)

def call_back(future):
    """
    call_back function for multiprocessing
    """
    task_info = future.arg['task_info']
    result = task_info + '\t' + json.dumps({"{}".format(future.arg['modelname']): []})
    if future.cancelled():
        logging.info('process failed! cancelled! [{}]'.format(future.arg))
    elif future.done():
        error = future.exception()
        if error:
            logging.info('process failed! [{}] return error:{}'.format(future.arg, error))
        else:
            fresult = future.result()
            if fresult:
                result = task_info + '\t' + fresult

    #fout_file = os.path.join(_curpath, 'feed_output/{}'.format(future.arg['modelname']), 'data')
    fout_file = sys.argv[-1]
    with open(fout_file, 'a+', encoding='UTF-8') as fout:
        fout.write('{}\n'.format(result))

def thread_worker(ttasks, server_addrs, modelname='button', tworker_num=5, timeout=10):
    """
    thread worker for multiprocessing
    """
    with futures.ThreadPoolExecutor(max_workers=tworker_num) as t_executor:
        for ttask in tqdm.tqdm(ttasks):
            task_future = t_executor.submit(base_worker, ttask,
                                            random.choice(server_addrs), modelname, timeout)
            task_future.arg = {'task_info': ttask, 'modelname': modelname}
            task_future.add_done_callback(call_back)

def process_worker(ptasks, server_addrs, modelname='button', pworker_num=1, tworker_num=10):
    """
    process worker for multiprocessing
    """
    if pworker_num is None:
        pworker_num = os.cpu_count() or 1
    if len(ptasks) < pworker_num:
        pworker_num = len(ptasks)
    tasks_lists = list_groups(ptasks, children_list_num = pworker_num)

    p_executor = futures.ProcessPoolExecutor(max_workers=pworker_num)
    task_futures = [p_executor.submit(thread_worker, ptask,
                                      server_addrs, modelname, tworker_num) for ptask in tasks_lists]
    p_executor.shutdown(wait=True)


def main_feed_ct():
    """
    main function
    """
    if len(sys.argv) < 5:
        msg = "script usage:\n\tpython {} \
                [input_data_file] [output_data_file] [log_file] [task_modelname]".format(__file__)
        print(msg)
        return

    input_file=sys.argv[1]
    logfile = sys.argv[3]
    modelname = sys.argv[4]
    process_num = 4
    thread_num = 10
    logger = getlogger(file_name = logfile)
    server_addrs = get_bns_addrs(TAG_SERVER_ONLINE_BNS)

    hint_size = 100 * 1024 * 1024
    fin = open(input_file, encoding = "UTF-8")
    while True:
        input_data=[item.strip() for item in fin.readlines(hint_size)]
        if len(input_data) <= 0:
            break
        process_worker(input_data, server_addrs, modelname, process_num, thread_num)
    fin.close()



def main_imageurls():
    """
    main function for processing image urls
    """
    filein_path = "/home/users/liuxing07/ssd2/project/button/fengkong_feeds_image_url_20210501_20210512.txt.sample100K"
    filein_dir, filein = os.path.split(filein_path)

    fileout = filein + '.playbutton'
    fileout_dir = filein_dir
    fileout_path = os.path.join(fileout_dir, fileout)
    sys.argv.append(fileout_path)
    logger = getlogger(file_name=fileout_path + '.log')
    server_addrs = get_bns_addrs(TAG_SERVER_ONLINE_BNS)

    fin = open(filein_path, encoding='UTF-8')
    hint_size = 50 * 1024 * 1024
    while True:
        input_data = [item.strip() for item in fin.readlines(hint_size)]
        if len(input_data) <= 0:
            break
        process_worker(input_data, server_addrs, 'button', 1, 10)
    fin.close()




def main():
    """
    main function
    """
    main_imageurls()



if __name__ == '__main__':
    main()
else:
    print('import module [{}] succ!'.format(os.path.join(_curpath, __name__)))
