"""
filename:       ct_feed_mohu.py
author:         huxu01@baidu.com
"""
#!/usr/bin/env python
#coding:UTF-8

import os
import sys
import time
import requests
import random
import pypinyin
import logging
import logging.handlers
import json
import demjson
import traceback
import collections
import base64

if sys.version_info.major == 3:
    from concurrent import futures
else:
    logging.info('make sure futures module installed! [pip install futures]')
    exit(0)
assert sys.version_info.major == 3, 'python3.x script!'
assert sys.version_info.minor >= 2, 'concurrent.future must be with \
                                pyton version higher than python3.2'

_curpath = os.path.dirname(os.path.abspath(__file__))

blur_violate_threshold=-5
# blur_manual_threshold=-2.5
rcpt_blur_violate_threshold=0.9
# rcpt_blur_manual_threshold=0.85
xvision_blur_threshold=0.0

def getlogger(file_name):
    """
        initailize logger
    """
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    fh = logging.handlers.TimedRotatingFileHandler(filename = file_name, when = "midnight",
                                          interval = 1, backupCount = 10, encoding='utf-8')
    fh.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s")
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    return logger

def chinese2pinyin(word):
    """
    transform Chinese charactor to pinyin format
    """
    s = ''
    word_pinyin = pypinyin.pinyin(word, style=pypinyin.NORMAL)
    for i in word_pinyin:
        s += ''.join(i)
    return s

def get_server_url(num=5):
    """
    get tag server addresses
    """
    bns = "group.opera-tagserveronline-tagserver2-000-sz.FENGKONG.all"
    url = 'http://{}/ImageQueryTagService/query'
    server_port_status = os.popen('get_instance_by_service -i -p -s {}'.format(bns)).readlines()
    server_port_status = [addr.strip().split(' ') for addr in server_port_status]
    server_url = ['{}:{}'.format(item[1], item[2]) for item in server_port_status if item[-1] == '0']
    sample_server_url = random.sample(server_url, num)
    return [url.format(ip_port) for ip_port in sample_server_url]

def list_groups(init_list, children_list_len=None, children_list_num=None):
    """
    spplit list to sublists

    init_list:          original list
    children_list_len:  length of sublist
    children_list_num:  number of sublist
    """
    if children_list_num is not None:
        if len(init_list) % children_list_num == 0:
            children_list_len = int(len(init_list) // children_list_num)
        else:
            children_list_len = int(len(init_list) // (children_list_num - 1))
            if children_list_len == 0:
                return init_list
    list_of_groups = zip(*(iter(init_list),) *children_list_len)
    end_list = [list(i) for i in list_of_groups]
    count = len(init_list) % children_list_len
    end_list.append(init_list[-count:]) if count != 0 else end_list
    return end_list

def process_model_result(modelname='mohu', result='', version=1):
    """
    process data and return audit result
    """
    #model_output = collections.defaultdict(list)
    model_output = {modelname: []}
    if result != '':
        model_result = json.loads(result)
        try:
            # rcpt_confidence = res[0]['image_taginfo']['rcpt_tag']['blur']['content']
            rcpt_confidence = model_result['items'][0]['image_taginfo']['rcpt_tag']['blur'].get('content', 0.0)
            xvision_confidence = model_result['items'][0]['image_taginfo']['xvision_tag']['clarity'].get('content', 0.0)
            # rebuild score
            confidence_score = 0.5 * rcpt_confidence + 0.5 * (6.0 - xvision_confidence) / 12.0
            if xvision_confidence < blur_violate_threshold:
                model_score = 0.9 + 0.1 * confidence_score
            elif rcpt_confidence > rcpt_blur_violate_threshold:
                if xvision_confidence < xvision_blur_threshold:
                    model_score = 0.9 + 0.1 * confidence_score
            else:
                # model_score = 0.9 * confidence_score
                model_score = 0
            if model_score is 0:
                reason_dict = {"mohu":[]}
            else:
                model_score = round(model_score, 6)
                reason_dict = {"mohu": [{"score": model_score, "name": "mohu", "version": 1}]}
            model_output = reason_dict
        except Exception as e:
            # print(info[1])
            # traceback.print_exc()
            reason_dict = {"mohu":[]}
            model_output = reason_dict
    return json.dumps(model_output)

def make_request(imgurl=None, imgb64=None, item_count=1):
    """
    generate parameters for tagserver request
    """
    #tagpaths = ["xvision_tag.gpu_web_ocr_text", "rcpt_tag.truncated", "rcpt_tag.watermark", "rcpt_tag.disgust", "rcpt_tag.blur"]
    tagpaths = ["xvision_tag.clarity", "rcpt_tag.blur"]
    logid = int(time.time() * 1e6)
    param = {"logid": logid, "items": []}
    for idx in range(0, item_count):
        item = {"id": idx, "userid": 0, "biz_src_id": 1, "is_deliver": True, "tag_paths": []}
        item["tag_paths"].extend(tagpaths)
        if (imgurl is None and imgb64 is None):
            raise Exception("imgurl and imgb64 are None at the same time")
        if (imgurl is not None):
            item["req_url"] = imgurl
        if (imgb64 is not None):
            item["req_cont"] = imgb64
            item["is_req_cont_base64"] = True
        param["items"].append(item)
    return param

def get_request(content=None, mode='IMAGE_DATA_TYPE_B64'):
    """
    content: image data in
    mode   : image data in type including three types
             1: IMAGE_DATA_TYPE_B64 (content = imgb64_data)
             2: IMAGE_DATA_TYPE_BIN (content = imgfile absolute path)
             3: IMAGE_DATA_TYPE_URL (content = url)
    """
    if mode == "IMAGE_DATA_TYPE_B64":
        return make_request(imgb64 = content)
    elif mode == "IMAGE_DATA_TYPE_BIN":
        with open(content, 'rb') as fin:
            imgb64_data = base64.b64encode(fin.read())#.encode('GBK')
        return make_request(imgb64 = imgb64_data)
    elif mode == "IMAGE_DATA_TYPE_URL":
        assert content.startswith('http'), 'url must be startwith http!'
        return make_request(imgurl = content)
    else:
        logging.warning('content image data type is not supported!')
        return None

def base_worker(line_info, server_addr, modelname='mohu', timeout=20):
    """
    base worker for multiprocessing
    """
    line_list = line_info.strip().split('\t')
    csid, url, imgb64 = line_list[:3]
    param = get_request(content=imgb64, mode='IMAGE_DATA_TYPE_B64')
    response = requests.post(server_addr, json=param, timeout=timeout)
    # response = requests.post(server_addr, data=imgb64, timeout=timeout)
    if response.status_code == requests.codes.ok:
        result = response.text
    else:
        result = ''
    logging.info("image response;[url:{}\t{}]".format(url, result))
    model_output = process_model_result(modelname, result)
    output = '\t'.join([csid, url, model_output])
    return output

def call_back(future):
    """
    call_back function for multiprocessing
    """
    result = '\t'.join([future.arg['csid'], future.arg['url']])
    result = result + '\t' + (process_model_result(modelname=future.arg['modelname'], result=''))
    if future.cancelled():
        logging.info('process failed! cancelled! [{}]'.format(future.arg))
    elif future.done():
        error = future.exception()
        if error:
            logging.info('process failed! [{}] return error:{}'.format(future.arg, error))
        else:
            result = future.result()
    #fout_file = os.path.join(_curpath, 'feed_output/{}'.format(future.arg['modelname']), 'data')
    fout_file = sys.argv[2]
    with open(fout_file, 'a+', encoding='UTF-8') as fout:
        fout.write('{}\n'.format(result))

def thread_worker(ttasks, modelname='mohu', tworker_num=5, timeout=10):
    """
    thread worker for multiprocessing
    """
    with futures.ThreadPoolExecutor(max_workers=tworker_num) as t_executor:
        for ttask in ttasks:
            server_addr = get_server_url(num = 1)[0]
            task_future = t_executor.submit(base_worker, ttask, server_addr, modelname, timeout)
            csid, url = ttask.strip().split('\t')[:2]
            task_future.arg = {'csid':csid, 'url':url, 'modelname':modelname}
            task_future.add_done_callback(call_back)

def process_worker(ptasks, modelname='mohu', pworker_num=1, tworker_num=10):
    """
    process worker for multiprocessing
    """
    if pworker_num is None:
        pworker_num = os.cpu_count() or 1
    if (len(ptasks) < pworker_num):
        pworker_num = 1
    tasks_lists = list_groups(ptasks, len(ptasks) // pworker_num)

    p_executor = futures.ProcessPoolExecutor(max_workers=pworker_num)
    #p_executor.map(thread_worker, ptasks, chunksize=10)
    task_futures = [p_executor.submit(thread_worker, ptask, modelname, tworker_num) for ptask in tasks_lists]
    p_executor.shutdown(wait=True)


def main():
    """
    main function
    """
    if len(sys.argv) < 5:
        msg = "script usage:\n\tpython {} \
               [input_data_file] [output_data_file] [log_file] [task_modelname]".format(__file__)
        print(msg)
        return

    input_file=sys.argv[1]
    max_read_size = 500 * 1024 * 1024
    data_file = open(input_file, encoding="UTF-8")
    input_data=[item.strip() for item in data_file.readlines(max_read_size)]
    logfile = sys.argv[3]
    modelname = sys.argv[4]
    process_num = 2
    thread_num = 10
    logger = getlogger(file_name = logfile)

    while input_data:
        logging.info("input file name : [{}] , input data length:[{}]".format(input_file, len(input_data)))
        process_worker(input_data, modelname, process_num, thread_num)
        input_data=[item.strip() for item in data_file.readlines(max_read_size)]
    
    data_file.close()

if __name__ == '__main__':
    main()
else:
    print('import module [{}] succ!'.format(os.path.join(_curpath, __name__)))

