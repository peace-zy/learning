#!/usr/bin/env python
# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了纯色背景ct任务。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2021/05/14 14:00:00
"""

import os
import sys
import time
import requests
#import pypinyin
import logging
import logging.handlers
import json
#import demjson
import traceback
import collections
import hashlib
import ctypes 
from ctypes import *   
import copy

if sys.version_info.major == 3:
    from concurrent import futures
else:
    logging.info('make sure futures module installed! [pip install futures]')
    exit(0)
assert sys.version_info.major == 3, 'python3.x script!'
assert sys.version_info.minor >= 2, 'concurrent.future must be with \
                                pyton version higher than python3.2'

_curpath = os.path.dirname(os.path.abspath(__file__))


def getlogger(file_name):
    """
        initailize logger
    """
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    fh = logging.handlers.TimedRotatingFileHandler(filename = file_name, when = "midnight",
                                          interval = 1, backupCount = 10)
    fh.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s")
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    return logger

'''
def chinese2pinqin(word):
    s = ''
    word_pinyin = pypinyin.pinyin(word, style=pypinyin.NORMAL)
    for i in word_pinyin:
        s += ''.join(i)
    return s
'''

def list_groups(init_list, children_list_len=None, children_list_num=None):
    """list_groups"""
    if children_list_num is not None:
        if len(init_list) % children_list_num == 0:
            children_list_len = int(len(init_list) // children_list_num)
        else:
            children_list_len = int(len(init_list) // (children_list_num - 1))
    list_of_groups = zip(*(iter(init_list),) *children_list_len)
    end_list = [list(i) for i in list_of_groups]
    count = len(init_list) % children_list_len
    end_list.append(init_list[-count:]) if count != 0 else end_list
    return end_list

def process_model_result(modelname='chunsebeijing', result='', version=1):
    """process_model_result"""
    model_output = {modelname: []}
    if not result == '':
        model_result = json.loads(result)
        model_output[modelname].append(model_result)
    return json.dumps(model_output)

def normalize(data, in_min, in_max, n_min=0, n_max=1):
    """normalize"""
    return (n_max - n_min) / (in_max - in_min) * (data - in_min) + n_min;

def run_pure_background(source_input, save_name="image.jpg"):
    """run_pure_background"""
    result = '' 
    try:
        ll = ctypes.cdll.LoadLibrary   
        lib = ll(os.path.join(_curpath, "pure_background_color_detector_pyapi_b64input.so")) 
        out_mem = create_string_buffer(1024, "\0")
        if "http:" in source_input or "https:" in source_input:
            print (source_input)
            print ("*" * 100)
            lib.port(source_input.encode(), save_name.encode(), out_mem)
        else:
            lib.port_b64(source_input.encode(), out_mem)
        s_result = str(copy.deepcopy(out_mem.value), encoding="utf8")
        out_mem = None
        print (s_result)
        print (type(s_result))

        fields = s_result.rstrip().split(' ')
        if len(fields) != 2:
            return result
             
        first_res = 0.8
        second_res = 0.3

        principal_color = fields[0]
        parts = principal_color.split(':')
        color = parts[0]
        percentage = float(parts[1])
        br_ratio = float(fields[1].split(':')[1])
        pure_background = False
        score = 0
        if color == 'White' or color == 'Black':
            if (percentage > 0.9 and br_ratio < first_res):
                pure_background = True
                score = 0.9 + 0.1 * normalize(1 - br_ratio, 1 - first_res, 1) 
            elif (percentage > 0.8 and br_ratio < second_res):
                pure_background = True
                score = 0.8 + 0.1 * normalize(1 - br_ratio, 1 - second_res, 1)

        if pure_background:
            tag = {"name": color, "score": score, "version": 1}
            result = '{}'.format(json.dumps(tag))
    except Exception as e:
        traceback.print_exc()

    return result

def base_worker(line_info, modelname='chunsebeijing', timeout=10):
    """base_worker"""
    output = ''
    try:
        line_list = line_info.strip().split('\t')
        csid, url, imgb64 = line_list[:3]
        '''
        csid, url = line_list[:2]
        save_name = hashlib.md5(csid.encode('utf-8')).hexdigest()
        result = run_pure_background(url, save_name)
        '''
        result = run_pure_background(imgb64)

        logging.info("image response;[url:{}\t{}]".format(url, result))
        model_output = process_model_result(modelname, result)
        output = '\t'.join([csid, url, model_output])
    except Exception as e:
        traceback.print_exc()
    return output

def call_back(future):
    """call_back"""
    result = '\t'.join([future.arg['csid'], future.arg['url']])
    result = result + '\t' + (process_model_result(modelname=future.arg['modelname'], result=''))
    if future.cancelled():
        logging.info('process failed! cancelled! [{}]'.format(future.arg))
    elif future.done():
        error = future.exception()
        if error:
            logging.info('process failed! [{}] return error:{}'.format(future.arg, error))
        else:
            result = future.result()
    #fout_file = os.path.join(_curpath, 'feed_output/{}'.format(future.arg['modelname']), 'data')
    fout_file = sys.argv[2]
    with open(fout_file, 'a+', encoding='UTF-8') as fout:
        fout.write('{}\n'.format(result))

def thread_worker(ttasks, modelname='chunsebeijing', tworker_num=5, timeout=10):
    """thread_worker"""
    with futures.ThreadPoolExecutor(max_workers=tworker_num) as t_executor:
        for ttask in ttasks:
            task_future = t_executor.submit(base_worker, ttask, modelname, timeout)
            csid, url = ttask.strip().split('\t')[:2]
            task_future.arg = {'csid':csid, 'url':url, 'modelname':modelname}
            task_future.add_done_callback(call_back)

def process_worker(ptasks, modelname='chunsebeijing', pworker_num=1, tworker_num=10):
    """process_worker"""
    if pworker_num is None:
        pworker_num = os.cpu_count() or 1
    if (len(ptasks) < pworker_num):
        pworker_num = 1
    tasks_lists = list_groups(ptasks, len(ptasks) // pworker_num)

    p_executor = futures.ProcessPoolExecutor(max_workers=pworker_num)
    #p_executor.map(thread_worker, ptasks, chunksize=10)
    task_futures = [p_executor.submit(thread_worker, ptask, modelname, tworker_num) for ptask in tasks_lists]
    p_executor.shutdown(wait=True)


def main():
    """main"""
    if len(sys.argv) < 5:
        msg = "script usage:\n\t \
                python {} [input_data_file] [output_data_file] [log_file] [task_modelname]".format(__file__)
        print (msg)
        return

    input_file=sys.argv[1]
    logfile = sys.argv[3]
    modelname = sys.argv[4]
    process_num = 2 
    thread_num = 10
    logger = getlogger(file_name = logfile)

    num_line = 0
    split_size = 1024 * 1024 * 1024 # 1G
    with open(input_file, mode='r', encoding='UTF-8') as f:
        while True:
            input_data=[item.strip() for item in f.readlines(split_size)]
            if input_data:
                process_worker(input_data, modelname, process_num, thread_num)
                num_line += len(input_data)
            else:
                break

    logging.info("input data length:[{}]".format(num_line))

if __name__ == '__main__':
    main()
else:
    print('import module [{}] succ!'.format(os.path.join(_curpath, __name__)))
