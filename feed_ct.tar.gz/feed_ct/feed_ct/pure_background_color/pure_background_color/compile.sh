#!/bin/bash
/opt/compiler/gcc-8.2/bin/g++ pure_background_color_detector_pyapi_b64input.cpp -o pure_background_color_detector_pyapi_b64input.so -shared -fPIC -g `pkg-config --cflags --libs opencv` -std=c++0x
