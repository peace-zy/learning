// Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
// @file name: model_image_background_color_analysis.cpp
// @author: yan zhang(zhangyan75@baidu.com)
// @date: 2021年5月14日

#include <opencv2/opencv.hpp>

template <typename T>
std::string to_string(T value) {
    std::ostringstream os;
    os << value;
    return os.str();
}

struct HsvColorItem {
    cv::Scalar  low;
    cv::Scalar  high;
    std::string name;
};

struct PrincipalColorItem {
    std::string name;
    float       percentage;
};

std::vector<HsvColorItem> get_hsv_color_table() {
    std::cout << "get_hsv_color_table() start" << std::endl;
    std::vector<HsvColorItem> color_table;
    HsvColorItem hsv_color_item;

    hsv_color_item.low = cv::Scalar(0, 0, 0);
    hsv_color_item.high = cv::Scalar(180, 255, 46);
    hsv_color_item.name = "Black";
    color_table.emplace_back(hsv_color_item);

    hsv_color_item.low = cv::Scalar(0, 0, 46);
    hsv_color_item.high = cv::Scalar(180, 43, 220);
    hsv_color_item.name = "Gray";
    color_table.emplace_back(hsv_color_item);

    hsv_color_item.low = cv::Scalar(0, 0, 221);
    hsv_color_item.high = cv::Scalar(180, 30, 255);
    hsv_color_item.name = "White";
    color_table.emplace_back(hsv_color_item);

    hsv_color_item.low = cv::Scalar(156, 43, 46);
    hsv_color_item.high = cv::Scalar(180, 255, 255);
    hsv_color_item.name = "Red1";
    color_table.emplace_back(hsv_color_item);

    hsv_color_item.low = cv::Scalar(0, 43, 46);
    hsv_color_item.high = cv::Scalar(0, 255, 255);
    hsv_color_item.name = "Red2";
    color_table.emplace_back(hsv_color_item);

    hsv_color_item.low = cv::Scalar(11, 43, 46);
    hsv_color_item.high = cv::Scalar(25, 255, 255);
    hsv_color_item.name = "Orange";
    color_table.emplace_back(hsv_color_item);

    hsv_color_item.low = cv::Scalar(26, 43, 46);
    hsv_color_item.high = cv::Scalar(34, 255, 255);
    hsv_color_item.name = "Yellow";
    color_table.emplace_back(hsv_color_item);

    hsv_color_item.low = cv::Scalar(35, 43, 46);
    hsv_color_item.high = cv::Scalar(77, 255, 255);
    hsv_color_item.name = "Green";
    color_table.emplace_back(hsv_color_item);

    hsv_color_item.low = cv::Scalar(78, 43, 46);
    hsv_color_item.high = cv::Scalar(99, 255, 255);
    hsv_color_item.name = "Cyan";
    color_table.emplace_back(hsv_color_item);

    hsv_color_item.low = cv::Scalar(100, 43, 46);
    hsv_color_item.high = cv::Scalar(124, 255, 255);
    hsv_color_item.name = "Blue";
    color_table.emplace_back(hsv_color_item);

    hsv_color_item.low = cv::Scalar(125, 43, 46);
    hsv_color_item.high = cv::Scalar(155, 255, 255);
    hsv_color_item.name = "Purple";
    color_table.emplace_back(hsv_color_item);
    std::cout << "get_hsv_color_table() end" << std::endl;
    return color_table;
}

void get_principal_color(
            const cv::Mat& image,
            const int fg_pixel_sum,
            std::vector<PrincipalColorItem>* all_colors,
            PrincipalColorItem* principal_color) {
    std::cout << "get_principal_color() start" << std::endl;
    std::vector<HsvColorItem> hsv_color_table;
    hsv_color_table = get_hsv_color_table();

    cv::Mat hsv_image;
    cv::Mat single_color_image;
    cv::Mat single_color_binary_image;
    std::vector<cv::Vec4i> hierarchy;
    std::vector<std::vector<cv::Point>> contours;
    cv::cvtColor(image, hsv_image, cv::COLOR_BGR2HSV);

    float pixel_sum = 0.0;
    float max_pixel_sum = 0.0;
    float image_area = image.rows * image.cols;

    cv::Mat red1, red2;
    float red_pixel_sum = 0.0;
    for (int i = 0; i < hsv_color_table.size(); ++i) {
        cv::inRange(hsv_image, hsv_color_table[i].low, hsv_color_table[i].high, single_color_image);
        cv::threshold(single_color_image, single_color_binary_image, 127, 1, cv::THRESH_BINARY);

        /*cv::Mat target;
        cv::bitwise_and(image, image, target, single_color_binary_image);*/

        pixel_sum = float(sum(single_color_binary_image)[0]);
        if (hsv_color_table[i].name == "Black") {
            pixel_sum -= fg_pixel_sum;
        }

        if (hsv_color_table[i].name == "Red1") {
            red1 = single_color_binary_image.clone();
            red_pixel_sum += pixel_sum;
        }
        if (hsv_color_table[i].name == "Red2") {
            red2 = single_color_binary_image.clone();
            red_pixel_sum += pixel_sum;
        }

        PrincipalColorItem principal_color_item;
        principal_color_item.name = hsv_color_table[i].name;
        principal_color_item.percentage = pixel_sum / image_area;
        (*all_colors).emplace_back(principal_color_item);

        if (pixel_sum > max_pixel_sum) {
            max_pixel_sum = pixel_sum;
            principal_color->name =  hsv_color_table[i].name;
            principal_color->percentage =  pixel_sum / image_area;
        }
        std::cout << "get_principal_color() [" << principal_color_item.name.c_str() \
                  << ": " << to_string(principal_color_item.percentage) << "]!" << std::endl; 
    }

    //std::cout << sum(red1) << ";" << sum(red2) << std::endl;
    if (red_pixel_sum >= max_pixel_sum) {
        principal_color->name = "Red";
        principal_color->percentage =  red_pixel_sum / image_area;
    }

    std::cout << "get_principal_color() [Red : " << \
                to_string(red_pixel_sum / image_area) << "]!" << std::endl; 
    std::cout << "get_principal_color() principal_color [" << \
                principal_color->name.c_str() << ": " << to_string(principal_color->percentage) << "]!" << std::endl; 
    /*cv::Mat red = red1 | red2;
    cv::Mat target;
    cv::bitwise_and(image, image, target, red);*/
    std::cout << "get_principal_color() end" << std::endl;
    return;
}

void energy_function(
        const cv::Mat& image,
        cv::Mat* energy_image){
    std::cout << "energy_function() start" << std::endl;
    cv::Mat gray_image;
    if (image.channels() == 3) {
        cv::cvtColor(image, gray_image, cv::COLOR_BGR2GRAY);
    } else if (image.channels() == 1) {
        gray_image = image;
    }

    cv::Mat dx, dy;
    Sobel(gray_image, dx, CV_32F, 1, 0);
    Sobel(gray_image, dy, CV_32F, 0, 1);
    cv::magnitude(dx,dy, *energy_image);
    (*energy_image).convertTo(*energy_image,CV_8U,1,0);
    std::cout << "energy_function() end" << std::endl;
}

void connect_edge_of_open_contour(
        cv::Mat& image,
        const int& fg_pixel = 255) {
    std::cout << "connect_edge_of_open_contour() start" << std::endl;
    const int border_size = 20;
    if (image.rows < 2 * border_size || image.cols < 2 * border_size) {
        return;
    }

    // top
    std::vector<int> v_fg_pos;
    int i = 0, j = 0, k = 0;
    for (i = 0; i < border_size; ++i) {
        for (j = 0; j < image.cols; ++j) {
            //std::cout << int(image.at<uchar>(i, j)) << "\t";
            if (int(image.at<uchar>(i, j)) == fg_pixel) {
                v_fg_pos.emplace_back(j);
            }
        }
        // find the paired startpoint and endpoint
        if (v_fg_pos.size() >= 2) {
            cv::Mat cut_mat;
            for (int m = 0; m < v_fg_pos.size() - 1; ++m) {
                int fg_pos_start = v_fg_pos[m];
                int fg_pos_end = v_fg_pos[m + 1];

                //std::cout << fg_pos_start << "," << fg_pos_end << std::endl;
                if (fg_pos_end - fg_pos_start > 1){
                    bool blank = false;
                    for (k = fg_pos_start; k < fg_pos_end - 1; ++k) {
                        // [)
                        cut_mat = image.colRange(k, k + 1);
                        if (sum(cut_mat)[0] == 0) {
                            blank = true;
                            break;
                        }
                    }
                    if (!blank) {
                        for (k = fg_pos_start; k < fg_pos_end; ++k) {
                            image.at<uchar>(i, k) = fg_pixel;
                        }
                    } else {
                        std::cout << "connect_edge_of_open_contour() top blank" << std::endl;
                    }
                }
            }
            break;
        } else {
            v_fg_pos.clear();
        }
    }

    // bottom
    v_fg_pos.clear();
    for (i = image.rows - 1; i > image.rows - border_size - 1; --i) {
        for (j = 0; j < image.cols; ++j) {
            //std::cout << int(image.at<uchar>(i, j)) << "\t";
            if (int(image.at<uchar>(i, j)) == fg_pixel) {
                v_fg_pos.emplace_back(j);
            }
        }
        // find the paired startpoint and endpoint
        std::vector<int> v_cut_sum;
        if (v_fg_pos.size() >= 2) {
            cv::Mat cut_mat;
            for (int m = 0; m < v_fg_pos.size() - 1; ++m) {
                int fg_pos_start = v_fg_pos[m];
                int fg_pos_end = v_fg_pos[m + 1];

                //std::cout << fg_pos_start << "," << fg_pos_end << std::endl;
                if (fg_pos_end - fg_pos_start > 1){
                    bool blank = false;
                    for (k = fg_pos_start; k < fg_pos_end - 1; ++k) {
                        // [)
                        cut_mat = image.colRange(k, k + 1);
                        if (sum(cut_mat)[0] == 0) {
                            blank = true;
                            break;
                        }
                    }
                    if (!blank) {
                        for (k = fg_pos_start; k < fg_pos_end; ++k) {
                            image.at<uchar>(i, k) = fg_pixel;
                        }
                    } else {
                        std::cout << "connect_edge_of_open_contour() bottom blank" << std::endl;
                    }
                }
            }
            break;
        } else {
            v_fg_pos.clear();
        }
    }

    // left
    v_fg_pos.clear();
    for (j = 0; j < border_size; ++j) {
        for (i = 0; i < image.rows; ++i) {
            //std::cout << int(image.at<uchar>(i, j)) << "\t";
            if (int(image.at<uchar>(i, j)) == fg_pixel) {
                v_fg_pos.emplace_back(i);
            }
        }
        // find the paired startpoint and endpoint
        if (v_fg_pos.size() >= 2) {
            cv::Mat cut_mat;
            for (int m = 0; m < v_fg_pos.size() - 1; ++m) {
                int fg_pos_start = v_fg_pos[m];
                int fg_pos_end = v_fg_pos[m + 1];

                //std::cout << fg_pos_start << "," << fg_pos_end << std::endl;
                if (fg_pos_end - fg_pos_start > 1){
                    bool blank = false;
                    for (k = fg_pos_start; k < fg_pos_end - 1; ++k) {
                        // [)
                        cut_mat = image.rowRange(k, k + 1);
                        if (sum(cut_mat)[0] == 0) {
                            blank = true;
                            break;
                        }
                    }
                    if (!blank) {
                        for (k = fg_pos_start; k < fg_pos_end; ++k) {
                            image.at<uchar>(k, j) = fg_pixel;
                        }
                    } else {
                        std::cout << "connect_edge_of_open_contour() left blank" << std::endl;
                    }
                }
            }
            break;
        } else {
            v_fg_pos.clear();
        }
    }

    // right
    v_fg_pos.clear();
    for (j = image.cols - 1; j > image.cols - border_size - 1; --j) {
        for (i = 0; i < image.rows; ++i) {
            //std::cout << int(image.at<uchar>(i, j)) << "\t";
            if (int(image.at<uchar>(i, j)) == fg_pixel) {
                v_fg_pos.emplace_back(i);
            }
        }
        // find the paired startpoint and endpoint
        if (v_fg_pos.size() >= 2) {
            cv::Mat cut_mat;
            for (int m = 0; m < v_fg_pos.size() - 1; ++m) {
                int fg_pos_start = v_fg_pos[m];
                int fg_pos_end = v_fg_pos[m + 1];

                //std::cout << fg_pos_start << "," << fg_pos_end << std::endl;
                if (fg_pos_end - fg_pos_start > 1){
                    bool blank = false;
                    for (k = fg_pos_start; k < fg_pos_end - 1; ++k) {
                        // [)
                        cut_mat = image.rowRange(k, k + 1);
                        if (sum(cut_mat)[0] == 0) {
                            blank = true;
                            break;
                        }
                    }
                    if (!blank) {
                        for (k = fg_pos_start; k < fg_pos_end; ++k) {
                            image.at<uchar>(k, j) = fg_pixel;
                        }
                    } else {
                        std::cout << "connect_edge_of_open_contour() right blank" << std::endl;
                    }
                }
            }
            break;
        } else {
            v_fg_pos.clear();
        }
    }
    std::cout << "connect_edge_of_open_contour() end" << std::endl;
    return;
}

void g_func_find_contours(
        const cv::Mat& image,
        std::vector<cv::Vec4i>* hierarchy,
        std::vector<std::vector<cv::Point>>* contours) {
    cv::Mat image_with_border;
    cv::copyMakeBorder(image, image_with_border, 1, 1, 1, 1, cv::BORDER_CONSTANT | cv::BORDER_ISOLATED, cv::Scalar(0));
    cv::findContours(image_with_border, *contours, *hierarchy, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE, cv::Point(-1, -1));
    return;
}

void open_operation(
        const cv::Mat& image,
        cv::Mat* open_mat) {
    cv::Mat structure_element = getStructuringElement(cv::MORPH_RECT, cv::Size(3, 3));
    cv::Mat erodeMat;
    cv::erode(image, erodeMat, structure_element);
    cv::dilate(erodeMat, *open_mat, structure_element);
    return;
}

int32_t background_color_analysis(
        const cv::Mat mat_src_img, 
        std::string& out_principal_color) {
    std::cout << "background_color_analysis() start" << std::endl;
    int32_t ret = -1;
    do {
        cv::Mat mat_bgr_img;
        const int num_channels = mat_src_img.channels();
        // 输入图像需3通道
        if (num_channels == 1) {
            cv::cvtColor(mat_src_img, mat_bgr_img, cv::COLOR_GRAY2BGR);
        } else if (num_channels == 3) {
            mat_bgr_img = mat_src_img;
        } else if (num_channels == 4) {
            cv::cvtColor(mat_src_img, mat_bgr_img, cv::COLOR_BGRA2BGR);
        }
        std::cout << CV_MAJOR_VERSION << " " << CV_MINOR_VERSION << " " << CV_VERSION_REVISION << std::endl;
        //saliency::Ptr<StaticSaliencyFineGrained> saliency = cv::saliency::StaticSaliencyFineGrained::create();	

        const int long_side = 200;
        const int height = mat_bgr_img.rows;
        const int width = mat_bgr_img.cols;
        int resized_width = 0;
        int resized_height = 0;
        float ratio = float(width) / height;
        if (width > height) {
            resized_width = long_side;
            resized_height = int(resized_width / ratio);
        } else {
            resized_height = long_side;
            resized_width = int(resized_height * ratio);
        }
    
        cv::Mat fixed_image;
        cv::resize(mat_bgr_img, fixed_image, cv::Size(resized_width, resized_height));
        const int fixed_image_area = resized_width * resized_height;
        cv::Mat energy_mat;
        energy_function(fixed_image, &energy_mat);
        //cv::imwrite("energy.jpg", energy_mat);

        const int fg_pixel = 255;
        //const int fg_pixel = 1;
        cv::Mat energy_binary_image;
        int scale = 10;
        float cutoff = scale * cv::mean(energy_mat).val[0];
        float thres = sqrt(cutoff);
        //std::cout << thres << std::endl;
        cv::threshold(energy_mat, energy_binary_image, thres, fg_pixel, cv::THRESH_BINARY);
        //cv::imwrite("energy_binary_image.png", energy_binary_image);
        //float fg_pixels = float(sum(energy_binary_image)[0]);
        connect_edge_of_open_contour(energy_binary_image, fg_pixel);

        std::vector<cv::Vec4i> hierarchy;
        std::vector<std::vector<cv::Point>> contours;
        g_func_find_contours(energy_binary_image, &hierarchy, &contours);

        int fg_pixel_num = 0;
        for(int i = 0; i < contours.size(); i++) {
            // 连通域
            cv::drawContours(energy_binary_image, contours, i, cv::Scalar(fg_pixel), -1, 8, hierarchy);
        }

        cv::Mat structure_element = getStructuringElement(cv::MORPH_RECT, cv::Size(3, 3));
        cv::Mat open_mat;
        open_operation(energy_binary_image, &open_mat);
        g_func_find_contours(open_mat, &hierarchy, &contours);
        std::vector<cv::Point> points;
        for(int i = 0; i < contours.size(); i++)
        {
            points.insert(points.end(), contours[i].begin(), contours[i].end());
            fg_pixel_num += cv::contourArea(contours[i]);
        }
        std::cout << fg_pixel_num << std::endl;
        //std::cout << "empty: " << points.empty() << std::endl;
        cv::Rect bounding_rect;
        if (!points.empty()) {
            bounding_rect = cv::boundingRect(points);
        }

        cv::bitwise_not(open_mat, open_mat);
        cv::Mat target;
        cv::bitwise_and(fixed_image, fixed_image, target, open_mat);
        std::vector<PrincipalColorItem> all_colors;
        PrincipalColorItem principal_color;
        get_principal_color(target, fg_pixel_num, &all_colors, &principal_color);

        /*cv::Mat concate_image(fixed_image.rows, fixed_image.cols * 2, fixed_image.type(), cv::Scalar(0, 0, 0));
        fixed_image.copyTo(concate_image(cv::Range(0, fixed_image.rows), cv::Range(0, fixed_image.cols)));
        target.copyTo(concate_image(cv::Range(0, fixed_image.rows), cv::Range(fixed_image.cols, fixed_image.cols*2)));
        cv::imwrite(save_name, concate_image);
        */
        
        float br_ratio = float(bounding_rect.area()) / fixed_image_area;
        /*std::string s_res;
        s_res = principal_color.name + ":" + to_string(principal_color.percentage) + " br:" + to_string(br_ratio);
        */
        std::cout << "background_color_analysis() "\
                      "[bg principal color - " << principal_color.name.c_str() << ": " \
                      << principal_color.percentage << "] [fg bounding rect percentage : " \
                      << br_ratio << "]" << std::endl;
        std::cout << "background_color_analysis() end" << std::endl;
        out_principal_color = principal_color.name + ":" + \
                              to_string(1 - float(fg_pixel_num) / fixed_image_area) + " br:" + to_string(br_ratio);
                              //to_string(principal_color.percentage) + " br:" + to_string(br_ratio);
        ret = 0;
    } while (0);
    return ret;
}

#ifdef __cplusplus
extern "C"
void port(const char* s_input, const char* s_save_name, char out[1024]) {
    std::string input(s_input);
    std::string save_name(s_save_name);
    std::cout << input.c_str() << ", " << save_name.c_str() << std::endl;
    cv::Mat image;
    cv::VideoCapture video;

    if (!video.open(input)) {
        std::cout << "open video error: " << input << std::endl;
    }
    while (true) {
        video >> image;
        if (image.empty()) {
            std::cout << "no frame" << std::endl;
            break;
        }

        std::string out_principal_color;
        int32_t status = background_color_analysis(image, out_principal_color); 
        if (!out_principal_color.empty()) {
            memcpy(out, out_principal_color.c_str(), out_principal_color.length()); 
        }
    }
}
#endif
static std::string base64Decode(const char* Data, int DataByte)
{
    //解码表
    const char DecodeTable[] =
    {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        62, // '+'
        0, 0, 0,
        63, // '/'
        52, 53, 54, 55, 56, 57, 58, 59, 60, 61, // '0'-'9'
        0, 0, 0, 0, 0, 0, 0,
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,
        13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, // 'A'-'Z'
        0, 0, 0, 0, 0, 0,
        26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38,
        39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, // 'a'-'z'
    };
    //返回值
    std::string strDecode;
    int nValue = 0;
    int i = 0;
    while (i < DataByte)
    {
        if (*Data != '\r' && *Data != '\n')
        {
            nValue = DecodeTable[*Data++] << 18;
            nValue += DecodeTable[*Data++] << 12;
            strDecode += (nValue & 0x00FF0000) >> 16;
            if (*Data != '=')
            {
                nValue += DecodeTable[*Data++] << 6;
                strDecode += (nValue & 0x0000FF00) >> 8;
                if (*Data != '=')
                {
                    nValue += DecodeTable[*Data++];
                    strDecode += nValue & 0x000000FF;
                }
            }
            i += 4;
        }
        else// 回车换行,跳过
        {
            Data++;
            i++;
        }
    }
    return strDecode;
}
 
 
static std::string base64Encode(const unsigned char* Data, int DataByte)
{
    //编码表
    const char EncodeTable[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    //返回值
    std::string strEncode;
    unsigned char Tmp[4] = { 0 };
    int LineLength = 0;
    for (int i = 0; i < (int)(DataByte / 3); i++)
    {
        Tmp[1] = *Data++;
        Tmp[2] = *Data++;
        Tmp[3] = *Data++;
        strEncode += EncodeTable[Tmp[1] >> 2];
        strEncode += EncodeTable[((Tmp[1] << 4) | (Tmp[2] >> 4)) & 0x3F];
        strEncode += EncodeTable[((Tmp[2] << 2) | (Tmp[3] >> 6)) & 0x3F];
        strEncode += EncodeTable[Tmp[3] & 0x3F];
        if (LineLength += 4, LineLength == 76) { strEncode += "\r\n"; LineLength = 0; }
    }
    //对剩余数据进行编码
    int Mod = DataByte % 3;
    if (Mod == 1)
    {
        Tmp[1] = *Data++;
        strEncode += EncodeTable[(Tmp[1] & 0xFC) >> 2];
        strEncode += EncodeTable[((Tmp[1] & 0x03) << 4)];
        strEncode += "==";
    }
    else if (Mod == 2)
    {
        Tmp[1] = *Data++;
        Tmp[2] = *Data++;
        strEncode += EncodeTable[(Tmp[1] & 0xFC) >> 2];
        strEncode += EncodeTable[((Tmp[1] & 0x03) << 4) | ((Tmp[2] & 0xF0) >> 4)];
        strEncode += EncodeTable[((Tmp[2] & 0x0F) << 2)];
        strEncode += "=";
    }
 
    return strEncode;
}
 
 
/*
static std::string MattoBase64(const cv::Mat &img, std::string imgType)
{
    //Mat转base64
    std::string img_data;
    std::vector<uchar> vecImg;
    std::vector<int> vecCompression_params;
    vecCompression_params.push_back(CV_IMWRITE_JPEG_QUALITY);
    vecCompression_params.push_back(90);
    imgType = "." + imgType;
    cv::imencode(imgType, img, vecImg, vecCompression_params);
    img_data = base64Encode(vecImg.data(), vecImg.size());
    return img_data;
}
 
 
static cv::Mat Base64toMat(std::string &base64_data)
{
    cv::Mat img;
    std::string s_mat;
    s_mat = base64Decode(base64_data.data(), base64_data.size());
    std::vector<char> base64_img(s_mat.begin(), s_mat.end());
    img = cv::imdecode(base64_img, CV_LOAD_IMAGE_COLOR);
    return img;
}
*/

#ifdef __cplusplus
extern "C"
void port_b64(const char* s_input, char out[1024]) {
    std::string base64_data(s_input);
    cv::Mat image;

    std::string s_mat;
    s_mat = base64Decode(base64_data.data(), base64_data.size());
    std::vector<char> base64_img(s_mat.begin(), s_mat.end());
    image = cv::imdecode(base64_img, CV_LOAD_IMAGE_COLOR);

    if (image.empty()) {
        std::cout << "no image" << std::endl;
        return;
    }
    std::string out_principal_color;
    int32_t status = background_color_analysis(image, out_principal_color); 
    if (!out_principal_color.empty()) {
        memcpy(out, out_principal_color.c_str(), out_principal_color.length()); 
    }
}

#endif
