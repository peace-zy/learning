# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件允许模块包以python -m feed_ct方式直接执行。

Authors: zhangyan75(zhangyan75@baidu.com)
Date:    2021/02/24 14:48:52
"""

from __future__ import absolute_import
from __future__ import print_function
from __future__ import unicode_literals


import sys
from feed_ct.cmdline import main
sys.exit(main())
