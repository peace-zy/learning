"""
filename:       ct_feed_mohu_v2.py
author:         huxu01@baidu.com
"""
#!/usr/bin/env python
#coding:UTF-8
from __future__ import print_function, division
import os
import torch
from torch import nn
import pandas as pd
from skimage import transform
import numpy as np

from torch.utils.data import Dataset, DataLoader
from torch.utils.data.dataloader import default_collate
from torchvision import transforms

from PIL import Image
import time
import math
import copy
from sklearn.model_selection import train_test_split
import torch.optim as optim
from torch.autograd import Variable
from torchvision import models

import warnings

warnings.filterwarnings("ignore")
import random
from scipy.stats import spearmanr, pearsonr

import urllib.request
from io import BytesIO

import sys
import requests
import logging
import logging.handlers
import json
import traceback
import collections
import base64

use_gpu = True
Image.LOAD_TRUNCATED_IMAGES = True
os.environ["CUDA_VISIBLE_DEVICES"] = "2"

transform_in = transforms.Compose([ transforms.Resize(256),
                                    transforms.CenterCrop(224),
                                    transforms.ToTensor(),
                                    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                                         std=[0.229, 0.224, 0.225])])

_curpath = os.path.dirname(os.path.abspath(__file__))

def getlogger(file_name):
    """
    initailize logger
    """
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    fh = logging.handlers.TimedRotatingFileHandler(filename = file_name, when = "midnight",
                                          interval = 1, backupCount = 10, encoding='utf-8')
    fh.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s")
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    return logger

class BaselineModel1(nn.Module):
    """
    blur_v2 module class
    """
    def __init__(self, num_classes, keep_probability, inputsize):
        """
        init
        """
        super(BaselineModel1, self).__init__()
        self.fc1 = nn.Linear(inputsize, 1024)
        self.bn1 = nn.BatchNorm1d(1024)
        self.drop_prob = (1 - keep_probability)
        self.relu1 = nn.PReLU()
        self.drop1 = nn.Dropout(self.drop_prob)
        self.fc2 = nn.Linear(1024, 512)
        self.bn2 = nn.BatchNorm1d(512)
        self.relu2 = nn.PReLU()
        self.drop2 = nn.Dropout(p=self.drop_prob)
        self.fc3 = nn.Linear(512, num_classes)
        self.sig = nn.Sigmoid()
        
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                # Weight initialization reference: https://arxiv.org/abs/1502.01852
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            # elif isinstance(m, nn.Linear):
            #     m.weight.data.normal_(0, 0.02)
            #     m.bias.data.zero_()
    
    def forward(self, x):
        """
        Feed-forward pass.
        :param x: Input tensor
        : return: Output tensor
        """
        out = self.fc1(x)
        
        out = self.bn1(out)
        out = self.relu1(out)
        out = self.drop1(out)
        out = self.fc2(out)
        
        out = self.bn2(out)
        out = self.relu2(out)
        out = self.drop2(out)
        out = self.fc3(out)
        out = self.sig(out)
        # out_a = torch.cat((out_a, out_p), 1)
        
        # out_a = self.sig(out)
        return out

class Net(nn.Module):
    """
    blur_v2 net class
    """
    def __init__(self, resnet, net):
        """
        init 
        """
        super(Net, self).__init__()
        self.resnet_layer = resnet
        self.net = net
    
    def forward(self, x):
        """
        Feed-forward pass.
        :param x: Input tensor
        : return: Output tensor
        """
        x = self.resnet_layer(x)
        x = self.net(x)
        
        return x

def process(input_data, output_file_path, log_file_path, modelname='mohu'):
    """
        process input data
    """
    with open(log_file_path, 'a') as f_log:
        with open(output_file_path, 'a') as f_w:
            for each_line in input_data:
                # model_output = {modelname: []}
                try:
                    info = each_line.strip().split('\t')
                    csid = info[0]
                    url = info[1]

                    img = urllib.request.urlopen(url, timeout=5).read()
                    tmp_img = BytesIO(img)
                    image = Image.open(tmp_img)
                    if image.mode != 'RGB':
                        image = image.convert('RGB')
                    image = transform_in(image)
                    image = image.unsqueeze(0)
                    
                    predict = model(image.cuda())
                    score = predict.item()
                    score = round(1 - score, 6)
                    # print(url, score)
                    
                except Exception as e:
                    # print(each_line,e)
                    # traceback.print_exc()
                    score = round(0.0, 6)
                    f_log.write(each_line + '\n')
                    f_log.write(traceback.format_exc())
                    # f_w.write('\t'.join(info) + '\n')
                model_output = {"mohu": [{"score": score, "name": "mohu", "version": 2}]}
                output_json = json.dumps(model_output)
                f_w.write('\t'.join([csid, url, output_json]) + '\n')

def main():
    """
    main
    """
    if len(sys.argv) < 5:
        msg = "script usage:\n\tpython {} \
               [input_data_file] [output_data_file] [log_file] [task_modelname]".format(__file__)
        print(msg)
        return

    input_file=sys.argv[1]
    output_data = sys.argv[2]
    logfile = sys.argv[3]
    modelname = sys.argv[4]
    max_read_size = 500 * 1024 * 1024
    logger = getlogger(file_name = logfile)
    data_file = open(input_file, encoding="UTF-8")
    input_data=[item.strip() for item in data_file.readlines(max_read_size)]

    while input_data:
        logging.info("input file name : [{}] , input data length:[{}]".format(input_file, len(input_data)))
        process(input_data, output_data, logfile, modelname)
        input_data=[item.strip() for item in data_file.readlines(max_read_size)]
    
    data_file.close()

if __name__ == '__main__':
    pt_path = '/ssd3/huxu/meta_iqa/model_finetune/metatk_v4_best_2.pt'
    model = torch.load(pt_path)
    model.eval()
    main()
else:
    print('import module [{}] succ!'.format(os.path.join(_curpath, __name__)))
