"""
filename:       check_output_file.py
author:         huxu01@baidu.com
"""
import os
import sys
import time
import random
import json
import traceback
import collections
import base64

def check_output_files(check_input_dir, check_output_dir, check_month, start_date, end_date):
    """
    check output ct files, return missed file name and length
    """
    mismatch = []
    for date in range(start_date, end_date):
        for hour in range(0, 24):
            check_file_name = '2021%02d%02d/%02d/data' % (check_month, date, hour)
            
            check_input_path = os.path.join(check_input_dir, check_file_name)
            if not os.path.exists(check_input_path):
                continue
            with open(check_input_path) as input_file:
                in_len = len(input_file.readlines())
            
            check_output_path = os.path.join(check_output_dir, check_file_name)
            if not os.path.exists(check_output_path):
                mismatch.append((check_file_name, in_len, 0))
                continue
            with open(check_output_path) as output_file:
                out_len = len(output_file.readlines())
            if in_len != out_len:
                mismatch.append((check_file_name, in_len, out_len))
    print(mismatch)
    return mismatch

def count_output_violated(output_file_path, violated_th):
    """
    count violated materials in output file
    """
    count = 0
    with open(output_file_path) as f:
        for each_line in f:
            info = each_line.strip().split('\t')
            rlt = info[-1]
            rlt_dict = json.loads(rlt)
            score = rlt_dict["mohu"][0]["score"]
            if score > violated_th:
                count += 1
    print(count)
    return count


if __name__ == '__main__':
    # check_input_dir = '/ssd3/huxu/feed_output/mohu_v2/input'
    # check_output_dir = '/ssd3/huxu/feed_output/mohu_v2/output'
    # check_month = 2
    # start_date = 1
    # end_date = 28

    # check_output_files(check_input_dir, check_output_dir, check_month, start_date, end_date)

    output_file_path = '/ssd3/huxu/feed_output/data'
    count_output_violated(output_file_path, 0.93)
