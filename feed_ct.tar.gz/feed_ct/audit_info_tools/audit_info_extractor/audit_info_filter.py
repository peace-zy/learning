"""
filename:       audit_info_filter.py
author:         huxu01@baidu.com
读取日志文件并解码为人审拒绝理由+url的格式
"""
#! /usr/bin/env python
# -*- coding: utf-8 -*-
import os
import json
import sys
import traceback


def _file_reader(path):
    """
    读取文件
    """
    with open(path, 'r', encoding='utf-8', errors='ignore') as _f:
        for each_line in _f:
            yield each_line.strip().split('\t')


def _manual_judge(reason_str=''):
    """
    机审标志判断
    """
    if reason_str:
        manual_flag = 'machine_manual'
        return_reason = reason_str
    else:
        manual_flag = 'machine_pass'
        return_reason = 'Null'
    return manual_flag, return_reason


def _reject_judge(reason_str=''):
    """
    人审标志判断
    """
    if reason_str:
        reject_flag = 'manual_reject'
        return_reason = reason_str
    else:
        reject_flag = 'manual_pass'
        return_reason = 'Null'
    return reject_flag, return_reason


def _build_info_str(info_list, url):
    """
    构造写入到输出文件的字符串
    """
    product_id = '@%s' % info_list[0]
    is_manual, strategy_word = _manual_judge(info_list[5])
    is_reject, reject_reason = _reject_judge(info_list[13])
    strategy_type = info_list[6]
    if info_list[17]:
        risk_id = info_list[17]
    else:
        risk_id = '0'
    return_info_list = [product_id, info_list[4], info_list[2], is_manual, is_reject, \
                        strategy_word, strategy_type, reject_reason, risk_id, url]
    return '\t'.join(return_info_list)


def video_info_filter(workroot='', date='unknowndate'):
    """
    在人审日志文件中抽取视频 url 信息，输出为 txt 文件
    """
    if workroot:
        curr_dir = workroot
    else:
        curr_dir = os.getcwd()
    output_file = '%s_video_info.txt' % date
    data_dir = os.path.join(curr_dir, 'tmp/')
    output_dir = os.path.join(curr_dir, 'parsed_data/')
    os.makedirs(output_dir, exist_ok=True)

    with open(os.path.join(output_dir, output_file), 'w', encoding='utf-8', errors='ignore') as out_f:
        # 提取数据的表头，具体对应列号参考 http://wiki.baidu.com/pages/viewpage.action?pageId=304518030
        title = ('product_id', 'ad_id', 'user_id', 'is_manual', 'is_reject', \
                 'strategy_word', 'strategy_type', 'reject_reason', 'risk_id', 'video_url')
        out_f.write('\t'.join(title) + '\n')
        for root, dirs, files in os.walk(data_dir):
            for each_file in files:
                # 去重
                url_pool = []
                # 仅对人审数据进行处理
                if 'auditlist' in each_file:
                    print('start extract VIDEO info of %s in date: %s' % (each_file, date))
                    f = _file_reader(os.path.join(root, each_file))
                    for item in f:
                        if len(item) > 8 and 'video_url' in item[8]:
                            tmp = json.loads(item[8])
                            try:
                                if 'video_url' in tmp:
                                    video_url = tmp['video_url'][0]
                                    
                                    if video_url in url_pool:
                                        continue
                                    else:
                                        url_pool.append(video_url)
                                else:
                                    continue
                                # 添加机审和人审结果标签
                                out_info_str = _build_info_str(item, video_url)
                                out_f.write(out_info_str + '\n')
                            except Exception as e:
                                print('*' * 20)
                                print('Exception occurred ,err massage is: %s \nin file:%s \n file date is: %s\n' \
                                      % (e, each_file, date))
                                continue
        print('video info in date : %s has been extracted!' % date)


def image_info_filter(workroot='', date='unknowndate'):
    """
    在人审日志文件中抽取图片 url 信息，输出为 txt 文件
    """
    if workroot:
        curr_dir = workroot
    else:
        curr_dir = os.getcwd()
    output_file = '%s_image_info.txt' % date
    data_dir = os.path.join(curr_dir, 'tmp/')
    output_dir = os.path.join(curr_dir, 'parsed_data/')
    os.makedirs(output_dir, exist_ok=True)

    with open(os.path.join(output_dir, output_file), 'w', encoding='utf-8', errors='ignore') as out_f:
        # 提取数据的表头，具体对应列号参考 http://wiki.baidu.com/pages/viewpage.action?pageId=304518030
        title = ('product_id', 'ad_id', 'user_id', 'is_manual', 'is_reject', \
                 'strategy_word', 'strategy_type', 'reject_reason', 'risk_id', 'image_url')
        out_f.write('\t'.join(title) + '\n')
        for root, dirs, files in os.walk(data_dir):
            for each_file in files:
                # 去重
                url_pool = []
                # 仅对人审数据进行处理
                if 'auditlist' not in each_file:
                    continue
                print('start extract PICTURE info of %s in date: %s' % (each_file, date))
                f = _file_reader(os.path.join(root, each_file))
                for item in f:
                    # 只捞取人审拒绝的物料
                    if len(item) > 8 and (('picture' in item[8]) or ('img' in item[8]) 
                                          or ('image' in item[8]) or ('photo' in item[8]) 
                                          or ('jpg' in item[8]) or ('png' in item[8])):
                        tmp = json.loads(item[8])
                        try:
                            image_url_list = []
                            if 'picture' in tmp:
                                image_url = tmp['picture'][0].split('@')[0]
                            elif 'image' in tmp:
                                image_url = tmp['image'][0].split('@')[0]
                            elif 'pic_info.1.picture' in tmp:
                                image_url = tmp['pic_info.1.picture'][0].split('@')[0]
                            elif 'img_link' in tmp:
                                image_url = tmp['img_link'][0].split('@')[0]
                            elif 'img' in tmp:
                                image_url = tmp['img'][0].split('@')[0]
                            elif 'attributes.image2' in tmp:
                                image_url = tmp['attributes.image2'][0].split('@')[0]
                            elif 'front_0_photo' in tmp:
                                image_url = tmp['front_0_photo'][0].split('@')[0]
                            elif 'store_photo' in tmp:
                                image_url = tmp['store_photo'][0].split('@')[0]
                            elif 'img_link_0' in tmp:
                                image_url_list.append(tmp['img_link_0'][0].split('@')[0])
                                for i in range(1, 100):
                                    dict_key = 'img_link_%d' % i
                                    if dict_key in tmp:
                                        image_url_list.append(tmp[dict_key][0])
                                    else:
                                        break
                            elif 'img2' in tmp:
                                image_url_list.append(tmp['img2'][0])
                                for i in range(3, 100):
                                    dict_key = 'img%d' % i
                                    if dict_key in tmp:
                                        image_url_list.append(tmp[dict_key][0])
                                    else:
                                        break
                            elif 'product_small_img' in tmp:
                                image_url_list.append(tmp['product_small_img'][0])
                                image_url_list.append(tmp['product_big_img'][0])
                                for i in range(1, 100):
                                    dict_key = 'wailian.%d.img' % i
                                    if dict_key in tmp:
                                        image_url_list.append(tmp[dict_key])
                                    else:
                                        break
                                
                            else:
                                continue
                            
                            if image_url_list:
                                image_url = str(image_url_list)
                            else:
                                if image_url in url_pool:
                                    continue
                                else:
                                    url_pool.append(image_url)
                            
                            # 添加机审和人审结果标签
                            out_info_str = _build_info_str(item, image_url)
                            out_f.write(out_info_str + '\n')
                        except Exception as e:
                            print('*' * 20)
                            print('Exception occurred ,err massage is: %s \nin file:%s \n file date is: %s\n' \
                                  % (e, each_file, date))
                            print(traceback.format_exc())
                            continue
        print('image info in date : %s has been extracted!' % date)


if __name__ == '__main__':
    print("""cur:{}
            usage: python {} work_dir date_number
            """.format(sys.argv, __file__))

    if (len(sys.argv) > 2):
        work_dir = sys.argv[1]
        date_number = sys.argv[2]

        video_info_filter(work_dir, date_number)
        image_info_filter(work_dir, date_number)

