"""
filename:       extract_audit_info.py
author:         huxu01@baidu.com
下载人审日志，并解码为人审拒绝理由+url的格式，储存为日志日期为名的文件，如 20190731.txt
"""
#! /usr/bin/env python
# -*- coding: utf-8 -*-
import os
import datetime
import sys
import glob

sys.path.append(os.getcwd())
import audit_info_filter


def download_file(date='20190801', download_path=''):
    """
    下载文件
    """
    if not download_path:
        download_path = os.path.join(os.getcwd(), 'tmp/')
        os.makedirs(download_path, exist_ok=True)

    wget_str = 'wget --ftp-user=ftp --ftp-password=defftp171945'
    cmd_str = "%s ftp://10.169.42.6/home/work/var/dfdata/mtaudit/data/%s/auditlist* -P %s" \
              % (wget_str, date, download_path)
    os.popen(cmd_str).read()


def generate_date(start, end):
    """
    输入起止时间的闭区间，由后往前遍历日期，并逐个生成。格式均为(20190801） *注意，前后日期不可以相同
    """
    curr_date = datetime.datetime.strptime(end, '%Y%m%d')
    len_date = str(curr_date - datetime.datetime.strptime(start, '%Y%m%d'))
    len_date_int = int(len_date.split(' ')[0]) + 1
    for i in range(len_date_int):
        yield datetime.datetime.strftime(curr_date, '%Y%m%d')
        curr_date -= datetime.timedelta(1)


def extract_info(start_date='20200301', end_date='20200301', data_path=''):
    """
    对每个输入日期的人审日志进行处理，日期前后均为闭区间
    """
    if not data_path:
        data_path = os.getcwd()

    if start_date == end_date:
        out_date = [start_date]
    else:
        out_date = generate_date(start_date, end_date)

    for each_date in out_date:
        download_file(each_date)
        for each_md5 in glob.glob(os.path.join(data_path, '*.md5')):
            os.remove(each_md5)
        audit_info_filter.video_info_filter(date=each_date)
        audit_info_filter.image_info_filter(date=each_date)
        for each_auditlist in glob.glob(os.path.join(data_path, 'auditlist*')):
            os.remove(each_auditlist)
        print('*' * 20)
        print('information of files in date: %s has been extracted!' % each_date)
        print('*' * 20)


if __name__ == '__main__':
    print("""cur:{}
            usage: python {} start_date end_date
            """.format(sys.argv, __file__))

    if (len(sys.argv) > 2):
        start_date = sys.argv[1]
        end_date = sys.argv[2]
        if (len(sys.argv) > 3):
            data_path = sys.argv[3]
        else:
            data_path = os.path.join(os.getcwd(), 'tmp/')

        extract_info(start_date, end_date, data_path)

