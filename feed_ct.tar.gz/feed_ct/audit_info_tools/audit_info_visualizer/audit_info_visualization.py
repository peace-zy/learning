"""
filename:       audit_info_visualization.py
author:         huxu01@baidu.com
批量处理日志文件，将指定数据可视化
"""
#! /usr/bin/env python
# -*- coding: utf-8 -*-

import os
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib import cm
from collections import Counter
import numpy as np
import xlrd
import glob
import json

# 加载中文字体库
fontprop = FontProperties(fname='/ssd3/huxu/audit_info_visualization/STHeiti_Medium.ttc')


def get_reason_dict(excel_file_path=''):
    """
    解析存储拒绝理由与三级风险分类对应关系的 excel，并返回一个字典。若文件不存在，发出 IOError。
    字典结构：{'reason_id': {'risk_id1': 一级风险分类, 'risk_id2': 二级风险分类, 'risk_id3': 三级风险分类,
                           'MM_HR': 0, 'MM_HP': 0, 'MP_HR': 0, 'MM': 0, 'HR': 0, 'MR': 0}
    MM_HR = 0  # tp 机审发人工，人审拒绝
    MM_HP = 0  # fp 机审发人工，人审通过
    MP_HR = 0  # fn 机审通过，人审拒绝
    MM = 0 # 机审发人工
    HR = 0 # 人审拒绝
    MR = 0 # 机审拒绝
    :param excel_file_path:  excel 文件路径
    :return: 字典
    """
    reason_dict = {}
    
    if os.path.exists(excel_file_path):
        workbook = xlrd.open_workbook(excel_file_path)
        workbook.sheet_names()  # 获取所有 sheet 名称
        table = workbook.sheets()[0]
        
        for row_num in range(1, table.nrows):
            tmp_list = table.row_values(row_num)
            reason_id = str(int(tmp_list[0]))
            reason_dict[reason_id] = {
                'risk_id': {'level_1': tmp_list[3], 'level_2': tmp_list[4], 'level_3': tmp_list[5]},
                'MM_HR': 0, 'MM_HP': 0, 'MP_HR': 0, 'MM': 0, 'HR': 0, 'MR': 0}
        return reason_dict
    else:
        raise IOError('can not find input excel file:%s' % excel_file_path)


def _count_reason_data(input_file_path, reason_dict, is_title=True):
    """
    解析人审日志文件，并计算各类型拒绝理由数量等
    :param input_file_path: 输入的人审日志文件路径
    :param reason_dict: 包含 reason_id 的字典
    :param is_title: 人审日志文件是否包含标题
    :return:  计数后的 reason_dict
    """
    print('processing file: %s' % input_file_path)
    with open(input_file_path) as f_r:
        if is_title:
            f_r.readline()
        for each_line in f_r:
            info = each_line.rstrip().split('\t')
            reason_ids = info[7].split(',')
            for reason_id in reason_ids:
                if info[3] == 'machine_pass':
                    if info[4] == 'manual_reject':
                        reason_dict[reason_id]['MP_HR'] = reason_dict[reason_id].get('MP_HR', 0) + 1
                        reason_dict[reason_id]['HR'] = reason_dict[reason_id].get('HR', 0) + 1
                    else:
                        continue
                elif info[3] == 'machine_manual':
                    reason_dict[reason_id]['MM'] = reason_dict[reason_id].get('MM', 0) + 1
                    if info[4] == 'manual_pass':
                        reason_dict[reason_id]['MM_HP'] = reason_dict[reason_id].get('MM_HP', 0) + 1
                    elif info[4] == 'manual_reject':
                        reason_dict[reason_id]['MM_HR'] = reason_dict[reason_id].get('MM_HR', 0) + 1
                        reason_dict[reason_id]['HR'] = reason_dict[reason_id].get('HR', 0) + 1
            else:
                continue
    
    return reason_dict


def _reason_data_to_risk_data(reason_dict, risk_l1_dict=None, risk_l2_dict=None, risk_l3_dict=None):
    """
    把拒绝理由分类的 reason_data 转换成三级分类 risk_data
    :param reason_dict: 拒绝理由字典
    :param risk_l1_dict: 一级风险分类词典
    :param risk_l2_dict: 二级风险分类词典
    :param risk_l3_dict: 三级风险分类词典
    :return: 三个风险分类词典：risk_l1_dict, risk_l2_dict, risk_l3_dict
    """
    if not risk_l1_dict:
        risk_l1_dict = {}
    if not risk_l2_dict:
        risk_l2_dict = {}
    if not risk_l3_dict:
        risk_l3_dict = {}
    
    for each_reason_id in reason_dict:
        data_dict = reason_dict[each_reason_id].copy()
        risk_dict = data_dict['risk_id']
        del data_dict['risk_id']
        
        risk_l1_dict[risk_dict['level_1']] = risk_l1_dict.get(risk_dict['level_1'],
                                                              Counter()) + Counter(data_dict)
        
        risk_l2_dict[risk_dict['level_2']] = risk_l2_dict.get(risk_dict['level_2'],
                                                              Counter()) + Counter(data_dict)
        
        risk_l3_dict[risk_dict['level_3']] = risk_l3_dict.get(risk_dict['level_3'],
                                                              Counter()) + Counter(data_dict)
    
    return risk_l1_dict, risk_l2_dict, risk_l3_dict


def _daily_data_to_block_data(reason_data_list, date_blk=7):
    """
    将按天读取的日志，以 date_blk 为单位进行拼接
    :param reason_data_list: 按天读取的数据名列表
    :param date_blk: 分块跨度，默认是7天（一周）
    :return: block_data_list：按 date_blk 分块的数据名列表
    """
    block_data_list = []
    risk_l1_dict = {}
    risk_l2_dict = {}
    risk_l3_dict = {}
    i = 1
    for each_reason_dict in reason_data_list:
        risk_l1_dict, risk_l2_dict, risk_l3_dict = _reason_data_to_risk_data(each_reason_dict[1],
                                                                             risk_l1_dict, risk_l2_dict, risk_l3_dict)
        i += 1
        if i > date_blk:
            i = 1
            block_data_list.append((each_reason_dict[0], risk_l1_dict, risk_l2_dict, risk_l3_dict))
            risk_l1_dict = {}
            risk_l2_dict = {}
            risk_l3_dict = {}
    
    return block_data_list


def get_risk_data(data_file_dir, reason_dict, end_date, block_length=8, date_block=7,
                  data_file_postfix='_picture_info.txt'):
    """
    从文件夹 data_file_dir 中，按需求逐个读取文件，返回统计好的文件列表
    :param data_file_dir: 数据文件夹
    :param reason_dict: 拒绝理由字典
    :param end_date: 指定的日期
    :param block_length: 想要展示的区块数量
    :param date_block: 日期区块，建议以天、周为单位
    :param data_file_postfix: 文件后缀
    :return: 统计好的文件列表 risk_data_list
    """
    daily_reason_data_list = []
    
    end_date_file = end_date + data_file_postfix
    file_list = []
    for each_file_path in glob.glob(os.path.join(data_file_dir, '*%s' % data_file_postfix)):
        file_list.append(os.path.basename(each_file_path))
    if end_date_file not in file_list:
        raise IOError('can not find input end_date:%s' % end_date)
    
    file_list.sort()
    file_position = file_list.index(end_date_file) + 1
    if file_position < block_length * date_block:
        raise IOError('can not find enough data, block_length:%s, date_block:%s' % (block_length, date_block))
    file_list = file_list[file_position - block_length * date_block:file_position]
    
    for each_file in file_list:
        input_file_path = os.path.join(data_file_dir, each_file)
        
        daily_reason_dict = _count_reason_data(input_file_path, reason_dict)
        date = each_file[:8]
        daily_reason_data_list.append((date, daily_reason_dict))
    
    block_data_list = _daily_data_to_block_data(daily_reason_data_list, date_blk=date_block)
    
    return block_data_list


def _calculate_data(risk_data_counter):
    """
    计算输入统计数据对应的准召和 f1
    :param risk_data_counter: 数据统计列表，使用counter类计数
    :return: 准召和 f1
    """
    precision = risk_data_counter['MM_HR'] / (risk_data_counter['MM_HR'] + risk_data_counter['MM_HP'] + 0.01)
    recall = risk_data_counter['MM_HR'] / (risk_data_counter['MM_HR'] + risk_data_counter['MP_HR'] + 0.01)
    f1 = 2 * precision * recall / (precision + recall + 0.01)
    
    return precision, recall, f1


def get_risk_precision_recall(block_data_list, risk_name):
    """
    计算查询风险名 risk_name 所对应的 p，r，f1，并以列表的形式输出 l1_pr = [[p], [r], [f1]]
    :param risk_name: 查询计算的风险名称，需严格对照 excel 中的名称进行查询
    :param block_data_list:
    :return: date_list, 日期列表
            l1_pr, 查询风险对应的 p,r,f1，内含3个列表
    """
    date_list, l1_list, l2_list, l3_list = zip(*block_data_list)
    
    if risk_name in l1_list[0]:
        process_list = l1_list
    elif risk_name in l2_list[0]:
        process_list = l2_list
    elif risk_name in l3_list[0]:
        process_list = l3_list
    else:
        raise IOError('can not find risk:%s in data' % risk_name)
    
    pr_list = []
    for each in process_list:
        precision, recall, f1 = _calculate_data(each[risk_name])
        pr_list.append((precision, recall, f1))
    pr_list = list(zip(*pr_list))
    
    return date_list, pr_list


def get_risk_number(block_data_list, data_type='HR', risk_level='3', rank_num=10):
    """
    统计指定风险分类等级的相关数据
    :param block_data_list: 分好块的数据列表
    :param data_type: 要统计的数据类型
    :param risk_level: 指定的风险分类等级
    :param rank_num: 统计的数量，尾部会整合为 others
    :return: 统计好的 风险名和数量
    """
    date_list, l1_list, l2_list, l3_list = zip(*block_data_list)
    
    if risk_level == '1':
        process_list = l1_list
    elif risk_level == '2':
        process_list = l2_list
    elif risk_level == '3':
        process_list = l3_list
    else:
        raise IOError('illegal risk level: %s , should be str : 1 or 2 or 3' % risk_level)
    
    risk_data = {}
    for each_risk_dict in process_list:
        for each_key in each_risk_dict:
            risk_data[each_key] = risk_data.get(each_key, 0) + each_risk_dict[each_key][data_type]
    risk_counter = Counter(risk_data)
    
    if len(risk_counter) > rank_num:
        risk_name, risk_number = zip(*risk_counter.most_common(rank_num))
        other_number = sum(risk_counter.values()) - sum(risk_number)
        
        risk_name = list(risk_name)
        risk_number = list(risk_number)
        risk_name.append('others')
        risk_number.append(other_number)
    else:
        risk_name, risk_number = zip(*risk_counter.most_common())
    
    return risk_name, risk_number


def draw_line(date_list, data_list, l3_risk_name, output_img, block_length=10):
    """
    根据指定的三级风险分类，画数据分布的柱状图
    :param date_list: 数据日期列表
    :param data_list: 数据文件名列表
    :param l3_risk_name: 指定的三级风险分类名
    :param output_img: 输出的图片名
    :param block_length: 日期区块长度，建议以天、周为单位
    """
    p, r, f1 = data_list
    # 创建画图窗口
    fig = plt.figure()
    ax1 = fig.add_subplot(1, 1, 1)
    ax1.set_title(l3_risk_name, fontsize=15, color='r', fontproperties=fontprop)
    ax1.set_xlabel("date", fontsize=10, color='g')
    plt.xlim(xmax=block_length + 1, xmin=-1)
    plt.ylim(ymax=1, ymin=0)
    
    # 散点图
    # ax1.scatter(_date, p, s=20, c='r', marker='x', alpha=0.8, label='precision')
    # ax1.scatter(_date, r, s=20, c='g', marker='+', alpha=0.8, label='recall')
    # ax1.scatter(_date, f1, s=20, c='b', marker='*', alpha=0.8, label='f1-measure')
    
    ax1.plot(date_list, p, c='r', marker='.', ls='-', lw=1, label='precision')
    ax1.plot(date_list, r, c='g', marker='.', ls='-', lw=1, label='recall')
    bar_width = 0.5
    ax1.bar(date_list, f1, bar_width, color="#87CEFA", label='f1-measure')
    ax1.legend(loc='best')
    fig.savefig(output_img)


def draw_pie(risk_name, risk_number, output_img, data_scope='image', data_type='HR', risk_level='1'):
    """
    画饼图
    :param risk_name: 指定风险名
    :param risk_number: 风险代码
    :param output_img: 输出图
    :param data_scope: 统计的数据类，图片：image，视频：video
    :param data_type:  数据类型，HR=人审拒绝
    :param risk_level: 三级风险分类
    """
    data_type_dict = {'MM_HR': '机审发人工，人审拒绝',
                      'MM_HP': '机审发人工，人审通过',
                      'MP_HR': '机审通过，人审拒绝',
                      'MM': '机审发人工',
                      'HR': '人审拒绝',
                      'MR': '机审拒绝'}
    
    pic_title = '%s 域  :  %s级风险分类  %s比例图' % (data_scope, risk_level, data_type_dict[data_type])
    # 将排列在第4位分离出来
    # explode = [0, 0, 0, 0.3, 0, 0, 0, 0, 0, 0]
    # colors = cm.rainbow(np.arange(len(risk_name)) / len(risk_name))
    # colormaps: Paired, autumn, rainbow, gray,spring,Darks
    colors = ["#377eb8", "#4daf4a", "#984ea3", "#ff7f00", "#e6ab02", "r"]
    
    # 将横、纵坐标轴标准化处理,保证饼图是一个正圆,否则为椭圆
    plt.axes(aspect='equal')
    
    # 控制X轴和Y轴的范围(用于控制饼图的圆心、半径)
    plt.xlim(0, 240)
    plt.ylim(0, 120)
    
    # 不显示边框
    plt.gca().spines['right'].set_color('none')
    plt.gca().spines['top'].set_color('none')
    plt.gca().spines['left'].set_color('none')
    plt.gca().spines['bottom'].set_color('none')
    
    # 绘制饼图
    plt.title(pic_title, fontsize=15, color='r', fontproperties=fontprop)
    wedges, texts, autotexts = plt.pie(x=risk_number,  # 绘制数据
                                       # labels=risk_name,  # 添加标签
                                       # explode=explode,
                                       colors=colors,  # 设置自定义填充色
                                       autopct='%.2f%%',  # 设置百分比的格式,保留3位小数
                                       pctdistance=1.2,  # 设置百分比标签和圆心的距离
                                       # labeldistance=1.1,  # 设置标签和圆心的距离
                                       startangle=180,  # 设置饼图的初始角度
                                       center=(50, 50),  # 设置饼图的圆心(相当于X轴和Y轴的范围)
                                       radius=45,  # 设置饼图的半径(相当于X轴和Y轴的范围)
                                       counterclock=False,  # 是否为逆时针方向,False表示顺时针方向
                                       wedgeprops={'linewidth': 1, 'edgecolor': 'green'},  # 设置饼图内外边界的属性值
                                       textprops={'fontsize': 6, 'color': 'black', 'fontproperties': fontprop},
                                       # 设置文本标签的属性值
                                       frame=1)  # 是否显示饼图的圆圈,1为显示
    
    plt.legend(wedges,
               risk_name,
               fontsize=12,
               loc="center left",
               prop=fontprop,
               bbox_to_anchor=(0.45, 0, 0.3, 1))
    
    plt.setp(autotexts, fontproperties=fontprop)
    plt.setp(texts, fontproperties=fontprop)
    
    # 不显示X轴、Y轴的刻度值
    plt.xticks(())
    plt.yticks(())
    
    # 添加图形标题
    # plt.title(fig_title)
    
    # 显示图形
    plt.savefig(output_img)


def main(l3_risk_name, end_date, data_scope='image', block_length=4, date_block=7,
            draw_pie_flag=False, pie_data_type='HR', pie_risk_level='3', pie_rank_num=10,
            data_dir='', excel_path='',
            output_path=''):
    """
    处理主函数
    """
    reason_dict = get_reason_dict(excel_path)
    # 解析
    if not data_dir:
        data_dir = os.getcwd()
    data_file_postfix = '_%s_info.txt' % data_scope
    block_data_list = get_risk_data(data_dir, reason_dict, end_date, block_length=block_length, date_block=date_block,
                                    data_file_postfix=data_file_postfix)    
    # 画柱状图
    date, pr_list = get_risk_precision_recall(block_data_list, l3_risk_name)
    if not output_path:
        output_path = os.getcwd()
    draw_line(date, pr_list, l3_risk_name, output_img=os.path.join(output_path, 'risk_pr.png'),
              block_length=block_length)
    # 画饼图
    if draw_pie_flag:
        risk_name_list, risk_num = get_risk_number(block_data_list, data_type=pie_data_type,
                                                   risk_level=pie_risk_level, rank_num=pie_rank_num)
        draw_pie(risk_name_list, risk_num, data_scope=data_scope, data_type=pie_data_type, risk_level=pie_risk_level,
                    output_img=os.path.join(output_path, 'risk_piechart.png'))


if __name__ == '__main__':
    data_dir = '/ssd3/huxu/audit_info_visualization/parsed_data/'
    excel_path = '/ssd3/huxu/audit_info_visualization/reason_20201028.xlsx'
    l3_risk_name = '夸张性描述、绝对化用语(10020903)'
    data_scope = 'image'
    
    main(l3_risk_name, '20201124', data_scope=data_scope, block_length=20, date_block=1,
            draw_pie_flag=True, pie_data_type='HR', pie_risk_level='2', pie_rank_num=10,
            data_dir=data_dir, excel_path=excel_path,
            output_path=data_dir)

