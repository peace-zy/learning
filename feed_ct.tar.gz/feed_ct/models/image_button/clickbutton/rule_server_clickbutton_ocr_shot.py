#!/usr/bin/env python3
#coding:utf-8

import os
import sys
import json
import tqdm
import pretty_errors
import collections
from typing import Optional

_curpath = os.path.dirname(os.path.abspath(__file__))

class ClickbuttonRuleData(object):
    schema_list = [
        "id_num",
        "level1",
        "level2",
        "level3",
        "label_name",
        "label_id",
        "confidence",
        "punish_word",
        "unpunish_word",
        "detail",
    ]

    def __init__(self, line):
        super().__init__()
        self.load_line(line)

    def load_line(self, line, separator="\t"):
        line_list = line.strip('\n').split(separator)
        assert len(line_list) == len(self.schema_list), f"invalid line info {line}"

        for i in range(len(self.schema_list)):
            setattr(self, self.schema_list[i], line_list[i])
        if (self.unpunish_word == "NULL"
                and self.punish_word != "NULL"
                and ',' in self.punish_word
                and 2 == len(self.punish_word.split(','))):
            punish, unpunish = self.punish_word.split(',')
            self.punish_word = punish
            self.unpunish_word = unpunish


class ClickbuttonRuleShotOCR(object):
    def __init__(self,
                 rule_file: Optional[str],
                 separator: str='\t'):
        # rule_file must be absolute path of target rule file
        assert (os.path.exists(rule_file)
                and os.path.isabs(rule_file)
                and os.path.isfile(rule_file)), f"invalid rule file [{rule_file}]"

        self.rule_file = rule_file
        self.rule_lines = [i.strip('\n') for i in filter(None, open(rule_file).readlines())]
        self.clear()

    def clear(self) -> None:
        self.be_shot = False
        self.be_single_shot = False
        self.class_tag = None
        self.tag = None
        self.confidence = 0.
        self.label_id = None

    def ocr_shot_single_rule(self,
                             ocr_content: str,
                             single_rule: Optional[ClickbuttonRuleData]) -> bool:
        if '|' in single_rule.punish_word:
            word_and_shot = True
            word_and_shot_cnt = 0
            for word_and in single_rule.punish_word.split('|'):
                if word_and in ocr_content:
                    word_and_shot_cnt += 1
                else:
                    word_and_shot = False
                    break
            if word_and_shot_cnt == len(single_rule.punish_word.split('|')):
                assert word_and_shot == True, 'word1|word2'
                self.be_single_shot = True
            else:
                word_and_shot == False
        else:
            if single_rule.punish_word in ocr_content:
                self.be_single_shot = True

        if self.be_single_shot:
            if not single_rule.unpunish_word == 'NULL':
                for unpunish_word in single_rule.unpunish_word.split('|'):
                    if unpunish_word in ocr_content:
                        #print(f"[shot_word]: {single_rule.punish_word}\t \
                        #      [unpunish_word]: {unpunish_word}\t \
                        #      [ocr]: {ocr_content}")

                        self.be_single_shot = False
                        break
        if self.be_single_shot:
            self.tag = single_rule.label_name
            self.class_tag = '_'.join([single_rule.level1,
                                       single_rule.level2,
                                       single_rule.level3])
            self.confidence = single_rule.confidence
            self.label_id = single_rule.label_id
        return self.be_single_shot

    def ocr_shot_rules(self, ocr_content: str) -> Optional[str]:
        if not ocr_content:
            return None
        for rule_line in self.rule_lines:
            line_data = ClickbuttonRuleData(rule_line)
            if self.ocr_shot_single_rule(ocr_content, line_data):
                self.be_shot = True
                break
        if not self.be_shot:
            return None
        else:
            result = {'name': self.tag,
                      'score': self.confidence,
                      'id': self.label_id,
                      'detail': self.class_tag}
            return json.dumps(result, ensure_ascii=False, separators=(',', ':'))


def main():
    pass

if __name__ == '__main__':
    main()
else:
    print(f'import module [{os.path.join(_curpath, __name__)}] successfully!')
