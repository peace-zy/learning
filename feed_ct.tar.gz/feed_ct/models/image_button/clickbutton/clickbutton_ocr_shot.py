#!/usr/bin/env python3
#coding:utf-8

import os
import sys
import json
import tqdm
import pretty_errors
import collections

_curpath = os.path.dirname(os.path.abspath(__file__))

class OcrWordShotSingleRule(object):
    """
    OCR 命中规则逻辑
    """
    def __init__(self, rule, seperator='|'):
        rule_list = rule.strip().split(seperator)
        self.idnum = rule_list[0]
        self.level1 = rule_list[1]
        self.level2 = rule_list[2]
        self.level3 = rule_list[3]
        self.label_name = rule_list[4]
        self.label_id = rule_list[5]
        self.confidence = rule_list[6]
        self.punish_word = rule_list[7]
        self.unpunish_words = rule_list[8]
        self.detail = rule_list[9]

        self.be_shot = False
        self.class_tag = None
        self.tag = None

    def implement_rule(self):
        raise NotImplementedError('{} is not implemented'.format(self.__class__.__name__))


    def implement_rule_ocr(self, ocr_content=''):
        """
        ocr text to single rule
        """
        if '&' in self.punish_word:
            word_and_shot = True
            word_and_shot_cnt = 0
            for word_and in self.punish_word.split('&'):
                if word_and in ocr_content:
                    word_and_shot_cnt += 1
                else:
                    word_and_shot = False
                    break
            if word_and_shot_cnt == len(self.punish_word.split('&')):
                assert word_and_shot == True, 'word1&word2'
                self.be_shot = True
            else:
                word_and_shot == False
        else:
            if self.punish_word in ocr_content:
                self.be_shot = True

        if self.be_shot:
            if not self.unpunish_words == 'NULL':
                for unpunish_word in self.unpunish_words.split(','):
                    if unpunish_word in ocr_content:
                        self.be_shot = False
                        break
        if self.be_shot:
            self.tag = self.label_name
            self.class_tag = '_'.join([self.level1, self.level2, self.level3])
        return self


class OcrWordShotRules(object):
    """
    OCR 命中词表逻辑
    """
    def __init__(self, rule_file):
        assert os.path.exists(os.path.abspath(rule_file)), 'please input path of rule file'
        self.rules = open(rule_file, encoding='utf-8').readlines()[1:]

    def implement_rules_ocr(self, ocr_content=''):
        """
        ocr text to whole rule file
        """
        rules_shot = False
        for rule in self.rules:
            single_rule = OcrWordShotSingleRule(rule).implement_rule_ocr(ocr_content)
            if single_rule.be_shot:
                rules_shot = True
                break
        if not rules_shot:
            return None
        else:
            position = {"x":0, "y":0, "width":0, "height":0}
            result = {'name': single_rule.tag, 'score': single_rule.confidence, 'id': single_rule.label_id,
                      'position': position, 'detail': single_rule.class_tag}
            return json.dumps(result, ensure_ascii=False, separators=(',', ':'))

# 解决误判case逻辑
def classify_filter_rule(classify_result, ocr_text=''):
    """
    classify_result: {}
    ocr_text: string
    """
    qipai_ocr_filter_rule = os.path.join(_curpath, "qipai_ocr_filter_rule.txt")
    filter_label_words_map = collections.defaultdict(list)
    for line in open(qipai_ocr_filter_rule, encoding='UTF-8').readlines():
        label, filter_words = line.strip().split(':')
        filter_label_words_map[label].extend(filter_words.strip().split(','))
    for filter_word in filter_label_words_map[classify_result["name"]]:
        if filter_word in ocr_text:return {}
    return classify_result


def clickbutton_ocr_through_rules(url_ocr_file, rule_file):
    """
    clickbutton_ocr_through_rules
    """
    results = []
    ocr_word_shot_rules = OcrWordShotRules(rule_file)
    for line in tqdm.tqdm(open(url_ocr_file, encoding='utf-8').readlines()):
        ocrtext = line.strip().split('\t')[-1].strip().split(':')[-1]
        rule_result = ocr_word_shot_rules.implement_rules_ocr(ocrtext)
        if rule_result is None:
            rule_result = 'NULL'
        results.append(line.strip() + '\t' + rule_result)
    with open(url_ocr_file + '.clickbutton', 'w') as fout:
        fout.write('\n'.join(results))


def main():
    url_ocr_file = os.path.join(_curpath, '..', 'imagequality-button-recall-PM-label_validinfo_need_to_recall.txt.urls.ocr')
    url_ocr_file = os.path.join(_curpath, '..', 'fengkong_feeds_image_url_20210501_20210512.txt.sample100K.ocr')
    rule_file = os.path.join(_curpath, 'clickbutton_ocr_shot_words_rule.txt')
    clickbutton_ocr_through_rules(url_ocr_file, rule_file)
    pass

if __name__ == '__main__':
    main()
else:
    print(f'import module [{os.path.join(_curpath, __name__)}] successfully!')
