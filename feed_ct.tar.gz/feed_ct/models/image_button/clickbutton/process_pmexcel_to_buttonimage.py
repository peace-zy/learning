#!/usr/bin/env python3
#coding:utf-8

"""
Author: liuxing07@baidu.com
Date:   2021年 12月 13日 星期一 11:02:47 CST
Description:    click button process excel from PM
"""

import os
import sys
import pandas
import traceback
import json
import re
import tqdm
import requests
import concurrent
import concurrent.futures
import collections
import collections.abc
import pretty_errors
import random
from typing import Union, Optional

_curpath = os.path.dirname(os.path.realpath(__file__))

class ButtonData(object):
    """
    pm 同步数据基础schema类
    """
    def __init__(self, parts: list):
        super().__init__()
        assert parts is not None and len(parts) == len(self.attrs)
        for attr, part in zip(self.attrs, parts):
            setattr(self, attr, part)

    def __len__(self):
        return len(self.attrs)

    def __repr__(self):
        return '\n'.join([f"{attr}=\t{getattr(self, attr, None)}\t"
                          "{getattr(self, attr_doc, None)[attr] or ""}" for attr in self.attrs])

    def __str__(self):
        return self.__repr__()


class ButtonPmData(ButtonData):
    """
    userid,             # 0. 用户id
    product_id,         # 1. 产品线id（审核流id）
    review_result,      # 2. 审核结果
    audit_channel_type, # 3. 审核渠道
    ideaid,             # 4. 创意id
    idea_array,         # 5. 创意array
    word_array,         # 6. 词array
    img_array,          # 7. 图片array
    video_array,        # 8. video array
    url_array,          # 9. 物料array
    is_risky,           # 10. 是否有风险
    reject_reason_id,   # 11. 拒绝理由id
    reject_reason,      # 12. 拒绝理由
    """
    doc_list = filter(None, __doc__.strip().split('\n'))
    attr_doc = {i.split(',')[0].strip(): i.split(',')[1].strip() for i in doc_list}
    attrs = attr_doc.keys()

class ButtonAccFeedData(ButtonData):
    """
    element_type,       # 1. 元素类型(idea, picture, video)
    pid,                # 2. 产品线id
    userid,             # 3. 用户id
    material_id,        # 4. 物料id
    element_url,        # 5. 元素内容(idea: 标题/内容, picture: 图片url, video: 视频url)
    """
    doc_list = filter(None, __doc__.strip().split('\n'))
    attr_doc = {i.split(',')[0].strip(): i.split(',')[1].strip() for i in doc_list}
    attrs = attr_doc.keys()

class TagService(object):
    """
    qianfan tag server request function
    """

    def __init__(self,
                 server_url: Optional[str]="",
                 token: Optional[str]="",
                 tag_paths: Optional[list]=[]):
        super().__init__()
        self.server_urls = {
            "online": "http://qianfan.baidu-int.com/StarlinkHttpProxyService/proxy",
            "offline_leizihe": "http://10.255.120.17:8988/StarlinkService/calculate"
        }
        self.tokens = {
            "zhongtai": "eb01b627038435d137aace687da9568a",
            "qa": "95759011c79ba0548fb3b89bd35adb69"
        }
        self.server_url = server_url or self.server_urls["offline_leizihe"]
        self.token = token or self.tokens["qa"]
        self.tag_paths = tag_paths or ['assisting_tag.image_text']

    def cal_tag_qianfan_online(self,
                               server_url: Optional[str]="",
                               token: Optional[str]="",
                               image_url: Optional[str]="",
                               tag_paths: Optional[list]=[]) -> Optional[str]:
        post_data = {
            "log_id": "test_log_id",
            "calculate_tags": tag_paths or self.tag_paths,
            "data": {
                "input": {
                    "image_input": {"url": image_url}
                }
            },
            "user_info": {
                "user_token": token or self.token
            }
        }
        server_url = server_url or self.server_url
        token = token or self.token

        headers = {'Content-Type': 'application/json'}
        response = requests.post(server_url,
                                 headers=headers,
                                 data=json.dumps(post_data, ensure_ascii=True),
                                 timeout=10)
        response.encoding = "utf-8"
        if response.status_code == requests.codes.ok:
            result = json.loads(response.text, encoding="utf-8")
            if result["err_code"] != "ECODE_OK":
                print(f"\nrequsts error!\n \
                      request data: [{json.dumps(post_data, ensure_ascii=True)}]\n \
                      response: [{response.text}]\n \
                      error_code: {result['err_code']}\n")
                return ""
            return json.loads(response.text, encoding="utf-8")
        else:
            return ""

    @staticmethod
    def get_image_ocr(image_url: str) -> Optional[str]:
        """
        obtain ocr content with single image url
        """
        tag_info = TagService().cal_tag_qianfan_online(image_url=image_url,
                                                     tag_paths=['assisting_tag.image_text'])
        try:
            image_ocr = tag_info and tag_info["data"]["assisting_tag"]["image_text"]["content"]
        except:
            image_ocr = ""
            sys.stderr.write(traceback.format_exc())
        return f"{image_url}|{image_ocr}"

    @staticmethod
    def get_images_ocr(image_urls) -> Optional[list]:
        """
        multi threading request warp
        """
        if isinstance(image_urls, str):
            if os.path.isfile(image_urls):
                image_urls = [i.strip().split('\t')[0] for i in filter(None, open(image_urls, 'r').readlines())
                              if i.startswith("http")]
            else:
                sys.stderr.write("invalid input!")
                return
        if not isinstance(image_urls, collections.abc.Iterable):
            return
        results = []
        executors = concurrent.futures.ThreadPoolExecutor(max_workers=10)
        for res in executors.map(TagService.get_image_ocr, image_urls):
            try:
                results.append(res)
            except:
                pass
        return results


class Process(object):
    """
    pm基础数据处理类
    """
    element_type = {"图片": "img_array", "URL": "url_array", "视频": "video_array"}

    def __init__(self, type_map: dict=None):
        super().__init__()
        element_type = type_map or Process.element_type

    @staticmethod
    def filter_info(button_data: ButtonPmData) -> Union[None, str]:
        """
        parse info from something like warps(img1, img2, ...)
        """
        if button_data.is_risky != "是":
            return None
        # example:  图片1: 涉及误导按钮；URL: 涉及误导按钮
        targets = []
        for reason in button_data.reject_reason.strip().split('；'):
            reason_head = reason.strip().split(':')[0]
            reject_type = re.findall('\D+', reason_head)
            reject_numid = re.findall('\d+', reason_head)
            if not reject_type or not reject_numid:
                continue
            ele_array_cont = getattr(button_data, Process.element_type[reject_type[0]], None)
            if ele_array_cont is None:
                continue
            ele_targets = re.findall(r'[(](.*?)[)]', ele_array_cont)
            if not ele_targets and len(ele_targets) == 1:
                continue
            ele_target = ele_targets and ele_targets[0].split(',')[int(reject_numid[0]) - 1]
            targets.append(f"{reject_type[0]}->" + ele_target)
        return '|'.join(targets)

    @staticmethod
    def read_excel(excel_file: str, sheet_name: str):
        content = pandas.read_excel(excel_file, sheet_name=None, engine="openpyxl")
        sheet_names = content.keys()
        if sheet_name not in sheet_names:
            sys.stderr.write(f"invalid sheet name! \n"
                             "{sheet_names} are available sheet names from {excel_file}")

        schema = content[sheet_name].keys()
        rows, cols = content[sheet_name].shape
        for idx, ir in enumerate(range(rows)):
            line_info = ButtonPmData(content[sheet_name].iloc[ir].values.astype(str).tolist())
            line_info.__dict__['result_urls'] = Process.filter_info(line_info)
            yield line_info

    @staticmethod
    def show_image_html(datas: list, show_cols=4) -> list:
        html_lines = []
        html_lines.append('<table border=1>\n')
        col_item = '<td>show image</td><td>ocr content</td>'
        col_content = '<td>id_num</td>' + col_item * show_cols
        html_lines.append('<tr>{}</tr>\n'.format(col_content))
        html_img_base = '<td>{}<a href="{}" src="{}"><img src="{}" width=216 border=3 controls></a></td><td>{}</td>'
        html_img_pendix = '<tr><td>{}</td>{}</tr>\n'
        html_image_cols = []
        for ik, item in enumerate(datas):
            try:
                if ik != 0 and ik % show_cols == 0:
                    line_index = (ik // show_cols)
                    line = html_img_pendix.format(line_index, ''.join(html_image_cols))
                    html_lines.append(line)
                    html_image_cols.clear()
                contents = item.strip().split('\t')
                if len(contents) == 2:
                    url, ocr = contents
                else:
                    url = contents[0]
                    ocr = ""
                html_image_cols.append(html_img_base.format(ik + 1, url, url, url, ocr))
            except Exception as e:
                sys.stderr.write('parse line failed! {}'.format(traceback.format_exc()))
                continue
        html_lines.append('\n</table>')
        return html_lines


def file2html(file_path: str,
              separator: str='\t',
              schema: Optional[list]=None) -> None:
    """
    默认文件第一列为图片url
    """
    assert os.path.exists(file_path), f"invalid file path: [{file_path}]"
    html_lines = []
    html_lines.append('<table border=1 width="100%">\n')

    line_pendix = "<tr>{}</tr>"
    line_head_pendix = "<th width=150>{}</th>"
    line_item_id = "<td width=10>{}</td>"
    line_item_pendix = "<td width=150>{}</td>"
    line_item_image_pendix = '<a href="{}" src="{}"><img src="{}" width=150 border=1 controls></a>'

    if schema:
        schema_line_list = [line_head_pendix.format('id').replace("150", "10")]
        for ik, item in enumerate(schema):
            schema_line_list.append(line_head_pendix.format(item))
        html_lines.append(line_pendix.format(''.join(schema_line_list)))

    lines = [i.strip('\n') for i in filter(None, open(file_path).readlines())]
    for ik, item in enumerate(lines, 1):
        item_list = item.split(separator)[:3]
        line_list = [] if not schema else [line_item_id.format(ik)]
        for ic, cell in enumerate(item_list):
            if ic == 0:
                html_cell = line_item_image_pendix.format(cell, cell, cell)
            else:
                html_cell = cell
            line_list.append(line_item_pendix.format(html_cell))
        html_lines.append(line_pendix.format(''.join(line_list)))

    html_lines.append('\n</table>')
    html_out_file = os.path.join(os.path.expanduser('~/cloud/share/html'),
                                 os.path.basename(file_path).split('.')[0] + '.html')
    with open(html_out_file, 'w') as fout:
        fout.writelines([f"{i}\n" for i in html_lines])
    http_addr_prefix = "http://10.12.184.89:8080/html/"
    #sys.stdout.write(f"tramsform file [{file_path}] to html successfully!\n")
    sys.stdout.write(f"click: {http_addr_prefix}{os.path.basename(html_out_file)}\n")


def process_excel(excel_file: str, sheet_name: str) -> None:
    results = []
    for line_info in tqdm.tqdm(Process.read_excel(excel_file, sheet_name)):
        for result_url in line_info.__dict__["result_urls"].split('|'):
            if result_url.split("->")[0] == "图片":
                image_ocr = TagService.get_image_ocr(result_url.split("->")[1].strip())
                image_url, image_ocr = image_ocr.split('|')
                image_ocr = image_ocr.replace(" ", ";").replace('\t', ';').replace('|', ';')
                results.append(image_url + "\t" + image_ocr)
    output_filename = os.path.join(os.path.dirname(excel_file),
                                   f"{os.path.basename(excel_file).split('.')[0]}_{sheet_name}.txt")
    with open(output_filename, "w") as fout:
        fout.writelines([f"{i}\n" for i in results])

    output_html_filename = os.path.join(os.path.dirname(output_filename),
                                        os.path.basename(output_filename).split('.')[0] + '.html')
    with open(output_html_filename, 'w') as fout:
        fout.writelines(Process.show_image_html(results, 1))


def clickbutton_recgnize_by_ocr(rule_file: str,
                                image_ocr_file: str):
    if _curpath not in sys.path:
        sys.path.append(_curpath)

    try:
        import rule_server_clickbutton_ocr_shot
    except:
        sys.stderr.write(f"{traceback.format_exc()}")
        sys.exit(1)

    if not os.path.isabs(rule_file):
        rule_file = os.path.join(_curpath, rule_file)
    if not os.path.isabs(image_ocr_file):
        image_ocr_file = os.path.join(_curpath, image_ocr_file)

    images_url_ocr = [i.strip() for i in filter(None, open(image_ocr_file, 'r').readlines())]
    rule = rule_server_clickbutton_ocr_shot.ClickbuttonRuleShotOCR(rule_file=rule_file, separator='\t')
    results = []
    for ik, item in enumerate(images_url_ocr):
        image_url, ocr = item.split('\t')
        result = rule.ocr_shot_rules(ocr)
        result = result or ""
        results.append('\t'.join([image_url, result, ocr]))
        rule.clear()

    output_ocr_shot_rule =os.path.join(os.path.dirname(image_ocr_file),
                                       os.path.basename(image_ocr_file).replace('.', '_ocr-shot-rule.'))
    with open(output_ocr_shot_rule, 'w') as fout:
        fout.writelines([f"{i}\n" for i in results])

    file2html(output_ocr_shot_rule, separator='\t',
              schema=["图片url", "点击按钮识别结果", "ocr内容"])


def recall_data_from_pm():
    pm_data_dir = os.path.join(_curpath, "data_from_pm")
    pm_data_name = "pm_button_excel_2021-09-10.xlsx"
    excel_file = os.path.join(pm_data_dir, pm_data_name)
    sheet_name="十月未召回"
    #process_excel(excel_file, sheet_name)
    clickbutton_recgnize_by_ocr(rule_file='clickbutton_ocr_shot_words_rule_utf8.txt',
                                image_ocr_file=os.path.join(os.path.dirname(excel_file),
                                                            f"{os.path.basename(excel_file).split('.')[0]}_{sheet_name}.txt"))


def acc_processor(input_data: list,
                  out_file_path: str,
                  rule_file: str) -> None:
    if _curpath not in sys.path:
        sys.path.append(_curpath)

    try:
        import rule_server_clickbutton_ocr_shot
    except:
        sys.stderr.write(f"{traceback.format_exc()}")
        sys.exit(1)

    #input_feed_urls = [ButtonAccFeedData(i.split('\t')).element_url.strip() for i in input_data]
    rule = rule_server_clickbutton_ocr_shot.ClickbuttonRuleShotOCR(rule_file=rule_file, separator='\t')
    input_n_urls = []
    for ik, input_url in tqdm.tqdm(enumerate(input_data)):
        url = ButtonAccFeedData(input_url.split('\t')).element_url.strip()
        input_n_urls.append(url)
        if len(input_n_urls) == 100 or (len(input_data) - (ik + 1) <= 10):
            try:
                image_n_ocr = TagService.get_images_ocr(input_n_urls)

                results = []
                for image_ocr in image_n_ocr:
                    if len(image_ocr.split('|')) < 2:
                        print(image_ocr)
                    image_url, ocr = image_ocr.split('|')
                    ocr = ocr.replace(" ", ";").replace('\t', ';').replace('|', ';')
                    result = rule.ocr_shot_rules(ocr)
                    result = result or ""
                    results.append('\t'.join([image_url, result, ocr]))
                    rule.clear()
                with open(out_file_path, 'a+') as fout:
                    fout.writelines([f"{i}\n" for i in results])

            except:
                sys.stderr.write(traceback.format_exc())
                continue
            finally:
                input_n_urls.clear()


    #image_ocrs = TagService.get_images_ocr(input_feed_urls)

def acc_data_from_feed():
    rule_file='clickbutton_ocr_shot_words_rule_utf8.txt'
    if not os.path.isabs(rule_file):
        rule_file = os.path.join(_curpath, rule_file)

    feed_data = os.path.join(_curpath, "feed_sample_by_overall_elem_20211126_20211206.picture")
    out_file_path = feed_data + '.button_result'
    if os.path.exists(out_file_path):
        fout = open(out_file_path, 'w')
        fout.close()

    fin = open(feed_data, 'r', encoding="gbk")
    hint_size = 1 * 1024 * 1024
    while True:
        input_data = [i.strip('\n') for i in filter(None, fin.readlines(hint_size))]
        if not input_data:
            break
        acc_processor(input_data, out_file_path, rule_file)
    fin.close()

def image_ocr_through_rule():
    rule_file = os.path.join(_curpath, "clickbutton_ocr_shot_words_rule_utf8.txt")
    if _curpath not in sys.path:
        sys.path.append(_curpath)
    try:
        import rule_server_clickbutton_ocr_shot
    except:
        sys.stderr.write(f"{traceback.format_exc()}")
        sys.exit(1)
    rule = rule_server_clickbutton_ocr_shot.ClickbuttonRuleShotOCR(rule_file=rule_file, separator='\t')

    acc_image_ocr_file = "acc_feed_sample_by_overall_elem_20211126_20211206_picture_ocr"
    acc_image_ocr_file = os.path.join(_curpath, "data", acc_image_ocr_file)
    recall_image_ocr_file = os.path.join(_curpath, "data", "recall_pm_button_excel_2021-09-10_valid_ocr")

    need_to_process_files = [recall_image_ocr_file, acc_image_ocr_file]
    for single_file in need_to_process_files:
        results = []
        for ik, line in enumerate(tqdm.tqdm(open(single_file).readlines())):
            image_url, image_ocr = line.strip('\n').split('\t')
            result = rule.ocr_shot_rules(image_ocr)
            result = result or ""
            results.append('\t'.join([image_url, result, image_ocr]))
            rule.clear()
        out_file_name = single_file + '_button_result'
        if os.path.basename(single_file).split('_')[0] == 'recall':
            with open(out_file_name, 'w') as fout:
                fout.writelines([f"{i}\n" for i in results])
            file2html(out_file_name, '\t', schema=["图片url", "点击按钮识别结果", "ocr内容"])
        else:
            results = [i for i in results if i.split('\t')[1]]
            with open(out_file_name, 'w') as fout:
                fout.writelines([f"{i}\n" for i in results])
            sample_num = 100
            if sample_num > len(results):
                file2html(out_file_name, '\t', schema=["图片url", "点击按钮识别结果", "ocr内容"])
            else:
                sample_out_file_name = out_file_name + f"_sample{sample_num}"
                with open(sample_out_file_name, 'w') as fout:
                    fout.writelines([f"{i}\n" for i in random.sample(results, sample_num)])
                file2html(sample_out_file_name, '\t', schema=["图片url", "点击按钮识别结果", "ocr内容"])

def mapping_tradeid():
    ##schema: \t[userid fisrt_tradeid   fisrt_trade_name second_tradeid second_trade_name time]
    #user_tradeid_map_file = os.path.expanduser('~/cloud/share/userid_new_ssg_trade_day_20211226')
    #user_tradeid_map = collections.defaultdict(str)
    #for line in open(user_tradeid_map_file).readlines():
    #    userid = line.strip('\n').split('\t')[0]
    #    user_tradeid_map[userid] = line.strip('\n')


    ##schema:   \t [mt_type, pid, userid, mt_id, mt_url]
    #imgurl_userid_map_file = os.path.join(_curpath, 'acc_feed_origin_data/feed_sample_by_overall_elem_20211126_20211206.picture')
    #imgurl_userid_map = collections.defaultdict(str)
    #for line in open(imgurl_userid_map_file).readlines():
    #    line_list = line.strip('\n').split('\t')
    #    img_url = line_list[-1]
    #    imgurl_userid_map[img_url] = '\t'.join(line_list[:-1])

    ## schema: \t[imgurl, button_result, img_ocr_content]
    button_result_file = os.path.join(_curpath, 'data/acc_feed_sample_by_overall_elem_20211126_20211206_picture_ocr_button_result')

    out_file_name = button_result_file + '_group_by_trade'
    #fout = open(out_file_name, 'w', encoding='utf-8')

    #count_tmp = collections.Counter()
    #for line in open(button_result_file).readlines():
    #    line = line.strip('\n')
    #    line_list = line.split('\t')
    #    imgurl_info = imgurl_userid_map[line_list[0]]
    #    userid = imgurl_info.strip().split('\t')[2]
    #    trade_info = user_tradeid_map[userid]
    #    first_tradeid, first_tradename = trade_info.split('\t')[1:3]
    #    result = '\t'.join([line, imgurl_info, trade_info])
    #    fout.write('{}\n'.format(result))

    #    first_trade_id_name = ':'.join([first_tradeid.strip(), first_tradename.strip()])

    #    count_tmp[first_trade_id_name] += 1

    #fout.close()

    #total_num = sum(count_tmp.values())
    #print('-' * 30)
    #print("total num: {}".format(total_num))
    #print('-' * 30)
    #for id_name, img_num in count_tmp.items():
    #    percentage = 1. * img_num / total_num
    #    show_result = '\t'.join([id_name, f"{percentage:.2%}", str(img_num)])
    #    print(show_result)

    tradeidname_imgurls = collections.defaultdict(list)
    couter_out = collections.Counter()
    for line in open(out_file_name).readlines():
        line = line.strip('\n')
        line_list = line.split('\t')
        first_trade_id_name = '_'.join(line_list[-5:-3])
        tradeidname_imgurls[first_trade_id_name].append(line)
        couter_out[first_trade_id_name] += 1

    total_button_imgs = sum(couter_out.values())
    print('-' * 30)
    print("total_button_imgs: {}".format(total_button_imgs))
    print('-' * 30)
    for id_name, img_num in couter_out.most_common(len(couter_out)):
        percentage = 1. * img_num / total_button_imgs
        show_result = '\t'.join([id_name, f"{percentage:.2%}", str(img_num)])
        print(show_result)


    for idk, (id_name, img_num) in enumerate(couter_out.most_common(10), 1):
        sample_num = 100 if idk > 1 else 200
        out_trade_filename = out_file_name + "_{}".format(id_name)
        out_trade_filename_imgurls = tradeidname_imgurls[id_name]
        sample_num = min(sample_num, len(out_trade_filename_imgurls))
        with open(out_trade_filename, 'w', encoding='utf-8') as fout:
            fout.writelines(["{}\n".format(i) for i in random.sample(out_trade_filename_imgurls, sample_num)])
        file2html(out_trade_filename, '\t', schema=["图片url", "点击按钮识别结果", "ocr内容"])

def main():
    # recall and acc data respectively
    #recall_data_from_pm()
    #acc_data_from_feed()
    #image_ocr_through_rule()
    #mapping_tradeid()
    file2html(sys.argv[1], schema=["title", "图片url", "vis-8w分类-top"])

if __name__ == "__main__":
    main()
else:
    print(f"import module success! [{os.path.join(_curpath, __file__)}]")
