#!/usr/bin/env python3
#coding:utf-8

import os
import sys
import json
import argparse
import tqdm
import cv2
import numpy
import random
import traceback
import pretty_errors

from collections import defaultdict
from typing import Optional, Union

_curpath = os.path.dirname(os.path.realpath(__file__))


class Opts(object):
    """
    parameters for parse infomation
    """
    def __init__(self):
        self.parser = argparse.ArgumentParser(description="精灵标注助手标注图像结果处理")

        self.parser.add_argument('--data_path', type=str, dest='data_path', metavar='DATA_PATH',
                                 default='./crawl_data/data', help='图片，标注数据相对当前路径')
        self.parser.add_argument('--anno_path', type=str, dest='anno_path', metavar='ANNO_PATH',
                                 default='annotations', help='标注精灵助手标注结果目录')
        self.parser.add_argument('--anno_type', default='json', type=str,
                                 choices=['json', 'xml', 'pascal-voc'], help='需要解析的标注结果格式')
        self.parser.add_argument('--image_path', type=str, dest='image_path', metavar='IMAGE_PATH',
                                 default='images', help='local image data saved path on linux')
        self.parser.add_argument('--classes', type=str, dest='classes', metavar='CLASSES',
                                 default='classes.txt', help='标注数据类别名称文件')
        self.parser.add_argument('--dataset_type', type=str, choices=['COCO'], default='COCO',
                                 dest='dataset_type', help='target dataset type')
        self.parser.add_argument('--path2local_sep', type=str, default='data',
                                 help='anno path always is path on Mac, so need to get relative path on linux. \
                                 The separator is always the folder name saving anno images on Mac')

    def parse(self, arg_str: str):
        """
        parse parameters from string or command line
        """
        if arg_str:
            opt = self.parser.parse_args(arg_str.split())
        else:
            opt = self.parser.parse_args()

        if not os.path.isabs(opt.data_path):
            opt.data_path = os.path.realpath(opt.data_path)

        if not os.path.isabs(opt.anno_path):
            opt.anno_path = os.path.join(opt.data_path, opt.anno_path)

        if not os.path.isabs(opt.image_path):
            opt.image_path = os.path.join(opt.data_path, opt.image_path)

        if not os.path.isabs(opt.classes):
            opt.classes = os.path.join(opt.data_path, opt.classes)

        if not self.check_opt(opt):
            sys.exit(1)

        return opt


    def check_opt(self, opt) -> bool:
        """
        check parameters of opt
        """
        attr_check = ['anno_path', 'classes', 'data_path', 'image_path']
        for attr in attr_check:
            value = getattr(opt, attr, None)
            if value is None:
                sys.stderr.write(f"Invalid parameters! [opt.{attr}: {value}]\n")
                return False
            elif not os.path.exists(value):
                sys.stderr.write(f"Input parameter [opt.{attr}: {value}] not exists!\n")
                return False
        return True


def get_image_real_ext(image: Union[str, bytes, None]) -> Optional[str]:
    """
    get real extension of image
    """
    if not image:
        sys.stdout.write("Empty input!\n")
        return None
    if isinstance(image, str):
        assert os.path.exists(image), f"[{image}] not exists!"
        try:
            image_bin = open(image, 'rb').read()
        except Exception:
            sys.stdout.write("open image file failed! [{image}]\n")
            sys.stderr.write("{}\n".format(traceback.format_exc()))
            return None
    elif isinstance(image, bytes):
        image_bin = image
    else:
        sys.stderr.write(f"Invalid input type! [{type(image)}] must be in [str, bytes]\n")
        return None

    # image format position mapping
    # example: "GIF": image extension
    #           "GIF": ext str-format
    #           (0, 3): start position in binary file and ext length
    image_ext_pos_map = {
        "GIF": {"GIF": (0, 3)},
        "PNG": {"PNG": (1, 3)},
        "JPG": {"JFIF": (6, 4)},
        "BMP": {"BM": (0, 2)},
        "TIFF": {"MM": (0, 2)},
        "TIFF": {"II": (0, 2)},
    }
    image_ext_mapinfo = {
        "GIF": {"tag": "GIF", "tag_start": 0, "tag_len": 3},
        "PNG": {"tag": "PNG", "tag_start": 1, "tag_len": 3},
        "JPG": {"tag": "JFIF", "tag_start": 6, "tag_len": 4},
        "BMP": {"tag": "BM", "tag_start": 0, "tag_len": 2},
        "TIFF": {"tag": "MM", "tag_start": 0, "tag_len": 2},
        "TIFF": {"tag": "II", "tag_start": 0, "tag_len": 2},
    }
    # TIFF图像文件格式详解: https://www.cnblogs.com/gywei/p/3393816.html

    if len(image_bin) < 10:
        return None
    for ext, ext_map_value in image_ext_mapinfo.items():
        tag = ext_map_value.get("tag")
        tag_start = int(ext_map_value.get("tag_start"))
        tag_end = tag_start + int(ext_map_value.get("tag_len"))

        #import pdb;pdb.set_trace()
        try:
            this_tag = image_bin[tag_start: tag_end].decode()
        except UnicodeDecodeError:
            continue
        else:
            if this_tag == tag:
                return ext
    return None


def is_zh(string: str) -> bool:
    """
    判断输入字符串中是否包含中文
    ord(c_str) > 255 的字符均为中文
    """
    import six
    if six.PY2:
        if not isinstance(string, unicode):
            string = string.decode('utf-8')
    for c_str in string:
        if u'\u4e00' <= c_str <= u'\u9fa5':
            return True
    return False


class ReadFile(object):
    def __init__(self, file_type: str='json'):
        self.file_type = file_type

    def read_json(self, file_path):
        try:
            info = json.loads(open(file_path).read(), encoding='utf-8')
        except Exception as e:
            ex = e
            sys.stderr.write("{}\n".format(traceback.format_exc()))
        else:
            return info
        raise ex

    def read_xml(self, file_path):
        raise NotImplementedError

    def read_pascal_voc(self, file_path):
        raise NotImplementedError

    def __call__(self, file_path):
        func_name = "read_" + self.file_type.lower()

        if not hasattr(self, func_name):
            raise NotImplementedError(f"read function for type [{self.file_type}] is not implemented!")

        return getattr(self, func_name)(file_path)


class AnnoParse(object):

    anno_types = ['json', 'xml']

    def __init__(self, opt):
        self.opt = opt


    @staticmethod
    def get_file(walk_path: str,
                 file_type: Optional[str]=None):
        """
        get files of dir path
        """

        if not os.path.exists(walk_path):
            sys.stdout.write(f"path does not exists! [{walk_path}]\n")

        if not os.path.isabs(walk_path):
            walk_path = os.path.realpath(walk_path)

        if os.path.isfile(walk_path):
            if file_type:
                if walk_path.endswith('.' + file_type.lower()):
                    yield walk_path
            else:
                yield walk_path
        elif os.path.isdir(walk_path):
            for root, dirs, files in os.walk(walk_path):
                if len(files) <= 0:
                    continue
                for perfile in files:
                    perfile = os.path.join(root, perfile)
                    if file_type:
                        if perfile.endswith('.' + file_type.lower()) != -1:
                            yield perfile
                    else:
                        yield perfile
        else:
            sys.stderr.write(f"Invalid dir path: {walk_path}\n")
            raise ValueError


    def get_anno_file(self, anno_path, anno_type):
        assert anno_type.lower() in self.anno_types, f"invalid type: {anno_type}!"

        if not os.path.isabs(anno_path):
            anno_path = os.path.realpath(anno_path)

        anno_sub_paths = os.listdir(anno_path)
        for anno_sub_path in anno_sub_paths:
            anno_sub_path = os.path.join(anno_path, anno_sub_path)

            if os.path.isdir(anno_sub_path):
                sub_types = os.listdir(anno_sub_path)

                if anno_type.lower() in sub_types:
                    anno_sub_type_path = os.path.join(anno_sub_path, anno_type.lower())
                elif anno_type.upper() in sub_types:
                    anno_sub_type_path = os.path.join(anno_sub_path, anno_type.upper())
                else:
                    sys.stderr.write(f"There is no [{anno_type}] anno info within dir: {anno_sub_path}\n")
                    continue

                for perfile in  AnnoParse.get_file(anno_sub_type_path, anno_type.lower()):
                    yield perfile


    def load_anno_file(self, anno_file_path: str) -> Optional[dict]:
        file_type = anno_file_path.split('.')[-1].lower()
        return ReadFile(file_type)(anno_file_path)


    @staticmethod
    def path_windows2linux(path: str) -> str:
        """
        标注数据来源于其他同学，因此数据来源与window或者mac等软件导出结果,
        需要转为linux适配格式

        windows: "D:\\待完成任务\\data2\\hongbao_jiaojie\\0b39f2c66737f2732cc60adbc175ce12.jpg"
        mac:    "/Users/liuxing07/Downloads/data/红包/ffb82141e8035e155608ad9667ba7617.jpg"
        """
        if '\\' in path:
            path = os.sep.join(path.split('\\')[1:])
        return path


    def anno_path2local(self, path, separator='data'):
        """
        annotation file path depends on each person's local path on mac/windows computer
        so need to change it.

        annotation path (Mac/Window):    /Users/liuxing07/Downloads/data/红包/ffb82141e8035e155608ad9667ba7617.jpg
        local path (Linux):           opt.data_path +
                                       ./clean_data/images//红包/ffb82141e8035e155608ad9667ba7617.jpg

        return: relative path according to separator
        """
        assert path.find(separator) != -1, f"cannot find separator({separator}) in path: [{path}]"
        return path.split(separator)[-1].lstrip('/')


    @staticmethod
    def is_valid_image(image_file_path: str,
                       exclude_exts: Optional[list]=["GIF"]) -> bool:
        """
        check whether is an normal image file
        """
        assert os.path.exists(image_file_path), f"{image_file_path} does not exist!"

        image_bin = open(image_file_path, 'rb').read()
        if not image_bin or len(image_bin) < 10:
            sys.stderr.write(f"{image_file_path} is an empty or corrupted image file!\n")
            return False

        image_ext = get_image_real_ext(image_file_path)
        if image_ext is None:
            sys.stderr.write(f"{image_file_path} is not a normal image format file!\n")
            return False

        if exclude_exts and (image_ext in exclude_exts):
            sys.stdout.write(f"{image_file_path} is GIF-image! Ignored!\n")
            return False

        if is_zh(image_file_path):
            image_arr = cv2.imdecode(numpy.frombuffer(image_bin, dtype=numpy.uint8),
                                     cv2.IMREAD_UNCHANGED)
        else:
            image_arr = cv2.imread(image_file_path, cv2.IMREAD_UNCHANGED)

        if image_arr is None:
            sys.stdout.write(f"image read/decode failed! [{image_file_path}]\n")
            return False

        if len(image_arr.shape) == 3:
            height, width, channel = image_arr.shape
            if channel not in [1, 3, 4]:
                sys.stdout.write(f"{image_file_path} is not a normal image with channel={channel}\n")
                return False
        elif len(image_arr.shape) != 2:
            sys.stdout.write(f"{image_file_path} is not an image with shape: {image_arr.shape}\n")
            return False

        return True


    @staticmethod
    def has_labeled_object(image_anno_info: dict) -> bool:
        """
        check whether this image is labeled or has no ocject
        annotation info from biaozhujingling looks like below:

        not labeled:    {"path":"/Users/liuxing07/Downloads/data/红包/0b441165f2d4e820226bb58947cc5236.jpg",
                         "outputs":{},
                         "time_labeled":0,
                         "labeled":false}

        without object: {"path":"/Users/liuxing07/Downloads/data/红包/8c60315daa424ab2612a0092b6af73b3.jpg",
                         "outputs":{"object":[]},
                         "time_labeled":1641883452714,
                         "labeled":true,
                         "size":{"width":4,"height":8,"depth":3}}

        with object:    {"path":"/Users/liuxing07/Downloads/data/红包/0ac474880dee533f2f7f535ade16baac.jpg",
                         "outputs":{"object":[{"name":"普通红包","bndbox":{"xmin":698,"ymin":193,"xmax":1634,"ymax":827}}]},
                         "time_labeled":1641537831612,
                         "labeled":true,
                         "size":{"width":1800,"height":1000,"depth":3}}
        """
        if len(image_anno_info) < 4:
            sys.stdout.write(f"invlaid image_anno_info dict info! [{image_anno_info}]\n")
            return False

        if not image_anno_info.get("labeled", False):
            sys.stdout.write(f"image is not labeled! Ignored!\n")
            return False

        outputs = image_anno_info.get("outputs", None)
        if outputs is None or "object" not in outputs:
            return False

        if len(outputs.get("object")) < 1:
            sys.stdout.write(f"image has zero object! Ignored!\n")
            return False

        return True


    def remove_invalid_anno_image(self):
        """
        remove unlabeled anno files and images
        """
        annotation_path = self.opt.anno_path

        for anno_file in self.get_anno_file(annotation_path, self.opt.anno_type):
            anno_content = self.load_anno_file(anno_file)
            assert isinstance(anno_content, dict)

            image_file = AnnoParse.path_windows2linux(anno_content.get("path"))
            image_file = os.path.join(self.opt.image_path, self.anno_path2local(image_file,
                                                                                separator=self.opt.path2local_sep))

            if  AnnoParse.has_labeled_object(anno_content) and AnnoParse.is_valid_image(image_file):
                continue
            else:
                sys.stdout.write(f"Deleting annotation file: [{anno_file}]\n")
                sys.stdout.write(f"Deleting anno_image file: [{image_file}]\n")
                os.remove(image_file)
                os.remove(anno_file)

    @staticmethod
    def is_same_list(lista: Union[list, set],
                listb: Union[list, set]) -> bool:
        return (set(lista) & set(listb)) == (set(lista) | set(listb))


    def check_anno_image(self) -> bool:
        """
        检查annotation文件是否和images文件保持一致
        """

        annotation_path = self.opt.anno_path
        image_path = self.opt.image_path

        annotation_dirs = os.listdir(annotation_path)
        image_dirs = os.listdir(image_path)

        if not AnnoParse.is_same_list(annotation_dirs, image_dirs):
            sys.stdout.write(f"dirs in annotation path is not matched with dirs in image path!\n")
            sys.stdout.write(f"annotation dirs: {annotation_dirs}\n \
                               images dirs: {image_dirs}\n")
            return False


        is_matched = True

        for class_name in annotation_dirs:

            class_anno_path = os.path.join(annotation_path, class_name)
            class_image_path = os.path.join(image_path, class_name)

            if self.opt.anno_type in os.listdir(class_anno_path):
                anno_type = self.opt.anno_type
            else:
                anno_type = self.opt.anno_type.upper()

            class_anno_path = os.path.join(class_anno_path, anno_type, 'outputs')

            anno_files_dict = {i.split('.')[0]: i for i in os.listdir(class_anno_path)}
            image_files_dict = {i.split('.')[0]: i for i in os.listdir(class_image_path)}

            anno_files = anno_files_dict.keys()
            image_files = image_files_dict.keys()

            if not AnnoParse.is_same_list(anno_files, image_files):
                both_file = set(anno_files) & (image_files)
                anno_files_exclude = set(anno_files) - both_file
                image_files_exclude = set(image_files) - both_file

                sys.stdout.write("{}\n".format("--" * 30))
                sys.stdout.write(f"The anno files below have no matched images!\n"
                                 "{}\n".format('\n'.join([os.path.join(class_anno_path, anno_files_dict.get(i)) for i in anno_files_exclude])))
                sys.stdout.write("{}\n".format("**" * 30))
                sys.stdout.write(f"The image files below have no matched annotations!\n"
                                 "{}\n".format('\n'.join([os.path.join(class_image_path, image_files_dict.get(i)) for i in image_files_exclude])))
                sys.stdout.write("{}\n".format("--" * 30))

                is_matched = False

        return is_matched


    def __call__(self):
        self.remove_invalid_anno_image()
        return self.check_anno_image()



class AnnoToData(object):

    origin_data_type = "json"
    target_data_type = "COCO"

    def __init__(self, opt):
        self.opt = opt
        self.target_data_type = self.opt.dataset_type
        self.dataset = None
        self.class_names = [name.strip() for name in
                                    filter(None, open(self.opt.classes, encoding='utf-8').readlines())]

        # {name: {'class_id': 1, 'supercategory': xxx}}
        self.class_info = defaultdict(dict)

        for ik, class_name in enumerate(self.class_names, 1):
            if class_name == "手机":
                supercategory = "3C电子类"
            else:
                supercategory = "诱导icon"

            self.class_info[class_name] = {"class_id": ik,
                                           "supercategory": supercategory}

        self.init_dataset()


    def init_dataset(self):
        if self.target_data_type == "COCO":
            self.dataset = DataCOCO()
        else:
            raise NotImplementedError






def parse_anno(opt):
    return AnnoParse(opt)()


def main():
    opt_str1 = "--data_path ./crawl_data/data \
               --anno_path annotations/biaozhuxinxi-final-done \
               --anno_type json \
               --image_path images \
               --classes classes.txt \
               --dataset_type COCO \
               --path2local_sep data"

    opt_str = "--data_path ./crawl_data/origin_data_append_clean/ \
               --anno_path annotations/biaozhuxinxi-final-done \
               --anno_type json \
               --image_path images \
               --classes classes.txt \
               --dataset_type COCO \
               --path2local_sep youdao-icons-pinqin"

    opt = Opts().parse(opt_str)
    parse_anno(opt)
    pass


if __name__ == '__main__':
    main()
