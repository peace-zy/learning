#!/usr/bin/env python3
#coding: utf-8

import os
import sys
import cv2
import numpy
import json
import argparse
import traceback

from tqdm import tqdm
from typing import Optional, Union
from collections import defaultdict


_curpath = os.path.dirname(os.path.realpath(__file__))


class ReadFile(object):
    def __init__(self, file_type: str='json'):
        self.file_type = file_type

    def read_json(self, file_path):
        try:
            info = json.loads(open(file_path).read(), encoding='utf-8')
        except Exception as e:
            ex = e
            sys.stderr.write("{}\n".format(traceback.format_exc()))
        else:
            return info
        raise ex

    def read_xml(self, file_path):
        raise NotImplementedError

    def read_pascal_voc(self, file_path):
        raise NotImplementedError

    def __call__(self, file_path):
        func_name = "read_" + self.file_type.lower()

        if not hasattr(self, func_name):
            raise NotImplementedError(f"read function for type [{self.file_type}] is not implemented!")

        return getattr(self, func_name)(file_path)


class DataCOCO(object):

    def __init__(self, opt=None):
        self.data = {
            'categories':[],
            'images':[],
            'annotations':[],
        }

        self.opt = opt
        self.classes_id = defaultdict(int)
        self.classes_supercategory = defaultdict(str)

        self.class_imgbbox = defaultdict(lambda: defaultdict(set))


    def init_categories(self,
                        classes: Union[str, dict, None]=None):
        if classes is None:
            classes = self.opt.classes

        if isinstance(classes, str):
            assert os.path.exists(classes) and os.path.isfile(classes)
            class_info = [i.strip('\n') for i in filter(None, open(classes).readlines())]

            separator = None
            for sep in ['\t', ';', ',', '|', '\x01']:
                if sep in class_info[-1]:
                    separator = sep
            assert len(class_info[-1].split(separator)) <= 2

            if separator is None:
                supercategory = ""
                for ik, name_supercategory in enumerate(class_info, 1):
                    self.classes_id[name_supercategory] = ik
                    self.classes_supercategory[name_supercategory] = supercategory
            else:
                for ik, name_supercategory in enumerate(class_info, 1):
                    name, supercategory = name_supercategory.split(separator)
                    self.classes_id[name] = ik
                    self.classes_supercategory[name] = supercategory
        elif isinstance(classes, dict):
            for name, item in classes.items():
                self.classes_id[name] = item['class_id']
                self.classes_supercategory[name] = item['supercategory']
        else:
            print(f"invalid input classes: {classes}")
            return False


        for class_name, supercategory in self.classes_supercategory.items():
            if "手机" in class_name:
                supercategory = "3C电子"
            else:
                supercategory = "诱导icon"
            self.classes_supercategory[class_name] = supercategory

        for class_name, class_id in self.classes_id.items():
            category_info = {'id': class_id,
                             'name': class_name,
                             'supercategory': self.classes_supercategory[class_name]}
            self.data['categories'].append(category_info)
        return True


    @staticmethod
    def get_file(walk_path: str,
                 file_type: Optional[str]=None):
        """
        get files of dir path
        """

        if not os.path.exists(walk_path):
            sys.stdout.write(f"path does not exists! [{walk_path}]\n")

        if not os.path.isabs(walk_path):
            walk_path = os.path.realpath(walk_path)

        if os.path.isfile(walk_path):
            if file_type:
                if walk_path.endswith('.' + file_type.lower()):
                    yield walk_path
            else:
                yield walk_path
        elif os.path.isdir(walk_path):
            for root, dirs, files in os.walk(walk_path):
                if len(files) <= 0:
                    continue
                for perfile in files:
                    perfile = os.path.join(root, perfile)
                    if file_type:
                        if perfile.endswith('.' + file_type.lower()) != -1:
                            yield perfile
                    else:
                        yield perfile
        else:
            sys.stderr.write(f"Invalid dir path: {walk_path}\n")
            raise ValueError


    def get_anno_file(self, anno_path, anno_type='json'):
        if not os.path.isabs(anno_path):
            anno_path = os.path.realpath(anno_path)

        anno_sub_paths = os.listdir(anno_path)
        for anno_sub_path in anno_sub_paths:
            anno_sub_path = os.path.join(anno_path, anno_sub_path)

            if os.path.isdir(anno_sub_path):
                sub_types = os.listdir(anno_sub_path)

                if anno_type.lower() in sub_types:
                    anno_sub_type_path = os.path.join(anno_sub_path, anno_type.lower())
                elif anno_type.upper() in sub_types:
                    anno_sub_type_path = os.path.join(anno_sub_path, anno_type.upper())
                else:
                    sys.stderr.write(f"There is no [{anno_type}] anno info within dir: {anno_sub_path}\n")
                    continue

                for perfile in  DataCOCO.get_file(anno_sub_type_path, anno_type.lower()):
                    yield perfile


    def load_anno_file(self, anno_file_path: str) -> Optional[dict]:
        file_type = anno_file_path.split('.')[-1].lower()
        return ReadFile(file_type)(anno_file_path)


    def __call__(self):
        if not self.init_categories(self.opt.classes):
            sys.exit(-1)

        image_idx = 0
        bbox_idx = 0

        for anno_file in tqdm(self.get_anno_file(self.opt.anno_path, self.opt.anno_type)):
            anno_content = self.load_anno_file(anno_file)
            assert isinstance(anno_content, dict)

            image_label_path = anno_content.get('path')
            image_relative_path = image_label_path.split(self.opt.path2local_sep)[-1].lstrip('/')
            image_real_path = os.path.join(self.opt.image_path, image_relative_path)


            assert anno_content.get('labeled', False) == True
            assert len(anno_content.get('outputs').get('object', [])) >= 1

            width = int(anno_content.get('size').get('width'))
            height = int(anno_content.get('size').get('height'))
            depth = int(anno_content.get('size').get('depth'))

            assert 4 >= depth >= 2, f"Invalid image channels! [{depth}]"

            image_idx += 1
            image_info = {"file_name": image_relative_path,
                          "width": width,
                          "height": height,
                          "id": image_idx}
            self.data['images'].append(image_info)

            boxes = []
            for bbox in anno_content.get('outputs').get('object'):
                bbox_name = bbox['name']
                x = int(bbox['bndbox']['xmin'])
                y = int(bbox['bndbox']['ymin'])
                bbox_width = int(bbox['bndbox']['xmax'] - x)
                bbox_height = int(bbox['bndbox']['ymax'] - y)

                bbox_idx += 1
                bbox_info = {
                    "area": bbox_width * bbox_height,
                    "bbox": [x, y, bbox_width, bbox_height],
                    "category_id": self.classes_id[bbox_name],
                    "id": bbox_idx,
                    "image_id": image_idx,
                    "iscrowd": 0,
                    "ignore": 0,
                    "segmentation": []
                }
                boxes.append(bbox_info)
                self.class_imgbbox[bbox_name]['images'].add(image_idx)
                self.class_imgbbox[bbox_name]['bboxes'].add(bbox_idx)

            self.data['annotations'].extend(boxes)


        self.to_file()
        self.__repr__()



    def __repr__(self):
        """
        basic infomation about dataset
        """
        self.classes = [i.get('name') for i in self.data['categories']]
        print(f"*" * 100)
        print(f"image number: {len(self.data['images'])}")
        print(f"bbox number: {len(self.data['annotations'])}")
        print(f"classes number: {len(self.classes)} [{self.classes}]")
        for class_name, imgbbox in self.class_imgbbox.items():
            print(f"{class_name:<10}: [image: {len(imgbbox['images']):<10}\tbboxes: {len(imgbbox['bboxes'])}]")


    def to_file(self):
        opath = os.path.join(os.path.dirname(self.opt.anno_path.rstrip('/')), 'train.json')
        with open(opath, 'w', encoding='utf-8') as fout:
            json.dump(self.data, fout)


class Opts(object):
    """
    parameters for parse infomation
    """
    def __init__(self):
        self.parser = argparse.ArgumentParser(description="精灵标注助手标注图像结果处理")

        self.parser.add_argument('--data_path', type=str, dest='data_path', metavar='DATA_PATH',
                                 default='./crawl_data/data', help='图片，标注数据相对当前路径')
        self.parser.add_argument('--anno_path', type=str, dest='anno_path', metavar='ANNO_PATH',
                                 default='annotations', help='标注精灵助手标注结果目录')
        self.parser.add_argument('--anno_type', default='json', type=str,
                                 choices=['json', 'xml', 'pascal-voc'], help='需要解析的标注结果格式')
        self.parser.add_argument('--image_path', type=str, dest='image_path', metavar='IMAGE_PATH',
                                 default='images', help='local image data saved path on linux')
        self.parser.add_argument('--classes', type=str, dest='classes', metavar='CLASSES',
                                 default='classes.txt', help='标注数据类别名称文件')
        self.parser.add_argument('--dataset_type', type=str, choices=['COCO'], default='COCO',
                                 dest='dataset_type', help='target dataset type')
        self.parser.add_argument('--path2local_sep', type=str, default='data',
                                 help='anno path always is path on Mac, so need to get relative path on linux. \
                                 The separator is always the folder name saving anno images on Mac')

    def parse(self, arg_str: str):
        """
        parse parameters from string or command line
        """
        if arg_str:
            opt = self.parser.parse_args(arg_str.split())
        else:
            opt = self.parser.parse_args()

        if not os.path.isabs(opt.data_path):
            opt.data_path = os.path.realpath(opt.data_path)

        if not os.path.isabs(opt.anno_path):
            opt.anno_path = os.path.join(opt.data_path, opt.anno_path)

        if not os.path.isabs(opt.image_path):
            opt.image_path = os.path.join(opt.data_path, opt.image_path)

        if not os.path.isabs(opt.classes):
            opt.classes = os.path.join(opt.data_path, opt.classes)

        if not self.check_opt(opt):
            sys.exit(1)

        return opt


    def check_opt(self, opt) -> bool:
        """
        check parameters of opt
        """
        attr_check = ['anno_path', 'classes', 'data_path', 'image_path']
        for attr in attr_check:
            value = getattr(opt, attr, None)
            if value is None:
                sys.stderr.write(f"Invalid parameters! [opt.{attr}: {value}]\n")
                return False
            elif not os.path.exists(value):
                sys.stderr.write(f"Input parameter [opt.{attr}: {value}] not exists!\n")
                return False
        return True


def generate_coco_dataset(opt):
    return DataCOCO(opt)()


def main():
    opt_str1 = "--data_path ./crawl_data/data \
               --anno_path annotations/biaozhuxinxi-final-done \
               --anno_type json \
               --image_path images \
               --classes classes.txt \
               --dataset_type COCO \
               --path2local_sep data"

    opt_str2 = "--data_path ./crawl_data/origin_data_append_clean/ \
               --anno_path annotations/biaozhuxinxi-final-done \
               --anno_type json \
               --image_path images \
               --classes classes.txt \
               --dataset_type COCO \
               --path2local_sep youdao-icons-pinqin"

    for opt_str in [opt_str1, opt_str2]:
        opt = Opts().parse(opt_str)
        generate_coco_dataset(opt)


def join_coco_json_file():
    data_path = os.path.join(_curpath, 'crawl_data')
    anno_paths = ['origin_data_clean', 'origin_data_append_clean']

    files = [f'crawl_data/{i}/annotations/train.json' for i in anno_paths]

    data = {
        'categories':[],
        'images':[],
        'annotations':[],
    }

    new_classes_map = {'按钮(圆)': '类圆形按钮',
                      '按钮(类矩形)': '类矩形按钮',
                      '手势': '虚拟手势',
                      }

    class_supercategory_map = {}
    for pfile in files:
        per_data = json.load(open(pfile, encoding='utf-8'))
        for categories in per_data['categories']:
            if categories['name'] in new_classes_map:
                class_name = new_classes_map[categories['name']]
            else:
                class_name = categories['name']
            supercategory = categories['supercategory']
            class_supercategory_map[class_name] = supercategory

    new_class_id = {i: ik for ik, i in enumerate(class_supercategory_map.keys(), 1)}
    fout = open(os.path.join(data_path, 'total_classes.txt'), 'w', encoding='utf-8')
    for class_name, cid in new_class_id.items():
        category_info = {'id': cid,
                         'name': class_name,
                         'supercategory': class_supercategory_map[class_name]}
        data['categories'].append(category_info)
        fout.write(f"{class_name}\n")


    classname_imgbbox_map = defaultdict(lambda: defaultdict(set))

    for pfile in files:
        image_num = len(data['images'])
        bbox_num = len(data['annotations'])

        per_data = json.load(open(pfile, encoding='utf-8'))
        origin_id_classname = {i['id']: i['name'] for i in per_data['categories']}

        for image_info in per_data['images']:
            image_info['id'] += image_num
            data['images'].append(image_info)


        for annotation in per_data['annotations']:
            origin_classname = origin_id_classname[annotation['category_id']]
            if origin_classname in new_classes_map:
                new_classname = new_classes_map[origin_classname]
            else:
                new_classname = origin_classname
            annotation['category_id'] = new_class_id[new_classname]
            annotation['id'] += bbox_num
            annotation['image_id'] += image_num
            data['annotations'].append(annotation)

            classname_imgbbox_map[annotation['category_id']]['images'].add(annotation['image_id'])
            classname_imgbbox_map[annotation['category_id']]['bboxes'].add(annotation['id'])

    with open(os.path.join(data_path, 'train.json'), 'w', encoding='utf-8') as fout:
        json.dump(data, fout)


    print('*' * 100)
    print(f"image number: {len(data['images'])}")
    print(f"bbox number: {len(data['annotations'])}")
    for classid, item in classname_imgbbox_map.items():
        classname = [i['name'] for i in data['categories'] if i['id'] == classid][0]
        print(f"{classid:<2}:{classname:<10} [image: {len(classname_imgbbox_map[classid]['images'])} \
                                            bbox: {len(classname_imgbbox_map[classid]['bboxes'])}]")



def split_dataset(data_filepath):
    import random
    import copy
    phase_dict = {"train":0.9, "val":0.1}

    train_data = {
        'categories':[],
        'images':[],
        'annotations':[],
    }
    test_data = copy.deepcopy(train_data)

    data = json.load(open(data_filepath), encoding='utf-8')
    train_data['categories'].extend(data['categories'])
    test_data['categories'].extend(data['categories'])

    test_image_idxs = [i['id'] for i in random.sample(data['images'], round(phase_dict['val'] * len(data['images'])))]

    for image in tqdm(data['images'], desc='processing images ...'):
        if image['id'] in test_image_idxs:
            test_data['images'].append(image)
        else:
            train_data['images'].append(image)

    for bbox in tqdm(data['annotations'], desc='processing bboxed ...'):
        if bbox['image_id'] in test_image_idxs:
            test_data['annotations'].append(bbox)
        else:
            test_data['annotations'].append(bbox)

    with open(os.path.dirname(data_filepath) + f"/train-{phase_dict['train']:.1f}.json", 'w', encoding='utf-8') as fout:
        json.dump(train_data, fout)

    with open(os.path.dirname(data_filepath) + f"/test-{phase_dict['val']:.1f}.json", 'w', encoding='utf-8') as fout:
        json.dump(test_data, fout)




if __name__ == '__main__':
    #main()
    #join_coco_json_file()
    split_dataset(sys.argv[1])



