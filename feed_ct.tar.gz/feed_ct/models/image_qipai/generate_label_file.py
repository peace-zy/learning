#!/usr/bin/env python3
"""
Authors:    liuxing07@baidu.com
"""
#coding:UTF-8

import os
import sys
import numpy as np
import cv2
from tqdm import tqdm
import collections

_cur_path = os.path.dirname(os.path.abspath(__file__))
image_exts = ['jpg', 'jpeg', 'png', 'bmp']

def get_image(path, check_image=False):
    """
    obtain image file from annotation info
    """
    for root, dirs, files in os.walk(path):
        for pfile in files:
            if pfile.startswith('.') or pfile.endswith('.txt'):
                continue
            pfile_name = os.path.join(root, pfile)
            pfile_ext = os.path.splitext(pfile_name)[-1].split('.')[-1]
            if pfile_ext.lower() not in image_exts:
                print('invalid image format![{}]'.format(pfile_name))
                continue
            if check_image:
                imgdata = cv2.imdecode(np.frombuffer(open(pfile_name, 'rb').read(), dtype='uint8'), 1)
                if imgdata is None:
                    os.remove(pfile_name)
                    continue
            yield pfile_name


def main():
    """
    generate data with negtive samples
    """
    positive_image_path = os.path.join(_cur_path, 'data/images')
    voc_image_path = os.path.join(_cur_path, 'data/negtive/', 'VOC2007/JPEGImages')
    object365_image_path1 = os.path.join(_cur_path, 'data/negtive/', 'Object365Dataset/object365/val')
    object365_image_path2 = os.path.join(_cur_path, 'data/negtive/', 'Object365Dataset/object365/train')
    csid_image_path = os.path.join(_cur_path, 'data/negtive/', 'csid_sample_images')

    positive_image_paths = [positive_image_path]
    negtive_image_paths = [voc_image_path, object365_image_path1, object365_image_path2]
    negtive_image_paths = [csid_image_path, voc_image_path, object365_image_path2]

    need_negtive_data = True
    image_paths = []
    image_paths.extend(positive_image_paths)
    if need_negtive_data:
        image_paths.extend(negtive_image_paths)

    #classes_file_path = os.path.join(_cur_path, 'annotation/classify/classes_zhipai_rect.txt')
    classes_file_path=sys.argv[1]
    rect_classes = ['邮票', '纸张明信片', '纸币', '红包']
    classes_names = [item.strip() for item in open(classes_file_path).readlines()]
    classes_id = {classes:idx for idx, classes in enumerate(classes_names, 0)}
    classes_num = collections.defaultdict(int)
    print(classes_id)

    fout = open(os.path.join(_cur_path, 'annotation/classify/train_imgsinfo_images_zhipai_simple.txt'), 'w')

    check_image = False
    for image_path in image_paths:
        if not os.path.exists(image_path):
            print('invalid negtive samplges path![{}]'.format(image_path))
            return
        for pfile_image in tqdm(get_image(image_path, check_image=check_image)):
            if 'negtive' in pfile_image:
                label_name = 'negtive'
            else:
                label_name = pfile_image.split('/')[-2].strip()
                if label_name in rect_classes:
                    label_name = '方形物体'
                else:
                    if label_name not in classes_id.keys():
                        if 'augment' in pfile_image:
                            continue
                        label_name = 'negtive'
            classes_num[label_name] += 1
            if need_negtive_data:
                label_id = classes_id[label_name]
            else:
                label_id = classes_id[label_name] - 1
            res = pfile_image + ' ' + '{}\n'.format(label_id)
            fout.write(res)

    fout.close()
    print(classes_num)

def get_filepath(path):
    """
    get_filepath
    """
    assert os.path.exists(path), 'invalid path! [{}]'.format(path)
    fout = open(os.path.join(path, '../cartoon_image_list.txt'), 'w')
    for imagepath in tqdm(get_image(path, check_image=True)):
        labelname = imagepath.split('/')[-2].strip()
        fout.write('{} {}\n'.format(imagepath, labelname))



if __name__ == '__main__':
    main()
    #get_filepath(sys.argv[1])
else:
    print('import module [{}]'.format(__name__))
