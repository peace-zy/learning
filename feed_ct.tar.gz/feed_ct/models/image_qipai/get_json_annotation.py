#/usr/bin/env python3
"""
Authors:    liuxing07@baidu.com
"""
#coding:utf-8

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import os
import sys
import json
import random
import cv2
import numpy as np
from tqdm import tqdm

CUR_PATH = os.path.dirname(os.path.abspath(__file__))

ANNOTATION_PATH = os.path.join(CUR_PATH, "annotation/detection")
CLASSES_PATH = os.path.join(CUR_PATH, "annotation/detection/classes.txt")

class Opts(object):
    """
    parameters for parse annotations
    """
    def __init__(self):
        self.parser = argparse.ArgumentParser()
        self.parser.add_argument('--annotation_path', default='data/annotations',
            help='标注精灵助手标注结果(json形式导出)目录dir')
        self.parser.add_argument('--classes', default='classes.txt', help='标注数据类别名称文件地址')
        self.parser.add_argument('--out_anno_path', default="annotations", help='输出coco格式json文件')
    def parse(self, args=''):
        """
        parse from str or cmd
        """
        if args == '':
            opt = self.parser.parse_args()
        else:
            opt = self.parser.parse_args(args)
        opt.annotation_path = os.path.join(CUR_PATH, opt.annotation_path)
        opt.classes = os.path.join(CUR_PATH, opt.classes)
        if not os.path.exists(opt.annotation_path):
            print("{} not exists!".format(opt.annotation_path))
        if not os.path.exists(opt.classes):
            print("{} not exists!".format(opt.classes))
        return opt

class Convert(object):
    """
    convert functions
    """
    def __init__(self, opt):
        self.phase_dict = {"train":0.9, "val":0.1}
        self.phase = "train"
        self.phase_size = self.phase_dict[self.phase]
        self.opt = opt
        self.train_dataset = {'categories':[], 'images':[], 'annotations':[]}
        self.val_dataset = {'categories':[], 'images':[], 'annotations':[]}
        self.cls_dict = {}
        self.supercategory = '游戏-棋牌'
        #self.pre_process(self.opt.classes)

    def pre_process(self, classes_file):
        """
        preprocess
        """
        with open(classes_file) as f:
            classes = f.read().strip().split('\n')
        for i, cls in enumerate(classes, 1):
            self.train_dataset['categories'].append({'id':i, 'name':cls, 'supercategory':self.supercategory})
            self.val_dataset['categories'].append({'id':i, 'name':cls, 'supercategory':self.supercategory})
            self.cls_dict[cls] = i

    def get_json_file(self, annotation_path):
        """
        collect annotation json file and return a list
        """
        if not os.path.isdir(annotation_path):
            print("this path [{}] is not directory!".format(annotation_path))
        filelist = []
        for root, dirs, files in os.walk(annotation_path):
            if len(files) > 0:
                for perfile in files:
                    if perfile.find(".json") != -1:
                        filelist.append(os.path.abspath(os.path.join(root, perfile)))
        if len(filelist) < 1:
            print("get empty json files!")
            return None
        return filelist

    def is_ZH(self, image_file):
        '包含汉字的返回TRUE'
        'ord(c_str) > 255 的字符均为中文'
        for c_str in image_file:
            if '\u4e00' <= c_str <= '\u9fa5':
                return True
        return False

    def get_json_info(self, perfile):
        """
        parse each json file
        """
        #if len(filelist) < 1:
        #    print("empty input! [{}]".format(filelist))
        #print("length of filelist is:[{}]".format(len(filelist)))
        #for perfile filelist:
        if not os.path.isfile(perfile):
            print("{} is not a file!".format(perfile))
            return None
        json_info = json.loads(open(perfile).read().strip(), encoding="UTF-8")
        label_image_path = json_info["path"].strip()
        if '/' in label_image_path:
            image_file_name = '/'.join(label_image_path.split('/')[-2:])
        elif '\\' in label_image_path:
            image_file_name = '/'.join(label_image_path.split('\\')[-2:])
        else:
            print('invalid label image file path!')
            return

        imgpath = os.path.join(CUR_PATH, "data/detection_data", image_file_name)
        if (not json_info["labeled"]) or (len(json_info["outputs"]["object"]) < 1):
            try:
                os.remove(imgpath)
            except Exception as e:
                print(e)
            return None
        if self.is_ZH(imgpath):
            image_arr = cv2.imdecode(np.fromfile(imgpath, dtype=np.uint8), cv2.IMREAD_COLOR)
        else:
            image_arr = cv2.imread(imgpath, cv2.IMREAD_COLOR)
        if image_arr is None:
            try:
                os.remove(imgpath)
            except Exception as e:
                print(e)
            return None
        object_box = []
        width = int(json_info["size"]["width"])
        height = int(json_info["size"]["height"])
        depth = int(json_info["size"]["depth"])
        image_info = {"file_name":imgpath, "width":width, "height":height, "depth":depth}
        for box in json_info["outputs"]["object"]:
            name = box["name"]
            if name == '棋牌':
                name = '纸牌'
            x = int(box["bndbox"]["xmin"])
            y = int(box["bndbox"]["ymin"])
            box_width = int(box["bndbox"]["xmax"] - x)
            box_height = int(box["bndbox"]["ymax"] - y)
            object_box.append({"name":name, "x":x, "y":y, "width":box_width, "height":box_height})
        return {"image_info":image_info, "object_box":object_box}

    def make_coco_data(self, filelist):
        """
        generate coco format data
        """
        #for k, perfile in enumerate(filelist, 1):
        img_idx = 0
        box_idx = 0
        for perfile in tqdm(filelist):
            json_info = self.get_json_info(perfile)
            if json_info is None:
                os.remove(perfile)
            else:
                image_info = json_info["image_info"]
                object_box = json_info["object_box"]
                if (image_info["depth"] == 3) and (len(object_box) > 0):
                    img_idx += 1
                    image_info["id"] = img_idx
                    boxes = []
                    for box in object_box:
                        box_idx += 1
                        box_info = {"area": box["width"] * box["height"],
                                    "bbox": [box["x"], box["y"], box["width"], box["height"]],
                                    "category_id": self.cls_dict[box["name"]],
                                    "id": box_idx,
                                    "image_id": img_idx,
                                    "iscrowd":0}
                        boxes.append(box_info)
                    if random.random() < self.phase_size:
                        self.train_dataset["images"].append(image_info)
                        self.train_dataset["annotations"].extend(boxes)
                    else:
                        self.val_dataset["images"].append(image_info)
                        self.val_dataset["annotations"].extend(boxes)
        print('image_num: %d' % img_idx)
        print('box_num: %d' % box_idx)

    def generate_coco_file(self):
        """
        generate coco format data file for trainning
        """
        coco_anno_path = os.path.join(CUR_PATH, "annotation/detection/train")
        if not os.path.exists(coco_anno_path):
            os.makedirs(coco_anno_path)
        with open(os.path.join(coco_anno_path, "train.json"), "w", encoding="UTF-8") as ftrain:
            json.dump(self.train_dataset, ftrain)
        with open(os.path.join(coco_anno_path, "val.json"), "w", encoding="UTF-8") as fval:
            json.dump(self.val_dataset, fval)

    def join(self):
        """
        like call function
        """
        self.pre_process(self.opt.classes)
        filelist = self.get_json_file(self.opt.annotation_path)
        self.make_coco_data(filelist)
        self.generate_coco_file()

if __name__ == "__main__":
    args_str = "--annotation_path data/annotations/ --classes classes.txt --out_anno_path annotations/"
    args_str = '--annotation_path annotation/detection/游戏-棋牌 --classes annotation/detection/classes.txt'
    opt = Opts().parse(args_str.split(' '))
    convert_data = Convert(opt)
    convert_data.join()
















