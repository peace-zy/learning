#!/usr/bin/bash
#coding:UTF-8

source env.sh

# data
#bash task/script.sh data dataset/qipai/data/train_imgsinfo_images_augment_negtive.txt dataset/qipai/
#train
#bash task/script.sh train dataset/qipai/ResNet50_vd.yaml
nohup bash task/script.sh train dataset/qipai/ResNet50_vd.yaml >log/ResNet50_vd_20200908.log 2>&1 &

#freeze
#bash task/script.sh freeze ResNet50_vd output/image_augment_negtive/ResNet50_vd/best_model/ppcls output/image_augment_negtive/ResNet50_vd

