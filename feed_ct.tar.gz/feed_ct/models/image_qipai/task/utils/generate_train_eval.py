# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
本文件实现了分类任务训练集、测试集划分及类别数量。

Authors: zhangyan(zhangyan75@baidu.com)
Date:    2020/08/11 10:00:00
"""

import os
import sys
import random
import traceback
import argparse

def gen_train_eval_with_file(input, save_path, ratio=0.9):
    """gen_train_eval_with_file"""
    train = []
    evaluation = []
    all = {}
    with open(input, 'r') as f:
        for line in f:
            try:
                infos = line.rstrip().split(' ')
                if len(infos) != 2:
                    continue
                img_file = infos[0]
                cls = infos[1]
                if cls not in all:
                    all[cls] = []
                all[cls].append(line)
            except Exception as e:
                continue
    for cls, lines in all.items():
        random.shuffle(lines)
        idx = int(len(lines) * ratio)
        t = lines[:idx]
        e = lines[idx:]
        train.extend(t)
        evaluation.extend(e)
        print('cls:{}, train={}, eval={}'.format(cls, len(t), len(e)))
    if train:
        random.shuffle(train)
        with open(os.path.join(save_path, 'train_list.txt'), 'w') as f:
            f.writelines(train)
    if evaluation:
        random.shuffle(evaluation)
        with open(os.path.join(save_path, 'val_list.txt'), 'w') as f:
            f.writelines(evaluation)
    print('cls_cnt={}, all_train={}, all_eval={}'.\
            format(len(all.keys()), len(train), len(evaluation)))
    print(all.keys())

    return

def gen_train_eval_with_path(input, save_path, ratio=0.9):
    """gen_train_eval_with_path"""
    subdirs = os.listdir(input)
    train = []
    evaluation = []
    cls_cnt = 0
    for sub in subdirs:
        try:
            dir = os.path.join(input, sub)
            if not os.path.isdir(dir):
                continue
            files = os.listdir(dir)
            wlines = []
            for f in files:
                p = os.path.join(dir, f)
                wlines.append('{} {}\n'.format(p, sub))
            random.shuffle(wlines)
            idx = int(len(wlines) * ratio)
            t = wlines[:idx]
            e = wlines[idx:]
            train.extend(t)
            evaluation.extend(e)
            cls_cnt += 1
            print('cls:{}, train={}, eval={}'.format(sub, len(t), len(e)))
        except Exception as e:
            traceback.print_exc()
            continue
    if train:
        random.shuffle(train)
        with open(os.path.join(save_path, 'train.list'), 'w') as f:
            f.writelines(train)
    if evaluation:
        random.shuffle(evaluation)
        with open(os.path.join(save_path, 'eval.list'), 'w') as f:
            f.writelines(evaluation)
    print('cls_cnt={}, all_train={}, all_eval={}'.format(cls_cnt, len(train), len(evaluation)))
    return

def main():
    """main"""
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=str, help='source input anotation file or dataset path')
    parser.add_argument('--save_path', type=str, help='save_path')
    parser.add_argument('--ratio', type=float, default=0.9, help='ratio of training data')
    args = parser.parse_args()

    input = args.input
    save_path = args.save_path
    ratio = args.ratio

    if not os.path.exists(save_path):
        os.makedirs(save_path)
    if os.path.isfile(input):
        gen_train_eval_with_file(input, save_path, ratio)
    elif os.path.isdir(input):
        gen_train_eval_with_path(input, save_path, ratio)

if __name__ == '__main__':
    main()
