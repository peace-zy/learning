#set -e
#set -u
#set -o pipefail

#CUDA_HOME=/home/work/cuda-10.2
#CUDNN_HOME=/home/work/cudnn/cudnn_v7.6
#export LD_LIBRARY_PATH=${CUDA_HOME}/lib64:${CUDNN_HOME}/cuda/lib64:$LD_LIBRARY_PATH
##export PATH=${CUDA_HOME}/bin:$PATH
#export LD_LIBRARY_PATH=/home/work/cudnn/cudnn_v7.6/cuda/lib64:/usr/local/cuda/lib64:/ssd2/dengyuanda/nccl-master/build/lib
#:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=/home/work/cudnn/cudnn_v7.6/cuda/lib64:/ssd2/dengyuanda/nccl-master/build/lib:/home/work/cuda-10.0/lib64
#export LD_LIBRARY_PATH=/ssd2/dengyuanda/nccl-master/build/lib
export PYTHONIOENCODING=UTF-8
