"""
filename:       dataset.py
author:         liuxing07@baidu.com
description:    base class of dataset generator
"""
#!/usr/bin/env python
#coding:UTF-8

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os
import sys
import collections

import torch
import torchvision
import cv2
import numpy
import requests
import transform

from utility import *

_curpath = os.path.dirname(os.path.abspath(__file__))



class DatasetMapFromAnnotation(torch.utils.data.Dataset):
    """
    generate map style dataset from annotation
    """
    def __init__(self, anno_file_path, input_transform=None, target_transform=None,
                 image_max_size=None):
        super(DatasetMapFromAnnotation).__init__()
        self.anno_file_path = anno_file_path
        self.input_transform = input_transform
        self.target_transform = target_transform
        self.image_max_size = image_max_size

        anno_file_path, anno_file_ext = os.path.splitext(self.anno_file_path)
        if anno_file_ext in ['.txt']:
            self.annotations = [item.strip() for item in open(self.anno_file_path).readlines()]
        else:
            self.annotations = []


    def __getitem__(self, index):
        origin_image, image_path, image_size, w_ratio, h_ratio = self.annotations[index].split('\t')
        input_image = cv_imread_check(image_path, image_max_size=self.image_max_size)
        target = numpy.array([w_ratio, h_ratio], dtype=numpy.float32)
        if self.input_transform:
            input_image = self.input_transform(input_image)
        if self.target_transform:
            target = self.target_transform(target)

        return input_image, target


    def __len__(self):
        return len(self.annotations)



class DatasetIterFromAnnotation(torch.utils.data.IterableDataset):
    """
    generate iterable dataset from annotation
    """
    def __init__(self, anno_file_path, batch_size=32, input_transform=None, target_transform=None,
                 image_max_size=None, drop_last=None, batch_size_min=5):
        super(DatasetIterFromAnnotation).__init__()
        self.anno_file_path = anno_file_path
        self.input_transform = input_transform
        self.target_transform = target_transform
        self.image_max_size = image_max_size
        self.batch_size = batch_size
        self.drop_last = drop_last
        self.image_size_indexs = collections.defaultdict(list)
        self.batch_num = 0
        self.batch_size_min = 5

        anno_file_path, anno_file_ext = os.path.splitext(self.anno_file_path)
        if anno_file_ext in ['.txt']:
            self.annotations = [item.strip() for item in open(self.anno_file_path).readlines()]
        else:
            self.annotations = []

        for idx, annotation in enumerate(self.annotations, 0):
            origin_image, image_path, image_size, w_ratio, h_ratio = annotation.split('\t')
            self.image_size_indexs[image_size].append(idx)
        self.image_sizes = list(self.image_size_indexs.keys())
        for image_size in self.image_sizes:
            image_size_batch_num = len(self.image_size_indexs[image_size]) // self.batch_size
            if (len(self.image_size_indexs[image_size]) % self.batch_size) > self.batch_size_min and not self.drop_last:
                image_size_batch_num += 1
            self.batch_num += image_size_batch_num

    def __iter__(self):
        worker_info = torch.utils.data.get_worker_info()
        if worker_info is None:     #single process data loading, return full iterator
            worker_size_indexs = self.image_sizes
        else:
            worker_id = worker_info.id
            total_workers = worker_info.num_workers
            per_worker_num = int(numpy.ceil(len(self.image_sizes) * 1. / total_workers))
            worker_size_indexs_start = worker_id * per_worker_num
            worker_size_indexs_end = min(worker_size_indexs_start + per_worker_num, len(self.image_sizes))
            worker_size_indexs = self.image_sizes[worker_size_indexs_start: worker_size_indexs_end]
        return self.__getbysize__(worker_size_indexs)


    def __getbysize__(self, size_idxs):
        for size_idx in size_idxs:
            batch = []
            for iidx in self.image_size_indexs[size_idx]:
                input_image, target = self.__getitembyidx__(iidx)
                if input_image is None:
                    continue
                batch.append(self.__postprocess__(input_image, target))

                if len(batch) == self.batch_size:
                    batch_images = numpy.stack([item[0] for item in batch], axis=0)
                    batch_targets = numpy.stack([item[1] for item in batch], axis=0)
                    yield batch_images, batch_targets
                    batch = []
            if len(batch) > self.batch_size_min and not self.drop_last:
                batch_images = numpy.stack([item[0] for item in batch], axis=0)
                batch_targets = numpy.stack([item[1] for item in batch], axis=0)
                yield batch_images, batch_targets

    def __getitembyidx__(self, index):
        origin_image, image_path, image_size, w_ratio, h_ratio = self.annotations[index].split('\t')
        input_image = cv_imread_check(image_path, self.image_max_size)
        #input_image = numpy.transpose(input_image, (2,0,1))
        target = numpy.array([w_ratio, h_ratio], dtype=numpy.float32)
        return input_image, target

    def __postprocess__(self, input_image, target):
        if self.input_transform:
            input_image = self.input_transform(input_image)
        if self.target_transform:
            target = self.target_transform(target)

        return input_image, target


    def __len__(self):
        return self.batch_num



def main():
    """
    main function
    """
    dataset_path = os.path.join(_curpath, '../data/datasets/strech_dataset/')
    images_dir = os.path.join(dataset_path, 'images')
    annotation_path = os.path.join(dataset_path, 'annotations/generate_patch_images_anno_sample10K.txt')


    composed = torchvision.transforms.Compose([
                                            transform.ToCHW(),
                                            transform.Normalize(order='CHW')])
    dataset = DatasetIterFromAnnotation(annotation_path, input_transform=composed,
                                        batch_size=16, image_max_size=600, drop_last=False)
    print(len(dataset.image_size_indexs))
    image_size_num_map = {size:len(dataset.image_size_indexs[size]) for size in dataset.image_size_indexs.keys()}
    print(image_size_num_map)

    data_loader = torch.utils.data.DataLoader(dataset=dataset, num_workers=10)
    for iteration, batch_data in enumerate(data_loader, 1):
        if iteration == 10:break
        print(batch_data[0].shape, batch_data[0].dtype, torch.max(batch_data[0]))
        print(batch_data[1].shape, batch_data[1].dtype, torch.max(batch_data[1]))
    print(dataset.batch_num)
    print(len(data_loader))

if __name__ == '__main__':
    main()
else:
    print("import module success! [{}]".format(os.path.join(_curpath, __file__)))

