"""
author:     liuxing07@baidu.com
"""
#!/usr/bin/env python
#coding:UTF-8

import os
import sys
import collections

import cv2
import numpy
import requests
import logging
import logging.handlers
import pypinyin
import hashlib


_curpath = os.path.dirname(os.path.abspath(__file__))

def getlogger(log_file):
    """
    initialize logger handle

    logging.basicConfig < handler.setLevel < logger.setLevel
    """
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    fh = logging.handlers.TimedRotatingFileHandler(filename=log_file, when='midnight',
                                                   interval=1, backupCount=10, encoding='UTF-8')
    #fh.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s")
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    return logger

def chinese2pinqin(word):
    """
    transform Chinese charactor to pinyin format
    """
    s = ''
    word_pinyin = pypinyin.pinyin(word, style=pypinyin.NORMAL)
    for i in word_pinyin:
        s += ''.join(i)
    return s

def is_ZH(string):
    """
    '包含汉字的返回TRUE'
    'ord(c_str) > 255 的字符均为中文'
    """
    for c_str in string:
        if '\u4e00' <= c_str <= '\u9fa5':
            return True
    return False


def md5(bytes_str):
    """
    md5 function from bytes to bytes
    """
    return hashlib.md5(bytes_str).hexdigest()


def dir_to_files(dirpath):
    """
    read files from dirpath
    """
    filepaths = []
    for root, dirs, files in os.walk(dirpath):
        for perfile in files:
            if not perfile.startswith('.'):
                filepaths.append(os.path.join(root, perfile))
    return filepaths


def list_groups(init_list, children_list_len=None, children_list_num=None):
    """
    spplit list to sublists

    init_list:          original list
    children_list_len:  length of sublist
    children_list_num:  number of sublist
    """
    if children_list_num is not None:
        if len(init_list) % children_list_num == 0:
            children_list_len = int(len(init_list) // children_list_num)
        else:
            children_list_len = int(len(init_list) // (children_list_num - 1))
    if children_list_len <= 0:
        return init_list
    list_of_groups = zip(*(iter(init_list),) *children_list_len)
    end_list = [list(i) for i in list_of_groups]
    count = len(init_list) % children_list_len
    end_list.append(init_list[-count:]) if count != 0 else end_list
    return end_list


def cv_imread_check(image_path, image_max_size=None):
    """
    obtain valid image RGB format data
    image_path: [image_path/image_url]
    """
    if image_path.startswith("http"):
        image_bin = requests.get(image_path).content
    else:
        if not os.path.exists(image_path):
            image_bin = None
        if not os.path.isfile(image_path):
            image_bin = None
        if is_ZH(image_path):
            logging.info("image path includes Chinese charactor! \
                         You'd better not next time![{}]".format(image_path))
        image_bin = open(image_path, 'rb').read()
    if image_bin is None:
        return None
    image = cv2.imdecode(numpy.frombuffer(image_bin, dtype=numpy.uint8), cv2.IMREAD_COLOR)
    if image is None:
        return None
    h, w, channel = image.shape
    if channel == 4:
        image = cv2.cvtColor(image, cv2.COLOR_RGBA2RGB)
    if image_max_size and (max(w, h) > image_max_size):
        scale = 1. * image_max_size / max(w, h)
        image = cv2.resize(src=image, dsize=(0, 0), fx=scale, fy=scale, interpolation=cv2.INTER_LINEAR)

    return numpy.ascontiguousarray(image[:, :, ::-1])


def main():
    """
    main function
    """
    pass

if __name__ == '__main__':
    main()
else:
    print("import module success! [{}]".format(os.path.join(_curpath, __file__)))

