"""
author:     liuxing07@baidu.com
"""
#!/usr/bin/env python
#coding:UTF-8

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os
import sys
import collections

import torch
import cv2
import numpy
from PIL import Image


_curpath = os.path.dirname(os.path.abspath(__file__))

class OperatorParamError(ValueError):
    """
    OperatorParamError exception class
    """
    pass

class Rescale(object):
    """
    Rescale the image to a given size

    Args:

    """
    def __init__(self, size=None, on_short=False, interpolation=-1):
        """
        iterpolation parameters:
        enum    cv::InterpolationFlags {
                cv::INTER_NEAREST = 0,
                cv::INTER_LINEAR = 1,
                cv::INTER_CUBIC = 2,
                cv::INTER_AREA = 3,
                cv::INTER_LANCZOS4 = 4,
                cv::INTER_LINEAR_EXACT = 5,
                cv::INTER_MAX = 7,
                cv::WARP_FILL_OUTLIERS = 8,
                cv::WARP_INVERSE_MAP = 16

        }
        """
        self.interpolation = interpolation if (interpolation >= 0 and interpolation <= 16) else None
        if size is None:
            raise OperatorParamError("size must be provided!")
        elif isinstance(size, int):
            self.size = (size, size)
        else:
            assert len(size) == 2
            self.size = size
        self.on_short = on_short

    def __call__(self, image):
        h, w = image.shape[:2]
        if self.on_short:
            scale_ratio = 1. * min(self.size) / min(h, w)
        else:
            scale_ratio = 1. * max(self.size) / max(h, w)
        if self.interpolation is None:
            return cv2.resize(image, dsize=(0, 0), fx=scale_ratio, fy=scale_ratio)
        return cv2.resize(image, dsize=(0, 0), fx=scale_ratio, fy=scale_ratio, interpolation=self.interpolation)


class ExpandDim(object):
    """
    ExpandDim class
    """
    def __init__(self, at_begin=True):
        self.at_begin = at_begin
        if self.at_begin:
            self.dim_position = 0
        else:
            self.dim_position = -1

    def __call__(self, numpy_array):
        return numpy.expand_dims(numpy_array, axis=self.dim_position)


class SqueezeDim(object):
    """
    SqueezeDim class
    """
    def __init__(self, at_begin=True):
        self.at_begin = at_begin
        if self.at_begin:
            self.dim_position = 0
        else:
            self.dim_position = -1

    def __call__(self, numpy_array):
        return numpy.squeeze(numpy_array, axis=self.dim_position)


class ToCHW(object):
    """
    convert HWC format image to CHW format
    """
    def __call__(self, numpy_array):
        #import pdb;pdb.set_trace()
        return numpy.transpose(numpy_array, (2, 0, 1))


class Normalize(object):
    """
    normalization
    """
    def __init__(self, scale=None,  mean=None, std=None, order='CHW'):
        if isinstance(scale, str):
            scale = eval(scale)
        self.scale = numpy.float32(scale if scale is not None else 1. / 255)
        mean = mean if mean is not None else [0.485, 0.456, 0.406]
        std = std if std is not None else [0.229, 0.224, 0.225]

        shape = (3, 1, 1) if order == 'CHW' else (1, 1, 3)
        self.mean = numpy.array(mean).reshape(shape).astype('float32')
        self.std = numpy.array(mean).reshape(shape).astype('float32')

    def __call__(self, numpy_array):
        if isinstance(numpy_array, Image.Image):
            numpy_array = numpy.array(numpy_array)
        assert isinstance(numpy_array, numpy.ndarray), 'invalid input numpy array'
        return (numpy_array.astype('float32') * self.scale - self.mean) / self.std


class ToTorchTensor(object):
    """
    convert numpy.adarray to torch.tensor format
    """
    def __call__(self, numpy_array):
        return torch.tensor(numpy_array)


class TargetNormalize(object):
    """
    normalize stretch targets w/h ratio to [-1, 1] distribution
    """
    def __call__(self, numpy_target):
        return 1. * (numpy_target[0] - 1) - 1. * (numpy_target[1] - 1)


class RandomCrop(object):
    """
    random crop from image
    output shape: [H, W, C]
    """
    def __init__(self, crop_size=None):
        if crop_size is None:
            raise OperatorParamError("crop size must be provided!")
        elif isinstance(crop_size, int):
            self.crop_size = (crop_size, crop_size)
        elif isinstance(crop_size, float):
            self.crop_size = (crop_size, crop_size)
        elif isinstance(crop_size, tuple):
            assert len(crop_size) == 2, 'crop size: (height, width)'
            self.crop_size = crop_size
        elif isinstance(crop_size, list):
            assert len(crop_size) == 2, 'crop size: (height, width)'
            self.crop_size = tuple(crop_size)
        elif isinstance(crop_size, str):
            if '(' in crop_size or '[' in crop_size:
                self.__init__(crop_size = eval(crop_size))
            else:
                crop_size = int(crop_size)
                self.crop_size = (crop_size, crop_size)
        else:
            raise OperatorParamError("Invalid crop size format [{}]".format(crop_size))


    def __call__(self, numpy_array):
        image_h, image_w, image_ch = numpy_array.shape

        crop_h, crop_w = self.crop_size
        if isinstance(crop_h, float):
            crop_h = int(crop_h * image_h)
        if isinstance(crop_w, float):
            crop_w = int(crop_w * image_w)

        if image_h < crop_h or image_w < crop_w:
            raise ValueError('crop size exceeds image size!')
            return None

        h_start = 0 if crop_h == image_h else numpy.random.randint(0, image_h - crop_h)
        w_start = 0 if crop_w == image_w else numpy.random.randint(0, image_w - crop_w)

        return numpy_array[h_start: h_start + crop_h, w_start: w_start + crop_w, :]


class NumpyStack(object):
    """
    numpy stack
    """
    def __call__(self, numpy_arrays, axis=0):
        return numpy.stack(numpy_arrays, axis=axis)
