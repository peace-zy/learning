"""
filename:       data.py
author:         liuxing07@baidu.com
"""
#!/usr/bin/env python
#coding:UTF-8

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os
import torch
import torchvision

import transform
import dataset
import random

_curpath = os.path.dirname(os.path.abspath(__file__))

class ParamError(ValueError):
    """
    custom param exception class
    """
    pass

class IterableTransform(object):
    """
    transforms for interable style dataset
    """
    @staticmethod
    def input_transform():
        """
        transforms of input images
        """
        return torchvision.transforms.Compose([
            transform.ToCHW(),
            transform.Normalize(order='CHW')
        ])


    @staticmethod
    def target_transform(target_normalize):
        """
        transforms of target [y]
        """
        if target_normalize:
            return torchvision.transforms.Compose([
                transform.TargetNormalize()
            ])
        else:
            return torchvision.transforms.Compose([])


class MapTransform(object):
    """
    transofrms for map style dataset
    """
    @staticmethod
    def input_transform(size):
        """
        transforms of input images
        """
        return torchvision.transforms.Compose([
            transform.Rescale(size=size, interpolation=3),
            transform.ToCHW(),
            transform.Normalize(order='CHW')
            ])


    @staticmethod
    def target_transform(target_normalize):
        """
        transforms of target [y]
        """
        if target_normalize:
            return torchvision.transforms.Compose([
                transform.TargetNormalize()
            ])
        else:
            return torchvision.transforms.Compose([])



def get_dataset(mode='train', batch_size=16, num_process=1, train_percent=0.7,
                image_max_size=600, drop_last=False, image_transform_size=None,
                data_dir='', target_normalize=False, **kwargs):
    """
    get dataset of different mode of trainning of evaluation

    shuffle:    True [iterableDatasets]
                False [mapDatasets]
    """
    if num_process <= 0 or num_process == 1:
        num_process = 0

    dataset_path = os.path.join(_curpath, data_dir)
    annotation_path = os.path.join(dataset_path, 'annotations/generate_patch_images_anno_{}.txt')
    if mode == 'train':
        annotation_path = annotation_path.format(mode)
    elif mode == 'val':
        annotation_path = annotation_path.format(mode)
    elif mode == 'sample':
        annotation_path = os.path.join(dataset_path, 'annotations/generate_patch_images_anno_sample10K.txt')
    else:
        raise ParamError("parameter {mode: [train, test, sample]}, input parameter mode:[{}]".format(mode))

    if not os.path.exists(annotation_path):
        split_train_val(dataset_path, train_percent=train_percent)

    if image_transform_size:
        datasets = dataset.DatasetMapFromAnnotation(
            anno_file_path = annotation_path,
            input_transform = MapTransform.input_transform(size=image_transform_size),
            target_transform = MapTransform.target_transform(target_normalize),
            image_max_size = image_max_size, **kwargs
        )
        return torch.utils.data.DataLoader(dataset = datasets,
                                           batch_size = batch_size,
                                           shuffle = True,
                                           num_workers = num_process,
                                           drop_last = drop_last,
                                           pin_memory = True)

    datasets = dataset.DatasetIterFromAnnotation(anno_file_path = annotation_path,
                                                batch_size = batch_size,
                                                input_transform = IterableTransform.input_transform(),
                                                target_transform = IterableTransform.target_transform(target_normalize),
                                                image_max_size = image_max_size,
                                                drop_last = drop_last, **kwargs)
    return torch.utils.data.DataLoader(dataset=datasets, num_workers=num_process)


def split_train_val(dataset_path, train_percent=0.7):
    """
    split dataset to train/val subs
    """
    annotation_path = os.path.join(dataset_path, 'annotations/generate_patch_images_anno.txt')
    annotation_infos = open(annotation_path).readlines()

    annotation_path_sub = os.path.join(dataset_path, 'annotations/generate_patch_images_anno_{}.txt')
    with open(annotation_path_sub.format('train'), 'w') as fout_train, \
            open(annotation_path_sub.format('val'), 'w') as fout_val:
        #random.seed(0)
        for annotation_info in annotation_infos:
            if random.random() < train_percent:
                fout_train.write(annotation_info)
            else:
                fout_val.write(annotation_info)



def main():
    """
    main function
    """
    dataloader = get_dataset(mode='sample', image_transform_size=None,
                             data_dir='../data/datasets/strech_dataset/',
                             target_normalize = False)
    for iteration, batch_data in enumerate(dataloader, 1):
        if iteration == 4:break
        print(batch_data[0].ndim)
        print(batch_data[0].shape, batch_data[0].dtype, torch.max(batch_data[0]))
        print(batch_data[1].shape, batch_data[1].dtype, torch.max(batch_data[1]))
    print(len(dataloader))
    pass

if __name__ == '__main__':
    main()
else:
    print("import module success! [{}]".format(os.path.join(_curpath, __file__)))

