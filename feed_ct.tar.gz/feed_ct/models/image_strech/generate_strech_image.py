"""
filename:   generate_strech_image.py
author:     liuxing07@baidu.com
description:    script for generating strech images
"""
#!/usr/bin/env python
#coding:UTF-8

import os
import sys
import cv2
import requests
import numpy
import logging
import logging.handlers
import pypinyin
import traceback
import random
import hashlib
import tqdm
import datetime

if sys.version_info.major == 3:
    from concurrent import futures
else:
    logging.info("make sure futures module installed! [pip install futures]")
    exit(0)
assert sys.version_info.major == 3
assert sys.version_info.minor >= 2, "concurrent.futures must be with higher than python3.2 version!"

_curpath = os.path.dirname(os.path.abspath(__file__))



def getlogger(log_file):
    """
    initialize logger handle

    logging.basicConfig < handler.setLevel < logger.setLevel
    """
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    fh = logging.handlers.TimedRotatingFileHandler(filename=log_file, when='midnight',
                                                   interval=1, backupCount=10, encoding='UTF-8')
    #fh.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s")
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    return logger

def chinese2pinqin(word):
    """
    transform Chinese charactor to pinyin format
    """
    s = ''
    word_pinyin = pypinyin.pinyin(word, style=pypinyin.NORMAL)
    for i in word_pinyin:
        s += ''.join(i)
    return s


def is_ZH(string):
    """
    '包含汉字的返回TRUE'
    'ord(c_str) > 255 的字符均为中文'
    """
    for c_str in string:
        if '\u4e00' <= c_str <= '\u9fa5':
            return True
    return False


def md5(bytes_str):
    """
    md5 encoding for bytes string
    """
    return hashlib.md5(bytes_str).hexdigest()


def dir_to_files(dirpath):
    """
    look up files of dirpath
    """
    filepaths = []
    for root, dirs, files in os.walk(dirpath):
        for perfile in files:
            if not perfile.startswith('.'):
                filepaths.append(os.path.join(root, perfile))
    return filepaths


def cv_imread_check(image_path):
    """
    obtain valid image RGB format data
    image_path: [image_path/image_url]
    """
    if image_path.startswith("http"):
        image_bin = requests.get(image_path).content
    else:
        if not os.path.exists(image_path):
            logging.warning("image file not exists! [{}]".format(image_path))
            image_bin = None
        if not os.path.isfile(image_path):
            logging.warning("image path must be a file! [{}]".format(image_path))
            image_bin = None
        if is_ZH(image_path):
            logging.info("image path includes Chinese charactor! \
                         You'd better not next time![{}]".format(image_path))
        image_bin = open(image_path, 'rb').read()
    if image_bin is None:
        logging.info("Fail to read image file [{}]!".format(image_path))
        return None
    image = cv2.imdecode(numpy.frombuffer(image_bin, dtype=numpy.uint8), cv2.IMREAD_COLOR)
    if image.shape[-1] == 4:
        image = cv2.cvtColor(image, cv2.COLOR_RGBA2RGB)
    # image[:, :, ::-1] 会导致内存不连续
    return numpy.ascontiguousarray(image[:, :, ::-1])


def list_groups(init_list, children_list_len=None, children_list_num=None):
    """
    spplit list to sublists

    init_list:          original list
    children_list_len:  length of sublist
    children_list_num:  number of sublist
    """
    if children_list_num is not None:
        if len(init_list) % children_list_num == 0:
            children_list_len = int(len(init_list) // children_list_num)
        else:
            if len(init_list) // children_list_num < 1:
                children_list_len = 1
            else:
                children_list_len = int(len(init_list) // (children_list_num - 1))
    if children_list_len <= 0:
        return init_list
    list_of_groups = zip(*(iter(init_list),) *children_list_len)
    end_list = [list(i) for i in list_of_groups]
    count = len(init_list) % children_list_len
    end_list.append(init_list[-count:]) if count != 0 else end_list
    return end_list


class StrechParam(object):
    """
    generate image streching parameters
    """
    def __init__(self, patch_size_max, patch_size_step=40, wh_ratio_max=2.5,
                 wh_ratio_low_high_thresh=1.5, wh_ratio_high_percent=0.8):
        """
        Args:
            patch_size_max(int):        max size of crop patch
            patch_size_step(int):       crop patch step from origin image
            wh_ratio_max(float):        max ratio of w/h or h/w
            wh_ratio_low_high_thresh:   strech ratio threshold, default value is 1.5
            wh_ratio_high_percent:      hihg strech sample percentage of all generated samples

        """
        super(StrechParam, self).__init__()
        self.patch_size_max = patch_size_max
        self.patch_size_min = 100
        self.patch_size_step = patch_size_step

        self.wh_ratio_max = wh_ratio_max
        self.wh_ratio_step = 0.1
        self.wh_ratio_low_high_thresh = wh_ratio_low_high_thresh
        self.wh_ratio_high_percent = wh_ratio_high_percent

        self.patch_size = range(self.patch_size_min, self.patch_size_max + 1, self.patch_size_step)
        self.wh_ratio_low = numpy.arange(1, self.wh_ratio_low_high_thresh, self.wh_ratio_step)
        self.wh_ratio_high = numpy.arange(self.wh_ratio_low_high_thresh, self.wh_ratio_max + 0.001, self.wh_ratio_step)

    def params(self, param_num=1):
        """
        Args:
            param_num(int):     param pair number
        Return: list of strech ratio parameters
            [float, ..., float]
        """
        size_wh_params = []
        for inx in range(param_num):
            if random.random() < self.wh_ratio_high_percent:
                wh_ratio = random.choice(self.wh_ratio_high)
            else:
                wh_ratio = random.choice(self.wh_ratio_low)
            patch_size = random.choice(self.patch_size)
            size_wh_params.append((patch_size, wh_ratio))
        return size_wh_params


def image_crop_patch(image, strech_params, style='CROP_AND_RESIZE'):
    """
    image:      origin base imgae of RGB format
    strech_params:  strech_params
    style:      style of generating trainning images
        CROP_AND_RESIZE:    crop patch from base image and resize to realize streching
        RESIZE_AND_CROP:    strech base and crop image along the short image edge and
                            resize to trainning size
    """
    image_size = image.shape[:2]
    for param in strech_params:
        patch_size, wh_ratio = param
        if style == 'RESIZE_AND_CROP':
            # image without streching
            patch_size_base = min(image.shape[:2])
            h_start = 0 if image.shape[0] == patch_size_base else numpy.random.randint(0,
                                                                                       image.shape[0] - patch_size_base)
            w_start = 0 if image.shape[1] == patch_size_base else numpy.random.randint(0,
                                                                                       image.shape[1] - patch_size_base)
            image_crop = image[h_start:h_start + patch_size_base, w_start:w_start + patch_size_base, :]
            image_patch = cv2.resize(src=image_crop, dsize=(patch_size, patch_size), interpolation=cv2.INTER_AREA)
            yield (image_patch, 1, 1, '{}x{}'.format(patch_size, patch_size), md5(image_patch.tobytes()))


            # image with streching of w direction
            image_w = cv2.resize(src=image, dsize=(0, 0), fx=wh_ratio, fy=1, interpolation=cv2.INTER_AREA)
            patch_size_base = min(image_w.shape[:2])
            h_start = 0 if image_w.shape[0] == patch_size_base else numpy.random.randint(0,
                                                                                    image_w.shape[0] - patch_size_base)
            w_start = 0 if image_w.shape[1] == patch_size_base else numpy.random.randint(0,
                                                                                    image_w.shape[1] - patch_size_base)
            image_w_crop = image_w[h_start:h_start + patch_size_base, w_start:w_start + patch_size_base, :]
            image_patch_w = cv2.resize(src=image_w_crop, dsize=(patch_size, patch_size), interpolation=cv2.INTER_AREA)
            yield (image_patch_w, wh_ratio, 1, '{}x{}'.format(patch_size, patch_size), md5(image_patch_w.tobytes()))


            # image with streching of h direction
            image_h = cv2.resize(src=image, dsize=(0, 0), fx=1, fy=wh_ratio, interpolation=cv2.INTER_AREA)
            patch_size_base = min(image_h.shape[:2])
            h_start = 0 if image_h.shape[0] == patch_size_base else numpy.random.randint(0,
                                                                                    image_h.shape[0] - patch_size_base)
            w_start = 0 if image_h.shape[1] == patch_size_base else numpy.random.randint(0,
                                                                                    image_h.shape[1] - patch_size_base)
            image_h_crop = image_h[h_start: h_start + patch_size_base, w_start: w_start + patch_size_base, :]
            image_patch_h = cv2.resize(src=image_h_crop, dsize=(patch_size, patch_size), interpolation=cv2.INTER_AREA)
            yield (image_patch_h, 1, wh_ratio, '{}x{}'.format(patch_size, patch_size), md5(image_patch_h.tobytes()))

        else:
            if patch_size > min(image_size):
                continue
            #if wh_ratio - 1 <  0.0001:
            #    continue
            # numpy.random.randint()---> [a, b)
            # random.randint() --------> [a, b]
            patch_size_ratio = int(numpy.ceil(patch_size * wh_ratio))
            h_start = 0 if image_size[0] == patch_size else numpy.random.randint(0, image_size[0] - patch_size)
            w_start = 0 if image_size[1] == patch_size else numpy.random.randint(0, image_size[1] - patch_size)
            image_crop = image[h_start: h_start + patch_size, w_start: w_start + patch_size, :]
            yield (image_crop, 1, 1, '{}x{}'.format(patch_size, patch_size), md5(image_crop.tobytes()))
            image_patch_w = cv2.resize(src=image_crop,
                                       dsize=(patch_size_ratio, patch_size), interpolation=cv2.INTER_AREA)
            yield (image_patch_w, wh_ratio, 1,
                   '{}x{}'.format(patch_size_ratio, patch_size), md5(image_patch_w.tobytes()))
            image_patch_h = cv2.resize(src=image_crop,
                                       dsize=(patch_size, patch_size_ratio), interpolation=cv2.INTER_AREA)
            yield (image_patch_h, 1, wh_ratio,
                   '{}x{}'.format(patch_size, patch_size_ratio), md5(image_patch_h.tobytes()))


def base_worker(image, strech_params):
    return image_crop_patch(image, strech_params, style='RESIZE_AND_CROP')


def call_back(future):
    root_image_path = future.arg["root_image_path"]
    root_annotation_path = future.arg["root_annotation_path"]
    origin_base_image_path = future.arg["origin_base_image_path"]
    if future.cancelled():
        logging.info("threading cancelled!")
    elif future.done():
        error = future.exception()
        if error:
            logging.info("threading failed! [{}]".format(error))
        else:
            try:
                results = future.result()
                for result in results:
                    image_patch, w_ratio, h_ratio, size, patch_name = result
                    image_patch_name = os.path.join(root_image_path,
                                                    patch_name + '_{}_{:.2f}_{:.2f}.jpg'.format(size, w_ratio, h_ratio))
                    annotation_info = '\t'.join([origin_base_image_path, image_patch_name, size,
                                                 '{:.2f}\t{:.2f}'.format(w_ratio, h_ratio)])

                    cv2.imwrite(image_patch_name, image_patch[:, :, ::-1])
                    with open(root_annotation_path, 'a+') as fout:
                        fout.write('{}\n'.format(annotation_info))
            except Exception as e:
                logging.info(traceback.format_exc())
                traceback.print_exc()


def thread_worker(image_path, params, root_path, tworker_num=10):
    image = cv_imread_check(image_path)
    image_sub_path = image_path.split('/')
    root_image_path = os.path.join(root_path, 'images', '{}'.format(
            image_sub_path[image_sub_path.index('public_datasets') + 1]), md5(image.tobytes()))
    root_annotation_path = os.path.join(root_path, 'annotations', 'generate_patch_images_anno.txt')
    os.makedirs(root_image_path, exist_ok=True)
    os.makedirs(os.path.dirname(root_annotation_path), exist_ok=True)

    ttasks_params = list_groups(params, children_list_num=tworker_num)
    with futures.ThreadPoolExecutor(max_workers=tworker_num) as t_executor:
        for ttasks_param in ttasks_params:
            t_future = t_executor.submit(base_worker, image, ttasks_param)
            t_future.arg = {"root_image_path": root_image_path, "root_annotation_path": root_annotation_path,
                            "origin_base_image_path": image_path}
            t_future.add_done_callback(call_back)
        futures.wait(t_executor, timeout=20)


def process_worker(ptasks, root_path, pworker_num=5, tworker_num=10, patch_num=10):
    if (pworker_num <= 0) or (pworker_num is None):
        pworker_num = os.cpu_count() or 1
    if len(ptasks) < pworker_num:
        pworker_num = len(ptasks)

    with futures.ProcessPoolExecutor(max_workers=pworker_num) as p_executor:
        p_futures = []
        for ptask in tqdm.tqdm(ptasks):
            strech_param_obj = StrechParam(patch_size_max=300, wh_ratio_max=2.0, wh_ratio_high_percent=0.5)
            strech_params = strech_param_obj.params(param_num=patch_num)

            p_future = p_executor.submit(thread_worker, ptask, strech_params, root_path, tworker_num)
            p_futures.append(p_future)
        for p_future in p_futures:
            if p_future.cancelled():
                logging("process cancelled! [{}]".format(ptask))
            #elif p_future.running():
            #    print("[{}] process is running!".format(p_future))
            elif p_future.done():
                error = p_future.exception()
                if error:
                    logging.info(error)
                    logging.info(traceback.format_exc())



def main():
    public_datasets_path = os.path.join(_curpath, 'datasets/public_datasets')
    image_dataset_path = ['ILSVRC2012/ILSVRC2012_img_val', 'Object365Dataset/object365/val']
    #image_dataset_path = ['test_imgs']

    image_dataset_paths = [os.path.join(public_datasets_path, subpath) for subpath in image_dataset_path]
    generate_strech_dataset_path = os.path.join(_curpath, 'datasets/strech_dataset_samesize_ratio1-2_patchnum5')
    os.makedirs(generate_strech_dataset_path, exist_ok=True)
    getlogger(os.path.join(generate_strech_dataset_path, '{}.log'.format(datetime.date.today())))

    for perdir in image_dataset_paths:
        logging.info("process images of dirpath: [{}]".format(perdir))
        base_images = dir_to_files(perdir)
        process_worker(base_images, generate_strech_dataset_path, pworker_num=10, tworker_num=10, patch_num=5)

if __name__ == "__main__":
    main()
else:
    print("import module [{}] succ!".format(os.path.join(_curpath, __file__)))
