"""
author:     liuxing07@baidu.com
filename:   args.py
description:    arguments for trainning with cmdline input
"""
#!/usr/bin/env python
#coding=UTF-8

import argparse
import os

import resnet

model_names = sorted(name for name in resnet.__dict__
                     if name.islower()
                     and not name.startswith("_")
                     and callable(resnet.__dict__[name])
                     and name.startswith("resnet")
                     and not '_' in name)

_curpath = os.path.dirname(os.path.abspath(__file__))

def optargs():
    """
    parse parameters
    """
    parser = argparse.ArgumentParser(description='Pytorch Training')
    parser.add_argument()
    return parser.parse_args()

class Opt(object):
    """
    opt parameters class
    """
    def __init__(self):
        super(Opt).__init__()
        self.parser = argparse.ArgumentParser(description='Pytorch Training')
        self.parser.add_argument('-s', '--seed', default=0, type=int, help='seed for initialization')
        self.parser.add_argument('-g', '--gpu', default=0, type=int, help='GPU single id to use')
        self.parser.add_argument('-a', '--arch', metavar='ARCH', default='resnet18', choices=model_names,
                                 help='backbone architecture from [{}]'.format('|'.join(model_names)))

        self.parser.add_argument('--data_dir', default='../data/datasets/strech_dataset', type=str,
                                 metavar='DATA_DIR', help='dataset path for trainning', dest='data_dir')
        self.parser.add_argument('-n', '--class_num', default=2, type=int, metavar='CLASS_NUM',
                                 help='number of model class', dest='class_num')
        self.parser.add_argument('--target_normalize', dest='target_normalize', action='store_true',
                                 help='target_normalize for only one stretch ratio')
        self.parser.add_argument('--visualize_model', dest='visualize_model', action='store_true',
                                 help='print model information')

        self.parser.add_argument('--lr', '--learning_rate', default=1e-3, type=float, metavar='LR',
                                 help='initial learning rate', dest='lr')
        self.parser.add_argument('--lr_decay_interval', default=30, type=int, metavar='LR_DECAY_INTERVAL',
                                 help='lr decay interval', dest='lr_decay_interval')
        self.parser.add_argument('--lr_decay_ratio', default=0.1, type=float, metavar='LR_DECAY_RATIO',
                                 help='learning rate decay ratio every interval', dest='lr_decay_ratio')
        self.parser.add_argument('--pretrained', dest='pretrained', action='store_true',
                                 help='whether to load pretrained weight of origin paper result')
        self.parser.add_argument('--resume', default='', type=str, metavar='PATH',
                                 help='path to latest checkpoint for resuming training')
        self.parser.add_argument('--epochs', default=200, metavar="EPOCHS", type=int,
                                 help='total tarinning epoch nums', dest='epochs')
        self.parser.add_argument('--start_epoch', default=0, type=int, metavar='START_EPOCH',
                                 help='manual epoch of resume trainning')
        self.parser.add_argument('--val_interval', default=1, type=int, metavar='VAL_INTERVAL',
                                 help='validation will execute during every ${val_interval} epoch')
        self.parser.add_argument('--save_checkpoint_interval', default=1000, type=int, metavar='SAVE_INTERVAL',
                                 help='save model when every interval epoch', dest='save_checkpoint_interval')

        self.parser.add_argument('-b', '--batch_size', default=32, type=int, metavar='BATCH_SIZE',
                                 help='batch size of trainning and evaluation', dest='batch_size')
        self.parser.add_argument('-j', '--dataload_process_num', default=1, type=int, metavar='PROCESS_NUM',
                                 help='process number of dataloading', dest='dataload_process_num')
        self.parser.add_argument('-p', '--train_percent', default=0.7, type=float, metavar='TRAIN_PERCENT',
                                 help='percentage of dataset for trainning', dest='train_percent')
        self.parser.add_argument('--image_max_size', default=600, type=int, metavar='IMAGE_MAX_SIZE',
                                 help='image max size. This is in case to preventing OOM caused by \
                                 large-size image', dest='image_max_size')
        self.parser.add_argument('--drop_last', dest='drop_last', action='store_true',
                                 help='drop last batch which is less than batch size')
        self.parser.add_argument('--model_save_pathname', default='', type=str, metavar='MODEL_SAVE_PATHNAME',
                                 help='checkpoint model save name of path directory', dest='model_save_pathname')
        self.parser.add_argument('--image_transform_size', default=None, type=int, metavar='IMAGE_TRANSFORM_SIZE',
                                 help='image data size for trainning', dest='image_transform_size')


    def parse(self, args_str=''):
        """
        parse string to parameter
        """
        if args_str == '':
            opt = self.parser.parse_args()
        else:
            args_list = args_str.split()
            opt = self.parser.parse_args(args_list)
            if opt.class_num == 1:
                opt.target_normalize = True
            if opt.target_normalize and opt.class_num != 1:
                opt.class_num = 1
        return opt
