"""
filename:       evaluate.py
description:    model evaluation process
"""
#!/usr/bin/env python
#coding:UTF-8

from __future__ import print_function

import os
import argparse
import traceback
import time

import torch
import pynvml
from tqdm import tqdm
import numpy

import resnet
import utility
import transform


model_names = sorted(name for name in resnet.__dict__
                     if name.islower()
                     and not name.startswith("_")
                     and callable(resnet.__dict__[name])
                     and name.startswith("resnet")
                     and not '_' in name)

_curpath = os.path.dirname(os.path.abspath(__file__))


class Opt(object):
    """
    parameters for model evaluation
    """
    def __init__(self):
        super(Opt).__init__()
        self.parser = argparse.ArgumentParser(description='strech model evaluation')

        self.parser.add_argument('--arch', default='resnet18', choices=model_names, metavar='ARCH',
                                 help='backbone architecture from [{}]'.format('|'.join(model_names)),
                                 dest='arch')
        self.parser.add_argument('--gpu', default=0, type=int, help='GPU id to use for evaluation')
        self.parser.add_argument('--checkpoint', default=None, type=str, help='model checkpoint')
        self.parser.add_argument('-n', '--class_num', default=2, type=int, metavar='CLASS_NUM',
                                 help='number of model class', dest='class_num')

        self.parser.add_argument('--image_path', default=None, type=str, help='image path for evaluation')
        self.parser.add_argument('--file_path', default=None, type=str,
                                 help='a file containning image paths or urls for evaluation')
        self.parser.add_argument('--eval_path', default=os.path.join(_curpath, 'evaluation'), type=str,
                                 help='evaluation directory path')
        self.parser.add_argument('--image_size', default=224, type=int, metavar='IMAGE_SIZE',
                                 help='image size for resize to addaption', dest='image_size')


    def parse(self, cmd_str=''):
        """
        parse command string to parameters
        """
        if cmd_str == '':
            opt = self.parser.parse_args()
        else:
            cmd_list = cmd_str.strip().split()
            opt = self.parser.parse_args(cmd_list)
        return opt


class Data(object):
    """
    image data for evaluation
    """
    def __init__(self, data_path=None):
        """
        data_path:      abspath of data_path
        """
        super(Data).__init__()
        self.data_path = data_path
        self.data_list = []

        if self.data_path is not None:
            if os.path.isfile(self.data_path):
                self.data_path = os.path.abspath(self.data_path)
                data_dirpath, ext = os.path.splitext(self.data_path)
                if ext.lower() in ['.png', '.jpg', 'jpeg', 'tiff', '.bmp']:
                    self.data_list.append(self.data_path)
                else:
                    try:
                        filepaths = [item.strip().split('\t')[0] for item in open(self.data_path).readlines()]
                        self.data_list.extend(filepaths)
                    except Exception as e:
                        print(traceback.format_exc())
                        print('invalid file path! [{}]'.format(self.data_path))
            elif os.path.isdir(self.data_path):
                filepaths = utility.dir_to_files(self.data_path)
                self.data_list.extend(filepaths)

    def __getitem__(self, idx):
        assert idx < self.__len__()
        #if idx < 7464:return None
        if len(self.data_list) == 0:
            return None
        if isinstance(idx, str):
            try:
                idx = int(idx)
            except:
                print(traceback.format_exc())

        if isinstance(idx, int):
            try:
                print(idx)
                image_data = utility.cv_imread_check(image_path=self.data_list[idx])
                return image_data
            except:
                print(traceback.format_exc())
                return None
        elif isinstance(idx, slice):
            sub_data_list = []
            for i in range(idx.start, idx.stop, 1):
                sub_data_list.append(utility.cv_imread_check(image_path=self.data_list[i]))
            return sub_data_list

    def __len__(self):
        return len(self.data_list)


def time_warpper(function):
    """
    decorator function for testing time cost
    """
    def inner_warpper():
        """
        inner function of decorator function
        """
        start_time = time.time()
        function()
        print("time cost: [{}]".format(time.time() - start_time))
    return inner_warpper


def build_model(opt):
    """
    construct model for evaluation
    """
    if opt.gpu is None or opt.gpu == -1:
        device_type = 'cpu'
    elif not torch.cuda.is_available():
        device_type = 'cpu'
    else:
        #pynvml.nvmlInit()
        #gpu_count = pynvml.nvmlDeviceGetCount()
        #pynvml.nvmlShutdown()
        gpu_count = torch.cuda.device_count()
        if opt.gpu not in range(gpu_count):
            device_type = 'cpu'
        else:
            device_type = 'cuda'
            torch.cuda.set_device(opt.gpu)
    device= torch.device(device_type)
    print('=====> building model')

    model = resnet.__dict__[opt.arch](num_classes=opt.class_num, fc2conv=True)

    if opt.checkpoint is None:
        print("invalid checkpoint! [{}".format(opt.checkpoint))
        return
    checkpoint_path = os.path.join(_curpath, opt.checkpoint)
    if os.path.isdir(checkpoint_path):
        checkpoint_path = os.path.join(checkpoint_path, 'model_best.pth')

    map_location = '{}:{}'.format(device_type, opt.gpu) if device_type == 'cuda' else device_type

    checkpoint = torch.load(checkpoint_path, map_location=map_location)
    model.load_state_dict(checkpoint['state_dict'])
    model = model.to(device).eval()
    return model, device


def preprocess(image_numpy, size):
    """
    preprocess for image data
    """
    ops = [transform.Rescale(size=size),
           transform.ToCHW(),
           transform.Normalize(order='CHW'),
           transform.ExpandDim()]
    for op in ops:
        image_numpy = op(image_numpy)
    return image_numpy



def preprocess_crop(image_numpy, size, crop_num=8):
    """
    generate crops of image for batch prediction
    """
    crop_ops = [transform.RandomCrop(min(image_numpy.shape[:2])),
                transform.Rescale(size=size),
                transform.ToCHW(),
                transform.Normalize(order='CHW')]
    image_crops = []
    for ic in range(crop_num):
        image_crop = image_numpy.copy()
        for op in crop_ops:
            image_crop = op(image_crop)
        image_crops.append(image_crop)
    return transform.NumpyStack()(image_crops, axis=0)



def single_evaluate(model, image_numpy, device):
    """
    single evaluating
    """
    with torch.no_grad():
        inputs = torch.tensor(image_numpy).to(device)
        outputs = model(inputs).squeeze().to('cpu').detach()
        return outputs.numpy()


def evaluate(opt):
    """
    main evaluation function
    """
    images_data = Data(data_path=opt.image_path)
    outfile_path = os.path.join(_curpath, opt.eval_path, opt.arch, opt.checkpoint.split('/')[-3],
                                os.path.basename(opt.checkpoint).split('.')[0].split('_')[-1],
                                os.path.basename(opt.image_path) + '_strech_ratio.txt')
    os.makedirs(os.path.dirname(outfile_path), exist_ok=True)
    if os.path.exists(outfile_path):
        os.system('cp {filename} {filename}.bak'.format(filename=outfile_path))
    fout = open(outfile_path, 'w')
    fout.close()
    model, device = build_model(opt)
    for ik, image_data in enumerate(tqdm(images_data), 0):
        if image_data is None:
            continue
        #if ik > 10:break
        try:
            image_path = images_data.data_list[ik]
            image_data = preprocess(image_data, opt.image_size)
            output = single_evaluate(model, image_data, device)
            strech_w, strech_h = float(output[0]), float(output[1])
            write_info = '\t'.join([image_path, 'W:{:.3f}|H:{:.3f}'.format(strech_w, strech_h)])
            with open(outfile_path, 'a+') as fout:
                fout.write('%s\n' % write_info)
        except Exception as e:
            print(traceback.format_exc())
            continue


def test_evaluate(opt):
    """
    test function for testing time cost
    """
    images_data = Data(data_path=opt.image_path)
    print(len(images_data))
    model, device = build_model(opt)
    for ik, image_data in enumerate(tqdm(images_data), 0):
        if image_data is None:
            continue
        image_path = images_data.data_list[ik]
        preprocess_start_time = time.time()
        image_data = preprocess(image_data, opt.image_size)
        evaluate_start_time = time.time()
        print("preprocess time: [{}]".format(evaluate_start_time - preprocess_start_time))
        output = single_evaluate(model, image_data, device)
        print("single_evaluate time: [{}]".format(time.time() - evaluate_start_time))
        if ik > 10: break


def evaluate_target_normalize(opt):
    """
    main evaluation function
    """
    assert opt.class_num == 1, "class num must be equals to 1 with target normalization"
    images_data = Data(data_path=opt.image_path)
    #import pdb;pdb.set_trace()
    outfile_path = os.path.join(_curpath, opt.eval_path, opt.arch, opt.checkpoint.split('/')[-3],
                                os.path.basename(opt.checkpoint).split('.')[0].split('_')[-1],
                                os.path.basename(opt.image_path) + '_strech_ratio.txt')
    os.makedirs(os.path.dirname(outfile_path), exist_ok=True)
    if os.path.exists(outfile_path):
        os.system('cp {filename} {filename}.bak'.format(filename=outfile_path))
    fout = open(outfile_path, 'w')
    fout.close()
    model, device = build_model(opt)
    for ik, image_data in enumerate(tqdm(images_data), 0):
        if image_data is None:
            continue
        if ik >= 10:#len(images_data):
            break
        try:
            image_path = images_data.data_list[ik]
            image_data = preprocess(image_data, opt.image_size)
            output = single_evaluate(model, image_data, device)
            ratio = float(output)
            w_ratio, h_ratio = 1., 1.
            if ratio > 0:
                w_ratio += ratio
            else:
                h_ratio -= ratio
            write_info = '\t'.join([image_path, 'W:{:.3f}|H:{:.3f}'.format(w_ratio, h_ratio)])
            with open(outfile_path, 'a+') as fout:
                fout.write('%s\n' % write_info)
        except Exception as e:
            print(traceback.format_exc())
            continue


def evaluate_crops_target_normalize(opt):
    """
    main evaluation function
    """
    assert opt.class_num == 1, "class num must be equals to 1 with target normalization"
    images_data = Data(data_path=opt.image_path)
    #import pdb;pdb.set_trace()
    outfile_path = os.path.join(_curpath, opt.eval_path, opt.arch, opt.checkpoint.split('/')[-3],
                                os.path.basename(opt.checkpoint).split('.')[0].split('_')[-1], 'crops',
                                os.path.basename(opt.image_path) + '_strech_ratio.txt')
    os.makedirs(os.path.dirname(outfile_path), exist_ok=True)
    if os.path.exists(outfile_path):
        os.system('cp {filename} {filename}.bak'.format(filename=outfile_path))
    fout = open(outfile_path, 'w')
    fout.close()
    model, device = build_model(opt)
    for ik, image_data in enumerate(tqdm(images_data), 0):
        if image_data is None:
            continue
        if ik >= len(images_data):
            break
        try:
            image_path = images_data.data_list[ik]
            image_data = preprocess_crop(image_data, opt.image_size)
            outputs = single_evaluate(model, image_data, device)
            output_index = numpy.argmin(numpy.absolute(outputs - outputs.mean()))
            ratio = float(outputs[output_index])
            w_ratio, h_ratio = 1., 1.
            if ratio > 0:
                w_ratio += ratio
            else:
                h_ratio -= ratio
            write_info = '\t'.join([image_path, 'W:{:.3f}|H:{:.3f}'.format(w_ratio, h_ratio)])
            with open(outfile_path, 'a+') as fout:
                fout.write('%s\n' % write_info)
        except Exception as e:
            print(traceback.format_exc())
            continue



def main():
    """
    main function
    """
    parameters_strings = '--arch resnet18 \
                         --image_path /home/users/liuxing07/ssd2/project/strech/model/pytorch/out/evaluation/{} \
                         --gpu 4 \
                         --class_num 1 \
                         --checkpoint out/checkpoint/resnet18_samesize_ratio1-2_patchnum5_target_normalize_smoothL1/20210426/checkpoint_epoch200.pth \
                         --image_size 224 \
                         --eval_path out/evaluation'
    evaluate_files = ['feed_image_data_strech.txt.show', 'feedads_20210401-20210415_image_urls.txt']
    for evaluate_file in evaluate_files:
        if 'feed_image_data_strech' in evaluate_file:continue
        parameters_string = parameters_strings.format(evaluate_file)
        print(parameters_string.split())
        opt = Opt().parse(parameters_string)
        #test_evaluate(opt)
        evaluate_crops_target_normalize(opt)


    pass

if __name__ == '__main__':
    main()
else:
    print('import module [{}] success!'.format(os.path.join(_curpath, __file__)))
