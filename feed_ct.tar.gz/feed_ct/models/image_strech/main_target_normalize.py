#!/usr/bin/env python3
#coding=UTF-8

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import argparse
import os
import sys
import random
import shutil
import time
import logging
import collections

import torch
import torchvision
from torch.utils.tensorboard import SummaryWriter

from args import Opt

import resnet as models
from data import get_dataset

_curpath = os.path.dirname(os.path.abspath(__file__))


best_acc = 0.
summary_writer = SummaryWriter(comment='strech_target_normalize_lossSmoothL1_batch64')
summary_loss = 0.
summary_acc = 0.
learning_rate = 0.

def main_func(args_str):
    """
    trainning function
    """
    global best_acc
    args = Opt().parse(args_str)

    if args.seed is not None:
        random.seed(args.seed)
        torch.manual_seed(args.seed)
        torch.cuda.manual_seed(args.seed)
        torch.cuda.manual_seed_all(args.seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        logging.info('This will turn on the CUDNN deterministic setting \
                     which can slow down your training considerably! \
                     You may see unexpected behavior when restarting from checkpoints.')

    if args.gpu == -1:
        logging.info('CPU mode!')
        device_type= 'cpu'
    elif not torch.cuda.is_available():
        logging.info("GPU is not available, use CPU which will be slow!")
        device_type = 'cpu'
    else:
        device_type = 'cuda'
        ngpus_per_node = torch.cuda.device_count()
        logging.info('There is [{}] GPU available!')
        assert args.gpu < ngpus_per_node and args.gpu > -1, 'please specify correct gpu parameter'
        torch.cuda.set_device(args.gpu)
    device = torch.device(device_type)


    logging.info("=> building model")

    if args.pretrained:
        logging.info('=> using pre-trained model [{}]'.format(args.arch))
        model = models.__dict__[args.arch](pretrained=True, num_classes=args.class_num, fc2conv=True)
    else:
        logging.info('=> create model [{}]'.format(args.arch))
        model= models.__dict__[args.arch](num_classes=args.class_num, fc2conv=True)
    model = model.to(device)

    # define loss function (criterion) and optimizer
    #criterion = torch.nn.L1Loss().to(device)
    #criterion = torch.nn.MSELoss().to(device)
    criterion = torch.nn.SmoothL1Loss().to(device)
    #optimizer = torch.optim.SGD(model.parameters(), args.lr, momentum=0.9)
    optimizer = torch.optim.Adam(model.parameters(), args.lr)


    if args.resume:
        if os.path.isfile(args.resume):
            logging.info('=> loading checkpoint [{}]'.format(args.resume))
            if device_type == 'cuda':
                map_location = '{}:{}'.format(device_type, args.gpu)
            else:
                map_location = '{}'.format(device_type)
            checkpoint = torch.load(args.resume, map_location=map_location)
            args.start_epoch = checkpoint['epoch']
            best_acc = checkpoint['best_acc']
            #if args.gpu > -1:
            #    best_acc.to(args.gpu)
            model.load_state_dict(checkpoint['state_dict'])
            optimizer.load_state_dict(checkpoint['optimizer'])
            logging.info('=> loading checkpoint [{} (epoch {})]'.format(args.resume, checkpoint['epoch']))
            print('=> loading checkpoint [{} (epoch {})]'.format(args.resume, checkpoint['epoch']))
        else:
            logging.info("=> no checkpoint found at {}".format(args.resume))


    # prepare data loading
    data_parameters = {'batch_size': args.batch_size, 'num_process': args.dataload_process_num,
                      'train_percent': args.train_percent, 'image_max_size': args.image_max_size,
                       'drop_last': args.drop_last, 'image_transform_size': args.image_transform_size,
                       'data_dir': args.data_dir, 'target_normalize': args.target_normalize}
    train_loader = get_dataset(mode='train', **data_parameters)
    val_loader = get_dataset(mode='val', **data_parameters)

    lr_scheduler_cosine = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,
                                                              args.batch_size * len(train_loader),
                                                              0,
                                                              checkpoint['epoch'] - 1 if args.resume else -1)
    lr_scheduler_plateau = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer=optimizer,
                                                                      mode='min',
                                                                      factor=0.1,
                                                                      patience=3,
                                                                      verbose=True,
                                                                      threshold=1e-4,
                                                                      cooldown=0,
                                                                      min_lr=0,
                                                                      eps=1e-8)

    # trainning model
    epoch_lr = collections.defaultdict(int)
    for epoch in range(args.start_epoch, args.epochs):
        #adjust_learning_rate(optimizer, epoch, args)

        is_best = False
        train_loss = train(train_loader, model, criterion, optimizer, epoch, device)
        if (epoch + 1) % args.val_interval == 0:
            val_acc = validation(val_loader, model, criterion, optimizer, device)
            is_best = val_acc > best_acc
            best_acc = max(val_acc, best_acc)
        lr_scheduler_plateau.step(train_loss)
        trainning_params = {'epoch': epoch + 1, 'arch':args.arch, 'state_dict': model.state_dict(),
                            'best_acc': best_acc, 'optimizer': optimizer.state_dict()}
        checkpoint_filepath = os.path.join(_curpath, 'out/checkpoint/{}/{}'.format(
                                    args.model_save_pathname, time.strftime('%Y%m%d')))
        os.makedirs(checkpoint_filepath, exist_ok = True)
        checkpoint_filename = 'checkpoint_epoch{}.pth'.format(epoch+1)
        if (epoch + 1) % args.save_checkpoint_interval == 0:
            checkpoint_filename = os.path.join(checkpoint_filepath,
                                               'checkpoint_epoch{}.pth'.format(epoch + 1))
            save_checkpoint(trainning_params, False, checkpoint_filename)
        if is_best:
            checkpoint_filename = os.path.join(checkpoint_filepath,
                            'model_best_checkpoint_epoch{}_acc{:.3f}.pth'.format(epoch + 1, best_acc))
            save_checkpoint(trainning_params, is_best, checkpoint_filename)

        global summary_loss
        global summary_acc
        global learning_rate
        summary_writer.add_scalar('loss', summary_loss, epoch)
        summary_writer.add_scalar('accuracy', summary_acc, epoch)
        for param_groups in optimizer.param_groups:
            epoch_lr[param_groups['lr']] += 1
        learning_rate = float(sorted(epoch_lr.items(), key=lambda k:k[1], reverse=True)[0][0])
        summary_writer.add_scalar('learning_rate', learning_rate, epoch)




def train(train_loader, model, criterion, optimizer, epoch, device):
    """
    trainning process
    """
    batch_time = AverageMeter('Time', ':6.3f')
    data_time = AverageMeter('Data', ':6.3f')
    loss = AverageMeter('Loss', ':.6f')
    accuracy = AverageMeter('Accuracy', ':6.3f')

    progress = ProgressMeter(len(train_loader), [batch_time, data_time, accuracy, loss],
                             prefix='Epoch: [{}]'.format(epoch))

    model.train()

    end = time.time()
    for ib, (batch_image, batch_target) in enumerate(train_loader):
        data_time.update(time.time() - end)

        #import pdb;pdb.set_trace()
        if batch_image.ndim == 5 and batch_image.shape[0] == 1:
            batch_image = torch.squeeze(batch_image, dim=0)
        if batch_target.ndim == 3 and batch_target.shape[0] == 1:
            batch_target = torch.squeeze(batch_target, dim=0)

        inputs = batch_image.to(device)
        targets = batch_target.to(device)

        outputs = model(inputs).squeeze()
        losses = criterion(outputs, targets)
        outputs_acc = calc_accuracy(outputs, targets)

        accuracy.update(outputs_acc.item(), inputs.size(0))
        loss.update(losses.item(), inputs.size(0))

        # compute gradient and do SGD step
        optimizer.zero_grad()
        losses.backward()
        optimizer.step()

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        global summary_loss
        global summary_acc
        summary_loss = loss.avg
        summary_acc = accuracy.avg

        progress.display(ib)
    print('\n')
    return loss.avg


def validation(val_loader, model, criterion, optimizer, device):
    """
    validation process
    """
    batch_time = AverageMeter('Time', ':6.3f')
    data_time = AverageMeter('Data', ':6.3f')
    loss = AverageMeter('Loss', ':.6f')
    accuracy = AverageMeter('Accuracy', ':6.3f')

    progress = ProgressMeter(len(val_loader), [batch_time, data_time, accuracy, loss],
                             prefix='Test: ')

    model.eval()

    with torch.no_grad():
        end = time.time()
        for ib, (batch_image, batch_target) in enumerate(val_loader):
            data_time.update(time.time() - end)

            if batch_image.ndim == 5 and batch_image.shape[0] == 1:
                batch_image = torch.squeeze(batch_image, dim=0)
            if batch_target.ndim == 3 and batch_target.shape[0] == 1:
                batch_target = torch.squeeze(batch_target, dim=0)
            inputs = batch_image.to(device)
            targets = batch_target.to(device)

            outputs = model(inputs).squeeze()
            losses = criterion(outputs, targets)

            outputs_acc = calc_accuracy(outputs, targets)
            accuracy.update(outputs_acc.item(), inputs.size(0))
            loss.update(losses.item(), inputs.size(0))
            batch_time.update(time.time() - end)
            end = time.time()

            progress.display(ib)
        print('\n')
    return accuracy.avg


def calc_accuracy(output, target, epsilon=1e-1):
    """
    calculate model accuracy of strech ratio regression
    only both predicted w_ratio and h_ratio error less than epsilon becomes the corrected one
    """
    with torch.no_grad():
        #error = (output - target).abs_()
        ## accuracy_w = 1. * torch.sum(error[:, 0] < epsilon) / output.size(0)
        ## accuracy_h = 1. * torch.sum(error[:, 1] < epsilon) / output.size(0)
        #correct = error < epsilon
        #total_correct = correct[:, 0] & correct[:, 1]
        #return 1. * torch.sum(total_correct) / output.size(0)

        if target.ndim == output.ndim == 1:
            return 1. * torch.sum((output - target).abs_() < epsilon) / output.size(0)
        strech_w = output[:, 0] >= output[:, 1]
        #import pdb;pdb.set_trace()
        strech_h = output[:, 0] < output[:, 1]
        error_w = (output[strech_w][:, 0] / output[strech_w][:, 1] -
                        target[strech_w][:, 0] / target[strech_w][:, 1]).abs_()
        error_h = (output[strech_h][:, 1] / output[strech_h][:, 0] -
                        target[strech_h][:, 1] / target[strech_h][:, 0]).abs_()
        return 1. * (torch.sum(error_w < epsilon) + torch.sum(error_h < epsilon)) / output.size(0)


def save_checkpoint(state, is_best, filename):
    """
    save_checkpoint
    """
    torch.save(state, filename)
    if is_best:
        shutil.copyfile(filename, os.path.join(os.path.dirname(filename), 'model_best.pth'))


def adjust_learning_rate(optimizer, epoch, args):
    """
    adjust learning rete during trainning process
    you can custom learning rate schedule
    """
    lr = args.lr * (args.lr_decay_ratio ** (epoch // args.lr_decay_interval))
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr


class AverageMeter(object):
    """
    computes and stores the average and current value
    """
    def __init__(self, name, fmt=':.2f'):
        self.name = name
        self.fmt = fmt
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

    def __str__(self):
        fmtstr = '{name}: {val' + self.fmt + '}({avg' + self.fmt + '})'
        return fmtstr.format(**self.__dict__)

class ProgressMeter(object):
    """
    trainning processBar class
    """
    def __init__(self, num_batches, meters, prefix=''):
        self.batch_fmtstr = self._get_batch_fmtstr(num_batches)
        self.meters = meters
        self.prefix = prefix

    def display(self, batch):
        entries = [self.prefix + self.batch_fmtstr.format(batch)]
        entries += [str(meter) for meter in self.meters]
        print('\r' + '\t'.join(entries), flush=True, end='')

    def _get_batch_fmtstr(self, num_batches):
        num_digits = len(str(num_batches // 1))
        fmt = '{:' + str(num_digits) + 'd}'
        return '[' + fmt + '/' + fmt.format(num_batches) + ']'


def main():
    args_str = '--arch resnet18 \
                --gpu 7 \
                --class_num 1 \
                --train_percent 0.8 \
                --epochs 300 \
                --batch_size 64 \
                --dataload_process_num 8 \
                --lr 1e-4 \
                --save_checkpoint_interval 10 \
                --lr_decay_interval 20 \
                --lr_decay_ratio 0.5 \
                --val_interval 1 \
                --model_save_pathname resnet18_samesize_ratio1-2_patchnum5_target_normalize_smoothL1 \
                --image_transform_size 224 \
                --data_dir ../data/datasets/strech_dataset_samesize_ratio1-2_patchnum5 \
                --target_normalize \
                --resume out/checkpoint/resnet18_samesize_ratio1-2_patchnum5_target_normalize_smoothL1/20210425/checkpoint_epoch170.pth'
    print(args_str.split())
    main_func(args_str)

if __name__ == '__main__':
    main()
else:
    print("import module success! [{}]".format(os.path.join(_curpath, __file__)))

