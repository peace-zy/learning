# !/usr/bin/env python3
"""
get discomfort score via model
"""
import os
import argparse
import torch
from torch import nn
from torchvision import transforms
from torchvision import models
from torchvision import datasets
import torch.optim as optim
import torch.optim.lr_scheduler as lr_scheduler
from torch.utils.data.dataloader import default_collate  
from efficientnet_pytorch import EfficientNet #EfficientNet
import argparse

from PIL import Image
# Image.LOAD_TRUNCATED_IMAGES = True

import warnings
warnings.filterwarnings("ignore")

import math
import json
import urllib.request
from io import BytesIO
import traceback

parser = argparse.ArgumentParser(description='get discomfort classification result')
parser.add_argument('--gpu', default='7', help='define which gpu device to use')  # gpu device number
parser.add_argument('--url', default="", help='single url test, empty for file test')  #  单独测试的 url，为空时则指定批量测试模式
parser.add_argument('--input', default='', help='input image_url file')  # 输入图片 url 路径
parser.add_argument('--output', default='', help='output file path')  # 输出结果保存路径
parser.add_argument('--input_size', type=int, default=224, help='input image_url file')  # 模型输入大小
parser.add_argument('--model', default='./check_points/s2.6.1.14_best.pth', help='model checkpoints path')  # 加载模型路径 
parser.add_argument('--label_map', 
                    default='/ssd3/huxu/classification_datasets/discomfort_s2_v1/discomfort_labels_map.json', 
                    help='label map json file path')  # 加载模型映射词典 
parser.add_argument('--url_idx', type=int, default=-1, help='url`s colum index in input file row') # url 的位置索引

args = parser.parse_args()
os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu
input_size = args.input_size
label_map = json.load(open(args.label_map))
class_num = len(label_map)
transform_in = transforms.Compose([ transforms.Resize(input_size),
                                    transforms.CenterCrop(input_size),
                                    transforms.ToTensor(),
                                    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                                         std=[0.229, 0.224, 0.225])])

def image_preprocess(image):
    """
    image preprocess
    """
    tmp_img = BytesIO(image)
    image = Image.open(tmp_img)
    if image.mode != 'RGB':
        image = image.convert('RGB')
    image = transform_in(image)
    image = image.unsqueeze(0)
    # print(image.shape)
    return image

def process(input_file_path, output_file_path, url_idx=-1):
    """
    main process
    """
    with open(input_file_path) as f_r, open(output_file_path, 'w') as f_w:
        for each_line in f_r:
            rlt_dict = {}
            rlt_class = ''
            rlt_score = 0.0
            try:
                info = each_line.strip().split('\t')
                url = info[url_idx]

                img = urllib.request.urlopen(url, timeout=5).read()
                image = image_preprocess(img)
                
                predict = model(image.cuda())
                rlt = torch.softmax(predict, dim=1).squeeze(0).tolist()
                for idx, prob in enumerate(rlt):
                    prob = round(prob * 100, 2)
                    rlt_dict[label_map[str(idx)]] = prob
                    if idx == 0:
                        continue
                    if prob > 90:
                        rlt_class = label_map[str(idx)]
                        rlt_score = prob
                        break

                rlt_str = json.dumps(rlt_dict)
                print(f'{url}\t{rlt_str}\t{rlt_class}\t{rlt_score}')

                info.extend([rlt_str, rlt_class, str(rlt_score)])
                f_w.write('\t'.join(info) + '\n')
            except Exception as e:
                print(each_line, e)
                traceback.print_exc()
                info.append('{}\terr\t0')
                f_w.write('\t'.join(info) + '\n')

def single_test(img_url):
    """
    single image test process
    """
    rlt_dict = {}
    rlt_class = {}
    try:
        img = urllib.request.urlopen(img_url, timeout=5).read()
        image = image_preprocess(img)
        
        predict = model(image.cuda())
        print(predict)

        rlt = torch.softmax(predict, dim=1)
        print(rlt)

        #print topk results
        topk = torch.topk(rlt, k=class_num).indices.squeeze(0).tolist()
        print(topk)

        for idx in topk:
            prob = rlt[0, idx].item()
            # prob = round(prob, 2)
            if prob > 0.9:
                rlt_class[label_map[str(idx)]] = prob
            rlt_dict[label_map[str(idx)]] = prob
            print(f'[{idx:>2}]:{label_map[str(idx)]:<75} {prob:f}')

        rlt_str = json.dumps(rlt_dict)
        class_str = json.dumps(rlt_class)
        print(f'{img_url}\t{rlt_str}\t{class_str}')

        # score = predict.item()
        # score = str(round(1-score, 6))
        # print(img_url, score)
        
    except Exception as e:
        print(img_url, e)
        traceback.print_exc()

def discomfort2onnx(pt_path):
    onnx_model_name = 'discomfort.onnx'
    model = torch.load(pt_path)
    model.cpu()

    # torch 1.4 + ; discomfort model
    # replace memory_efficient_swish to normal swish layer
    model.set_swish(memory_efficient=False)
    dummy_input = torch.randn(1,3,224,224)
    dynamic_axes = {'input': {0: 'batch'}, 'output': {0: 'batch'}}

    torch.onnx.export(model, dummy_input, onnx_model_name, verbose=True, input_names=['input'], output_names=['output'], dynamic_axes=dynamic_axes)
    print('==============> export to onnx model success!')


if __name__ == '__main__':
    if args.url:
        model = torch.load(args.model)
        model.eval()
        # print(model)
        for i in range(1):
            single_test(args.url)
    elif args.input and args.output:
        model = torch.load(args.model)
        model.eval()
        # print(model)
        print(f"INPUT:{args.input}\nOUTPUT:{args.output}\n")
        process(args.input, args.output, args.url_idx)
    else:
        parser.print_help()
