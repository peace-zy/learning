"""
train discomfort model
"""
from torchvision import datasets, transforms
import torch
from torch import nn
import torch.optim as optim
import argparse
import warnings
import torch.optim.lr_scheduler as lr_scheduler
from torch.utils.data.dataloader import default_collate  
from efficientnet_pytorch import EfficientNet # EfficientNet的使用需要倒入的库
#from label_smooth import LabelSmoothSoftmaxCE
import os
warnings.filterwarnings("ignore")


parser = argparse.ArgumentParser(description='PyTorch <discomfort classification model> Training')
parser.add_argument('--data_dir', default="/ssd3/huxu/classification_datasets/discomfort_s2_v2/", 
                    help='dataset dir')  #  数据集地址
parser.add_argument('--checkpoint_dir', default='./check_points', help='checkpoints path')  # 输出结果保存路径
parser.add_argument('--model_level', default='6', help='pretrained model level')  # 要加载的预训练文件
parser.add_argument('--task_name', default='6_v8', help='task name to clarify multi tasks')  # 保存文件的前缀名
parser.add_argument('--gpu', default='7', help='define which gpu device to use')  # gpu device number
parser.add_argument('--num_classes', type=int, default=14, help='classes to be classified')  # 分类数量
parser.add_argument('--batch_size', type=int, default=16, help='batch size')  # batch_size
parser.add_argument('--epoch', type=int, default=100, help='epoch')  # epoch
parser.add_argument('--input_size', type=int, default=224, help='input image size')  # epoch

args = parser.parse_args()

os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu
pretrained_model = 'efficientnet-b%s' % args.model_level
data_dir = args.data_dir
# 需要分类的数目
num_classes = args.num_classes
# 批处理尺寸
batch_size = args.batch_size
# 训练多少个epoch
EPOCH = args.epoch

class Net(nn.Module):
    """
    model defination
    """
    def __init__(self, model):	#此处的model参数是已经加载了预训练参数的模型，方便继承预训练成果
        super(Net, self).__init__()
        #取掉model的后两层
        self.efficient_layer = nn.Sequential(*list(model.children())[:-2])
        
        self.transion_layer = nn.ConvTranspose2d(2048, 2048, kernel_size=14, stride=3)
        self.pool_layer = nn.MaxPool2d(32)
        self.Linear_layer = nn.Linear(2048, 8)
        
    def forward(self, x):
        """model forward
        """
        x = self.efficient_layer(x)
        x = self.transion_layer(x)
        x = self.pool_layer(x)
        x = x.view(x.size(0), -1)
        x = self.Linear_layer(x)
        
        return x

# feature_extract = True ture为特征提取，false为微调
feature_extract = False
# 超参数设置
pre_epoch = 0  # 定义已经遍历数据集的次数

input_size = args.input_size  
# EfficientNet的使用和微调方法
net = EfficientNet.from_pretrained(pretrained_model)
# net = EfficientNet.from_name('efficientnet-b5')

fc_features = net._fc.in_features
net._fc = nn.Linear(fc_features, num_classes)

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
if torch.cuda.device_count() > 1:
    net = nn.DataParallel(net)
net.to(device)

# net.load_state_dict(torch.load('./model/net_pre.pth'))
# net = net.to(device)
# 数据预处理部分
mean, std = [0.485, 0.456, 0.406], [0.229, 0.224, 0.225]
data_transforms_fix = {
    'train': transforms.Compose([
        transforms.RandomResizedCrop(input_size),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(mean, std),

    ]),

    'val': transforms.Compose([
        # transforms.Resize(int((256 / 224) * input_size)),  # to maintain same ratio w.r.t. 224 images
        transforms.Resize(input_size),  # to maintain same ratio w.r.t. 224 images
        transforms.CenterCrop(input_size),
        transforms.ToTensor(),
        transforms.Normalize(mean, std)
    ]),
}

# data_transforms = {
#     'train': transforms.Compose([
#         transforms.Resize(input_size),
#         transforms.CenterCrop(input_size),
#         transforms.RandomAffine(degrees=0, translate=(0.05, 0.05)),
#         transforms.RandomHorizontalFlip(),
#         transforms.ToTensor(),
#         transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),

#     ]),

#     'val': transforms.Compose([
#         transforms.Resize(input_size),
#         transforms.CenterCrop(input_size),
#         transforms.ToTensor(),
#         transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
#     ]),
# }


def my_collate_fn(batch):
    '''
    batch中每个元素形如(data, label)
    '''
    # 过滤为None的数据
    batch = list(filter(lambda x: x[0] is not None, batch))
    if len(batch) == 0: return torch.Tensor()
    return default_collate(batch)  # 用默认方式拼接过滤后的batch数据

def main():
    """
    train model
    """
    # Create training and validation datasets
    image_datasets = {x: datasets.ImageFolder(os.path.join(data_dir, x), data_transforms_fix[x]) 
                      for x in ['train', 'val']}
    # Create training and validation dataloaders
    dataloaders_dict = {
        x: torch.utils.data.DataLoader(image_datasets[x], batch_size=batch_size, shuffle=True, num_workers=10,
                                       collate_fn=my_collate_fn) for x in ['train', 'val']}
    length = len(dataloaders_dict['train'])
    b = image_datasets['train'].class_to_idx

    params_to_update = net.parameters()

    print("Params to learn:")
    if feature_extract:
        params_to_update = []
        for name, param in net.named_parameters():
            if param.requires_grad == True:
                params_to_update.append(param)
                print("\t", name)
    else:
        for name, param in net.named_parameters():
            if param.requires_grad == True:
                print("\t", name)

    LR = 1e-3  # 学习率
    best_acc = 0  # 初始化best test accuracy

    # criterion
    criterion = nn.CrossEntropyLoss().to(device)
    # optimizer
    optimizer = optim.Adam(params_to_update, lr=LR, betas=(0.9, 0.999), eps=1e-9)
    print("Start Training discomfort model")
    # scheduler
    scheduler = lr_scheduler.ReduceLROnPlateau(optimizer, mode='max', factor=0.7, patience=3, verbose=True)
    with open("./log/%s_acc.log" % args.task_name, "w") as acc_log_file, \
         open("./log/%s_train.log" % args.task_name, "w") as train_log_file:
        for epoch in range(pre_epoch, EPOCH):
            # scheduler.step(epoch)
            print('\nTrain phase!\tEpoch: %d' % (epoch + 1))
            net.train()
            sum_loss = 0.0
            correct = 0.0
            total = 0.0

            for iter_num, data in enumerate(dataloaders_dict['train'], 0):
                # 准备数据
                input, target = data
                input, target = input.to(device), target.to(device)
                # 训练
                optimizer.zero_grad()
                # forward + backward
                output = net(input)
                loss = criterion(output, target)
                loss.backward()
                optimizer.step()
                
                # 每训练1个batch打印一次loss和准确率
                sum_loss += loss.item()
                _, predicted = torch.max(output.data, 1)
                total += target.size(0)
                correct += predicted.eq(target.data).sum()

                # acc = 100. * float(correct) / float(total)
                acc = float(100. * correct / total)
                info = '[epoch:%d, iter:%d] Loss: %.03f | Acc: %.3f%% ' % \
                       (epoch + 1, (iter_num + 1 + epoch * length), sum_loss / (iter_num + 1), acc)
                print(info)
                train_log_file.write(info)
                train_log_file.write('\n')
                train_log_file.flush()

            # 每训练完一个epoch测试一下准确率
            print("Validation phase!")
            with torch.no_grad():
                correct = 0
                total = 0
                for data in dataloaders_dict['val']:
                    net.eval()
                    images, labels = data
                    images, labels = images.to(device), labels.to(device)
                    outputs = net(images)
                    # 取得分最高的那个类 (outputs.data的索引号)
                    _, predicted = torch.max(outputs.data, 1)
                    total += labels.size(0)
                    correct += (predicted == labels).sum()
                # acc = 100. * float(correct) / float(total)
                acc = float(100. * correct / total)
                print('test acc: %.3f%%' % acc)
                scheduler.step(acc)

                # 每10个 epoch 保存一个模型
                if ((epoch - pre_epoch) % 10 == 9):
                    print('Saving model......')
                    torch.save(net.cuda(), '%s/%s_%03d_epoch.pth' % (args.checkpoint_dir, args.task_name, epoch + 1))
                    # torch.save(net.state_dict(), '%s/%s_%03d_epoch.pth' % 
                    #            (args.checkpoint_dir, args.task_name, epoch + 1))
                # 将每次测试结果实时写入acc.txt文件中
                acc_log_file.write("EPOCH=%03d,Accuracy= %.3f%%" % (epoch + 1, acc))
                acc_log_file.write('\n')
                acc_log_file.flush()
                # 记录最佳测试分类准确率并写入best_acc.txt文件中
                if acc >= best_acc:
                    torch.save(net.cuda(), '%s/%s_best.pth' % (args.checkpoint_dir, args.task_name))
                    with open("./log/%s_best_acc.log" % args.task_name, "w") as best_acc_file:
                        best_acc_file.write("EPOCH=%d, test_loss=%.8f, best_acc= %.3f%%\n" % (epoch + 1, sum_loss, acc))
                    best_acc = acc
        print("Training Finished, Total EPOCH=%d" % EPOCH)


if __name__ == "__main__":
    main()
