"""
finetune blur model 
"""
from __future__ import print_function, division
import os
import torch
from torch import nn
import pandas as pd
from skimage import transform
import numpy as np

from torch.utils.data import Dataset, DataLoader
from torch.utils.data.dataloader import default_collate
from torchvision import transforms

from PIL import Image
import time
import math
import copy
from sklearn.model_selection import train_test_split
import torch.optim as optim
from torch.autograd import Variable
from torchvision import models

import warnings

warnings.filterwarnings("ignore")
import random
from scipy.stats import spearmanr, pearsonr

import argparse

parser = argparse.ArgumentParser(description='get blur evaluation result')
parser.add_argument('--gpu', default='5', help='define which gpu device to use')  # gpu device number
parser.add_argument('--pretrain', default='/ssd3/huxu/blur_regression/model/tk_fc1_allsize.pt', 
                    help='pretrained model path')  # 预加载权重
parser.add_argument('--image', default='/ssd3/huxu/blur_regression/dataset/feed_custom/images/', 
                    help='image dir')  # 训练图片保存路径
parser.add_argument('--data', default='/ssd3/huxu/blur_regression/dataset/feed_custom/ls.csv', 
                    help='training data(csv file) path')  # 训练数据路径
parser.add_argument('--save', default='/ssd3/huxu/blur_regression/model/tk_fc1_ls.pt', 
                    help='save best model‘s path')  #  最佳模型的存储路径
parser.add_argument('--epoch', type=int, default=100, help='epochs')  # 迭代次数
parser.add_argument('--lr', type=float, default=1e-4, help='learning rate')  # 学习率 
parser.add_argument('--batch', type=int, default=1, help='batch size')  # batch_size
parser.add_argument('--reshape', action="store_true", default=False, help='preprocess with reshape')  # 训练是否基于resize图片

args = parser.parse_args()
use_gpu = True
Image.LOAD_TRUNCATED_IMAGES = True

class ImageRatingsDataset(Dataset):
    """Images dataset."""
    def __init__(self, csv_file, root_dir, transform=None):
        """
        Args:
            csv_file (string): Path to the csv file with annotations.
            root_dir (string): Directory with all the images.
            transform (callable, optional): Optional transform to be applied
                on a sample.
        """
        
        self.images_frame = pd.read_csv(csv_file, sep=',')
        self.root_dir = root_dir
        self.transform = transform
    
    def __len__(self):
        return len(self.images_frame)
    
    def __getitem__(self, idx):
        # try:
        img_name = str(os.path.join(self.root_dir, str(self.images_frame.iloc[idx, 0])))
        im = Image.open(img_name).convert('RGB')
        if im.mode == 'P':
            im = im.convert('RGB')
        image = np.asarray(im)
        # image = io.imread(img_name+'.jpg', mode='RGB').convert('RGB')
        rating = self.images_frame.iloc[idx, 1]
        sample = {'image': image, 'rating': rating}
        
        if self.transform:
            sample = self.transform(sample)
        return sample
    # except Exception as e:
    #     pass


class Rescale(object):
    """Rescale the image in a sample to a given size.

    Args:
        output_size (tuple or int): Desired output size. If tuple, output is
            matched to output_size. If int, smaller of image edges is matched
            to output_size keeping aspect ratio the same.
    """
    
    def __init__(self, output_size):
        """
        init rescale method
        """
        assert isinstance(output_size, (int, tuple))
        self.output_size = output_size
    
    def __call__(self, sample):
        image, rating = sample['image'], sample['rating']
        h, w = image.shape[:2]
        if isinstance(self.output_size, int):
            if h > w:
                new_h, new_w = self.output_size * h / w, self.output_size
            else:
                new_h, new_w = self.output_size, self.output_size * w / h
        else:
            new_h, new_w = self.output_size
        
        new_h, new_w = int(new_h), int(new_w)
        
        image = transform.resize(image, (new_h, new_w))
        
        return {'image': image, 'rating': rating}


class RandomCrop(object):
    """Crop randomly the image in a sample.

    Args:
        output_size (tuple or int): Desired output size. If int, square crop
            is made.
    """
    
    def __init__(self, output_size):
        assert isinstance(output_size, (int, tuple))
        if isinstance(output_size, int):
            self.output_size = (output_size, output_size)
        else:
            assert len(output_size) == 2
            self.output_size = output_size
    
    def __call__(self, sample):
        image, rating = sample['image'], sample['rating']
        h, w = image.shape[:2]
        new_h, new_w = self.output_size
        
        top = np.random.randint(0, h - new_h)
        left = np.random.randint(0, w - new_w)
        
        image = image[top: top + new_h,
                left: left + new_w]
        
        return {'image': image, 'rating': rating}


class RandomHorizontalFlip(object):
    """Random flip the image
    """
    def __init__(self, p):
        self.p = p
    
    def __call__(self, sample):
        image, rating = sample['image'], sample['rating']
        if random.random() < self.p:
            image = np.flip(image, 1)
            # image = io.imread(img_name+'.jpg', mode='RGB').convert('RGB')
        return {'image': image, 'rating': rating}


class Normalize(object):
    """
    normalize
    """
    def __init__(self):
        self.means = np.array([0.485, 0.456, 0.406])
        self.stds = np.array([0.229, 0.224, 0.225])
    
    def __call__(self, sample):
        image, rating = sample['image'], sample['rating']
        im = image / 1.0  # / 255
        im[:, :, 0] = (image[:, :, 0] - 0.485) / 0.229
        im[:, :, 1] = (image[:, :, 1] - self.means[1]) / self.stds[1]
        im[:, :, 2] = (image[:, :, 2] - self.means[2]) / self.stds[2]
        image = im
        return {'image': image, 'rating': rating}


class ToTensor(object):
    """Convert ndarrays in sample to Tensors."""
    
    def __call__(self, sample):
        image, rating = sample['image'], sample['rating']
        
        # swap color axis because
        # numpy image: H x W x C
        # torch image: C X H X W
        
        image = image.transpose((2, 0, 1))
        return {'image': torch.from_numpy(image).double(),
                'rating': torch.from_numpy(np.float64([rating])).double()}


class Model(nn.Module):
    """
    model defination
    """
    def __init__(self):
        super(Model, self).__init__()
        self.resnet_layer = models.resnet18(pretrained=False)
        self.resnet_layer.avgpool = nn.AdaptiveAvgPool2d(output_size=(1, 1))
        self.resnet_layer.fc = nn.Linear(512, 1)
        self.sig = nn.Sigmoid()
    
    def forward(self, x):
        x = self.resnet_layer(x)
        x = self.sig(x)
        return x


def computeSpearman(dataloader_valid, model):
    """
    compute SROCC in order to evaluate models
    """
    ratings = []
    predictions = []
    with torch.no_grad():
        cum_loss = 0
        for batch_idx, data in enumerate(dataloader_valid):
            inputs = data['image']
            batch_size = inputs.size()[0]
            labels = data['rating'].view(batch_size, -1)
            # labels = labels / 100.0
            if use_gpu:
                try:
                    inputs, labels = Variable(inputs.float().cuda()), Variable(labels.float().cuda())
                except:
                    print(inputs, labels)
            else:
                inputs, labels = Variable(inputs), Variable(labels)
            
            outputs_a = model(inputs)
            ratings.append(labels.float().cpu())
            predictions.append(outputs_a.float().cpu())
    
    ratings_i = np.vstack(ratings)
    predictions_i = np.vstack(predictions)
    a = ratings_i[:, 0]
    b = predictions_i[:, 0]
    sp = spearmanr(a, b)[0]
    pl = pearsonr(a, b)[0]
    return sp, pl

def finetune_model(image_csv_path, image_dir, base_model_path, save_best_model_name, loop_num=1):
    """
    fitune model
    """
    epochs = args.epoch
    srocc_l = []
    
    images = pd.read_csv(image_csv_path, sep=',')
    model_name = os.path.split(save_best_model_name)[1][:-3] + '_'
    if not os.path.exists(image_dir):
        os.makedirs(image_dir)
    for i in range(loop_num):
        images_train, images_test = train_test_split(images, train_size=0.8)
        
        train_path = image_dir + model_name + "train_image" + ".csv"
        test_path = image_dir + model_name + "test_image" + ".csv"
        images_train.to_csv(train_path, sep=',', index=False)
        images_test.to_csv(test_path, sep=',', index=False)
        
        # model = Model()
        # model.load_state_dict(torch.load(base_model_path), strict=False)
        model = torch.load(base_model_path)
        criterion = nn.MSELoss()
        # criterion = nn.SmoothL1Loss()
        
        optimizer = optim.Adam(model.parameters(), lr=args.lr, weight_decay=0)
        model.cuda()
        
        spearman = 0
        for epoch in range(epochs):
            optimizer = exp_lr_scheduler(optimizer, epoch)
            
            if epoch == 0:
                dataloader_valid = load_data(image_dir, train_path, test_path, 'train')
                model.eval()
                
                sp = computeSpearman(dataloader_valid, model)[0]
                if sp > spearman:
                    spearman = sp
                print('no train srocc {:4f}'.format(sp))
            
            # Iterate over data.
            print('############# %s %2d train phase epoch %2d ###############' % (model_name, i, epoch))
            dataloader_train = load_data(image_dir, train_path, test_path, 'train')
            model.train()  # Set model to training mode
            for batch_idx, data in enumerate(dataloader_train):
                inputs = data['image']
                batch_size = inputs.size()[0]
                labels = data['rating'].view(batch_size, -1)
                # labels = labels / 100.0
                if use_gpu:
                    try:
                        inputs, labels = Variable(inputs.float().cuda()), Variable(labels.float().cuda())
                    except:
                        print(inputs, labels)
                else:
                    inputs, labels = Variable(inputs), Variable(labels)
                
                optimizer.zero_grad()
                outputs = model(inputs)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()
            
            print('############# %s %2d test phase epoch %2d ###############' % (model_name, i, epoch))
            dataloader_valid = load_data(image_dir, train_path, test_path, 'test')
            model.eval()
            
            sp, pl = computeSpearman(dataloader_valid, model)

            if sp > spearman:
                spearman = sp
                best_model = copy.deepcopy(model)
                torch.save(best_model.cuda(), save_best_model_name)

            print('Validation Results - Epoch: {:2d}, PLCC: {:4f}, SROCC: {:4f}, '
                  'best SROCC: {:4f}'.format(epoch, pl, sp, spearman))
        
        srocc_l.append(spearman)
    
    ind = 'results/%s' % model_name
    file = pd.DataFrame(columns=[ind], data=srocc_l)
    file.to_csv(ind + '.csv')
    
    torch.save(model.cuda(), model_name + 'final.pt')
    print('average srocc {:4f}'.format(np.mean(srocc_l)))


def exp_lr_scheduler(optimizer, epoch, lr_decay_epoch=10):
    """Decay learning rate by a factor of DECAY_WEIGHT every lr_decay_epoch epochs."""
    
    decay_rate = 0.8 ** (epoch // lr_decay_epoch)
    if epoch % lr_decay_epoch == 0:
        print('decay_rate is set to {}'.format(decay_rate))
    
    for param_group in optimizer.param_groups:
        param_group['lr'] = param_group['lr'] * decay_rate
    
    return optimizer


def my_collate(batch):
    """
    collate data
    """
    batch = list(filter(lambda x: x is not None, batch))
    return default_collate(batch)


def load_data(image_dir='', train_path='', test_path='', mod='train', rescale=args.reshape, meta_num=args.batch):
    """
    dataloader
    """
    if rescale == True:
        output_size = (224, 224)
        transformed_dataset_train = ImageRatingsDataset(csv_file=train_path,
                                                        root_dir=image_dir,
                                                        transform=transforms.Compose([Rescale(output_size=(256, 256)),
                                                                                    RandomHorizontalFlip(0.5),
                                                                                    RandomCrop(
                                                                                        output_size=output_size),
                                                                                    Normalize(),
                                                                                    ToTensor(),
                                                                                    ]))
        transformed_dataset_valid = ImageRatingsDataset(csv_file=test_path,
                                                        root_dir=image_dir,
                                                        transform=transforms.Compose([Rescale(output_size=(224, 224)),
                                                                                    Normalize(),
                                                                                    ToTensor(),
                                                                                    ]))
    else:
        transformed_dataset_train = ImageRatingsDataset(csv_file=train_path,
                                                        root_dir=image_dir,
                                                        transform=transforms.Compose([RandomHorizontalFlip(0.5),
                                                                                    Normalize(),
                                                                                    ToTensor(),
                                                                                    ]))
        transformed_dataset_valid = ImageRatingsDataset(csv_file=test_path,
                                                        root_dir=image_dir,
                                                        transform=transforms.Compose([Normalize(),
                                                                                    ToTensor(),
                                                                                    ]))
    
    if mod == 'train':
        dataloader = DataLoader(transformed_dataset_train, batch_size=meta_num,
                                shuffle=True, num_workers=0, collate_fn=my_collate)
    else:
        dataloader = DataLoader(transformed_dataset_valid, batch_size=meta_num,
                                shuffle=False, num_workers=0, collate_fn=my_collate)
    
    return dataloader

if __name__ == '__main__':
    print(args)
    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu

    finetune_model(image_csv_path=args.data, image_dir=args.image, 
                   base_model_path=args.pretrain, save_best_model_name=args.save)
