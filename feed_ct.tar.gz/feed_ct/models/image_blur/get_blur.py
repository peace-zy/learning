# !/usr/bin/env python3
"""
get blur score via model
"""
import os
import torch
from torch import nn
from torchvision import transforms
from torchvision import models

from PIL import Image
# Image.LOAD_TRUNCATED_IMAGES = True

import warnings
warnings.filterwarnings("ignore")

import math
import urllib.request
from io import BytesIO
import traceback
import argparse

parser = argparse.ArgumentParser(description='get blur evaluation result')
parser.add_argument('--gpu', default='5', help='define which gpu device to use')  # gpu device number
parser.add_argument('--url', default='', help='single url test, empty for file test')  # 单独测试的图片 url 地址
parser.add_argument('--input', default='', help='folder to output images and model checkpoints')  # 输出结果保存路径
parser.add_argument('--output', default='', help='task name to clarify multi tasks')  # 保存文件的前缀名
parser.add_argument('--model', default='/ssd3/huxu/blur_regression/blur_v3_sd.pt', help='checkpoints path')  # 加载模型路径
parser.add_argument('--reshape', action="store_false", default=True, help='preprocess with reshape')  # 输入是否 reshape
parser.add_argument('--url_idx', type=int, default=-1, help='preprocess with reshape')  # url 索引

args = parser.parse_args()

class Model(nn.Module):
    """
    model defination
    """
    def __init__(self):
        super(Model, self).__init__()
        self.resnet_layer = models.resnet18(pretrained=False)
        self.resnet_layer.avgpool = nn.AdaptiveAvgPool2d(output_size=(1, 1))
        self.resnet_layer.fc = nn.Linear(512, 1)
        self.sig = nn.Sigmoid()
    
    def forward(self, x):
        """
        forward
        """
        x = self.resnet_layer(x)
        x = self.sig(x)
        return x

def image_preprocess(image, rescale=True):
    """
    image process
    """
    if rescale:
        transform_in = transforms.Compose([ transforms.Resize(256),
                                            transforms.CenterCrop(224),
                                            transforms.ToTensor(),
                                            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                                                std=[0.229, 0.224, 0.225])])
    else:
        transform_in = transforms.Compose([ transforms.ToTensor(),
                                            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                                                std=[0.229, 0.224, 0.225])])
    tmp_img = BytesIO(image)
    image = Image.open(tmp_img)
    if image.mode != 'RGB':
        image = image.convert('RGB')
    image = transform_in(image)
    image = image.unsqueeze(0)
    return image

def process(input_file_path, output_file_path, url_idx=-1, reshape=True):
    """
    main process
    """
    with open(input_file_path) as f_r, open(output_file_path, 'w') as f_w:
        for each_line in f_r:
            try:
                info = each_line.strip().split('\t')
                url = info[url_idx]

                img = urllib.request.urlopen(url, timeout=5).read()
                image = image_preprocess(img, rescale=reshape)
                
                predict = model(image.cuda())
                score = predict.item()
                score = str(round(1 - score, 6))
                print(url, score)
                
                info.append(score)
                f_w.write('\t'.join(info) + '\n')
            except Exception as e:
                print(each_line, e)
                traceback.print_exc()
                info.append('0.000000')
                f_w.write('\t'.join(info) + '\n')

def single_test(img_url):
    """
    single image test process
    """
    try:
        img = urllib.request.urlopen(img_url, timeout=5).read()
        image = image_preprocess(img)
        
        predict = model(image.cuda())
        score = predict.item()
        score = str(round(score, 6))
        print(img_url, score)
        
    except Exception as e:
        print(img_url, e)
        traceback.print_exc()

def iqa_model_to_depoly_model(iqa_model_path, save_deploy_model_path):
    """
    修改 iqa 模型的 state_dict 的 key，不改变参数，并保存为新模型的 state_dict，方便部署
    保存的 state_dict 使用 model.load_state_dict(torch.load('./model_state.pth')) 加载
    若要使用 torch.load() 方法，需要在新模型中 load 后重新保存一次。
    """
    model = torch.load(iqa_model_path)
    sd = model.state_dict()
    from collections import OrderedDict
    deploy_model_sd = OrderedDict([(k[4:], v) if 'net' in k else (k, v) for k, v in sd.items()])
    torch.save(deploy_model_sd, save_deploy_model_path)

def torch2onnx(pt_path):
    onnx_model_name = 'blur.onnx'
    model = torch.load(pt_path)
    model.cpu()

    dummy_input = torch.randn(1,3,224,224)
    dynamic_axes = {'input': {0: 'batch'}, 'output': {0: 'batch'}}
    torch.onnx.export(model, dummy_input, onnx_model_name, verbose=True, input_names=['input'], output_names=['output'], dynamic_axes=dynamic_axes)


if __name__ == '__main__':
    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu

    # model = torch.load(args.model)

    model = Model()
    model.load_state_dict(torch.load(args.model))
    model.cuda()
    model.eval()
    # print(model)

    if args.url:
        img_url = 'https://feed-image.baidu.com/0/pic/1113f4e6aef0f81ef680f4983a598791.jpg'
        for i in range(1):
            single_test(args.url)
    elif args.input and args.output:
        print(f"INPUT:{args.input}\nOUTPUT:{args.output}\n")
        process(args.input, args.output, url_idx=args.url_idx, reshape=args.reshape)
    else:
        parser.print_help()
