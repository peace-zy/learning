#!/bin/bash
# Path to dataset to use for calibration. 
#   **Not necessary if you already have a calibration cache from a previous run.
CALIBRATION_DATA="../VOCdevkit/VOC2007/JPEGImages"

# Truncate calibration images to a random sample of this amount if more are found.
#   **Not necessary if you already have a calibration cache from a previous run.
MAX_CALIBRATION_SIZE=1024

# Calibration cache to be used instead of calibration data if it already exists,
# or the cache will be created from the calibration data if it doesn't exist.
CACHE_PATH="caches"
if [ ! -d ${CACHE_PATH} ]; then
    mkdir -p ${CACHE_PATH}
fi
CACHE_FILENAME="qipai.cache"

# Any function name defined in `processing.py`
PREPROCESS_FUNC="preprocess_imagenet_with_cv"

# Path to ONNX model
ONNX_MODEL="in_onnx/qipai.onnx"

# Creates an int8 engine from your ONNX model, creating ${CACHE_FILENAME} based
# on your ${CALIBRATION_DATA}, unless ${CACHE_FILENAME} already exists, then
# it will use simply use that instead.
echo ${MAX_CALIBRATION_SIZE}

## calibration with your data [recommend]
function calib_with_your_data()
{
    CUDA_VISIBLE_DEVICES=2 python code/onnx_to_tensorrt.py --fp16 --int8 -v \
        --max-calibration-size=${MAX_CALIBRATION_SIZE} \
        --calibration-data=${CALIBRATION_DATA} \
        --calibration-cache=${CACHE_PATH}/${CACHE_FILENAME} \
        --explicit-batch \
        --preprocess_func=${PREPROCESS_FUNC} \
        --onnx ${ONNX_MODEL}
}

## calibration with random data () 
function calib_with_random_data()
{
    CUDA_VISIBLE_DEVICES=2 python code/onnx_to_tensorrt.py --fp16 --int8 -v \
        --max-calibration-size=${MAX_CALIBRATION_SIZE} \
        --simple \
        --explicit-batch \
        --preprocess_func=${PREPROCESS_FUNC} \
        --onnx ${ONNX_MODEL}
}

function usage()
{
    echo -e """usage:\e[32m
         calibration with [your data]:
         please set CALIBRATION_DATA,MAX_CALIBRATION_SIZE,CACHE_FILENAME,PREPROCESS_FUNC,ONNX_MODEL,OUTPUT
         sh convert_onnx_to_trt_in_int8_mode.sh 0

         calibration with [random data]:
         please set MAX_CALIBRATION_SIZE,CACHE_FILENAME,PREPROCESS_FUNC,ONNX_MODEL,OUTPUT
         sh convert_onnx_to_trt_in_int8_mode.sh 1\e[0m"""
}

if [ $# -eq 0 ];then
    usage
    exit
fi

mode=$1
echo "mode="${mode}
if [ ${mode} == 0 ];then
    calib_with_your_data
elif [ ${mode} == 1 ];then
    calib_with_random_data
else
    echo "invalid mode ["${mode}"] support 0/1 mode"
fi
