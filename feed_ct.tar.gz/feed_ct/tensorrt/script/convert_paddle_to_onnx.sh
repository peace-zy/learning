#!/bin/bash
ONNX_SAVE_PATH="in_onnx"
if [ ! -d ${ONNX_SAVE_PATH} ]; then
    mkdir -p ${ONNX_SAVE_PATH}
fi
ONNX_NAME="qipai.onnx"
paddle2onnx --model_dir model/paddle_cls/qipai --save_file ${ONNX_SAVE_PATH}/${ONNX_NAME} --opset_version 10 --enable_onnx_checker True --params_filename params --model_filename model
#python -m pdb ~/anaconda3/envs/paddle-2.0.0/lib/python3.7/site-packages/paddle2onnx/command.py --model_dir data --save_file currency.onnx --opset_version 10 --enable_onnx_checker True --params_filename __params__ --model_filename __model__
