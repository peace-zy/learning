#!/bin/bash
python code/infer.py -e out_trt/qipai.int8.trt -b 16 
