# paddle模型转成onnx，再将onnx转换成tensorrt  
## 安装
### 网络安装  
- Paddle  
    pip install paddlepaddle-gpu==1.8.5.post107 -f https://paddlepaddle.org.cn/whl/stable.html
- onnx  
    pip install onnx==1.8.1 -i https://pypi.tuna.tsinghua.edu.cn/simple
- Paddle2ONNX  
    [参考原项目地址](https://github.com/PaddlePaddle/Paddle2ONNX)
- tensorrt
    1.安装pycuda  
      pip install 'pycuda>=2019.1.1'
    2.tensorrt、cudnn  
      线上环境:
      tensorrt=7.1.3.4  
      pip install xx.whl
      cudnn=8.0  
      cuda=10.2
- opencv  
    pip install opencv-python==3.4.9.33 -i https://pypi.tuna.tsinghua.edu.cn/simple
### 本地安装 
- Paddle  
  1.本地wheel  
  wget ftp://10.12.186.173:8001/environment/onnx_to_trt/paddlepaddle_gpu-1.8.5.post107-cp37-cp37m-linux_x86_64.whl  
  2.paddle虚拟环境  
  wget ftp://10.12.186.173:8001/environment/onnx_to_trt/paddle.tar.gz  
- tensorrt  
  1.本地cuda  
  wget ftp://10.12.186.173:8001/environment/onnx_to_trt/cuda-10.2.tar.gz  
  2.本地cudnn  
  wget ftp://10.12.186.173:8001/environment/onnx_to_trt/cudnn-8.0.tar.gz  
  3.本地tensorrt  
  wget ftp://10.12.186.173:8001/environment/onnx_to_trt/TensorRT-7.1.3.4.tar.gz  

## paddle分类模型转onnx  
   sh script/convert_paddle_to_onnx.sh 

## 生成校准文件  
   sh script/generate_calibration_cache.sh 0-自己数据(推荐)/1-随机数据  
   
## onnx转tensorrt  
   sh script/convert_onnx_to_trt.sh 0-float32/1-int8  

## 测试  
   sh script/eval_with_trt.sh  
