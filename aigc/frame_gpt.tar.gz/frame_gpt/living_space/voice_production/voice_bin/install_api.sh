#!/usr/bin/env bash

yum install -y opencv opencv-devel opencv-python

set -eu

ROOT_DIR=./
echo ${ROOT_DIR}

source ${ROOT_DIR}/living_space/voice_production/bin/echo_color.sh

umask 000

black_green "[ info ] 升级pip、setuptools、wheel..."
pip install -U pip -i https://mirrors.aliyun.com/pypi/simple/
pip install -U setuptools -i https://mirrors.aliyun.com/pypi/simple/
pip install -U wheel -i https://mirrors.aliyun.com/pypi/simple/

black_green "[ info ] 安装 ke-ffmpeg..."
pip uninstall -y ke-ffmpeg && pip install ${ROOT_DIR}/living_space/voice_production/bin/ke_ffmpeg-*.whl

# black_green "[ info ] 安装依赖包..."
# pip install -r ${ROOT_DIR}/living_space/voice_production/requirements.txt -i https://mirrors.aliyun.com/pypi/simple/ --ignore-installed