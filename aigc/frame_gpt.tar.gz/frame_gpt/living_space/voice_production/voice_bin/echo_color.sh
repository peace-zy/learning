#!/bin/bash

function black_green() {
  echo -e "\e[40;32m${1}\e[0m"
}

function black_red() {
  echo -e "\e[40;31m${1}\e[0m"
}

function blue() {
  echo -e "\033[0;34m${1}\033[0m"
}
