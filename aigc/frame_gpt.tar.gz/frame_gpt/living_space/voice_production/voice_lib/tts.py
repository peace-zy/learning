# -*- coding: utf-8 -*-
# ===============================================================
#
#    Copyright (C) 2020 Beike, Inc. All Rights Reserved.
#
#    @Create Author : liweipeng007 (liweipeng007@ke.com)
#    @Create Time   : 2020/9/23 4:09 下午
#    @Description   : tts任务处理
#
# ===============================================================


import base64
import copy
import json
import math
import re
from collections import namedtuple

import requests

from living_space.voice_production.voice_config.general import TTSConfig
from living_space.voice_production.voice_lib import errors
from living_space.voice_production.voice_utils import common_util, text_util, singleton


class TTSAPI(object, metaclass=singleton.Singleton):
    _max_retry = 5
    _retry_interval = 1

    # 目前标贝的音量调节范围为0-9，5为默认语速；思必驰的音量调节范围为0.5-2（自测），1为默认语速
    # 接口wiki：http://wiki.lianjia.com/pages/viewpage.action?pageId=615424527
    _TTSTuple = namedtuple('TTSTuple', ('url', 'headers', 'body'))
    # 标贝-楠楠
    _bb_nn = _TTSTuple(
        'http://spider.tts.ke.com/tts',
        {"Content-Type": "application/json"},
        {"ak": "2a7a3e0330b79ad1c8754484b9306448",
         "speed": 5,
         "voiceName": "楠楠",
         "distributor": "biaobei",
         "audiotype": "mp3",
         "text": "贝壳是找房大平台！",
         "rate": "16k"}
    )
    # 标贝-静静
    _bb_jj = _TTSTuple(
        'http://spider.tts.ke.com/tts',
        {"Content-Type": "application/json"},
        {"ak": "2a7a3e0330b79ad1c8754484b9306448",
         "speed": 5,
         "voiceName": "静静",
         "distributor": "biaobei",
         "audiotype": "mp3",
         "text": "贝壳是找房大平台！",
         "rate": "16k"}
    )
    # 标贝-静静cc
    _bb_jjcc = _TTSTuple(
        'http://spider.tts.ke.com/tts',
        {"Content-Type": "application/json"},
        {"ak": "2a7a3e0330b79ad1c8754484b9306448",
         "speed": 5,
         "voiceName": "静静cc",
         "distributor": "biaobei",
         "audiotype": "wav",
         "text": "贝壳是找房大平台！",
         "rate": "8k"}
    )
    # 标贝-天天
    _bb_tt = _TTSTuple(
        'http://spider.tts.ke.com/tts',
        {"Content-Type": "application/json"},
        {"ak": "2a7a3e0330b79ad1c8754484b9306448",
         "speed": 5,
         "voiceName": "天天",
         "distributor": "biaobei",
         "audiotype": "mp3",
         "text": "贝壳是找房大平台！",
         "rate": "16k"}
    )
    # 标贝-子衿cc
    _bb_zjcc = _TTSTuple(
        'http://spider.tts.ke.com/tts',
        {"Content-Type": "application/json"},
        {"ak": "2a7a3e0330b79ad1c8754484b9306448",
         "speed": 5,
         "voiceName": "子衿cc",
         "distributor": "biaobei",
         "audiotype": "wav",
         "text": "贝壳是找房大平台！",
         "rate": "8k"}
    )
    # 标贝-阿科
    _bb_ak = _TTSTuple(
        'http://spider.tts.ke.com/tts',
        {"Content-Type": "application/json"},
        {"ak": "2a7a3e0330b79ad1c8754484b9306448",
         "speed": 5,
         "voiceName": "阿科",
         "distributor": "biaobei",
         "audiotype": "mp3",
         "text": "贝壳是找房大平台！",
         "rate": "16k"}
    )
    # 标贝-小金
    _bb_xj = _TTSTuple(
        'http://spider.tts.ke.com/tts',
        {"Content-Type": "application/json"},
        {"ak": "2a7a3e0330b79ad1c8754484b9306448",
         "speed": 5,
         "voiceName": "小金",
         "distributor": "biaobei",
         "audiotype": "mp3",
         "text": "贝壳是找房大平台！",
         "rate": "16k"}
    )
    # 标贝-小金cc
    _bb_xjcc = _TTSTuple(
        'http://spider.tts.ke.com/tts',
        {"Content-Type": "application/json"},
        {"ak": "2a7a3e0330b79ad1c8754484b9306448",
         "speed": 5,
         "voiceName": "小金cc",
         "distributor": "biaobei",
         "audiotype": "wav",
         "text": "贝壳是找房大平台！",
         "rate": "8k"}
    )
    # 思必驰-知性女声晶晶
    _sbc_jj = _TTSTuple(
        'http://spider.tts.ke.com/tts',
        {"Content-Type": "application/json"},
        {"ak": "2a7a3e0330b79ad1c8754484b9306448",
         "speed": 1,
         "voiceName": "jjingf",
         "distributor": "sibichi",
         "audiotype": "mp3",
         "text": "贝壳是找房大平台！",
         "rate": "16k"}
    )

    # 新版
    # 标准男声_01
    _standard_m01 = _TTSTuple(
        'http://gateway.service.speech.ke.com/api/speech/synth/sentence',  # 测试环境
        {"Content-Type": "application/json", "Sk": TTSConfig.Sk, "Traceid": TTSConfig.Traceid},
        {"property": {
            "speaker": 0,
            "volume": 50,
            "speed": 50,
            "CODEC": 2
        }, "text": "贝壳是找房大平台！"}
    )

    # 标准男声_02 (标贝MDB2)
    _standard_m02 = _TTSTuple(
        'http://gateway.service.speech.ke.com/api/speech/synth/sentence',  # 测试环境
        {"Content-Type": "application/json", "Sk": TTSConfig.Sk, "Traceid": TTSConfig.Traceid},
        {"property": {
            "speaker": 1,
            "volume": 50,
            "speed": 50,
            "CODEC": 2
        }, "text": "贝壳是找房大平台！"}
    )

    # 标准女声_01 (海天King003)
    _standard_f01 = _TTSTuple(
        'http://gateway.service.speech.ke.com/api/speech/synth/sentence',  # 测试环境
        {"Content-Type": "application/json", "Sk": TTSConfig.Sk, "Traceid": TTSConfig.Traceid},
        {"property": {
            "speaker": 3,
            "volume": 50,
            "speed": 50,
            "CODEC": 2
        }, "text": "贝壳是找房大平台！"}
    )

    # 标准女声_02 (海天King042)
    _standard_f02 = _TTSTuple(
        'http://gateway.service.speech.ke.com/api/speech/synth/sentence',  # 测试环境
        {"Content-Type": "application/json", "Sk": TTSConfig.Sk, "Traceid": TTSConfig.Traceid},
        {"property": {
            "speaker": 4,
            "volume": 50,
            "speed": 50,
            "CODEC": 2
        }, "text": "贝壳是找房大平台！"}
    )

    # 演讲男声_01 (问问M001)
    _speaker_m01 = _TTSTuple(
        'http://gateway.service.speech.ke.com/api/speech/synth/sentence',  # 测试环境
        {"Content-Type": "application/json", "Sk": TTSConfig.Sk, "Traceid": TTSConfig.Traceid},
        {"property": {
            "speaker": 5,
            "volume": 50,
            "speed": 50,
            "CODEC": 2
        }, "text": "贝壳是找房大平台！"}
    )

    @common_util.retry(_max_retry, _retry_interval)
    def _tts_one(self, text, tts_info):
        tts_tone = tts_info['tone']
        if tts_tone == TTSConfig.TONE_bb_nn:
            tts_tone_config = self._bb_nn
        elif tts_tone == TTSConfig.TONE_bb_jj:
            tts_tone_config = self._bb_jj
        elif tts_tone == TTSConfig.TONE_bb_jjcc:
            tts_tone_config = self._bb_jjcc
        elif tts_tone == TTSConfig.TONE_bb_tt:
            tts_tone_config = self._bb_tt
        elif tts_tone == TTSConfig.TONE_bb_zjcc:
            tts_tone_config = self._bb_zjcc
        elif tts_tone == TTSConfig.TONE_bb_ak:
            tts_tone_config = self._bb_ak
        elif tts_tone == TTSConfig.TONE_bb_xj:
            tts_tone_config = self._bb_xj
        elif tts_tone == TTSConfig.TONE_bb_xjcc:
            tts_tone_config = self._bb_xjcc
        elif tts_tone == TTSConfig.TONE_sbc_jj:
            tts_tone_config = self._sbc_jj
        elif tts_tone == TTSConfig.STANDARD_M01:
            tts_tone_config = self._standard_m01
        elif tts_tone == TTSConfig.STANDARD_M02:
            tts_tone_config = self._standard_m02
        elif tts_tone == TTSConfig.STANDARD_F01:
            tts_tone_config = self._standard_f01
        elif tts_tone == TTSConfig.STANDARD_F02:
            tts_tone_config = self._standard_f02
        elif tts_tone == TTSConfig.SPEAKER_M01:
            tts_tone_config = self._speaker_m01
        else:
            raise ValueError('tts_tone is invalid')

        data = copy.deepcopy(tts_tone_config.body)
        data['text'] = text
        if tts_info.get('speed', None) is not None:
            if data.get('speed', None) is not None:
                data['speed'] = tts_info['speed']
            elif data.get('property', None) is not None and data['property'].get('speed', None) is not None:
                data['property']['speed'] = tts_info['speed']

        if tts_info.get('volume', None) is not None:
            if data.get('property', None) is not None and data['property'].get('volume', None) is not None:
                data['property']['volume'] = tts_info['volume']
        try:
            r = requests.post(tts_tone_config.url, headers=tts_tone_config.headers, data=json.dumps(data))
            res = json.loads(r.content)
            if res['code'] == 200:
                if isinstance(res['data'], dict) is True and res['data'].get('audio', None) is not None:
                    result = base64.b64decode(res['data']['audio'])
                else:
                    result = base64.b64decode(res['data'])
            else:
                raise errors.ResponseError(f'res:{json.dumps(res)}')
        except Exception as e:
            raise errors.WillRetryError(e)

        return result

    def _handle_integer(self, integer) -> list:
        """处理整数"""
        integer_len = len(integer)
        integer_list = list(integer)
        integer_list.reverse()  # 反转

        groups = []
        g_cnt = math.ceil(integer_len / 4)  # 每4位一组
        for i in range(g_cnt):
            start = i * 4
            if (i + 1) * 4 > integer_len:
                end = integer_len
            else:
                end = (i + 1) * 4
            groups.append(integer_list[start:end])

        results = []
        for index, group in enumerate(groups):
            count = 0
            result = []
            for number in group:
                if number != '0':
                    result.append(TTSConfig.unit_map[0][count])
                    result.append(TTSConfig.num_map[int(number)])
                    count += 1
                else:
                    if (not result) or (result[-1] is not '零'):  # 结果为空 or 前一位不为0时
                        result.append('零')
                    count += 1
            if result[0] == '零':  # 每组中最低位为0时
                if len(result) != 1:  # 本组中数字不全为0
                    result = ['零', TTSConfig.unit_map[1][index]] + result[1:]
            else:
                result = [TTSConfig.unit_map[1][index]] + result
            if results and results[-1] == '零' and result[0] == '零':  # 相邻的两位均为0时
                results.extend(result[1:])
            else:
                results.extend(result)
        results.reverse()

        return results

    def _handle_decimal(self, decimal) -> list:
        """处理小数"""
        res = []
        for i in decimal:
            res.append(TTSConfig.num_map[int(i)])

        return res

    def _number_to_str(self, number) -> str:
        """阿拉伯数字转中文"""
        assert isinstance(number, (float, int))
        # 处理小数
        if isinstance(number, float):
            integer, decimal = str(number).split('.')
            integer_list = self._handle_integer(integer)
            if integer_list[-1] == "零" and len(integer_list) is not 1:
                integer_list.pop()  # 去掉"一十零"这样整数的“零”
            integer_list = ['十'] if integer_list == ['一', '十'] else integer_list

            decimal_list = self._handle_decimal(decimal)
            if decimal_list == ['零']:  # 百分之一百点零变成百分之一百
                res = integer_list
            else:
                res = integer_list + ['点'] + decimal_list
        else:
            integer_list = self._handle_integer(str(number))
            if integer_list[-1] == "零" and len(integer_list) is not 1:
                integer_list.pop()  # 去掉"一十零"这样整数的“零”
            res = integer_list

        result = "".join(res).replace('二百', '两百').replace("二千", "两千")
        result = result.replace("一十", "十") if result.startswith("一十") else result
        result = result.replace("二万", "两万") if result.startswith("二万") else result
        return result

    def _replace(self, text) -> str:
        """ 字符串替换"""
        # 数字转为汉字
        results = re.findall(r'(\d*\.?\d+)(%|套|次|平|万|元|米|栋|贝壳币)', text)
        for (digit, unit) in results:
            digit_num = float(digit) if '.' in digit else int(digit)
            if unit == "%":
                chinese = "百分之" + self._number_to_str(digit_num)
            else:
                result = self._number_to_str(digit_num)
                result = "两" if result == "二" else result
                chinese = result + unit
            text = text.replace(digit + unit, chinese)
        # 电话号转为汉字
        results = re.findall('实际办公电话是([0-9-]+)', text)
        for phone in results:
            chinese_phone = phone.replace('-', '')
            for i in TTSConfig.num_map.keys():
                chinese = TTSConfig.num_map[i]
                i = str(i)
                chinese_phone = chinese_phone.replace(i, chinese)
            text = text.replace(phone, chinese_phone)
        return text

    def _special_op(self, text, tts_tone):
        """针对不同的音色进行文本特殊处理"""
        text = text.upper()
        if tts_tone == TTSConfig.TONE_sbc_jj:  # 思必驰-知性女声晶晶
            text = text \
                .replace('400', '四零零') \
                .replace('A+', 'A加') \
                .replace('AI', 'A爱') \
                .replace('APP', 'A批批') \
                .replace('CA', 'C诶') \
                .replace('IM', '挨挨姆') \
                .replace('LINK', '另科') \
                .replace('TOP', '套坡') \
                .replace('VR', 'V阿') \
                .replace('参与率', '参与律').replace('复看率', '复看律').replace('评价率', '评价律').replace('通过率', '通过律')
        elif tts_tone == TTSConfig.TONE_bb_jj:  # 标贝-静静
            text = text \
                .replace('A+', '欸加') \
                .replace('ACN', '欸C恩') \
                .replace('AI', '欸艾') \
                .replace('CA', 'C欸') \
                .replace('IM', '艾M') \
                .replace('LINK', '吝坷') \
                .replace('TOP', '套噗') \
                .replace('参与率', '参与律').replace('复看率', '复看律').replace('评价率', '评价律').replace('通过率', '通过律')
        elif tts_tone == TTSConfig.STANDARD_M01 or tts_tone == TTSConfig.STANDARD_M02 or tts_tone == TTSConfig.STANDARD_F01 or tts_tone == TTSConfig.STANDARD_F02 or tts_tone == TTSConfig.SPEAKER_M01:
            text = text \
                .replace('ACN', '欸C恩') \
                .replace('AI', '欸艾') \
                .replace('CA', 'C欸') \
                .replace('IM', '艾M') \
                .replace('LINK', '吝坷') \
                .replace('TOP', '套坡') \
                .replace('VR', 'V阿') \
                .replace('参与率', '参与律').replace('复看率', '复看律').replace('评价率', '评价律').replace('通过率', '通过律')
        else:  # （标贝-静静cc、标贝-天天、标贝-子衿cc）
            text = text \
                .replace('A+', '欸加') \
                .replace('ACN', '欸C恩') \
                .replace('AI', '欸艾') \
                .replace('CA', 'C欸') \
                .replace('IM', '艾M') \
                .replace('LINK', '吝坷') \
                .replace('TOP', '套噗') \
                .replace('参与率', '参与律').replace('复看率', '复看律').replace('评价率', '评价律').replace('通过率', '通过律')

        return text

    def _filter(self, text) -> str:
        """异常文本过滤(\r,\br,以及emoji)"""
        text = text.replace("\r", "")
        text = text.replace("\br", "")
        index_list = []
        for i, t in enumerate(text):
            if text_util.is_emoji(t):
                index_list.append(i)
        res = text
        for index in index_list:
            res = res.replace(text[index], '')
        return res

    def request_tts(self, mp3_path, text, tts_info):
        """
        获取音频信息

        Args:
            mp3_path (str): 音频路径
            text (str): 文本内容
            tts_info (dict): tts配置信息
        """
        chosen_logger = common_util.choose_logger()
        chosen_logger.debug(f'TTS Request | {mp3_path} | {text}')
        text = self._filter(text)
        text = self._replace(text)
        text = self._special_op(text, tts_info['tone'])  # 文本特殊处理
        content = self._tts_one(text, tts_info)
        return content
