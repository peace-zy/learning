# -*- coding: utf-8 -*-
# ===============================================================
#
#    Copyright (C) 2020 Beike, Inc. All Rights Reserved.
#
#    @Create Author : liweipeng007 (liweipeng007@ke.com)
#    @Create Time   : 2020/5/11 2:38 下午
#    @Description   : 日志模块
#                     api会通过gunicorn加载WebLogger来初始化
#                     非api需要主动调用init_logger来初始化
#
# ===============================================================


import fcntl
import json
import logging
import os
import os.path as osp
import re
import traceback
from logging.handlers import BaseRotatingHandler
from logging.handlers import TimedRotatingFileHandler

from gunicorn.glogging import Logger as GLogger

from living_space.voice_production.voice_config.gunicorn import accesslog,errorlog
from living_space.voice_production.voice_config.system import ENV_TYPE, PathConfig, POD_NAME
from living_space.voice_production.voice_utils import time_util

# 日志记录提效，不记录的字段无需计算
logging._srcfile = None
logging.logThreads = 0
logging.logMultiprocessing = 0

_app_logger = None
log_wrapper = None  # type: DoLoggingWrapper


class DoLoggingWrapper(object):
    """用于记录日志"""
    __slots__ = ('extra_info', 'is_api', 'request_path')  # 限制对象的属性绑定

    def __init__(self, extra_info, is_api=False, request_path=None):
        self.extra_info = extra_info
        self.is_api = is_api
        self.request_path = request_path

    def debug(self, log_message, **kwargs):
        self.do_logging(_app_logger.debug, log_message, extra=self.extra_info, **kwargs)

    def info(self, log_message, **kwargs):
        self.do_logging(_app_logger.info, log_message, extra=self.extra_info, **kwargs)

    def warning(self, log_message, **kwargs):
        self.do_logging(_app_logger.warning, log_message, extra=self.extra_info, **kwargs)

    def error(self, log_message, **kwargs):
        self.do_logging(_app_logger.error, log_message, extra=self.extra_info, **kwargs)

    def exception(self, log_message, **kwargs):
        kwargs['exc_info'] = traceback.format_exc()
        self.do_logging(_app_logger.error, log_message, extra=self.extra_info, **kwargs)

    def critical(self, log_message, **kwargs):
        self.do_logging(_app_logger.critical, log_message, extra=self.extra_info, **kwargs)

    def do_logging(self, log_level_func, log_message, extra=None, **kwargs):
        """
        打印日志内容，并可补充额外信息

        Args:
            log_level_func (function): 不同等级的日志输出函数
            log_message (str): 日志内容
            extra (dict): 固定信息记录字段
            **kwargs (): 需要额外补充的信息，key-value形式
        """
        msg_dict = {"message": log_message}
        if "message" in kwargs:
            kwargs.pop("message", None)
        if self.is_api:
            kwargs['request_path'] = self.request_path
        msg_dict.update(kwargs)  # kwargs会记录到日志的message中
        log_level_func(json.dumps(msg_dict, ensure_ascii=False), extra=extra)  # extra会成为新的字段


class CustomLoggerAdapter(logging.LoggerAdapter):
    """自定义的LoggerAdapter，主要用于处理extra参数"""

    def process(self, msg, kwargs):
        return_kwargs = {'extra': dict(self.extra)}
        if ("extra" in kwargs) and (kwargs["extra"] is not None):
            return_kwargs["extra"].update(kwargs["extra"])  # 在预设的额外字段基础上添加新的字段
        return msg, return_kwargs


def transform_logger(logger_name):
    """
    构造包含自定义字段的 Logger

    Args:
        logger_name (str): 日志记录器的名称

    Returns:
        logger (logging.LoggingAdapter)
    """
    extra = {
        "POD_NAME": POD_NAME,
        "ENV_TYPE": ENV_TYPE,
        'style': '-',
        "entity_id": "-",
        "uniq_id": "-",
        'para_index': '-',
        'template_code': '-'
    }
    logger = CustomLoggerAdapter(logging.getLogger(logger_name), extra)
    return logger


def init_logger():
    """项目日志记录器初始化"""
    base_app_logger = logging.getLogger("thor.video_platform")
    base_app_logger.setLevel(logging.DEBUG)

    # message中除了message外，还有可能含有time_type、time_cost、exc_info、request_path、error_code，在天眼解析时要增加
    formatter = logging.Formatter(
        "%(asctime)s\t%(levelname)s\t%(process)d\t%(name)s\t%(ENV_TYPE)s\t%(POD_NAME)s\t%(style)s\t%(entity_id)s\t%(uniq_id)s\t%(para_index)s\t%(template_code)s\t%(message)s")
    formatter.default_msec_format = "%s.%03d"

    filename = osp.join(PathConfig.MATRIX_APPLOGS_DIR, f'{ENV_TYPE}_{POD_NAME}_app.log')
    tr_file_hdlr = TimedRotatingFileHandler(filename, when="midnight", backupCount=15)  # 日志文件保留15天
    tr_file_hdlr.setFormatter(formatter)
    base_app_logger.addHandler(tr_file_hdlr)
    if ENV_TYPE == 'dev':
        str_hdlr = logging.StreamHandler()
        str_hdlr.setFormatter(formatter)
        base_app_logger.addHandler(str_hdlr)

    global _app_logger
    _app_logger = transform_logger("thor.video_platform")
    global log_wrapper
    extra_info = {'style': '-', 'entity_id': '-', 'uniq_id': '-', 'para_index': '-', 'template_code': '-'}
    log_wrapper = DoLoggingWrapper(extra_info)


class CustomTRFileHandler(BaseRotatingHandler):
    """
    自定义TimedRotatingFileHandler类，只支持按天进行日志切分

    特点：
        按天零点切分日志
        多进程安全
        只支持本地时间

    References:
        https://my.oschina.net/lionets/blog/796438
    """

    def __init__(self, filename, backupCount=0, encoding=None, delay=False):
        self.backupCount = backupCount  # todo: need test
        self.suffix = "%Y-%m-%d"
        self.extMatch = re.compile(r"^\d{4}-\d{2}-\d{2}(\.\w+)?$", re.ASCII)
        self.baseFilename = filename
        self.currentFileName = self._compute_fn()
        self._relink_file()
        BaseRotatingHandler.__init__(self, filename, 'a', encoding, delay)

    def shouldRollover(self, record):
        if self.currentFileName != self._compute_fn():
            return True
        return False

    def doRollover(self):
        if self.stream:
            self.stream.close()
            self.stream = None
        self.currentFileName = self._compute_fn()
        self._relink_file()
        if self.backupCount > 0:
            for s in self.getFilesToDelete():
                os.remove(s)

    def getFilesToDelete(self):
        """
        Determine the files to delete when rolling over.

        More specific than the earlier method, which just used glob.glob().
        """
        dirName, baseName = os.path.split(self.baseFilename)
        fileNames = os.listdir(dirName)
        result = []
        prefix = baseName + "."
        plen = len(prefix)
        for fileName in fileNames:
            if fileName[:plen] == prefix:
                suffix = fileName[plen:]
                if self.extMatch.match(suffix):
                    result.append(os.path.join(dirName, fileName))
        if len(result) < self.backupCount:
            result = []
        else:
            result.sort()
            result = result[:len(result) - self.backupCount]
        return result

    def _compute_fn(self):
        """
        获取最新日期的日志文件名称

        Returns:
            最新日期的日志文件名称
        """
        return f'{self.baseFilename}.{time_util.readable_timestamp(self.suffix)}'

    def _relink_exec(self):
        """执行更新软链操作"""
        if os.path.lexists(self.baseFilename):
            try:
                os.remove(self.baseFilename)
            except Exception:
                raise SystemError('remove error')
        try:
            os.symlink(os.path.basename(self.currentFileName), self.baseFilename)
        except Exception:
            raise SystemError('symlink error')

    def _relink_file(self):
        """将baseFilename指向最新的日志文件"""
        with open(f'{self.baseFilename}.lock', 'w') as fd_lock:
            fcntl.lockf(fd_lock, fcntl.LOCK_EX)
            if os.path.realpath(self.baseFilename) == os.path.realpath(self.currentFileName):
                return  # 如果软链已经更新则退出
            self._relink_exec()
            fcntl.lockf(fd_lock, fcntl.LOCK_UN)


class WebLogger(GLogger):

    def _add_custom_handler(self, logger, filename, formatter):
        """
        添加所需的handler

        Args:
            logger (logging.Logger): Logger
            filename (str): 日志路径
            formatter (logging.Formatter): 日志格式
        """
        tr_file_hdlr = CustomTRFileHandler(filename)
        tr_file_hdlr.setFormatter(formatter)
        logger.addHandler(tr_file_hdlr)
        if ENV_TYPE == 'dev':
            stream_hdlr = logging.StreamHandler()
            stream_hdlr.setFormatter(formatter)
            logger.addHandler(stream_hdlr)

    def setup(self, cfg):
        """
        修改gunicorn的logger

        Args:
            cfg (): gunicorn配置
        """
        super(WebLogger, self).setup(cfg)

        # 修改gunicorn.error的handler
        error_log_handlers = self.error_log.handlers
        for hdlr in error_log_handlers:
            self.error_log.removeHandler(hdlr)
        # message中除了message外，还有可能含有time_type、time_cost、exc_info、request_path、error_code，在天眼解析时要增加
        error_log_formatter = logging.Formatter(
            '%(asctime)s\t%(levelname)s\t%(process)d\t%(name)s\t%(ENV_TYPE)s\t%(POD_NAME)s\t%(style)s\t%(entity_id)s\t%(uniq_id)s\t%(para_index)s\t%(template_code)s\t%(message)s')
        error_log_formatter.default_msec_format = '%s.%03d'
        self._add_custom_handler(self.error_log, errorlog, error_log_formatter)
        self.error_log = transform_logger('gunicorn.error')
        global _app_logger
        _app_logger = self.error_log
        global log_wrapper
        extra_info = {'style': '-', 'entity_id': '-', 'uniq_id': '-', 'para_index': '-', 'template_code': '-'}
        log_wrapper = DoLoggingWrapper(extra_info)

        # 修改gunicorn.access的handler
        access_log_handlers = self.access_log.handlers
        for hdlr in access_log_handlers:
            self.access_log.removeHandler(hdlr)
        self._add_custom_handler(self.access_log, accesslog, logging.Formatter(self.access_fmt))
