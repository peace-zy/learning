# -*- coding: utf-8 -*-
import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import time
import boto3
import hashlib
import datetime
import os.path as osp

from living_space.voice_production.voice_config.general import TTSConfig
from living_space.voice_production.voice_config.system import PathConfig
from living_space.voice_production.voice_lib import log, tts
from living_space.voice_production.voice_lib.tts import TTSAPI

log.init_logger()
log.log_wrapper.info("init logger done")

public_s3 = {
    "BUCKET_NAME": "frame-dict",
    "ACCESS_KEY": "57X7TYUMZDH0ZAS6HJ9P",
    "SECERT_ACCESS_KEY": "5uxw2vNlEe7j7AAk7nOnMqBLf6/4ZVs1/YNTandr",
    "REGION_NAME": "cn-north-1",
    "ENDPOINT_URL": "http://storage.lianjia.com",
    "DOMAIN": "http://audio.ljcdn.com" # 用于音频
}


class S3(object):
    
    def __init__(self, config):
        self.access_key = config["ACCESS_KEY"]
        self.secret_access_key = config["SECERT_ACCESS_KEY"]
        self.region_name = config["REGION_NAME"]
        self.bucket_name = config["BUCKET_NAME"]
        self.endpoint_url = config["ENDPOINT_URL"]
        self.domain = config["DOMAIN"]
        try:
            self.session = boto3.session.Session(
                aws_access_key_id=self.access_key,
                aws_secret_access_key=self.secret_access_key,
                region_name=self.region_name
            )
            self.s3 = self.session.resource('s3', region_name=self.region_name, endpoint_url=self.endpoint_url)
            self.bucket = self.s3.Bucket(self.bucket_name)
        except Exception as e:
            print('s3 connect error. msg:%s' % (repr(e)))

    def upload_file(self, filename, data, is_sign):
        if self.bucket is None:
            return False
        try:
            self.bucket.put_object(Key=filename, Body=data)
            if is_sign:
                return self._get_url_sign(filename)
            else:
                return self._get_url(filename)
        except Exception as e:
            print('s3 upload file failure. msg:%s' % (repr(e)))
            return False

    def _get_url_sign(self, filename):
        if filename is None:
            return False
        domain = self.domain
        expire = 1800000
        path = '/%s/%s' % (self.bucket_name, filename)
        ak = self.access_key
        sk = self.secret_access_key
        ts = int(time.time())

        data = [('ak', ak), ('path', path), ('ts', ts), ('exp', expire)]
        data = sorted(data)

        verify = ''
        for (key,value) in data:
            verify = "%s%s=%s&" % (verify, key.strip(), value)
        verify = "%ssk=%s" % (verify, sk)
        sign = hashlib.md5(verify.encode('utf-8')).hexdigest()
        return '%s%s?ak=%s&exp=%s&ts=%s&sign=%s' % (domain, path, ak, expire, ts, sign)

    def _get_url(self, filename):
        if filename is None:
            return False
        domain = self.domain
        path = '/%s/%s' % (self.bucket_name, filename)
        return '%s%s' % (domain, path)


def s3_upload(config, filename, data, is_sign):
    s3 = S3(config)
    return s3.upload_file(filename, data, is_sign)


def text2voice(text, convert_url=False, name='test', tone=TTSConfig.TONE_bb_jj):
    now = datetime.datetime.now().strftime('%y%m%d-%H%M%S')

    current_dir = PathConfig.TEST_DIR
    input_dir = osp.join(current_dir, 'input')
    output_dir = osp.join(current_dir, 'output')

    output = osp.join(output_dir, f'{now}_tts.mp3')

    tts_info = {
        'tone': tone,
        'speed': 5.5
    }
    TTSAPI()._filter(text)
    TTSAPI()._replace(text)
    TTSAPI()._replace(text)
    voice_content = tts.TTSAPI().request_tts(output, text, tts_info)
    if convert_url:
        response = s3_upload(public_s3, '{}.mp3'.format(name), voice_content, False)
        return response
    return voice_content


if __name__ == '__main__':
    for _ in ['bb-nn', 'bb-jj', 'bb-jjcc', 'bb-tt', 'bb-ak', 'sbc-jj', 'STANDARD_M01' ,'STANDARD_M02', 'STANDARD_F01', 'STANDARD_F02', 'SPEAKER_M01']:
        res = text2voice('试试能不能把文本转语音接口部署到工程里面', convert_url=True, name=time.time(), tone=_)
        print(_, res)
        pass