# -*- coding: utf-8 -*-
# ===============================================================
#
#    Copyright (C) 2019 Beike, Inc. All Rights Reserved.
#
#    @Create Author : gaixindong (gaixindong@ke.com)
#    @Create Time   : 2020/1/9 18:51
#    @Description   : 
#
# ===============================================================


class Singleton(type):
    """单例模式"""
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]
