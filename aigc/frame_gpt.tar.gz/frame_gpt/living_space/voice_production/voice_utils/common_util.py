# -*- coding: utf-8 -*-
# ===============================================================
#
#    Copyright (C) 2020 Beike, Inc. All Rights Reserved.
#
#    @Create Author : liweipeng007 (liweipeng007@ke.com)
#    @Create Time   : 2020/5/11 2:41 下午
#    @Description   : 公共工具
#
# ===============================================================


import functools
import time
import traceback

import flask

from living_space.voice_production.voice_config.general import RetryConfig
from living_space.voice_production.voice_config.system import API_SERVICE, DEFAULT_SERVICE, PRODUCTION_SERVICE, SERVICE_NAME
from living_space.voice_production.voice_lib import errors, log


def retry(tries=RetryConfig.retry, delay=RetryConfig.sleep, exception=errors.WillRetryError):
    """
    函数重试装饰器

    Args:
        tries ():
        delay ():
        exception ():
    """

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kw):
            assert int(tries) > 0 and int(delay) > 0
            count = 0
            chosen_logger = choose_logger()
            while count < tries:
                try:
                    res = func(*args, **kw)
                    return res
                except exception as e:
                    count += 1
                    if count < tries:
                        chosen_logger.warning(f'Retry WARNING | <{func.__name__}> {count}-{tries} | {e}',
                                              exc_info=traceback.format_exc())
                    else:
                        chosen_logger.error(f'Retry ERROR | <{func.__name__}> {count}-{tries} | {e}',
                                            exc_info=traceback.format_exc())
                    time.sleep(delay)
            raise errors.RetryFailedError(f'<{func.__name__}> has failed {tries} times continuously!')
        return wrapper
    return decorator
# @formatter:on


def choose_logger() -> log.DoLoggingWrapper:
    """根据不同的服务选择对应的日志记录器"""
    if SERVICE_NAME == API_SERVICE:
        return flask.g.api_logger
    elif SERVICE_NAME in (PRODUCTION_SERVICE, DEFAULT_SERVICE):
        return log.log_wrapper
    else:
        log.log_wrapper.critical(f'SERVICE_NAME({SERVICE_NAME}) illegal')
        exit(1)
