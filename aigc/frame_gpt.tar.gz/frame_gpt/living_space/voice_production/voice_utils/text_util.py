# -*- coding: utf-8 -*-
# ===============================================================
#
#    Copyright (C) 2019 Beike, Inc. All Rights Reserved.
#
#    @Create Author : gaixindong (gaixindong@ke.com)
#    @Create Time   : 2020/11/26 下午10:37
#    @Description   : 文字处理工具
#
# ===============================================================


def is_emoji(text):
    """
    检测字符是否为emoji表情包

    Args:
        text (str): 一个字符

    Returns:
        是否为emoji
    """
    if not text:
        return False
    if u"\U0001F600" <= text and text <= u"\U0001F64F":
        return True
    elif u"\U0001F300" <= text and text <= u"\U0001F5FF":
        return True
    elif u"\U0001F680" <= text and text <= u"\U0001F6FF":
        return True
    elif u"\U0001F1E0" <= text and text <= u"\U0001F1FF":
        return True
    else:
        return False
