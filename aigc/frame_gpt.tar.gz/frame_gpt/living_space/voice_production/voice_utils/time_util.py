# -*- coding: utf-8 -*-
# ===============================================================
#
#    Copyright (C) 2020 Beike, Inc. All Rights Reserved.
#
#    @Create Author : liweipeng007 (liweipeng007@ke.com)
#    @Create Time   : 2020/5/11 2:41 下午
#    @Description   : 时间处理工具
#
# ===============================================================


import datetime
import time


def readable_timestamp(format="%y%m%d-%H%M%S-%f") -> str:
    """
    获取便于阅读的计算机本地时间戳

    Args:
        format (str): 便于阅读的时间格式

    Returns:
        返回指定格式的时间字符串。默认为 年月日-时分秒-微秒，每段各六位（年为后两位）
    """
    return datetime.datetime.now().strftime(format)  # 读取当前时间并格式化


def timestamp2format(timestamp, format="%Y-%m-%d %H:%M:%S") -> str:
    """
    将时间戳转换为指定格式的时间字符串

    Args:
        format (str): 转换的时间格式

    Returns:
        返回指定格式的时间字符串。默认格式为 2020-01-01 01:01:01
    """
    return datetime.datetime.fromtimestamp(timestamp).strftime(format)  # 转换为当地时间并格式化


def format2timestamp(date_str, format) -> float:
    """
    将时间字符串转换为时间戳

    Args:
        date_str (str): 时间字符串
        format (str): 时间字符串对应的格式

    Returns:
        返回时间戳
    """
    return datetime2timestamp(datetime.datetime.strptime(date_str, format))


def datetime2timestamp(datetime_struct) -> float:
    """
    将datetime时间元组转换成时间戳

    Args:
        datetime_struct: datetime结构的时间，形如datetime.datetime.now()

    Returns:
        返回时间戳
    """
    return time.mktime(datetime_struct.timetuple()) + datetime_struct.microsecond / 1E6


def time_diff(start, end=None, unit='ms', p=0) -> int or float:
    """
    计算两个时间戳之间的时间差

    Args:
        start (int or float): 起始时间
        end (int or float): 结束时间
        unit (str): 返回结果的单位
        p (int): 返回结果的小数点精度

    Returns:
        指定单位的时间差
    """
    if end is None:
        end = time.time()
    else:
        if not isinstance(end, (int, float)):
            raise TypeError('The type of end time must be int or float.')
    if not isinstance(start, (int, float)):
        raise TypeError('The type of start time must be int or float.')

    if not isinstance(p, int):
        raise TypeError('The type of p must be int.')
    if p < 0:
        raise ValueError('The value of p must be natural number.')

    if unit == 'ms':
        res = (end - start) * 1000
    elif unit == 's':
        res = end - start
    elif unit == 'us':
        res = (end - start) * 100000
    else:
        raise ValueError('The value of unit is invalid.')

    if p == 0:
        return int(res)
    else:
        return round(res, p)
