# -*- coding: utf-8 -*-
# ===============================================================
#
#    Copyright (C) 2020 Beike, Inc. All Rights Reserved.
#
#    @Create Author : liweipeng007 (liweipeng007@ke.com)
#    @Create Time   : 2020/5/11 12:03 下午
#    @Description   : 通用配置项
#
# ===============================================================


import os.path as osp
from collections import namedtuple

from ke_ffmpeg import codec

from living_space.voice_production.voice_config.system import ENV_TYPE, PathConfig


class VideoStyleConfig(object):
    """业务名称标识相关配置"""
    # 'video_type', 'video_style', 'style_version'
    ATV_10_v1 = 'atv_10_v1'  # 讲盘学习，贝壳经纪学院app训练场，PM王欢、RD赵卓；楼盘字典小区详情页，PM范芳芳、RD李云山
    ATV_20_v1 = 'atv_20_v1'  # 讲盘学习，北京链家链识界，孙孟洋
    ATV_30_v1 = 'atv_30_v1'  # 讲盘学习，2.0版本，上线场景未知
    RFV_10_v1 = 'rfv_10_v1'  # 小区户型解读，看点场景，导购分发，RD傅发佐
    RFV_20_v1 = 'rfv_20_v1'  # 小区户型解读，无logo投放快手，导购分发，RD傅发佐
    LJV_10_v1 = 'ljv_10_v1'  # 视频剪辑工具，灵镜，视频生产，PM李佳
    LJA_10_v1 = 'lja_10_v1'  # 视频剪辑工具，灵镜，音频生产，FE闫士博、RD钱力、PM李佳
    LJTV_10_v1 = 'ljtv_10_v1'  # 视频格式转化工具，灵镜，视频生产，FE闫士博、RD钱力、PM李佳
    LJTV_11_v1 = 'ljtv_11_v1'  # 视频剪切工具，灵镜，视频生产，FE闫士博、RD钱力、PM李佳
    LJTV_12_v1 = 'ljtv_12_v1'  # 视频裁剪工具，灵镜，视频生产，FE闫士博、RD钱力、PM李佳
    LJTV_13_v1 = 'ljtv_13_v1'  # 视频合并工具，灵镜，视频生产，FE闫士博、RD钱力、PM李佳
    LJTV_14_v1 = 'ljtv_14_v1'  # 视频提取音频工具，灵镜，视频生产，FE闫士博、RD钱力、PM李佳
    LJTV_15_v1 = 'ljtv_15_v1'  # 视频转gif工具，灵镜，视频生产，FE闫士博、RD钱力、PM李佳
    LJTV_16_v1 = 'ljtv_16_v1'  # 视频同一格式合并工具，灵镜，视频生产，FE闫士博、RD钱力、PM李佳
    LJTV_17_v1 = 'ljtv_17_v1'  # 录屏工具，灵镜，视频生产，FE闫士博、RD钱力、PM李佳
    NHIV_10_v1 = 'nhiv_10_v1'  # 新房讲盘视频，C端新盘详情页头图位，PM方方、PO曹然然、RD杨勤川
    RMQWV_10_v1 = 'rmqwv_10_v1'  # 行情播报视频（小区），C端小区详情页，PM葛唱，RD余志斌
    BPV_10_v1 = 'bpv_10_v1'  # 批处理，房屋检测视频，C端房源详情页，PM葛唱，RD张一帆
    ALL = [
        ATV_10_v1, ATV_20_v1, ATV_30_v1,
        RFV_10_v1, RFV_20_v1,
        LJV_10_v1, LJA_10_v1, LJTV_10_v1, LJTV_11_v1, LJTV_12_v1, LJTV_13_v1, LJTV_14_v1, LJTV_15_v1, LJTV_16_v1, LJTV_17_v1,
        NHIV_10_v1,
        RMQWV_10_v1,
        BPV_10_v1
    ]
    convert = {
        'agent_training_videos': 'atv',
        'resblock_frame_videos': 'rfv',
        'new_house_introduction_video': 'nhiv',
        'resblock_market_quotation_weekly_video': 'rmqwv',
        'batch_processing_video': 'bpv'
    }
    full2short = {
        'agent_training_videos': 'atv',
        'resblock_frame_videos': 'rfv',
        'new_house_introduction_video': 'nhiv',
        'resblock_market_quotation_weekly_video': 'rmqwv',
        'batch_processing_video': 'bpv'
    }
    short2full = {
        'atv': 'agent_training_videos',
        'rfv': 'resblock_frame_videos',
        'ljv': 'lingjing_video',
        'lja': 'lingjing_audio',
        'ljtv': 'lingjing_video_tool',
        'nhiv': 'new_house_introduction_video',
        'rmqwv': 'resblock_market_quotation_weekly_video',
        'bpv': 'batch_processing_video'
    }
    full2chinese = {
        'agent_training_videos': '讲盘学习视频',
        'resblock_frame_videos': '小区户型解读视频',
        'lingjing_video': '灵镜视频',
        'lingjing_audio': '灵镜音频',
        'lingjing_video_tool': '灵镜视频处理工具',
        'new_house_introduction_video': '新房讲盘视频',
        'resblock_market_quotation_weekly_video': '小区行情播报视频',
        'batch_processing_video': '批处理视频'
    }


class LogoConfig(object):
    """Logo相关配置"""
    bk_blue_icon = osp.join(PathConfig.DATA_LOGO_DIR, 'bk_blue_icon@1x.png')
    bk_horizontal_blue = osp.join(
        PathConfig.DATA_LOGO_DIR, 'bk_horizontal_blue@1x.png')
    bk_horizontal_white = osp.join(
        PathConfig.DATA_LOGO_DIR, 'bk_horizontal_white@1x.png')
    bk_vertical_blue = osp.join(
        PathConfig.DATA_LOGO_DIR, 'bk_vertical_blue@2x.png')
    bk_vertical_blue_no_subtitle = osp.join(
        PathConfig.DATA_LOGO_DIR, 'bk_vertical_blue.png')
    homelink = osp.join(PathConfig.DATA_LOGO_DIR, 'homelink_green.png')
    ALL_LOGO = [
        bk_blue_icon,
        bk_horizontal_blue, bk_horizontal_white, bk_vertical_blue, bk_vertical_blue_no_subtitle,
        homelink
    ]


class BGMConfig(object):
    """BGM相关配置"""
    a_long_cold = osp.join(PathConfig.DATA_BGM_DIR, 'a_long_cold.mp3')
    barton_springs = osp.join(PathConfig.DATA_BGM_DIR, 'barton_springs.mp3')
    blue_skies = osp.join(PathConfig.DATA_BGM_DIR, 'barton_springs.mp3')
    coffee_stains = osp.join(PathConfig.DATA_BGM_DIR, 'coffee_stains.mp3')
    get_outside = osp.join(PathConfig.DATA_BGM_DIR, 'get_outside.mp3')
    how_it_began = osp.join(PathConfig.DATA_BGM_DIR, 'how_it_began.mp3')
    on_hold = osp.join(PathConfig.DATA_BGM_DIR, 'on_hold.mp3')
    pas_de_deux = osp.join(PathConfig.DATA_BGM_DIR, 'pas_de_deux.mp3')
    payday = osp.join(PathConfig.DATA_BGM_DIR, 'payday.mp3')
    sound_off = osp.join(PathConfig.DATA_BGM_DIR, 'sound_off.mp3')
    spring_in_my_step = osp.join(
        PathConfig.DATA_BGM_DIR, 'spring_in_my_step.mp3')
    you_re_no_help = osp.join(PathConfig.DATA_BGM_DIR, 'you_re_no_help.mp3')
    ALL_BGM = [
        a_long_cold, barton_springs, blue_skies, coffee_stains, get_outside, how_it_began,
        on_hold, pas_de_deux, payday, sound_off, spring_in_my_step, you_re_no_help
    ]


class XiaoBeiConfig(object):
    """小贝形象相关配置"""
    consultant_gif = osp.join(PathConfig.DATA_XIAOBEI_DIR, 'consultant.gif')
    instructor_gif = osp.join(PathConfig.DATA_XIAOBEI_DIR, 'instructor.gif')
    normal = osp.join(PathConfig.DATA_XIAOBEI_DIR, 'normal.png')
    instructor = osp.join(PathConfig.DATA_XIAOBEI_DIR, 'instructor.png')


class TTSConfig(object):
    """TTS语音生产相关配置"""
    TONE_bb_nn = 'bb-nn'  # 标贝-楠楠
    TONE_bb_jj = 'bb-jj'  # 标贝-静静
    TONE_bb_jjcc = 'bb-jjcc'  # 标贝-静静cc
    TONE_bb_tt = 'bb-tt'  # 标贝-天天
    TONE_bb_zjcc = 'bb-zjcc'  # 标贝-子衿cc
    TONE_bb_ak = 'bb-ak'  # 标贝-阿科
    TONE_bb_xj = 'bb-xj'  # 标贝-小金
    TONE_bb_xjcc = 'bb-xjcc'  # 标贝-小金cc
    TONE_sbc_jj = 'sbc-jj'  # 思必驰-知性女声晶晶
    # 新版
    STANDARD_M01 = 'STANDARD_M01'  # 标准男声_01 (贝壳自建.小海管家.任老师)
    STANDARD_M02 = 'STANDARD_M02'  # 标准男声_02 (标贝MDB2)
    STANDARD_F01 = 'STANDARD_F01'  # 标准女声_01 (海天King003)
    STANDARD_F02 = 'STANDARD_F02'  # 标准女声_02 (海天King042)
    SPEAKER_M01 = 'SPEAKER_M01'  # 演讲男声_01 (问问M001)

    max_task_count = 5  # 正在处理的tts任务最大数量
    qps_control_interval = 1  # 1s

    Sk = 'lingjing-open-video-api'  # 新版本请求加密配置
    # 新版本请求加密配置, md5('lingjing-open-video-api-thor-video-platform')
    Traceid = '1DE3F1B73401DF8F8344EEE8E3637A73'

    # 单位
    unit_map = [["", "十", "百", "千"],
                ["", "万", "亿", "兆"]]

    # 数字
    num_map = {0: "零", 1: "一", 2: "二", 3: "三", 4: "四",
               5: "五", 6: "六", 7: "七", 8: "八", 9: "九"}


class Audio2TextConfig(object):
    """语音转文字生产相关配置"""
    base_url = "http://10.200.20.242:38880/api/speech/platform/cangjie/house/detect"
    headers = {"Content-Type": "application/json"}
    applicationId = "test"  # 申请接入的唯一标识
    sampleRate = 16000  # 采样率
    audioSource = "url"  # 音频来源
    channel = 1


class CallbackHostConfig(object):
    """生产完毕后的本服务回调host配置"""
    __url = {
        'online': 'http://i.thor-business-script.serving.ljnode.com:9047',
        'test': 'http://thor-video-platform.test-lingjing-open-video-api.ttb.test.ke.com',
        'dev': 'http://0.0.0.0:17890'
    }
    url = __url[ENV_TYPE]


class MultimediaDomainConfig(object):
    """多媒体域名相关配置"""
    file_in = 'http://file.media.lianjia.com/'
    file_out = 'https://file.ljcdn.com/'
    audio_in = 'http://audio.media.lianjia.com/'
    audio_out = 'https://audio.ljcdn.com/'
    video_in = 'http://video.media.lianjia.com/'
    video_out = 'https://video.ljcdn.com/'
    image_host = 'https://p.ljcdn.com/'


class ProgressConfig(object):
    """生产状态相关配置"""
    default = 199  # 默认值
    failed = 198  # 生产失败
    deleted = 197  # 已删除
    done = 100  # 生产完成
    start = 0  # 生产开始


class SQLStatementConfig(object):
    """SQL语句"""
    status_valid = 1
    status_custom_invalid = 0
    status_lj_deleted = 2

    # 使用生产id查询视频
    select_id = "SELECT prod_id, dim_id, geography_dim, city_code, " \
                "video_url, video_md5, duration, style, cover_list, ext_info, stat_time, video_type, video_topic, " \
                "create_time, update_time, status " \
                "FROM video_product_content WHERE prod_id = %s;"
    # 使用视频维度id查询视频
    select_dim = "SELECT prod_id, dim_id, geography_dim, city_code, " \
                 "video_url, video_md5, duration, style, cover_list, ext_info, stat_time, video_type, video_topic, " \
                 "create_time, update_time, status " \
                 "FROM video_product_content WHERE dim_id = %s AND geography_dim = %s AND style = %s AND status = 1;"
    # 使用视频维度id查询视频（多个）
    select_dim_multi = "SELECT prod_id, dim_id, geography_dim, city_code, " \
                       "video_url, video_md5, duration, style, cover_list, ext_info, stat_time, video_type, video_topic, " \
                       "create_time, update_time, status " \
                       "FROM video_product_content WHERE dim_id in (%s) AND geography_dim = %s AND style = %s AND status = 1;"
    # 使用视频维度id配合统计时间查询视频
    select_dim_stat = "SELECT prod_id, dim_id, geography_dim, city_code, " \
                      "video_url, video_md5, duration, style, cover_list, ext_info, stat_time, video_type, video_topic, " \
                      "create_time, update_time, status " \
                      "FROM video_product_content WHERE dim_id = %s AND geography_dim = %s AND style = %s AND status = 1 AND stat_time = %s;"

    # 使用动效类型查询动效
    select_effect = "SELECT material_id, material_name, material_type, material_url, description, ext_info, " \
                    "create_time, update_time, status " \
                    f"FROM video_product_basic_material WHERE material_type = %s AND status = {status_valid};"
    # 使用模板名称模糊查询和分页查询模板
    select_template_list = "SELECT material_id, material_name, material_type, material_url, description, ext_info, " \
                           "create_time, update_time, status, " \
                           "( SELECT COUNT( material_id ) FROM video_product_basic_material WHERE material_type = 'video_template' ) AS template_cnt " \
                           f"FROM video_product_basic_material WHERE material_type = 'video_template' AND status = {status_valid} AND material_name LIKE %s LIMIT %s, %s;"
    # 使用模板id查询模板预设数据
    select_template_detail = "SELECT material_id, material_name, material_type, material_url, description, ext_info, " \
                             "create_time, update_time, status " \
                             f"FROM video_product_basic_material WHERE material_type = 'video_template' AND status = {status_valid} AND material_id = %s;"

    # 插入生产状态
    insert_progress = "INSERT INTO video_product_progress " \
                      "(prod_id, dim_id, style, progress, create_time, update_time) " \
                      "VALUE (%s, %s, %s, %s, %s, %s);"
    # 查询灵镜生产状态
    select_lj_progress = "SELECT prod_id, dim_id, style, progress, create_time, update_time " \
                         "FROM video_product_progress WHERE dim_id = %s AND style IN ('ljv_10_v1', 'lja_10_v1');"
    # 更新生产状态
    update_progress = "UPDATE video_product_progress SET update_time = %s, progress = %s WHERE prod_id = %s;"
    # 使用生产id更新数据
    delete_production = f"UPDATE video_product_content SET status = {status_lj_deleted}, update_time = %s, video_url = %s " \
                        "WHERE prod_id = %s;"

    product_content_formatter = '{prod_id}\t{dim_id}\t{geography_dim}\t{city_code}\t' \
                                '{video_url}\t{video_md5}\t{duration}\t{style}\t{cover_list}\t{ext_info}\t{stat_time}\t{video_type}\t{video_topic}\t' \
                                '{create_time}\t{update_time}\t{status}'
    # 插入结果数据
    insert_one = "INSERT INTO video_product_content " \
                 "(prod_id, dim_id, geography_dim, city_code, " \
                 "video_url, video_md5, duration, style, cover_list, ext_info, stat_time, video_type, video_topic, " \
                 "create_time, update_time, status) " \
                 "VALUE (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);"
    # 更新结果数据
    update_data = f"UPDATE video_product_content SET status = {status_custom_invalid}, update_time = %s " \
                  f"WHERE dim_id = %s AND geography_dim = %s AND style = %s AND status = {status_valid} AND stat_time = %s;"

    # 查询生产状态
    select_progress = "SELECT prod_id, dim_id, style, progress, create_time, update_time " \
                      "FROM video_product_progress WHERE prod_id = %s;"

    # 查询时间段内生成视频数量
    select_count_by_create_time = "SELECT COUNT(id) as total, style FROM video_product_content WHERE create_time BETWEEN %s AND %s GROUP BY style;"


class RecoderConfig(object):
    """录屏相关的配置项"""
    OFFSET_X = 10  # 录屏窗口水平偏移像素
    OFFSET_Y = 10  # 录屏窗口垂直偏移像素
    COLORDEPTH = 24  # 颜色深度
    LOAD_TIMEOUT = 15  # 页面加载时长，单位：s
    WAIT_TIMEOUT = 1  # 录屏前强制等待时长，单位：s
    PAGE_ZOOM = 0.8  # 页面缩放比例


class CheckConfig(object):
    level1_key = {
        'entity_id', 'uniq_id', 'index', 'timestamp', 'para_count',
        'transition_info', 'style_info', 'script', 'biz_info'
    }
    style_key = {'video_style', 'guarantee_info', 'video_info',
                 'logo_info', 'bgm_info', 'srt_info', 'tts_info'}
    script_key = {
        'template_code', 'para_name', 'para_cname',
        'head_idle', 'tail_idle', 'subtitle', 'vision', 'biz_vision'
    }
    biz_key = {'ext_info', 'city_code', 'geography_dim', 'stat_time'}


class Image2VideoConfig(object):
    image_factor = 1.2  # 图片放大系数
    gl_duration = 0.5  # 0.5s


class FFmpegConfig(object):
    LOGLEVEL = 'warning'  # FFmpeg日志输出级别
    THREAD_NUMS = 2  # FFmpeg处理线程数

    VIDEO_SUPPORT_FORMAT = ['mov', 'MOV', 'mp4', 'MP4',
                            'avi', 'AVI', 'wmv', 'WMV', 'flv', 'FLV', 'm3u8']
    VIDEO_ENCODE_CUDA = 'h264_nvenc'
    VIDEO_ENCODE = codec.ENCODER_H264
    VIDEO_DECODE_CUDA = 'h264_cuvid'
    VIDEO_DECODE = codec.DECODER_H264
    AUDIO_ENCODE = codec.ENCODER_AAC

    CUDA_ACC = '-hwaccel_output_format cuda'

    BITRATE = '10240k'
    BUFSIZE = '10240k'
    AUDIO_SAMPLING_FREQUENCY = '48000'
    PIX_FORMAT = 'yuv420p'
    MOV_FLAGS = 'faststart'

    box_info_check_list = {'x', 'y', 'w', 'h', 'color', 'thickness'}
    text_info_check_list = {'text', 'x', 'y',
                            'font_file', 'font_size', 'font_color'}
    material_info_check_list = {'material', 'w', 'h', 'x', 'y'}


class TransitionConfig(object):
    """转场文件相关配置"""
    transition_path = {
        '5101001': osp.join(PathConfig.DATA_TRANSITION_DIR, '5101001-cube.glsl'),
        '5101002': osp.join(PathConfig.DATA_TRANSITION_DIR, '5101002-fade.glsl'),
        '5101003': osp.join(PathConfig.DATA_TRANSITION_DIR, '5101003-wipe_down.glsl'),
        '5101004': osp.join(PathConfig.DATA_TRANSITION_DIR, '5101004-wipe_up.glsl'),
        '5101005': osp.join(PathConfig.DATA_TRANSITION_DIR, '5101005-wipe_right.glsl'),
        '5101006': osp.join(PathConfig.DATA_TRANSITION_DIR, '5101006-wipe_left.glsl'),
        '5101007': osp.join(PathConfig.DATA_TRANSITION_DIR, '5101007-fadecolor.glsl'),
        '5101008': osp.join(PathConfig.DATA_TRANSITION_DIR, '5101008-directional_wipe.glsl'),
        '5101009': osp.join(PathConfig.DATA_TRANSITION_DIR, '5101009-inverted_page_curl.glsl'),
        '5101010': osp.join(PathConfig.DATA_TRANSITION_DIR, '5101010-swap.glsl'),
        '5101011': osp.join(PathConfig.DATA_TRANSITION_DIR, '5101011-circle_crop.glsl'),
        '5101012': osp.join(PathConfig.DATA_TRANSITION_DIR, '5101012-radial.glsl'),
        '5101013': osp.join(PathConfig.DATA_TRANSITION_DIR, '5101013-simple_zoom.glsl'),
        '5101014': osp.join(PathConfig.DATA_TRANSITION_DIR, '5101014-linear_blur.glsl'),
        '5101015': osp.join(PathConfig.DATA_TRANSITION_DIR, '5101015-heart.glsl'),
        '5101016': osp.join(PathConfig.DATA_TRANSITION_DIR, '5101016-grid_flip.glsl')
    }


class DispatchConfig(object):
    """生产任务调度相关配置"""
    sleep_interval = 0.1  # 100ms


class RetryConfig(object):
    """重试"""
    retry = 5
    sleep = 1  # s


class MapConfig(object):
    """地图相关的配置项"""

    map_urls = {
        'general': 'http://api.map.baidu.com/api?v=3.0',
        'webgl': 'http://api.map.baidu.com/api?type=webgl&v=2.0'
    }

    css = osp.join(PathConfig.DATA_WEB_DIR, 'baidu_map.css')
    jquery_js = osp.join(PathConfig.DATA_WEB_DIR, 'jquery-3.4.1.min.js')

    # 录屏式相关模板的配置项
    MapTuple = namedtuple(typename='MapTuple', field_names=(
        'map_url', 'js_file', 'icon_file'))

    api_urls = {
        "online": 'http://i.thor-business-script.serving.ljnode.com:9047/api/arrangement/poi_label',
        "test": 'http://i.test-thor-business-script.serving.ljnode.com:9058/api/arrangement/poi_label',
        "dev": 'http://10.26.32.3:34592/api/arrangement/poi_label'
    }

    center_icon = osp.join(PathConfig.DATA_WEB_DIR, 'center.png')
    general_icon = osp.join(PathConfig.DATA_WEB_DIR, 'general.png')
    traffic_icon = osp.join(PathConfig.DATA_WEB_DIR, 'traffic.png')
    education_icon = osp.join(PathConfig.DATA_WEB_DIR, 'education.png')
    medical_icon = osp.join(PathConfig.DATA_WEB_DIR, 'medical.png')
    shopping_icon = osp.join(PathConfig.DATA_WEB_DIR, 'shopping.png')
    pedestrian_icon = osp.join(PathConfig.DATA_WEB_DIR, 'pedestrian.png')

    general_js = osp.join(PathConfig.DATA_WEB_DIR, 'general.js')
    zoom_js = osp.join(PathConfig.DATA_WEB_DIR, 'zoom.js')
    static_js = osp.join(PathConfig.DATA_WEB_DIR, 'static.js')
    dynamic_js = osp.join(PathConfig.DATA_WEB_DIR, 'dynamic.js')

    pages = {
        'position': MapTuple(map_urls['webgl'], zoom_js, general_icon),
        'traffic': MapTuple(map_urls['general'], general_js, traffic_icon),
        'traffic_static': MapTuple(map_urls['general'], static_js, traffic_icon),
        'traffic_dynamic': MapTuple(map_urls['general'], dynamic_js, traffic_icon),
        'shopping': MapTuple(map_urls['general'], general_js, shopping_icon),
        'medical': MapTuple(map_urls['general'], general_js, medical_icon),
        'education': MapTuple(map_urls['general'], general_js, education_icon),
        'general': MapTuple(map_urls['general'], general_js, general_icon)
    }

    html_str = f'<!DOCTYPE html>' \
               f'<html lang="zh-cn">' \
               f'<head>' \
               f'<meta charset="UTF-8">' \
               f'<link rel="stylesheet" type="text/css" href="{css}">' \
               f'</head>' \
               '<script type="text/javascript" src="{map_url}&ak=xmdoecrWaGarTEeROLW21cFKeLyKQbUI">' \
               f'</script>' \
               f'<script type="text/javascript" src="{jquery_js}"></script>' \
               f'<body>' \
               f'<div id="BaiduMap"></div>' \
               f'</body>' \
               '<script type="text/javascript" src="{data_file}"></script>' \
               '<script type="text/javascript" src="{js_file}"></script>' \
               f'</html>'

    # 截屏式相关模板的配置项
    poi_mid_light = osp.join(PathConfig.DATA_MAP_DIR, 'poi_mid_light.png')
    poi_left_light = osp.join(PathConfig.DATA_MAP_DIR, 'poi_left_light.png')
    poi_right_light = osp.join(PathConfig.DATA_MAP_DIR, 'poi_right_light.png')
    poi_mid_dark = osp.join(PathConfig.DATA_MAP_DIR, 'poi_mid_dark.png')
    poi_left_dark = osp.join(PathConfig.DATA_MAP_DIR, 'poi_left_dark.png')
    poi_right_dark = osp.join(PathConfig.DATA_MAP_DIR, 'poi_right_dark.png')
    poi_size_info = {
        'height': 96,
    }

    title_bg_size_info = {
        'height': 184,
    }

    center_arrow = osp.join(PathConfig.DATA_MAP_DIR, 'center_poi_arrow.png')
    center_mid = osp.join(PathConfig.DATA_MAP_DIR, 'center_poi_mid.png')
    center_left = osp.join(PathConfig.DATA_MAP_DIR, 'center_poi_left.png')
    center_right = osp.join(PathConfig.DATA_MAP_DIR, 'center_poi_right.png')
    center_flag = osp.join(PathConfig.DATA_MAP_DIR, 'center_poi_flag.png')
    center_dot = osp.join(PathConfig.DATA_MAP_DIR, 'center_dot.mov')
    center_size_info = {
        'height': 162,
        'visible_height': 101, 'above_height': 34, 'below_height': 27,
        'arrow_width': 24,
    }

    # 北京地铁线路颜色
    pk_subway_color = {
        "地铁1号线": "#C23A30",
        "地铁2号线": "#006098",
        "地铁4号线大兴线": "#008E9C",
        "地铁5号线": "#A6217F",
        "地铁6号线": "#D29700",
        "地铁7号线": "#f6c582",
        "地铁8号线": "#009B6B",
        "地铁8号线南段": "#009B6B",
        "地铁9号线": "#8FC31F",
        "地铁10号线": "#009BC0",
        "地铁13号线": "#FFC540",
        "地铁14号线": "#D5A7A1",
        "地铁14号线西段": "#D5A7A1",
        "地铁14号线东段": "#D5A7A1",
        "地铁15号线": "#5B2C68",
        "地铁16号线": "#76A32E",
        "地铁八通线": "#C23A30",
        "地铁房山线": "#E46022",
        "地铁昌平线": "#DE82B2",
        "地铁亦庄线": "#E40077",
        "地铁燕房线": "#E46022",
        "地铁S1线": "#B35A20",
        "地铁西郊线": "#E50619",
        "首都机场线": "#A29BBB",
        "大兴机场线": "#004A9F"
    }

    subway_flag = osp.join(PathConfig.DATA_MAP_DIR, 'subway_poi_flag.png')
    subway_left = osp.join(PathConfig.DATA_MAP_DIR, 'subway_poi_left.svg')
    subway_mid = osp.join(PathConfig.DATA_MAP_DIR, 'subway_poi_mid.svg')
    subway_right = osp.join(PathConfig.DATA_MAP_DIR, 'subway_poi_right.svg')

    subway_transfer_flag = osp.join(
        PathConfig.DATA_MAP_DIR, 'subway_transfer_flag.png')
    subway_transfer_left = osp.join(
        PathConfig.DATA_MAP_DIR, 'subway_transfer_left.png')
    subway_transfer_mid = osp.join(
        PathConfig.DATA_MAP_DIR, 'subway_transfer_mid.png')
    subway_transfer_right = osp.join(
        PathConfig.DATA_MAP_DIR, 'subway_transfer_right.png')
    subway_transfer_circle = osp.join(
        PathConfig.DATA_MAP_DIR, 'subway_transfer_circle.svg')

    meal_icon = osp.join(PathConfig.DATA_MAP_DIR, 'poi_meal.png')
    school_icon = osp.join(PathConfig.DATA_MAP_DIR, 'poi_school.png')
    shop_icon = osp.join(PathConfig.DATA_MAP_DIR, 'poi_shop.png')
    bus_icon = osp.join(PathConfig.DATA_MAP_DIR, 'poi_bus.png')
    hospital_icon = osp.join(PathConfig.DATA_MAP_DIR, 'poi_hospital.png')
    park_icon = osp.join(PathConfig.DATA_MAP_DIR, 'poi_park.png')
    highway_icon = osp.join(PathConfig.DATA_MAP_DIR, 'poi_highway.png')
    police_icon = osp.join(PathConfig.DATA_MAP_DIR, 'poi_police.png')
    bank_icon = osp.join(PathConfig.DATA_MAP_DIR, 'poi_bank.png')
    disgust_facility_icon = osp.join(
        PathConfig.DATA_MAP_DIR, 'poi_disgust_facility.png')
    lj_icon = osp.join(PathConfig.DATA_MAP_DIR, 'poi_lj.png')
    kindergarten_icon = osp.join(
        PathConfig.DATA_MAP_DIR, 'poi_kindergarten.png')
    # 普通截图
    html_template = '<!DOCTYPE html' \
                    '><html lang="zh-cn"><head>' \
                    '<meta charset="UTF-8">' \
                    f'<link rel="stylesheet" type="text/css" href="{css}">' \
                    f'</head><script type="text/javascript" src="{map_urls["general"]}&ak=xmdoecrWaGarTEeROLW21cFKeLyKQbUI">' \
                    '</script>' \
                    f'<script type="text/javascript" src="{jquery_js}"></script>' \
                    '<body>' \
                    '<div id="BaiduMap"></div>' \
                    '<script type="text/javascript">' \
                    'let BMap = window.BMap;' \
                    'let center_point = new BMap.Point({lng}, {lat});' \
                    'let map = new BMap.Map("BaiduMap");' \
                    'var ps = [];' \
                    'var t = 0;' \
                    'map.addEventListener("load", function(){{' \
                    '   ps.push(new Promise((resolve, reject) => {{' \
                    '       map.addEventListener("tilesloaded",function(){{' \
                    '           t += 1;' \
                    '           if(t=={trigger}){{' \
                    '               resolve("bb");' \
                    '           }}' \
                    '       }});' \
                    '   }}));' \
                    '}});' \
                    'map.clearOverlays();' \
                    'map.centerAndZoom(center_point, {zoom});' \
                    'map.enableScrollWheelZoom(true);' \
                    '{set_style}' \
                    'async function title(){{' \
                    '   await Promise.all(ps);' \
                    '   document.title="loaded";' \
                    '}}' \
                    'title();' \
                    '</script>' \
                    '</script>' \
                    '</body>' \
                    '</html>'
    # 公交线路展示
    html_template1 = '<!DOCTYPE html' \
                     '><html lang="zh-cn"><head>' \
                     '<meta charset="UTF-8">' \
                     f'<link rel="stylesheet" type="text/css" href="{css}">' \
                     f'</head><script type="text/javascript" src="{map_urls["general"]}&ak=xmdoecrWaGarTEeROLW21cFKeLyKQbUI">' \
                     '</script>' \
                     f'<script type="text/javascript" src="{jquery_js}"></script>' \
                     '<body>' \
                     '<div id="BaiduMap"></div>' \
                     '<script>' \
                     'var map = new BMap.Map("BaiduMap"); ' \
                     'var center_point = new BMap.Point({lng}, {lat});' \
                     'var zoom={zoom};' \
                     'map.centerAndZoom(center_point, zoom);' \
                     'map.setMapStyle({{style: "googlelite"}});' \
                     'var busline = new BMap.BusLineSearch(map,{{renderOptions: {{map: map,autoViewport:false}},' \
                     'onGetBusLineComplete: function(){{' \
                     'map.addEventListener("tilesloaded",function (event){{' \
                     'document.title="loaded";' \
                     '}});' \
                     'map.centerAndZoom(center_point, zoom);}},' \
                     'onGetBusListComplete: function(result){{if(result){{var fstLine = result.getBusListItem(0);' \
                     'if (typeof(fstLine) == "undefined"){{' \
                     'map.addEventListener("tilesloaded",function (event){{' \
                     'document.title="loaded";' \
                     '}});' \
                     'map.centerAndZoom(center_point, zoom);}}' \
                     'else {{busline.getBusLine(fstLine);}}}}}}}});' \
                     'busline.getBusList({bus_name});' \
                     '</script>' \
                     '</body>' \
                     '</html>'
    # 寻路
    html_template2 = '<!DOCTYPE html' \
                     '><html lang="zh-cn"><head>' \
                     '<meta charset="UTF-8">' \
                     f'<link rel="stylesheet" type="text/css" href="{css}">' \
                     f'</head><script type="text/javascript" src="{map_urls["general"]}&ak=xmdoecrWaGarTEeROLW21cFKeLyKQbUI">' \
                     '</script>' \
                     f'<script type="text/javascript" src="{jquery_js}"></script>' \
                     '<body>' \
                     '<div id="BaiduMap"></div>' \
                     '<script>' \
                     'var map = new BMap.Map("BaiduMap"); ' \
                     'var myP1 = new BMap.Point({lng1}, {lat1});' \
                     'var myP2 = new BMap.Point({lng2}, {lat2});' \
                     'var zoom={zoom};' \
                     'var count=0;' \
                     'map.centerAndZoom(myP1,zoom);' \
                     'window.run = function () {{' \
                     '  var walking = new BMap.WalkingRoute(map,{{renderOptions: {{map: map,autoViewport:false}}}});' \
                     '  walking.search(myP1, myP2);' \
                     '  walking.setSearchCompleteCallback(function () {{' \
                     '      map.centerAndZoom(myP1, zoom);' \
                     '      {set_style}' \
                     '      map.addEventListener("tilesloaded",function(event){{count++;' \
                     '      if(count=={trigger}){{document.title ="loaded";}}}});' \
                     '  }});' \
                     '}};' \
                     'run();' \
                     '</script>' \
                     '</body>' \
                     '</html>'
    # 录屏-zoom缩放
    html_template3 = '<!DOCTYPE html' \
                     '><html lang="zh-cn"><head>' \
                     '<meta charset="UTF-8">' \
                     f'<link rel="stylesheet" type="text/css" href="{css}">' \
                     f'</head><script type="text/javascript" src="{map_urls["webgl"]}&ak=xmdoecrWaGarTEeROLW21cFKeLyKQbUI">' \
                     '</script>' \
                     f'<script type="text/javascript" src="{jquery_js}"></script>' \
                     '<body>' \
                     '<div id="BaiduMap"></div>' \
                     '<script>' \
                     'let BMap = window.BMap;' \
                     'let center_point = new BMapGL.Point({lng}, {lat});' \
                     'let map = new BMapGL.Map("BaiduMap");' \
                     'map.centerAndZoom(center_point, 13);' \
                     'var count=0;' \
                     'map.addEventListener("tilesloaded",function(){{count++;' \
                     '      if(count==1){{document.title ="loaded";}}}});' \
                     'setTimeout(function () {{ map.centerAndZoom(center_point, 15);' \
                     '}}, 5000);' \
                     '</script>' \
                     '</body>' \
                     '</html>'


class BasicMaterialConfig(object):
    """基础素材信息相关配置"""
    ALL = ['bgm', 'font', 'logo', 'xiaobei', 'background', 'transition', 'web', 'map', 'asset',
           'lingjing_template', 'lingjing_asset', 'lingjing_lottie',
           'hsws_template', 'hsws_support', 'hsws_background', 'hsws_sound', 'hsws_animation',
           'batch', 'watermark']
    basic_material_prefix = 'basic_material'

    bgm_object_prefix = f'{basic_material_prefix}/bgm'
    bgm_dir = PathConfig.DATA_BGM_DIR
    bgm_md5 = {
        'a_long_cold.mp3': '7b6cdb2216c29f72fb99a1eb3177b417',
        'barton_springs.mp3': 'ab033ff09020d2c84cdb008853ea9a87',
        'blue_skies.mp3': 'c68365d6e959d7b943d14ee85c767390',
        'coffee_stains.mp3': 'e65543973a8833e5793674166d292a2e',
        'get_outside.mp3': '21c3f0f812cea01ca860c3749c127502',
        'how_it_began.mp3': 'e2bef2d3dfafdf7cc33f1444eea29888',
        'on_hold.mp3': '7acf656a5eed07a1ee4feaf694fed43d',
        'pas_de_deux.mp3': '18d3a3604ebfc6eb975e36a733cf62e6',
        'payday.mp3': 'ea66f1f0fcf73f39fba88423707fdd5f',
        'sound_off.mp3': '8692bfcd74867dbd809578336b246d08',
        'spring_in_my_step.mp3': '4b76fde0328cb0f9fd64b2ff9cb56238',
        'you_re_no_help.mp3': '43b57730b7c990762f4871732f24694e'
    }

    font_object_prefix = f'{basic_material_prefix}/font'
    font_dir = PathConfig.DATA_FONT_DIR
    font_md5 = {
        '方正兰亭特黑简体.ttf': '34d211b807682118d8cb560b214cb021',
        '方正正大黑简体.ttf': 'ab1fcbf7870b61c63846f4edd7f71dc0',
        '苹方-简-中粗体.ttf': 'a660a2b7ff078ef632fd4cc92698ce77',
        '苹方-简-中黑体.ttf': 'f7c2166e8085cc87ab95cadf5dafea2d',
        '苹方-简-常规体.ttf': '243f514bc7a853e77db697e53a7aae51',
        '方正兰亭准黑简体.ttf': 'c651deee9ccc168d271681807aef77f3',
        '方正兰亭中黑简体.ttf': 'fb6d093600f4200da825815c179838e8',
        '方正兰亭粗黑简体.ttf': '0191f252296c45fa8594e2045f8c0b59',
        '方正兰亭黑简体.ttf': '43e50b0ddbe9d3637145771140ba0979',
        '方正品尚中黑简体.ttf': '91c094850805b96a8eb42e48f8936df6',
        '方正榜书行简体.ttf': '73e777298791dcd3bf656a024d4b2ed8',
        '方正兰亭超细黑简体.ttf': 'f39efb90c8cdbc9a9a788112bd45ed4c',
        '方正兰亭细黑简体.ttf': '62eed7a8a39b20f3490a0086107678b6',
        '方正品尚黑简体.ttf': 'c7fb53fe816b8d126c117eb3e610e229',
        '方正品尚粗黑简体.ttf': '46f16fa833125c0c6ff5bab48796a09e',
        '方正锐正圆-简-Bold.ttf': 'df3364c217b9d78a2878b0a342cefab6',
        '方正锐正圆-简-DemiBold.ttf': '2c47d59890315e5eeb85976f7c50067b',
        '方正锐正圆-简.ttf': 'f78bd8773036f0647acd6302d360b00a',
        '方正字迹-黄龄野鹤行书-简.ttf': 'f88ab4133da0dba81cdf37a9ee3c546d',
        '方正黑隶简体_大.ttf': '8ca2cd963d58c14b5d2db9fa7738b5bd',
        '方正华隶简体.ttf': 'fcbab6c5d19f606c8c3602ad8a224015',
        '方正拉勾标题-简.ttf': '9d213e772af2da414c1765eb7ae9c216',
        '方正拉勾标题体简体Demibold.ttf': '60f01e5bbd2580f7a2cdc5998c31a334',
        '方正盛世楷书简体_大.ttf': 'c0f071de375b921d80d95678b794f259',
        '方正时代宋-简.ttf': '7b28ece17bc96d1f04a870f903e51666',
        '方正水云简体_粗.ttf': '3987364343ec5dd334a5152a36a17c6d',
        '方正宋刻本秀楷简体.ttf': 'ee7a0297674577b4bf016daf2d34a7da',
        '方正颜宋简体_粗.ttf': '70bec3fa010a1ad0208fee56845eb234',
        '方正字迹-龙吟体.ttf': '9e102c8a9731d73ff24891fb4db89969',
        '方正字迹-牟氏黑隶简体.ttf': 'c289ea1c3cc79b2ab20851f0e4393961',
        '方正字迹-新手书.ttf': 'dac7df8d95ac8d209736d2d92a8e3023',
        '优设标题黑.ttf': '1726685ca93be4e04930d6561afd1d68',
        'DIN_Alternate_Bold.ttf': '4e108eed3072dea4283c213b6c912b26'
    }

    logo_object_prefix = f'{basic_material_prefix}/logo'
    logo_dir = PathConfig.DATA_LOGO_DIR
    logo_md5 = {
        'bk_blue_icon@1x.png': '1f5569529c1309f725bb536f04f0e7bf',
        'bk_horizontal_blue_fullbg@3x.png': 'd6d7d2714b24ffc21faea0930da280b7',
        'bk_horizontal_blue@1x.png': '1f9eacb24c280d8b66c0d348ab74c397',
        'bk_horizontal_blue@3x.png': '2c173eb4bfa38fdf2c634ff91234d835',
        'bk_horizontal_white@1x.png': '66b640fed207d14c362c9ffd59918ced',
        'bk_horizontal_white@3x.png': '7882d8e306afdcaf54d5fb2f889c70c2',
        'bk_vertical_blue.png': '52b873feb10954f3e5327cb159bf2438',
        'bk_vertical_blue@2x.png': '18bd5859d616d6ca8ebcbeea57750db1',
        'homelink_green.png': '7d9a0ef75089948b7feef3ade354e1d5',
        'lj_horizontal_green_fullbg@3x.png': '4ddd001563ef96fbe71f6c55b63c5b8f',
        'lj_horizontal_green@3x.png': 'a3e90da3861fc67d7c10feba1c5a6c66',
        'lj_horizontal_white@3x.png': '16c24c4588b0857a44c710847f634b87'
    }

    xiaobei_object_prefix = f'{basic_material_prefix}/xiaobei'
    xiaobei_dir = PathConfig.DATA_XIAOBEI_DIR
    xiaobei_md5 = {
        'consultant.gif': 'bac5b3c1985e7bd8eb6e1d7e5c106122',
        'instructor.gif': '6aa14966291b0f76456454a2f3d641ee',
        'normal.png': '0308792b3ecdc2d6b402d9af33f85324',
        'instructor.png': '8f30cc7897b2935d92a5f486d027e4b6'
    }

    background_object_prefix = f'{basic_material_prefix}/background'
    background_dir = PathConfig.DATA_BACKGROUND_DIR
    background_md5 = {
        'rfv_default_background.png': '9c9a807800353d98f4f70872eccccaba',
        'rfv_default_background_mask.png': '1c2a648949372436ed6362cf73c65124',
        'rfv_guarantee_overview.jpg': '341fb540800116ba8cb71d69baff7c9c',
        'atv_default_background.png': '2506b223b2a3c6b2055710e760804d53',
        'atv_guarantee_basic_info_1.jpg': '01f2d44c70d59ce18416d9e3451a1d38',
        'atv_guarantee_basic_info_2.jpg': '9ac65ab2b6e04ac0ed89053386864b30',
        'atv_guarantee_basic_info_3.jpg': 'aa1c838409c5484734e4a815dacb098c',
        'atv_guarantee_basic_info_4.jpg': '624c5716e34bf47dd92e6ad3bf63190e',
        'atv_guarantee_better_frame_info_1.jpg': '8342cbcdeb750a0bf27ae32fefc93bb9',
        'atv_guarantee_better_frame_info_2.jpg': '07582efc7cf24e876c1ad6cd60ec9036',
        'atv_guarantee_better_frame_info_3.jpg': '31bc17f4fa03f1d84c126e2310a8fc91',
        'atv_guarantee_better_frame_info_4.jpg': '6f9ba5608f60f26c8628bb0877088bb2',
        'atv_guarantee_live_info_1.jpg': '281abd6037a10341419ca17e30082612',
        'atv_guarantee_live_info_2.jpg': 'b951e8be48e9f56654e7d9390f37aea2',
        'atv_guarantee_live_info_3.jpg': 'c1a85018e1b9c5c64ab97278e151113b',
        'atv_guarantee_live_info_4.jpg': '01299505ad90ac7709bac6e2473a5d90',
        'atv_guarantee_security_parking_1.jpg': '09d37b411e65252ea3fa9993c829c21f',
        'atv_guarantee_security_parking_2.jpg': '12d00cab09e6044ad4581b1d0878a0b2',
        'atv_guarantee_security_parking_3.jpg': 'e000a475269233c7befad38e6c0b67d7',
        'atv_guarantee_security_parking_4.jpg': 'd3993907184e626b59f1a1ef14b263ad',
        'atv_guarantee_live_population_1.jpg': 'b31c60bdc84af83a1c6cfffd67525f90',
        'atv_guarantee_live_population_2.jpg': '3ac1f0df75835dd8b46dfb1c6ee3cfa3',
        'atv_guarantee_live_population_3.jpg': '5873e0b40d0dd680c3ed8ee133b6ca81',
        'atv_guarantee_live_population_4.jpg': '31bc17f4fa03f1d84c126e2310a8fc91',
        'nhiv_default_background.png': '658b5e961b8b105db297025c8b580ab4',
        'nhiv_head.mp4': '2e4da461da39297760179f62cdd1cc82',
        'nhiv_tail_normal.mp4': 'afe8cc31a2be98a7de4fcbc49ee1e632',
        'nhiv_tail_inside.mp4': 'e267553b94db0daa70d4a147898d22da'
    }

    transition_object_prefix = f'{basic_material_prefix}/transition'
    transition_dir = PathConfig.DATA_TRANSITION_DIR
    transition_md5 = {
        '5101001-cube.glsl': '4d6d70910375f7165bb8bef0ac723754',
        '5101002-fade.glsl': 'ccce24b4e4c21bb01bc82adb9cde139c',
        '5101003-wipe_down.glsl': '74d3e885f0bfdfb7dcec893df803838a',
        '5101004-wipe_up.glsl': '8bc6a0bebede06da9be142d76b657b75',
        '5101005-wipe_right.glsl': '2623158e116591501eed7e50a1b20f10',
        '5101006-wipe_left.glsl': '0ad8b2caa9616a3a00a89a3e456f322c',
        '5101007-fadecolor.glsl': '51bb4e3577ded81d4685a8807ff9e28f',
        '5101008-directional_wipe.glsl': 'acbb2b60ab50d3f1178b352a9c66940f',
        '5101009-inverted_page_curl.glsl': '7d1618a98adc59b9ed85440c50df6eaa',
        '5101010-swap.glsl': '02a86c98033378c60545aa60c41492f0',
        '5101011-circle_crop.glsl': '8e3300bec50b741062efe8b8c2bae4ac',
        '5101012-radial.glsl': 'c2b702b90f87d82770e126498e4803ef',
        '5101013-simple_zoom.glsl': 'ab292290f3a7db0c5d580e46fd999c99',
        '5101014-linear_blur.glsl': '2770593e6a4f2dcb11eb94d4e0865484',
        '5101015-heart.glsl': 'b91dd3b004207fa478a28520b761bae1',
        '5101016-grid_flip.glsl': 'a55da996691885aef338be92793c22e0'
    }

    web_object_prefix = f'{basic_material_prefix}/web'
    web_dir = PathConfig.DATA_WEB_DIR
    web_md5 = {
        'web.zip': 'ef3d7a1ff8e7ba736b481763967857d2'
    }

    map_object_prefix = f'{basic_material_prefix}/map'
    map_dir = PathConfig.DATA_MAP_DIR
    map_md5 = {
        'map.zip': '8ec685ad82dbc13f082895dba1cc4033'
    }

    asset_object_prefix = f'{basic_material_prefix}/asset'
    asset_dir = PathConfig.DATA_ASSET_DIR
    asset_md5 = {
        'white_bar.png': '3ca1dbff6cf37e3c64bdbc93ede05007',
        'rounded_background.png': '83679920e474bf8a1de60aaf55019164',
        'rounded_background_bei.png': '2c1acf9c827a6db18a36cd2d7bbf441a',
        'title_bg_left.png': 'afdc36b7e1dad90a2fbe27a5c09a6461',
        'title_bg_mid.png': 'be67badc15c03921c5df3e3aa78d1d4d',
        'title_bg_right.png': 'b01699ba3103f1d4072427bf1fcdcfca',
        'photo_bg.png': 'ea51f3e972dbe641ca3ec2394734c282',
        'biz_stripe.png': 'cd22714ee7b1fb31177ba28ec79cc635'
    }

    lingjing_template_object_prefix = f'{basic_material_prefix}/lingjing/template'
    lingjing_template_dir = PathConfig.DATA_LINGJING_TEMPLATE_DIR
    lingjing_template_md5 = {
        '5001000.json': 'd13f74d11dee442e90b0517fc807e30f',
        '5001100.json': 'f593bb8532ce606386dbc4923c3ded89',
        '5001200.json': 'fc62c64693fa2ec8fadb89d8d77d94d7',
        '5001300.json': '2eccd4123ad73070a2dbc2d049aa00f7',
        '5001400.json': 'e0ecb52f2affaa5298b66ce41d3b3f14',
        '5001500.json': 'a23ba575252c5d33c507fa12807d6fdb'
    }

    lingjing_asset_object_prefix = f'{basic_material_prefix}/lingjing/asset'
    lingjing_asset_dir = PathConfig.DATA_LINGJING_ASSET_DIR
    lingjing_asset_md5 = {
        '52010040101.png': '71b9affb529cbbb0f1a9684d3af796f9',
        '52010040102.png': '68447d00196b00fa72f32baa5442aa9b',
        '52010040103.png': 'a388de630693883ed89050e076e82caf'
    }

    lingjing_lottie_object_prefix = f'{basic_material_prefix}/lingjing/lottie'
    lingjing_lottie_dir = PathConfig.DATA_LINGJING_LOTTIE_DIR
    lingjing_lottie_md5 = {
        'man.json': '5776a3f15f1497ff96107e18afd8354f',
        'woman.json': '0de21d44a3d9956f89bc52a3cc59897c'
    }

    hsws_template_object_prefix = f'{basic_material_prefix}/hsws/template'
    hsws_template_dir = PathConfig.DATA_HSWS_TEMPLATE_DIR
    hsws_template_md5 = {
        'entity_name_title.zip': '51623c08ac0ae505ff6bbf403ffc064a',
        'date_under_title.zip': '910011b69c7577b9157d6e4dda24b390',
        'average_price_weekly_title.zip': '8451916b0c5a1d724bad9da8aa2dbc95',
        'average_price_weekly_roll_4.zip': 'd55ce8206c5e30c6df3d7e245facd394',
        'average_price_weekly_roll_5.zip': 'dd2c58665855f842c49f430e7aa18b3d',
        'average_price_weekly_roll_6.zip': '70e9a670217d80e1c5b444ee99d2f92a',
        'resblock_rank_in_bizcircle_title.zip': 'f61bc90ed1c74054d0b694c03685fd8a',
        'rank_1_vs_123.zip': '05ce99be33f6763c96e26e1f66b2f728',
        'rank_2_vs_123.zip': '34c8ec27e294558620d9de8ec0ea8d20',
        'rank_3_vs_123.zip': 'fd76540100cb72d959077bba0a0c3880',
        'increase_rank.zip': '1f0a310bb111fd65d83c5304bb5a84a7',
        'decrease_rank.zip': '21ab6e122023901818e362e385f78b98',
        'deal_histogram_resblock_short.zip': '9eb90fee2440575ec3cf1ccb64be5867',
        'deal_histogram_resblock_long.zip': '44a1d7a6642479f118e3f2fb2f1585d8',
        'deal_histogram_resblock_equal.zip': '849edd52e7c588a0b533a8802668b803',
        'house_vs_customer_this_week.zip': '341b44dd597cd63247b1ea783265d61f',
        'house_vs_customer_last_week.zip': '8bda65cfafaf41552e016309b3ed1b59',
        'increase_percent.zip': '9d9af36b28e824699205db3c01b136c6',
        'decrease_percent.zip': 'c65b5aae55308d5dc566412d769c47f7',
        'price_curve_change.zip': 'a908e03974bdf7efe17044550ed358d2',
        'price_curve_compare.zip': '298777249272583e9185dac033ba8733',
        'price_curve_trend.zip': '006700420dce851ecb6dd309461b7241',
        'summary_content_1.zip': 'f6961ac17fa217b513c6df626d9e6ff0',
        'summary_content_2.zip': '91cc312d5a8b62f2278569d32a8bfb14',
        'summary_content_3.zip': '79268711183ea78f370afbf32c875fc7'
        # 'summary_part_1.zip': '1173936729f7f6ce2b1825170a7c7306',
        # 'summary_part_2.zip': '1213c846080ee5a7c47abc240efa920e',
        # 'summary_part_3.zip': 'ccaaec30084a9d8aa82417d340e57601',
    }

    hsws_support_object_prefix = f'{basic_material_prefix}/hsws/support'
    hsws_support_dir = PathConfig.DATA_HSWS_SUPPORT_DIR
    hsws_support_md5 = {
        'FileSaver.min.js': 'bd9105ba51dccb7403a47ccaa3a5ce2e'
    }

    hsws_background_object_prefix = f'{basic_material_prefix}/hsws/background'
    hsws_background_dir = PathConfig.DATA_HSWS_BACKGROUND_DIR
    hsws_background_md5 = {
        'title_and_date.mp4': '565c94b49e1e3d570b518928c47985b2',
        'price_and_rank.mp4': '8d012e90db98f1f1678b0070fd1c6c76',
        'deal_histogram.mp4': 'aa3160130c6445992d2b9ea70a1ec247',
        'house_vs_customer_this_week.mp4': '22e9bafff96f3b9a0e5a12b3288b53e7',
        'house_vs_customer_last_week.mp4': 'd8045a404f447d43edf0cbba33f13a6a',
        'summary_static.mp4': 'e367b49aeb5d2d23023671c26aa5b2ff',
        'house_vs_customer_transition.mp4': '619147527663175418c83a82ec775bf8',
        'deal_histogram_transition.mp4': '233bcdce36e548e50649fc563d01fbbd',
        'summary_dynamic.mp4': '8ae41c69ab039a6728f4fc877c6491fc',
        'head.mp4': '13bd49de77dc5c54ad4dc64e8cd7e9e7',
        'tail.mp4': 'd6d9f5b044343b899add6e502849e7aa',
        'price_trend.mp4': 'ebfd0bc175a8c06b5b3fb7b8be8707c5',
        'deal_histogram_transition_comp.mp4': '3eccc38ddc7c1e7b343f572cf72d2ab2',
        'house_vs_customer_transition_comp.mp4': '290fca9a16be7f21ad22e6293e6093b6',
        'tail_comp.mp4': '5229229c9f4df25f32f5fa47dbf1f945'
    }

    hsws_sound_object_prefix = f'{basic_material_prefix}/hsws/sound'
    hsws_sound_dir = PathConfig.DATA_HSWS_SOUND_DIR
    hsws_sound_md5 = {
        '嗒.m4a': '11c5ed0466f7d376b909ffc84d57710f',
        '弹出.m4a': '0d99b0c14e42b06033a167c5088a5f25',
        '滴.m4a': '81cd6952e21f6b092ab606651dce6211',
        '电脑报错.m4a': 'b99e11c190294b6462a2846c02f1ce16',
        '电脑点击.m4a': 'f71be106ad3a0c802fa6ca713f1acd59',
        '嗙.m4a': '0ef1378973096aba5a39b5295b77b15f',
        '嗖_短.m4a': 'd5177fed3ccd1c2d58607c1e62cd4e53',
        '嗖_长.m4a': 'f539de87789a0b775469ff492e063230',
        '用力弹出.m4a': '812f5a9d5af646bfc862ab9dbe1ade9c'
    }

    hsws_animation_object_prefix = f'{basic_material_prefix}/hsws/animation'
    hsws_animation_dir = PathConfig.DATA_HSWS_ANIMATION_DIR
    hsws_animation_md5 = {
        'average_price_weekly_title.mov': '7819342bbe7694724cbb341e3996d10c',
        'resblock_rank_in_bizcircle_title.mov': '333817284e0657f8a9ec9891d65c0124',
        '价格走势持续上涨-1.mov': 'ffe46f34ff65edb9025d5ad0442dca34',
        '价格走势波动上涨-1.mov': '710df6cca412fb319f9cdf515528f54b',
        '价格走势持续下降-1.mov': '67f06f8b9ab5097fed1b84b956cbd4a5',
        '价格走势波动下降-1.mov': '1dc6705ceda4ae56f0e1987912046925',
        '价格走势相对平稳-1.mov': '9e70a21ca0e907c9c65558bace6fd5fe',
        '价格走势波动震荡-1.mov': 'd661de647ec3be720feb70a259dd808c',
        '市场热度有所降温-1.mov': 'abaab12df054fe0ac7c912f629060b8d',
        '市场热度有所升温-1.mov': 'b3d0a698cfd4473b45d47b5633a6c2df',
        '市场热度保持不变-1.mov': '029a2fcdfd852a1c6813e08aa7364ff1',
        '属于抢手房源-1.mov': 'f7eeb6ca971e014645db121935441b2e',
        '属于一般房源-1.mov': '7c0e9604761ab7594e3a930738813621',
        '属于长周期房源-1.mov': '65ac1c9ec680538d86b55b26ab0b0576',
        '市场热度有所降温-2.mov': '053672fcaadbbbabb56e50228495b9b3',
        '市场热度有所升温-2.mov': 'c4e9b67164932b8783a59ffbd2ef7c6a',
        '市场热度保持不变-2.mov': '747c601d78b244772d6e10006741cc69',
        '属于抢手房源-2.mov': 'dc98cb07a5221f6955ebd0dffe3a0b6f',
        '属于一般房源-2.mov': '4e7523d608db02ada2e2c34e60059b47',
        '属于长周期房源-2.mov': '936fa8840a6a22fa838aaba83ddb75d8',
        '属于抢手房源-3.mov': '7f98517bd2b083e27652d9c9dd25ea93',
        '属于一般房源-3.mov': '25debda3cb9b222041343d427d822278',
        '属于长周期房源-3.mov': '2434224294fb95088f7e0038ce79fc05'
    }

    batch_object_prefix = f'{basic_material_prefix}/batch'
    batch_dir = PathConfig.DATA_BATCH_DIR
    batch_md5 = {
        '7001001.json': '0335852136efce289b897142fc22559e',
        '7001002.json': 'a88cf9b92b6fe999e143daa8ef05e45f'
    }

    watermark_object_prefix = f'{basic_material_prefix}/watermark'
    watermark_dir = PathConfig.DATA_WATERMARK_DIR
    watermark_md5 = {
        'watermark_lj@2x.png': '6c7925e3ccd80f9d4b2719f830bfc1a4',
        'watermark_bk@2x.png': '454a39f6a03da35df8334b0318c73793'
    }
