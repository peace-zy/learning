# -*- coding: utf-8 -*-
# ===============================================================
#
#    Copyright (C) 2020 Beike, Inc. All Rights Reserved.
#
#    @Create Author : liweipeng007 (liweipeng007@ke.com)
#    @Create Time   : 2020/5/11 12:03 下午
#    @Description   : 系统配置项
#
# ===============================================================


import os
import os.path as osp
from collections import namedtuple

# 设置系统配置
ENV_TYPE = os.environ.get("ENV_TYPE", "dev")
POD_NAME = os.environ.get("POD_NAME", "video_platform_pod")
NODE_NAME = os.environ.get("NODE_NAME", "video_platform_node").replace(
    '.', '_').replace('-', '_')
DEFAULT_SERVICE = 'default_service'
API_SERVICE = 'api_service'
PRODUCTION_SERVICE = 'production_service'
SERVICE_NAME = os.environ.get("SERVICE_NAME", DEFAULT_SERVICE)


class PathConfig(object):
    """程序运行所使用的路径"""
    ROOT_DIR = osp.dirname(osp.dirname(osp.abspath(__file__)))
    APPDATA_DIR = osp.join(osp.dirname(ROOT_DIR), 'thor-app-data')

    MATRIX_CODE_DIR = os.environ.get("MATRIX_CODE_DIR", ROOT_DIR)
    MATRIX_CACHE_DIR = os.environ.get(
        "MATRIX_CACHE_DIR", osp.join(APPDATA_DIR, 'cache'))
    MATRIX_APPLOGS_DIR = os.environ.get(
        "MATRIX_APPLOGS_DIR", osp.join(APPDATA_DIR, 'applogs'))
    MATRIX_PRIVDATA_DIR = os.environ.get(
        "MATRIX_PRIVDATA_DIR", osp.join(APPDATA_DIR, 'privdata'))
    MATRIX_ACCESSLOGS_DIR = os.environ.get(
        "MATRIX_ACCESSLOGS_DIR", osp.join(APPDATA_DIR, 'logs'))

    if ENV_TYPE in ('online', 'test'):
        TEMPLATE_WORK_DIR = '/data0/strategy/thor/cache'  # 宿主机目录
    else:
        TEMPLATE_WORK_DIR = MATRIX_CACHE_DIR

    DATA_DIR = osp.join(MATRIX_PRIVDATA_DIR, 'basic_material')
    TEST_DIR = osp.join(ROOT_DIR, 'test')

    DATA_BGM_DIR = osp.join(DATA_DIR, 'bgm')
    DATA_FONT_DIR = osp.join(DATA_DIR, 'font')
    DATA_LOGO_DIR = osp.join(DATA_DIR, 'logo')
    DATA_XIAOBEI_DIR = osp.join(DATA_DIR, 'xiaobei')
    DATA_BACKGROUND_DIR = osp.join(DATA_DIR, 'background')
    DATA_TRANSITION_DIR = osp.join(DATA_DIR, 'transition')
    DATA_WEB_DIR = osp.join(DATA_DIR, 'web')
    DATA_MAP_DIR = osp.join(DATA_DIR, 'map')
    DATA_ASSET_DIR = osp.join(DATA_DIR, 'asset')
    DATA_LINGJING_TEMPLATE_DIR = osp.join(DATA_DIR, 'lingjing/template')
    DATA_LINGJING_ASSET_DIR = osp.join(DATA_DIR, 'lingjing/asset')
    DATA_LINGJING_LOTTIE_DIR = osp.join(DATA_DIR, 'lingjing/lottie')
    DATA_HSWS_TEMPLATE_DIR = osp.join(DATA_DIR, 'hsws/template')
    DATA_HSWS_SUPPORT_DIR = osp.join(DATA_DIR, 'hsws/support')
    DATA_HSWS_BACKGROUND_DIR = osp.join(DATA_DIR, 'hsws/background')
    DATA_HSWS_SOUND_DIR = osp.join(DATA_DIR, 'hsws/sound')
    DATA_HSWS_ANIMATION_DIR = osp.join(DATA_DIR, 'hsws/animation')
    DATA_HSWS_RESBLOCK_TITLE_DIR = osp.join(
        DATA_HSWS_ANIMATION_DIR, 'resblock_title')
    DATA_HSWS_STAT_DATE_DIR = osp.join(DATA_HSWS_ANIMATION_DIR, 'date')
    DATA_BATCH_DIR = osp.join(DATA_DIR, 'batch')
    DATA_WATERMARK_DIR = osp.join(DATA_DIR, 'watermark')

    for dir in [APPDATA_DIR,
                MATRIX_CODE_DIR, MATRIX_CACHE_DIR, MATRIX_APPLOGS_DIR, MATRIX_PRIVDATA_DIR, MATRIX_ACCESSLOGS_DIR,
                TEMPLATE_WORK_DIR, DATA_DIR, TEST_DIR,
                DATA_BGM_DIR, DATA_FONT_DIR, DATA_LOGO_DIR, DATA_XIAOBEI_DIR,
                DATA_BACKGROUND_DIR, DATA_TRANSITION_DIR, DATA_WEB_DIR, DATA_MAP_DIR,
                DATA_ASSET_DIR, DATA_LINGJING_TEMPLATE_DIR, DATA_LINGJING_ASSET_DIR, DATA_LINGJING_LOTTIE_DIR,
                DATA_HSWS_TEMPLATE_DIR, DATA_HSWS_SUPPORT_DIR, DATA_HSWS_BACKGROUND_DIR, DATA_HSWS_SOUND_DIR,
                DATA_HSWS_ANIMATION_DIR, DATA_HSWS_RESBLOCK_TITLE_DIR, DATA_HSWS_STAT_DATE_DIR,
                DATA_BATCH_DIR, DATA_WATERMARK_DIR]:
        os.makedirs(dir, exist_ok=True)


class RedisConfig(object):
    """Redis相关配置"""
    RedisTuple = namedtuple(typename="RedisTuple", field_names=[
                            "host", "port", "password", "db"])
    ENV = {
        "online": RedisTuple("m12624.zeus.redis.ljnode.com", "12624", "JYIKZg240M17A9UC", 0),
        "test": RedisTuple("10.26.40.112", "11191", "n6RbH2NDzS", 1),
        "dev": RedisTuple("10.26.40.112", "11191", "n6RbH2NDzS", 0)
    }  # 零信任安全平台  kgw.ke.com:10815 -> 10.26.40.47:11191  相关wiki：http://wiki.lianjia.com/pages/viewpage.action?pageId=646709442

    own_job_queue = f'video_platform:template_job_queue:{NODE_NAME}'
    video_queue = 'video_platform:{}_video_queue'
    download_flag = 'video_platform:lock:download:basic_material'
    dispatch_flag = f'video_platform:lock:dispatch:{NODE_NAME}'

    doing_template_prefix = 'video_platform:template:'
    assemble_prefix = 'video_platform:assemble:'

    key_expire_time = 3600 * 24 * 7  # 7d
    download_expire_time = 60 * 3  # 3min
    tts_task_count_expire_time = 60  # 60s

    tts_task_count_prefix = 'video_platform:tts_task_count_'
    tts_key = 'video_platform:current_tts_task_count_key'

    retry_num = 5
    retry_interval = 0.05  # 50ms
    download_interval = 10  # 10s


class S3Config(object):
    """S3相关配置"""
    # 服务云 Principal：lj:iam:::other-intelligent-video
    # 产品树id：10396  产品树路径：/数据智能中心/策略算法部/AI内容与图像组/图像处理
    AK = 'B4CXKULMKKNG5BJXTNID'
    SK = 'p1RJvOfw/3ixVyzoiGeJYzvnbeGfT5QZdT5zxa4O'
    endpoint_url = 'http://storage.lianjia.com'
    bucket_name = 'intelligent-video'


# @formatter:off
class MySQLConfig(object):
    """MySQL相关配置"""
    MySQLTuple = namedtuple(typename='MySQLTuple', field_names=[
                            "host", "port", "user", "password", 'database'])

    __ENV = {
        "online": MySQLTuple("m9048.zeus.mysql.ljnode.com", 9048, "video_platform", "bEHC9WZS16qTV5jR", 'content_center'),
        "test": MySQLTuple("10.26.62.78", 10628, "root", "D2BbEF3DC8", 'ai_content'),
        "dev": MySQLTuple("10.26.62.78", 10628, "root", "D2BbEF3DC8", 'ai_content')
    }  # 零信任安全平台 kgw.ke.com:11189 -> m10628.mars.test.mysql.ljnode.com:10628
    INFO = __ENV[ENV_TYPE]

    # 知识点
    __ENV_KNOWLEDGE = {
        "online": MySQLTuple("m6674.zeus.mysql.ljnode.com", 6674, "video_platform", "M33oh4SVMHjh6WMJ", 'ai_content'),
        "test": MySQLTuple("10.26.62.78", 10628, "root", "D2BbEF3DC8", 'ai_content'),
        "dev": MySQLTuple("10.26.62.78", 10628, "root", "D2BbEF3DC8", 'ai_content')
    }
    INFO_KNOWLEDGE = __ENV_KNOWLEDGE[ENV_TYPE]
# @formatter:on


class AlbumConfig(object):
    """图床图库相关配置"""
    # DF010000289C
    # 10396 /数据智能中心/策略算法部/AI内容与图像组/图像处理
    EXP = '300'  # 秒级过期时间
    domain = 'https://p.ljcdn.com'  # 图床图库域名
    AK = 'DF010000289C'
    SK = '558EC6919536896409E56768373BA972'
    default_album = 'intelligent-video-cover'


class StatusCodeConfig(object):
    """异常名称及编号"""
    INITIAL_STATUS = -1  # 初始状态，未知错误
    OK = 0  # 正常
    PARTIAL_OK = 1  # 部分结果正常
    INTERNAL_ERROR = 10  # 服务内部错误
    TTS_ERROR = 11  # TTS生产错误
    TIMEOUT = 12  # 超时
    CALLBACK_ERROR = 13  # 回调报错
    MISSING_ARGUMENTS = 20  # 缺少接口所需参数
    INVALID_ARGUMENTS = 21  # 参数值无效
    ALREADY_EXISTS = 30  # 数据已经存在
    UNEXPECTED_DATA = 31  # 异常数据
    ALREADY_DELETED = 32  # 数据已经删除（灵境）

    error_msg = {
        INITIAL_STATUS: 'INITIAL_STATUS',
        OK: '',
        PARTIAL_OK: 'PARTIAL_OK',
        INTERNAL_ERROR: 'INTERNAL_ERROR',
        TTS_ERROR: 'TTS_ERROR',
        TIMEOUT: 'TIMEOUT',
        CALLBACK_ERROR: 'CALLBACK_ERROR',
        MISSING_ARGUMENTS: 'MISSING_ARGUMENTS',
        INVALID_ARGUMENTS: 'INVALID_ARGUMENTS',
        ALREADY_EXISTS: 'ALREADY_EXISTS',
        UNEXPECTED_DATA: 'UNEXPECTED_DATA',
        ALREADY_DELETED: 'ALREADY_DELETED'
    }
