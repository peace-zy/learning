# -*- coding: utf-8 -*-
# ===============================================================
#
#    Copyright (C) 2019 Beike, Inc. All Rights Reserved.
#
#    @Create Author : gaixindong (gaixindong@ke.com)
#    @Create Time   : 2019/12/28 15:14
#    @Description   :
#
# ===============================================================


import os
import os.path as osp

from living_space.voice_production.voice_config.system import API_SERVICE, ENV_TYPE, PathConfig, POD_NAME, SERVICE_NAME

# 未设置的参数均使用gunicorn的默认值

# ip:port
# http://docs.gunicorn.org/en/stable/settings.html#bind
bind = '0.0.0.0:{}'.format(os.environ.get("PORT", "17890"))

# worker进程数量
# http://docs.gunicorn.org/en/stable/settings.html#workers
workers = 5

# worker的类型
# http://docs.gunicorn.org/en/stable/settings.html#worker-class
worker_class = 'gevent'
if worker_class == 'gevent' and SERVICE_NAME == API_SERVICE:
    import gevent.monkey
    gevent.monkey.patch_all()

# 单worker的最大并发量
# https://docs.gunicorn.org/en/stable/settings.html#worker-connections
worker_connections = 100

# 单worker接收多少次请求后重启
# http://docs.gunicorn.org/en/stable/settings.html#max-requests
max_requests = 10000

# 给max_requests加上[0, 1000]之间的随机数
# http://docs.gunicorn.org/en/stable/settings.html#max-requests-jitter
max_requests_jitter = 1000

# 是否启用SO_REUSEPORT特性
# https://docs.gunicorn.org/en/stable/settings.html#reuse-port
reuse_port = True

# 自定义日志类
# http://docs.gunicorn.org/en/stable/settings.html#logger-class
logger_class = 'lib.log.WebLogger'

# 应用日志路径
# http://docs.gunicorn.org/en/stable/settings.html#errorlog
errorlog = osp.join(PathConfig.MATRIX_APPLOGS_DIR, f'{ENV_TYPE}_app.log')

# 应用日志级别
# http://docs.gunicorn.org/en/stable/settings.html#loglevel
loglevel = 'debug'

# 请求日志路径
# http://docs.gunicorn.org/en/stable/settings.html#accesslog
accesslog = osp.join(PathConfig.MATRIX_ACCESSLOGS_DIR, f'{ENV_TYPE}_{POD_NAME}_access.log')

# 请求日志格式
# http://docs.gunicorn.org/en/stable/settings.html#access-log-format
access_log_format = '%(h)s\t%(l)s\t%(u)s\t%(t)s\t%(r)s\t%(m)s\t%(U)s\t%(q)s\t%(H)s\t%(s)s\t%(b)s\t%(f)s\t%(a)s\t%(L)s\t%(p)s'
