# LIVING SPACE

## 视频脚本

## 动效

### 2D动效

- SVG 动效相关依赖


## 视频生产

### 立木接口
[API接入文档](https://weapons.ke.com/project/9341/wiki/page/36823)

[视频生产文档](https://weapons.ke.com/project/9341/interface/api/1588272)

### API加签python包依赖
```bash
pip install git+https://git.lianjia.com/infrastructure/api-signature-python.git
```

```bash

pip install ffmpeg-python

export PATH=/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt/msic/ffmpeg-6.1-amd64-static:$PATH

sudo mv /home/hilarie/bin/ffmpeg  /usr/local/bin

tar -xvf ffmpeg-release-amd64-static.tar.xz 

ffmpeg -f concat -safe 0 -i mylist.txt -c copy output.mp4
```

### 视频生成pipeline

1. 复制视频脚本到  `living_space/source/script/*.xlsx`. 需要保证有表头, 内容来自于frame_gpt的公共文档里视频脚本的sheet.
2. 启动视频回调接口接受视频 `living_space/video_callback_app.py`.
3. 修改回调ip端口, 并执行 `living_space/gen_video.py` main下的 生成视频脚本部分. 脚本会在result文件夹下生成timestamp命名的的文件夹.
4. 注释`living_space/gen_video.py` 生成视频部分, 修改timestamp变了问上一步生成的文件夹路径，执行拼接视频部分.

### CAD文件读取

0. 设置pip源: `pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple`
1. 安装包 `pip install ezdxf[draw]`
2. 安装默认字体: `./msic/ARIALUNI.TTF` 到 `~/.font`
 - ref: 
    - https://ezdxf.mozman.at/docs/tools/fonts.html#module-ezdxf.fonts.fonts
    - https://github.com/mozman/ezdxf/pull/999
    - https://www.fonts100.com/font+5091_Arial+Unicode+MS.html
 - 刷新字体:
 ```
from ezdxf.fonts import fonts
fonts.build_system_font_cache()
 ```