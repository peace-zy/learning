import os.path as osp
import os
from flask import Flask, request, jsonify
import requests

app = Flask(__name__)


def download_video(url, filename):
    # 发送GET请求并获取响应
    response = requests.get(url, stream=True)

    # 检查请求是否成功
    if response.status_code == 200:
        # 打开文件并写入响应内容
        with open(filename, 'wb') as file:
            for chunk in response.iter_content(chunk_size=1024):
                if chunk:
                    file.write(chunk)
    else:
        print('请求失败，状态码：', response.status_code)


@app.route('/gen_video_callback', methods=['POST'])
def my_api():
    data = request.get_json()
    scene_id = request.args.get('scene_id', default=-1, type=int)
    template_id = request.args.get('template_id', default=-1, type=int)
    template_clip_id = request.args.get('template_clip_id', default=-1, type=int)
    subtitle_no = request.args.get('subtitle_no', default=-1, type=int)
    timestamp = request.args.get('timestamp', default='', type=str)
    status = int(data.get('status', 0))
    message = data.get('message', 'no message')
    assert status == 1, "video gen failed, message: %s" % message
    video_info = data.get('data')

    if video_info:
        video_url = video_info.get('url')
        video_duration = video_info.get('duration')
        _res_str = '%s\t%s\t%s\t%s\t%s\t%s\n' % (timestamp, template_id, template_clip_id, subtitle_no, video_url, video_duration)
        print(_res_str)
        # 判断路径是否存在
        _file_path = f"/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt/living_space/result/{timestamp}/{scene_id}"
        if not osp.exists(_file_path):
            # 创建一个目录
            os.makedirs(_file_path)
        # 调用函数下载视频
        download_video(video_url, f'{_file_path}/{str(subtitle_no).zfill(4)}.mp4')
        with open(f'{_file_path}/video_info.txt', 'a') as f:
            f.write(_res_str)
    # 判断视频片段是否完成
    # 触发视频生成 
    
    return jsonify(message="Data received successfully!")

if __name__ == '__main__':
    app.run(debug=True, port=8006, host='0.0.0.0')