# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2024/1/18 11:42
# ===================================
import ffmpeg

class LsVideo(object):
    def __int__(self, basic_info_dict, **kwargs):
        pass


    def duration(self):
        pass
    
    
def split_video(in_video, splits, **kwargs):
    split = ffmpeg.input('in.mp4').filter_multi_output('split') 
    split0 = split.stream(0) 
    split1 = split[1]
    ffmpeg.concat(split0, split1).output('out.mp4').run()