import sys
sys.path.append('/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt/living_space/voice_production')
import time
import os
import os.path as osp
import glob

import requests
import json

import ffmpeg

import pandas as pd
from api_signature_python3 import SignatureUtil
import video_util
sys.path.append('/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt')
from living_space.voice_production.inference import text2voice
from lib import ffprobe
from living_space.voice_production.voice_config.general import TTSConfig




def gen_video(script_dict, req_url):
    headers = SignatureUtil.SignatureUtil(video_util.AK, video_util.SK).customSignature(req_url, 'post', video_util.GEN_HEADER)
    print(headers)
    r = requests.post(req_url, json=script_dict, headers=headers)
    return r.text

base_script_dict = {
    "t0": "",
    "t1": "",
    "t2": "",
    "t3": "",
    "t4": "",
    "t5": "",
    "t6": "",
    "t7": "",
    "t8": "",
    "t9": "",
    "t10": "",
    "i4": "",
    "i3": "",
    "i2": "",
    "i1": "",
    "i0": "",
}


def assemble_img_seg_video(img_list_path, t, framerate=0.33):
    # ffmpeg.input(f'{img_list_path}/*.png', pattern_type='glob', framerate=24).output(video_path).run()
    return ffmpeg.input(f'{img_list_path}/*.png', pattern_type='glob', framerate=framerate, t=t)


def test_pipeline():
    callback_url = f'http://{CALLBACK_IP}/gen_video_callback'
    df = pd.read_excel(script_path)
    # group df by template_id, template_clip_id, subtitle_no then keep first
    df = df.drop_duplicates(subset=['template_id', 'template_clip_id', 'subtitle_no'], keep='first')
    # 格式化年月日秒
    _file_path = f"/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt/living_space/result/{timestamp}"
    if not osp.exists(_file_path):
        # 创建一个目录
        os.mkdir(_file_path)
    total_num = len(df)
    timeline = []
    for _r in df.itertuples():
        # voice_url = ''
        # try:
        scene_id = _r.scene_id
        scene_path = _file_path + f'/{scene_id}'
        if not osp.exists(scene_path):
            os.mkdir(scene_path)
        template_id = _r.template_id
        template_clip_id = _r.template_clip_id
        subtitle_no = _r.subtitle_no
        subtitle = _r.subtitle
        _source_str = "timestamp=%s&scene_id=%s&template_clip_id=%s&subtitle_no=%s&total_num=%s&template_id=%s" % (timestamp, scene_id, template_clip_id, subtitle_no, total_num, template_id)
        voice_file = text2voice(subtitle, name=_source_str, tone=TTSConfig.TONE_bb_nn)
        # 返回url
        # voice_url = text2voice(subtitle, convert_url=True, name=_source_str)
        # with open(f'{_file_path}/{timestamp}_voice_info.txt', 'a') as f:
        #     voice_res_str = '%s\t%s\t%s\t%s\t%s\t%s\n' % (timestamp, template_id, template_clip_id, subtitle_no, voice_url, subtitle)
        #     f.write(voice_res_str)
        # 判断路径是否存在
        tmp_voice_path = f'{scene_path}/{str(_r.subtitle_no).zfill(4)}_tmp.mp3'
        with open(tmp_voice_path, 'wb') as fwb:
            fwb.write(voice_file)
        # pad音频时间
        voice_path = f'{scene_path}/{str(_r.subtitle_no).zfill(4)}.mp3'
        _audio_duration = ffprobe.audio_duration(tmp_voice_path)
        if _audio_duration < 2:
            _voice_clip = ffmpeg.input(tmp_voice_path).filter('apad', whole_dur=2).output(voice_path).overwrite_output()
            ffmpeg.run(_voice_clip)
            _audio_duration = 2
        else:
            # 文件重命名
            os.rename(tmp_voice_path, voice_path)
        # 删除原始临时文件
        if osp.exists(tmp_voice_path):
            os.remove(tmp_voice_path)
        timeline.append((scene_id, subtitle_no, _audio_duration))
        
        if pd.isna(_r.template_detail):
            continue
        template_detail = json.loads(_r.template_detail)
        template_data = base_script_dict.copy()
        template_data.update(template_detail)
        _callback_url = callback_url + "?"+ _source_str
        print(_callback_url)
        script_dict = {
                "tid": template_id,
                "type": "mp4",
                "callback": _callback_url,
                "data": template_data,
                'fragments': [template_clip_id],
            }
        req_url = video_util.URL + video_util.GEN_VIDEO_URL
        resp = gen_video(script_dict, req_url)
        print(resp)
        # break
        # except Exception as e:
        #     print(str(_r), e)
        #     continue
        # voice_list.append(voice_url)
    # timeline数据join到原先的df
    timeline_df = pd.DataFrame(timeline, columns=['scene_id', 'subtitle_no', 'audio_duration'])
    df = df.merge(timeline_df, on=['scene_id', 'subtitle_no'], how='left')
    df.to_excel(f'{_file_path}/timeline.xlsx', index=False)
    print('done')
    
      
def concat_videos():
    
    # timestamp = '20240123101654'
    timestamp = '20240123173701'
    _file_path = f"/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt/living_space/result/{timestamp}"
    
    script_path = '/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt/living_space/source/script/living_space_script.xlsx'
    df = pd.read_excel(script_path)
    # group df by template_id, template_clip_id, subtitle_no then keep first
    # df = df.drop_duplicates(subset=['template_id', 'template_clip_id', 'subtitle_no'], keep='first')
    # 从df中找不同的scene_id
    scene_video_list, scene_voice_lsit = [], []
    for _scene_id, _df in df.groupby('scene_id'):
        # if _scene_id not in {5}:
        #     continue
        # voice_url = ''
        try:
            scene_path = _file_path + f'/{_scene_id}'
            assert osp.exists(scene_path), f'{scene_path} not exists'
            
            video_list, voice_list = [], []
            all_voice_duration = 0
            for _r in _df.drop_duplicates(subset=['template_id', 'template_clip_id', 'subtitle_no'], keep='first').itertuples():
                subtitle_no = _r.subtitle_no
                _voice_path = scene_path + f'/{str(subtitle_no).zfill(4)}.mp3'
                assert osp.exists(_voice_path), f'{_voice_path} not exists'
                _video_path = scene_path + f'/{str(subtitle_no).zfill(4)}.mp4'
                assert osp.exists(_video_path), f'{_video_path} not exists'
                
                _audio_duration = ffprobe.audio_duration(_voice_path)
                if _audio_duration < 3:
                    _voice_clip = ffmpeg.input(_voice_path).filter('apad', whole_dur=3)
                    _audio_duration = 3
                else:
                    _voice_clip = ffmpeg.input(_voice_path)
                all_voice_duration += _audio_duration
                _video_duration = ffprobe.video_duration(_video_path)
                if _audio_duration < _video_duration:
                    _video_clip = ffmpeg.input(_video_path).crop(0, 297, 1080, 1324).trim(start=0, end=_audio_duration)
                else:
                    _video_clip = ffmpeg.input(_video_path).crop(0, 297, 1080, 1324).filter('tpad', stop_duration=_audio_duration-_video_duration, stop_mode='clone')
                video_list.append(_video_clip)
                voice_list.append(_voice_clip)
            # 拼接视频和音频流
            _temp_v, _temp_a = f'{scene_path}/_video.mp4', f'{scene_path}/_audio.mp3'
            joined_video = ffmpeg.concat(*video_list, v=1, a=0).output(_temp_v).overwrite_output()
            joined_audio = ffmpeg.concat(*voice_list, v=0, a=1).output(_temp_a).overwrite_output()
            # 运行ffmpeg命令
            ffmpeg.run(joined_video)
            ffmpeg.run(joined_audio)
            # 将拼接后的视频和音频合并
            input_video = ffmpeg.input(_temp_v).filter('fade', t='out', st=all_voice_duration-0.5, d=0.5, c='white')
            input_audio = ffmpeg.input(_temp_a).filter('asetpts', 'PTS-STARTPTS')
            concat_video = f'{scene_path}/concat_video_{_scene_id}.mp4'
            ffmpeg.output(input_video, input_audio, concat_video, shortest=None).overwrite_output().run()
            scene_video_list.append(input_video)
            scene_voice_lsit.append(input_audio)
            # break
        except Exception as e:
            print(str(_r), e)
            continue
    # # 合并所有的scene video
    _temp_v, _temp_a = f'{_file_path}/_video.mp4', f'{_file_path}/_audio.mp3'
    joined_video = ffmpeg.concat(*scene_video_list, v=1, a=0).output(_temp_v).overwrite_output()
    joined_audio = ffmpeg.concat(*scene_voice_lsit, v=0, a=1).output(_temp_a).overwrite_output()
    # 运行ffmpeg命令
    ffmpeg.run(joined_video)
    ffmpeg.run(joined_audio)
    input_video = ffmpeg.input(_temp_v)
    input_audio = ffmpeg.input(_temp_a).filter('asetpts', 'PTS-STARTPTS')
    whole_video = _file_path + '/whole_video.mp4'
    ffmpeg.output(input_video, input_audio, whole_video, shortest=None, ac=2, vtag='hvc1', vcodec='libx265', acodec='aac').overwrite_output().run()
    pass


def concat_videos_animation():
    
    # timestamp = '20240123101654'
    _file_path = f"/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt/living_space/result/{timestamp}"
    
    # script_path = '/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt/living_space/source/script/living_space_script_0126.xlsx'
    df = pd.read_excel(script_path)
    # group df by template_id, template_clip_id, subtitle_no then keep first
    # df = df.drop_duplicates(subset=['template_id', 'template_clip_id', 'subtitle_no'], keep='first')
    # 从df中找不同的scene_id
    scene_video_list, scene_voice_lsit = [], []
    for _scene_id, _df in df.groupby('scene_id'):
        # if _scene_id not in {1,2,3}:
        #     continue
        # try:
        scene_path = _file_path + f'/{_scene_id}'
        assert osp.exists(scene_path), f'{scene_path} not exists'
        
        # img_path = f'/aistudio/workspace/aigc/zhangyan461/research/29_machine/frame_gpt/living_space/zhangyan/pngs/scene_{_scene_id}_pngs'
        img_path = f'/aistudio/workspace/aigc/zhangyan461/research/29_machine/frame_gpt/living_space/zhangyan/new_pngs_0129/scene_{_scene_id}'
        
        video_list, voice_list = [], []
        all_voice_duration = 0
        voice_duration_list = []
        for _r in _df.drop_duplicates(subset=['template_id', 'template_clip_id', 'subtitle_no'], keep='first').itertuples():
            subtitle_no = _r.subtitle_no
            _voice_path = scene_path + f'/{str(subtitle_no).zfill(4)}.mp3'
            assert osp.exists(_voice_path), f'{_voice_path} not exists'
            _video_path = scene_path + f'/{str(subtitle_no).zfill(4)}.mp4'
            assert osp.exists(_video_path), f'{_video_path} not exists'       
            _audio_duration = ffprobe.audio_duration(_voice_path)
            _voice_clip = ffmpeg.input(_voice_path)
            all_voice_duration += _audio_duration
            _video_duration = ffprobe.video_duration(_video_path)
            if _audio_duration <= _video_duration:
                _video_clip = ffmpeg.input(_video_path).crop(0, 297, 1080, 1324).trim(start=0, end=_audio_duration)
            else:
                _video_clip = ffmpeg.input(_video_path).crop(0, 297, 1080, 1324).filter('tpad', stop_duration=_audio_duration-_video_duration, stop_mode='clone')
            # 加载图片序列合成的视频
            # _animation_path = scene_path + f'/a_{str(subtitle_no).zfill(4)}.mp4'
            # animation_video = assemble_img_seg_video(img_path, _animation_path)
            voice_duration_list.append((subtitle_no, _audio_duration))
            video_list.append(_video_clip)
            voice_list.append(_voice_clip)
        # 拼接视频和音频流
        _temp_v, _temp_a = f'{scene_path}/_video.mp4', f'{scene_path}/_audio.mp3'
        joined_video = ffmpeg.concat(*video_list, v=1, a=0)
        joined_audio = ffmpeg.concat(*voice_list, v=0, a=1)
        
        # 获取图片数量
        img_count = len(glob.glob(os.path.join(img_path, '*.png')))
        animation_video = assemble_img_seg_video(img_path, framerate=img_count / all_voice_duration, t=all_voice_duration).filter('scale', -1, 814).filter('crop', 984, 814)
        # joined_video = joined_video.overlay(animation_video, x=48, y=174)
        # 运行ffmpeg命令
        ffmpeg.overlay(joined_video, animation_video, x=48, y=174).output(_temp_v, framerate=25).overwrite_output().run()
        ffmpeg.run(joined_audio.output(_temp_a).overwrite_output())
        # 截取视频的最后一帧作为封面
        _voice_duration = 0
        for _subtitle_no, _voice in voice_duration_list:
            _voice_duration += _voice
            ffmpeg.input(_temp_v, ss=_voice_duration-0.1).output(f'{scene_path}/{_subtitle_no}_cover.jpg', vframes=1).overwrite_output().run()
        # 将拼接后的视频和音频合并
        input_video = ffmpeg.input(_temp_v).filter('fade', t='out', st=all_voice_duration-0.5, d=0.5, c='white')
        input_audio = ffmpeg.input(_temp_a).filter('asetpts', 'PTS-STARTPTS')
        # concat_video = f'{scene_path}/concat_video_{_scene_id}.mp4'
        # ffmpeg.output(input_video, input_audio, concat_video, shortest=None).overwrite_output().run()
        scene_video_list.append(input_video)
        scene_voice_lsit.append(input_audio)
            # break
        # except Exception as e:
        #     print(str(_r), e)
        #     continue
    # 合并所有的scene video
    _temp_v, _temp_a = f'{_file_path}/_video.mp4', f'{_file_path}/_audio.mp3'
    joined_video = ffmpeg.concat(*scene_video_list, v=1, a=0).output(_temp_v).overwrite_output()
    joined_audio = ffmpeg.concat(*scene_voice_lsit, v=0, a=1).output(_temp_a).overwrite_output()
    # 运行ffmpeg命令
    ffmpeg.run(joined_video)
    ffmpeg.run(joined_audio)
    input_video = ffmpeg.input(_temp_v)
    input_audio = ffmpeg.input(_temp_a).filter('asetpts', 'PTS-STARTPTS')
    whole_video = _file_path + '/whole_video.mp4'
    ffmpeg.output(input_video, input_audio, whole_video, ac=2, r='25', acodec='aac').overwrite_output().run()
    pass


if __name__ == '__main__':
    CALLBACK_IP = '10.229.129.104:8006'
    script_path = '/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt/living_space/source/script/living_space_script_0129.xlsx'
    
    # 生成底层模版和配音
    timestamp = time.strftime("%Y%m%d%H%M%S", time.localtime(time.time()))
    test_pipeline()
    
    # 拼接视频
    # timestamp = '20240129170012'
    # concat_videos_animation()
    