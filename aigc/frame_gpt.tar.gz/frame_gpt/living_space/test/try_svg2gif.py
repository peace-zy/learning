import drawsvg as draw

d = draw.Drawing(200, 200, duration=8, origin='center')

# Animate the position and color of circle
c = draw.Circle(0, 0, 20, fill='red')
# See for supported attributes:
# https://developer.mozilla.org/en-US/docs/Web/SVG/Element/animate
c.append_anim(draw.Animate('cy', '6s', '-80;80;-80',
                           repeatCount='indefinite'))
c.append_anim(draw.Animate('cx', '6s', '0;80;0;-80;0',
                           repeatCount='indefinite'))
c.append_anim(draw.Animate('fill', '6s', 'red;green;blue;yellow',
                           calc_mode='discrete',
                           repeatCount='indefinite'))
d.append(c)


# Animate a black circle around an ellipse
ellipse = draw.Path()
ellipse.M(-90, 0)
ellipse.A(90, 40, 360, True, True, 90, 0)  # Ellipse path
ellipse.A(90, 40, 360, True, True, -90, 0)
ellipse.Z()

png = draw.Image(50, 50, 20,20,'https://doctorstrange-vrlab.lianjia.com/editor/0.6.141-beta/resource/items/legacy/table_for_8.png')
d.append(png)
png.append_anim(draw.AnimateMotion(ellipse, '3s',
                                  repeatCount='indefinite'))

c2 = draw.Circle(0, 0, 10)
# See for supported attributes:
# https://developer.mozilla.org/en-US/docs/Web/SVG/Element/animate_motion
c2.append_anim(draw.AnimateMotion(ellipse, '3s',
                                  repeatCount='indefinite'))
# See for supported attributes:
# https://developer.mozilla.org/en-US/docs/Web/SVG/Element/animate_transform
c2.append_anim(draw.AnimateTransform('scale', '3s', '1,2;2,1;1,2;2,1;1,2',
                                     repeatCount='indefinite'))
d.append(c2)
import drawsvg as draw

d = draw.Drawing(200, 200, duration=8, origin='center')

# Animate the position and color of circle
c = draw.Circle(0, 0, 20, fill='red')
# See for supported attributes:
# https://developer.mozilla.org/en-US/docs/Web/SVG/Element/animate
c.append_anim(draw.Animate('cy', '6s', '-80;80;-80',
                           repeatCount='indefinite'))
c.append_anim(draw.Animate('cx', '6s', '0;80;0;-80;0',
                           repeatCount='indefinite'))
c.append_anim(draw.Animate('fill', '6s', 'red;green;blue;yellow',
                           calc_mode='discrete',
                           repeatCount='indefinite'))
d.append(c)


# Animate a black circle around an ellipse
ellipse = draw.Path()
ellipse.M(-90, 0)
ellipse.A(90, 40, 360, True, True, 90, 0)  # Ellipse path
ellipse.A(90, 40, 360, True, True, -90, 0)
ellipse.Z()

# png = draw.Image(50, 50, 20,20,'https://doctorstrange-vrlab.lianjia.com/editor/0.6.141-beta/resource/items/legacy/table_for_8.png', embed=True)
png = draw.Image(50, 50, 20,20,'/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt/living_space/test/res/bed.png', embed=True)
d.append(png)
# png.append_anim(draw.AnimateMotion(ellipse, '3s',
#                                   repeatCount='indefinite'))
png.add_key_frame(0, x=0,    y=0, opacity=0)
png.add_key_frame(2, x=50,  y=50, opacity=1)
png.add_key_frame(4, x=50,  y=10, opacity=0)

c2 = draw.Circle(0, 0, 10)
# See for supported attributes:
# https://developer.mozilla.org/en-US/docs/Web/SVG/Element/animate_motion
c2.append_anim(draw.AnimateMotion(ellipse, '3s',
                                  repeatCount='indefinite'))
# See for supported attributes:
# https://developer.mozilla.org/en-US/docs/Web/SVG/Element/animate_transform
c2.append_anim(draw.AnimateTransform('scale', '3s', '1,2;2,1;1,2;2,1;1,2', repeatCount='indefinite'))
d.append(c2)

# d.save_svg('./living_space/test/res/animated.svg')  # Save to file
d.save_svg('./living_space/test/res/animated.svg')  # Save to file