from svgelements import *

frame_svg = SVG.parse('/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt/living_space/test/res/111.svg')
print(frame_svg)
frame_svg.write_xml('/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt/living_space/test/res/111.svg_ele.svg', xml_declaration=True)

