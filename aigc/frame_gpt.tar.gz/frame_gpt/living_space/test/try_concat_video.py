# -*- coding: utf-8 -*-
from api_signature_python3 import SignatureUtil
import json, requests


ak = "fBKcP5W5matxpnmNi666"
sk = "6ciZjBmKRhKDBHDyyr7D2nG4CyszFeQeexXeyYkJ"

url = "http://lingjing-open.ke.com"
# test_url = "http://test-lingjing-open.ke.com"

# 获取模版列别
TEMPLATE_URL = '/api/open/template/list'

# 生成视频接口
GEN_VIDEO_URL = '/api/open/video/gen'

data = {
  "accountSystemId": "employee",
  "type": ["phone"],
  "identity":"18888888888"
}

# urllib2Signature
# request = urllib2.Request(url, headers={'Content-Type': 'application/json'}, data=json.dumps(data))
# request = SignatureUtil.SignatureUtil(ak, sk).urllib2Signature(request)
# print request.headers
# try:
# 	response = urllib2.urlopen(request)
# 	print response.read()
# except urllib2.HTTPError,e:
# 	print e.read()


# commomSignature
req_url = url + TEMPLATE_URL
headers = {"Content-Type":"application/json"}
headers = SignatureUtil.SignatureUtil(ak, sk).customSignature(req_url, "get", headers)
print(headers)
r = requests.get(req_url, headers=headers)
print(r.text)
