#-*-coding: utf-8-*-

import xml.etree.ElementTree as ET
from xml.etree.ElementTree import register_namespace
import os
import copy
import traceback
import uuid
import webcolors

import util
from elements import *
from animation_config.general import SvgConfig

class SvgEditor(object):
    IMAGE_NODE_IDS = []
    
    def __init__(self, 
        **kwargs
    ):
        for key, value in kwargs.items():
            setattr(self, key, value)
        if not hasattr(self, "before_tree") or (hasattr(self, "before_tree") and getattr(self, "before_tree") is None):
            raise ValueError("[{}] please set before_tree".format(self.__class__.__name__))

        if not hasattr(self, "after_tree") or (hasattr(self, "after_tree") and getattr(self, "after_tree") is None):
            raise ValueError("[{}] please set after_tree".format(self.__class__.__name__))
        
        """
        self.before_tree = copy.deepcopy(self.before_tree)
        self.after_tree = copy.deepcopy(self.after_tree)
        self.before_empty_tree = copy.deepcopy(self.before_empty_tree)
        self.after_empty_tree = copy.deepcopy(self.after_empty_tree)
        """

    @staticmethod
    def add_shadow(tree):
        root = tree.getroot()
        _keys = ["lineGroup"]
        remove_elems = {}
        style_text = """
        .{} {{
            filter: drop-shadow(4px 4px 8px rgba(0, 0, 0, 0.4));
        }}
        """
        # put image tag to last 
        first_image_index = None
        for index, elem in enumerate(root):
            if "id" in elem.attrib and elem.attrib["id"] in SvgEditor.IMAGE_NODE_IDS:
                first_image_index = index
                break

        for elem in root:
            if "type" in elem.attrib and elem.attrib["type"] in _keys:
                #print(elem.tag, elem.attrib)
                elem.attrib["class"] = elem.attrib["type"]
                if elem.attrib["type"] not in remove_elems:
                    remove_elems[elem.attrib["type"]] = []
                remove_elems[elem.attrib["type"]].append(elem)

        for k in _keys:
            if k in remove_elems:
                for e in remove_elems[k]:
                    if first_image_index is not None:
                        root.insert(first_image_index, e)
                    else:
                        root.append(e)

        for k, v in remove_elems.items():
            for elem in v:
                root.remove(elem)
        
        style_node = ET.SubElement(root, "style")
        style_node.text = "".join([style_text.format(k) for k in _keys])
        return tree

    @staticmethod
    def floorplan_opacity(tree, opacity=0.5):
        root = tree.getroot()
        _keys = ["lineGroup", "pointGroup", "lineItemGroup", "itemGroup", "defs"]

        style_text = """
        .{} {{
            opacity: {};
        }}
        """
        for elem in root:
            if "type" in elem.attrib and elem.attrib["type"] in _keys:
                #print(elem.tag, elem.attrib)
                elem.attrib["class"] = elem.attrib["type"]
                
        style_node = ET.SubElement(root, "style")
        style_node.text = "".join([style_text.format(k, opacity) for k in _keys])
        return tree

    @staticmethod
    def get_view_box_coords(view_box_id):
        #[left_top right_bottom]
        view_box_coords = self.before_item_id_and_et_ele_dict.get(view_box_id, None)
        if view_box_coords is None:
            view_box_coords = self.after_item_id_and_et_ele_dict.get(view_box_id, None)

    def _get_elems(self, bg_key, item_id):
        res = {"elems": None, "action": None}
        elems_before = self.before_item_id_and_et_ele_dict.get(item_id, None)
        elems_after = self.after_item_id_and_et_ele_dict.get(item_id, None)
        if elems_before is None and elems_after is None:
            raise ValueError("{} not exists in before and after svg".format(item_id))
        if bg_key.startswith("before"):
            if elems_before is None and elems_after is not None:
                res["elems"] = elems_after
                res["action"] = "add"
            elif elems_before is not None:
                res["elems"] = elems_before
                res["action"] = "modify"
        elif bg_key.startswith("after"):
            if elems_before is not None and elems_after is None:
                res["elems"] = elems_before
                res["action"] = "add"
            elif elems_after is not None:
                res["elems"] = elems_after
                res["action"] = "modify"

        if "empty" in bg_key and res["action"] is not None:
            res["action"] = "add"
            if bg_key.startswith("before") and item_id in self.before_empty_item_id_and_et_ele_dict:
                res["action"] = "modify"
                res["elems"] = self.before_empty_item_id_and_et_ele_dict[item_id]
            elif bg_key.startswith("after") and item_id in self.after_empty_item_id_and_et_ele_dict:
                res["action"] = "modify"
                res["elems"] = self.after_empty_item_id_and_et_ele_dict[item_id]
        return res

    def _find_elem(self, group, tag_name):
        target_elem = None
        for e in group.iter():
            if tag_name in e.tag:
                target_elem = e
                break
        return target_elem

    def set_opacity_image(self, bg_key, bg_tree, animation_detail):
        img_url = animation_detail["object_source"]
        percentage = animation_detail["percentage"]
        scale = animation_detail.get("scale", (0.5, 0.5))
        if not img_url.startswith("http"):
            raise ValueError("set_opacity_image {} is bad".format(img_url))
        
        root = bg_tree.getroot()
        # x, y, w, h
        view_box_coords = [float(e) for e in root.attrib["viewBox"].split(" ")]

        if img_url not in self.preload_new_elements["image_def"]:
            raise ValueError("[{}] set_opacity_image has no preload_image_ele [{}]".format(self.preload_new_elements))

        image_def = self.preload_new_elements["image_def"][img_url]

        image_use = ImageUseElement()(
            view_box_coords=view_box_coords,
            image_id=image_def["element_id"],
            image_size=(float(image_def["image_elem"].attrib["width"]), float(image_def["image_elem"].attrib["height"])),
            scale=scale
        )
        root.append(image_def["element"])
        image_use["use_element"].attrib["opacity"] = f"{percentage}"
        root.append(image_use["element"])
        self.IMAGE_NODE_IDS.append(image_use["element_id"])
        return bg_tree
    
    def set_opacity_other(self, bg_key, bg_tree, animation_detail):
        # wall/furniture/door/window/room/region/view_box/image
        object_type = animation_detail["object_type"]
        item_id = animation_detail["object_source"]
        percentage = animation_detail["percentage"]

        res = self._get_elems(bg_key, item_id)
        elems, action = res["elems"], res["action"]
        if elems is None:
            print("set_opacity_other item_id={} not be found".format(item_id))
            return bg_tree

        g_elem, id_type = elems["g_elem"], elems["id_type"]
        if id_type == "item":
            if object_type == "furniture":
                _tag_name = "use"
            else:
                _tag_name = "rect"
            
        elif id_type == "area":
            _tag_name = "path"

        elif id_type == "lineItem":
            _tag_name = "rect"

        elif id_type == "line":
            _tag_name = "path"
        else:
            raise ValueError("set_opacity_other not support item_id={} 's {} type".format(item_id, elem_type))

        target_elem = self._find_elem(g_elem, _tag_name)
        if target_elem is None:
            raise ValueError("set_opacity_other not support item_id={} 's {} type".format(item_id, elem_type))
        if "opacity" in target_elem.attrib:
            target_elem.attrib.pop("opacity")
        if object_type == "region":
            g_elem.attrib["opacity"] = "{}".format(float(target_elem.attrib["ori_opacity"]) * percentage)
        else:
            g_elem.attrib["opacity"] = "{}".format(percentage)
        if action == "add":
            root = bg_tree.getroot()
            new_g = ET.SubElement(root, "g")
            new_g.attrib["type"] = elems["g_addr"].attrib["type"]
            new_g.append(g_elem)
            
        return bg_tree

    def set_opacity(self, bg_key, bg_tree, animation_detail):
        object_type = animation_detail.get("object_type", None)
        if object_type is None and animation_detail["animation_type"] != "view_move":
            raise ValueError("set_opacity object_type is None {}".format(animation_detail))
        
        if object_type == "image":
            self.set_opacity_image(bg_key, bg_tree, animation_detail)            
        elif object_type != "view_move":
            self.set_opacity_other(bg_key, bg_tree, animation_detail)
     
    def set_view_box(self, bg_key, bg_tree, animation_detail):        
        item_id = animation_detail["object_source"]
        percentage = animation_detail["percentage"]
        root = bg_tree.getroot()
        res = self._get_elems(bg_key, item_id)
        elems, action = res["elems"], res["action"]
        if elems is None:
            print("set_view_box item_id={} not be found".format(item_id))
            return bg_tree
        target_elem = elems["id_addr"]
    
        if "data_x" not in target_elem.attrib or \
                "data_y" not in target_elem.attrib or \
                "width" not in target_elem.attrib or \
                "height" not in target_elem.attrib:
            raise ValueError("set_view_box item_id={} lack attrib {}".format(item_id, target_elem.attrib))
        
        root.attrib["viewBox"] = "{} {} {} {}".format(
                target_elem.attrib["data_x"],
                target_elem.attrib["data_y"],
                target_elem.attrib["width"],
                target_elem.attrib["height"]
        )   
        return bg_tree
        
    def set_view_move(self, bg_key, bg_tree, animation_detail):
        object_type = animation_detail["object_type"]
        percentage = animation_detail["percentage"]

        transition = animation_detail["animation_args"].get("transition", None)
        if transition is None:
            raise ValueError("set_view_move animation_detail lack transition {}".format(animation_detail))

        from_item_id = transition[0]
        to_item_id = transition[1]

        root = bg_tree.getroot()
        from_res = self._get_elems(bg_key, from_item_id)
        to_res = self._get_elems(bg_key, to_item_id)

        from_elems = from_res["elems"]
        to_elems = to_res["elems"]

        target_from_elem = from_elems["id_addr"]
        target_to_elem = to_elems["id_addr"]

        if target_from_elem is None or target_to_elem is None:
            print("set_view_move target_elem not be found")
            return bg_tree
        
        if "data_x" not in target_from_elem.attrib or \
                "data_y" not in target_from_elem.attrib or \
                "width" not in target_from_elem.attrib or \
                "height" not in target_from_elem.attrib:
            raise ValueError("set_view_move from_item_id={} lack attrib {}".format(from_item_id, target_from_elem.attrib))

        if "data_x" not in target_to_elem.attrib or \
                "data_y" not in target_to_elem.attrib or \
                "width" not in target_to_elem.attrib or \
                "height" not in target_to_elem.attrib:
            raise ValueError("set_view_move to_item_id={} lack attrib {}".format(to_item_id, target_to_elem.attrib))
        
        f_x = float(target_from_elem.attrib["data_x"])
        f_y = float(target_from_elem.attrib["data_y"])
        f_w = float(target_from_elem.attrib["width"])
        f_h = float(target_from_elem.attrib["height"])

        t_x = float(target_to_elem.attrib["data_x"])
        t_y = float(target_to_elem.attrib["data_y"])
        t_w = float(target_to_elem.attrib["width"])
        t_h = float(target_to_elem.attrib["height"])

        root.attrib["viewBox"] = "{} {} {} {}".format(
                f_x + (t_x - f_x) * percentage,
                f_y + (t_y - f_y) * percentage,
                f_w + (t_w - f_w) * percentage,
                f_h + (t_h - f_h) * percentage
        )   
        return bg_tree

    def set_color(self, bg_key, bg_tree, animation_detail):
        object_type = animation_detail["object_type"]
        item_id = animation_detail["object_source"]
        percentage = animation_detail["percentage"]

        transition = animation_detail["animation_args"].get("transition", None)
        if transition is None:
            raise ValueError("set_color animation_detail lack transition {}".format(animation_detail))

        res = self._get_elems(bg_key, item_id)
        elems, action = res["elems"], res["action"]
        g_elem, id_type, id_tag, id_addr = elems["g_elem"], elems["id_type"], elems["id_tag"], elems["id_addr"]

        if g_elem is None:
            print("set_opacity_other g_elem not be found")
            return bg_tree
        colors = []
        for ele in transition:
            if ele.isalpha():
                colors.append(webcolors.name_to_rgb(ele))
            elif ele.startswith("#"):
                colors.append(webcolors.hex_to_rgb(ele))

        from_color, to_color = colors[0], colors[1]

        current_color_r = from_color.red + (to_color.red - from_color.red) * percentage
        current_color_g = from_color.green + (to_color.green - from_color.green) * percentage
        current_color_b = from_color.blue + (to_color.blue - from_color.blue) * percentage
        current_color = "rgb({}, {}, {})".format(current_color_r, current_color_g, current_color_b)
        
        if object_type != "door":
            g_elem.attrib["stroke"] = current_color
        g_elem.attrib["fill"] = current_color
        if action == "add":
            root = bg_tree.getroot()
            new_g = ET.SubElement(root, "g")
            new_g.attrib["type"] = elems["g_addr"].attrib["type"]
            new_g.append(g_elem)        
        
        return bg_tree

    def set_moving_line(self, bg_key, bg_tree, animation_detail):
        object_type = animation_detail["object_type"]
        item_id = animation_detail["object_source"]
        percentage = animation_detail["percentage"]
        #color = "#F07A7A"
        color = animation_detail["animation_args"].get("color", "#222")
        back_ground_opacity = animation_detail["animation_args"].get("back_ground_opacity", 1)
        marker_type = animation_detail["animation_args"].get("marker_type", "arrow")
        stroke_width = animation_detail["animation_args"].get("stroke_width", "4")

        if marker_type not in self.preload_new_elements["marker"]:
            raise ValueError("set_moving_line not support marker_type [{}] please choose in [{}]"\
                    .format(marker_type, MarkerDefElement.MARKER_TYPES))

        transition = animation_detail["animation_args"].get("transition", None)
        if transition is None:
            raise ValueError("set_moving_line animation_detail lack transition {}".format(animation_detail))
        direction = animation_detail["animation_args"].get("direction", None) 
        if direction is None:
            raise ValueError("set_moving_line animation_detail lack direction {}".format(animation_detail))
        
        if len(transition) != len(direction):
            raise ValueError("set_moving_line number of transition should equal number of direction {}".format(animation_detail))
        def get_line(id_addr, id_tag):
            if id_tag != "path":
                raise ValueError("set_moving_line only support path vs {}".format(id_tag))
            line = id_addr.attrib["data_location"].split(",")
            
            return [float(e) for e in line]

        def analyze_moving_lines(bg_key, transition):
            moving_lines = []
            total_move_len = 0
            for index, line_id in enumerate(transition):
                res = self._get_elems(bg_key, line_id)
                elems, action = res["elems"], res["action"]
                id_tag, id_addr = elems["id_tag"], elems["id_addr"]
                if id_addr is None:
                    print("set_moving_line first_line_addr not be found")
                    return bg_tree
                line = get_line(id_addr, id_tag)
                line_move_len = 0
                # same x
                if line[0] == line[2]:
                    line_move_len = line[3] - line[1]
                # same y
                elif line[1] == line[3]:
                    line_move_len = line[2] - line[0]
                else:
                    raise ValueError("set_moving_line only support straight line {}".format(line))
                moving_lines.append({
                    "direction": direction[index],
                    "line": line,
                    "id_addr": id_addr,
                    "line_move_len": abs(line_move_len),
                    "stroke": color
                    #"stroke": id_addr.attrib["stroke"]
                })
                total_move_len += line_move_len
            return (moving_lines, total_move_len)
        moving_lines, total_move_len = analyze_moving_lines(bg_key, transition)
        current_move_len = total_move_len * percentage
        moved_lines = []
        in_line_idx = None
        in_line_percentage = None
        for idx, line in enumerate(moving_lines):
            current_move_len -= line["line_move_len"]
            if current_move_len < 0:
                in_line_idx = idx
                in_line_percentage = (current_move_len + line["line_move_len"]) / line["line_move_len"]
                break
            else:
                moved_lines.append(idx)

        def add_marker_attrib(marker_id, line_direction):
            marker_attrib = {}
            if line_direction == "right" or line_direction == "down":
                marker_attrib["marker-end"] = "url(#{})".format(marker_id)
            else:
                marker_attrib["marker-start"] = "url(#{})".format(marker_id)
            return marker_attrib

        root = bg_tree.getroot()
        g_elem = ET.SubElement(root, "g")
        for line_idx in moved_lines:
            line_direction = moving_lines[line_idx]["direction"]
            line = moving_lines[line_idx]["line"]
            line_attrib = {
                "x1": str(line[0]),
                "y1": str(line[1]),
                "x2": str(line[2]),
                "y2": str(line[3]),
                "stroke": moving_lines[line_idx]["stroke"],
                "stroke-width": stroke_width,
                "type": "moving_line",
                "stroke-linecap": "round"
            }
                    
            if line_idx == len(moving_lines) - 1:
                marker_attrib = add_marker_attrib(self.preload_new_elements["marker"][marker_type]["element_id"], line_direction)
                line_attrib.update(marker_attrib)
            line_elem = LineElement()(
                attrib=line_attrib
            )
            g_elem.append(line_elem["element"])

        if in_line_idx is not None:
            line = moving_lines[in_line_idx]["line"]
            line_direction = moving_lines[in_line_idx]["direction"]
            line_move_len = moving_lines[in_line_idx]["line_move_len"]

            line_attrib = {
                "x1": str(line[0]),
                "y1": str(line[1]),
                "x2": str(line[2]),
                "y2": str(line[3]),
                "stroke": moving_lines[in_line_idx]["stroke"],
                "stroke-width": stroke_width,
                "type": "moving_line",
                "stroke-linecap": "round"
            }
            
            # same x
            if line[0] == line[2]:
                if line_direction == "down":
                    line_attrib["y2"] = str(line[1] + line_move_len * in_line_percentage)
                elif line_direction == "up":
                    line_attrib["y1"] = str(line[3] - line_move_len * in_line_percentage)
            # same y
            elif line[1] == line[3]:
                if line_direction == "right":
                    line_attrib["x2"] = str(line[0] + line_move_len * in_line_percentage)
                elif line_direction == "left":
                    line_attrib["x1"] = str(line[2] - line_move_len * in_line_percentage)

            marker_attrib = add_marker_attrib(self.preload_new_elements["marker"][marker_type]["element_id"], line_direction)
            line_attrib.update(marker_attrib)

            line_elem = LineElement()(
                attrib=line_attrib
            )
            g_elem.append(line_elem["element"])

        bg_tree = SvgEditor.floorplan_opacity(bg_tree, opacity=back_ground_opacity)
        return bg_tree
    
    @staticmethod
    def write(tree, out_svg_file, add_shadow=False):
        register_namespace('', SvgConfig.REGISTER_TAG)
        register_namespace('xlink', SvgConfig.REGISTER_XLINK)
        if not isinstance(tree, ET.ElementTree):
            tree = ET.ElementTree(tree)
        if add_shadow:
            tree = SvgEditor.add_shadow(tree)
        tree.write(out_svg_file)

def main():
    import sys
    svg_file = sys.argv[1]
    SvgEditor = SvgEditor(svg_file=svg_file)
    return
if __name__ == "__main__":
    main()