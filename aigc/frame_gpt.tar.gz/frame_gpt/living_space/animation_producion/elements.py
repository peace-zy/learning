import xml.etree.ElementTree as ET
import uuid

import util

__all__ = ["BasicElement", "SubElement", "ImageDefElement", "ImageUseElement", "MarkerDefElement", "LineElement"]

class BasicElement(object):
    def __init__(self):
        self.ARGS = []

    def __call__(self, tag, attrib={}, **kwargs):
        elem_id = f"add_{tag}" + str(uuid.uuid1())
        attrib["id"] = elem_id
        elem = ET.Element(tag, attrib, *kwargs)
        return {"element": elem, "element_id": elem_id}

    def _check(self, **kwargs):
        for k, v in kwargs.items():
            if k not in self.ARGS:
                raise ValueError("{} need arg [{}], please set all args=[{}]".\
                        format(self.__class__.__name__, k, self.ARGS))

class SubElement(BasicElement):
    def __init__(self):
        super(ParentElement, self).__init__()
        self.ARGS = []

    def __call__(self, parent, tag, attrib={}, **kwargs):
        elem_id = f"add_{child_tag}" + str(uuid.uuid1())
        attrib["id"] = elem_id
        elem = ET.SubElement(parent, tag, attrib, **kwargs)
        return {"element": elem, "element_id": elem_id}

class ImageDefElement(object):
    def __call__(self, img_url):
        img_size = util.get_image_size(img_url)
        if img_size is None:
            raise ValueError("[{}] {} is in valid".format(self.__class__.__name__, img_url))
        defs = ET.Element("defs", {"id": "add_image"})
        image_id = "add_image_def" + str(uuid.uuid1())
        defs_g_elem = ET.SubElement(defs, "g", {"id": image_id})
        image_elem = ET.SubElement(defs_g_elem, "image")
        image_elem.attrib = {
            "x": "0",
            "y": "0",
            "width": str(img_size[0]),
            "height": str(img_size[1]),
            "xlink:href": str(img_url)
        }
        return {"element": defs, "element_id": image_id, "image_elem": image_elem} 


class ImageUseElement(BasicElement):
    def __init__(self):
        super(ImageUseElement, self).__init__()
        self.ARGS = ["view_box_coords", "image_id", "image_size", "scale"]

    def __call__(self, **kwargs):
        self._check(**kwargs)
        view_box_coords = kwargs["view_box_coords"]
        image_id = kwargs["image_id"]
        scale = kwargs["scale"]
        image_size = kwargs["image_size"]
        
        img_w = image_size[0] * scale[0]
        img_h = image_size[1] * scale[1]

        x = view_box_coords[0] + view_box_coords[2] / 2 - img_w / 2
        y = view_box_coords[1] + view_box_coords[3] / 2 - img_h / 2

        g_elem = ET.Element("g")

        transform_id = "add_image_transform_" + str(uuid.uuid1())
        g_elem.attrib = {
            "transform": f"translate({x}, {y})",
            "id": transform_id
        }

        use_elem = ET.SubElement(g_elem, "use")
        use_elem.attrib = {
            "x": "0",
            "y": "0",
            "xlink:href": f"#{image_id}",
            "no-point-event": "true",
            "transform": f"scale{scale}",
        }
        return {"element": g_elem, "element_id": transform_id, "use_element": use_elem} 

class MarkerDefElement(BasicElement):
    MARKER_TYPES = ["arrow", "dot"]
    def __init__(self):
        super(MarkerDefElement, self).__init__()
        self.ARGS = ["marker_type"]
        
    def __call__(self, **kwargs):
        self._check(**kwargs)
        marker_type = kwargs["marker_type"]
        
        marker_defs = ET.Element("defs", {"id": "add_marker"})
        marker = ET.SubElement(marker_defs, "marker")
        if marker_type not in self.MARKER_TYPES:
           raise ValueError("[{}] {} is not support. choose from [{}]".format(
                self.__class__.__name__, marker_type, self.MARKER_TYPES))
        if marker_type == "arrow":
            """
            <defs>
                <marker
                id="arrow"
                viewBox="0 0 10 10"
                refX="5"
                refY="5"
                markerWidth="4"
                markerHeight="4"
                orient="auto-start-reverse">
                <path d="M 0 0 L 10 5 L 0 10 z" />
                </marker>
            </defs>
            """
            marker_id = "add_maker_arrow_" + str(uuid.uuid1())
            marker.attrib = {
                "id": f"{marker_id}",
                "viewBox": "0 0 10 10",
                "refX": "5",
                "refY": "5",
                "markerWidth": "4",
                "markerHeight": "4",
                "orient": "auto-start-reverse"
            }

            marker_path = ET.SubElement(marker, "path")
            marker_path.attrib = {
                "d": "M 0 0 L 10 5 L 0 10 z"
            }
        elif marker_type == "dot":
            """
            <defs>
                <marker
                id="dot"
                viewBox="0 0 10 10"
                refX="5"
                refY="5"
                markerWidth="5"
                markerHeight="5">
                <circle cx="5" cy="5" r="5" fill="red" />
                </marker>
            </defs>
            """
            marker_id = "add_maker_dot_" + str(uuid.uuid1())
            marker.attrib = {
                "id": f"{marker_id}",
                "viewBox": "0 0 10 10",
                "refX": "5",
                "refY": "5",
                "markerWidth": "3",
                "markerHeight": "3",
            }

            marker_path = ET.SubElement(marker, "circle")
            marker_path.attrib = {
                "cx": "5",
                "cy": "5",
                "r": "5",
            }
            
        return {"element": marker_defs, "element_id": marker_id}  

class LineElement(BasicElement):
    def __init__(self):
        super(LineElement, self).__init__()
        self.ARGS = ["attrib"]
        
    def __call__(self, **kwargs):
        self._check(**kwargs)
        line_id = "add_line_" + str(uuid.uuid1())
        line_attrib = kwargs["attrib"]
        line_attrib["id"] = line_id
        line_elem = ET.Element("line")
        line_elem.attrib = line_attrib
            
        return {"element": line_elem, "element_id": line_id} 