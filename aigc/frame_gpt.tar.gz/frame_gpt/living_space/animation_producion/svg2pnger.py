#-*-coding: utf-8-*-
import os
from selenium import webdriver
from pyvirtualdisplay import Display

class Svg2Pnger(object):
    def __init__(self, png_output_path, display_window_size):
        self.display_window_size = display_window_size
        self.png_output_path = png_output_path
        self._init_display()
        self._init_driver()
        
    def _init_display(self):
        self.display = Display(visible=0, size=self.display_window_size)
        self.display.start()

    def _init_driver(self):
        self.driver = webdriver.Firefox()

    def svg_to_png(self, svg_file, subdir=None):
        svg_basic_fname = os.path.splitext(os.path.basename(svg_file))[0]
        self.driver.get("file:///{}".format(os.path.abspath(svg_file)))
        self.driver.get_screenshot_as_file(
            os.path.join(
                self.png_output_path,
                "" if subdir is None else subdir,
                f"{svg_basic_fname}.png"
            )
        )

    def release(self):
        self.driver.close()
        self.driver.quit()
        self.display.stop()
