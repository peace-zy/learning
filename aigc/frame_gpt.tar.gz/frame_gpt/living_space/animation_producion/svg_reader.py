#-*-coding: utf-8-*-
import xml.etree.ElementTree as ET
import copy
import os
import traceback
from animation_config.general import SvgConfig

__all__ =["SvgReader"]

class SvgReader(object):
    @staticmethod
    def load_svg(in_svg, modify_image_href=False):
        # return ET.ElementTree
        if in_svg is None:
            raise ValueError("[{}] set svg_file and svg_data_str".format("SvgReader"))
        try:
            if isinstance(in_svg, str):
                if os.path.exists(in_svg):
                    tree = ET.parse(in_svg)
                else:
                    tree = ET.ElementTree(ET.fromstring(in_svg))
            elif isinstance(in_svg, ET.Element):
                tree = copy.deepcopy(ET.ElementTree(in_svg))
            elif isinstance(in_svg, ET.ElementTree):
                tree = copy.deepcopy(in_svg)
            else:
                raise ValueError("now support file_path, xml_str, \
                        xml.etree.ElementTree.Element, xml.etree.ElementTree.ElementTree")
            if modify_image_href:
                for elem in tree.iter():
                    if SvgConfig.SVG_PREFIX_TAG + "image" == elem.tag:
                        elem.attrib[SvgConfig.SVG_XLINK + "href"] = "http:" + elem.attrib[SvgConfig.SVG_XLINK + "href"]
        except Exception as e:
            traceback.print_exc()
            return None
        return tree

def main():
    import sys
    svg_file = sys.argv[1]
    tree = SvgReader.load_svg(in_svg=svg_file, modify_image_href=True)
    print(tree)
    return
if __name__ == "__main__":
    main()