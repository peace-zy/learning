import json
import pandas as pd

data = {
    "video": [
        {
            "scene_id": 1,                   # 分镜id
            "scene_desc": "当前问题",              # 分镜描述 @ydx
            "scene_duration": None,          # 相对于当前分镜的结束时间 视频模版的时间, 设置最大值. @ydx
            "background": "before", # 背景基于哪个户型的动效 @ydx
            "empty_plan": False,       # 背景是否为空户型 @ydx
            "canvas_coords": [0, 0, 1920, 1080],  # viewbox 坐标: 左上x，左上y，宽，高 @zy
            "template_id": "立木片段模版",
            "clips": [                # 段落(配音)粒度的片段
                {
                    "template_no": 1, #
                    "template_clip_id": 1,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "view_box",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-4VIBT8lRHk4Bnj", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                        "t8":"改造前",
                        "i4": "https://file.ljcdn.com/nebula/black_tag_1705741066230.png",
                        "t0": "63㎡",
                        "t1": "2室1厅"
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "这是一个63平米的2室1厅，原本可容纳1家3口居住",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 1,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 2, #
                    "template_clip_id": 2,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "image",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "https://file.ljcdn.com/nebula/情侣贴纸_1705652501667.png", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 0.5,     # 相对于当前分镜入场结束时间
                    "out_start": -1.5, # 相对于当前分镜出场开始时间
                    "out_end": -1,     # 相对于当前分镜出场结束时间
                    "animation_detail": { # 动画详情               
                    },             # 特效细节json
                    
                    "template_detail": {
                        "t8": "改造前",
                        "i4":"https://file.ljcdn.com/nebula/black_tag_1705741066230.png",
                        "t0":"63㎡",
                        "t1":"2室1厅",
                        "i1":"https://file.ljcdn.com/nebula/哭脸_1705652459271.png"
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "当单身或2人居住时，难免存在一些问题",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 2,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 3, #
                    "template_clip_id": 3,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "region",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-jV2neRLRK2w6TZ", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 0.5,     # 相对于当前分镜入场结束时间
                    "out_start": -0.5, # 相对于当前分镜出场开始时间
                    "out_end": 0,     # 相对于当前分镜出场结束时间
                    "animation_detail": { # 动画详情               
                    },             # 特效细节json
                    
                    "template_detail": {
                        "t8":"改造前",
                        "i4": "https://file.ljcdn.com/nebula/black_tag_1705741066230.png",
                        "t0": "63㎡",
                        "t1": "2室1厅",
                        "t2": "公共面积少，卧室浪费",
                        "i1": "https://file.ljcdn.com/nebula/哭脸_1705652459271.png"
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "首先公共面积少，浪费了一间卧室",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 3,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 3, #
                    "template_clip_id": 3,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "region",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-vvz8J8lrk2U65J", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 0.5,     # 相对于当前分镜入场结束时间
                    "out_start": -0.5, # 相对于当前分镜出场开始时间
                    "out_end": 0,     # 相对于当前分镜出场结束时间
                    "animation_detail": { # 动画详情               
                    },             # 特效细节json
                    
                    "template_detail": {
                        "t8":"改造前",
                        "i4":"https://file.ljcdn.com/nebula/black_tag_1705741066230.png",
                        "t0":"63㎡",
                        "t1":"2室1厅",
                        "t2":"公共面积少，卧室浪费",
                        "i1":"https://file.ljcdn.com/nebula/哭脸_1705652459271.png"
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "首先公共面积少，浪费了一间卧室",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 3,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 4, #
                    "template_clip_id": 4,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "region",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-6LB3UilrK31kE2", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 0.5,     # 相对于当前分镜入场结束时间
                    "out_start": -0.5, # 相对于当前分镜出场开始时间
                    "out_end": 0,     # 相对于当前分镜出场结束时间
                    "animation_detail": { # 动画详情               
                    },             # 特效细节json
                    
                    "template_detail": {
                        "t8": "改造前",
                        "i4": "https://file.ljcdn.com/nebula/black_tag_1705741066230.png",
                        "t0": "63㎡",
                        "t1": "2室1厅",
                        "t2": "公共面积少，卧室浪费",
                        "t3": "卫生间正对入户门，面积小",
                        "i1": "https://file.ljcdn.com/nebula/哭脸_1705652459271.png"
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "其次卫生间正对入户门，且面积较小，淋浴区拥挤",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 4,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 5, #
                    "template_clip_id": 5,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "region",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-p3fSiJlrK33Pc1", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 0.5,     # 相对于当前分镜入场结束时间
                    "out_start": -0.5, # 相对于当前分镜出场开始时间
                    "out_end": 0,     # 相对于当前分镜出场结束时间
                    "animation_detail": { # 动画详情               
                    },             # 特效细节json
                    
                    "template_detail": {
                        "t8":"改造前",
                        "i4": "https://file.ljcdn.com/nebula/black_tag_1705741066230.png",
                        "t0":"63㎡",
                        "t1":"2室1厅",
                        "t2":"公共面积少，卧室浪费",
                        "t3":"卫生间正对入户门，面积小",
                        "t4":"主卧小，缺少办公&娱乐空间",
                        "i1":"https://file.ljcdn.com/nebula/哭脸_1705652459271.png"
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "最后是主卧小，缺少办公与娱乐的空间",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 5,
                    "sound_detail": "url"                    # 声音特效
                },
            ]
        },
        {
            "scene_id": 2,                   # 分镜id
            "scene_desc": "业主诉求",              # 分镜描述 @ydx
            "scene_duration": None,          # 相对于当前分镜的结束时间 视频模版的时间, 设置最大值. @ydx
            "background": "after", # 背景基于哪个户型的动效 @ydx
            "empty_plan": False,       # 背景是否为空户型 @ydx
            "canvas_coords": [0, 0, 1920, 1080],  # viewbox 坐标: 左上x，左上y，宽，高 @zy
            "template_id": "立木片段模版",
            "clips": [                # 段落(配音)粒度的片段
                {
                    "template_no": 2, #
                    "template_clip_id": 1,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "view_box",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-4VIBT8lRHk4Bnj", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                        "i4":"改造后",
                        "t8":"https://file.ljcdn.com/nebula/yellow_tag_1705741066229.png",
                        "t0":"63㎡",
                        "t1":"两居改一居"
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "我们对房屋进行了整体改造",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 6,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 3, #
                    "template_clip_id": 2,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "region",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-9W1fK7lRoJyPyj", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 0.5,     # 相对于当前分镜入场结束时间
                    "out_start": -0.5, # 相对于当前分镜出场开始时间
                    "out_end": 0,     # 相对于当前分镜出场结束时间
                    "animation_detail": { # 动画详情               
                    },             # 特效细节json
                    
                    "template_detail": {
                        "i4":"改造后",
                        "t8":"https://file.ljcdn.com/nebula/yellow_tag_1705741066229.png",
                        "t0":"63㎡",
                        "t1":"两居改一居",
                        "t2":"一体化休闲客餐厅"
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "第一，设置一体化休闲客餐厅",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 7,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 4, #
                    "template_clip_id": 3,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "region",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-DH2eTBLrOK0uZR", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 0.5,     # 相对于当前分镜入场结束时间
                    "out_start": -0.5, # 相对于当前分镜出场开始时间
                    "out_end": 0,     # 相对于当前分镜出场结束时间
                    "animation_detail": { # 动画详情               
                    },             # 特效细节json
                    
                    "template_detail": {
                        "i4":"改造后",
                        "t8":"https://file.ljcdn.com/nebula/yellow_tag_1705741066229.png",
                        "t0":"63㎡",
                        "t1":"两居改一居",
                        "t2":"一体化休闲客餐厅",
                        "t3":"增加玄关和淋浴区"
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "第二，卫生间移位，增加玄关区和淋浴房",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 8,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 5, #
                    "template_clip_id": 4,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "region",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-VFj56ELrOK1nyg", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 0.5,     # 相对于当前分镜入场结束时间
                    "out_start": -0.5, # 相对于当前分镜出场开始时间
                    "out_end": 0,     # 相对于当前分镜出场结束时间
                    "animation_detail": { # 动画详情               
                    },             # 特效细节json
                    
                    "template_detail": {
                        "i4":"改造后",
                        "t8":"https://file.ljcdn.com/nebula/yellow_tag_1705741066229.png",
                        "t0":"63㎡",
                        "t1":"两居改一居",
                        "t2":"一体化休闲客餐厅",
                        "t3":"增加玄关和淋浴区",
                        "t4":"扩大卧室，增加书房"
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "第三，扩大卧室面积，增加书房",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 9,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 9, #
                    "template_clip_id": 4,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": None,   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": None, # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { # 动画详情               
                    },             # 特效细节json
                    
                    "template_detail": {
                        "i4":"改造后",
                        "t8":"https://file.ljcdn.com/nebula/yellow_tag_1705741066229.png",
                        "t0":"63㎡",
                        "t1":"两居改一居",
                        "t2":"一体化休闲客餐厅",
                        "t3":"增加玄关和淋浴区",
                        "t4":"扩大卧室，增加书房",
                        "i1":"https://file.ljcdn.com/nebula/笑脸_1705652556730.png"
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "接下来我们看看详细的全屋改造思路",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 10,
                    "sound_detail": "url"                    # 声音特效
                },
            ]
        },
        {
            "scene_id": 3,                   # 分镜id
            "scene_desc": "开始改造",              # 分镜描述 @ydx
            "scene_duration": None,          # 相对于当前分镜的结束时间 视频模版的时间, 设置最大值. @ydx
            "background": "before", # 背景基于哪个户型的动效 @ydx
            "empty_plan": True,       # 背景是否为空户型 @ydx
            "canvas_coords": [0, 0, 1920, 1080],  # viewbox 坐标: 左上x，左上y，宽，高 @zy
            "template_id": "立木片段模版",
            "clips": [                # 段落(配音)粒度的片段
                {
                    "template_no": 6, #
                    "template_clip_id": 9,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "view_box",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-4VIBT8lRHk4Bnj", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "这是改造前的户型墙体分布情况，我们分步骤看如何改造",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 11,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 10,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": None,   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": None, # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "view_move": { # 动效类型
                            "start": 0,             # 相对于当前分镜动效开始时间
                            "end": 1,               # 相对于当前分镜动效结束时间
                            "transition": [         # 变换设置
                                "u-4VIBT8lRHk4Bnj", 
                                "u-iwAIbRLrIZo6UI"
                            ]
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "从入户门左侧的厨房开始",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 12,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "wall",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-D8q7s8lRhICt9B", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": -2, # 相对于当前分镜出场开始时间
                    "out_end": -1,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "color": { # 动效类型
                            "start": 1,             # 相对于当前分镜动效开始时间
                            "end": 1.5,               # 相对于当前分镜动效结束时间
                            "transition": [         # 变换设置
                                "black", 
                                "#f07a7a"
                            ]
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "第一个改造点,我们拆除厨房墙体,防止空间太小",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 13,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "wall",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-E95cI8lRhib5RP", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": -2, # 相对于当前分镜出场开始时间
                    "out_end": -1,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "color": {# 动效类型
                            "start": 1,             # 相对于当前分镜动效开始时间
                            "end": 1.5,               # 相对于当前分镜动效结束时间
                            "transition": [         # 变换设置
                                "black", 
                                "#f07a7a"
                            ]
                        } 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "第一个改造点,我们拆除厨房墙体,防止空间太小",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 13,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": None,   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": None, # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "打通了厨房与餐厅的空间",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 14,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "furniture",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-nXFA10LrhHcMRp", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 0.5,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "设置U型厨房,扩大操作和储物空间",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 15,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "furniture",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-7I56nXlrhhE2J3", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 0.5,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "设置U型厨房,扩大操作和储物空间",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 15,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "furniture",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-QqI0ZjLRHHfIGQ", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 0.5,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "厨房外设置餐边柜与餐桌,餐厨一体增加烹饪乐趣",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 16,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": None,   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": None, # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "view_move": { # 动效类型
                            "start": 0,             # 相对于当前分镜动效开始时间
                            "end": 1,               # 相对于当前分镜动效结束时间
                            "transition": [         # 变换设置
                                "u-iwAIbRLrIZo6UI", 
                                "u-20vZYPlrJ042hz"
                            ]
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "向右看,我们来到次卧的位置",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 17,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "wall",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-NdVhA7lRhie22q", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": -2, # 相对于当前分镜出场开始时间
                    "out_end": -1,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "color": { # 动效类型
                            "start": 1,             # 相对于当前分镜动效开始时间
                            "end": 1.5,               # 相对于当前分镜动效结束时间
                            "transition": [         # 变换设置
                                "black", 
                                "#f07a7a"
                            ]
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "第二个改造点,我们要打造二人世界的娱乐天地,拆除次卧与餐厅的分隔墙",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 18,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "wall",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-v3g53KLRhiE22q", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": -2, # 相对于当前分镜出场开始时间
                    "out_end": -1,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "color": { # 动效类型
                            "start": 1,             # 相对于当前分镜动效开始时间
                            "end": 1.5,               # 相对于当前分镜动效结束时间
                            "transition": [         # 变换设置
                                "black", 
                                "#f07a7a"
                            ]
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "第二个改造点,我们要打造二人世界的娱乐天地,拆除次卧与餐厅的分隔墙",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 18,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "wall",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-8uU18OLRhiEj4z", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": -2, # 相对于当前分镜出场开始时间
                    "out_end": -1,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "color": { # 动效类型
                            "start": 1,             # 相对于当前分镜动效开始时间
                            "end": 1.5,               # 相对于当前分镜动效结束时间
                            "transition": [         # 变换设置
                                "black", 
                                "#f07a7a"
                            ]
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "第二个改造点,我们要打造二人世界的娱乐天地,拆除次卧与餐厅的分隔墙",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 18,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "wall",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-ALYn6wLRhIej4z", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": -2, # 相对于当前分镜出场开始时间
                    "out_end": -1,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "color": { # 动效类型
                            "start": 1,             # 相对于当前分镜动效开始时间
                            "end": 1.5,               # 相对于当前分镜动效结束时间
                            "transition": [         # 变换设置
                                "black", 
                                "#f07a7a"
                            ]
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "第二个改造点,我们要打造二人世界的娱乐天地,拆除次卧与餐厅的分隔墙",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 18,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "wall",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-GTGUgtLrhiEJ4z", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": -2, # 相对于当前分镜出场开始时间
                    "out_end": -1,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "color": { # 动效类型
                            "start": 1,             # 相对于当前分镜动效开始时间
                            "end": 1.5,               # 相对于当前分镜动效结束时间
                            "transition": [         # 变换设置
                                "black", 
                                "#f07a7a"
                            ]
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "第二个改造点,我们要打造二人世界的娱乐天地,拆除次卧与餐厅的分隔墙",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 18,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": None,   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": None, # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "打造一体化客餐厅",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 19,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "furniture",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-k9bd5XlR8yu2On", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 0.5,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "餐桌前设沙发休闲区,空间更通透,满足日常娱乐互动",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 20,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "furniture",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-5P680pLRHHw1QF", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 0.5,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "餐桌前设沙发休闲区,空间更通透,满足日常娱乐互动",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 20,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "furniture",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-2bSTo4lr8z18Zi", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 0.5,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "餐桌前设沙发休闲区,空间更通透,满足日常娱乐互动",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 20,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "furniture",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-F6ihl0LRHHWXKa", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 0.5,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "餐桌前设沙发休闲区,空间更通透,满足日常娱乐互动",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 20,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": None,   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": None, # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "view_move": { # 动效类型
                            "start": 0,             # 相对于当前分镜动效开始时间
                            "end": 1,               # 相对于当前分镜动效结束时间
                            "transition": [         # 变换设置
                                "u-20vZYPlrJ042hz", 
                                "u-44c2vgLRj0hfqP"
                            ]
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "向下看,我们来到了卧室",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 21,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "wall",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-TBcLuBLrhiej4x", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": -3, # 相对于当前分镜出场开始时间
                    "out_end": -2,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "color": { # 动效类型
                            "start": 1,             # 相对于当前分镜动效开始时间
                            "end": 1.5,               # 相对于当前分镜动效结束时间
                            "transition": [         # 变换设置
                                "black", 
                                "#f07a7a"
                            ]
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "第三个改造点,为了让休息空间更加宽敞、入户门不正对着卫生间,我们拆除卧室与卫生间隔墙,重新规划布局",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 22,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "wall",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-D5he2vlrHiej4X", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": -3, # 相对于当前分镜出场开始时间
                    "out_end": -2,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "color": { # 动效类型
                            "start": 1,             # 相对于当前分镜动效开始时间
                            "end": 1.5,               # 相对于当前分镜动效结束时间
                            "transition": [         # 变换设置
                                "black", 
                                "#f07a7a"
                            ]
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "第三个改造点,为了让休息空间更加宽敞、入户门不正对着卫生间,我们拆除卧室与卫生间隔墙,重新规划布局",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 22,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "wall",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-EA1PFvlrHiVVNC", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": -3, # 相对于当前分镜出场开始时间
                    "out_end": -2,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "color": { # 动效类型
                            "start": 1,             # 相对于当前分镜动效开始时间
                            "end": 1.5,               # 相对于当前分镜动效结束时间
                            "transition": [         # 变换设置
                                "black", 
                                "#f07a7a"
                            ]
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "第三个改造点,为了让休息空间更加宽敞、入户门不正对着卫生间,我们拆除卧室与卫生间隔墙,重新规划布局",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 22,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "wall",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-351y0slr8YE9Je", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 1,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "color": { # 动效类型
                            "start": 1,             # 相对于当前分镜动效开始时间
                            "end": 2,               # 相对于当前分镜动效结束时间
                            "initial": "#8CB2FF",
                            "transition": [         # 变换设置
                                "#8CB2FF", 
                                "black"
                            ]
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "正对入户门新建墙体,将空间一分为三",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 23,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "wall",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-49h08slRhhpc4a", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 1,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "color": { # 动效类型
                            "start": 1,             # 相对于当前分镜动效开始时间
                            "end": 2,               # 相对于当前分镜动效结束时间
                            "initial": "#8CB2FF",
                            "transition": [         # 变换设置
                                "#8CB2FF", 
                                "black"
                            ]
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "正对入户门新建墙体,将空间一分为三",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 23,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "wall",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-KHeoluLRhhPc4C", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 1,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "color": { # 动效类型
                            "start": 1,             # 相对于当前分镜动效开始时间
                            "end": 2,               # 相对于当前分镜动效结束时间
                            "initial": "#8CB2FF",
                            "transition": [         # 变换设置
                                "#8CB2FF", 
                                "black"
                            ]
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "正对入户门新建墙体,将空间一分为三",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 23,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "wall",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-cVKLKlLRHHPC4A", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 1,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "color": { # 动效类型
                            "start": 1,             # 相对于当前分镜动效开始时间
                            "end": 2,               # 相对于当前分镜动效结束时间
                            "initial": "#8CB2FF",
                            "transition": [         # 变换设置
                                "#8CB2FF", 
                                "black"
                            ]
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "正对入户门新建墙体,将空间一分为三",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 23,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "door",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-2368GALR8YT8S6", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 1,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "color": { # 动效类型
                            "start": 1,             # 相对于当前分镜动效开始时间
                            "end": 2,               # 相对于当前分镜动效结束时间
                            "initial": "#8CB2FF",
                            "transition": [         # 变换设置
                                "#8CB2FF", 
                                "black"
                            ]
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "正对入户门新建墙体,将空间一分为三",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 23,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "wall",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-Nq9CW4LR8y4EOH", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 1,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "color": { # 动效类型
                            "start": 1,             # 相对于当前分镜动效开始时间
                            "end": 2,               # 相对于当前分镜动效结束时间
                            "initial": "#8CB2FF",
                            "transition": [         # 变换设置
                                "#8CB2FF", 
                                "black"
                            ]
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "正对入户门新建墙体,将空间一分为三",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 23,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": True,  # 是否使用动画, 如果 @ydx
                    "object_type": "wall",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-NbT16TLrhh340Q", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 1,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                        "color": { # 动效类型
                            "start": 1,             # 相对于当前分镜动效开始时间
                            "end": 2,               # 相对于当前分镜动效结束时间
                            "initial": "#8CB2FF",
                            "transition": [         # 变换设置
                                "#8CB2FF", 
                                "black"
                            ]
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "正对入户门新建墙体,将空间一分为三",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 23,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "furniture",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-1kIEfbLRHhTjR5", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 1,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "左侧设玄关柜,方便进门后收纳衣物和鞋子",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 24,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "furniture",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-NEQjx5LRhHFuxw", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 1,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "中间设置干湿分离卫生间,扩大淋浴区",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 25,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "furniture",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-W41vg2lrHhjnnQ", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 1,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "洗澡如厕互不影响,方便多人使用",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 26,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "furniture",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-IjEYawLRhhRAv0", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 1,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "扩大了卧室面积,增加独立书房,满足日常学习办公",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 27,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "furniture",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-w67T06LRHHmGVq", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 1,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "扩大了卧室面积,增加独立书房,满足日常学习办公",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 27,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "furniture",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-iJN9AALR8z2Qrs", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 1,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "扩大了卧室面积,增加独立书房,满足日常学习办公",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 27,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "furniture",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-bzjne8lR914ePp", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 1,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "扩大了卧室面积,增加独立书房,满足日常学习办公",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 27,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 11,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "furniture",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-ygxm7glr8Z4jCV", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 1,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "扩大了卧室面积,增加独立书房,满足日常学习办公",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 27,
                    "sound_detail": "url"                    # 声音特效
                },
            ]
        },
        {
            "scene_id": 4,                   # 分镜id
            "scene_desc": "改造完成",              # 分镜描述 @ydx
            "scene_duration": None,          # 相对于当前分镜的结束时间 视频模版的时间, 设置最大值. @ydx
            "background": "after", # 背景基于哪个户型的动效 @ydx
            "empty_plan": False,       # 背景是否为空户型 @ydx
            "canvas_coords": [0, 0, 1920, 1080],  # viewbox 坐标: 左上x，左上y，宽，高 @zy
            "template_id": "立木片段模版",
            "clips": [                # 段落(配音)粒度的片段
                {
                    "template_no": 6, #
                    "template_clip_id": 9,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "view_box",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": "u-4VIBT8lRHk4Bnj", # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "再整体回顾一下,两居改一居,适合两人世界的1居室就改造完成啦",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 28,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 9,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": None,   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": None, # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": None,     # 相对于当前分镜入场开始时间
                    "in_end": None,     # 相对于当前分镜入场结束时间
                    "out_start": None, # 相对于当前分镜出场开始时间
                    "out_end": None,     # 相对于当前分镜出场结束时间
                    "animation_detail": { 
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "再整体回顾一下,两居改一居,适合两人世界的1居室就改造完成啦",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 28,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 9,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "moving_line",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": None, # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 0,     # 相对于当前分镜入场结束时间
                    "out_start": 0, # 相对于当前分镜出场开始时间
                    "out_end": 0,     # 相对于当前分镜出场结束时间
                    "animation_detail": {
                        "moving_line": { # 动效类型
                            "start": 0,             # 相对于当前分镜动效开始时间
                            "end": -4,               # 相对于当前分镜动效结束时间
                            "transition": [         # 变换设置
                                "u-g5GQGWLRkfi5b4", 
                                "u-h5dwL6lRkfi7ir"
                            ],
                            "direction": ["down", "right"],
                            "color": "#222",
                            "back_ground_opacity": 0.5,
                            "marker_type": "arrow"
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "最后我们进行生活动线模拟。餐厨,洗,切,炒,盛,吃,为流畅的L型动线,一气呵成",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 29,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 9,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "moving_line",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": None, # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 0,     # 相对于当前分镜入场结束时间
                    "out_start": 0, # 相对于当前分镜出场开始时间
                    "out_end": 0,     # 相对于当前分镜出场结束时间
                    "animation_detail": {
                        "moving_line": { # 动效类型
                            "start": 0,             # 相对于当前分镜动效开始时间
                            "end": -4,               # 相对于当前分镜动效结束时间
                            "transition": [         # 变换设置
                                "u-91RNd3LRRA6EhK", 
                                "u-Xx4WeZlrRDInee",
                                "u-BtxHPzlrrDil09"
                            ],
                            "direction": ["up", "right", "up"],
                            "color": "#222",
                            "back_ground_opacity": 0.5,
                            "marker_type": "arrow"
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "招待客人时,脱鞋,洗手,聚餐,玩耍,区域集中,动静分区明确,不影响卧室休息/办公",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 30,
                    "sound_detail": "url"                    # 声音特效
                },
                {
                    "template_no": 6, #
                    "template_clip_id": 9,     # 动效id
                    "use": False,  # 是否使用动画, 如果 @ydx
                    "object_type": "moving_line",   # 元素类型 墙体/家具/门/窗/分间/区域/镜头视窗/图片
                    "object_source": None, # 元素来源 墙体/家具/门/窗/分间/区域/镜头视窗: 前端显示item_id 图片: url
                    "in_start": 0,     # 相对于当前分镜入场开始时间
                    "in_end": 0,     # 相对于当前分镜入场结束时间
                    "out_start": 0, # 相对于当前分镜出场开始时间
                    "out_end": 0,     # 相对于当前分镜出场结束时间
                    "animation_detail": {
                        "moving_line": { # 动效类型
                            "start": 0,             # 相对于当前分镜动效开始时间
                            "end": -4,               # 相对于当前分镜动效结束时间
                            "transition": [         # 变换设置
                                "u-91RNd3LRRA6EhK", 
                                "u-QBxhXIlrRA6fea",
                                "u-e2C1FbLrrA6HkJ"
                            ],
                            "direction": ["up", "right", "up"],
                            "color": "#222",
                            "back_ground_opacity": 0.5,
                            "marker_type": "arrow"
                        }
                    },             # 特效细节json
                    "template_detail": {
                    },           # 分镜中展示文本 @ydx
                    "subtitle": "招待客人时,脱鞋,洗手,聚餐,玩耍,区域集中,动静分区明确,不影响卧室休息/办公",           # 特效的解读文案字幕 @ydx
                    "sound_duration": None,                    # 旁白持续时间s, 秒 @ydx 解析完csv之后, 需要计算音频.
                    "sound_after_delay": 0,                  # 旁白结束后停留秒
                    "subtitle_no": 30,
                    "sound_detail": "url"                    # 声音特效
                },
            ]
        },
    ]
}
def get_absolute_time(time_offset, absolute_start_time, relative_time_length):
    if time_offset < 0:
        return absolute_start_time + relative_time_length + time_offset
    else:
        return absolute_start_time + time_offset

word_time = 0.25
#clip_group = pd.DataFrame(scene["clips"]).groupby("template_clip_id")
# u-5Lk5gQLRrA86de
for scene in data["video"]:
    for one_clip in scene["clips"]:
        subtitle = one_clip["subtitle"]
        sound_after_delay = one_clip["sound_after_delay"]
        sound_duration = len(subtitle) * word_time
        one_clip["sound_duration"] = sound_duration
            
    clip_group = pd.DataFrame(scene["clips"]).groupby("subtitle_no")
    """
    for clips in clip_group: 
        print(len(clips))
        print(clips[1])
    """
    clip_start_time_dict = {}
    scene_total_time = 0
    for clips in clip_group: 
        subtitle_no = clips[1]["subtitle_no"].to_list()[0]
        sound_after_delay = clips[1]["sound_after_delay"].to_list()[0]
        sound_duration = clips[1]["sound_duration"].to_list()[0]
        #print(template_clip_id, type(template_clip_id))
        #print(sound_after_delay, type(sound_after_delay))
        #print(sound_duration, type(sound_duration))
        clip_start_time_dict[subtitle_no] = scene_total_time
        scene_total_time += sound_duration + sound_after_delay
        
    scene["scene_duration"] = scene_total_time
    print("scene_{}={}s".format(scene["scene_id"], scene_total_time))


    for one_clip in scene["clips"]:
        subtitle_no = one_clip["subtitle_no"]
        clip_start_time = clip_start_time_dict[subtitle_no]      
        clip_duration = one_clip["sound_duration"] + one_clip["sound_after_delay"]
        
        if one_clip["in_start"] is None:
            one_clip["in_start"] = clip_start_time
        else:
            one_clip["in_start"] = get_absolute_time(one_clip["in_start"], clip_start_time, clip_duration)
        
        if one_clip["in_end"] is None:
            one_clip["in_end"] = clip_start_time
        else:
            one_clip["in_end"] = get_absolute_time(one_clip["in_end"], clip_start_time, clip_duration)

        if one_clip["object_type"] is None:
            one_clip["out_start"] = clip_start_time + clip_duration
            one_clip["out_end"] = clip_start_time + clip_duration
        else:
            if one_clip["out_start"] is None:
                one_clip["out_start"] = scene_total_time
            else:
                one_clip["out_start"] = get_absolute_time(one_clip["out_start"], clip_start_time, clip_duration)
            
            if one_clip["out_end"] is None:
                one_clip["out_end"] = scene_total_time
            elif one_clip["out_end"] == 0:
                one_clip["out_end"] = clip_start_time + clip_duration
            else:
                one_clip["out_end"] = get_absolute_time(one_clip["out_end"], clip_start_time, clip_duration)
        if one_clip["animation_detail"]:
            for animation_type, animation_args in one_clip["animation_detail"].items():
                one_clip["animation_detail"][animation_type]["start"] = get_absolute_time(
                                                            one_clip["animation_detail"][animation_type]["start"],
                                                            clip_start_time,
                                                            clip_duration)
                one_clip["animation_detail"][animation_type]["end"] = get_absolute_time(
                                                            one_clip["animation_detail"][animation_type]["end"],
                                                            clip_start_time,
                                                            clip_duration)
        

with open("debug_sample.json", "w") as f:
    json.dump(data, f, indent=4, ensure_ascii=False)
