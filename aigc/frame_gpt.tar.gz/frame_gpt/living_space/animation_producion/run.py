#-*-coding: utf-8-*-
import os
import json
import copy
import argparse
import time
from tqdm import tqdm

from frame_diff import FrameDiffer
from frame_to_svg import frame_to_svg
from svg_sequence_script_creator import SVGSequenceScriptCreator
from frame_vector_processor import process_frame_vector
from svg_reader import SvgReader
from svg_editor import SvgEditor
from preprocessor import Preprocessor
from multiple_threader import MultipleThreader
from animation_config.general import SVGSequenceScriptCreatorConfig

def get_args():
    parser = argparse.ArgumentParser() 
    parser.add_argument("--before_json_file", type=str, default=None,
                        help="before_json_file.")
    parser.add_argument("--after_json_file", type=str, default=None,
                        help="after_json_file.")
    parser.add_argument("--sample_in_file", type=str, default=None,
                        help="sample_in_file.")
    parser.add_argument("--outpath", type=str, default="out_frame_diff_to_svg",
                        help="outpath.")
    args = parser.parse_args()
    return args

def main():
    args = get_args()
    if not os.path.exists(args.outpath):
        os.makedirs(args.outpath)

    processed_data = process_frame_vector(args.before_json_file, args.after_json_file)
    before_frame_dict = processed_data[0]
    after_frame_dict = processed_data[1]
    before_after_line_and_line_item_dict = processed_data[2]
    before_svg_data = frame_to_svg(before_frame_dict)
    after_svg_data = frame_to_svg(after_frame_dict)
    
    before_tree = SvgReader.load_svg(before_svg_data, modify_image_href=True)
    after_tree = SvgReader.load_svg(after_svg_data, modify_image_href=True)
    SvgEditor.write(before_tree, os.path.join(args.outpath, "before_m.svg"))
    SvgEditor.write(after_tree, os.path.join(args.outpath, "after_m.svg"))
    
    with open(args.sample_in_file, "r") as f:
        in_data = json.load(f)

    preprocessor = Preprocessor(before_tree, after_tree)
    preprocessor.preprocess(in_data)

    # M1640.412244,1396.2L1640.412244,1401M1673.836152,1396.2L1673.836152,1401

    #SvgEditor.write(before_tree, os.path.join(args.outpath, "before_m_region.svg"))
    #SvgEditor.write(after_tree, os.path.join(args.outpath, "after_m_region.svg"))


    TOTAL_FRAMES = int(preprocessor.video_duration * SVGSequenceScriptCreatorConfig.FPS)
    svg_sequence_path = os.path.join(args.outpath, "svg_sequence")
    multhreader = MultipleThreader(total_frames=TOTAL_FRAMES)
    #multhreader = MultipleThreader()

    start = time.time()
    for scene in in_data["video"]:
        scene_id  = scene["scene_id"]
        #print(f"Processing \033[32mscene_{scene_id}\033[0m")

        scene_duration = scene["scene_duration"]
        
        bg_key = "{}{}".format(scene["background"], "_empty" if scene["empty_plan"] else "")
        
        svg_sequence_script_creator = SVGSequenceScriptCreator(
            before_after_line_and_line_item_dict,
            clips=scene["clips"], 
            duration=scene_duration
        )
        svg_sequence_script = svg_sequence_script_creator.get_svg_sequence_script()
        svg_sequence_script = [
            {
                "id": "scene_{}_{:0>6d}".format(scene_id, idx),
                "data": svg_script
            } for idx, svg_script in enumerate(svg_sequence_script)
        ]
        multhreader.submit_task(
            svg_sequence_script,
            preprocessor,
            bg_key
        )
    multhreader.shutdown()
    end = time.time()
    print("elpas time={}s".format(end - start))
    return
    
if __name__ == "__main__":
    main()
