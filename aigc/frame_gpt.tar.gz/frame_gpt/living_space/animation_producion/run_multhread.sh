#!/bin/bash
#/mnt/aigc_chubao/zhangyan461/env/miniconda3/envs/svg/bin/python -m cProfile -o program.prof run.py \
/mnt/aigc_chubao/zhangyan461/env/miniconda3/envs/svg/bin/python run_multhread.py \
       --before_json_file demo_frame_json/before.json \
       --after_json_file demo_frame_json/after.json \
       --sample_in_file debug_sample.json

