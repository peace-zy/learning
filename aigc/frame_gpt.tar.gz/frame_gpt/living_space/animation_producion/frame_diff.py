#-*-coding: utf-8-*-
import json
import copy
import json_tools

class FrameDiffer(object):
    # json字段名称
    FLOOR_PLAN_KEY = u'floorplans'
    # 默认楼层=0
    DEFAULT_FLOOR_IDX = 0
    # 角点字段名称
    POINT_KEY = u'points'
    # 墙体字段名称
    LINE_KEY = u'lines'
    # 墙体厚度名称
    LINE_THICKNESS_KEY = u'thickness'
    # 墙体自动厚度名称
    LINE_AUTO_THICKNESS_KEY = u'thicknessComputed'
    # 分间字段名称
    AREA_KEY = u'areas'
    # 分间字段名称
    LINE_ITEM_KEY = u'lineItems'
    # 分间字段名称
    ITEM_KEY = u'items'
    EDGE_KEY = u'edgeComputed'
    UID_KEY = u'id'
    TYPE_KEY = u'type'
    CURVE_KEY = u'curve'
    # 墙体字段
    LINE_ITEM_START_PT_KEY = u'startPointAt'
    LINE_ITEM_END_PT_KEY = u'endPointAt'
    LINE_ITEM_IS_KEY = u'is'
    LINE_ITEM_ENTRANCE_KEY = u'entrance'
    LINE_ITEM_LINE_ID = u'line'
    LINE_ITEM_START = u'start'
    LINE_ITEM_ROTATE_Y = u'rotateY'
    LINE_ITEM_ROTATE_X = u'rotateX'

    # 分间字段
    ROOM_TYPE_KEY = u'roomType'

    def __init__(self, before_frame_dict, after_frame_dict):
        self.same_part_dict = {self.FLOOR_PLAN_KEY: [{}]}
        self.diff_part_dict = {}
        self.before_frame_dict = before_frame_dict
        self.after_frame_dict = after_frame_dict

    def compare_func(self, item_key):
        diff = {
            "same": [],
            "del": [],
            "add": []
        }
        before_item_dict = self.before_frame_dict[self.FLOOR_PLAN_KEY][self.DEFAULT_FLOOR_IDX][item_key]
        after_item_dict = self.after_frame_dict[self.FLOOR_PLAN_KEY][self.DEFAULT_FLOOR_IDX][item_key]
        before_item_dict = {ele["id"]: ele for ele in before_item_dict}
        after_item_dict = {ele["id"]: ele for ele in after_item_dict}
        same_ele_ids = set(before_item_dict.keys()).intersection(set(after_item_dict.keys()))
        for ele_id in same_ele_ids:
            diff["same"].append(before_item_dict[ele_id])
        self.same_part_dict[self.FLOOR_PLAN_KEY][self.DEFAULT_FLOOR_IDX][item_key] = diff["same"]
        # before有而after中没有的
        del_ele_ids = set(before_item_dict.keys()).difference(set(after_item_dict.keys()))
        for ele_id in del_ele_ids:
            diff["del"].append(before_item_dict[ele_id])

        add_ele_ids = set(after_item_dict.keys()).difference(set(before_item_dict.keys()))
        for ele_id in add_ele_ids:
            diff["add"].append(after_item_dict[ele_id])

        return diff

    def postprocess_lines(self, lines_diff):
        # keep edge
        posted_lines_diff = copy.deepcopy(lines_diff)
        pop_idxs = []
        for idx, ele_del in enumerate(lines_diff["del"]):
            if ele_del[self.EDGE_KEY]:
                pop_idxs.append(idx)
                self.same_part_dict[self.FLOOR_PLAN_KEY][self.DEFAULT_FLOOR_IDX][self.LINE_KEY].append(ele_del)

        posted_lines_diff["del"] = [x for i, x in enumerate(posted_lines_diff["del"]) if i not in pop_idxs]
        pop_idxs = []
        for idx, ele_add in enumerate(lines_diff["add"]):
            if ele_add[self.EDGE_KEY]:
                pop_idxs.append(idx)
        posted_lines_diff["add"] = [x for i, x in enumerate(posted_lines_diff["add"]) if i not in pop_idxs]

        return posted_lines_diff
    
    def add_same_points_to_diff(self):
        same_points = self.same_part_dict[self.FLOOR_PLAN_KEY][self.DEFAULT_FLOOR_IDX][self.POINT_KEY]
        points_diff = self.diff_part_dict[self.POINT_KEY]
        all_points = {p["id"]: p for p in same_points}
        all_points.update(points_diff["add"])

        self.diff_part_dict[self.POINT_KEY]["all"] = all_points
        
    def get_frame_diff(self):
        # basic part
        for b_k, b_v in self.before_frame_dict.items():
            if b_k != self.FLOOR_PLAN_KEY and b_k in self.after_frame_dict:
                diff = json_tools.diff(b_v, self.after_frame_dict[b_k])
                if not diff:
                    self.same_part_dict[b_k] = b_v
        compare_keys = [self.POINT_KEY, self.LINE_KEY, self.LINE_ITEM_KEY, self.AREA_KEY, self.ITEM_KEY]
        all_diff_dict = {}
        for item_key in compare_keys:
            all_diff_dict[item_key] = self.compare_func(item_key)
        lines_diff = all_diff_dict[self.LINE_KEY]
        posted_lines_diff = self.postprocess_lines(lines_diff)
        all_diff_dict[self.LINE_KEY] = posted_lines_diff        
        
        for item_key, diff in all_diff_dict.items():
            self.diff_part_dict[item_key] = {
                    "del": {ele["id"]: ele for ele in diff["del"]},
                    "add": {ele["id"]: ele for ele in diff["add"]}
            }
        self.add_same_points_to_diff()

        return {"same": self.same_part_dict, "diff": self.diff_part_dict}

def main():
    import sys
    before_json_file = sys.argv[1] 
    after_json_file = sys.argv[2] 
    with open(before_json_file, "r") as f:
        before_frame_dict = json.load(f)
    with open(after_json_file, "r") as f:
        after_frame_dict = json.load(f)
    frame_differ = FrameDiffer(before_frame_dict, after_frame_dict)
    res = frame_differ.get_frame_diff()
    #print(json.dumps(res["same"])

    print(res["diff"])
    print(res["diff"].keys())
    return

if __name__ == "__main__":
    main()
