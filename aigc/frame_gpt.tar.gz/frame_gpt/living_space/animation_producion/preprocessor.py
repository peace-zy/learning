#-*-coding: utf-8-*-

import traceback
import copy
from collections import OrderedDict
import xml.etree.ElementTree as ET

from svg_reader import *
from elements import *
from util import ViviDict
from animation_config.general import SvgConfig, ProcessorConfig
from svg_sequence_script_creator import SVGSequenceScriptCreator

class Preprocessor(object):    
    def __init__(self, 
        before_svg=None,
        after_svg=None,
        modify_image_href=False,
        clean=True
    ):
        if before_svg is None and after_svg is None:
            raise ValueError("set svg_file and svg_data_str")

        self.preload_new_elements = ViviDict()
        self.before_tree = SvgReader.load_svg(before_svg, modify_image_href)
        self.after_tree = SvgReader.load_svg(after_svg, modify_image_href)
        if clean:
            self.before_tree = Preprocessor.get_clean_svg(self.before_tree)
            self.after_tree = Preprocessor.get_clean_svg(self.after_tree)
    
    def post_init(self, reset_item_keys):
        self.before_tree = self.reset_initial_opacity(self.before_tree, reset_item_keys)
        self.after_tree = self.reset_initial_opacity(self.after_tree, reset_item_keys)

        self.before_empty_tree, self.before_defs = self.empty_floorplan(self.before_tree)
        self.after_empty_tree, self.after_defs = self.empty_floorplan(self.after_tree)
        
        self._merge_defs()

        self.before_item_id_and_et_ele_dict = self._get_item_id_and_et_ele_dict(self.before_tree)
        self.after_item_id_and_et_ele_dict = self._get_item_id_and_et_ele_dict(self.after_tree)
        self.before_empty_item_id_and_et_ele_dict = self._get_item_id_and_et_ele_dict(self.before_empty_tree)
        self.after_empty_item_id_and_et_ele_dict = self._get_item_id_and_et_ele_dict(self.after_empty_tree)

    def empty_floorplan(self, tree):
        empty_tree = copy.deepcopy(tree)
        root = empty_tree.getroot()
        remove_keys = []
        empty_defs = []
        for elem in root:
            if "type" in elem.attrib and elem.attrib["type"] not in ProcessorConfig.EMPTY_FLOORPLAN_KEEP_KEYS:
                #print(elem.tag, elem.attrib)
                remove_keys.append(elem)
            if elem.tag == SvgConfig.SVG_PREFIX_TAG + "defs":
                empty_defs.append(elem)
                remove_keys.append(elem)
        for key in remove_keys:
            root.remove(key)

        return (empty_tree, empty_defs)

    def _merge_defs(self):        
        markers = [ele["element"] for ele in self.preload_new_elements["marker"].values()]        
        merged_defs = []
        
        def traverse_defs(_defs):
            pop_idx = None
            record = OrderedDict()
            """
            for idx, def_g in enumerate(_defs):
                if "id" in def_g[0].attrib:
                    if "item-defs-" in def_g[0].attrib["id"]:
                        pop_idx = idx
                    else:
                        for d in def_g:
                            if "id" in d.attrib:
                                record[d.attrib["id"]] = {"elem": d, "idx": idx}
            """
            for idx, def_g in enumerate(_defs):
                for d in def_g:
                    record[ET.tostring(d)] = d
                        
            return (pop_idx, record)

        pop_idx, record_before = traverse_defs(self.before_defs)
        #if pop_idx is None:
        #    merged_defs.append(self.before_defs[pop_idx])
        pop_idx, record_after = traverse_defs(self.after_defs)
        
        merged_keys = set(record_before.keys()).union(set(record_after.keys()))
        
        in_args = {"tag": "defs"}
        defs_node = BasicElement()(tag="defs")["element"]
        for key in merged_keys:
            if key in record_before:
                defs_node.append(record_before[key])
            elif key in record_after:
                defs_node.append(record_after[key])
            """
            if "item-defs-88" in key:
                import pdb
                pdb.set_trace()
            before_data = record_before.get(key, None)
            after_data = record_before.get(key, None)
            if before_data is not None and after_data is not None:
                if ET.tostring(before_data["elem"]) == ET.tostring(after_data["elem"]):
                    defs_node.append(before_data["elem"])
                else:
                    defs_node.extend([before_data["elem"], after_data["elem"]])
            elif before_data is not None:
                defs_node.append(before_data["elem"])
            elif after_data is not None:
                defs_node.append(after_data["elem"])
            """
        merged_defs.append(defs_node)

        before_root = self.before_tree.getroot()
        before_empty_root = self.before_empty_tree.getroot()
        before_root.extend(merged_defs + markers)
        before_empty_root.extend(merged_defs + markers)


        after_root = self.after_tree.getroot()
        after_empty_root = self.after_empty_tree.getroot()
        after_root.extend(merged_defs + markers)
        after_empty_root.extend(merged_defs + markers)

        """
        before_root.extend(self.after_defs)
        before_empty_root.extend(self.after_defs)

        before_root.extend(markers)
        before_empty_root.extend(markers)

        after_root = self.after_tree.getroot()
        after_empty_root = self.after_empty_tree.getroot()
        after_root.extend(self.before_defs)
        after_empty_root.extend(self.before_defs)
        after_root.extend(markers)
        after_empty_root.extend(markers)
        """

    def _get_item_id_and_et_ele_dict(self, tree):
        item_id_and_et_ele_dict = {}
        root = tree.getroot()
        for g in root:
            #print(g.attrib, g.tag)
            for elem in g:
                for e in elem.iter():
                    if "id" in e.attrib and "type" in e.attrib and e.attrib["type"] in ProcessorConfig.VALID_ATTRIB_TYPES:
                        if e.attrib["id"] not in item_id_and_et_ele_dict:
                            item_id_and_et_ele_dict[e.attrib["id"]] = {
                                "g_addr": g,
                                "g_elem": elem,
                                "id_type": e.attrib["type"],
                                "id_tag": e.tag.split(SvgConfig.SVG_PREFIX_TAG)[1],
                                "id_addr": e
                            }
                        else:
                            raise ValueError("duplicate")
                        
                        """
                            item_id_and_et_ele_dict[e.attrib["id"]] = []
                        item_id_and_et_ele_dict[e.attrib["id"]].append(
                            {
                                "g_addr": g,
                                "id_type": e.attrib["type"],
                                "id_tag": e.tag.split(SvgConfig.SVG_PREFIX_TAG)[1]
                            }
                        )
                        """
        return item_id_and_et_ele_dict

    def reset_initial_opacity(self, tree, item_keys):
        for elem in tree.iter():
            if "id" in elem.attrib and elem.attrib["id"] in item_keys:
                if "opacity" in elem.attrib:
                    elem.attrib["ori_opacity"] = elem.attrib["opacity"]
                elem.attrib["opacity"] = "0"
            if "data_type" in elem.attrib and elem.attrib["data_type"] == "moving_line":
                elem.attrib["opacity"] = "0"
        # remove small line
        for group in tree.getroot():
            if "type" in group.attrib and group.attrib["type"] == "lineGroup":
                for elem in group.iter():
                    if "id" not in elem.attrib and "fill" in elem.attrib and elem.attrib["fill"] == "none":
                        elem.attrib["opacity"] = "0"
        return tree
    
    @staticmethod
    def get_clean_svg(tree):
        root = tree.getroot()
        remove_elems = []
        for elem in root:
            if "type" in elem.attrib and elem.attrib["type"] in ProcessorConfig.REMOVE_KEYS:
                #print(elem.tag, elem.attrib)
                remove_elems.append(elem)
        for elem in remove_elems:
            root.remove(elem)
        # VIEW_BOX_DASHED_LINE
        for elem in tree.iter():
            if "id" in elem.attrib and elem.attrib["id"] == ProcessorConfig.VIEW_BOX_DASHED_LINE_ITEM_ID:
                for e in elem:
                    if SvgConfig.SVG_PREFIX_TAG + "image" == e.tag:
                        #e.attrib["width"] = "0"
                        #e.attrib["height"] = "0"
                        elem.remove(e)
                        break
                        
        return tree

    def get_svg_sequence_script(self, in_data, before_after_line_and_line_item_dict):
        all_svg_sequence_script = []
        scene_ids = []
        for scene in in_data["video"]:
            scene_id  = str(scene["scene_id"])
            scene_ids.append(scene_id)
            scene_duration = scene["scene_duration"]
            
            bg_key = "{}{}".format(scene["background"], "_empty" if scene["empty_plan"] else "")
            
            svg_sequence_script_creator = SVGSequenceScriptCreator(
                before_after_line_and_line_item_dict,
                clips=scene["clips"], 
                duration=scene_duration
            )
            svg_sequence_script = svg_sequence_script_creator.get_svg_sequence_script()
            all_svg_sequence_script += [
                {
                    "id": "scene_{}_{:0>6d}".format(scene_id, idx),
                    "scene_id": scene_id,
                    "bg_key": bg_key,
                    "data": svg_script
                } for idx, svg_script in enumerate(svg_sequence_script)
            ]
        return {
            "svg_sequence_script": all_svg_sequence_script,
            "scene_ids": scene_ids
        }

    def preprocess(self, in_data, before_after_line_and_line_item_dict):
        reset_item_keys = set([])
        for marker_type in MarkerDefElement.MARKER_TYPES:
            self.preload_new_elements["marker"][marker_type] = MarkerDefElement()(marker_type=marker_type)
        self.video_duration = 0
        for scene in in_data["video"]:
            for one_clip in scene["clips"]:
                if one_clip["object_type"] == "region":
                    reset_item_keys.add(one_clip["object_source"])
                elif one_clip["object_type"] == "moving_line":
                    for animation_type, animation_args in one_clip["animation_detail"].items():
                        for item_id in animation_args["transition"]:
                            reset_item_keys.add(item_id)
                elif one_clip["object_type"] == "image":
                    if one_clip["object_source"] not in self.preload_new_elements["image_def"]:
                        self.preload_new_elements["image_def"][one_clip["object_source"]] = ImageDefElement()(one_clip["object_source"])
            self.video_duration += scene["scene_duration"]
        
        self.post_init(reset_item_keys)
        svg_sequence_script = self.get_svg_sequence_script(in_data, before_after_line_and_line_item_dict)
        return svg_sequence_script

def main():
    import sys
    before_svg = sys.arg[1]
    after_svg = sys.arg[2]
    preprocessor = Preprocessor(
        before_svg=None,
        after_svg=None,
        modify_image_href=False,
        clean=True)
    return
if __name__ == "__main__":
    main()