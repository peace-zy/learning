#-*-coding: utf-8-*-
import requests
import json
import time
import traceback

from animation_config.general import FrameToSvgConfig

def frame_to_svg(frame_dict):
    post_data = {
            "source": json.dumps(frame_dict),
            "index": 0
    }
    #headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    start = time.time()
    TRY_NUM = FrameToSvgConfig.TRY_NUM
    svg_data = None

    while TRY_NUM: 
        try:
            # {"error":true,"message":"Protocol error (Runtime.callFunctionOn): Target closed."}
            TRY_NUM -= 1
            response = requests.post(
                url=FrameToSvgConfig.HTTP_URL,
                data=post_data,
                timeout=FrameToSvgConfig.TIMEOUT
            )
            try:
                content = response.content.decode("utf-8")          
                res = json.loads(content)
            except Exception as ce:
                svg_data = content
                break
            if "code" in res and res["code"] != 0:
                break
            #elif "error" in res and res["error"]:
            
        except Exception as e:
            #traceback.print_exc()
            pass
            
    end = time.time()
    print("frame_to_svg time={}s".format(end - start))
    return svg_data

def main():
    import sys
    infile = sys.argv[1]
    with open(infile, "r") as f:
        data = json.load(f)
    res = frame_to_svg(data)
    with open("jjjj.svg", "w") as f:
        f.write(res)
    #print(res)
    return

if __name__ == "__main__":
    main()
