# 生成svg序列
python run.py \
       --before_json_file demo_frame_json/before.json \
       --after_json_file demo_frame_json/after.json \
       --sample_in_file debug_sample.json \
       --outpath svg_sequence

# svg序列转png
python svg2image.py 2 svg_sequence/scene_1 pngs/scene_1
