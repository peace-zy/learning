#-*-coding: utf-8-*-
import os
import json
import copy
import argparse
import time
from tqdm import tqdm

from frame_diff import FrameDiffer
from frame_to_svg import frame_to_svg

from frame_vector_processor import process_frame_vector
from svg_reader import SvgReader
from svg_editor import SvgEditor
from preprocessor import Preprocessor
from multiple_threader import MultipleThreader
from animation_config.general import SVGSequenceScriptCreatorConfig, MultipleThreaderConfig

def get_args():
    parser = argparse.ArgumentParser() 
    parser.add_argument("--before_json_file", type=str, default=None,
                        help="before_json_file.")
    parser.add_argument("--after_json_file", type=str, default=None,
                        help="after_json_file.")
    parser.add_argument("--sample_in_file", type=str, default=None,
                        help="sample_in_file.")
    #parser.add_argument("--outpath", type=str, default="out_frame_diff_to_svg",
    #                    help="outpath.")
    args = parser.parse_args()
    return args

def main():
    args = get_args()
    if not os.path.exists(MultipleThreaderConfig.OUTPUT_PATH):
        os.makedirs(MultipleThreaderConfig.OUTPUT_PATH)

    processed_data = process_frame_vector(args.before_json_file, args.after_json_file)
    before_frame_dict = processed_data[0]
    after_frame_dict = processed_data[1]
    before_after_line_and_line_item_dict = processed_data[2]
    before_svg_data = frame_to_svg(before_frame_dict)
    after_svg_data = frame_to_svg(after_frame_dict)
    
    before_tree = SvgReader.load_svg(before_svg_data, modify_image_href=True)
    after_tree = SvgReader.load_svg(after_svg_data, modify_image_href=True)
    SvgEditor.write(before_tree, os.path.join(MultipleThreaderConfig.OUTPUT_PATH, "before_m.svg"))
    SvgEditor.write(after_tree, os.path.join(MultipleThreaderConfig.OUTPUT_PATH, "after_m.svg"))
    
    with open(args.sample_in_file, "r") as f:
        in_data = json.load(f)

    print("\033[32m[Doing\033[0m {:>10}".format("Preprocessor"))
    preprocessor = Preprocessor(before_tree, after_tree)
    initial_data = preprocessor.preprocess(in_data, before_after_line_and_line_item_dict)
    print("\033[32mDone] \033[0m {:<10}".format("Preprocessor"))
    # M1640.412244,1396.2L1640.412244,1401M1673.836152,1396.2L1673.836152,1401

    TOTAL_FRAMES = int(preprocessor.video_duration * SVGSequenceScriptCreatorConfig.FPS)

    print("\033[32m[Doing\033[0m {:>10}".format("MultipleThreader init"))
    multhreader = MultipleThreader(initial_data["scene_ids"], TOTAL_FRAMES)
    print("\033[32mDone] \033[0m {:<10}".format("MultipleThreader init"))

    print("\033[32m[Doing\033[0m {:>10}".format("MultipleThreader run"))
    multhreader.submit_task(initial_data["svg_sequence_script"], preprocessor)
    print("\033[32mDone] \033[0m {:<10}".format("MultipleThreader run"))
    

    return
    
if __name__ == "__main__":
    main()
