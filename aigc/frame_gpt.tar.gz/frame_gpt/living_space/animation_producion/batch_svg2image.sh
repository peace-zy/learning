#!/bin/bash
root=out_frame_diff_to_svg/svg_sequence/scene_1
python_bin=python
out_path=new_pngs_0130/scene_1
${python_bin} svg2image.py 2 ${root} ${out_path} 2>&1 &

root=out_frame_diff_to_svg/svg_sequence/scene_2
out_path=new_pngs_0130/scene_2
${python_bin} svg2image.py 2 ${root} ${out_path} 2>&1 &

root=out_frame_diff_to_svg/svg_sequence/scene_3
out_path=new_pngs_0130/scene_3
${python_bin} svg2image.py 2 ${root} ${out_path} 2>&1 &

root=out_frame_diff_to_svg/svg_sequence/scene_4
out_path=new_pngs_0130/scene_6
${python_bin} svg2image.py 2 ${root} ${out_path} 2>&1 &
