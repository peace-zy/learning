#-*- coding: utf-8-*-
import requests
from PIL import Image
from io import BytesIO

def str_time_to_float_second(time):
    """
    takes time paramter in an svg and converts it to seconds

    Args:
        time (str): time format from SVG i.e. 10s = 10 seconds
    Returns:
        (float): cleaned time
    """
    if type(time) != str:
        raise Exception("did not pass str")
    elif "s" in time:
        return float(time.replace("s",""))
    elif "m" in time:
        return float(time.replace("m","")) * 60
    else:
        raise Exception("Time was not in seconds or minutes")

def get_image_size(img_url):
    size = None
    try:
        image_data = requests.get(img_url).content
        image = Image.open(BytesIO(image_data))
        size = image.size
    except Exception as e:
        pass
    return size

class ViviDict(dict):
    def __missing__(self, key):
        value = self[key] = type(self)()
        return value