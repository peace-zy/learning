#-*-coding: utf-8-*-
import numpy as np
import copy

from animation_config.general import SVGSequenceScriptCreatorConfig

class SVGSequenceScriptCreator(object):
    def __init__(
        self,
        before_after_line_and_line_item_dict,
        clips,
        duration, 
    ):
        self.before_after_line_and_line_item_dict = before_after_line_and_line_item_dict
        self.clips = clips
        self.duration = duration
        self.FPS = SVGSequenceScriptCreatorConfig.FPS
        self.keytimes = [(s + 1)* (1 / self.FPS) for s in range(int(duration * self.FPS))]
        self.np_keytimes = np.array(self.keytimes)
        self.KEYFRAMES_NUM = len(self.keytimes)
        self.svg_sequence_script = [[]] * self.KEYFRAMES_NUM

        self.SCENE_START_INDEX = 0
        self.SCENE_END_INDEX = self.KEYFRAMES_NUM

        self.ANIMATION_DETAIL_KEYS = {
            "object_type": None,
            "object_source": None,
            "keytime": None,
            "percentage": None,
            "animation_type": None,
            "animation_args": None,
        }
    
    def prepare_left(self, one_clip, start_index, end_index):
        # left
        if one_clip["object_type"] == "view_box":
            for index in range(start_index, end_index, 1):
                kwargs = copy.deepcopy(self.ANIMATION_DETAIL_KEYS)
                kwargs["object_type"] = "view_box"
                kwargs["object_source"] = one_clip["object_source"]
                kwargs["keytime"] = self.np_keytimes[index]
                kwargs["percentage"] = 1
                kwargs["animation_type"] = "view_box"
                self.svg_sequence_script[index] = self.svg_sequence_script[index] + [kwargs]
    def prepare_in(self, one_clip, start_index, end_index):
        # in
        loop_list = []
        loop_list.append({
            "object_type": one_clip["object_type"],
            "object_source": one_clip["object_source"]
        })
        """
        if one_clip["object_type"] == "moving_line":
            for item_id in  one_clip["animation_detail"]["transition"]:
                loop_list.append({"object_type": one_clip["object_type"], "object_source": item_id})
        else:
            loop_list.append({
                "object_type": one_clip["object_type"],
                "object_source": one_clip["object_source"]
            })
        """

        for index in range(start_index, end_index, 1):
            for item in loop_list:
                kwargs = copy.deepcopy(self.ANIMATION_DETAIL_KEYS)
                kwargs["object_type"] = item["object_type"]
                kwargs["object_source"] = item["object_source"]
                kwargs["keytime"] = self.np_keytimes[index]
                kwargs["percentage"] = (index - start_index) / (end_index - start_index + 1)
                kwargs["animation_type"] = "opacity"
                self.svg_sequence_script[index] = self.svg_sequence_script[index] + [kwargs]

    def prepare_keep(self, one_clip, start_index, end_index):
        loop_list = []
        loop_list.append({
            "object_type": one_clip["object_type"],
            "object_source": one_clip["object_source"]
        })
        for index in range(start_index, end_index, 1):
            for item in loop_list:
                kwargs = copy.deepcopy(self.ANIMATION_DETAIL_KEYS)
                kwargs["object_type"] = item["object_type"]
                kwargs["object_source"] = item["object_source"]
                kwargs["keytime"] = self.np_keytimes[index]
                kwargs["percentage"] = 1
                kwargs["animation_type"] = "opacity"
                self.svg_sequence_script[index] = self.svg_sequence_script[index] + [kwargs]

    def prepare_out(self, one_clip, start_index, end_index):
        loop_list = []
        loop_list.append({
            "object_type": one_clip["object_type"],
            "object_source": one_clip["object_source"]
        })

        for index in range(start_index, end_index, 1):
            for item in loop_list:
                kwargs = copy.deepcopy(self.ANIMATION_DETAIL_KEYS)
                kwargs["object_type"] = item["object_type"]
                kwargs["object_source"] = item["object_source"]
                kwargs["keytime"] = self.np_keytimes[index]
                kwargs["percentage"] = (1 - (index - start_index)/ (end_index - start_index + 1))
                kwargs["animation_type"] = "opacity"
                self.svg_sequence_script[index] = self.svg_sequence_script[index] + [kwargs]
    def prepare_right(self, one_clip, start_index, end_index):
        for index in range(start_index, end_index, 1):
            kwargs = copy.deepcopy(self.ANIMATION_DETAIL_KEYS)
            kwargs["object_type"] = one_clip["object_type"]
            kwargs["object_source"] = one_clip["object_source"]
            kwargs["keytime"] = self.np_keytimes[index]
            kwargs["percentage"] = 0
            kwargs["animation_type"] = "opacity"
            self.svg_sequence_script[index] = self.svg_sequence_script[index] + [kwargs]
            # lineItem out with line
            if one_clip["object_source"] in self.before_after_line_and_line_item_dict:
                """
                if "u-D8q7s8lRhICt9B" == one_clip["object_source"]:
                    import pdb
                    pdb.set_trace()
                """
                for line_item_id in self.before_after_line_and_line_item_dict[one_clip["object_source"]]:
                    kwargs = copy.deepcopy(self.ANIMATION_DETAIL_KEYS)
                    kwargs["object_type"] = one_clip["object_type"]
                    kwargs["object_source"] = line_item_id
                    kwargs["keytime"] = self.np_keytimes[index]
                    kwargs["percentage"] = 0
                    kwargs["animation_type"] = "opacity"
                    self.svg_sequence_script[index] = self.svg_sequence_script[index] + [kwargs]

    def prepare_animation(self, one_clip, in_start_pos, in_end_pos, out_start_pos, out_end_pos):
        animation_detail = one_clip["animation_detail"]
        if animation_detail:
            for animation_type, animation_args in animation_detail.items():
                animate_start_pos = np.argmin(np.abs(animation_args["start"] - self.np_keytimes))
                animate_end_pos = np.argmin(np.abs(animation_args["end"] - self.np_keytimes))
                # transition
                for index in range(animate_start_pos, animate_end_pos, 1):
                    kwargs = copy.deepcopy(self.ANIMATION_DETAIL_KEYS)
                    kwargs["object_type"] = one_clip["object_type"]
                    kwargs["object_source"] = one_clip["object_source"]
                    kwargs["keytime"] = self.np_keytimes[index]
                    kwargs["percentage"] = (index - animate_start_pos) / (animate_end_pos - animate_start_pos + 1)
                    kwargs["animation_type"] = animation_type
                    kwargs["animation_args"] = animation_args
                    self.svg_sequence_script[index] = self.svg_sequence_script[index] + [kwargs]
                # update right
                # color effect with initial color
                if animation_type == "color":
                    if "initial" in animation_args:
                        for index in range(in_start_pos, animate_start_pos, 1):
                            kwargs = copy.deepcopy(self.ANIMATION_DETAIL_KEYS)
                            kwargs["object_type"] = one_clip["object_type"]
                            kwargs["object_source"] = one_clip["object_source"]
                            kwargs["keytime"] = self.np_keytimes[index]
                            kwargs["percentage"] = 1
                            kwargs["animation_type"] = animation_type
                            kwargs["animation_args"] = copy.deepcopy(animation_args)
                            kwargs["animation_args"]["transition"] = [animation_args["initial"], animation_args["initial"]]
                            self.svg_sequence_script[index] = self.svg_sequence_script[index] + [kwargs]
                    for index in range(animate_end_pos, self.SCENE_END_INDEX, 1):
                        kwargs = copy.deepcopy(self.ANIMATION_DETAIL_KEYS)
                        kwargs["object_type"] = one_clip["object_type"]
                        kwargs["object_source"] = one_clip["object_source"]
                        kwargs["keytime"] = self.np_keytimes[index]
                        kwargs["percentage"] = 1
                        kwargs["animation_type"] = animation_type
                        kwargs["animation_args"] = animation_args
                        self.svg_sequence_script[index] = self.svg_sequence_script[index] + [kwargs]
                elif animation_type == "view_move":
                    for index in range(animate_end_pos, self.SCENE_END_INDEX, 1):
                        kwargs = copy.deepcopy(self.ANIMATION_DETAIL_KEYS)
                        kwargs["object_type"] = "view_box"
                        kwargs["object_source"] = animation_args["transition"][1]
                        kwargs["keytime"] = self.np_keytimes[index]
                        kwargs["percentage"] = 1
                        kwargs["animation_type"] = "view_box"
                        
                        self.svg_sequence_script[index] = self.svg_sequence_script[index] + [kwargs]

                elif animation_type == "moving_line":
                    for index in range(animate_end_pos, out_end_pos, 1):
                        kwargs = copy.deepcopy(self.ANIMATION_DETAIL_KEYS)
                        kwargs["object_type"] = "moving_line"
                        kwargs["object_source"] = None
                        kwargs["keytime"] = self.np_keytimes[index]
                        kwargs["percentage"] = 1
                        kwargs["animation_type"] = "moving_line"
                        kwargs["animation_args"] = animation_args
                        self.svg_sequence_script[index] = self.svg_sequence_script[index] + [kwargs]
    def get_svg_sequence_script(self):
        SKIP = ["moving_line"]
        for one_clip in self.clips:
            ##################################lifetime###############################
            in_start_pos = np.argmin(np.abs(one_clip["in_start"] - self.np_keytimes))
            in_end_pos = np.argmin(np.abs(one_clip["in_end"] - self.np_keytimes))
            out_start_pos = np.argmin(np.abs(one_clip["out_start"] - self.np_keytimes))
            out_end_pos = np.argmin(np.abs(one_clip["out_end"] - self.np_keytimes))

            if one_clip["object_type"] not in SKIP:
                # left
                self.prepare_left(one_clip, self.SCENE_START_INDEX, in_start_pos)
                
                # in
                self.prepare_in(one_clip, in_start_pos, in_end_pos)
                
                # keep
                self.prepare_keep(one_clip, in_end_pos, out_start_pos)
                
                # out
                self.prepare_out(one_clip, out_start_pos, out_end_pos)

                # right
                self.prepare_right(one_clip, out_end_pos, self.SCENE_END_INDEX)
            #########################################################################
            self.prepare_animation(one_clip, in_start_pos, in_end_pos, out_start_pos, out_end_pos)

        return self.svg_sequence_script
    
if __name__ == "__main__":
    main()
