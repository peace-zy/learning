#-*- coding: utf-8-*-

import glob
import contextlib
import re
import os 
import shutil
import sys
import time
from tqdm import tqdm

from PIL import Image
from bs4 import BeautifulSoup
from math import ceil
from selenium import webdriver
from pyvirtualdisplay import Display
import util

class SVG_TO_IMAGE(object):
    def __init__ (self, image_size=(540, 960)):
        self.image_size = image_size
        
    def svg2gif(self, svg_file, out_path="out_image/gif"):
        SCREENSHOTS_PER_SECOND = 22
        svg_basic_fname = os.path.splitext(os.path.basename(svg_file))[0]
        TMP_PATH = os.path.join(out_path, "tmp", svg_basic_fname)
        screenshots_path = os.path.join(TMP_PATH, "screenshots")
        if not os.path.exists(screenshots_path):
            os.makedirs(screenshots_path)

        with open(svg_file, 'r') as f:
            soup = BeautifulSoup(f, features="html.parser")
        
        animation_timers = [util.str_time_to_float_second(time_element.get("dur"))
                for time_element in soup.findAll('animate')]

        if not animation_timers:
            print("{} not contain animate tag".format(svg_file))
        total_time_animated = ceil(max(animation_timers)) if animation_timers else 1
        print(total_time_animated)

        """
        """
        display = Display(visible=0, size=self.image_size)
        display.start()
        driver = webdriver.Firefox()

        # In Selenium you need the prefix file:/// to open a local file
        start = time.time()
        driver.get("file:///{}".format(os.path.abspath(svg_file)))

        total_screenshots = int(SCREENSHOTS_PER_SECOND * total_time_animated)
        print("total_screenshots={}".format(total_screenshots))
        for i in range(total_screenshots):
            driver.get_screenshot_as_file(os.path.join(screenshots_path, f"{i}.png"))

        driver.close()
        driver.quit()
        
        fp_in = f"{screenshots_path}/*.png"
        fp_out = os.path.join(out_path, svg_basic_fname + ".gif")
        print(fp_out)

        # use exit stack to automatically close opened images
        with contextlib.ExitStack() as stack:

            files = glob.glob(fp_in)
            files.sort(key=lambda f: int(re.sub('\D', '', f))) 

            # lazily load images
            imgs = (stack.enter_context(Image.open(f))
                    for f in files)

            img = next(imgs)

            # https://pillow.readthedocs.io/en/stable/handbook/image-file-formats.html
            img.save(fp=fp_out, format='GIF', append_images=imgs,
                    save_all=True,
                    #duration=(total_time_animated * 1000)/len(files) - 10, # the math here feels off because the resulting gif is too slow thus -10 is implemented
                    duration=41.6,
                    loop=None)
            print("du={}, total_time_animated={}, len(files)={}".format(
                (total_time_animated * 1000)/len(files) - 10,
                total_time_animated, len(files)
            ))

        end = time.time()
        print("svg2gif {} s".format(end - start))

        #shutil.rmtree(TMP_PATH)

        #Optional delete of selenium logs
        #os.remove(f"geckodriver.log")
        display.stop()

    def svg2png(self, svg_file, out_path="out_image/png"):
        svg_basic_fname = os.path.splitext(os.path.basename(svg_file))[0]
        #out_path = os.path.join(out_path, svg_basic_fname)
        if not os.path.exists(out_path):
            os.makedirs(out_path)
        
        display = Display(visible=0, size=self.image_size)
        display.start()
        driver = webdriver.Firefox()

        # In Selenium you need the prefix file:/// to open a local file
        start = time.time()
        driver.get("file:///{}".format(os.path.abspath(svg_file)))

        total_screenshots = 1
        #for i in range(total_screenshots):
        driver.get_screenshot_as_file(os.path.join(out_path, f"{svg_basic_fname}.png"))
        end = time.time()
        print("svg2png {} s".format(end - start))
        driver.close()
        driver.quit()
        #os.remove(f"geckodriver.log")
        display.stop()

    def svg_list2png(self, svg_list, out_path="out_image/png"):
        #out_path = os.path.join(out_path, svg_basic_fname)
        if not os.path.exists(out_path):
            os.makedirs(out_path)
        
        print(self.image_size)
        display = Display(visible=0, size=self.image_size)
        display.start()
        driver = webdriver.Firefox()
        for svg_file in tqdm(svg_list):
            svg_basic_fname = os.path.splitext(os.path.basename(svg_file))[0]

            # In Selenium you need the prefix file:/// to open a local file
            #start = time.time()
            driver.get("file:///{}".format(os.path.abspath(svg_file)))

            #for i in range(total_screenshots):
            driver.get_screenshot_as_file(os.path.join(out_path, f"{svg_basic_fname}.png"))
            #end = time.time()
            #print("svg2png {} s".format(end - start))
            #time.sleep(0.1)
        driver.close()
        driver.quit()
        #os.remove(f"geckodriver.log")
        display.stop()


def main():
    out_path = None
    if len(sys.argv) == 3:
        mode = sys.argv[1]
        svg_file = sys.argv[2]
    elif len(sys.argv) > 3:
        mode = sys.argv[1]
        svg_file = sys.argv[2]
        out_path = sys.argv[3]
    else:
        raise Exception("Usage: python svg2gif.py 0-svg2gif/1-svg2png <SVG_file>")

    #885, 616
    #svg_to_img = SVG_TO_IMAGE(image_size=(1904, 2503))
    #svg_to_img = SVG_TO_IMAGE(image_size=(1920, 1080))
    svg_to_img = SVG_TO_IMAGE(image_size=(984, 812))
    # svg2gif
    if mode == "0":
        if out_path is not None:
            svg_to_img.svg2gif(svg_file, out_path)
        else:
            svg_to_img.svg2gif(svg_file)
    elif mode == "1":
        if out_path is not None:
            svg_to_img.svg2png(svg_file, out_path)
        else:
            svg_to_img.svg2png(svg_file)
    elif mode == "2":
        import glob
        svg_list = glob.glob(os.path.join(svg_file, "*.svg"))
        print(svg_list[0])
        if out_path is not None:
            svg_to_img.svg_list2png(svg_list, out_path)
        else:
            svg_to_img.svg_list2png(svg_list)
if __name__ == "__main__":
    main()
