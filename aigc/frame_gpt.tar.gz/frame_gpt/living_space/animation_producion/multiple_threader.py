#-*-coding: utf-8-*-
from concurrent import futures
from tqdm import tqdm
import logging
import os
import copy
import psutil
import threading
import time

from svg_editor import SvgEditor
from svg2pnger import Svg2Pnger
from animation_config.general import MultipleThreaderConfig

class MultipleThreader(object):
    def __init__(self, scene_ids, total_frames=None):
        self.svg_editor_thread_num = MultipleThreaderConfig.SVG_EDITOR_THREAD_NUM
        self.cput_num = psutil.cpu_count(logical=False)

        if self.svg_editor_thread_num is None:
            self.svg_editor_thread_num = self.cput_num
        self.svg_editor_thread_num = min(self.svg_editor_thread_num, self.cput_num - 1)
        self.svg_editor_executor = futures.ThreadPoolExecutor(max_workers=self.svg_editor_thread_num)
        self.svg2png_wokers = self._init_svg2png_worker(scene_ids)
        
        self.bar = None
        if total_frames is not None:
            self.bar = tqdm(total=total_frames)
    
    def _create_path(self, scene_ids):
        for _scene_id in scene_ids:
            os.makedirs(os.path.join(MultipleThreaderConfig.SVG_SEQUENCE_OUTPUT_PATH, _scene_id), exist_ok=True)
            os.makedirs(os.path.join(MultipleThreaderConfig.PNG_OUTPUT_PATH, _scene_id), exist_ok=True)

    def _init_svg2png_worker(self, scene_ids):
        """初始化"""
        def get_thread_op(png_output_path, display_window_size):
            svg2pnger = Svg2Pnger(png_output_path, display_window_size)
            thread_id = threading.currentThread().ident
            print(f"svg2png: thread_id={thread_id}")
            return {thread_id : svg2pnger}
        self._create_path(scene_ids)
        svg2png_wokers = {}
        tasks = []
        for _ in range(self.svg_editor_thread_num):  # 初始化子进程
            task_future = self.svg_editor_executor.submit(
                get_thread_op,
                MultipleThreaderConfig.PNG_OUTPUT_PATH,
                MultipleThreaderConfig.DISPLAY_WINDOW_SIZE
            )
            tasks.append(task_future)
        futures.wait(tasks)
        for task_future in tasks:
            error = task_future.exception()
            if error is None:
                svg2png_wokers.update(task_future.result(timeout=MultipleThreaderConfig.SVG_EDITOR_TIMEOUT))
            else:
                print("[{}] _init_svg2png_worker error [{}]".format(self.__class__.__name__, error))
        return svg2png_wokers
    
    def run_svg_to_png(self, svg2png_wokers, svg_script_data, preprocessor):
        output = self.base_worker(svg_script_data, preprocessor)
        output["instance"].write(**output["args"])
        out_svg_file = output["args"]["out_svg_file"]
        thread_id = threading.currentThread().ident
        svg2pnger = svg2png_wokers[thread_id]
        svg2pnger.svg_to_png(out_svg_file, subdir=svg_script_data["scene_id"])

    def list_of_groups(self, init_list, childern_list_len):
        """list_of_group"""
        list_of_group = zip(*(iter(init_list),) *childern_list_len) 
        end_list = [list(i) for i in list_of_group] # i is a tuple
        count = len(init_list) % childern_list_len
        end_list.append(init_list[-count:]) if count != 0 else end_list
        return end_list

    def svg2png_call_back(self, future):
        result = None
        if future.cancelled():
            #logging.info('process failed! cancelled! [{}]'.format(future.arg["svg_script_data"]["id"]))
            print("[{}] svg2png_call_back process failed! cancelled! [{}]".format(
                    self.__class__.__name__, future.arg["svg_script_data"]["id"]))
        elif future.done():
            error = future.exception()
            if error:
                #logging.info('process failed! [{}] return error:{}'.format(future.arg["svg_script_data"]["id"], error))
                print("[{}] svg2png_call_back process failed! [{}] return error:{}".format(
                        self.__class__.__name__, future.arg["svg_script_data"]["id"], error))
            else:
                result = future.result(timeout=future.arg["timeout"])
        
        #if result is None:
        #    logging.warning("[{}] dd {} result is None".format(self.__class__.__name__, future.arg["out_svg_file"]))
            
        if self.bar is not None:
            future.arg['bar'].update(1)

    def base_worker(self, svg_script_data, preprocessor):
        """base_worker"""
        output = {}
        try:
            bg_key = svg_script_data["bg_key"]
            bg_tree_key = bg_key + "_tree"
            in_id, scene_id, in_data = svg_script_data["id"], svg_script_data["scene_id"], svg_script_data["data"]
            out_svg_file = os.path.join(MultipleThreaderConfig.SVG_SEQUENCE_OUTPUT_PATH, scene_id, f"{in_id}.svg")
            bg_tree = None
            svg_editor_in = copy.deepcopy(preprocessor.__dict__)
            my_svg_editor = SvgEditor(**svg_editor_in)
            
            if hasattr(my_svg_editor, bg_tree_key):
                bg_tree = getattr(my_svg_editor, bg_tree_key)
            else:
                raise ValueError("SvgEditor has no {} tree".format(bg_tree_key))
            
            for animation_detail in in_data:
                if animation_detail["object_type"] is None \
                    and animation_detail["object_source"] is None \
                    and animation_detail["animation_type"] != "view_move":
                    continue
                func_str = "set_" + animation_detail["animation_type"]
                if hasattr(my_svg_editor, func_str):
                    getattr(my_svg_editor, func_str)(
                        bg_key, bg_tree, animation_detail
                    )
                else:
                    raise NotImplementedError("SvgEditor has not {} func".format(func_str))
                        
            output = {
                "instance": my_svg_editor,
                "args": {
                    "tree": bg_tree,
                    "out_svg_file": out_svg_file,
                    "add_shadow": True
                }
            }
            
        except Exception as e:
            #traceback.print_exc()
            logging.warning(e)
        return output

    def submit_task(self, ttasks, preprocessor):
        """submit_task"""
        ttask_group = self.list_of_groups(ttasks, self.svg_editor_thread_num)
        
        for ttasks in ttask_group:
            for ttask in ttasks:
                task_future = self.svg_editor_executor.submit(
                    self.run_svg_to_png,
                    self.svg2png_wokers,
                    ttask,
                    preprocessor
                )
                task_future.arg = {
                    "svg_script_data": ttask,
                    "bar": self.bar,
                    "timeout": MultipleThreaderConfig.SVG_EDITOR_TIMEOUT
                }
                task_future.add_done_callback(self.svg2png_call_back)

    def shutdown(self):
        self.svg_editor_executor.shutdown()
        for worker in self.svg2png_wokers.values():
            print(worker)
            worker.release()