#-*-coding: utf-8-*-

class SvgConfig(object): 
    REGISTER_TAG = "http://www.w3.org/2000/svg"
    REGISTER_XLINK = "http://www.w3.org/1999/xlink"
    SVG_PREFIX_TAG = f"{{{REGISTER_TAG}}}"
    SVG_XLINK = f"{{{REGISTER_XLINK}}}"

class FrameToSvgConfig(object):
    #HTTP_URL ="https://doctorstrange-vrlab.lianjia.com/print-svg"
    # test env
    HTTP_URL = "http://huxing.ttb.test.ke.com/print-svg"
    TIMEOUT = 10
    TRY_NUM = 5

class ProcessorConfig(object):
    EMPTY_FLOORPLAN_KEEP_KEYS = {"areaGroup", "lineGroup", "pointGroup", "lineItemGroup", "defs"}
    REMOVE_KEYS = {"ruleGroup", "gridGroup", "areaLabelGroup"}
    VIEW_BOX_DASHED_LINE_ITEM_ID = "item-defs-85"
    VALID_ATTRIB_TYPES = {"line", "item", "image", "area", "lineItem"}
    VALID_GROUP = {"areaGroup", "lineGroup", "pointGroup", "lineItemGroup", "itemGroup", "defs"}

class MultipleThreaderConfig(object):
    SVG_EDITOR_THREAD_NUM = 5
    SVG_EDITOR_TIMEOUT = 3
    OUTPUT_PATH = "0220"
    SVG_SEQUENCE_OUTPUT_PATH = f"{OUTPUT_PATH}/svg_sequence"
    PNG_OUTPUT_PATH = f"{OUTPUT_PATH}/png"
    DISPLAY_WINDOW_SIZE = (984, 812)

class SVGSequenceScriptCreatorConfig(object):
    FPS = 24
