#-*-coding: utf-8-*-
import json
import os

def get_before_and_after_line_and_line_item_dict(before_frame_dict, after_frame_dict):
    FLOOR_PLAN_KEY = u'floorplans'
    DEFAULT_FLOOR_IDX = 0
    LINE_KEY = u'lines'
    LINE_ITEM_KEY = u'lineItems'
    if not isinstance(before_frame_dict, dict):
        raise TypeError("{} type is {}, but need dict".format(before_frame_dict, type(before_frame_dict)))
    if not isinstance(after_frame_dict, dict):
        raise TypeError("{} type is {}, but need dict".format(after_frame_dict, type(after_frame_dict)))

    before_flooplan = before_frame_dict[FLOOR_PLAN_KEY][DEFAULT_FLOOR_IDX]
    after_flooplan = after_frame_dict[FLOOR_PLAN_KEY][DEFAULT_FLOOR_IDX]

    merge_line_and_line_item_dict = {}
    for line in before_flooplan[LINE_KEY]:
        if line["items"]:
            if line["id"] not in merge_line_and_line_item_dict:
                merge_line_and_line_item_dict[line["id"]] = set([]) 
            merge_line_and_line_item_dict[line["id"]] = merge_line_and_line_item_dict[line["id"]].union(set(line["items"]))

    for line in after_flooplan[LINE_KEY]:
        if line["items"]:
            if line["id"] not in merge_line_and_line_item_dict:
                merge_line_and_line_item_dict[line["id"]] = set([]) 
            merge_line_and_line_item_dict[line["id"]] = merge_line_and_line_item_dict[line["id"]].union(set(line["items"]))
    return merge_line_and_line_item_dict

def process_frame_vector(before_json_file, after_json_file):
    if not os.path.exists(before_json_file):
        raise FileNotFoundError("{} is not exists".format(before_json_file))
    if not os.path.exists(after_json_file):
        raise FileNotFoundError("{} is not exists".format(after_json_file))

    with open(before_json_file, "r") as f:
        before_frame_dict = json.load(f)

    with open(after_json_file, "r") as f:
        after_frame_dict = json.load(f)
    before_after_line_and_line_item_dict = get_before_and_after_line_and_line_item_dict(before_frame_dict, after_frame_dict)
    return (before_frame_dict, after_frame_dict, before_after_line_and_line_item_dict)
