#-*-coding: utf-8 -*-
import os
import json

from frame_to_svg import frame_to_svg
from prepare_svg_sequence_script import get_svg_sequence_script

def frame_vector_to_sequence() 

