# video="/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt/living_space/source/video/limu_9-16.mp4"
video="/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt/living_space/source/video/4159.mp4"
sound="/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt/living_space/source/sound/240117-170645_tts.mp3"
# ffmpeg -i limu_9-16.mp4 -i audio.mp3 -map 0:v -map 1:a -c:v copy -c:a aac output.mp4
save_folder="/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt/living_space/test/res/"

# 叠加音频
# ffmpeg -i $video -i $sound -map 0:v -map 1:a -c:v copy -c:a aac $save_folder/output.mp4

gif="/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt/living_space/test/res/f1.gif"
mv $save_folder/output.mp4 $save_folder/output_bak.mp4

# 视频加速3倍,最后一帧保持到视频结束,再以中心为原点剪裁视频变成1080x1324, 插入gif视频到指定视频中心, 增加一段配乐
ffmpeg -i $video -ignore_loop 0 -i $gif -i $sound -filter_complex "[0:v]setpts=0.33*PTS,crop=1080:1324[video];[1:v]scale=-1:812,crop=984:812[gif];[video][gif]overlay=48:174[output]" -map "[output]" -map 2:a $save_folder/output.mp4

img_sq="/aistudio/workspace/aigc/zhangyan461/research/29_machine/frame_gpt/living_space/zhangyan/out_image/gif/tmp/scene_0/screenshots"
# ffmpeg -framerate 30 -i  -c:v libx264 -r 30 -pix_fmt yuv420p $save_folder/output.mp4
# ffmpeg -framerate 30 -i $img_sq/%d.png -c:v libx264 -r 30 $save_folder/output.mp4

# 合并文件夹下所有00**.mp4的文件
ffmpeg 