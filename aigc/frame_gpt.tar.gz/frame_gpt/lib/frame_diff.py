# -*- coding: utf-8 -*-
# ===============================================================
#
#    Copyright (C) 2021 Beike, Inc. All Rights Reserved.
#
#    @Create Author : 李雨龙 (liyulong008@ke.com)
#    @Create Time   : 2021/7/15 14:41
#    @Description   : 户型改造解读&Diff
#
# ===============================================================
from __future__ import division

import random
from collections import Counter, defaultdict
import json
import copy
import logging

import numpy as np
from scipy.optimize import linear_sum_assignment
from shapely.affinity import affine_transform
from skimage import transform
from skimage.draw import polygon
import pandas as pd

from lib import frame_diff_entity as ent
from lib import code_enum as ce, diff_util, figures
import lib.utils as tag_utils
from lib import print_utils

random.seed(12)


def display_frame_pairs(frame_a, frame_b, corner_desc=False, wall_desc=False, display=True, use_b_axis=False):
    """
    绘出户型对比图
    :param frame_a:
    :param frame_b:
    :param corner_desc: 是否显示点坐标
    :param wall_desc: 是否显示墙的长度
    :param display: True, 直接调试中显示; False, 保存到指定目录
    :param use_b_axis: 将frame_a的坐标系换算到b.
    :return:
    """
    size = ent.DiffFrame.DISPLAY_SIZE
    _margin = int(size * 0.01)
    fig = plt.figure(1, figsize=(12, 6), dpi=90)
    ax_a = fig.add_subplot(121)
    ax_a.axis('off')
    ax_b = fig.add_subplot(122)
    ax_b.axis('off')
    for _ax, _frame in zip([ax_a, ax_b], [frame_a, frame_b]):
        if use_b_axis:
            _matrix_1d = frame_b.get_trans_matrix_1d()
        else:
            _matrix_1d = _frame.get_trans_matrix_1d()
        # 绘制角点
        for _p in _frame.corner_list:
            _scale_p = affine_transform(_p.obj, _matrix_1d)
            figures.plot_coords(_ax, _scale_p, color=_p.color, zorder=_p.zorder, alpha=_p.alpha)
            if corner_desc:
                figures.add_origin(_ax, _scale_p, 'center', _p.name)
        # 绘制墙体
        for _w in _frame.wall_list:
            _scale_w = affine_transform(_w.obj, _matrix_1d)
            figures.plot_line(_ax, _scale_w, color=figures.BLUE, zorder=_w.zorder, linewidth=1, alpha=_w.alpha)
            figures.plot_line(_ax, _scale_w, color=_w.color, zorder=_w.zorder, linewidth=_w.linewidth, alpha=_w.alpha)
            if wall_desc:
                figures.add_origin(_ax, _scale_w, 'center', str(_w.length))
        # 绘制墙体附件
        for _w_i in _frame.wall_item_list:
            if not _w_i.is_matched:
                _scale_w_i = affine_transform(_w_i.obj, _matrix_1d)
                figures.plot_line(_ax, _scale_w_i, color=figures.BLUE, zorder=_w_i.zorder, linewidth=1, alpha=_w_i.alpha)
                figures.plot_line(_ax, _scale_w_i, color=_w_i.color, zorder=_w_i.zorder, linewidth=_w_i.linewidth, alpha=_w_i.alpha)
                if wall_desc:
                    figures.add_origin(_ax, _scale_w_i, 'center', str(_scale_w_i.length))
        figures.set_limits(_ax, -_margin, size + _margin, -_margin, size + _margin)
    if display:
        plt.show()
    else:
        # plt.savefig('data/mod_diff_res/img/{}-{}.jpg'.format(frame_a.frame_id, frame_b.frame_id), bbox_inches='tight', pad_inches=0)
        plt.savefig('data/reform_doc_pic/skeleton/{}-{}.jpg'.format(frame_a.frame_id, frame_b.frame_id), bbox_inches='tight', pad_inches=0)
        plt.close()


def display_frame_quads(frame_a, frame_b, frame_a_img, frame_b_img, corner_desc=False, wall_desc=False, display=True, use_b_axis=False):
    """
    绘出户型对比图(包含原图)
    :param frame_a:
    :param frame_b:
    :param frame_a_img:
    :param frame_b_img:
    :param corner_desc: 是否显示点坐标
    :param wall_desc: 是否显示墙的长度
    :param display: True, 直接调试中显示; False, 保存到指定目录
    :param use_b_axis: 将frame_a的坐标系换算到b.
    :return:
    """
    size = ent.DiffFrame.DISPLAY_SIZE
    _margin = int(size * 0.01)
    fig = plt.figure(1, figsize=(12, 12), dpi=90)
    ax_a = fig.add_subplot(221)
    ax_a.axis('off')

    # 户型原图
    ax_aa = fig.add_subplot(224)
    ax_aa.axis('off')
    ax_aa.imshow(frame_a_img)

    ax_b = fig.add_subplot(222)
    ax_b.axis('off')
    # 户型原图
    ax_bb = fig.add_subplot(223)
    ax_bb.axis('off')
    ax_bb.imshow(frame_b_img)

    for _ax, _frame in zip([ax_a, ax_b], [frame_a, frame_b]):
        if use_b_axis:
            _matrix_1d = frame_b.get_trans_matrix_1d()
        else:
            _matrix_1d = _frame.get_trans_matrix_1d()
        # 绘制角点
        for _p in _frame.corner_list:
            _scale_p = affine_transform(_p.obj, _matrix_1d)
            figures.plot_coords(_ax, _scale_p, color=_p.color, zorder=_p.zorder, alpha=_p.alpha)
            if corner_desc:
                figures.add_origin(_ax, _scale_p, 'center', _p.name)
        # 绘制墙体
        for _w in _frame.wall_list:
            _scale_w = affine_transform(_w.obj, _matrix_1d)
            figures.plot_line(_ax, _scale_w, color=figures.BLUE, zorder=_w.zorder, linewidth=1, alpha=_w.alpha)
            figures.plot_line(_ax, _scale_w, color=_w.color, zorder=_w.zorder, linewidth=_w.linewidth, alpha=_w.alpha)
            if wall_desc:
                figures.add_origin(_ax, _scale_w, 'center', str(_w.length))
        # 绘制墙体附件
        for _w_i in _frame.wall_item_list:
            if not _w_i.is_matched:
                _scale_w_i = affine_transform(_w_i.obj, _matrix_1d)
                figures.plot_line(_ax, _scale_w_i, color=figures.BLUE, zorder=_w_i.zorder, linewidth=1, alpha=_w_i.alpha)
                figures.plot_line(_ax, _scale_w_i, color=_w_i.color, zorder=_w_i.zorder, linewidth=_w_i.linewidth, alpha=_w_i.alpha)
                if wall_desc:
                    figures.add_origin(_ax, _scale_w_i, 'center', str(_scale_w_i.length))
        figures.set_limits(_ax, -_margin, size + _margin, -_margin, size + _margin)
    if display:
        plt.show()
    else:
        plt.savefig('data/mod_diff_res/img_quad/{}-{}.jpg'.format(frame_a.frame_id, frame_b.frame_id), bbox_inches='tight', pad_inches=0)
        plt.close()


def distance_matrix(frame_a, frame_b, distance_threshold=2000):
    """
    计算点和点的距离矩阵
    :param frame_a:
    :param frame_b:
    :param distance_threshold:
    :return:
    """
    a_corner_list = frame_a.corner_list
    b_corner_list = frame_b.corner_list
    # 获取两户型长宽
    avg_w, avg_h = (frame_a.get_width() + frame_b.get_width()) / 2, (frame_a.get_height() + frame_b.get_height()) / 2
    # 归一化长度
    _norm_len = min(avg_h, avg_w)
    # 矩阵模板
    _matrix = np.ones((len(a_corner_list), len(b_corner_list))) * 100
    for a_i, a_c in enumerate(a_corner_list):
        # a_type = a_c.p_type
        for b_i, b_c in enumerate(b_corner_list):
            # b_type = b_c.p_type
            # if a_type != b_type:
            if a_c.line_cnt != b_c.line_cnt:
                # 点类别不一致置为不可达.
                _matrix[a_i, b_i] = 1e10
                continue
            # _distance = diff_util.p2p_euclidean(a_c.coord, b_c.coord)
            _distance = abs(a_c.centroid_distance - b_c.centroid_distance) \
                        + abs(a_c.entrance_distance - b_c.entrance_distance)\
                        + 2 * abs(a_c.min_contour_distance - b_c.min_contour_distance)
            if _distance > distance_threshold:
                _matrix[a_i, b_i] = 2e10 + _distance
                continue
            # 相对于点坐标距离
            _matrix[a_i, b_i] = _distance / _norm_len
    return _matrix


def estimate_trans_matrix(frame_a, frame_b, sum_diff_threshold=2000):
    """
    通过枚举有限的位置得到变换矩阵
    :param frame_a:
    :param frame_b:
    :param sum_diff_threshold:
    :return:
    """
    # 组合已经配好的点
    _frame_a_center = np.array(frame_a.centroid.coords)[0]
    _frame_b_center = np.array(frame_b.centroid.coords)[0]
    matched_list_a, matched_list_b = [_.coord for _ in frame_a.get_matched_corners()], [_.coord for _ in frame_b.get_matched_corners()]
    matched_list_a.extend([list(frame_a.centroid.coords)[0], frame_a.entrance_item.center])
    matched_list_b.extend([list(frame_b.centroid.coords)[0], frame_b.entrance_item.center])
    matched_list_a_np, matched_list_b_np = np.array(matched_list_a), np.array(matched_list_b)

    if len(matched_list_a) > 16:
        # affine 变化最少6对点
        tform = transform.estimate_transform('euclidean', np.array(matched_list_a), np.array(matched_list_b))
        # 去除shear
        # tform = transform.AffineTransform(rotation=tform.rotation, translation=tform.translation)
        trans_err = np.sum(np.abs(tform(matched_list_a_np) - matched_list_b_np))
        if trans_err < sum_diff_threshold:
            logging.info("use estimate_transform...")
            return tform, trans_err
    # 如果基于匹配点估计失败使用枚举模式
    mats = diff_util.generate_all_trans_matrix(_frame_a_center, _frame_b_center, frame_a.ROTATIONS)
    res_mats = []

    edge_item_list_a, edge_item_list_b = [_.center for _ in frame_a.wall_item_list if _.edge_computed], \
                                         [_.center for _ in frame_b.wall_item_list if _.edge_computed]
    edge_list_a, edge_list_b = matched_list_a + [_.coord for _ in frame_a.edge_pts] + edge_item_list_a, \
                                matched_list_b + [_.coord for _ in frame_b.edge_pts] + edge_item_list_b
    a_np, b_np = np.array(edge_list_a), np.array(edge_list_b)
    a_toilet_area_obj = [_area.obj for _area in frame_a.area_list if _area.room_type == ce.AreaType.toilet.value]
    b_toilet_area_obj = [_area.obj for _area in frame_b.area_list if _area.room_type == ce.AreaType.toilet.value]
    for _mat_idx, _mat in enumerate(mats):
        _trans = transform.AffineTransform(matrix=_mat)
        coord_diff = _trans(matched_list_a_np) - matched_list_b_np
        _trans_err = np.sum(np.abs(coord_diff))
        median_diff = np.median(coord_diff, axis=0)

        _mat[0:2, 2] -= median_diff

        _trans = transform.AffineTransform(matrix=_mat)
        coord_diff = _trans(matched_list_a_np) - matched_list_b_np
        _trans_err = np.sum(np.abs(coord_diff))

        _trans_matrix = _trans.params
        _trans_matrix_1d = list(_trans_matrix[:2, :2].flatten()) + list(_trans_matrix[[0, 1], -1])
        # 计算卫生间和厨房的重合比
        _inter_err = 0
        for a_area in a_toilet_area_obj:
            max_inter = float('-inf')
            a_area_b = affine_transform(a_area, _trans_matrix_1d)
            for b_area in b_toilet_area_obj:
                _inter = a_area_b.difference(b_area)
                max_inter = max(_inter.area, max_inter)
            _inter_err += np.sqrt(max_inter)
        a_np_trans = _trans(a_np)
        _, __, dist = diff_util.nearest_fit(a_np_trans, b_np)
        # d = np.sqrt(
        #     np.sum(a_np_trans ** 2, 1)[:, None]
        #     + np.sum(b_np ** 2, 1)[None, :]
        #     - 2 * a_np_trans.dot(b_np.T)
        # )
        # # choice = np.argmin(d, 1)
        # dist = np.sum(np.min(d, 1))

        res_mats.append((dist + _inter_err, _trans))
    _dist_err, min_trans = sorted(res_mats)[0]
    return min_trans, _dist_err


def estimate_trans_matrix_by_numeration(a_np, b_np, mats):
    res_mats = []
    for _mat_idx, _mat in enumerate(mats):
        _trans = transform.AffineTransform(matrix=_mat)
        coord_diff = _trans(a_np) - b_np
        _trans_err = np.sum(np.abs(coord_diff))
        median_diff = np.median(coord_diff, axis=0)
        # 上一步估计可能存在平移误差, 这里用中位数修正.
        _mat[0:2, 2] -= median_diff
        _trans = transform.AffineTransform(matrix=_mat)
        coord_diff = _trans(a_np) - b_np
        _trans_err = np.sum(np.abs(coord_diff))
        res_mats.append((_trans_err, _trans))
        res_mats.append((_trans_err, _trans))
    _min_mat_err, min_trans = sorted(res_mats)[0]
    return min_trans, _min_mat_err


# def estimate_trans_matrix(frame_a, frame_b, sum_diff_threshold=2000):
#     """
#     :param frame_a:
#     :param frame_b:
#     :param sun_diff_threshold:
#     :return:
#     """
#     # 估计变换矩阵
#     matched_list_a, matched_list_b = [_.coord for _ in frame_a.get_matched_corners()], [_.coord for _ in frame_b.get_matched_corners()]
#     # 增加入户门和重心点
#     matched_list_a.extend([list(frame_a.centroid.coords)[0], frame_a.entrance_item.center])
#     matched_list_b.extend([list(frame_b.centroid.coords)[0], frame_b.entrance_item.center])

    # else:
    #     tform = estimate_trans_matrix_by_enumeration(frame_a, frame_b, sun_diff_threshold)
    # # 复制一个A->B的A
    # # ##### LINE DIFF #####
    # # 匹配绝地误差SUM < 500 mm
    # if np.allclose(tform(matched_list_a), matched_list_b, atol=sun_diff_threshold):
    #     logging.info("transform success")
    # else:
    #     logging.info("transform fail!")
        # raise Exception("transform fail!")


def frame_diff(frame_a, frame_b):
    """
    户型的差异
    :return:
    """
    status = 0
    # ##### POINT DIFF #####
    _matrix = distance_matrix(frame_a, frame_b)
    row_ind, col_ind = linear_sum_assignment(_matrix)
    for _a_i, _b_i in zip(row_ind, col_ind):
        _a_c = frame_a.corner_list[_a_i]
        _b_c = frame_b.corner_list[_b_i]
        _tmp_dist = _matrix[_a_i, _b_i]
        # 判断Corner type是否一致 TODO

        # 过滤直线断墙? TODO
        if _tmp_dist > 50:
            frame_a.add_mismatch_corner(_a_c)
            frame_b.add_mismatch_corner(_b_c)
            # logging.info("mismatch", _a_i, _b_i, _a_c.coord, _b_c.coord, _tmp_dist)
        else:
            _random_c = random.choice(figures.COLOR_MAP)
            frame_a.add_match_corner(_a_c, _b_c, _random_c)
            frame_b.add_match_corner(_b_c, _a_c, _random_c)
    # mismatched = set(range(len(frame_b.corner_list))) - set(col_ind)
    # for _b_i in mismatched:
    #     _b_c = frame_b.corner_list[_b_i]
    #     frame_b.add_missing_corner(_b_c)
    #     print("missed:", _b_c.coord)
    # TODO 动态阈值
    min_sum_mat_err = 40000
    tform, _min_mat_err = estimate_trans_matrix(frame_a, frame_b, sum_diff_threshold=2000)
    if _min_mat_err > min_sum_mat_err:
        logging.warning("transform fail: {}".format(_min_mat_err))
        return frame_a, frame_b, -1
    # ##### LINE DIFF #####
    # MISMATCHED LINE
    _frames_list = [frame_a, frame_b]
    for _current_idx, _current_f in enumerate(_frames_list):
        other_f = _frames_list[1 - _current_idx]
        for _pt in _current_f.get_mismatched_corners():
            # 变换到另外一个坐标系
            _pt_coord = tform([_pt.coord])[0]
            for _connected_pt in _pt.connected_pts:
                _line_pt_ids = frozenset([_pt.uid, _connected_pt.uid])
                _wall = _current_f.pts_key_to_line_map[_line_pt_ids]
                if _connected_pt.is_matched:
                    # 半配对点的线召回
                    # 配对成功的另外一个户型点.
                    op_matched_pt = _connected_pt.matched_obj
                    for _op_connected_pt in op_matched_pt.connected_pts:
                        # 另外一个户型点关联的点有没有未配对点
                        if not _op_connected_pt.is_matched:
                            _pt_line_pt_ids = frozenset([op_matched_pt.uid, _op_connected_pt.uid])
                            _op_wall = other_f.pts_key_to_line_map[_pt_line_pt_ids]
                            # 变换
                            op_pt_connedted_dist = diff_util.p2p_euclidean(_pt_coord, _op_connected_pt.coord)
                            # 未配对点变换后坐标是否符合是否阈值
                            if op_pt_connedted_dist > 500 or abs(_op_wall.length - _wall.length) > 500:
                                # 未配对点线线长是否符合阈值
                                _current_f.add_mismatch_wall(_wall)
                                other_f.add_mismatch_wall(_op_wall)
                            else:
                                _current_f.add_match_corner(_pt, _op_connected_pt)
                                other_f.add_match_corner(_op_connected_pt, _pt)
                                _current_f.add_match_wall(_wall, _op_wall)
                                other_f.add_match_wall(_op_wall, _wall)
                    pass
                else:
                    # 未配对点
                    _current_f.add_mismatch_wall(_wall)
    # MATCHED LINE
    for _pt in frame_a.get_matched_corners():
        _match_op_pt = _pt.matched_obj
        for _connected_pt in _pt.connected_pts:
            if _connected_pt.is_matched:
                _line_pt_ids = frozenset([_pt.uid, _connected_pt.uid])
                _wall = frame_a.pts_key_to_line_map[_line_pt_ids]
                _connected_match_op_pt = _connected_pt.matched_obj
                _op_line_pt_ids = frozenset([_match_op_pt.uid, _connected_match_op_pt.uid])
                if _op_line_pt_ids in frame_b.pts_key_to_line_map:
                    _random_c = random.choice(figures.COLOR_MAP)
                    _op_wall = frame_b.pts_key_to_line_map[_op_line_pt_ids]
                    if abs(_op_wall.length - _wall.length) < 300:
                        frame_a.add_match_wall(_wall, _op_wall, _random_c)
                        frame_b.add_match_wall(_op_wall, _wall, _random_c)
                # else:
                #     print("mismatched wall", _op_line_pt_ids)
                #     frame_a.add_mismatch_wall(_wall)
                #     frame_b.add_mismatch_wall(_op_wall)
    # ##### ROOM DIFF #####
    # 定义模板
    size = ent.DiffFrame.DISPLAY_SIZE
    # 两层比较模板
    canvas_temp = np.zeros((size, size, 2), dtype=np.int)
    # 转换A到B 会有循环引用问题导致deepcopy栈溢出
    # frame_a_cp = copy.deepcopy(frame_a)
    frame_a_cp = frame_a
    frame_a_cp.trans_room_a_to_b(tform, frame_b.entrance_item.entrance)
    for _frame_idx, _frame in enumerate([frame_a_cp, frame_b]):
        for _room in _frame.area_list:
            room_pts_array = []
            for _room_pt_idx in _room.room_pts:
                room_pt = _frame.ori_p_map[_room_pt_idx]
                # if room_pt.is_matched and _frame_idx == 0:
                #     # 如果A有对应的匹配点直接用匹配点.
                #     room_pt = room_pt.matched_obj
                # 用frame_b的缩放矩阵
                _scale_p = affine_transform(room_pt.obj, frame_b.get_trans_matrix_1d())
                room_pts_array.extend(list(_scale_p.coords))
            c = np.array(room_pts_array)
            rr, cc = polygon(c[:, 0], c[:, 1], (size, size))
            # room_idx从0开始
            canvas_temp[rr, cc, _frame_idx] = _room.room_idx
    _counter = Counter((zip(canvas_temp[:, :, 0].flatten(), canvas_temp[:, :, 1].flatten())))
    a_pix_cnt, b_pix_cnt = np.count_nonzero(canvas_temp[:, :, 0]), np.count_nonzero(canvas_temp[:, :, 1])
    mean_area_pixel_cnt = (a_pix_cnt + b_pix_cnt) // 2
    pixel_to_area_size = (1e-6 * frame_a_cp.area_size) / a_pix_cnt
    for _k, _count in _counter.most_common():
        if (_count // mean_area_pixel_cnt) < 0.01:
            pass
        _a_name, _b_name = u'空白', u"空白"
        _area_size = round(pixel_to_area_size*_count, 2)
        _a_room = frame_a_cp.area_list[_k[0]-1]
        _b_room = frame_b.area_list[_k[1]-1]
        if _k[0] != 0 and _k[1] != 0:
            _a_name = _a_room.name
            _b_name = _b_room.name
            _a_room.matched_obj.append((_b_room, _area_size))
            _b_room.matched_obj.append((_a_room, _area_size))
        elif _k[0] == 0 and _k[1] != 0:
            _b_name = _b_room.name
        elif _k[0] != 0 and _k[1] == 0:
            _a_name = _a_room.name
        logging.debug(u"{}有{}平分配给{} ".format(_a_name, _area_size, _b_name))

    for _room in frame_b.area_list:
        # 选择已匹配/角点的点初始化点.
        _room_pts = _room.room_pts
        # 关联房间
        _match_a_room_ids = set([_.uid for _, __ in _room.matched_obj])
        # (是否已匹配, 锐角, 点id)
        _points_arr = [(1 - int(frame_b.ori_p_map[_pt_id].is_matched), abs(90 - abs(_a)), _pt_id) for _a, _pt_id in zip(_room.point_angle, _room_pts,)]
        _init_pt_id = sorted(_points_arr, key=lambda x: (x[0], x[1]))[0][-1]
        # 逆时针按照遍历点.
        _init_pt_idx = _room_pts.index(_init_pt_id)
        _pts_len = len(_room_pts)
        # 上一个点
        _prev_pt = frame_b.ori_p_map[_init_pt_id]
        for _pt_offset in range(1, _pts_len):
            # 从初始化点开始遍历点
            _current_pt_id = _room_pts[(_init_pt_idx + _pt_offset) % _pts_len]
            _current_pt = frame_b.ori_p_map[_current_pt_id]
            # 找到当前墙体
            _line_pt_ids = frozenset([_prev_pt.uid, _current_pt.uid])
            _current_line = frame_b.pts_key_to_line_map[_line_pt_ids]
            if _prev_pt.is_matched and _current_pt.is_matched and _current_line.is_matched:
                # 如果两个都匹配上, 线就匹配上
                # 要检查附件是否存在改变. TODO
                pass
            else:
                # 计算匹配关系: 全匹配, 半匹配, 未匹配
                # 利用STRtree找到关联墙体.
                related_a_walls = frame_a_cp.wall_str_tree.query(_current_line.obj)
                # 判断所有关联墙体的类别关系: 必须要是来自于匹配上的原分间, 斜率要一致.
                wall_match_score = []
                for _a_diluted_wall in related_a_walls:
                    _diluted_wall_id = id(_a_diluted_wall)
                    _a_wall = frame_a_cp.diluted_wall_id_to_wall[_diluted_wall_id]
                    # 斜率是否一致
                    if abs(int(_a_wall.angle // 90)) != abs(int(_current_line.angle // 90)):
                        continue
                    # 是否存在面积分配关系
                    has_matched_room = False
                    for _a_wall_room in _a_wall.rooms:
                        if _a_wall_room.uid in _match_a_room_ids:
                            has_matched_room = True
                            break
                    if not has_matched_room:
                        continue
                    # 计算交集
                    inter_obj = _current_line.obj.intersection(_a_diluted_wall)
                    if not inter_obj.is_empty:
                        wall_match_score.append((inter_obj.length, inter_obj, _a_wall))
                if wall_match_score:
                    # TODO 如果每个a的候选墙是同一直线&没有匹配上&类型一致, 可以合并成为一个超墙.
                    temp_match_wall = []
                    _random_c = random.choice(figures.COLOR_MAP)
                    # sorted(wall_match_score, key=lambda x: x[0], reverse=True)
                    for _inter_line_len, _inter_line, matched_frame_a_wall in wall_match_score:
                        if ((not matched_frame_a_wall.is_matched) or matched_frame_a_wall.is_almost_matched) \
                                and (abs(matched_frame_a_wall.obj.length - _inter_line_len) < 300
                                     or abs(_inter_line_len - _current_line.obj.length) < 300)\
                                and _inter_line_len > 100:
                            # TODO 约束点在一个分间里
                            if matched_frame_a_wall.is_almost_matched:
                                _random_c = matched_frame_a_wall.color
                            matched_frame_a_wall.set_almost_matched(_current_line, _random_c)
                            temp_match_wall.append(matched_frame_a_wall)
                    # frame_b记录frame_a的超墙
                    if temp_match_wall:
                        _current_line.set_super_wall_matched(temp_match_wall, _random_c)
                else:
                    _current_line.set_mismatched()
                # TODO 构建frame_a的超墙
                # 可能存在1对多, 因此不能直接赋给原户型
                # matched_frame_a_wall.matched_obj = _current_line
            _prev_pt = _current_pt
    # LINE ITEM MATCH
    for _wall in frame_a_cp.wall_list:
        if not _wall.edge_computed:
            if not (_wall.is_matched or _wall.is_almost_matched):
                _wall.set_mismatched()
            elif _wall.is_matched:
                # 附件的变化-只标记配对上的墙体-
                _matched_list = _wall.matched_obj
                _compare_res_list = []
                for _matched_list in [[_wall], _wall.matched_obj]:
                    _item_list = []
                    for _wall_with_item in _matched_list:
                        for _item in _wall_with_item.items:
                            _item_list.append(_item)
                    _compare_res_list.append(_item_list)
                item_type_set = [set(), set()]
                total_len = [0, 0]
                center_pos = [list(), list()]
                for _idx, _frame in enumerate([frame_a_cp, frame_b]):
                    for item_id in _compare_res_list[_idx]:
                        item = _frame.ori_line_item_map[item_id]
                        item_type_set[_idx].add(item.line_item_type)
                        total_len[_idx] = total_len[_idx] + item.length
                        # 计算附件相对于墙体两端的特征
                        _item_wall = _frame.ori_line_map[item.line_id]
                        center_pos[_idx].append(sorted([item.start, _item_wall.length - item.length - item.start]))
                _, __, item_corner_dist = diff_util.nearest_fit(np.array(center_pos[0]), np.array(center_pos[1]))
                if len(_compare_res_list[0]) != len(_compare_res_list[1])\
                        or frozenset(item_type_set[0]) != frozenset(item_type_set[1])\
                        or abs(total_len[0] - total_len[1]) > 200\
                        or item_corner_dist/max(1, min(len(item_type_set[0]), len(item_type_set[1]))) > 270:
                    for _idx, _frame in enumerate([frame_a_cp, frame_b]):
                        for _item in _compare_res_list[_idx]:
                            item = _frame.ori_line_item_map[_item]
                            _frame.add_mismatch_line_item(item)
    # 遍历户型找同一个对应墙体的 frame_b 的超墙
    frame_b_super_wall_dict = defaultdict(list)
    for _wall in frame_b.wall_list:
        if not (_wall.is_matched or _wall.is_almost_matched) and not _wall.edge_computed:
            _wall.set_mismatched()
        if _wall.is_almost_matched:
            frame_a_wall = _wall.matched_obj[0]
            frame_b_super_wall_dict[frame_a_wall.uid].append(frame_a_wall)
    for a_wall_uid in frame_b_super_wall_dict:
        tmp_b_walls = frame_b_super_wall_dict[a_wall_uid]
        frame_a_cp.ori_line_map[a_wall_uid].set_super_wall_matched(tmp_b_walls)
    # TODO 二次匹配未匹配上的线: 遍历来源分间所有线, 符合条件: 长度, 斜率要一致.
    # TODO 合并frame_a和frame_b的超墙: 遍历户型找同一个对应墙体.
    # 使用b户型的画图变换坐标系
    frame_a_cp.draw_matrix_dict = frame_b.draw_matrix_dict
    return frame_a_cp, frame_b, status


def std_frame_diff(frame_a_id, frame_b_id, frame_json_a, frame_json_b, **kwargs):
    """
    标准户型矢量对比
    :param frame_a_id:
    :param frame_b_id:
    :param frame_json_a:
    :param frame_json_b:
    :param kwargs:
    :return:
    """
    frame_a = ent.FrameStdVecObj(frame_json_a)
    frame_b = ent.FrameStdVecObj(frame_json_b)

    # entity_frame_a, eval_result_a = extract_single_frame_feature(frame_a_id, frame_json_a, **kwargs)
    # entity_frame_b, eval_result_b = extract_single_frame_feature(frame_b_id, frame_json_b, **kwargs)
    # frame_a.set_entity_frame(entity_frame_a, json.loads(eval_result_a[1]))
    # frame_b.set_entity_frame(entity_frame_b, json.loads(eval_result_a[1]))

    frame_a_cp, frame_b, status = frame_diff(frame_a, frame_b)
    return frame_a_cp, frame_b


def try_std_frame_diff():
    """
    双户型对比
    :return:
    """
    conf = dict()
    tag_utils.collect_conf(r"frame_eval/frame_tag_lib/conf.yml", conf)
    # f_1, f_2 = '11000000358315', '11000019494778'
    # f_1, f_2 = '11000000369164', '11000005988924' 1120026314148154-1120042895523876
    # f_1, f_2 = '11000000381665', '11000011810051' 1120033124266645-11000008689709
    # f_1, f_2 = '11000012403405', '11000006363061' 11000014060830-1120040141392400
    # f_1, f_2 = '1120026361330753', '11000000364969' 1120024829663145-11000010259688
    # 11000005886726 - - 1120044009183541 1120039478581206-1120034405145727
    # 11000016627335-1120044728809004
    # f_1, f_2 = '11000004657855', '1120044660616980' 1120044206582239- 1120023694606683
    # f_1, f_2 = '11000006846061', '1120041364217033' 11000002207017- 1120040140331784
    # f_1, f_2 = '1120044701513507', '11000000888408' 11000009051198- 11000014596982 11000015283294- 11000015640500
    f_1, f_2 = '11000016627335', '1120044728809004'
    # f_1, f_2 = '11000004657855--90-r', '1120044660616980'
    # f_1, f_2 = '1120023765937602-45', '1120027981048009'
    # f_1_json = diff_util.load_local_frame_json(f_1)
    # f_2_json = diff_util.load_local_frame_json(f_2)

    # f_1, f_2 = '1120023765937602', '1120027981048009'
    # f_1, f_2 = '11000016859105', '11000006597664'  1116599535334135-11000018329015 11000009773714- 11000009773714
    # f_1, f_2 = '1120023389283692', '1120042291313105'
    # f_1, f_2 = '1120032590462553', '11000013302900'
    # f_1, f_2 = '1120043174416197', '11000003678326'

    # Bad case
    # 1120026021113270 - 11000005819301 1120035262124547- 11000014461319
    # 1120021055503355 - 11000003431849
    # 1120040168553882 - 11000000703684 1120029595357508- 11000018831082
    # 1120022589993622 - 1114058553380277
    # 1120033595305062 - 11000019667220 1120035193966969- 11000004838318 1120044701513507- 11000000888408
    # 1120038940542676 - 1120042659206701
    # 11000001868182 - 11000000368908  11000015649617- 1120033206113660 1120020474517353-11000005563385
    # 1120031587222197 - 1117559916152921
    # 1116410942910893 - 11000007414533
    # 11000015649617 - 1120033206113660
    f_1_json, f_2_json = diff_util.download_frame_json([f_1, f_2], with_json=False)
    frame_s_tuple = std_frame_diff(f_1, f_2, f_1_json, f_2_json, conf=conf)
    std_imgs = []
    for _idx, _frame in enumerate(frame_s_tuple):
        poly_arr = []
        for _wall in _frame.wall_list:
            if not _wall.is_matched and not _wall.edge_computed:
                _polys = [{'x': __[0], 'y': __[1]}for __ in _wall.get_paired_wall_polygon()]
                _current_poly = {'points': _polys, "stroke": "#00FFFF", "stroke-width": 0, "fill": "#0000FF", "opacity": 0.2}
                poly_arr.append(_current_poly)
        frame_json_dict = frame_s_tuple[1-_idx].dump(poly_arr)
        _img = print_utils.draw_json(frame_json_dict, show=False)
        std_imgs.append(transform.rescale(np.array(_img), 2.5))
    display_frame_quads(frame_s_tuple[0], frame_s_tuple[1], std_imgs[0], std_imgs[1])

    # 测试标记误差容错
    # logging.info(diff_util.is_false_diff_room(frame_s_tuple[1].area_list[5], frame_s_tuple[0]))
    # print(diff_util.is_false_diff_room(frame_s_tuple[0].area_list[10], frame_s_tuple[0], frame_s_tuple[1]))
    # print_utils.draw_json(frame_json_dict, save_path="./_{}.png".format(_idx))
    pass


def batch_draw_frame():
    """
    批量测试
    :return:
    """
    ori_excel = pd.read_excel('data/mod_diff_res/bj_res_mod_all.xls')
    sample_df = ori_excel.sample(frac=0.05, random_state=58)
    _cnt = 0
    for _row in sample_df.itertuples():
        try:
            _ori_frame = _row.res_contour_rept_id
            logging.info("-------------Matching-----------", _ori_frame)
            if _ori_frame in {1120026799842049, 1120035993402211, 1120032590462553, 11000002561007, 1120033078136440, 11000016375715, 1111499556056889, 1120030662218798, 11000009319226, 1120026410614183, 1120037288598625}:
                continue
            # if _ori_frame in {11000000407455, 1120040690975454, 11000000407455, 11000018807973, 11000000482908, 1120040728767439, 11000000562235, 1120043258332740, 11000000826905, 11000010734186, 11000001632169, 11000017721859, 11000001868182, 11000002234964, 11000001868182, 11000020491870, 11000001868182, 11000000368908, 11000002270873, 11000001532428, 11000002730281, 11000009440603, 11000002785285, 1120022308880033, 11000002785285, 11000004379857, 11000003041931, 11000010449611, 11000003253162, 11000006694113, 11000003349246, 1120042659485635, 11000004661022, 11000018472272, 11000004891975, 1120043946474712, 11000005105111, 11000007073160, 11000005105111, 11000011605416, 11000005105111, 11000004889521, 11000005522117, 11000003844317, 11000005522117, 11000003009336, 11000005563815, 11000008368868, 11000005563815, 1120035762588149, 11000005581731, 11000002063624, 11000006308559, 11000016882338, 11000006401964, 1120037748044683, 11000006407780, 1120041131430915, 11000006454299, 11000009297202, 11000006656838, 1120037073648586, 11000006696938, 11000007425267, 11000006696938, 11000009905817, 11000006859448, 11000008338448, 11000006882721, 11000009128137, 11000007474544, 11000003401002, 11000007474544, 1120021813768704, 11000007474544, 1120025869022473, 11000007581299, 11000002720171, 11000007705545, 11000006942775, 11000008102322, 1120037413414687, 11000008663809, 11000006901930, 11000008663809, 1120033352920204, 11000008663809, 1120044586203263, 11000009757553, 11000003151584, 11000009757553, 1120044147856383, 11000009773714, 11000016429180, 11000010009267, 11000009960442, 11000010009267, 1120034826766189, 11000010089237, 1114015005208412, 11000010208381, 11000005627870, 11000010568601, 11000008951335, 11000010764189, 11000009278807, 11000010764189, 11000001563439, 11000011146956, 11000001341860, 11000011146956, 11000008022656, 11000011146956, 11000001833956, 11000011408914, 11000010682770, 11000011408914, 11000010733209, 11000011408914, 11000019127811, 11000011585610, 1120039334922644, 11000011791536, 11000000434744, 11000011791536, 1120033261683361, 11000011791536, 11000001701775, 11000011883394, 11000019461544, 11000011883394, 11000008546956, 11000012510394, 11000012444108, 11000012510394, 1120035431078398, 11000012515039, 1114666515385442, 11000012515039, 11000003626575, 11000012537114, 11000002782485, 11000012537114, 1116398452534398, 11000012947925, 1120031439375694, 11000012947925, 1120039839355789, 11000012947925, 11000020125002, 11000013070459, 11000000422878, 11000013070459, 11000003654176, 11000013087439, 1120023327415017, 11000013087439, 11000012063341, 11000013371525, 1120029834571876, 11000013893644, 11000001499045, 11000013917026, 11000004261873, 11000014005536, 1120038405501029, 11000014014624, 11000014554619, 11000014054245, 11000020143837, 11000014060830, 1120040141392400, 11000014193816, 1120041073758567, 11000014202310, 11000012618442, 11000014202310, 11000006554634, 11000014324771, 11000001145098, 11000014324771, 1113488565792036, 11000014324771, 1120021612426788, 11000014324771, 1120025891041749, 11000014341081, 1120041406240026, 11000014782729, 1120041714592428, 11000014916243, 11000008912347, 11000014916243, 11000007881505, 11000014934231, 11000003636077, 11000014934231, 11000007869407, 11000014934231, 11000013541818, 11000015076634, 11000000859973, 11000015076634, 11000003075829, 11000015076634, 11000014695268, 11000015160146, 1120041363172424, 11000015160146, 11000012635669, 11000015236396, 1118084145409580, 11000015283294, 11000012932949, 11000015283294, 11000015640500, 11000015620200, 11000019393465, 11000015649617, 1120033206113660, 11000015743213, 11000007585776, 11000016283128, 1120032929172592, 11000016388467, 11000001342521, 11000016388467, 11000007066719, 11000016388467, 1120043947519670, 11000016406927, 11000015064418, 11000016561141, 1120039931667968, 11000016561141, 11000009956465, 11000016724472, 11000018154576, 11000016724472, 11000016040289, 11000016859105, 11000006597664, 11000016906011, 11000000731451, 11000016906011, 11000002185167, 11000017223388, 11000008675374, 11000017649879, 1120040009270753, 11000017917375, 1120037931540612, 11000018006445, 11000000947849, 11000018006445, 11000015854824, 11000018176750, 11000004505084, 11000018176750, 11000017446338, 11000018232317, 11000010996790, 11000018325595, 11000000583075, 11000018325595, 11000005513162, 11000018325595, 11000016044950, 11000018820062, 11000008386491, 11000018820062, 11000012583791, 11000018820062, 11000020600833, 11000018888762, 11000007684343, 11000018888762, 11000013448474, 11000018888762, 1120039680984449, 11000018942113, 1120039844632668, 11000019352726, 11000009489431, 11000019352726, 11000006909247, 11000019645508, 11000000888057, 11000020014537, 11000013600429, 11000020027708, 11000014251251, 11000020209826, 11000013209132, 11000020209826, 11000018967282, 11000020209826, 11000020135961, 11000020290222, 11000016399278, 11000020290222, 1120043513220543, 11000020387021, 11000002586385, 11000020387021, 11000019759082, 11000020503763, 11000005011657, 11000020503763, 11000007853219, 11000020576042, 11000001830452, 11000020576042, 1120040370089872, 11000020576042, 1120040917520699, 1110523997646115, 11000012492473, 1111297524821298, 11000009985828, 1111724280836682, 11000009048245, 1111724280836682, 1120033108551246, 1112024341606655, 11000013375207, 1112024341606655, 1115259907952159, 1112024341606655, 1120028583143341, 1112024341606655, 1115288409295446, 1112138071732523, 1114222048898625, 1112138071732523, 1118187024872362, 1112546846764553, 11000005418174, 1112546846764553, 11000011661668, 1113869350685821, 1120024071232912, 1113973519872628, 11000004398336, 1113973519872628, 11000000854415, 1114058553380798, 1120041549899224, 1114058553380798, 1120041984013866, 1114201264288486, 11000007346078, 1114201264288486, 11000020267651, 1114201264288486, 1120030742962280, 1114201264288486, 1120036164318400, 1114221644148890, 1120042933274284, 1114530816543235, 1120043201601420, 1114596659490859, 11000006602034, 1114619958588341, 11000010811568, 1114743569706628, 11000004241806, 1114743569706628, 11000005873050, 1114743569706628, 11000007681765, 1114743569706628, 11000012209807, 1114743569706628, 1117207995149516, 1114743569706628, 1120026867026984, 1114743569706628, 1120027597017641, 1114743569706628, 1120033556500389, 1114743569706628, 11000017631715, 1114890197594576, 1120041603303777, 1114948004016765, 1120033207161960, 1114948004016765, 11000002354911, 1115004115700316, 11000000762525, 1115096264797713, 11000006651910, 1115096264797713, 1120036036404459, 1115173824055332, 1116926666141198, 1115173824055332, 11000006740540, 1115174358020562, 11000004255398, 1115174358020562, 11000010754155, 1115235913911979, 11000011249138, 1115235913911979, 11000002512540, 1115343879204621, 1115262720756869, 1115423204502731, 1118110984784587, 1115423204502731, 1120040485411601, 1115423204502731, 11000014037602, 1115425899628952, 1120030681099774, 1115576685121268, 11000008104405, 1115576685121268, 1116285200845888, 1115576685121268, 1120035192921839, 1115576685121268, 11000020427608, 1115592772374304, 11000015848827, 1115592772374304, 1120026916310168, 1115598723828512, 11000014026816, 1115598723828512, 11000015975506, 1115598723828512, 1115015054707086, 1115598723828512, 1120028048160986, 1115671135317863, 11000012356511, 1115823944298178, 1112090894462082, 1115869133468228, 11000000433979, 1115869133468228, 1113905679101854, 1115902777052643, 11000008875068, 1115902777052643, 1120040690985835, 1115988461701695, 1113416012984442, 1116034547403894, 11000019115561, 1116068027911475, 11000002975857, 1116068027911475, 11000009144117, 1116068027911475, 11000009754312, 1116068027911475, 1120026192511438, 1116068027911475, 11000004478947, 1116075697458329, 1120027269768908, 1116125749374301, 11000003280611, 1116125749374301, 11000000718935, 1116308453018333, 11000006858093, 1116410942910893, 11000007414533, 1116441308098278, 1113454159392001, 1116510030458494, 11000000811926, 1116510030458494, 11000001234150, 1116510030458494, 11000001725241, 1116510030458494, 1120042767209205, 1116510030458494, 1120041260411254, 1116525420169976, 11000003916282, 1116525420169976, 1116419888313127, 1116556369916027, 11000020577537, 1116579778064884, 1115738144829136, 1116599535334135, 11000005274240, 1116599535334135, 11000011773644, 1116599535334135, 11000013785125, 1116599535334135, 1118027385204840, 1116599535334135, 118125318443198, 1116599535334135, 11000018329015, 1116668475796619, 11000004591871, 1116668475796619, 11000010376771, 1116737384541277, 1113802525700228, 1116849108217006, 11000003734419, 1116849108217006, 11000012154481, 1116849108217006, 1120040785387850, 1116849108217006, 1120042818940874, 1116849108217006, 117349887054354, 1116874049144934, 11000007459102, 1116874049144934, 1120040974144727, 1117003569777024, 11000017363195, 1117003569777024, 11000009727061, 1117075135852177, 1120037731054740, 1117075135852177, 11000017520075, 1117086502177238, 1117086888554523, 1117101094924361, 11000012673742, 1117211410099324, 11000020079597, 1117547455116068, 1111638430774130, 1117644322827894, 11000005989154, 1117701851377640, 11000002226922, 1117779987853410, 11000002856651, 1117779987853410, 11000017695808, 1117779987853410, 11000003757164, 1117863829631476, 11000002769363, 1117863829631476, 11000008031093, 1117985172942203, 1120038890988339, 1118036886637231, 11000001246089, 1118036886637231, 11000015444416, 1118040521764995, 11000018011188, 1118040521764995, 1116963034450442, 1118098633846667, 1120040843063289, 1118157867643897, 1120022670745471, 1120020308825969, 11000012510936, 1120020308825969, 1120023495308479, 1120020418947377, 11000014369919, 1120020418947377, 1113742875357624, 1120020418947377, 1114666658492816, 1120020418947377, 11000007541740, 1120020474517353, 11000005563385, 1120020483961041, 11000000853833, 1120020483961041, 11000001641878, 1120020483961041, 11000002033414, 1120020483961041, 11000005293749, 1120020483961041, 11000017252707, 1120020483961041, 1120021862004411, 1120020483961041, 1120031775316740, 1120020483961041, 11000011853936, 1120020518581485, 11000012703975, 1120020554233663, 1120021413178966, 1120020683225913, 1120034156603354, 1120020683225913, 1120036783798861, 1120020724116927, 1115846224202256, 1120021034500281, 1120021781264599, 1120021068084532, 1120038404600437, 1120021190768186, 11000013371644, 1120021190768186, 1120042239942264, 1120021245296204, 11000003936017, 1120021350236196, 1120029969840607, 1120021350236196, 11000004885954, 1120021365991205, 11000016948705, 1120021365991205, 1117589937384854, 1120021365991205, 11000011710990, 1120021429953421, 11000010983685, 1120021429953421, 11000008141815, 1120021755048303, 11000002826449, 1120021755048303, 11000018868234, 1120021755048303, 1120024148864486, 1120021755048303, 1120038902790666, 1120021803284105, 11000007234018, 1120021803284105, 1120025843855835, 1120021927016593, 1120025332129338, 1120021927016593, 11000005504206, 1120022058237563, 11000005084560, 1120022672840178, 11000005786745, 1120022743136211, 11000013857185, 1120023217249094, 1120026416903531, 1120023219342696, 1120026222917545, 1120023366213769, 1120039198557936, 1120023406059441, 1120039565378919, 1120023465943323, 1120036170614003, 1120023469096768, 11000013253593, 1120023499504852, 11000000374377, 1120023721871058, 11000000885410, 1120024041871696, 11000007918062, 1120024041871696, 1114509912657842, 1120024041871696, 1120036637391750, 1120024041871696, 1120040216890545, 1120024072275991, 1120026594114029, 1120024072275991, 1120029373067368, 1120024383838606, 11000005609239, 1120024448879886, 11000020409332, 1120024448879886, 11000015238828, 1120024485595117, 11000018309538, 1120024485595117, 1117609504862831, 1120024485595117, 1120027580242633, 1120024500277809, 11000005320782, 1120024500277809, 11000010856539, 1120024500277809, 1120025981261209, 1120024500277809, 1120023994683824, 1120024635623039, 11000008108237, 1120024635623039, 11000015192553, 1120024829663145, 1120022810264358, 1120024829663145, 11000010259688, 1120024837005652, 11000005534113, 1120024837005652, 11000011070237, 1120024837005652, 11000018080797, 1120024837005652, 1120029408720004, 1120024851701293, 1120022720046983, 1120024906320804, 11000015932530, 1120024906320804, 1120040540891659, 1120024906320804, 11000002785620, 1120025286000896, 1112706442915272, 1120025286000896, 1117800034814116, 1120025288088084, 11000002730717, 1120025357307736, 1120044093263334, 1120025686569785, 11000009529729, 1120025686569785, 11000016705190, 1120025686569785, 11000019543890, 1120025987558628, 1120032607099309, 1120026021113270, 11000001435159, 1120026021113270, 11000004313509, 1120026021113270, 11000005819301, 1120026021113270, 11000012353271, 1120026021113270, 11000013709561, 1120026021113270, 11000015258829, 1120026021113270, 11000017925969, 1120026021113270, 1120022161025371, 1120026021113270, 1120037328447826, 1120026021113270, 11000019597647, 1120026081317953, 1120027579202343, 1120026137982566, 11000003951072, 1120026137982566, 1120038319668471, 1120026256473887, 11000005588279, 1120026256473887, 11000006052568, 1120026256473887, 11000002487988, 1120026314148154, 11000001949682, 1120026314148154, 11000008128306, 1120026314148154, 11000010997371, 1120026314148154, 11000013856367, 1120026314148154, 11000017111307, 1120026314148154, 11000018278979, 1120026314148154, 1120042895523876, 1120026361330172, 11000005002840, 1120026361330172, 11000017966535, 1120026370769048, 11000019081662, 1120026389646919, 1120031184570906, 1120026523859121, 11000007877044, 1120026612989626, 11000002004349, 1120026612989626, 11000003751618, 1120026612989626, 11000014221969, 1120026612989626, 1115149102567360, 1120026612989626, 11000014222371, 1120026840798452, 1120029980339652, 1120026946716730, 11000008979518, 1120027149183136, 11000003675053, 1120027171202927, 1120036621673708, 1120027425054283, 1120028681698614, 1120027425054283, 1120040550328633, 1120027476440641, 11000013702635, 1120027476440641, 1120037525587918, 1120027772227823, 11000004820559, 1120027772227823, 11000006105731, 1120028161448442, 1120033509143411, 1120028161448442, 1120033600543092, 1120028161448442, 11000016906842, 1120028197098922, 11000013355377, 1120028410117294, 11000010911335, 1120028410117294, 11000014852548, 1120028488769640, 11000007228432, 1120028575790376, 11000004648076, 1120028575790376, 11000007277744, 1120028600955622, 11000011478123, 1120028600955622, 1120024124708516, 1120028630328462, 11000000519399, 1120028630328462, 11000007313520, 1120028630328462, 11000012590281, 1120029177804040, 1120024345037652, 1120029177804040, 1120037790905728, 1120029521958380, 11000016702200, 1120029521958380, 1120038369851435, 1120029521958380, 11000009656103, 1120029538745670, 11000002831114, 1120029595357508, 11000018831082, 1120029595357508, 1120021055500861, 1120029645783134, 1120021884023610, 1120029645783134, 117649527870406, 1120029645783134, 1120024099541879, 1120029991859524, 11000001565487, 1120029991859524, 11000011252435, 1120029991859524, 1120025733757726, 1120029998150570, 1120039890671178, 1120029998150570, 11000020499909, 1120030198428817, 11000007795045, 1120030198428817, 1120035189689857, 1120030397874583, 1116702125912914, 1120030482808953, 11000017499395, 1120030482808953, 11000004040308, 1120030681095507, 11000006035416, 1120030681095507, 11000010154622, 1120030681095507, 11000016810034, 1120030681095507, 11000019874979, 1120030686335016, 11000004270437, 1120030782913651, 11000001136558, 1120030782913651, 1120041588697628, 1120030814375003, 1120041106264754, 1120030814375003, 1120041106266335, 1120030814375003, 11000001744708, 1120030949667136, 1112363139394890, 1120030949667136, 1120023517325924, 1120030949667136, 11000010246494, 1120031299914093, 11000007757840, 1120031299914093, 11000009563714, 1120031299914093, 1120040253585606, 1120031527613515, 11000002223568, 1120031587222197, 11000000589516, 1120031587222197, 11000000689383, 1120031587222197, 11000007456449, 1120031587222197, 11000018523813, 1120031587222197, 1117559916152921, 1120031587222197, 1120023894963481, 1120031587222197, 1120037481495938, 1120031587222197, 1120040315541429, 1120031601115353, 1120034784844565, 1120031601115353, 1120028490867519, 1120031685024880, 11000002460846, 1120031685024880, 1120027558223352, 1120031685024880, 1120033465119120, 1120031685024880, 1120043188078939, 1120031685024880, 1120044412096664, 1120031866541183, 1116709848673632, 1120031866541183, 11000002932920, 1120032212731682, 1117735012330719, 1120032212731682, 11000012076326, 1120032298713893, 11000018272647, 1120032298713893, 11000018947790, 1120032298713893, 11000019763487, 1120032298713893, 1120040583978059, 1120032306156927, 1115468780358353, 1120032515872214, 1120029214678461, 1120032515872214, 1120022131663061, 1120032772912541, 11000009679678, 1120032772912541, 11000010058809, 1120032977403951, 11000016726570, 1120032977403951, 11000004779655, 1120033055052327, 1118187061047061, 1120033055052327, 1120044656423484, 1120033124266645, 11000000600838, 1120033124266645, 11000008689709, 1120033595305062, 11000019667220, 1120033922678276, 11000018143859, 1120034049496058, 11000008693281, 1120034094717852, 11000007794960, 1120034213220570, 1120041915765407, 1120034392565315, 1111720909927324, 1120034535192681, 1120036361459079, 1120034611816461, 11000006046812, 1120034611816461, 11000002547183, 1120034987199979, 11000013479776, 1120034987199979, 1120034660050485, 1120035054315106, 11000009336861, 1120035054315106, 11000018255962, 1120035054315106, 1120041682981295, 1120035063754328, 11000006857437, 1120035063754328, 1120036636344526, 1120035074232004, 11000002531159, 1120035074232004, 11000001032075, 1120035193966969, 11000004838318, 1120035262124547, 11000009192195, 1120035262124547, 11000014461319, 1120035268459031, 11000000678053, 1120035268459031, 1120044017765832, 1120035335525077, 11000008399930, 1120035335525077, 1120033453666684, 1120035335525077, 1120031415401303, 1120035478323741, 11000001261552, 1120035601014750, 1120043514267304, 1120035794048481, 11000007366937, 1120036224905945, 1120039416481193, 1120036256598818, 1120026549027037, 1120036784036866, 11000020291626, 1120036908971123, 1120043283465884, 1120036908971123, 11000016549762, 1120037131269823, 1120036954946191, 1120037131269823, 1120025996991603, 1120037277063916, 11000016845267, 1120037427053951, 11000005327930, 1120037441735334, 11000007931659, 1120037484714577, 11000015574971, 1120037484714577, 11000014613379, 1120038316521629, 11000000777937, 1120038316521629, 1120041792190006, 1120038350971840, 11000005584277, 1120038350971840, 11000017213428, 1120038350971840, 1113677846082448, 1120038609085464, 11000009479087, 1120038705268961, 11000002738807, 1120038705268961, 11000008217229, 1120038705268961, 1120040952126990, 1120038705268961, 1120041637892294, 1120038705268961, 11000013000671, 1120038779838919, 11000014595391, 1120038779990089, 1116321046129921, 1120038865988097, 1120032930221634, 1120038878567903, 11000010945122, 1120038878567903, 11000016218717, 1120038881715389, 11000002388793, 1120038881715389, 1120037829835342, 1120038940542676, 1120042659206701, 1120039012962731, 1120033898391800, 1120039341222690, 1120044143661384, 1120039511903593, 1120034168138686, 1120039540448832, 11000017751132, 1120039540448832, 11000005060176, 1120039666044103, 11000002173901, 1120039666044103, 1120040216882228, 1120039825668359, 1113567394853255, 1120039834136667, 11000000884934, 1120039834136667, 1120022433660503, 1120040017649690, 11000001016398, 1120040017649690, 11000001210901, 1120040017649690, 11000006761840, 1120040097347857, 11000014884804, 1120040097347857, 11000015683655, 1120040186479384, 11000009031035, 1120040186479384, 1120045069495393, 1120040220025197, 11000012635137, 1120040220025197, 11000003753372, 1120040343874008, 1120043071756783, 1120040444517204, 11000019763348, 1120040444517204, 1120039712502577, 1120040514812260, 1120035103706703, 1120040514812260, 1120035020756208, 1120040573397602, 11000018939197, 1120040573397602, 1120035165568277, 1120040622817551, 11000014965679, 1120040782204266, 11000014494859, 1120041171224472, 11000015510915, 1120041818403805, 11000000351677, 1120042009244967, 1120040673157936, 1120042881901456, 11000003326726, 1120042881901456, 11000018724103, 1120043174416197, 11000003678326, 1120043229988248, 1120041425099615, 1120043281472153, 1120035870696515, 1120043286726653, 1120038801038935, 1120043286726653, 1120040191712363, 1120044206582239, 1120023694606683, 1120044206582239, 11000004177900, 1120044255800388, 11000006375097, 1120044255800388, 11000014586596, 1120044418330597, 11000013302900, 1120044429930299, 11000020362321, 1120044429930299, 1120042813706230, 1120044466638644, 1120033131600750, 1120044637482102, 11000000433786, 1120044637482102, 11000002448134, 1120044637482102, 11000003665570, 1120044701513507, 11000000888408, 1120044701513507, 1120040289231285, 1120045070542121, 1120024198198705, 118281910948457, 1113805687157341, 118783001038042, 11000003452576, 118868706135569, 11000000676910, 118868706135569, 11000018814385, 119165641887659, 11000010985346, 119639822897516, 1115757642575776, 119639822897516, 119639822897515}:
            #     continue
            # if _ori_frame != 11000009773714:
            #     continue
            _frame_a_json = diff_util.download_frame_json([_ori_frame])[0]
            _frame_ids = _row.frame_ids.split(',')
            _frame_b_json_list = diff_util.download_frame_json(_frame_ids)
            for _frame_id, _frame_b_json in zip(_frame_ids, _frame_b_json_list):
                frame_a = ent.FrameStdVecObj(copy.deepcopy(_frame_a_json), frame_id=_ori_frame)
                if _frame_id == _ori_frame:
                    continue
                logging.info("="*7)
                logging.info("REAL Matching", _ori_frame, _frame_id)
                frame_b = ent.FrameStdVecObj(copy.deepcopy(_frame_b_json), frame_id=_frame_id)
                # std_frame_diff(_frame_a_json, _frame_b_json)
                # if len(frame_a.corner_list) < len(frame_b.corner_list):
                #     print("a->b:")
                #     frame_diff(frame_a, frame_b)
                # else:
                #     print("b->a:")
                #     frame_diff(frame_b, frame_a)


                # frame_a_cp, frame_b = frame_diff(frame_a, frame_b)
                # if not frame_b.is_all_matched():
                #     display_frame_pairs(frame_a_cp, frame_b, display=False, use_b_axis=True)

                frame_s_tuple = frame_diff(frame_a, frame_b)
                if frame_b.is_all_matched():
                    continue
                std_imgs = []
                for _idx, _frame in enumerate(frame_s_tuple):
                    poly_arr = []
                    for _wall in _frame.wall_list:
                        if not _wall.is_matched and not _wall.edge_computed:
                            _polys = [{'x': __[0], 'y': __[1]} for __ in _wall.get_paired_wall_polygon()]
                            _current_poly = {'points': _polys, "stroke": "#00FFFF", "stroke-width": 0, "fill": "#0000FF",
                                             "opacity": 0.2}
                            poly_arr.append(_current_poly)
                    frame_json_dict = frame_s_tuple[1 - _idx].dump(poly_arr)
                    _img = print_utils.draw_json(frame_json_dict, show=False)
                    std_imgs.append(transform.rescale(np.array(_img), 2.5))
                display_frame_quads(frame_s_tuple[0], frame_s_tuple[1], std_imgs[0], std_imgs[1], display=False)
        # print("="*7)
        # _cnt += 1
        # if _cnt > 100:
        #     break
        except Exception as ex:
            print("ERROR", ex)


def extract_single_frame_feature(frame_id, frame_json, **kwargs):
    """
    提取单户型的特征和标签
    :param frame_id:
    :param frame_json:
    :param kwargs:
    :return:
    """
    image_id = kwargs.get('image_id', '-1')
    city_code = kwargs.get('city', '-1')
    conf = kwargs.get('conf')
    line = "\t".join([frame_id, str(image_id), frame_json, str(city_code)])
    entity_frame, result = tag_utils.get_whole_frame_info(
        line, conf["explain_params"], get_result, lambda x, y: -1)
        # line.encode('utf-8'), conf["explain_params"], get_result, lambda x, y: -1)

    return entity_frame, result


def case_study(frame):
    frame_id, line = tag_utils.get_frame_vector(frame)
    conf = dict()
    tag_utils.collect_conf(r"frame_eval/frame_tag_lib/conf.yml", conf)
    frame, result = tag_utils.get_whole_frame_info(
        line, conf["explain_params"], get_result, lambda x, y: x)
    features = result[1]
    if features != "":
        features = json.loads(result[1])

    return features, result


def get_result(frame_id, frame):
    """后处理结果"""
    result = []
    result.append(frame_id)
    if isinstance(frame, Exception):
        result.append('')  # feature
        result.append('')  # city_code
        result.append(str(frame))
    else:
        error = ''
        features = frame.explain_message['frame_tag_feature']
        result.append(json.dumps(features, cls=tag_utils.NpEncoder))
        result.append(frame.city_code)
        result.append(error)
    return result


def load_add_room_cases(file_path, num=200):
    """
    加载增加指定居室类型的case
    :param file_path: excel文件位置
    :param num: 返回的结果数量
    :return:
    """
    ori_excel = pd.read_excel(file_path)
    ret_tuple = []
    for _res_contour_rept_id, _rows in ori_excel.groupby('res_contour_rept_id'):
        temp_arr = []
        for _row in _rows.itertuples():
            temp_arr.append(_row.frame_id)
        if temp_arr:
            ret_tuple.extend(list(zip(temp_arr[:-1], temp_arr[1:])))
        if len(ret_tuple) > 5*num:
            break
    ret_tuple_choices = np.random.choice(np.arange(len(ret_tuple)), size=num)
    return [ret_tuple[_] for _ in ret_tuple_choices]


if __name__ == '__main__':
    import matplotlib.pyplot as plt
    # case_study('11000006597664')
    try_std_frame_diff()
    # batch_draw_frame()
    # f_path = u'data/mod_diff_res/北京ALL卧室改动的户型.xls'
    # f_path = u'data/mod_diff_res/北京ALL卫生间改动的户型.xls'
    # arr = load_add_room_cases(f_path)
    # print(arr)
    pass


