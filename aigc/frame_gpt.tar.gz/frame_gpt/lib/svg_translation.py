import shapely
from shapely.geometry import Polygon, MultiPolygon, LineString, MultiLineString, Point, MultiPoint, box
from matplotlib import pyplot as plt
from shapely.affinity import rotate, translate, scale

width, height = 78.48, 72.48
rect = box(0, 0 , width, height)

rect = scale(rect, xfact=2.9690949031600407, yfact=2.9690949031600407)
rect = rotate(rect, 90)
minx, miny, maxx, maxy = rect.bounds
print(minx, miny, maxx-minx, maxy-miny)
rect = translate(rect, 1695.093892, 1453.6618239999998)
rect = translate(rect, -116.093892, -107.6618239999998)
minx, miny, maxx, maxy = rect.bounds
print(minx, miny, maxx-minx, maxy-miny)
plt.plot(*rect.exterior.xy)
plt.savefig("./rect.png")
pass
