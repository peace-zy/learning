#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2018 www.ke.com, Inc. All Rights Reserved
import json
import copy
import math
import numpy as np
import collections
from shapely.geometry import Polygon, LineString

# 截取HU的前四位
LOG_HU_CUT_SIZE = 4


MAIN_DOOR_ROOM_TYPE_ORDER = {
    1: 0,      # 客厅
    2: 0,      # 餐厅
    25: 0,     # 门厅
    27: 0,     # 玄关
    37: 0,     # 起居室
    23: 1,     # 过道
    0: 1,      # 其他
    3: 1,      # 卧室
    8: 2,      # 厨房
    9: 2,      # 开放厨房
    26: 4,     # 入户花园
    12: 5,     # 阳台
    13: 5,     # 露台
    17: 5,     # 花园
}


def plambda(p1, p2, p):
    """
    计算点落在直线上的百分比(相对于p1)
    :param p1: p2.y
    :param p2: px
    :param p: py
    :return:
    """
    x1, y1, x2, y2, x, y = p1[0], p1[1], p2[0], p2[1], p[0], p[1]
    px = x2 - x1
    py = y2 - y1
    dd = px * px + py * py
    return ((x - x1) * px + (y - y1) * py) / max(1e-9, float(dd))


def p_to_line_distance(p1, p2, p):
    """
    点到直线距离
    :param p1:
    :param p2:
    :param p:
    :return:
    """
    vec1 = p1 - p
    vec2 = p2 - p
    distance = np.abs(np.cross(vec1, vec2)) / np.linalg.norm(p1 - p2)
    return distance


# 主门排序顺序
class OrderedSet(collections.OrderedDict, collections.abc.MutableSet):

    def __init__(self, elem_array):
        super(OrderedSet, self).__init__()
        for e in elem_array:
            self.add(e)

    def update(self, *args, **kwargs):
        if kwargs:
            raise TypeError("update() takes no keyword arguments")

        for s in args:
            for e in s:
                self.add(e)

    def pop_from_first(self):
        return self.popitem(last=False)[0]

    def add(self, elem):
        self[elem] = None

    def discard(self, elem):
        self.pop(elem, None)

    def __le__(self, other):
        return all(e in other for e in self)

    def __lt__(self, other):
        return self <= other and self != other

    def __ge__(self, other):
        return all(e in self for e in other)

    def __gt__(self, other):
        return self >= other and self != other

    def __repr__(self):
        return 'OrderedSet([%s])' % (', '.join(map(repr, self.keys())))

    def __str__(self):
        return '{%s}' % (', '.join(map(repr, self.keys())))

    difference = property(lambda self: self.__sub__)
    difference_update = property(lambda self: self.__isub__)
    intersection = property(lambda self: self.__and__)
    intersection_update = property(lambda self: self.__iand__)
    issubset = property(lambda self: self.__le__)
    issuperset = property(lambda self: self.__ge__)
    symmetric_difference = property(lambda self: self.__xor__)
    symmetric_difference_update = property(lambda self: self.__ixor__)
    union = property(lambda self: self.__or__)


class VRCode(object):
    """
    组代表状态
    """
    default = -1
    not_vr = 0
    is_vr = 1


class ValidCode(object):
    """
    记录有效状态码
    """
    default = '-1'
    invalid = '0'
    valid = '1'
    new = '2'


class ErrorCode(object):
    """
    无法提取特征的错误码
    """
    ok = 0
    json_unquote = -1
    json_invalid = -2
    plan_cnt = -3
    lack_data = -4
    area_analysis = -5
    point_iter = -6
    empty_points = -7
    cannot_rotate = -8
    area_info_empty = -9
    area_point_err = -10
    item_start_err = -11
    merge_line_err = -12
    get_cycle_radius_err = -13
    plan_cnt_exceeded = -14  # 超过两层楼
    missing_entrance = -15


class ContourErrCode(object):
    """
    轮廓匹配返回错误阈值
    """
    area_size_without_line_diff = 990
    area_size_diff = 991
    edge_len_diff = 992
    default_diff = 993

    towards_diff = 9991
    areas_diff = 9992
    window_cnt_diff = 9993
    window_diff = 9994
    door_cnt_diff = 9995
    door_diff = 9996
    vstack_err = 9997
    simi_contour_err = 9998


class ContourJsonEncoder(json.JSONEncoder):
    """
    自定义json序列化方法
    """
    def default(self, obj):
        if isinstance(obj, set):
            return list(obj)
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return super(ContourJsonEncoder, self).default(obj)


# import cv2
# from skimage.draw import polygon
#
#
# def draw_lines_visual(lines_ori, img_name = 'de'):
#     max_h = np.array(lines_ori).max() + 20
#     canvas = np.zeros((max_h, max_h), dtype=np.uint8)
#     for _ in lines_ori:
#         cv2.line(canvas, tuple(_[0]), tuple(_[1]), color=255)
#     cv2.imwrite('{}.jpg'.format(img_name), canvas)
#
#
# def draw_poly_visual(pts, img_name='de'):
#     pts_arr = np.array(pts, dtype=int)
#     scale = 256/pts_arr.max()
#     canvas = np.zeros((320, 320), dtype=np.uint8)
#     _pts_arr = (pts_arr * scale).astype(int)
#     rr, cc = polygon(_pts_arr[:, 0] + 20, _pts_arr[:, 1] + 20, canvas.shape)
#     canvas[rr, cc] = 255
#     cv2.imwrite('{}.jpg'.format(img_name), canvas)


# def fill_frame_poly(points, _offset, _ratio, im, gray_scale=1):
#     """
#     画户型图
#     :param points: 轮廓点序列
#     :param _offset: 坐标偏移
#     :param _ratio: 放缩比例
#     :param im: 图片模板
#     :param gray_scale: 灰度
#     :return:
#     """
#     _im = copy.deepcopy(im)
#     b = np.array(points, dtype=int)
#     c = b*_ratio + _offset
#     c = c.astype(int)
#     rr, cc = polygon(c[:, 0], c[:, 1], _im.shape)
#     _im[rr, cc] = gray_scale
#     return _im


class Contour(object):
    """
    轮廓对象
    """
    def __init__(self, **kwargs):
        entrance_angle = kwargs['entrance_angle']
        edge_len = kwargs['edge_len']
        area_size = kwargs['area_size']
        area_size_without_line = kwargs['area_size_without_line']
        mass_center = kwargs['mass_center']
        floor_points_to_line_map = kwargs['floor_points_to_line_map']
        edge_points_array = kwargs['edge_points_array']
        edge_points_dict = kwargs['edge_points_dict']
        log_hu = kwargs['log_hu']

        self._line_offset_array = list()
        self._item_offset_array = list()
        self._item_array = list()
        self._edge_len = edge_len
        self._entrance_angle = entrance_angle
        self._area_size = area_size/1e6
        self._area_size_without_line = area_size_without_line/1e6
        self._mass_center = mass_center
        self._floor_points_to_line_map = floor_points_to_line_map

        self._log_hu = [round(x, LOG_HU_CUT_SIZE) for x in log_hu]
        if not edge_points_dict and edge_points_array and len(edge_points_array) > 2:
            # list转字典
            triplet_arr, _ = array_2_combination(edge_points_array)
            triplet_dict = dict()
            edge_points_array_purify = list()
            for _tri in triplet_arr:
                key_tuple = tuple(_tri[1])
                pt_0_tuple = tuple(_tri[0])
                pt_2_tuple = tuple(_tri[2])
                if pt_0_tuple != pt_2_tuple and key_tuple not in triplet_dict:
                    triplet_dict[key_tuple] = set([pt_0_tuple, pt_2_tuple])
                    edge_points_array_purify.append(pt_0_tuple)
            if len(edge_points_array) != len(edge_points_array_purify):
                triplet_arr, _ = array_2_combination(edge_points_array_purify)
                triplet_dict = dict()
                for _tri in triplet_arr:
                    key_tuple = tuple(_tri[1])
                    pt_0_tuple = tuple(_tri[0])
                    pt_2_tuple = tuple(_tri[2])
                    if pt_0_tuple != pt_2_tuple and key_tuple not in triplet_dict:
                        triplet_dict[key_tuple] = set([pt_0_tuple, pt_2_tuple])
            self._edge_points_dict = triplet_dict
            self._edge_points_array = edge_points_array_purify
        if not edge_points_array and edge_points_dict:
            ret_list = triplet_2_array(edge_points_dict)
            self._edge_points_dict = edge_points_dict
            self._edge_points_array = ret_list
        room_poly = Polygon(self._edge_points_array)
        self.room_poly = room_poly
        self.mini_rectangle_pts = list(np.array(room_poly.minimum_rotated_rectangle.exterior.coords, dtype=int))
        if not room_poly.minimum_rotated_rectangle.exterior.is_ccw:
            self.mini_rectangle_pts = list(reversed(self.mini_rectangle_pts))
        self.mini_rect_centroid = list(np.array(room_poly.minimum_rotated_rectangle.centroid.coords, dtype=int))
        # 矩形率 = abs(1 - 多边形面积 / 最小旋转矩形面积)
        self.rectangle_ratio = round(abs(1 - self.room_poly.area / self.room_poly.minimum_rotated_rectangle.area), 4)
        # 直方图特征
        self.histogram_desc = {}
        # 傅里叶轮廓特征
        self.fourier_desc = {}

    def set_item_array(self, arr):
        self._item_array = arr

    @property
    def item_array(self):
        return self._item_array

    def set_line_offset_array(self, arr):
        self._line_offset_array = arr

    @property
    def line_offset_array(self):
        return self._line_offset_array

    def set_item_offset_array(self, arr):
        self._item_offset_array = arr

    @property
    def item_offset_array(self):
        return self._item_offset_array

    @property
    def floor_points_to_line_map(self):
        """
        直接用坐标索引的字典, {point: line dict()}
        :return:
        """
        return self._floor_points_to_line_map

    @property
    def entrance_angle(self):
        """
        户型朝向
        :return:
        """
        return self._entrance_angle

    @property
    def log_hu(self):
        """
        无权轮廓系数
        :return:
        """
        return self._log_hu

    @property
    def mass_center(self):
        """
        轮廓重心
        :return:
        """
        return self._mass_center

    @property
    def edge_len(self):
        """
        轮廓周长
        :return:
        """
        return self._edge_len

    @property
    def area_size(self):
        """
        轮廓面积
        :return:
        """
        return self._area_size

    @property
    def area_size_without_line(self):
        """
        轮廓面积不含墙
        :return:
        """
        return self._area_size_without_line

    @property
    def display_size(self):
        """
        展示的面积
        :return:
        """
        if self._area_size_without_line < 0.1:
            return self._area_size
        else:
            return self._area_size_without_line

    @property
    def edge_points_dict(self):
        """
        轮廓边界点 {角点: set({})}
        :return:
        """
        return self._edge_points_dict

    @property
    def edge_points_array(self):
        """
        轮廓顺序的边界点 [(x, y), (x1, y2)...]
        :return:
        """
        return self._edge_points_array


class RoomContour(Contour):
    """
    分间轮廓特征对象
    """
    def __init__(self, **kwargs):
        room_type = kwargs['room_type']
        area_id = kwargs['area_id']
        Contour.__init__(self, **kwargs)
        self.area_doors = kwargs['area_doors']
        self._room_type = room_type
        self._area_id = area_id
        # 给外接矩形编码, 主门在0号墙上, 逆时针遍历.
        # 主门id.
        #   p3#####l2######p2
        #   #             #
        #   #             #
        #   l3            l1
        #   #             #
        #   #             #
        #   p0#####l0#####p1
        tmp_mini_rect_lines, rect_min_dist, rect_mini_idx = [dict() for _ in range(4)], float('inf'), 0
        # 是否有阳台
        self.has_balcony = False
        # 宽a/cm
        self.main_width = -1
        self.main_width_label = -1
        # 进深b/cm
        self.main_deep = -1
        self.main_deep_label = -1
        # 主门距墙 > 40？
        self.has_side_400_cnt = 0
        # 主门距墙 > 80？
        self.has_side_800_cnt = 0
        # 主门距墙 > 130？
        self.has_side_1300_cnt = 0
        # 门相对阳台位置
        self.door_balcony_pos = -1
        # 厕所门在位置
        self.door_at_side = -1
        # 存在平行厨房阳台门
        self.has_parallel_balcony = False
        # 存在垂直厨房阳台门
        self.has_vertical_balcony = False
        # 阳台通道>800？
        self.balcony_has_800 = False
        # 厨房面积S/m²
        self.area_size_label = range_label(round(self.display_size, 2), [5, 7, 9])
        # 门数量
        self.door_cnt = 0
        # 阳台门数量
        self.balcony_door_cnt = 0
        # 窗数量
        self.window_cnt = 0

        main_item = kwargs.get('main_item', None)
        if main_item:
            item_is_entrance = main_item.get('is_entrance', False)
            if item_is_entrance:
                # 主门是入户门不用计算
                return
            for _i, (_p1, _p2) in enumerate(zip(self.mini_rectangle_pts[:-1], self.mini_rectangle_pts[1:])):
                line_obj = dict()
                line_obj['line_pt_0'] = _p1
                line_obj['line_pt_1'] = _p2
                _line_pts = np.array([_p1, _p2])
                line_obj['line_pts'] = _line_pts
                line_obj['line_vec'] = _line_pts[-1] - _line_pts[0]
                line_obj['line_str'] = LineString([_p1, _p2])
                line_obj['len'] = line_obj['line_str'].length
                line_obj['items'] = []
                _tmp_dist = p_to_line_distance(_line_pts[0], _line_pts[1], main_item['center'])
                if _tmp_dist < rect_min_dist:
                    rect_min_dist = _tmp_dist
                    rect_mini_idx = _i
                tmp_mini_rect_lines[_i] = line_obj
            self.mini_rect_lines = list(np.roll(tmp_mini_rect_lines, -rect_mini_idx))
            # self.mini_rect_lines[_i] = line_obj
            # 宽a/cm
            self.main_width = round(self.mini_rect_lines[0]['line_str'].length, 0)
            # 进深b/cm
            self.main_deep = round(self.mini_rect_lines[1]['line_str'].length, 0)

            sorted_line_arr = kwargs['sorted_line_arr']
            balcony_wall_idxs = set([])
            for _line in sorted_line_arr:
                # 遍历 items
                for _item in _line.get('items'):
                    # 匹配最近的点到矩形直线距离 -> 吸附外接矩形
                    item_center = _item['center']
                    if _item['is'] == 'door':
                        self.door_cnt += 1
                    elif _item['is'] == 'window':
                        self.window_cnt += 1
                        continue
                    min_dist_l_idx, min_dist, min_line = 0, float('inf'), None
                    for _l_i, _line_dict in enumerate(self.mini_rect_lines):
                        _line_pts = _line_dict['line_pts']
                        _tmp_dist = p_to_line_distance(_line_pts[0], _line_pts[1], item_center)
                        if _tmp_dist < min_dist:
                            min_dist = _tmp_dist
                            min_dist_l_idx = _l_i
                            min_line = _line_dict
                    _item['l_idx'] = min_dist_l_idx
                    _item['area_type'] = _line['area_type']
                    _has_balcony = '100900000005' in _line['area_type']
                    self.has_balcony = _has_balcony or self.has_balcony
                    _item['has_balcony'] = _has_balcony
                    if _has_balcony:
                        balcony_wall_idxs.add(min_dist_l_idx)
                    prev_has_balcony = self.mini_rect_lines[min_dist_l_idx].get('has_balcony', False)
                    self.mini_rect_lines[min_dist_l_idx]['has_balcony'] = _has_balcony or prev_has_balcony
                    _item_pts = _item['pts']
                    _line_vec = min_line['line_vec']
                    _item_dot = _line_vec.dot(_item_pts[1] - _item_pts[0])
                    if _item_dot < 0:
                        l_0 = plambda(min_line['line_pt_0'], min_line['line_pt_1'], _item_pts[-1])*min_line['len']
                        l_1 = plambda(min_line['line_pt_1'], min_line['line_pt_0'], _item_pts[0])*min_line['len']
                    else:
                        l_0 = plambda(min_line['line_pt_0'], min_line['line_pt_1'], _item_pts[0])*min_line['len']
                        l_1 = plambda(min_line['line_pt_1'], min_line['line_pt_0'], _item_pts[-1])*min_line['len']
                    # 计算夹角附件和墙体夹角
                    _item['l0'], _item['l1'] = l_0, l_1
                    self.mini_rect_lines[min_dist_l_idx]['items'].append(_item)
            # 主门距墙 > 40？
            # main_items = self.mini_rect_lines[0]['items']
            self.has_side_400_cnt = sum([main_item.get('l0', 0) > 400, main_item.get('l1', 0) > 400])
            # main_items = self.mini_rect_lines[0]['items']
            self.has_side_800_cnt = sum([main_item.get('l0', 0) > 800, main_item.get('l1', 0) > 800])
            # 主门距墙>130？
            self.has_side_1300_cnt = sum([main_item.get('l0', 0) > 1300, main_item.get('l1', 0) > 1300])

            # 门相对阳台位置 找到非阳台墙体.
            _has_non_balcony_wall_dist = []
            for _i, _line in enumerate(self.mini_rect_lines):
                _has_balcony = _line.get('has_balcony', False)
                _line_items = _line.get('items', False)
                if _has_balcony:
                    self.balcony_door_cnt += len(_line_items)
                if _i not in balcony_wall_idxs and _i % 2 == 1 and self.has_balcony:
                    if _i == 1:
                        _has_non_balcony_wall_dist.append(main_item.get('l1', 0))
                    elif _i == 3:
                        _has_non_balcony_wall_dist.append(main_item.get('l0', 0))
                if _i == 1:
                    self.has_vertical_balcony = _has_balcony or self.has_vertical_balcony
                    if _has_balcony:
                        for _ in _line_items:
                            self.balcony_has_800 = ((_['l1'] + _['length'] - 400 > 800) - 400 > 800) or self.balcony_has_800
                elif _i == 2:
                    self.has_parallel_balcony = _has_balcony or self.has_parallel_balcony
                elif _i == 3:
                    self.has_vertical_balcony = _has_balcony or self.has_vertical_balcony
                    if _has_balcony:
                        for _ in _line_items:
                            self.balcony_has_800 = (_['l0'] + _['length'] - 400 > 800) or self.balcony_has_800
            if _has_non_balcony_wall_dist and self.has_balcony and self.has_vertical_balcony:
                max_has_non_balcony_wall_dist = max(_has_non_balcony_wall_dist)
                self.door_balcony_pos = range_label(max_has_non_balcony_wall_dist, [400, 1300])

    @property
    def room_type(self):
        return self._room_type

    @property
    def area_id(self):
        return self._area_id

    def dump(self, **params):
        rectangle_ratio_threshold = params.get('max_rectangle_ratio', 0.087)
        ret_dict = {'center': (round(self._mass_center[0], 2), round(self._mass_center[1], 2)),
                    'edge_len': round(self._edge_len, 2), 'area_size': round(self._area_size, 2),
                    'area_id': self._area_id, 'room_points': self._edge_points_array}
        if not self.has_balcony:
            self.door_balcony_pos = -1
            self.has_parallel_balcony = -1
            self.has_vertical_balcony = -1
            self.balcony_has_800 = -1
        else:
            self.door_balcony_pos = int(self.door_balcony_pos)
            self.has_parallel_balcony = int(self.has_parallel_balcony)
            self.has_vertical_balcony = int(self.has_vertical_balcony)
            self.balcony_has_800 = int(self.balcony_has_800)
        _balcony_item_id_arr, attached_balcony_doors = params.get('balcony_doors', []), []
        if _balcony_item_id_arr:
            for _, _i in self.area_doors:
                for _balcony_item_id_set in _balcony_item_id_arr:
                    if _i['item_id'] in _balcony_item_id_set:
                        attached_balcony_doors = _balcony_item_id_set
                        break
        if self.room_type == '100900000003':
            self.main_width_label = range_label(self.main_width, [1400, 1900])
            self.main_deep_label = range_label(self.main_deep, [1300, 2200])
            # 厨房
            cluster_details = {'area_size': round(self._area_size, 2),
                               'area_id': self._area_id,
                               'room_type': self._room_type,
                               'display_size': round(self.display_size, 2),
                               'area_size_without_line': round(self._area_size_without_line, 2),
                               'mini_rectangle_pts': self.mini_rectangle_pts,
                               'mini_rect_centroid': self.mini_rect_centroid,
                               'rectangle_ratio': self.rectangle_ratio,
                               'has_balcony': int(self.has_balcony),
                               'main_width_label': self.main_width_label,
                               'main_width': self.main_width,
                               'main_deep': self.main_deep,
                               'main_deep_label': self.main_deep_label,
                               'has_side_400_cnt': self.has_side_400_cnt,
                               'has_side_1300_cnt': self.has_side_1300_cnt,
                               'door_balcony_pos': self.door_balcony_pos,
                               'has_parallel_balcony': self.has_parallel_balcony,
                               'has_vertical_balcony': self.has_vertical_balcony,
                               'balcony_has_800': self.balcony_has_800,
                               'area_size_label': self.area_size_label,
                               'door_cnt': len(attached_balcony_doors),
                               'window_cnt': self.window_cnt,
                               'door_cnt_all': self.door_cnt,
                               'balcony_door_cnt': self.balcony_door_cnt,
                             }
            # 聚类
            ret_dict.update({'cluster_details': cluster_details})
            if self.rectangle_ratio < rectangle_ratio_threshold:
                toilet_area_size = params.get('toilet_area_size', False)
                toilet_area_size_label = range_label(toilet_area_size, [2])
                ret_dict['cluster_details']['toilet_area_size_label'] = toilet_area_size_label
                ret_dict['room_label'] = '|'.join(
                    [str(ret_dict['cluster_details'][_k]) for _k in ['has_balcony', 'main_width_label',
                                                                     'main_deep_label', 'has_side_400_cnt',
                                                                     'has_side_1300_cnt', 'door_balcony_pos',
                                                                     'has_parallel_balcony', 'has_vertical_balcony',
                                                                     'balcony_has_800', 'area_size_label',
                                                                     'toilet_area_size_label', 'door_cnt']])
        elif self.room_type == '100900000004':
            # 卫生间
            self.main_width_label = range_label(self.main_width, [900, 1100, 1400, 1550, 1750, 2350, 3000])
            self.main_deep_label = range_label(self.main_deep, [900, 1100, 1400, 1550, 1750, 2350, 3000])
            self.door_at_side = int(self.main_width > self.main_deep)
            if not self.door_at_side:
                self.has_side_800_cnt = -1
            cluster_details = {'area_size': round(self._area_size, 2),
                               'area_id': self._area_id,
                               'room_type': self._room_type,
                               'display_size': round(self.display_size, 2),
                               'area_size_without_line': round(self._area_size_without_line, 2),
                               'mini_rectangle_pts': self.mini_rectangle_pts,
                               'mini_rect_centroid': self.mini_rect_centroid,
                               'rectangle_ratio': self.rectangle_ratio,
                               'has_balcony': int(self.has_balcony),
                               'main_width_label': self.main_width_label,
                               'main_width': self.main_width,
                               'main_deep': self.main_deep,
                               'main_deep_label': self.main_deep_label,
                               'has_side_800_cnt': self.has_side_800_cnt,
                               'door_cnt': self.door_cnt,
                               'window_cnt': self.window_cnt,
                               'door_cnt_all': self.door_cnt,
                               'door_at_side': self.door_at_side,
                               }
            ret_dict.update({'cluster_details': cluster_details})
            if self.rectangle_ratio < rectangle_ratio_threshold:
                ret_dict['room_label'] = '|'.join(
                    [str(ret_dict['cluster_details'][_k]) for _k in ['main_width_label', 'main_deep_label',
                                                                     'door_at_side', 'has_side_800_cnt']])
        ret_dict['cluster_details']['room_label'] = ret_dict.get('room_label', "")
        return ret_dict


def range_label(_v, sorted_range_arr):
    for _i, _r in enumerate(sorted_range_arr):
        if _v < _r:
            return _i
    return len(sorted_range_arr)


class FrameContour(Contour):
    """
    户型轮廓特征对象
    """
    def __init__(self, **kwargs):
        is_vr = kwargs['is_vr']
        shi = kwargs['shi']
        ting = kwargs['ting']
        chu = kwargs['chu']
        wei = kwargs['wei']
        yang = kwargs['yang']
        area_id_dict = kwargs['area_id_dict']
        w_log_hu = kwargs['w_log_hu']

        Contour.__init__(self, **kwargs)
        self._is_vr = is_vr
        self._shi = shi
        self._ting = ting
        self._chu = chu
        self._wei = wei
        self._yang = yang
        self._w_log_hu = [round(x, 4) for x in w_log_hu]
        self._mass_layout = None
        self._mass_layout_geo = None
        self._area_vec = None
        self._area_id_dict = area_id_dict

    def set_area_vec(self, area_vec):
        self._area_vec = area_vec

    def get_area_vec(self):
        return self._area_vec

    def set_mass_layout(self, mass_layout):
        self._mass_layout = mass_layout

    def get_mass_layout(self):
        return self._mass_layout

    def set_mass_layout_geo(self, mass_layout_geo):
        self._mass_layout_geo = mass_layout_geo

    def get_mass_layout_geo(self):
        return self._mass_layout_geo

    @property
    def is_vr(self):
        return self._is_vr

    @property
    def shi(self):
        return self._shi

    @property
    def ting(self):
        return self._ting

    @property
    def chu(self):
        return self._chu

    @property
    def wei(self):
        return self._wei

    @property
    def yang(self):
        return self._yang

    @property
    def w_log_hu(self):
        """
        加权轮廓系数
        :return:
        """
        return self._w_log_hu

    @property
    def area_id_dict(self):
        """
        {分间id: Contour}
        :return:
        """
        return self._area_id_dict

    def dump(self):
        ret_dict = {'center': (round(self._mass_center[0], 2), round(self._mass_center[1], 2)),
                    'edge_len': round(self._edge_len, 2), 'area_size': round(self._area_size, 2),
                    'area_size_without_line': round(self._area_size_without_line, 2),
                    'entrance_angle': self._entrance_angle,
                    'rectangle_ratio': self.rectangle_ratio,
                    }
        _area_id_dict = dict()
        max_toilet_size = 0
        toilet_contours, kitchen_contours, balcony_doors = [], [], []
        for area_id, area_contour in self.area_id_dict.items():
            if area_contour.room_type == '100900000005':
                balcony_doors.append(set([_i['item_id'] for _len, _i in area_contour.area_doors]))
            if area_contour.room_type == '100900000004':
                _area_contour_str = area_contour.dump(toilet_area_size=max_toilet_size)
                max_toilet_size = max(max_toilet_size, area_contour.area_size)
                toilet_contours.append(_area_contour_str)
        for area_id, area_contour in self.area_id_dict.items():
            if area_contour.room_type == '100900000003':
                _area_contour_str = area_contour.dump(toilet_area_size=max_toilet_size, balcony_doors=balcony_doors)
                kitchen_contours.append(_area_contour_str)
        kitchen_contours = sorted(kitchen_contours, key=lambda k: k['area_size'], reverse=True)
        toilet_contours = sorted(toilet_contours, key=lambda k: k['area_size'], reverse=True)
        ret_dict['kitchen_dict'] = kitchen_contours
        ret_dict['toilet_dict'] = toilet_contours
        ret_dict['fourier_desc'] = self.fourier_desc
        return ret_dict


class FloorContour(object):
    """
    户型实体
    """
    def __init__(self, _row):
        self._frame_id = _row.frame_id
        self._image_id = _row.image_id
        self._city_code = _row.city_code
        self._resblock_id = _row.resblock_id
        self._map_cnt = _row.map_cnt
        self._build_area = _row.build_area

        self._is_vr = -1

        self._t_shi = -1
        self._t_ting = -1
        self._t_chu = -1
        self._t_wei = -1
        self._t_yang = -1

        self._entrance = '-1'
        self._plans_len = -1
        self._edge_len = -1
        self._plans_area = -1
        self._mass_layout = ''
        self._mass_layout_geo = ''
        self._log_hu = ''
        self._w_log_hu = ''
        self._area_vec = ''
        self._floors = ''
        self._error = ErrorCode.ok
        # 增量计算新的
        self._is_valid = ValidCode.new

    def set_rooms(self, t_shi, t_ting, t_chu, t_wei, t_yang):
        self._t_shi = t_shi
        self._t_ting = t_ting
        self._t_chu = t_chu
        self._t_wei = t_wei
        self._t_yang = t_yang

    def set_is_vr(self, is_vr):
        self._is_vr = is_vr

    def set_entrance(self, entrance):
        self._entrance = entrance

    def set_plans_len(self, plans_len):
        self._plans_len = plans_len

    def set_edge_len(self, edge_len):
        self._edge_len = edge_len

    def set_plans_area(self, plans_area):
        self._plans_area = plans_area

    def set_mass_layout(self, mass_layout):
        self._mass_layout = mass_layout

    def set_mass_layout_geo(self, mass_layout_geo):
        self._mass_layout_geo = mass_layout_geo

    def set_log_hu(self, log_hu):
        self._log_hu = log_hu

    def set_w_log_hu(self, w_log_hu):
        self._w_log_hu = w_log_hu

    def set_area_vec(self, area_vec):
        self._area_vec = area_vec

    def set_floors(self, floors):
        self._floors = floors

    def set_error(self, error):
        self._error = error

    def set_is_valid(self, is_valid):
        self._is_valid = is_valid

    def dump(self):
        return [
            str(self._frame_id), str(self._image_id), str(self._city_code), str(self._resblock_id),
            str(self._map_cnt), str(round(self._build_area, 2)),
            str(self._t_shi), str(self._t_ting), str(self._t_chu), str(self._t_wei), str(self._t_yang),
            str(self._is_vr),
            str(self._entrance), str(round(self._plans_len, 2)), str(round(self._edge_len, 2)),
            str(round(self._plans_area, 2)),
            str(self._mass_layout), str(self._mass_layout_geo), str(self._log_hu), str(self._w_log_hu),
            str(self._area_vec), str(self._floors), str(self._error), str(self._is_valid)
        ]


def array_2_combination(pt_array, combination_len=3):
    """
    首位相接数组转成连续元组
    :param pt_array:
    :param combination_len:
    :return:
    """
    if type(pt_array) is not np.ndarray:
        pt_array = np.array(pt_array)
        if len(pt_array.shape) == 1:
            pt_array = pt_array[:, np.newaxis]
    if tuple(pt_array[0]) == tuple(pt_array[-1]):
        # 去除最后一个首尾相接重复的
        pt_array = pt_array[:-1, :]
    con_arr = np.arange(combination_len)
    tile_con_arr = np.tile(con_arr, (len(pt_array), 1))
    tile_pt_array = np.tile(pt_array, (len(pt_array), 1)).reshape(pt_array.shape[0], -1, pt_array.shape[1])
    r = np.arange(len(pt_array))
    column_indices = tile_con_arr + r[:, np.newaxis]
    triplet_idx = column_indices % len(column_indices)
    return tile_pt_array[r[:, np.newaxis], triplet_idx], triplet_idx


def triplet_2_array(triplet_dict, init_keys=None):
    """
    三元组dict转数组
    :param triplet_dict: {角点: set({})}
    :param init_keys: [(x1, y1), (x2, y2)]
    :return:
    """
    triplet_dict_len = len(triplet_dict)
    if triplet_dict_len < 1:
        return []
    ret_list = []
    if init_keys:
        from_x, from_y = init_keys[0]
        to_x, to_y = init_keys[1]
    else:
        triplet_dict_cp = copy.deepcopy(triplet_dict)
        (to_x, to_y), init_items = triplet_dict_cp.popitem()
        # 任意pop一个当起点
        from_x, from_y = init_items.pop()

    ret_list.append((from_x, from_y))
    ret_list.append((to_x, to_y))
    existed_set = set(ret_list)
    for i in range(triplet_dict_len + 1):
        next_point_set = triplet_dict[(to_x, to_y)]
        # 找到自己
        for tmp_next_point in next_point_set:
            if tmp_next_point not in existed_set:
                next_x, next_y = tmp_next_point
                break
        if (next_x, next_y) in existed_set:
            break
        ret_list.append((next_x, next_y))
        existed_set.add((next_x, next_y))
        to_x, to_y = next_x, next_y
    return ret_list
