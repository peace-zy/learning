#!/bin/env/python2.7
# coding=utf-8
import __init__
import re
import os
import numpy as np
import shutil
import pkg_resources


def extract_file_no(file_name):
    """
    获取文件名中frame_id
    :param file_name:
    :return:
    """
    return re.findall("\d+", file_name)[0]


def get_files(path, file_type):
    """
    Get files
    :param path:
    :param file_type:
    :return:
    """
    files = []
    ids = []
    for root, dirs, tmp_files in os.walk(path):
        for i in tmp_files:
            if i.endswith(file_type):
                files.append(os.path.join(path,i))
                ids.append(str(extract_file_no(i)))
    return files, ids


def write_back_line_array(arr, path):
    """
    写回文件-行
    :param arr:
    :param path:
    :return:
    """
    with open(path, 'w') as f:
        for line in arr:
            f.write(line)
            f.write("\n")


def write_back_array(arr, path):
    """
    写回文件
    :param arr:
    :param path:
    :return:
    """
    with open(path, 'w') as f:
        for line in arr:
            line = [str(x) for x in line]
            f.write("\t".join(line))
            f.write("\n")


def copy_frame(src_folder, dst_folder):
    if not os.path.isfile(src_folder):
        print("%s not exist!" %src_folder)
    else:
        fpath, fname = os.path.split(dst_folder)  # 分离文件名和路径
        if not os.path.exists(fpath):
            os.makedirs(fpath)  # 创建路径
        shutil.copyfile(src_folder, dst_folder)  # 复制文件


class LoadLineWithIteration(object):
    """
    使用迭代器读取行文件
    """
    def __init__(self, path, has_header=True):
        self.path = path
        self.f = open(self.path)
        if has_header:
            self.header = self.f.readline()
            self.headers = self.header.strip().split('\t')

    def __iter__(self):
        for line in self.f:
            yield line.strip()

    def __del__(self):
        self.f.close()


def read_top_n_result_arr_all(file):
    """
    读取server结果文件-保留排序
    :param file:
    :return:
    """
    result_dict = dict()
    read_row = 0
    idx_dict = {}
    frame_ids = []

    with open(file, 'r') as f:
        for k, line in enumerate(f):
            if not line:
                continue
            line_arr = line.split('\t')
            # print("line_arr:"+str(line_arr))
            frame_id = line_arr[0]
            # print("frame_id:"+str(frame_id))
            can_frame_id_arr_str = line_arr[-1]
            # print("can_frame_id_arr_str:"+str(can_frame_id_arr_str))
            can_frame_id_arr = can_frame_id_arr_str.split(',')
            can_frame_id_arr = [tmp_can_frame.split('_') for tmp_can_frame in can_frame_id_arr]
            tmp_tuple_dict = dict()
            for i in range(len(can_frame_id_arr)):
                if len(can_frame_id_arr[i]) < 2:
                    continue
                can_frame, dist = can_frame_id_arr[i][0], can_frame_id_arr[i][1]
                if not dist:
                    continue
                if dist.strip() == 'nan':
                    continue
                dist = float(dist)
                if np.isnan(dist):
                    continue
                tmp_tuple_dict[can_frame] = dist
            result_dict[frame_id] = tmp_tuple_dict
            read_row += 1
            idx_dict[frame_id] = k
            frame_ids.append(frame_id)
            if read_row % 1000 == 0:
                print("{0}  read...".format(read_row))
    print("LOAD FILE COMPLETED...")
    return result_dict, idx_dict, frame_ids


def get_pkg_stream(pkg_pos, file_name):
    """
    读取包中的文件流
    :param pkg_pos: str, 包名，可以包含子包名，如frame_eval.frame_newhouse_v2
    :param file_name: 要读取的文件名
    """
    file_stream = pkg_resources.resource_stream(pkg_pos, file_name)
    return file_stream


def get_file_stream(file_path):
    paths = file_path.split('/')
    file_name = paths.pop()
    pkg_pos = '.'.join(paths)

    f = get_pkg_stream(pkg_pos, file_name)
    return f
