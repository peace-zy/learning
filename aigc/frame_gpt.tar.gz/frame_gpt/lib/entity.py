#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2018 www.ke.com, Inc. All Rights Reserved
"""
实体类
* 户型
* 标签
Authors: yudonghai@ke.com
Date:    2019/01/08
"""
from __future__ import division
import logging
import math

import json

from lib import code_enum as ce
from lib import comm_lib


# 必需字段键列表
POINT_NECESSARY_KEYS = ["x", "y", "id", "lines"]
LINE_NECESSARY_KEYS = ["type", "points", "id", "curve"]
LINE_ITEM_NECESSARY_KEYS = ["type", "is", "startIndex", "start", "length", "line"]
AREA_NECESSARY_KEYS = ["id", "roomType", "type", "empty", "points", "attachments", "size"]
AREA_ATTACH_NECESSARY_KEYS = ["areas", "lineItems", "lines"]
ATTACH_AREA_NECESSARY_KEYS = ["id", "roomType", "sharedLineItems", "sharedLines"]
ATTACH_LINE_ITEMS_NECESSARY_KEYS = ["is", "edge", "id"]
ATTACH_LINES_NECESSARY_KEYS = ["length", "edge", "id"]


class Frame(object):
    """
    矢量户型封装类
    """

    _COLUMN_SEP = '\t'                      # 原始数据列分割字符
    _COLUMN_CNT = 4                         # 约定初始化数据列数
    _FRAME_ID_INDEX = (0, "frame_id")       # 户型 id 在初始化数据中的下标
    _IMAGE_ID_INDEX = (1, "image_id")       # 户型图 id 在初始化数据中的下标
    _VECTOR_INDEX = (2, "vector_value")     # 矢量值在初始化数据中的下标
    _CITY_CODE_INDEX = (3, "city_code")     # 城市编码在初始化数据中的下标
    _COLUMN_ORDER_INDEX = 0                 # 按下标取字段索引
    _COLUMN_NAME_INDEX = 1                  # 按名称取字段索引

    _PLAN_KEY = "floorplans"     # 户型数据（层）在矢量值中的键值

    def __init__(self, record_line):
        """
        初始化
        :param record_line: string, 原始表中的数据,
                由数据库查询得到，包含(frame_id, image_id, vector_value, city_code)
                代表(户型id, 户型图id, 矢量户型图json数据, 城市编码)
        """
        self._state = ce.State.valid        # 状态
        self._frame_id = ''                 # 户型id
        self._image_id = ''                 # 户型图id
        self._city_code = ''                # 城市编码
        self._vector = {}                   # 矢量值
        self._plan_cnt = -1                 # 层数
        self._frame_label = 0               # 户型标签值
        self._room_cnt = [0, 0, 0, 0]       # 室厅厨卫数量
        self._label_message = {}            # 标签附加信息
        self._label_str_lst = []            # 标签字符表达
        self._frame_size = 0.               # 户型总面积
        self._plan_sizes = []               # 每层面积
        self._explain_message = {}          # 户型解读信息
        self._entrance_degree = None        # 入户门朝向与正北方角度，朝向逆时针方向
        self._entrance_item = None          # 入户门墙体附件ID
        self._entrance_type = None          # 入户门识别方式，normal 为矢量中正常标记；auto 为自动识别添加
        self._entrance_towards = None       # 入户门朝向与x周正向夹角，x轴正向逆时针方向
        self._entrance_plan_idx = None      # 入户门所在楼层索引
        self._border_key_points = []        # 每层的坐标四至
        self.house = None                   # house类

        # 分割提取字段
        self._split_column(record_line)
        # 全局信息检查
        self._global_info_check_and_fix()

        if self._state is not ce.State.valid:
            logging.warning("extract frame data for frame:{} failed".format(self._frame_id))
            return
        self.__rotate__()

    def _split_column(self, row):
        """
        分割字段提取信息，并格式化 json
        :param row: string/Row, 原始表中的数据,
                由数据库查询得到，包含(frame_id, image_id, vector_value, city_code)
                代表(户型id, 户型图id, 矢量户型图json数据, 城市编码)
        :return:
        """
        # 字符串数据
        items = row
        index_type = self._COLUMN_NAME_INDEX
        if isinstance(row, str):
            items = row.split(self._COLUMN_SEP)
            if len(items) < self._COLUMN_CNT:
                logging.warning("raw record has less than {} properties".format(self._COLUMN_CNT))
                self._state = ce.State.lack_field
                return
            index_type = self._COLUMN_ORDER_INDEX

        self._frame_id = items[self._FRAME_ID_INDEX[index_type]]
        self._image_id = items[self._IMAGE_ID_INDEX[index_type]]
        self._city_code = items[self._CITY_CODE_INDEX[index_type]]
        try:
            vector_value = items[self._VECTOR_INDEX[index_type]]
            # hive 表中的矢量值经过 url 编码，需要先解码, 若在hql中进行了解码则不需要此操作
            # vector_value = urllib.unquote(vector_value)
            vector_value = json.loads(vector_value)
            if vector_value is None:
                self._state = ce.State.invalid_json_format
            else:
                self._vector = vector_value
        except Exception as e:
            self._state = ce.State.invalid_json_format

    @staticmethod
    def _key_none(keys, item_dict):
        """
        检查 keys 中所有元素是否都在字典中有有效值
        :param keys: list/dict/set, 键
        :param item_dict: dict, 字典
        :return: bool, True: keys 中有键不存在或值为None
        """
        for k in keys:
            if item_dict.get(k, None) is None:
                return True
        return False

    def _entrance_detect(self):
        """
        获取入户门信息
        有入户门标记时，按层顺序和墙体数据列表顺序选择第一个入户门作为朝向参考
        没有入户门时，同样顺序选择第一个外墙上的门作为朝向参考，方向选择上北下南
        :return: bool, 是否成功找到/猜测到 入户门，返回True时可能对矢量进行了修改
        """
        plans = self._vector[self._PLAN_KEY]
        plans_len = len(plans)

        entrance_line_id = None     # 入户门所在墙体ID
        entrance_item_id = None     # 入户门ID
        entrance_plan_idx = None    # 入户门所在层
        entrance_degree = None      # 入户门度数
        entrance_towards = None     # 入户门朝向与x周正向夹角

        edge_doors = None
        edge_plan_idx = None

        line_dict = {}
        entrance_type = None

        for plan_idx in range(plans_len):
            plan = plans[plan_idx]
            line_items = plan["lineItems"]
            lines = plan["lines"]

            for line in lines:
                line_dict[line["id"]] = line

            for lineItem in line_items:
                item_line = lineItem["line"]
                is_type = lineItem["is"]
                if edge_doors is None and line_dict.get(item_line, {}).get("edgeComputed", False) \
                        and (is_type == "door" or is_type == "other"):
                    edge_doors = [lineItem["id"], item_line]
                    edge_plan_idx = plan_idx

                # 窗户被设置成入户门的取消其入户门标记
                if lineItem["entrance"] is not None and is_type == "window":
                    lineItem["entrance"] = None

                if lineItem["entrance"] is not None and (is_type == "door" or is_type == "other"):
                    entrance_line_id = lineItem["line"]
                    entrance_plan_idx = plan_idx
                    entrance_item_id = lineItem["id"]
                    entrance_type = "normal"
                    entrance_degree = lineItem["entrance"]
                    break
            if entrance_line_id is not None:
                break

        if entrance_line_id is None and edge_doors is not None:
            entrance_item_id, entrance_line_id = edge_doors
            entrance_plan_idx = edge_plan_idx
            entrance_type = "auto"
        else:
            if entrance_plan_idx is None:
                return False
            for area in plans[entrance_plan_idx]["areas"]:
                for area_line_item in area["attachments"]["lineItems"]:
                    if area_line_item["id"] == entrance_item_id:
                        entrance_rad = area_line_item["towardsRad"]
                        if entrance_rad is None:
                            return False
                        entrance_towards = entrance_rad * 180 / math.pi

        # 从外墙上选一个入户门，并修改其 entrance 值为非null，上北下南原则确定方向
        if entrance_type == "auto":
            entrance_rad = None
            for area in plans[entrance_plan_idx]["areas"]:
                for area_line_item in area["attachments"]["lineItems"]:
                    if area_line_item["id"] == entrance_item_id:
                        entrance_rad = area_line_item["towardsRad"]
                        break
                if entrance_rad is not None:
                    break

            if entrance_rad is None:
                return False

            entrance_towards = entrance_rad * 180 / math.pi

            for lineItem in plans[entrance_plan_idx]["lineItems"]:
                if lineItem["id"] == entrance_item_id:
                    entrance_degree = (entrance_towards + 90) % 360
                    lineItem["entrance"] = entrance_degree
        if entrance_degree is not None and entrance_type == "auto":
            logging.warning("entrance lacking! but find one automatically")

        if None in {entrance_degree, entrance_item_id, entrance_type, entrance_towards, entrance_plan_idx}:
            return False
        self._entrance_degree = entrance_degree
        self._entrance_item = entrance_item_id
        self._entrance_type = entrance_type
        self._entrance_towards = entrance_towards
        self._entrance_plan_idx = entrance_plan_idx

        return True

    def _direction_creator(self, cur_toward):
        cur_degree_toward = cur_toward * 180 / math.pi
        north_diff = (self._entrance_degree + (self._entrance_towards - cur_degree_toward)) % 360
        north_diff = (north_diff + 360) % 360
        eps = 1.5
        direction = None
        direction_code = None
        if abs(north_diff - 0.0) < eps:
            direction = "north"
            direction_code = 100500000007
        elif abs(north_diff - 90.0) < eps:
            direction = "east"
            direction_code = 100500000001
        elif abs(north_diff - 180.0) < eps:
            direction = "south"
            direction_code = 100500000003
        elif abs(north_diff - 270.0) < eps:
            direction = "west"
            direction_code = 100500000005
        elif 0 < north_diff < 90:
            direction = "north-east"
            direction_code = 100500000008
        elif 90 < north_diff < 180:
            direction = "south-east"
            direction_code = 100500000002
        elif 180 < north_diff < 270:
            direction = "south-west"
            direction_code = 100500000004
        elif 270 < north_diff < 360:
            direction = "north-west"
            direction_code = 100500000006

        return direction, direction_code

    """
    def _direction_creator(self, cur_toward):
        
        attachments 属性中的元素方向（direction）字段构建，对于原始矢量中此字段缺失的进行修复
        :rtype: object
        :param cur_toward: 当前墙体附件朝向弧度（与x轴正方向逆时针方向）
        :return: direction, direction_code; string, int; 朝向， 朝向编码
        
        cur_degree_toward = cur_toward * 180 / math.pi
        north_diff = (self._entrance_degree + (self._entrance_towards - cur_degree_toward)) % 360
        direction_a = int(north_diff / 90)
        direction_b = 0 if (north_diff % 90) == 0 else 0.5
        direction_flag = direction_a + direction_b
        direction = None
        direction_code = None
        if direction_flag == 0:
            direction = "north"
            direction_code = 100500000007
        elif direction_flag == 0.5:
            direction = "north-east"
            direction_code = 100500000008
        elif direction_flag == 1:
            direction = "east"
            direction_code = 100500000001
        elif direction_flag == 1.5:
            direction = "south-east"
            direction_code = 100500000002
        elif direction_flag == 2:
            direction = "south"
            direction_code = 100500000003
        elif direction_flag == 2.5:
            direction = "south-west"
            direction_code = 100500000004
        elif direction_flag == 3:
            direction = "west"
            direction_code = 100500000005
        elif direction_flag == 3.5:
            direction = "north-west"
            direction_code = 100500000006
        elif direction_flag == 4:
            direction = "north"
            direction_code = 100500000007

        return direction, direction_code
    """
    def _global_info_check_and_fix(self):
        """
        全局信息检测与部分修复,
        为原始矢量每一层矢量增加  points_dict, lines_dict, line_items_dict, areas_dict 字典数据，方便按ID查找矢量元素；
        为 _frame_size（户型面积） 和 _room_cnt（室厅厨卫数量） 赋值；
        入户门缺失或者朝向有问题的矢量自动修复
        :return:
        """
        if self._state is not ce.State.valid:
            logging.error("invalid object, state: {}".format(self._state.value))
            return

        if not isinstance(self._vector, dict) or self._PLAN_KEY not in self._vector:
            self._state = ce.State.lack_plan_data
            return

        self._plan_cnt = len(self._vector[self._PLAN_KEY])

        if self._plan_cnt == 0:
            self._state = ce.State.empty_plan
            return

        entrance_flag = self._entrance_detect()
        if not entrance_flag:
            self._state = ce.State.lack_entrance
            return

        _frame_size = 0.
        bed_room_cnt = 0
        parlour_cnt = 0
        kitchen_cnt = 0
        toilet_cnt = 0
        plan_sizes = []
        border_key_points = []

        for plan in self._vector[self._PLAN_KEY]:
            plan_size = 0.
            minx, miny, maxx, maxy = float("inf"), float("inf"), -float("inf"), -float("inf")  # 四至

            plan_points = plan.get(ce.PLAN_POINTS_KEY, None)
            plan_lines = plan.get(ce.PLAN_LINES_KEY, None)
            plan_line_items = plan.get(ce.PLAN_LINE_ITEMS_KEY, None)
            plan_areas = plan.get(ce.PLAN_AREAS_KEY, None)

            # 全局信息缺失
            if None in [plan_points, plan_lines, plan_line_items, plan_areas]:
                self._state = ce.State.invalid_plan_data
                return

            # 点信息检查
            points_dict = {}
            for p in plan_points:
                if self._key_none(POINT_NECESSARY_KEYS, p):
                    self._state = ce.State.illegal_point_lack_key
                    return
                points_dict[p[ce.POINT_ID_KEY]] = p
                x = round(p.get('x', None), 0)
                y = round(p.get('y', None), 0)
                minx, miny = min(minx, x), min(miny, y)
                maxx, maxy = max(maxx, x), max(maxy, y)
            if minx == float("inf") or miny == float("inf") or maxx == -float("inf") or maxy == -float("inf"):
                self._state = ce.State.border_wrong
                return
            minx -= 1
            miny -= 1
            border_key_points.append([minx, miny, maxx, maxy])

            plan[ce.POINTS_DICT_KEY] = points_dict
            if len(plan_points) == 0:
                self._state = ce.State.illegal_point_empty
                return

            # 墙体信息检查
            lines_dict = {}
            for plan_line in plan_lines:
                if self._key_none(LINE_NECESSARY_KEYS, plan_line):
                    self._state = ce.State.illegal_line_lack_key
                    return
                lines_dict[plan_line[ce.LINE_ID_KEY]] = plan_line
                line_points = plan_line[ce.LINE_POINTS_KEY]
                # 墙体至少有两个端点
                if len(line_points) < 2:
                    self._state = ce.State.illegal_line_lack_point
                    return
                for p in line_points:
                    if p not in points_dict:
                        self._state = ce.State.illegal_line_diff_point
                        return

            plan[ce.LINES_DICT_KEY] = lines_dict

            # 再检查点连接边
            for p in plan_points:
                for line in p[ce.POINT_LINES_KEY]:
                    if line not in lines_dict:
                        self._state = ce.State.illegal_point_diff_line
                        return
            # 墙体附件检查
            line_items_dict = {}
            for line_item in plan_line_items:
                if self._key_none(LINE_ITEM_NECESSARY_KEYS, line_item):
                    self._state = ce.State.illegal_line_item_lack_key
                    return
                if line_item[ce.LINE_ITEM_LINE_KEY] not in lines_dict:
                    self._state = ce.State.illegal_line_item_diff_line
                    return
                line_items_dict[line_item[ce.LINE_ITEM_ID_KEY]] = line_item
            plan[ce.LINE_ITEMS_DICT_KEY] = line_items_dict

            areas_dict = {}

            for area in plan_areas:
                if self._key_none(AREA_NECESSARY_KEYS, area):
                    self._state = ce.State.illegal_area_lack_key
                    return
                area_room_type = area[ce.AREA_ROOM_TYPE_KEY]
                # 确认包含面积字段和类型字段且满足计入面积条件时加入总面积
                if not area[ce.AREA_EMPTY_KEY] and area_room_type != ce.AreaType.garden.value:
                    _frame_size += area[ce.AREA_SIZE_KEY]
                    plan_size += area[ce.AREA_SIZE_KEY]

                if area_room_type in {ce.AreaType.room.value, ce.AreaType.babysitter.value}:
                    bed_room_cnt += 1
                elif area_room_type == ce.AreaType.parlour.value:
                    parlour_cnt += 1
                elif area_room_type == ce.AreaType.kitchen.value:
                    kitchen_cnt += 1
                elif area_room_type == ce.AreaType.toilet.value:
                    toilet_cnt += 1

                for p in area[ce.AREA_POINTS_KEY]:
                    if p not in points_dict:
                        self._state = ce.State.illegal_area_diff_point
                        return

                if self._key_none(AREA_ATTACH_NECESSARY_KEYS, area[ce.AREA_ATTACHMENTS_KEY]):
                    self._state = ce.State.illegal_area_lack_attach_key
                    return

                area_attachments = area[ce.AREA_ATTACHMENTS_KEY]

                for attach_area in area_attachments[ce.ATTACH_AREAS_KEY]:
                    if self._key_none(ATTACH_AREA_NECESSARY_KEYS, attach_area):
                        self._state = ce.State.illegal_area_lack_attach_area_key
                        return

                    if self.entrance_type == "auto" or attach_area.get("direction", None) is None:
                        if attach_area["towardsRad"] is None:
                            self._state = ce.State.illegal_area_diff_attach_line_item
                            return
                        direction, direction_code = self._direction_creator(attach_area["towardsRad"])
                        attach_area["direction"] = direction
                        attach_area["directionCode"] = direction_code

                    for shared_line_item in attach_area[ce.SHARED_LINE_ITEMS_KEY]:
                        if shared_line_item not in line_items_dict:
                            self._state = ce.State.illegal_area_diff_shared_line_item
                            return
                    for shared_line in attach_area[ce.SHARED_LINES_KEY]:
                        if shared_line not in lines_dict:
                            self._state = ce.State.illegal_area_diff_shared_line
                            return

                for attach_line_item in area_attachments[ce.ATTACH_LINE_ITEMS_KEY]:
                    if self._key_none(ATTACH_LINE_ITEMS_NECESSARY_KEYS, attach_line_item):
                        self._state = ce.State.illegal_area_lack_attach_lineItem_key
                        return

                    if attach_line_item[ce.ATTACH_LINE_ITEM_ID_KEY] not in line_items_dict:
                        self._state = ce.State.illegal_area_diff_attach_line_item
                        return

                    if self.entrance_type == "auto" or attach_line_item.get("direction", None) is None:
                        if attach_line_item["towardsRad"] is None:
                            self._state = ce.State.illegal_area_diff_attach_line_item
                            return
                        direction, direction_code = self._direction_creator(attach_line_item["towardsRad"])
                        attach_line_item["direction"] = direction
                        attach_line_item["directionCode"] = direction_code

                for attach_line in area_attachments[ce.ATTACH_LINES_KEY]:
                    if self._key_none(ATTACH_LINES_NECESSARY_KEYS, attach_line):
                        self._state = ce.State.illegal_area_lack_attach_line_key
                        return
                    if attach_line[ce.ATTACH_LINE_ID_KEY] not in lines_dict:
                        self._state = ce.State.illegal_area_diff_attach_line
                        return

                    if self.entrance_type == "auto" or attach_line.get("direction", None) is None:
                        if attach_line["towardsRad"] is None:
                            self._state = ce.State.illegal_area_diff_attach_line
                            return
                        direction, direction_code = self._direction_creator(attach_line["towardsRad"])
                        attach_line["direction"] = direction
                        attach_line["directionCode"] = direction_code

                areas_dict[area[ce.AREA_ID_KEY]] = area

            plan[ce.AREAS_DICT_KEY] = areas_dict
            plan_sizes.append(plan_size / 1000000.)
        self._frame_size = _frame_size / 1000000.
        self._plan_sizes = plan_sizes
        self._border_key_points = border_key_points
        self._room_cnt = [bed_room_cnt, parlour_cnt, kitchen_cnt, toilet_cnt]

    def __rotate__(self):
        """
        旋转坐标，使得y轴正向与正北方最接近
        :return: None
        """
        if self._state is not ce.State.valid:
            return
        self._rotate_angle, self._real_angle = comm_lib.rotate(self._vector[self._PLAN_KEY])

        for plan in self._vector[self._PLAN_KEY]:
            if "rotate_points" in plan:
                rotate_points_dict = {}
                for p in plan["rotate_points"]:
                    rotate_points_dict[p["id"]] = p
                plan[ce.ROTATE_POINTS_DICT_KEY] = rotate_points_dict

    def __repr__(self):
        return "frame_id: {}, state: {}， label: {}".format(self._frame_id, self._state, self._frame_label)

    def add_label(self, func, **config):
        """
        添加标签
        :param func: function, 方法
        :param config: dict, 配置参数
        :return: None
        """
        if self._state is ce.State.valid:
            new_label, message = func(self, **config)
            self._frame_label |= new_label
            if message.get(ce.LABEL_STR_KEY, None) is not None:
                self._label_str_lst.append(message[ce.LABEL_STR_KEY])
            self._label_message.update({ce.LABEL_KEY: message.get(ce.LABEL_KEY, [])})
            if ce.EXPLAIN_QUIET_ROOMS in message:
                self._explain_message.update({ce.EXPLAIN_QUIET_ROOMS: message.get(ce.EXPLAIN_QUIET_ROOMS, [[]])})
            if ce.EXPLAIN_MOVING_ROOMS in message:
                self._explain_message.update({ce.EXPLAIN_MOVING_ROOMS: message.get(ce.EXPLAIN_MOVING_ROOMS, [[]])})
        else:
            logging.error("can not add label to invalid frame(state: {})".format(self._state.value))

    def report_lst(self):
        """
        输出标签结果等
        :return: result_lst, list, [户型ID, 城市编码, 状态值, 室, 厅, 厨, 卫, 标签数值, 标签中文, 附加信息json]
        """
        result_lst = [self._frame_id, self._city_code, self.state.value]
        result_lst.extend(self._room_cnt)
        result_lst.append(self._frame_label)
        result_lst = [str(x) for x in result_lst]
        result_lst.append(",".join(self._label_str_lst))
        result_lst.append(json.dumps(self._label_message))
        result_lst = [x.decode("utf-8") for x in result_lst]

        return result_lst

    def report_lst_3(self):
        """
        输出标签结果等
        :return: result_lst, list, [户型ID, 城市编码, 状态值, 室, 厅, 厨, 卫, 标签数值, 标签中文, 附加信息json]
        """
        result_lst = [self._frame_id, self._city_code, self.state.value]
        result_lst.extend(self._room_cnt)
        result_lst.append(self._frame_label)
        result_lst = [str(x) for x in result_lst]
        result_lst.append(",".join(self._label_str_lst))
        result_lst.append(json.dumps(self._label_message))
        return result_lst

    def base_feature(self):
        _vector = [
            self.frame_id,
            self.image_id,
            self.city_code,
            self.frame_size,
            self.state.value,
            self.plan_cnt,
            self.room,
            self.parlour,
            self.kitchen,
            self.toilet
        ]
        return _vector

    def report_dict(self):
        """
        以json方式输出标签结果等
        :return:
        """
        report_dict = {
            "state": self._state.value,
            "shi": self._room_cnt[0],
            "ting": self._room_cnt[1],
            "chu": self._room_cnt[2],
            "wei": self._room_cnt[3],
            "label_value": self._frame_label,
            "label_string": ",".join(self._label_str_lst),
            "label_message": self._label_message
        }

        return report_dict

    @property
    def frame_id(self):
        return self._frame_id

    @property
    def vector(self):
        return self._vector

    @property
    def plan_cnt(self):
        return self._plan_cnt

    @property
    def state(self):
        return self._state

    @property
    def image_id(self):
        return self._image_id

    @property
    def city_code(self):
        return self._city_code

    @property
    def frame_label(self):
        return self._frame_label

    @property
    def rotate_angle(self):
        return self._rotate_angle

    @property
    def real_angle(self):
        return self._real_angle

    @property
    def plan_key(self):
        return self._PLAN_KEY

    @property
    def room_cnt(self):
        return self._room_cnt

    @property
    def room(self):
        return self._room_cnt[0]

    @property
    def parlour(self):
        return self._room_cnt[1]

    @property
    def kitchen(self):
        return self._room_cnt[2]

    @property
    def toilet(self):
        return self._room_cnt[3]

    @property
    def frame_size(self):
        return self._frame_size

    @property
    def explain_message(self):
        return self._explain_message

    @property
    def label_message(self):
        return self._label_message

    @property
    def entrance_degree(self):
        return self._entrance_degree

    @property
    def entrance_item(self):
        return self._entrance_item

    @property
    def entrance_type(self):
        return self._entrance_type

    @property
    def entrance_towards(self):
        return self._entrance_towards

    @property
    def entrance_plan_idx(self):
        return self._entrance_plan_idx

    @property
    def plan_sizes(self):
        return self._plan_sizes

    @property
    def border_key_points(self):
        return self._border_key_points

    @property
    def plan_cnt(self):
        return self._plan_cnt

    def set_house(self, house):
        self.house = house


class Label(object):

    def __init__(self):
        self.__label_dict = ce.LABEL_DICT

    def __getitem__(self, item):
        return self.__label_dict[item][0]

    def code2str(self, code):
        str_lst = []
        for label_key in self.__label_dict:
            label_info = self.__label_dict[label_key]
            if label_info[0] & code != 0:
                str_lst.append(label_info[1])
        return ",".join(str_lst)

    def code2lst(self, code):
        value_lst = []
        str_lst = []
        for label_key in self.__label_dict:
            label_info = self.__label_dict[label_key]
            if label_info[0] & code != 0:
                value_lst.append(label_info[0])
                str_lst.append(label_info[1])
        return value_lst, str_lst

    def __repr__(self):
        str_lst = ["Label class:"]
        label_lst = []
        for label_key in self.__label_dict:
            label_info = self.__label_dict[label_key]
            label_lst.append(label_info)
        label_lst = sorted(label_lst, key=lambda x: x[0])
        str_lst.extend(["{}: {}".format(x[0], x[1]) for x in label_lst[1:]])
        all_str = "\n".join(str_lst)
        return all_str

    def __len__(self):
        return len(self.__label_dict) - 1


class Liner(object):
    """
    户型图像相关对象
    """

    def __init__(self, simple_info, line_feature_dict, line_img_dict, area_feature_dict, plan_vector):
        """
        :param simple_info: dict, 简单信息字典
        :param line_feature_dict: dict, 墙体特征字典
        :param line_img_dict: dict, 图像特征
        :param area_feature_dict: dict, 分间特征
        :param plan_vector: dict, 原始户型矢量特征
        """
        self._simple_info = simple_info
        self._line_feature_dict = line_feature_dict
        self._line_img_dict = line_img_dict
        self._area_feature_dict = area_feature_dict
        self._plan_vector = plan_vector

    @property
    def minx(self):
        return self._simple_info["minx"]

    @property
    def miny(self):
        return self._simple_info["miny"]

    @property
    def plan_vector(self):
        return self._plan_vector

    @property
    def frame_id(self):
        """
        户型id
        :return:
        """
        return self._simple_info["frame_id"]

    @property
    def city_code(self):
        """
        城市id
        :return:
        """
        return self._simple_info["city_code"]

    @property
    def img_size(self):
        """
        画布大小
        :return:
        """
        return self._simple_info["img_size"]

    @property
    def plan_line_im_shape(self):
        """
        画布大小
        :return:
        """
        return self._simple_info["img_size"], self._simple_info["img_size"]

    @property
    def zoom_ratio(self):
        """
        画布大小
        :return:
        """
        return self._simple_info["zoom_ratio"]

    @property
    def offset(self):
        """
        画布边距
        :return:
        """
        return self._simple_info["zoom_offset"]

    @property
    def steps(self):
        """
        路线采样步数间隔
        :return:
        """
        return self._simple_info["steps"]

    @property
    def entrance_line(self):
        """
        门的起点和终点线段
        :return:
        """
        return self._line_feature_dict["entrance_line"]

    @property
    def entrance_pt(self):
        """
        门的起点和终点线段
        :return:
        """
        return self._line_feature_dict["entrance_point"]

    @property
    def is_draw(self):
        """
        是否画动线
        :return:
        """
        return self._simple_info["is_draw"]

    @property
    def is_draw_v(self):
        """
        是否画可视域
        :return:
        """
        return self._simple_info["is_draw_v"]

    @property
    def line_thickness(self):
        """
        膨胀系数
        :return:
        """
        return self._simple_info["line_thickness"]

    @property
    def zoom_base(self):
        """
        缩放尺寸
        :return:
        """
        return self._simple_info["zoom_base"]

    @property
    def thin_door_width(self):
        """
        门中心偏移
        :return:
        """
        return self._simple_info["thin_door_width"]

    @property
    def line_pts_close(self):
        """
        关门直线端点
        :return:
        """
        return self._line_feature_dict["zoom_ps_dict"]["full_line_ps"]

    @property
    def line_pts_open(self):
        """
        开门直线端点
        :return:
        """
        return self._line_feature_dict["zoom_ps_dict"]["seg_lines_norm"]

    @property
    def guest_line_points_dict(self):
        """
        客线目标点
        :return:
        """
        return self._area_feature_dict["guest_line_points_dict"]

    @property
    def work_line_points_dict(self):
        """
        家务动线目标点
        :return:
        """
        return self._area_feature_dict["work_line_points_dict"]

    @property
    def living_line_points_dict(self):
        """
        居住动线目标点
        :return:
        """
        return self._area_feature_dict["living_line_points_dict"]

    @property
    def plan_mask_im_reverse(self):
        """
        非户区域的遮罩
        :return:
        """
        return self._area_feature_dict["plan_mask_im_reverse"]

    @property
    def plan_line_im(self):
        """
        关门的栅格
        :return:
        """
        return self._line_img_dict["full_line_ps"]

    @property
    def plan_line_im_open(self):
        """
        全开门的栅格
        :return:
        """
        return self._line_img_dict["seg_lines_norm"]

    @property
    def plan_line_im_h(self):
        """
        窄门的栅格
        :return:
        """
        return self._line_img_dict["seg_lines_expand"]

    @property
    def edge_len(self):
        return self._simple_info["edge_len"]


class Point(object):
    """
    点对象
    """
    def __init__(self, x, y):
        self._x = int(x)
        self._y = int(y)

    @property
    def x(self):
        return self._x

    @property
    def y(self):
        return self._y

    def __eq__(self, other):
        if other.x == self._x and other.y == self._y:
            return True
        return False

    def __str__(self):
        return "x:{}, y:{}".format(self._x, self._y)

    def __getitem__(self, key):
        if 0 == key:
            return self._x
        elif 1 == key:
            return self._y

    def __hash__(self):
        return self._x*1000+self._y

    def get_tuple(self):
        return self._x, self._y


if __name__ == "__main__":
    label_factory = Label()
    print("标签种类: {}".format(len(label_factory)))
    print(label_factory)
