#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2019 www.ke.com, Inc. All Rights Reserved
"""
总体特征检测
Authors: yudonghai@ke.com
Date: 2019-06-10
"""
from __future__ import division
import logging
from operator import itemgetter
import collections

from lib import code_enum as ce
from lib import geometry_lib


ROOM_ATTACH_TYPE = ce.RoomLabel.with_balcony | ce.RoomLabel.with_toilet


def v1(base_func):
    """
    总体特征v1
    :param base_func: function, 被装饰函数
    :return: 装饰器函数
    """
    def item_func(frame, *args, **kwargs):
        logging.debug("global_feature.v1")
        if frame.state != ce.State.valid:
            return base_func(frame, *args, **kwargs)

        frame_vector = frame.vector

        explain_face = frame.explain_message.get(ce.EXPLAIN_FACE, {})
        explain_room = frame.explain_message.get(ce.EXPLAIN_ROOM, {})
        explain_wall = frame.explain_message.get(ce.EXPLAIN_WALL, {})

        # 卧室列表，用于判定主次卧 <id, 是否有朝南， 是否带卫生间/阳台， 面积>
        room_lst = []
        max_room = 0
        main_room_index = None
        # 次卧列表 <id, 次序，名称>
        sub_rooms = []

        # 分间类型：[同类型数量，同类型总面积]
        area_inf_dict = collections.defaultdict(lambda: [0, 0.])
        frame_face = collections.defaultdict(float)

        # 主卧邻接都次卧数量
        surround_sub_room_cnt = 0

        # 所有墙体长度
        line_sum = 0.
        # 倾斜墙体长度（加入了倾斜指数）
        oblique_line_sum = 0.
        # 异形分间的面积（加入了异形指数）
        abnormal_shape_size = 0.
        # 计算异形指数的分母
        all_shape_size = 0.
        # 外接矩形周长
        out_rec_len = 0.

        # 逐层
        for plan_vector in frame_vector[frame.plan_key]:
            areas = plan_vector[ce.PLAN_AREAS_KEY]
            lines = plan_vector[ce.PLAN_LINES_KEY]
            points_dict = plan_vector[ce.POINTS_DICT_KEY]
            plan_out_rectangle = [float("inf"), 0., float('inf'), 0.]

            # 斜墙统计
            for line_o in lines:
                l_ps = line_o[ce.LINE_POINTS_KEY]
                l_ps = [points_dict[l_ps[0]], points_dict[l_ps[1]]]
                diffs = [int(abs(l_ps[0][ce.X] - l_ps[1][ce.X])), int(abs(l_ps[0][ce.Y] - l_ps[1][ce.Y]))]
                # 倾斜指数【0， 1】，45度为最倾斜
                oblique_r = min(diffs) / (max(diffs) + 0.) if max(diffs) > 0 else 0
                l_len = geometry_lib.ps_distance(l_ps[0], l_ps[1])
                # todo 弧形墙默认倾斜指数
                if line_o[ce.LINE_CURVE_KEY] > 0:
                    oblique_r = 0.3
                line_sum += l_len
                oblique_line_sum += (l_len * oblique_r)

            for area in areas:

                area_id, area_points, room_type, detail_type, area_size = itemgetter(*ce.IPTTS)(area)
                cnt_type = room_type
                if room_type in {ce.AreaType.room.value, ce.AreaType.babysitter.value}:
                    cnt_type = ce.AreaType.room.value
                area_inf_dict[cnt_type][0] += 1
                area_inf_dict[cnt_type][1] += area_size

                # 外接矩形坐标统计
                if room_type not in ce.OUT_ROOM_TYPE:
                    for p in area_points:
                        p_x = points_dict[p][ce.X]
                        p_y = points_dict[p][ce.Y]
                        min_x = min(plan_out_rectangle[0], p_x)
                        max_x = max(plan_out_rectangle[1], p_x)
                        min_y = min(plan_out_rectangle[2], p_y)
                        max_y = max(plan_out_rectangle[3], p_y)
                        plan_out_rectangle = [min_x, max_x, min_y, max_y]
                    out_rec_len += 2. * (plan_out_rectangle[1] - plan_out_rectangle[0] + plan_out_rectangle[3] -
                                         plan_out_rectangle[2])

                # 主朝向分析
                main_face_len = 0
                main_face = ""
                if area_id in explain_face:
                    _, _, face_dict = explain_face[area_id]
                    for direction in face_dict:
                        f_len = face_dict[direction][0]
                        # 最大开窗方向，相同大小南向优先
                        if f_len > main_face_len or all([f_len == main_face_len,
                                                         ce.CKEY_SOUTH in direction,
                                                         ce.CKEY_SOUTH not in main_face]):
                            main_face = direction
                            main_face_len = f_len

                        if room_type not in ce.OUT_ROOM_TYPE:
                            frame_face[direction] += f_len

                # 凹角统计，找出非规整矩形的分间，用于判定户型方正
                track_info = explain_wall[area_id]
                expand_points, oblique_flag, max_line, line_info_lst, entrance_vector = track_info
                concave_p_cnt = sum([1 if p[ce.CKEY_POINT_TYPE] & ce.PointType.concave else 0 for p in expand_points])
                room_label = explain_room.get(area_id, ["", 0])[1]
                # 附加分间允许增加一个凹角不算入异形
                if room_label & ce.RoomLabel.with_toilet or room_label & ce.RoomLabel.with_cloakroom:
                    concave_p_cnt -= 1
                # todo 客厅异形判定由于过道等影响无法使用,不计入异形指数
                if room_type not in ce.SQUARE_EXCEPT_TYPES and not area[ce.AREA_EMPTY_KEY]:
                    all_shape_size += area_size
                    # 有凹角（附加分间只允许增加一个凹角）
                    if concave_p_cnt > 0:
                        x_ps = [p[ce.X] for p in expand_points]
                        y_ps = [p[ce.Y] for p in expand_points]
                        appro_empty = (max(x_ps) - min(x_ps)) * (max(y_ps) - min(y_ps)) - area_size
                        abnormal_r = min(area_size, 2 * appro_empty)
                        abnormal_shape_size += abnormal_r

                # 最大卧室
                if room_type == ce.AreaType.room.value:
                    south_flag = 1 if ce.CKEY_SOUTH in main_face else 0
                    attach_flag = 1 if room_label & ROOM_ATTACH_TYPE else 0
                    room_lst.append([area_id, south_flag, attach_flag, area_size])

                    if area_size > max_room:
                        max_room = area_size
                        main_room_index = len(room_lst) - 1
        # 斜墙指数
        oblique_ratio = oblique_line_sum / line_sum if line_sum > 0 else 0
        # 异形指数
        abnormal_ratio = abnormal_shape_size / all_shape_size if all_shape_size > 0 else 0
        logging.debug(u"户型方正判定：斜墙指数： {}， 异形指数: {}".format(oblique_ratio, abnormal_ratio))

        # 主卧判定
        if not room_lst or main_room_index is None:
            main_room_id = None
        else:
            main_room_id = room_lst[main_room_index][0]

            # 面积最大卧室不朝南，而其他卧室有朝南的, 则优先选择朝南的
            if room_lst[main_room_index][1] == 0 and sum([x[1] for x in room_lst]) > 0:
                reorder_room_lst = sorted(room_lst, key=lambda x: (x[1], x[2], x[3]), reverse=True)
                main_room_id = reorder_room_lst[0][0]
                logging.debug("change main room without max size")
        logging.debug(u"{} -main room".format(explain_room.get(main_room_id, ["", 0])[0]))

        # 次卧统计
        room_lst = sorted(room_lst, key=lambda x: (x[1], x[2], x[3]), reverse=True)
        sub_flag = 1
        for r in room_lst:
            if r[0] == main_room_id or r[0] not in explain_room:
                continue
            sub_rooms.append([r[0], sub_flag, explain_room[r[0]][0]])
            sub_flag += 1

        # 统计与主卧相邻的次卧
        sub_room_set = set([x[0] for x in sub_rooms])
        for plan_vector in frame_vector[frame.plan_key]:
            areas = plan_vector[ce.PLAN_AREAS_KEY]
            for area in areas:
                area_id = area[ce.AREA_ID_KEY]
                if area_id == main_room_id:
                    attach_areas = area[ce.AREA_ATTACHMENTS_KEY][ce.ATTACH_AREAS_KEY]
                    attach_id_set = set([x[ce.ATTACH_AREA_ID_KEY] for x in attach_areas])
                    surround_sub_room_cnt = len(attach_id_set.intersection(sub_room_set))
                    break
        logging.debug(u"主卧与 {} 次卧相邻".format(surround_sub_room_cnt))

        clear_n_face = {}
        clear_s_face = {}
        clear_w_face = {}
        clear_e_face = {}
        trans_len = 0.
        for f in frame_face:
            trans_len += frame_face[f]
            if frame_face[f] >= ce.FRAME_FACE_LEN:
                # 优先记为南北
                if ce.CKEY_SOUTH in f:
                    clear_s_face[f] = frame_face[f]
                elif ce.CKEY_NORTH in f:
                    clear_n_face[f] = frame_face[f]
                elif ce.CKEY_WEST in f:
                    clear_w_face[f] = frame_face[f]
                else:
                    clear_e_face[f] = frame_face[f]
        trans_flag = 0
        trans_weight = 0.
        trans_ratio = 2 * trans_len / out_rec_len if out_rec_len > 0 else 0
        # 双向
        if (clear_n_face and clear_s_face) or (clear_e_face and clear_w_face):
            trans_flag |= ce.TransType.both_face
            trans_weight = 3
        # 邻向
        for ns in [clear_n_face, clear_s_face]:
            for we in [clear_w_face, clear_e_face]:
                if ns and we:
                    trans_flag |= ce.TransType.neighbour_face
                    trans_weight = 2
        if any([clear_e_face, clear_w_face, clear_s_face, clear_n_face]):
            trans_flag |= ce.TransType.single_face
            trans_weight = 1

        face_flag = 0
        # 南北均有
        if clear_n_face and clear_s_face:
            face_flag |= ce.FaceType.north_south
        # 只南无北
        elif not clear_n_face and clear_s_face:
            face_flag |= ce.FaceType.south
        else:
            if clear_e_face:
                face_flag |= ce.FaceType.east
            if clear_w_face:
                face_flag |= ce.FaceType.west
            if clear_n_face:
                face_flag |= ce.FaceType.north

        main_face_flag = 0
        # 南北均有
        if clear_n_face and clear_s_face:
            main_face_flag |= ce.FaceType.north_south
        # 只南无北
        elif not clear_n_face and clear_s_face:
            main_face_flag |= ce.FaceType.south
        else:
            max_len = 0
            max_face = None
            for k, v in frame_face.items():
                if v > max_len:
                    max_len = v
                    max_face = k
            if max_face == ce.CKEY_NORTH:
                main_face_flag |= ce.FaceType.north
            if max_face == ce.CKEY_WEST:
                main_face_flag |= ce.FaceType.west
            if max_face == ce.CKEY_EAST:
                main_face_flag |= ce.FaceType.east

        frame.explain_message[ce.EXPLAIN_WHOLE_FRAME] = [
            area_inf_dict, main_room_id, sub_rooms, trans_flag,
            face_flag, [[oblique_ratio, abnormal_ratio]], surround_sub_room_cnt, trans_weight,
            main_face_flag]

        return base_func(frame, *args, **kwargs)
    return item_func


def v1_bigC(base_func):
    """
    总体特征v1——大C户型解读专用，主要区别在于主卧判定逻辑进行修改
    :param base_func: function, 被装饰函数
    :return: 装饰器函数
    """
    def item_func(frame, *args, **kwargs):
        logging.debug("global_feature.v1")
        if frame.state != ce.State.valid:
            return base_func(frame, *args, **kwargs)

        frame_vector = frame.vector

        explain_face = frame.explain_message.get(ce.EXPLAIN_FACE, {})
        explain_room = frame.explain_message.get(ce.EXPLAIN_ROOM, {})

        # 卧室列表，用于判定主次卧 <id, 是否有朝南， 是否带卫生间/阳台， 面积>
        room_lst = []
        max_room_area = 0
        main_room_index = None
        # 次卧列表 <id, 次序，名称>
        sub_rooms = []

        # 主卧邻接都次卧数量
        surround_sub_room_cnt = 0

        # 逐层
        for plan_vector in frame_vector[frame.plan_key]:
            areas = plan_vector[ce.PLAN_AREAS_KEY]
            # 逐分间
            for area in areas:
                # 分间基础信息获取
                area_id, area_points, room_type, detail_type, area_size = itemgetter(*ce.IPTTS)(area)
                # 当前分间-主朝向
                main_face_len = 0
                main_face = ""
                if area_id in explain_face:
                    _, _, face_dict = explain_face[area_id]
                    for direction in face_dict:
                        f_len = face_dict[direction][0]
                        # 最大开窗方向，相同大小南向优先
                        if f_len > main_face_len or all([f_len == main_face_len, ce.CKEY_SOUTH in direction]):
                            main_face = direction
                            main_face_len = f_len
                # 分间标签
                room_label = explain_room.get(area_id, ["", 0])[1]
                # 卧室
                if room_type == ce.AreaType.room.value:
                    south_flag = 1 if ce.CKEY_SOUTH in main_face else 0
                    attach_flag = 1 if room_label & ROOM_ATTACH_TYPE else 0  # 有阳台、有卫生间
                    room_lst.append([area_id, south_flag, attach_flag, area_size])

                    if area_size > max_room_area:
                        max_room_area = area_size
                        main_room_index = len(room_lst) - 1

        # 主卧判定
        if not room_lst or main_room_index is None:
            main_room_id = None
        else:
            main_room_id = room_lst[main_room_index][0]

            # 面积最大卧室不朝南，而其他卧室有朝南的, 则优先选择朝南的
            if room_lst[main_room_index][1] == 0 and sum([x[1] for x in room_lst]) > 0:
                # 按照朝向、是否阳台卫生间、面积从大到小进行排序
                reorder_room_lst = sorted(room_lst, key=lambda x: (x[1], x[2], x[3]), reverse=True)
                # =====【增加面积约束:得到的主卧面积必须大于等于整个户型最大卧室面积的90%】=====
                if reorder_room_lst[0][-1] / room_lst[main_room_index][-1] >= 0.9:
                    main_room_id = reorder_room_lst[0][0]
                    logging.debug("change main room without max size")
        logging.debug(u"{} -main room".format(explain_room.get(main_room_id, ["", 0])[0]))

        # 次卧统计
        room_lst = sorted(room_lst, key=lambda x: (x[1], x[2], x[3]), reverse=True)
        sub_flag = 1
        for r in room_lst:
            if r[0] == main_room_id or r[0] not in explain_room:
                continue
            sub_rooms.append([r[0], sub_flag, explain_room[r[0]][0]])
            sub_flag += 1

        # 统计与主卧相邻的次卧
        sub_room_set = set([x[0] for x in sub_rooms])
        for plan_vector in frame_vector[frame.plan_key]:
            areas = plan_vector[ce.PLAN_AREAS_KEY]
            for area in areas:
                area_id = area[ce.AREA_ID_KEY]
                if area_id == main_room_id:
                    attach_areas = area[ce.AREA_ATTACHMENTS_KEY][ce.ATTACH_AREAS_KEY]
                    attach_id_set = set([x[ce.ATTACH_AREA_ID_KEY] for x in attach_areas])
                    surround_sub_room_cnt = len(attach_id_set.intersection(sub_room_set))
                    break
        logging.debug(u"主卧与 {} 次卧相邻".format(surround_sub_room_cnt))

        # 更新主卧，以及与主卧相关的变量
        frame.explain_message[ce.EXPLAIN_WHOLE_FRAME][1] = main_room_id
        frame.explain_message[ce.EXPLAIN_WHOLE_FRAME][2] = sub_rooms
        frame.explain_message[ce.EXPLAIN_WHOLE_FRAME][6] = surround_sub_room_cnt

        return base_func(frame, *args, **kwargs)
    return item_func
