# -*- coding: utf-8 -*-
# ===============================================================
#
#    Copyright (C) 2020 Beike, Inc. All Rights Reserved.
#
#    @Create Author : gaixindong (gaixindong@ke.com)
#    @Create Time   : 2020/7/22 18:23
#    @Description   : 
#
# ===============================================================


class FFmpegError(Exception):
    """FFmpeg命令执行异常"""
    pass


class AlreadyExistsError(Exception):
    """生产已存在数据时的异常"""
    pass


class ArgumentError(Exception):
    """请求参数错误"""
    pass


class MySQLError(Exception):
    """mysql错误"""
    pass


class UpdateError(Exception):
    """文件更新异常"""
    pass


class UploadError(Exception):
    """文件上传异常"""
    pass


class DownloadError(Exception):
    """文件下载异常"""
    pass


class WebdriverError(Exception):
    """浏览器异常"""
    pass


class RequestError(Exception):
    """请求异常"""
    pass


class ResponseError(Exception):
    """响应异常"""
    pass


class WillRetryError(Exception):
    """用于触发重试"""
    pass


class RetryFailedError(Exception):
    """重试失败"""
    pass


class TTSError(Exception):
    """tts生产错误"""
    pass


class TimeoutError(Exception):
    """超时错误"""
    pass


class RedisLockError(Exception):
    """未获取到redis锁错误"""
    pass
