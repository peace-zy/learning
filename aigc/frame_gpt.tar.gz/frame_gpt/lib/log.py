# coding=utf-8
"""
Author: caibaiyin@lianjia.com
        songxin@lianjia.com
Time: Wed Nov 29 18:54:37 CST 2017
"""

import logging
import logging.handlers
import os
import sys
import time

if os.name != "nt":
    import fcntl
# ke defined log level & name
KE_LOGNAMELVL = {
    'DEBUG': logging.DEBUG,
    'INFO': logging.INFO,
    'TRACE': logging.INFO,
    'NOTICE': logging.WARNING,
    'WARNING': logging.ERROR,
    'FATAL': logging.CRITICAL
}

# Global logging produced a unique ke_logger
ke_logger = logging.getLogger('ke_log')


class ConcurrentTimedRotatingFileHandler(logging.handlers.TimedRotatingFileHandler):
    """
    重写TimedRotatingFileHandler类，解决tornado多进程写日志丢失的问题
    """

    def __init__(self, filename, when='h', interval=1, backupCount=0, encoding=None, delay=False, utc=False,
                 op_log=False, log_type=None):
        """
        增加额外参数，用于兼容op log 格式
        :param op_log: boolean, 是否op log
        :param log_type: string, op log 类型，会被当做log文件的后缀
        """
        super(ConcurrentTimedRotatingFileHandler, self).__init__(filename, when, interval, backupCount, encoding,
                                                                 delay, utc)
        # 兼容op要求的log文件格式
        if op_log:
            self.suffix = self.suffix.replace("-", "")
            if log_type is not None:
                self.suffix += log_type

    def doRollover(self):
        """
        do a rollover; in this case, a date/time stamp is appended to the filename
        when the rollover happens.  However, you want the file to be named for the
        start of the interval, not the current time.  If there is a backup count,
        then we have to get a list of matching filenames, sort them and remove
        the one with the oldest suffix.
        """
        t = self.rolloverAt - self.interval
        if self.utc:
            time_tuple = time.gmtime(t)
        else:
            time_tuple = time.localtime(t)
        dfn = self.baseFilename + "." + time.strftime(self.suffix, time_tuple)

        # lock self.stream
        if os.name != "nt":
            fcntl.flock(self.stream, fcntl.LOCK_EX)
        if not os.path.exists(dfn) and os.path.exists(self.baseFilename):
            os.rename(self.baseFilename, dfn)
        if self.backupCount > 0:
            # find the oldest log file and delete it
            # s = glob.glob(self.baseFilename + ".20*")
            # if len(s) > self.backupCount:
            #    s.sort()
            #    os.remove(s[0])
            for s in self.getFilesToDelete():
                os.remove(s)
        if os.name != "nt":
            fcntl.flock(self.stream, fcntl.LOCK_UN)
        if self.stream:
            self.stream.close()

        self.mode = 'a'
        self.stream = self._open()
        current_time = int(time.time())
        new_rollover_at = self.computeRollover(current_time)
        while new_rollover_at <= current_time:
            new_rollover_at = new_rollover_at + self.interval
        # If DST changes and midnight or weekly rollover, adjust for this.
        if (self.when == 'MIDNIGHT' or self.when.startswith('W')) and not self.utc:
            dstNow = time.localtime(current_time)[-1]
            dstAtRollover = time.localtime(new_rollover_at)[-1]
            if dstNow != dstAtRollover:
                if not dstNow:  # DST kicks in before next rollover, so we need to deduct an hour
                    new_rollover_at = new_rollover_at - 3600
                else:  # DST bows out before next rollover, so we need to add an hour
                    new_rollover_at = new_rollover_at + 3600
        self.rolloverAt = new_rollover_at


class WfLogFilter(logging.Filter):
    """
    Filter out WARNING and FATAL log
    """

    def filter(self, record):
        return 0 if record.levelno >= logging.ERROR else 1


def init(level, normal_log_path, wf_log_path=None, auto_rotate=False, backup_days=7, op_log=False, log_type=None):
    """
    initialization function
    level: the level of log, it can be:
        'DEBUG'
        'TRACE'
        'NOTICE'
        'WARNING'
        'FATAL'
    normal_log_path: the path of log file
    wf_log_path: the path of warning and fatal log file
    """
    # Set log level
    for name in KE_LOGNAMELVL:
        logging.addLevelName(KE_LOGNAMELVL[name], name)
    levelno = KE_LOGNAMELVL[level]
    ke_logger.setLevel(levelno)
    ke_fmt = logging.Formatter('%(levelname)s: %(asctime)s: %(thread)d [%(bd_filename)s:%(bd_lineno)d]'
                               '[%(bd_funcName)s] %(message)s')
    # Set normal log file
    if auto_rotate:
        backup_count = backup_days * 24
        normal_hdlr = ConcurrentTimedRotatingFileHandler(normal_log_path, when='MIDNIGHT', interval=1,
                                                         backupCount=backup_count, op_log=op_log, log_type=log_type)
    else:
        normal_hdlr = logging.handlers.WatchedFileHandler(normal_log_path)
    normal_hdlr.setFormatter(ke_fmt)
    normal_hdlr.setLevel(levelno)

    sh = logging.StreamHandler()
    sh.setFormatter(ke_fmt)

    # Make WF log emit to a separate file
    if wf_log_path is not None:
        normal_hdlr.addFilter(WfLogFilter())
        # set wf log file
        if auto_rotate:
            wf_hdlr = ConcurrentTimedRotatingFileHandler(wf_log_path, when='MIDNIGHT', interval=1,
                                                         backupCount=backup_count, op_log=op_log, log_type=log_type)
        else:
            wf_hdlr = logging.handlers.WatchedFileHandler(wf_log_path)
        wf_hdlr.setFormatter(ke_fmt)
        wf_hdlr.setLevel(levelno if levelno > logging.ERROR else logging.ERROR)
        ke_logger.addHandler(wf_hdlr)
    ke_logger.addHandler(normal_hdlr)
    ke_logger.addHandler(sh)


def debug(msg, *args):
    """
    DEBUG level log
    """
    ke_logger.debug(msg, *args, extra=_extra())


def info(msg, *args):
    """
    INFO level log
    """
    ke_logger.info(msg, *args, extra=_extra())


def trace(msg, *args):
    """
    TRACE level log
    """
    ke_logger.info(msg, *args, extra=_extra())


def notice(msg, *args):
    """
    NOTICE level log
    """
    ke_logger.warning(msg, *args, extra=_extra())


def warning(msg, *args):
    """
    WARNING level log
    """
    ke_logger.error(msg, *args, extra=_extra())


def fatal(msg, *args):
    """
    FATAL level log
    """
    ke_logger.critical(msg, *args, extra=_extra())


def _extra():
    """
    add file name, file number and function name
    """
    file_path = sys._getframe(2).f_code.co_filename
    dir_path, base_name = os.path.split(file_path)
    super_dir, current_dir = os.path.split(dir_path)
    file_name = os.path.join(current_dir, base_name)
    return {'bd_filename': file_name,
            'bd_lineno': sys._getframe(2).f_lineno,
            'bd_funcName': sys._getframe(2).f_code.co_name}
