#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2019 www.ke.com, Inc. All Rights Reserved
"""
分间独立监测点（按分间类型）
Authors: yudonghai@ke.com
Date: 2019-06-10
"""
from __future__ import division
import logging
from operator import itemgetter
import collections
import numpy as np

from lib import code_enum as ce
from lib import geometry_lib
from frame_remould.geometry.line import Ray2D
from frame_remould.geometry.point import Point2D


def face_door(expand_points, line_info_lst):
    """
    获取正对的门
    :param expand_points: list, 分间墙体点列表
    :param line_info_lst: list, 分间墙体信息列表
    :return: face_pairs, list, 正对门的分间id对
            face_entrance, list, 正对入户门对分间id列表
    """

    # 门正对的分间对
    face_pairs = []
    # 正对入户门对分间
    face_entrance = []

    doors = []
    for i, line_info in enumerate(line_info_lst):
        line_id, s_i, e_i, edge_flag, face_line, out_len, real_conn_area_lst = line_info
        if len(real_conn_area_lst) > 1:
            logging.error("bad conn")

        conn_area_id = real_conn_area_lst[0] if real_conn_area_lst else None
        sub_ps = expand_points[s_i: e_i]
        door_ps = [x for x in sub_ps if x[ce.CKEY_POINT_TYPE] & ce.FACE_DOOR_POINT_TYPE]

        item_doors = [[[door_ps[i], door_ps[i + 1]], conn_area_id]for i in range(0, len(door_ps), 2)]
        doors.extend(item_doors)

    def get_angle(norma, normb):
        pa0 = Point2D(norma[0]['x'], norma[0]['y'])
        pa1 = Point2D(norma[1]['x'], norma[1]['y'])
        pb0 = Point2D(normb[0]['x'], normb[0]['y'])
        pb1 = Point2D(normb[1]['x'], normb[1]['y'])
        raya = Ray2D(pa0, pa1)
        rayb = Ray2D(pb0, pb1)
        ang = np.rad2deg(raya.angle_between(rayb))
        return ang

    for i, (dps_a, area_a) in enumerate(doors):
        for j, (dps_b, area_b) in enumerate(doors):
            if i >= j:
                continue
            normas = geometry_lib.get_normal_line(dps_a)
            normbs = geometry_lib.get_normal_line(dps_b)

            if normas is None or normbs is None:
                continue
            # 只用中间对一条法线
            norma = normas[0]
            normb = normbs[0]

            ang = get_angle(norma, normb)
            a_expand_line = geometry_lib.expand_line(dps_a, ce.FACE_DOOR_DIFF)
            b_expand_line = geometry_lib.expand_line(dps_b, ce.FACE_DOOR_DIFF)
            if a_expand_line is None or b_expand_line is None:
                continue
            a_face_flags = geometry_lib.to_left_test(norma, b_expand_line)
            b_face_flags = geometry_lib.to_left_test(normb, a_expand_line)

            a_face_value = a_face_flags[0] * a_face_flags[1]
            b_face_value = b_face_flags[0] * b_face_flags[1]

            # 两门正对
            if (a_face_value <= 0 or b_face_value <= 0) and ang > 160:
                real_dist = geometry_lib.ps_distance(norma[0], normb[0])
                if area_a is not None and area_b is not None:
                    face_pairs.append([area_a, area_b, real_dist])
                else:
                    if area_a is not None or area_b is not None:
                        face_entrance.append([area_a if area_a is not None else area_b, real_dist])

    return face_pairs, face_entrance


def single_general(base_func):
    """
    分功能分间的检测点
    :param base_func: function, 被装饰函数
    :return: 装饰器函数
    """
    def item_func(frame, *args, **kwargs):
        logging.debug("single_area.single_general")
        if frame.state != ce.State.valid:
            return base_func(frame, *args, **kwargs)

        frame_vector = frame.vector

        explain_wall = frame.explain_message[ce.EXPLAIN_WALL]

        explain_toilet = {}
        explain_room = {}
        explain_kitchen = collections.defaultdict(dict)
        explain_parlour = collections.defaultdict(dict)
        frame_p_label = 0
        french_window_areas = set()
        kitchen_closed_entrance = float("inf")

        for plan_vector in frame_vector[frame.plan_key]:
            areas = plan_vector[ce.PLAN_AREAS_KEY]
            points_dict, line_items_dict, lines_dict, areas_dict = itemgetter(*ce.DICTS)(plan_vector)
            toilet_dict = collections.defaultdict(lambda: {
                ce.AREA_LABEL: 0,
                ce.AREA_FACE_EN: float('inf'),
                ce.TOILET_FACE_KITCHEN: float('inf'),
                ce.TOILET_FACE_ROOM: float('inf'),
            })
            # room_dict = collections.defaultdict(int)
            room_dict = collections.defaultdict(lambda: {
                ce.AREA_LABEL: 0,
                ce.AREA_FACE_EN: float('inf'),
                ce.TOILET_FACE_ROOM: float('inf'),
            })

            out_lines = set()
            for area in areas:
                area_room_type = area[ce.AREA_ROOM_TYPE_KEY]
                if area_room_type == ce.AreaType.garden.value:
                    for l in area[ce.AREA_ATTACHMENTS_KEY][ce.ATTACH_LINES_KEY]:
                        out_lines.add(l[ce.ATTACH_LINE_ID_KEY])

            # 逐分间
            for area in areas:
                area_id, area_points, room_type, detail_type, area_size = itemgetter(*ce.IPTTS)(area)
                att_line_items, att_lines, _ = itemgetter(*ce.ATTACH_KEYS)(area[ce.AREA_ATTACHMENTS_KEY])
                # 落地窗/墙
                for li in att_lines:
                    li_obj = lines_dict[li[ce.ATTACH_LINE_ID_KEY]]
                    if not li_obj[ce.EDGE_COMP_KEY] and li[ce.ATTACH_LINE_ID_KEY] not in out_lines:
                        continue
                    if lines_dict[li[ce.ATTACH_LINE_ID_KEY]][ce.LINE_TYPE_KEY] == ce.GLASS_FRENCH_TYPE:
                        frame_p_label |= ce.FramePLabel.french_window
                        french_window_areas.add(area[ce.AREA_ROOM_NAME_KEY])
                    line_att_items = li_obj[ce.LINE_ITEMS_KEY]
                    for lii in line_att_items:
                        if line_items_dict[lii][ce.LINE_ITEM_TYPE_KEY] in ce.FRENCH_WINDOW_TYPES:
                            frame_p_label |= ce.FramePLabel.french_window
                            french_window_areas.add(area[ce.AREA_ROOM_NAME_KEY])
 
                # 有独立餐厅
                if detail_type == ce.DINING_ROOM:
                    frame_p_label |= ce.FramePLabel.with_dining_room
                # 带花园
                if room_type == ce.AreaType.garden.value:
                    frame_p_label |= ce.FramePLabel.with_garden
                elif room_type == ce.AreaType.loft.value:
                    frame_p_label |= ce.FramePLabel.with_loft
                elif room_type == ce.AreaType.terrace.value:
                    frame_p_label |= ce.FramePLabel.with_terrace

                wall_info = explain_wall[area_id]
                expand_points, oblique_flag, max_line, line_info_lst, entrance_vector = wall_info
                face_pairs, face_entrance = face_door(expand_points, line_info_lst)
                for a, b, face_d in face_pairs:
                    try:
                        a_type = areas_dict[a][ce.AREA_ROOM_TYPE_KEY]
                        b_type = areas_dict[b][ce.AREA_ROOM_TYPE_KEY]
                    except Exception as e:
                        logging.error("room_id key error: {}".format(frame.frame_id))
                        continue
                    if ce.AreaType.toilet.value in {a_type, b_type}:
                        toilet_id = a if a_type == ce.AreaType.toilet.value else b
                        another_id = b if toilet_id == a else a
                        another_type = areas_dict[another_id][ce.AREA_ROOM_TYPE_KEY]
                        # 卫生间正对厨房
                        if another_type == ce.AreaType.kitchen.value:
                            toilet_dict[toilet_id][ce.AREA_LABEL] |= ce.ToiletLabel.face_kitchen
                            toilet_dict[toilet_id][ce.TOILET_FACE_KITCHEN] = face_d / 1000.
                            explain_kitchen[another_id][ce.TOILET_FACE_KITCHEN] = min(
                                [toilet_dict[temp_id].get(ce.TOILET_FACE_KITCHEN, float('inf')) for temp_id in
                                 toilet_dict])

                        # 卫生间正对卧室
                        if another_type == ce.AreaType.room.value or another_type == ce.AreaType.babysitter.value:
                            room_dict[another_id][ce.AREA_LABEL] |= ce.RoomLabel.face_toilet
                            room_dict[another_id][ce.TOILET_FACE_ROOM] = face_d / 1000.
                            toilet_dict[toilet_id][ce.AREA_LABEL] |= ce.ToiletLabel.face_room
                            toilet_dict[toilet_id][ce.TOILET_FACE_ROOM] = face_d / 1000.

                    # 卧室正对其他卧室
                    if ce.AreaType.room.value in {a_type, b_type}:
                        a_id = a if a_type == ce.AreaType.room.value else b
                        another_id = b if a_id == a else a
                        another_type = areas_dict[another_id][ce.AREA_ROOM_TYPE_KEY]

                        if another_type == ce.AreaType.room.value:
                            room_dict[a_id][ce.AREA_LABEL] |= ce.RoomLabel.face_others
                            room_dict[another_id][ce.AREA_LABEL] |= ce.RoomLabel.face_others

                for a, d in face_entrance:
                    # 卫生间与入户门形成对视
                    if areas_dict[a][ce.AREA_ROOM_TYPE_KEY] == ce.AreaType.toilet.value:
                        toilet_dict[a][ce.AREA_LABEL] |= ce.ToiletLabel.face_entrance
                        toilet_dict[a][ce.AREA_FACE_EN] = d
                    # 厨房靠近入户门（正对）
                    if areas_dict[a][ce.AREA_ROOM_TYPE_KEY] == ce.AreaType.kitchen.value:
                        kitchen_closed_entrance = d if d < kitchen_closed_entrance else kitchen_closed_entrance
                        explain_kitchen[a][ce.WITH_ENTRANCE] = kitchen_closed_entrance
                    # 卧室靠近入户门（正对）
                    if areas_dict[a][ce.AREA_ROOM_TYPE_KEY] == ce.AreaType.room.value:
                        room_dict[a][ce.AREA_LABEL] |= ce.RoomLabel.face_entrance
                        room_dict[a][ce.AREA_FACE_EN] = d

                # 靠近入户门的分间查找
                if entrance_vector is not None:
                    doors = [i for i in range(len(expand_points)) if expand_points[i][ce.CKEY_POINT_TYPE] & ce.DOORS_TYPE]
                    pre, after, en = None, None, None
                    for i in range(len(doors)):
                        if expand_points[doors[i]][ce.CKEY_POINT_TYPE] & ce.PointType.entrance_start:
                            pre = doors[i - 1]
                            en = doors[i]
                            after = doors[(i + 1) % len(doors)]
                    if pre != after and pre is not None:
                        for _, expand_start_index, expand_end_index, _, _, _, real_conn_area_lst in line_info_lst:
                            cur_index = None
                            if expand_start_index <= pre <= expand_end_index:
                                cur_index = pre
                            if expand_start_index <= after <= expand_end_index:
                                cur_index = after
                            if cur_index is not None:
                                dist = geometry_lib.ps_distance(expand_points[cur_index], expand_points[en])

                                for closed_id in real_conn_area_lst:
                                    # 厨房近入户门
                                    if areas_dict[closed_id][ce.AREA_ROOM_TYPE_KEY] == ce.AreaType.kitchen.value:
                                        kitchen_closed_entrance = dist if dist < kitchen_closed_entrance else kitchen_closed_entrance
                                        explain_kitchen[closed_id][ce.WITH_ENTRANCE] = kitchen_closed_entrance
                inner_wall_flag = sum([1 for x in expand_points if x[ce.CKEY_POINT_TYPE] & ce.PointType.divergence])

                # 临近可联通分间
                conn_area_detail_type_lst = []
                conn_area_detail_type_set = set()
                conn_area_room_type_set = set()

                conn_area_id_set = set()
                surround_areas_lst = []

                # 临近不联通区域
                neighbor_detail_type_lst = []
                neighbor_detail_type_set = set()
                neighbor_room_type_set = set()

                for i, line_info in enumerate(line_info_lst):
                    line_id, s_i, e_i, edge_flag, face_line, out_len, real_conn_area_lst = line_info

                    surround_areas_lst.extend(real_conn_area_lst)
                    if line_id not in lines_dict:
                        frame._state = ce.State.illegal_area_diff_attach_line
                        return base_func(frame, *args, **kwargs)

                    if lines_dict[line_id][ce.LINE_TYPE_KEY] in ce.TRANS_WALL_TYPE:
                        door_cnt = 1
                    else:
                        door_cnt = sum([1 for k in expand_points[s_i: e_i]
                                        if k[ce.CKEY_POINT_TYPE] & ce.PointType.door_start])
                        items = lines_dict[line_id][ce.LINE_ITEMS_KEY]
                        for item in items:
                            if line_items_dict[item][ce.LINE_ITEM_TYPE_KEY] == ce.YAKOU:
                                door_cnt += 1
                    if door_cnt == 0:
                        for conn_area in real_conn_area_lst:
                            if conn_area not in areas_dict:
                                logging.error("lack {} in areas_dict".format(conn_area))
                                continue
                            c_area_id, _, conn_room_type, c_detail_type, _ = itemgetter(*ce.IPTTS)(
                                areas_dict[conn_area])

                            neighbor_detail_type_lst.append(c_detail_type)
                            neighbor_detail_type_set.add(c_detail_type)
                            neighbor_room_type_set.add(conn_room_type)
                    else:
                        for conn_area in real_conn_area_lst:
                            if conn_area not in areas_dict:
                                logging.error("lack {} in areas_dict".format(conn_area))
                                continue
                            c_area_id, _, conn_room_type, c_detail_type, _ = itemgetter(*ce.IPTTS)(areas_dict[conn_area])

                            conn_area_id_set.add(c_area_id)
                            conn_area_detail_type_lst.append(c_detail_type)
                            conn_area_detail_type_set.add(c_detail_type)
                            conn_area_room_type_set.add(conn_room_type)
                # 客厅
                if detail_type in ce.REAL_PARLOUR:
                    explain_parlour[area_id] = dict()
                    if ce.MEN_TING in conn_area_detail_type_set:
                        frame_p_label |= ce.FramePLabel.with_menting
                    if ce.AreaType.balcony.value in conn_area_room_type_set:
                        frame_p_label |= ce.FramePLabel.parlour_with_balcony
                        explain_parlour[area_id][ce.WITH_BALCONY] = True

                    if ce.DINING_ROOM in conn_area_detail_type_set:
                        frame_p_label |= ce.FramePLabel.parlour_with_dining
                # 厨房
                elif room_type == ce.AreaType.kitchen.value:
                    # explain_kitchen[area_id] = dict()
                    if area_size >= ce.COOKING_SIZE:
                        frame_p_label |= ce.FramePLabel.cooking_area
                    if ce.DINING_ROOM in conn_area_detail_type_set:
                        frame_p_label |= ce.FramePLabel.kitchen_with_dining
                        explain_kitchen[area_id][ce.WITH_DINNING] = True
                    if ce.AreaType.balcony.value in conn_area_room_type_set:
                        frame_p_label |= ce.FramePLabel.kitchen_with_balcony
                        explain_kitchen[area_id][ce.WITH_BALCONY] = True
                    # 厨房正对卫生间
                    # explain_kitchen[area_id][ce.TOILET_FACE_KITCHEN] = min([toilet_dict[temp_id].get(ce.TOILET_FACE_KITCHEN, float('inf')) for temp_id in toilet_dict])

                # 卫生间
                elif room_type == ce.AreaType.toilet.value:
                    # 干湿分离
                    toilet_dict[area_id][ce.AREA_LABEL] |= (ce.ToiletLabel.sep if inner_wall_flag > 0 else 0)
                    # 套间内卫生间
                    if ce.AreaType.room.value in conn_area_room_type_set and len(conn_area_detail_type_lst) == 1:
                        toilet_dict[area_id][ce.AREA_LABEL] |= ce.ToiletLabel.private

                # 室
                elif room_type == ce.AreaType.room.value:
                    # 卧室带卫生间
                    if ce.AreaType.toilet.value in conn_area_room_type_set:
                        room_dict[area_id][ce.AREA_LABEL] |= ce.RoomLabel.with_toilet

                    # 卧室带衣帽/储物间
                    if {ce.AreaType.cloakroom.value, ce.AreaType.storage.value}.intersection(conn_area_room_type_set):
                        room_dict[area_id][ce.AREA_LABEL] |= ce.RoomLabel.with_cloakroom
                    # 卧室带阳台
                    if ce.AreaType.balcony.value in conn_area_room_type_set:
                        room_dict[area_id][ce.AREA_LABEL] |= ce.RoomLabel.with_balcony

                    # 卧室与厨房相邻
                    if ce.AreaType.kitchen.value in neighbor_room_type_set:
                        room_dict[area_id][ce.AREA_LABEL] |= ce.RoomLabel.neighbor_kitchen

                    # room_dict[area_id] |= 0

                # 作为中间过渡，连接两个其他两个分间
                if (detail_type == ce.GUODAO or room_type == ce.AreaType.cloakroom.value) and len(conn_area_id_set) == 2:
                    type_id_dict = {areas_dict[k][ce.AREA_ROOM_TYPE_KEY]: k for k in conn_area_id_set}
                    if ce.AreaType.toilet.value in type_id_dict and ce.AreaType.room.value in type_id_dict:
                        toilet_dict[type_id_dict[ce.AreaType.toilet.value]][ce.AREA_LABEL] |= ce.ToiletLabel.private
                        room_dict[type_id_dict[ce.AreaType.room.value]][ce.AREA_LABEL] |= ce.RoomLabel.with_toilet
                    if ce.AreaType.cloakroom.value in type_id_dict and ce.AreaType.room.value in type_id_dict:
                        room_dict[type_id_dict[ce.AreaType.room.value]][ce.AREA_LABEL] |= ce.RoomLabel.with_cloakroom
                    if ce.AreaType.balcony.value in type_id_dict and ce.AreaType.room.value in type_id_dict:
                        room_dict[type_id_dict[ce.AreaType.room.value]][ce.AREA_LABEL] |= ce.RoomLabel.with_balcony
            t_dict = {x: [areas_dict[x][ce.AREA_ROOM_NAME_KEY],
                          toilet_dict[x][ce.AREA_LABEL],
                          toilet_dict[x][ce.AREA_FACE_EN],
                          toilet_dict[x][ce.TOILET_FACE_KITCHEN],
                          toilet_dict[x][ce.TOILET_FACE_ROOM]] for x in toilet_dict}
            # r_dict = {ri: [areas_dict[ri][ce.AREA_ROOM_NAME_KEY], room_dict[ri]] for ri in room_dict}
            r_dict = {ri: [areas_dict[ri][ce.AREA_ROOM_NAME_KEY], room_dict[ri][ce.AREA_LABEL], room_dict[ri][ce.AREA_FACE_EN], room_dict[ri][ce.TOILET_FACE_ROOM]] for ri in room_dict}
            explain_toilet.update(t_dict)
            explain_room.update(r_dict)
        frame.explain_message[ce.EXPLAIN_TOILET] = explain_toilet
        frame.explain_message[ce.EXPLAIN_ROOM] = explain_room
        frame.explain_message[ce.EXPLAIN_KITCHEN] = explain_kitchen
        frame.explain_message[ce.EXPLAIN_PARLOUR] = explain_parlour
        frame.explain_message[ce.EXPLAIN_FRAME] = frame_p_label
        frame.explain_message["french_window_areas"] = list(french_window_areas)
        frame.explain_message["kitchen_closed_entrance"] = kitchen_closed_entrance / 1000.

        return base_func(frame, *args, **kwargs)
    return item_func
