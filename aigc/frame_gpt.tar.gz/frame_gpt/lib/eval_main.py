#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2019 www.ke.com, Inc. All Rights Reserved
"""
户型解读主函数
Authors: yudonghai@ke.com
Date: 2019-06-10
"""
from __future__ import division
import logging
import sys
import os
import collections
from operator import itemgetter
import traceback

from lib import eval_general
from lib import eval_single
from lib import eval_global
from lib import liner_lib
from lib import entity
from lib import code_enum as ce
from lib import geometry_lib
from lib import room_contour_lib
from lib import mod_util_base as mod_util
from frame_remould.geometry.polygon import Polygon


FACE_MAP = {
    "north": u"北",
    "north-east": u"东北",
    "north-west": u"西北",
    "east": u"东",
    "south": u"南",
    "south-east": u"东南",
    "south-west": u"西南",
    "west": u"西",
}

KITCHEN_DECORATE_KEYS = {
    "area_id",
    "has_balcony",
    "main_width_label",
    "main_deep_label",
    "has_side_400_cnt",
    "has_side_1300_cnt",
    "door_balcony_pos",
    "has_parallel_balcony",
    "has_vertical_balcony",
    "balcony_has_800",
    "area_size_label",
    "toilet_area_size_label",
    "door_cnt"
}

TOILET_DECORATE_KEYS = {
    "main_width_label",
    "main_deep_label",
    "door_at_side",
    "has_side_800_cnt"
}


def get_real_value(message, path, strict=True):
    """
    数值提取
    :param message: dict, 包含检测点真实数值的字典
    :param path: list, 目标数值在 message 中的路径
    :param strict: bool, 是否必须找到值
    :return: p, 查找到的目标值
    """
    p = message
    try:
        for step in path:
            p = p[step]
    except Exception as e:
        logging.warn(message)
        logging.warn("invalid var(s) path: {}".format(path))
        if strict:
            os._exit(1)
        else:
            return None
    return p


def frame_prepare(base_func):
    """
    户型解读数据结构准备，包括墙体-分间映射和入户门信息
    Frame.explain_message 增加
    explain_line_areas: {area_id: list<line_id>}
    explain_entrance: [入户门entrance值, 入户门所在墙体ID, None]
    :param base_func: function, 被装饰函数
    :return: 装饰器函数
    """

    def item_func(frame, *args, **kwargs):
        logging.debug("main_func.frame_prepare")

        if frame.state != ce.State.valid:
            return base_func(frame, *args, **kwargs)

        frame_vector = frame.vector

        # 准备墙体-分间映射字典
        explain_line_areas = collections.defaultdict(set)
        entrance_value = None
        entrance_line = None

        # 逐层
        for plan_vector in frame_vector[frame.plan_key]:
            areas = plan_vector[ce.PLAN_AREAS_KEY]
            line_items = plan_vector[ce.PLAN_LINE_ITEMS_KEY]
            lines_dict = plan_vector[ce.LINES_DICT_KEY]

            # 查找入户门
            for line_item in line_items:
                entrance = line_item[ce.ENTRANCE_KEY]
                if entrance is not None:
                    entrance_value = entrance
                    entrance_line = lines_dict[line_item[ce.LINE_ITEM_LINE_KEY]]
            # 逐分间
            for area in areas:
                area_id = area[ce.AREA_ID_KEY]
                attachments = area[ce.AREA_ATTACHMENTS_KEY]
                attache_lines = attachments[ce.ATTACH_LINES_KEY]
                for line in attache_lines:
                    line_id = line[ce.ATTACH_LINE_ID_KEY]
                    explain_line_areas[line_id].add(area_id)

        explain_line_areas = {area_id: list(explain_line_areas[area_id]) for area_id in explain_line_areas}

        frame.explain_message[ce.EXPLAIN_LINE_AREAS] = explain_line_areas
        frame.explain_message[ce.EXPLAIN_ENTRANCE] = [entrance_value, entrance_line, None]

        return base_func(frame, *args, **kwargs)

    return item_func


def decoration_feature_collect(base_func):
    """
        装修特征收集
        :param base_func: function, 被装饰函数
        :return: 装饰器函数
        """

    def item_func(frame, *args, **kwargs):
        logging.debug("main_func.feature_collect")

        if frame.state != ce.State.valid:
            return base_func(frame, *args, **kwargs)

        message = frame.explain_message
        label_message = frame.label_message.get("label", [])
        frame_vector = frame.vector

        kitchen_features = room_contour_lib.get_room_cluster_feature(frame.frame_id, frame_vector,
                                                                     kwargs["dec_conf"]["class_conf"])
        kitchen_feature = kitchen_features.get(ce.AreaType.kitchen.value, [{}])
        kitchen_feature = kitchen_feature[0] if kitchen_feature else {}
        toilet_feature = kitchen_features.get(ce.AreaType.toilet.value, [{}])
        toilet_feature = toilet_feature[0] if toilet_feature else {}
        real_kitchen_feature = {}
        real_toilet_feature = {}
        if kitchen_feature.get("room_label", "") == "":
            real_kitchen_feature = []
        else:
            for k in kitchen_feature:
                if k in KITCHEN_DECORATE_KEYS:
                    real_kitchen_feature[k] = kitchen_feature[k]
            real_kitchen_feature = [real_kitchen_feature]

        if toilet_feature.get("room_label", "") == "":
            real_toilet_feature = []
        else:
            for k in toilet_feature:
                if k in TOILET_DECORATE_KEYS:
                    real_toilet_feature[k] = toilet_feature[k]
            real_toilet_feature = [real_toilet_feature]

        decoration_dict = collections.defaultdict(list)

        explain_width_depth = message.get(ce.EXPLAIN_WIDTH_DEPTH, {})
        explain_wall = message.get(ce.EXPLAIN_WALL, {})
        explain_face = message.get(ce.EXPLAIN_FACE, {})
        explain_window_door = message.get(ce.EXPLAIN_WINDOW_DOOR, {})
        explain_room = message.get(ce.EXPLAIN_ROOM, {})
        explain_parlour = message.get(ce.EXPLAIN_PARLOUR, {})
        explain_kitchen = message.get(ce.EXPLAIN_KITCHEN, {})
        explain_toilet = message.get(ce.EXPLAIN_TOILET, {})

        frame_size = frame.frame_size
        room_cnt = frame.room

        with_toilet_rooms = []
        with_room_toilets = []
        for item in label_message:
            if item["type"] == ce.LABEL_DICT[ce.LABEL_BEDROOM_TOILET][0]:
                room_toilet_paires = item.get("data", [])
                for rt in room_toilet_paires:
                    if len(rt) != 2:
                        continue
                    with_toilet_rooms.append(rt[0])
                    with_room_toilets.append(rt[1])

        for plan_idx, plan_vector in enumerate(frame_vector[frame.plan_key]):
            points_dict, line_items_dict, lines_dict, areas_dict = itemgetter(*ce.DICTS)(plan_vector)

            area_inf_dict, main_room_id, sub_rooms, _, _, _, _, _, _ = message[ce.EXPLAIN_WHOLE_FRAME]
            main_room_connected_id = frame.house.get_connect_areas4area_id(main_room_id)

            toilet_cnt = area_inf_dict.get(ce.AreaType.toilet.value, [None, None])[0]
            balcony_cnt = area_inf_dict.get(ce.AreaType.balcony.value, [None, None])[0]
            parlour_cnt = area_inf_dict.get(ce.AreaType.parlour.value, [None, None])[0]
            dinning_cnt = 0
            dinning_id = []
            for area_id in areas_dict:
                if areas_dict[area_id].get(ce.AREA_TYPE_KEY, None) == ce.DINING_ROOM:
                    dinning_cnt += 1
                    dinning_id.append(area_id)
            dinning_kitchen_dis = dinning_kitchen_distance(plan_vector, explain_kitchen)
            # 逐分间
            for area_id in areas_dict:
                # 独卫跳过
                if area_id in with_room_toilets and frame.toilet > 1:
                    continue
                _, area_points, room_type, detail_type, area_size = itemgetter(*ce.IPTTS)(areas_dict[area_id])
                size_without_line = areas_dict[area_id].get("sizeWithoutLine", None)

                area_new_type = None
                with_balcony = None
                with_toilet = None
                with_cloakroom = None
                with_entrance = None
                with_dinning = None
                toilet_sep = None
                open_kitchen = None
                toilet_area_size = None
                face_entrance_dis = float("inf")
                face_ketchen_dis = float("inf")
                face_room_dis = float("inf")
                face_toilet_dis = float("inf")
                subroom_dis = None
                parlour_dis = None
                open_to_livingroom = None
                neighbor_kitchen = None
                kitchen_closed_entrance = None

                base_info = {"size": area_size, "area_id": area_id}

                if room_type == ce.AreaType.room.value:
                    if area_id == main_room_id:
                        area_new_type = ce.DecorationAreaType.main_room.value
                    else:
                        area_new_type = ce.DecorationAreaType.sub_room.value
                    room_name, room_label, face_entrance_dis, face_toilet_dis = explain_room.get(area_id,
                                                                                                 ["", 0, float("inf"),
                                                                                                  float("inf")])
                    with_balcony = True if (room_label & ce.RoomLabel.with_balcony) else False
                    with_toilet = True if (room_label & ce.RoomLabel.with_toilet) else False
                    with_cloakroom = True if (room_label & ce.RoomLabel.with_cloakroom) else False
                    neighbor_kitchen = True if (room_label & ce.RoomLabel.neighbor_kitchen) else False

                    # 卧室门开向客厅
                    try:
                        open_to_livingroom = is_open_to_livingroom(area_id, plan_vector, message)
                    except Exception as e:
                        open_to_livingroom = False
                elif room_type == ce.AreaType.parlour.value:
                    if areas_dict[area_id].get('type', None) == 2:
                        area_new_type = ce.DecorationAreaType.dinning_room.value
                    else:
                        area_new_type = ce.DecorationAreaType.parlour.value
                        with_balcony = explain_parlour.get(area_id, {}).get(ce.WITH_BALCONY, False)
                    # area_new_type = ce.DecorationAreaType.parlour.value
                    # with_balcony = explain_parlour.get(area_id, {}).get(ce.WITH_BALCONY, False)
                elif room_type == ce.AreaType.kitchen.value:
                    area_new_type = ce.DecorationAreaType.kitchen.value
                    with_balcony = explain_kitchen.get(area_id, {}).get(ce.WITH_BALCONY, False)
                    with_entrance = explain_kitchen.get(area_id, {}).get(ce.WITH_ENTRANCE, None)
                    with_dinning = explain_kitchen.get(area_id, {}).get(ce.WITH_DINNING, False)
                    open_kitchen = True if detail_type == ce.OPEN_KITCHEN_TYPE else False
                    face_toilet_dis = explain_kitchen.get(area_id, {}).get(ce.TOILET_FACE_KITCHEN, float("inf"))
                    kitchen_closed_entrance = explain_kitchen.get(area_id, {}).get(ce.WITH_ENTRANCE, float("inf"))

                elif room_type == ce.AreaType.toilet.value:
                    if area_id in main_room_connected_id:
                        area_new_type = ce.DecorationAreaType.main_toilet.value
                    else:
                        if is_parlour_toilet(area_id, frame):
                            area_new_type = ce.DecorationAreaType.parlour_toilet.value
                        else:
                            area_new_type = ce.DecorationAreaType.toilet.value
                    subroom_dis = get_toilet_subroom_dis(frame, plan_idx, area_id)
                    # room_name, room_label, face_entrance_dis, face_ketchen_dis, face_room_dis = explain_toilet.get(
                        # area_id, ["", 0])
                    # toilet_sep = True if (room_label & ce.ToiletLabel.sep) else False
                    parlour_dis = get_toilet_parlour_dis(frame, plan_idx, area_id)
                    room_name, room_label, face_entrance_dis, face_ketchen_dis, face_room_dis = explain_toilet.get(
                        area_id, ["", 0])
                    # area_new_type = ce.DecorationAreaType.toilet.value
                    # room_name, room_label, _, _ = explain_toilet.get(area_id, ["", 0])
                    toilet_sep = True if (room_label & ce.ToiletLabel.sep) else False
                    face_entrance_dis = face_entrance_dis / 1000
                if area_new_type is None:
                    continue

                norm_area_size = area_size if size_without_line is None else size_without_line
                norm_area_size = None if norm_area_size is None else norm_area_size / 1000000.
                wd_info = explain_width_depth.get(area_id, None)
                if wd_info is None:
                    width = None
                    depth = None
                else:
                    width = wd_info[1]
                    depth = wd_info[2]
                if width is not None:
                    width = width / 1000.
                if depth is not None:
                    depth = depth / 1000.
                face = explain_face.get(area_id, [None])[0]

                window_door = explain_window_door.get(area_id, None)
                if window_door is None:
                    wdf = None
                    convex = None
                else:
                    wdf = window_door[1]  # 窗地比
                    convex = window_door[4]

                wall_info = explain_wall.get(area_id, None)
                if wall_info is None:
                    max_wall_len = None
                else:
                    max_wall_len = wall_info[2]
                if max_wall_len is not None:
                    max_wall_len = max_wall_len / 1000

                for i in range(len(with_toilet_rooms)):
                    if with_toilet_rooms[i] == area_id:
                        toilet_area_size = areas_dict.get(with_room_toilets[i], {}).get(ce.AREA_SIZE_KEY, None)
                        if toilet_area_size is not None:
                            toilet_area_size = toilet_area_size / 1000000.

                short_side = min([width, depth])
                long_side = max([width, depth])
                rect_size = width * depth if width is not None and depth is not None else None
                area_info = {
                    "base_info": base_info,
                    "toilet_cnt": toilet_cnt,
                    "balcony_cnt": balcony_cnt,
                    "parlour_cnt": parlour_cnt,
                    "dinning_cnt": dinning_cnt,
                    "room": room_cnt,
                    "frame_size": frame_size,
                    "area_size": norm_area_size,
                    "rect_size": rect_size,
                    "width": width,
                    "depth": depth,
                    "face": face,
                    "face_text": FACE_MAP[face],
                    "wdf": wdf,
                    "convex": convex,
                    "with_balcony": with_balcony,
                    "with_toilet": with_toilet,
                    "with_cloakroom": with_cloakroom,
                    "max_wall_len": max_wall_len,
                    "with_entrance": with_entrance,
                    "open_kitchen": open_kitchen,
                    "with_dinning": with_dinning,
                    "toilet_sep": toilet_sep,
                    "width_ps": [] if width is None else [[p["x"], p["y"]] for p in wd_info[5]],
                    "depth_ps": [] if depth is None else [[p["x"], p["y"]] for p in wd_info[6]],
                    "toilet_area_size": toilet_area_size,
                    "face_entrance_dis": face_entrance_dis,
                    "face_ketchen_dis": face_ketchen_dis,
                    "face_room_dis": face_room_dis,
                    "face_toilet_dis": face_toilet_dis,
                    "short_side": short_side,
                    "long_side": long_side,
                    "subroom_dis": subroom_dis,
                    "dinning_kitchen_dis": dinning_kitchen_dis / 1000.0 if dinning_kitchen_dis is not None else dinning_kitchen_dis,
                    "parlour_dis": parlour_dis,
                    "open_to_livingroom": open_to_livingroom,
                    "kitchen_closed_entrance": kitchen_closed_entrance / 1000.0 if kitchen_closed_entrance is not None else kitchen_closed_entrance,
                    "neighbor_kitchen": neighbor_kitchen,
                }

                decoration_dict[area_new_type].append(area_info)
        hallway_info = get_hallway_decoration_dict(frame, decoration_dict)
        if hallway_info is None:
            decoration_dict['hallway'] = []
        else:
            decoration_dict['hallway'] = [hallway_info]
        whole_info = {}
        decoration_dict['whole'] = [whole_info]
        # 更新卫生间
        if decoration_dict.get('toilet') is None:
            decoration_dict['toilet'] = []
        for t in decoration_dict.get(ce.DecorationAreaType.main_toilet.value, []):
            decoration_dict['toilet'].append(t)
        for t in decoration_dict.get(ce.DecorationAreaType.parlour_toilet.value, []):
            decoration_dict['toilet'].append(t
                                             )
        if len(decoration_dict['toilet']) == 0:
            decoration_dict.pop(ce.DecorationAreaType.toilet.value)

        frame.explain_message["decoration_dict"] = decoration_dict
        frame.explain_message["decoration_sug_dict"] = {ce.DecorationAreaType.kitchen.value: real_kitchen_feature,
                                                        ce.DecorationAreaType.toilet.value: real_toilet_feature}

        return base_func(frame, *args, **kwargs)

    return item_func


def bigC_feature_collect(base_func):
    """
    参考自decoration_feature_collect，去掉了decoration_sug_dict
    :param base_func: function, 被装饰函数
    :return:
    """

    def item_func(frame, *args, **kwargs):
        logging.debug("main_func.feature_collect")

        if frame.state != ce.State.valid:
            return base_func(frame, *args, **kwargs)

        # 获取户型解读信息（通过前面的装饰器函数得到）
        message = frame.explain_message
        label_message = frame.label_message.get("label", [])
        frame_vector = frame.vector

        feature_dict = collections.defaultdict(list)

        # 【1】整屋基础检测点
        # 检测点需要用到的函数
        def is_label_hit(label, key):
            """判断某一标签是否命中"""
            if ce.LABEL_DICT.get(key) is None:
                raise ValueError("no this tag")
            if label & ce.LABEL_DICT[key][0] == 0:
                return False
            else:
                return True

        frame_label = frame.frame_label
        whole_info = {
            "base_info": {"size": frame.frame_size, "area_id": frame.frame_id},  # 为了和后续分间保持一致，整屋增加base_info字段
            "label": frame.frame_label,
            "area_size": frame.frame_size,
            "room": frame.room_cnt[0],
            "parlour": frame.room_cnt[1],
            "kitchen": frame.room_cnt[2],
            "toilet": frame.room_cnt[3],
            "trans_label": message[ce.EXPLAIN_WHOLE_FRAME][3],  # 通透性编码
            "north_south_trans": is_label_hit(frame_label, "north_south_trans"),  # 南北通透
            "all_south": is_label_hit(frame_label, "all_south"),  # 全南户型
            "all_window": is_label_hit(frame_label, "all_window"),  # 全明格局
            "kitchen_window": is_label_hit(frame_label, "kitchen_window"),  # 明厨
            "toilet_window": is_label_hit(frame_label, "toilet_window"),  # 明卫
            "movement_clear": is_label_hit(frame_label, "movement_clear"),  # 动静分明
            "good_active_line": is_label_hit(frame_label, "good_active_line"),  # 动线合理
            "area_logical": is_label_hit(frame_label, "area_logical"),  # 分间面积合理
            "is_square": is_label_hit(frame_label, "square"),  # 户型方正
            "kitchen_face_toilet": is_label_hit(frame_label, "kitchen_face_toilet"),  # 厨卫对门
        }

        # 【2】分间检测点
        explain_width_depth = message.get(ce.EXPLAIN_WIDTH_DEPTH, {})
        explain_wall = message.get(ce.EXPLAIN_WALL, {})
        explain_face = message.get(ce.EXPLAIN_FACE, {})
        explain_window_door = message.get(ce.EXPLAIN_WINDOW_DOOR, {})
        explain_room = message.get(ce.EXPLAIN_ROOM, {})
        explain_parlour = message.get(ce.EXPLAIN_PARLOUR, {})
        explain_kitchen = message.get(ce.EXPLAIN_KITCHEN, {})
        explain_toilet = message.get(ce.EXPLAIN_TOILET, {})

        frame_size = frame.frame_size
        room_cnt = frame.room

        with_toilet_rooms = []
        with_room_toilets = []
        for item in label_message:
            if item["type"] == ce.LABEL_DICT[ce.LABEL_BEDROOM_TOILET][0]:
                room_toilet_pairs = item.get("data", [])
                for rt in room_toilet_pairs:
                    if len(rt) != 2:
                        continue
                    with_toilet_rooms.append(rt[0])
                    with_room_toilets.append(rt[1])

        for plan_idx, plan_vector in enumerate(frame_vector[frame.plan_key]):
            points_dict, line_items_dict, lines_dict, areas_dict = itemgetter(*ce.DICTS)(plan_vector)

            area_inf_dict, main_room_id, sub_rooms, _, _, _, _, _, _ = message[ce.EXPLAIN_WHOLE_FRAME]
            main_room_connected_id = frame.house.get_connect_areas4area_id(main_room_id)

            toilet_cnt = area_inf_dict.get(ce.AreaType.toilet.value, [None, None])[0]
            balcony_cnt = area_inf_dict.get(ce.AreaType.balcony.value, [None, None])[0]
            parlour_cnt = area_inf_dict.get(ce.AreaType.parlour.value, [None, None])[0]
            dining_cnt = 0
            dining_id = []
            for area_id in areas_dict:
                if areas_dict[area_id].get(ce.AREA_TYPE_KEY, None) == ce.DINING_ROOM:
                    dining_cnt += 1
                    dining_id.append(area_id)
            dining_kitchen_dis = dinning_kitchen_distance(plan_vector, explain_kitchen)
            # 逐分间
            for area_id in areas_dict:
                # 独卫跳过
                if area_id in with_room_toilets and frame.toilet > 1:
                    continue
                _, area_points, room_type, detail_type, area_size = itemgetter(*ce.IPTTS)(areas_dict[area_id])
                size_without_line = areas_dict[area_id].get("sizeWithoutLine", None)

                area_new_type = None
                with_balcony = None
                with_toilet = None
                with_cloakroom = None
                with_entrance = None
                with_dining = None
                toilet_sep = None
                open_kitchen = None
                toilet_area_size = None
                face_entrance_dis = float("inf")
                face_kitchen_dis = float("inf")
                face_room_dis = float("inf")
                face_toilet_dis = float("inf")
                subroom_dis = None  # 注意：None<n-->True;None>n-->False;其中n可以为任意实数
                parlour_dis = None
                open_to_livingroom = None
                neighbor_kitchen = None
                kitchen_closed_entrance = None

                base_info = {"size": area_size, "area_id": area_id}

                if room_type == ce.AreaType.room.value:
                    if area_id == main_room_id:
                        area_new_type = ce.DecorationAreaType.main_room.value
                    else:
                        area_new_type = ce.DecorationAreaType.sub_room.value
                    room_name, room_label, face_entrance_dis, face_toilet_dis = explain_room.get(area_id,
                                                                                                 ["", 0, float("inf"),
                                                                                                  float("inf")])
                    with_balcony = True if (room_label & ce.RoomLabel.with_balcony) else False
                    with_toilet = True if (room_label & ce.RoomLabel.with_toilet) else False
                    with_cloakroom = True if (room_label & ce.RoomLabel.with_cloakroom) else False
                    neighbor_kitchen = True if (room_label & ce.RoomLabel.neighbor_kitchen) else False

                    # 卧室门开向客厅
                    try:
                        open_to_livingroom = is_open_to_livingroom(area_id, plan_vector, message)
                    except Exception as e:
                        open_to_livingroom = False
                elif room_type == ce.AreaType.parlour.value:
                    if areas_dict[area_id].get('type', None) == 2:
                        area_new_type = ce.DecorationAreaType.dinning_room.value
                    else:
                        area_new_type = ce.DecorationAreaType.parlour.value
                        with_balcony = explain_parlour.get(area_id, {}).get(ce.WITH_BALCONY, False)
                    # area_new_type = ce.DecorationAreaType.parlour.value
                    # with_balcony = explain_parlour.get(area_id, {}).get(ce.WITH_BALCONY, False)
                elif room_type == ce.AreaType.kitchen.value:
                    area_new_type = ce.DecorationAreaType.kitchen.value
                    with_balcony = explain_kitchen.get(area_id, {}).get(ce.WITH_BALCONY, False)
                    with_entrance = explain_kitchen.get(area_id, {}).get(ce.WITH_ENTRANCE, None)
                    with_dining = explain_kitchen.get(area_id, {}).get(ce.WITH_DINNING, False)
                    open_kitchen = True if detail_type == ce.OPEN_KITCHEN_TYPE else False
                    face_toilet_dis = explain_kitchen.get(area_id, {}).get(ce.TOILET_FACE_KITCHEN, float("inf"))
                    kitchen_closed_entrance = explain_kitchen.get(area_id, {}).get(ce.WITH_ENTRANCE, float("inf"))

                elif room_type == ce.AreaType.toilet.value:
                    if area_id in main_room_connected_id:
                        area_new_type = ce.DecorationAreaType.main_toilet.value
                    else:
                        if is_parlour_toilet(area_id, frame):
                            area_new_type = ce.DecorationAreaType.parlour_toilet.value
                        else:
                            area_new_type = ce.DecorationAreaType.toilet.value
                    subroom_dis = get_toilet_subroom_dis(frame, plan_idx, area_id)
                    parlour_dis = get_toilet_parlour_dis(frame, plan_idx, area_id)
                    room_name, room_label, face_entrance_dis, face_kitchen_dis, face_room_dis = explain_toilet.get(
                        area_id, ["", 0])
                    toilet_sep = True if (room_label & ce.ToiletLabel.sep) else False
                    face_entrance_dis = face_entrance_dis / 1000
                elif room_type == ce.AreaType.storage.value:  # 储物间
                    # 这里不需要任何操作
                    area_new_type = 'storage'

                if area_new_type is None:
                    continue

                norm_area_size = area_size if size_without_line is None else size_without_line
                norm_area_size = None if norm_area_size is None else norm_area_size / 1000000.
                wd_info = explain_width_depth.get(area_id, None)
                if wd_info is None:
                    width = None
                    depth = None
                else:
                    width = wd_info[1]
                    depth = wd_info[2]
                if width is not None:
                    width = width / 1000.
                if depth is not None:
                    depth = depth / 1000.
                face = explain_face.get(area_id, [None])[0]

                window_door = explain_window_door.get(area_id, None)
                if window_door is None:
                    wdf = None
                    convex = None
                else:
                    wdf = window_door[1]  # 窗地比
                    convex = window_door[4]

                wall_info = explain_wall.get(area_id, None)
                if wall_info is None:
                    max_wall_len = None
                else:
                    max_wall_len = wall_info[2]
                if max_wall_len is not None:
                    max_wall_len = max_wall_len / 1000

                for i in range(len(with_toilet_rooms)):
                    if with_toilet_rooms[i] == area_id:
                        toilet_area_size = areas_dict.get(with_room_toilets[i], {}).get(ce.AREA_SIZE_KEY, None)
                        toilet_area_size_without_line = areas_dict.get(with_room_toilets[i], {}).get('sizeWithoutLine', None)
                        # 优先展示不带墙体的分间面积
                        toilet_area_size = toilet_area_size if toilet_area_size_without_line is None else toilet_area_size_without_line
                        if toilet_area_size is not None:
                            toilet_area_size = toilet_area_size / 1000000.

                short_side = min([width, depth])
                long_side = max([width, depth])
                rect_size = width * depth if width is not None and depth is not None else None
                width_depth_ratio = width / depth if width is not None and depth is not None else None
                area_info = {
                    "base_info": base_info,  # 里面的area_size是带墙体面积
                    "toilet_cnt": toilet_cnt,
                    "balcony_cnt": balcony_cnt,
                    "parlour_cnt": parlour_cnt,
                    "dining_cnt": dining_cnt,
                    "room_cnt": room_cnt,
                    "frame_size": frame_size,
                    "area_size": norm_area_size,  # 有带墙体面积和不带墙体面积之分，优先展示不带墙体的面积
                    "rect_size": rect_size,
                    "width": width,
                    "depth": depth,
                    "width_depth_ratio": width_depth_ratio,  # 补充分间面宽进深比
                    "face": face,
                    "face_text": FACE_MAP[face] if face is not None else None,
                    "wdf": wdf,
                    "convex": convex,
                    "with_balcony": with_balcony,
                    "with_toilet": with_toilet,
                    "with_cloakroom": with_cloakroom,
                    "max_wall_len": max_wall_len,
                    "with_entrance": with_entrance,
                    "open_kitchen": open_kitchen,
                    "with_dining": with_dining,
                    "toilet_sep": toilet_sep,
                    "width_ps": [] if width is None else [[p["x"], p["y"]] for p in wd_info[5]],
                    "depth_ps": [] if depth is None else [[p["x"], p["y"]] for p in wd_info[6]],
                    "toilet_area_size": toilet_area_size,  # 表示当前分间内的卫生间面积，即独卫面积
                    "face_entrance_dis": face_entrance_dis,
                    "face_kitchen_dis": face_kitchen_dis,
                    "face_room_dis": face_room_dis,
                    "face_toilet_dis": face_toilet_dis,
                    "short_side": short_side,
                    "long_side": long_side,
                    "subroom_dis": subroom_dis,
                    "dining_kitchen_dis": dining_kitchen_dis / 1000.0 if dining_kitchen_dis is not None else dining_kitchen_dis,
                    "parlour_dis": parlour_dis,
                    "open_to_livingroom": open_to_livingroom,
                    "kitchen_closed_entrance": kitchen_closed_entrance / 1000.0 if kitchen_closed_entrance is not None else kitchen_closed_entrance,
                    "neighbor_kitchen": neighbor_kitchen,
                }

                feature_dict[area_new_type].append(area_info)

        # 添加门厅分间信息
        hallway_info = get_hallway_decoration_dict(frame, feature_dict)
        if hallway_info is None:
            feature_dict['hallway'] = []
        else:
            hallway_info['room_cnt'] = frame.room  # 补充字段
            feature_dict['hallway'] = [hallway_info]

        # 储物间占位
        if 'storage' not in feature_dict:
            feature_dict['storage'] = []

        # 【3】待开发检测点，按照逐个分间进行开发
        # 整屋-面宽进深合理
        whole_info['whole_width_depth'] = 0.
        width_depth_ratios = []
        for space_type in ['parlour', 'main_room', 'sub_room']:  # 如果条件要放松一点的话，可以把sub_room去掉
            for space_feature in feature_dict.get(space_type, []):
                if space_feature.get('width_depth_ratio') is not None:
                    width_depth_ratios.append(space_feature.get('width_depth_ratio'))
        if len(width_depth_ratios):
            whole_info['whole_width_depth'] = float(sum(width_depth_ratios) / float(len(width_depth_ratios)))

        # 整屋-动静分区差
        whole_info['room_neighbor_kitchen'] = False
        for space_type in ['main_room', 'sub_room']:
            for space_feature in feature_dict.get(space_type, []):
                if space_feature.get('neighbor_kitchen') is True:
                    whole_info['room_neighbor_kitchen'] = True
        # 整屋-访客动线长
        whole_info['parlour_toilet_parlour_dis'] = None  # 和parlour_dis的初始化保持一致
        for parlour_toilet_feature in feature_dict.get('parlour_toilet', []):
            whole_info['parlour_toilet_parlour_dis'] = max(whole_info['parlour_toilet_parlour_dis'],
                                                           parlour_toilet_feature.get('parlour_dis'))

        # 整屋-起居动线长
        whole_info['parlour_toilet_subroom_dis'] = None  # 和subroom_dis的初始化保持一致
        for parlour_toilet_feature in feature_dict.get('parlour_toilet', []):
            whole_info['parlour_toilet_subroom_dis'] = max(whole_info['parlour_toilet_subroom_dis'],
                                                           parlour_toilet_feature.get('subroom_dis'))

        # 整屋-卫生间对入户
        whole_info['parlour_toilet_face_entrance_dis'] = float("inf")
        for parlour_toilet_feature in feature_dict.get('parlour_toilet', []):
            whole_info['parlour_toilet_face_entrance_dis'] = min(whole_info['parlour_toilet_face_entrance_dis'],
                                                                 parlour_toilet_feature.get('face_entrance_dis'))

        # 整屋-卧室对入户门
        whole_info['main_room_face_entrance_dis'] = float('inf')
        for main_room_feature in feature_dict.get('main_room', []):
            whole_info['main_room_face_entrance_dis'] = min(whole_info['main_room_face_entrance_dis'],
                                                            main_room_feature.get('face_entrance_dis'))

        # 整屋-卧室门开向客厅
        whole_info['room_open_to_livingroom'] = False
        if whole_info['room'] > 1:
            for space_type in ['main_room', 'sub_room']:
                for space_feature in feature_dict.get(space_type, []):
                    if space_feature.get('open_to_livingroom') is True:
                        whole_info['room_open_to_livingroom'] = True

        # 整屋-卧室对卫生间
        whole_info['room_face_toilet_dis'] = float('inf')
        for space_type in ['main_room', 'sub_room']:
            for space_feature in feature_dict.get(space_type, []):
                whole_info['room_face_toilet_dis'] = min(whole_info['room_face_toilet_dis'],
                                                         space_feature.get('face_toilet_dis'))

        # 整屋-卧室比例失调
        whole_info['main_room_width_depth_ratio'] = float('inf')
        for main_room_feature in feature_dict.get('main_room', []):
            whole_info['main_room_width_depth_ratio'] = min(whole_info['main_room_width_depth_ratio'],
                                                            main_room_feature.get('width_depth_ratio'))

        # 主卧-阳台
        try:
            # 默认只有一个客卫
            parlour_toilet_area_size = feature_dict['parlour_toilet'][0]['area_size']
        except Exception as e:  # KeyError, IndexError
            parlour_toilet_area_size = None
        for main_room_feature in feature_dict.get('main_room', []):
            main_room_feature['parlour_toilet_area_size'] = parlour_toilet_area_size

        # 客厅-餐厅有无独立就餐区
        try:
            kitchen_width_dining = feature_dict['kitchen'][0]['with_dining']
        except Exception as e:  # KeyError, IndexError
            kitchen_width_dining = False
        for parlour_feature in feature_dict.get('parlour', []):
            parlour_feature['kitchen_with_dining'] = kitchen_width_dining

        # 结果拼接
        feature_dict['whole'] = [whole_info]
        frame.explain_message["feature_dict"] = feature_dict

        return base_func(frame, *args, **kwargs)

    return item_func


def get_toilet_parlour_dis(frame, plan_id, toilet_id):
    toilet_parlour_door = frame.house.floorplans[plan_id].get_connected_parlour_door(toilet_id)
    if toilet_parlour_door is None:
        return None
    toilet_door_cen = toilet_parlour_door.segment2d.midpoint
    parlour_dis = 0
    # TODO: 没有考虑多层
    for living in frame.house.res_dict['livingroom']:
        contours = living['space_analysis']['contours']
        poly = Polygon(*[p for p in contours])
        center = poly.centroid
        dis = toilet_door_cen.manhattan_distance(center)
        if dis > parlour_dis:
            parlour_dis = dis

    return parlour_dis / 1000


def get_toilet_subroom_dis(frame, plan_id, toilet_id):
    """卫生间门到次卧门的曼哈顿距离"""
    toilet_parlour_door = frame.house.floorplans[plan_id].get_connected_parlour_door(toilet_id)
    if toilet_parlour_door is None:
        return None
    area_inf_dict, main_room_id, sub_rooms, _, _, _, _, _, _ = frame.explain_message[ce.EXPLAIN_WHOLE_FRAME]
    toilet_door_cen = toilet_parlour_door.segment2d.midpoint
    sub_room_dis = 0
    for sub_room in sub_rooms:
        sub_id = sub_room[0]
        sub_room_door = frame.house.floorplans[plan_id].get_connected_parlour_door(sub_id)
        if sub_room_door is None:
            dis = 0
        else:
            sub_door_cen = sub_room_door.segment2d.midpoint
            dis = sub_door_cen.manhattan_distance(toilet_door_cen)
        if dis > sub_room_dis:
            sub_room_dis = dis
    return sub_room_dis / 1000


def is_parlour_toilet(area_id, frame):
    connected_id = frame.house.get_connect_areas4area_id(area_id)
    for conn in connected_id:
        for fp in frame.house.floorplans:
            if conn not in fp.id_regions:
                continue
            roomType = fp.id_regions[conn]._roomType
            if roomType == ce.AreaType.other.value or roomType == ce.AreaType.parlour.value:
                return True
    return False


def is_open_to_livingroom(area_id, plan_vector, message):
    # 卧室门开向客厅
    points_dict, line_items_dict, lines_dict, areas_dict = itemgetter(*ce.DICTS)(plan_vector)
    explain_width_depth = message.get(ce.EXPLAIN_WIDTH_DEPTH, {})
    explain_parlour = message.get(ce.EXPLAIN_PARLOUR, {})
    open_to_livingroom = False
    for attach in areas_dict[area_id].get(ce.AREA_ATTACHMENTS_KEY, {}).get(ce.ATTACH_AREAS_KEY, []):
        if attach.get(ce.SHARED_LINE_ITEMS_KEY, []) and attach.get(ce.ATTACH_AREA_ROOM_TYPE_KEY,
                                                                   {}) == ce.AreaType.parlour.value:
            for item_id in attach[ce.SHARED_LINE_ITEMS_KEY]:
                if line_items_dict.get(item_id, {}).get(ce.TYPE_IS_KEY, {}) == ce.IS_DOOR:
                    door_pt1 = line_items_dict[item_id]["startPointAt"]
                    door_pt2 = line_items_dict[item_id]["endPointAt"]

                    parlour_id = explain_parlour.keys()[0]
                    parlour_wd = explain_width_depth.get(parlour_id)
                    if parlour_wd[5] is None or parlour_wd[6] is None:
                        continue
                    parlour_rect = [
                        min(parlour_wd[5][0]['x'], parlour_wd[5][1]['x'], parlour_wd[6][0]['x'],
                            parlour_wd[6][1]['x']),
                        min(parlour_wd[5][0]['y'], parlour_wd[5][1]['y'], parlour_wd[6][0]['y'],
                            parlour_wd[6][1]['y']),
                        max(parlour_wd[5][0]['x'], parlour_wd[5][1]['x'], parlour_wd[6][0]['x'],
                            parlour_wd[6][1]['x']),
                        max(parlour_wd[5][0]['y'], parlour_wd[5][1]['y'], parlour_wd[6][0]['y'],
                            parlour_wd[6][1]['y'])]
                    if parlour_rect[0] <= door_pt1['x'] <= parlour_rect[2] \
                            and parlour_rect[1] <= door_pt1['y'] <= parlour_rect[3] \
                            and parlour_rect[0] <= door_pt2['x'] <= parlour_rect[2] \
                            and parlour_rect[1] <= door_pt2['y'] <= parlour_rect[3]:
                        open_to_livingroom = True
    return open_to_livingroom


def dinning_kitchen_distance(plan_vector, explain_kitchen):
    distance = None
    for kit_id in explain_kitchen:
        if explain_kitchen.get(kit_id, {}).get(ce.WITH_DINNING, False):
            return 0.0
    dinning_tabel = []
    kitchen_table = []
    kitchen_door = []
    for item in plan_vector.get("items", []):
        if item.get('type', None) in [3, 63, 72, 74]:  # 餐桌
            dinning_tabel = [item['x'], item['y']]
        if item.get('type', None) in [2, 14, 15, 23]:  # 橱柜
            kitchen_table = [item['x'], item['y']]
    for area in plan_vector['areas']:
        if area['type'] == 8:  # 封闭厨房
            for atarea in area['attachments']['areas']:
                if atarea['type'] in (1, 2, 23):
                    for litem_id in atarea['sharedLineItems']:
                        litem = plan_vector['line_items_dict'].get(litem_id)
                        if litem['is'] == 'door':
                            kitchen_door = [(litem['startPointAt']['x'] + litem['endPointAt']['x']) / 2,
                                            (litem['startPointAt']['y'] + litem['endPointAt']['y']) / 2]
    if dinning_tabel and kitchen_door:
        distance = abs(kitchen_door[0] - dinning_tabel[0]) + abs(kitchen_door[1] - dinning_tabel[1])
    elif dinning_tabel and kitchen_table:
        distance = abs(kitchen_table[0] - dinning_tabel[0]) + abs(kitchen_table[1] - dinning_tabel[1])
    return distance


def get_hallway_decoration_dict(frame, decoration_dict):
    if len(frame.house.res_dict['hallway']) == 0:
        return None
    res_dict = frame.house.res_dict['hallway'][0]
    area_size = res_dict['space_analysis']['width'] / 1000 * res_dict['space_analysis']['depth'] / 1000
    base_info = {"size": area_size * 1000 * 1000, "area_id": "hallway"}
    r_or_l_1 = 0
    # if res_dict['space_analysis']['right_label'] == 1 or res_dict['space_analysis']['left_label'] == 1:
    #     r_or_l_1 = 1
    if len(res_dict['right_vertical_lay']) > 0 or len(res_dict['left_vertical_lay']) > 0:
        r_or_l_1 = 1
    hallway_info = {
        "base_info": base_info,
        "area_size": area_size,
        "width": res_dict['space_analysis']['width'] / 1000,
        "depth": res_dict['space_analysis']['depth'] / 1000,
        "right_label": res_dict['space_analysis']['right_label'],
        "left_label": res_dict['space_analysis']['left_label'],
        "face_wall": 0 if len(res_dict['face_lay']) == 0 else 1,
        "room": frame.room,
        "r_or_l_1": r_or_l_1,
        "right_vertical_lay_num": len(res_dict['right_vertical_lay']),
        "left_vertical_lay_num": len(res_dict['left_vertical_lay']),
        "right_side_lay_num": len(res_dict['right_side_lay']),
        "left_side_lay_num": len(res_dict['left_side_lay']),
        "face_lay_num": len(res_dict['face_lay']),
        "right_vertical_lay_depth": res_dict['right_vertical_lay'][0].depth if len(
            res_dict['right_vertical_lay']) > 0 else 0,
        "left_vertical_lay_depth": res_dict['left_vertical_lay'][0].depth if len(
            res_dict['left_vertical_lay']) > 0 else 0,
        "frame_size": frame.frame_size
    }
    return hallway_info


def feature_collect(base_func):
    """
        户型解读数据结构准备
        :param base_func: function, 被装饰函数
        :return: 装饰器函数
        """

    def item_func(frame, *args, **kwargs):
        logging.debug("main_func.feature_collect")

        if frame.state != ce.State.valid:
            return base_func(frame, *args, **kwargs)

        message = frame.explain_message

        collect_features = {}

        frame_vector = frame.vector
        ting_info = [None, None]
        chu_info = [None, None]
        wei_info = []

        for plan_vector in frame_vector[frame.plan_key]:
            points_dict, line_items_dict, lines_dict, areas_dict = itemgetter(*ce.DICTS)(plan_vector)

            # 逐分间
            for area_id in areas_dict:
                _, area_points, room_type, detail_type, area_size = itemgetter(*ce.IPTTS)(areas_dict[area_id])
                norm_area_size = area_size / 1000000.
                # 有独立餐厅
                if detail_type in ce.REAL_PARLOUR:
                    if norm_area_size > ting_info[1] or ting_info[1] is None:
                        ting_info = [area_id, norm_area_size]
                elif room_type == ce.AreaType.kitchen.value:
                    if norm_area_size > chu_info[1] or chu_info[1] is None:
                        chu_info = [area_id, norm_area_size]
                elif room_type == ce.AreaType.toilet.value:
                    wei_info.append([area_id, area_size])

        # name, width, depth, width_div_depth
        explain_width_depth = message.get(ce.EXPLAIN_WIDTH_DEPTH, {})
        # area_size, gray_size, door_size
        explain_size = message.get(ce.EXPLAIN_SIZE, {})
        # expand_points, oblique_flag, max_line, line_info_lst, entrance_vector
        explain_wall = message.get(ce.EXPLAIN_WALL, {})
        # all_window_len, w_div_floor, faces, main_face, convex_window
        explain_window_door = message.get(ce.EXPLAIN_WINDOW_DOOR, {})
        # name, ToiletLabel
        explain_toilet = message.get(ce.EXPLAIN_TOILET, {})
        # name, RoomLabel
        explain_room = message.get(ce.EXPLAIN_ROOM, {})
        # FramePLabel
        explain_frame = message.get(ce.EXPLAIN_FRAME, 0)
        # main_face, main_face_len, face_dict
        explain_face = message.get(ce.EXPLAIN_FACE, {})
        # ### explain_whole_frame
        # area_inf_dict, main_room_id, sub_rooms, trans_flag, face_flag, frame_rec, surround_sub_room_cnt
        explain_whole_frame = message.get(ce.EXPLAIN_WHOLE_FRAME, [{}, None, [], 0, 0, True, -1, 0.])

        area_inf_dict, main_room_id, sub_rooms, trans_flag, face_flag, frame_rec, surround_sub_room_cnt, _, _ = explain_whole_frame

        room_concave_cnts = []

        for room_id in explain_room:
            ps_lst = explain_wall.get(room_id, [[], False, 0., [], None])[0]
            concave_cnt = sum([1 for p in ps_lst if p[ce.CKEY_POINT_TYPE] & ce.PointType.concave])
            room_concave_cnts.append(concave_cnt)

        # 功能区面积占比
        size_ratio = []
        for area_type in [ce.AreaType.room.value, ce.AreaType.parlour.value, ce.AreaType.kitchen.value]:
            item_ratio = None
            if area_type in area_inf_dict:
                area_cnt, sum_size = area_inf_dict[area_type]
                if area_cnt > 0:
                    item_ratio = sum_size / max(1., frame.frame_size) / 1000000.
            size_ratio.append(item_ratio)
        logging.debug(size_ratio)

        collect_features["size_ratio"] = size_ratio

        collect_features["main_room"] = [
            # 面积
            explain_size.get(main_room_id, [0, 0, 0])[0] / 1000000.,
            # 窗地比
            explain_window_door.get(main_room_id, [0, 0, [], '', False])[1]
        ]
        if sub_rooms:
            collect_features["sub_room"] = [
                [explain_size.get(r[0], [0, 0, 0])[0] / 1000000. for r in sub_rooms],
                [explain_window_door.get(r[0], [0, 0, [], '', False])[1] for r in sub_rooms]
            ]
        else:
            collect_features["sub_room"] = [None, None]

        collect_features["room"] = [
            # RoomLabel
            [explain_room[room_id][1] for room_id in explain_room],
            # 凸窗
            [explain_window_door.get(room_id, [0, 0, [], '', False])[4] for room_id in explain_room],
            # 面宽进深比
            [explain_width_depth.get(room_id, ['', 0, 0, 0])[3] for room_id in explain_room],
            # 凹点
            room_concave_cnts,
            # 灰区面积
            [explain_size[room_id][1] / 1000000. for room_id in explain_room],
        ]

        collect_features["parlour"] = [
            # 窗地比
            explain_window_door.get(ting_info[0], [0, None, [], '', False])[1],
            # 最长连续墙体长度
            explain_wall.get(ting_info[0], [[], False, 0., [], None])[2] / 1000.,
            # 凸窗
            explain_window_door.get(ting_info[0], [0, 0, [], '', False])[4],
            # 面宽进深比
            explain_width_depth.get(ting_info[0], ['', 0, 0, 0])[3],
            # 最大厅面积
            ting_info[1]
        ]

        collect_features["kitchen"] = [
            # 面宽
            explain_width_depth.get(chu_info[0], [None, None, None, None])[1],
            # 进深
            explain_width_depth.get(chu_info[0], [None, None, None, None])[2],
            # 面积
            chu_info[1],
            # 窗地比
            explain_window_door.get(chu_info[0], [None, None, None, None, None])[1]
        ]

        if wei_info:
            collect_features["toilet"] = [
                # 面积
                max([explain_size.get(toilet[0], [0, 0, 0])[0] for toilet in wei_info] + [0.]),
                # ToiletLabel
                [explain_toilet.get(toilet[0], ['', 0, float("inf"), float("inf")])[1] for toilet in wei_info],
                # 采光宽度
                [max([t[0] for t in explain_face.get(toilet[0], ['', 0, {}])[2].values()] + [0.]) for toilet in
                 wei_info],
                # face entrance dist
                [explain_toilet.get(toilet[0], ['', 0, float("inf"), float("inf")])[2] / 1000. for toilet in wei_info],
                # face kitchen
                [explain_toilet.get(toilet[0], ['', 0, float("inf"), float("inf")])[3] for toilet in wei_info],
            ]
        else:
            collect_features["toilet"] = [None, None, None, None, None]

        frame.explain_message["collect_features"] = collect_features

        return base_func(frame, *args, **kwargs)

    return item_func


def base_vars(base_func):
    """
    户型解读基础变量
    :param base_func: function, 被装饰函数
    :return: 装饰器函数
    """

    def item_func(frame, *args, **kwargs):
        logging.debug("main_func.frame_prepare")

        if frame.state != ce.State.valid:
            return base_func(frame, *args, **kwargs)
        frame_label = frame.frame_label
        label_factory = entity.Label()
        explain_vars = {}
        wall_dict = frame.explain_message.get(ce.EXPLAIN_WALL, {})
        room_label_dict = frame.explain_message[ce.EXPLAIN_ROOM]
        explain_width_depth = frame.explain_message[ce.EXPLAIN_WIDTH_DEPTH]
        oblique_rooms = []
        add_room_types = set()
        add_area = 0.
        room_toilet_storage = []
        room_toilet = []
        room_storage = []

        frame_vector = frame.vector
        rooms_size = 0.
        wd_cnt = 0
        deep_depth_areas = []
        for plan_vector in frame_vector[frame.plan_key]:
            points_dict, line_items_dict, lines_dict, areas_dict = itemgetter(*ce.DICTS)(plan_vector)

            # 逐分间
            for area_id in areas_dict:
                room_name = areas_dict[area_id][ce.AREA_ROOM_NAME_KEY]
                _, area_points, room_type, detail_type, area_size = itemgetter(*ce.IPTTS)(areas_dict[area_id])
                wall_info = wall_dict.get(area_id, None)
                if wall_info is not None:
                    if wall_info[1] is True:
                        oblique_rooms.append(room_name)
                if room_type in {ce.AreaType.garden.value, ce.AreaType.loft.value, ce.AreaType.terrace.value}:
                    add_room_types.add(room_type)
                    add_area += (area_size / 1000000.)

                if area_id in room_label_dict:
                    room_label = room_label_dict[area_id][1]
                    if (room_label ^ (ce.RoomLabel.with_toilet | ce.RoomLabel.with_cloakroom)) == 0:
                        room_toilet_storage.append(room_name)
                    elif room_label & ce.RoomLabel.with_toilet:
                        room_toilet.append(room_name)
                    elif room_label & ce.RoomLabel.with_cloakroom:
                        room_storage.append(room_name)
                if room_type in {ce.AreaType.room.value, ce.AreaType.babysitter.value}:
                    rooms_size += area_size / 1000000.

                if room_type in {ce.AreaType.parlour.value, ce.AreaType.room.value}:
                    wd_cnt += 1
                    # 进深/面宽 大于等于 2:1
                    if explain_width_depth[area_id][3] <= 0.5:
                        deep_depth_areas.append(room_name)

        add_room_types_lst = []
        for rt in add_room_types:
            if rt == ce.AreaType.garden.value:
                add_room_types_lst.append(u"花园")
            if rt == ce.AreaType.loft.value:
                add_room_types_lst.append(u"阁楼")
            if rt == ce.AreaType.terrace.value:
                add_room_types_lst.append(u"露台")

        kitchen_w = frame.explain_message["collect_features"]["kitchen"][0]
        kitchen_table_cnt = None
        if kitchen_w is not None:
            kitchen_w /= 1000.
            if kitchen_w > 1.9:
                kitchen_table_cnt = u"两侧双"
            elif kitchen_w > 1.5:
                kitchen_table_cnt = u"单侧"

        trance_type = None
        trans_label = frame.explain_message[ce.EXPLAIN_WHOLE_FRAME][3]
        for label, tt in zip([1, 2, 4], [u"对侧", u"邻侧", u"单侧"]):
            if label & trans_label:
                trance_type = tt
                break

        total_face = None
        face_label = frame.explain_message[ce.EXPLAIN_WHOLE_FRAME][4]
        for label, ft in zip([1, 2, 4, 8, 16], [u"南北", u"南", u"东", u"西", u"北"]):
            if label & face_label:
                total_face = ft
                break

        rooms_ratio = frame.explain_message["collect_features"]["size_ratio"][0]
        if rooms_ratio is not None:
            rooms_ratio = rooms_ratio * 100.

        main_room = frame.explain_message["collect_features"]["main_room"][0]

        main_parlour_size = frame.explain_message["collect_features"]["parlour"][4]

        kitchen_size = frame.explain_message["collect_features"]["kitchen"][2]

        max_toilet_size = frame.explain_message["collect_features"]["toilet"][0]
        if max_toilet_size is not None:
            max_toilet_size /= 1000000.
        toilet_items = None
        for th, items in zip([2.5, 2, 1.8, 1.1], [u"便器、洗浴器、洗面器三件", u"洗浴器和便器或洗浴器和洗面器", u"洗面器和便器", u"单便器"]):
            if max_toilet_size is not None and max_toilet_size >= th:
                toilet_items = items
                break

        explain_vars["oblique_rooms"] = u",".join(oblique_rooms)
        explain_vars["add_room_types"] = u",".join(add_room_types_lst)
        explain_vars["add_area"] = add_area
        explain_vars["room_toilet_storage"] = u",".join(room_toilet_storage)
        explain_vars["room_toilet"] = u",".join(room_toilet)
        explain_vars["room_storage"] = u",".join(room_storage)
        explain_vars["frame_size"] = frame.frame_size
        explain_vars["room_cnt"] = frame.room
        explain_vars["rooms_size"] = rooms_size
        explain_vars["rooms_ratio"] = rooms_ratio
        explain_vars["main_room"] = main_room
        explain_vars["main_parlour_size"] = main_parlour_size
        explain_vars["kitchen_size"] = kitchen_size
        explain_vars["kitchen_w"] = kitchen_w
        explain_vars["kitchen_table_cnt"] = kitchen_table_cnt
        explain_vars["max_toilet_size"] = max_toilet_size
        explain_vars["toilet_items"] = toilet_items
        explain_vars["trance_type"] = trance_type
        explain_vars["total_face"] = total_face
        explain_vars["wd_cnt"] = wd_cnt
        explain_vars["deep_depth_areas"] = ",".join(deep_depth_areas)
        frame_labels_set = set(label_factory.code2lst(frame_label)[1])
        explain_vars["frame_label_advantage"] = ",".join(list(frame_labels_set - {'厨卫对门'}))
        frame_lack_labels_set = set(label_factory.code2lst(~frame_label)[1])
        sub_set = {'采光好', '户型利用率高', '风水好', '动线合理'}
        if '厨卫对门' in frame_labels_set:
            frame_lack_labels_set.add('厨卫对门')
        explain_vars["frame_label_disadvantage"] = ",".join(list(frame_lack_labels_set - sub_set))
        explain_vars["room_french_window"] = u"，".join(frame.explain_message["french_window_areas"])

        areas_dict = {}
        for plan_vector in frame_vector[frame.plan_key]:
            areas_dict.update(plan_vector[ce.AREAS_DICT_KEY])

        explain_vars["face_vectors"] = get_face_vectors(frame, areas_dict)
        wd_vectors_lst = []
        wd_vectors = get_width_depth_vector(frame, areas_dict)
        for plan_wd_dict in wd_vectors:
            wd_vectors_lst.append([plan_wd_dict[x] for x in plan_wd_dict])
        explain_vars["wd_vectors"] = wd_vectors_lst
        explain_vars["wd_vector_dict"] = wd_vectors
        explain_vars["quiet_areas"] = frame.explain_message[ce.EXPLAIN_QUIET_ROOMS][0]
        explain_vars["moving_areas"] = frame.explain_message[ce.EXPLAIN_MOVING_ROOMS][0]

        frame.explain_message[ce.EXPLAIN_VARS] = explain_vars
        return base_func(frame, *args, **kwargs)

    return item_func


def get_width_depth_vector(frame, areas_dict):
    # 面宽进深
    width_depth = frame.explain_message[ce.EXPLAIN_WIDTH_DEPTH]
    wd_vectors = []
    frame_vector = frame.vector
    for plan_vector in frame_vector[frame.plan_key]:
        areas = plan_vector[ce.PLAN_AREAS_KEY]
        floor_vectors = dict()
        # 逐分间
        for area in areas:
            area_id = area[ce.AREA_ID_KEY]
            if areas_dict.get(area_id, {}).get(ce.AREA_ROOM_TYPE_KEY, "") not in {ce.AreaType.room.value,
                                                                                  ce.AreaType.parlour.value}:
                continue
            wd_info = width_depth[area_id]
            area_name, width_len, real_depth, wd_r, size_diff, w, real_depth_info = wd_info
            if real_depth_info is None:
                continue
            angle = geometry_lib.line_angle(w, [{ce.X: 0, ce.Y: 0}, {ce.X: 100, ce.Y: 0}])
            # 面宽进深过小，或者倾斜角度超过10度不展示
            if width_len < 200 or real_depth < 200 or (0.17 < angle < 0.98):
                continue
            d = real_depth_info
            floor_vectors[area_id] = [w, d]
        wd_vectors.append(floor_vectors)

    return wd_vectors


def get_face_vectors(frame, areas_dict):
    # 采光
    explain_face = frame.explain_message[ce.EXPLAIN_FACE]
    light_vectors = []

    frame_vector = frame.vector
    for plan_vector in frame_vector[frame.plan_key]:
        areas = plan_vector[ce.PLAN_AREAS_KEY]
        floor_vectors = []
        # 逐分间
        for area in areas:
            area_id = area[ce.AREA_ID_KEY]
            area_type = areas_dict[area_id][ce.AREA_ROOM_TYPE_KEY]
            if area_type in {ce.AreaType.garden.value, ce.AreaType.terrace.value}:
                continue
            face_dict = explain_face[area_id][2]
            for direction in face_dict:
                line_info_lst = face_dict[direction][1]
                for item in line_info_lst:
                    norm_lines = item[2]
                    if item[3] == 0 or norm_lines is None:
                        continue
                    floor_vectors.append([norm_lines[0][0], norm_lines[0][1]])
        light_vectors.append(floor_vectors)
    return light_vectors


def point_value_collect(base_func):
    """
    检测点统计
    :param base_func: 装饰的方法
    :return: item_func
    """

    def item_func(frame, *args, **kwargs):
        logging.debug("eval_main.point_value_collect")
        point_value_dict = collections.defaultdict(dict)
        frame.explain_message[ce.EXPLAIN_POINT_VALUE_DICT] = point_value_dict
        if frame.state != ce.State.valid:
            return base_func(frame, *args, **kwargs)

        check_point_dict = kwargs.get("check_point", None)
        if check_point_dict is None:
            logging.error("lack 'check_point' config for evaluating")
            sys.exit(-1)

        message = frame.explain_message

        for dim in check_point_dict:
            for p in check_point_dict[dim]:
                value_path = check_point_dict[dim][p]
                if not value_path:
                    continue
                real_value = get_real_value(message, value_path)
                point_value_dict[dim].update({p: real_value})
        frame.explain_message[ce.EXPLAIN_POINT_VALUE_DICT] = point_value_dict
        return base_func(frame, *args, **kwargs)

    return item_func


def liner_worker(base_func):
    """
    动线和可视域计算
    :param base_func: 装饰的方法
    :return: item_func
    :return:
    """

    def item_func(frame, *args, **kwargs):
        logging.debug("eval_main.liner_worker")

        ret_dict_lst = []  # None
        v_dict_lst = []  # {"area_ratio_o": None}

        frame.explain_message[ce.EXPLAIN_VISUAL] = v_dict_lst
        frame.explain_message[ce.EXPLAIN_LINER] = ret_dict_lst

        frame.explain_message[ce.EXPLAIN_REAL_VISUAL] = {"area_ratio_o": None}
        frame.explain_message[ce.EXPLAIN_REAL_LINER] = {"cross_cnt": None}

        if frame.state != ce.State.valid:
            return base_func(frame, *args, **kwargs)

        # 动线和可视域
        liners_feature = liner_lib.line_feature_extractor(frame, kwargs.get("line_param"))
        # print("{} liners_feature".format(frame.frame_id))
        if liners_feature[liner_lib.ERROR] != mod_util.ErrorCode.ok:
            frame._state = ce.State.liner_error
            logging.error("{} liner_failed".format(frame.frame_id))
            return base_func(frame, *args, **kwargs)

        try:
            for liner in liners_feature["liners"]:
                if liner is None:
                    v_dict_lst.append({})
                    ret_dict_lst.append({})
                else:
                    v_dict = {}
                    ret_dict = liner_lib.line_maker(liner)
                    # print("{} line_maker".format(frame.frame_id))
                    area_ratio_o, pts_polygon_o, area_ratio_c, pts_polygon_c = liner_lib.entrance_visual_area(liner)
                    # print("{} visual area".format(frame.frame_id))
                    edge_len = liner.edge_len
                    v_dict["edge_len"] = edge_len
                    v_dict["area_ratio_o"] = area_ratio_o
                    v_dict["pts_polygon_o"] = pts_polygon_o
                    v_dict["area_ratio_c"] = area_ratio_c
                    v_dict["pts_polygon_c"] = pts_polygon_c

                    v_dict_lst.append(v_dict)
                    ret_dict_lst.append(ret_dict)

                    frame.explain_message[ce.EXPLAIN_REAL_VISUAL] = v_dict
                    frame.explain_message[ce.EXPLAIN_REAL_LINER] = ret_dict
        except Exception as e:
            logging.error(e)
            traceback.print_exc()
            frame._state = ce.State.liner_error
            logging.error("{} liner_failed with exception".format(frame.frame_id))
        if frame.state == ce.State.liner_error or ret_dict_lst is None:
            return base_func(frame, *args, **kwargs)

        # 动线相交类型数量
        cross_cnt = 0
        for ret_dict in ret_dict_lst:
            if ret_dict.get("living_guest_cross", None) is None:
                ret_dict["cross_cnt"] = -1
                continue

            for cross_type in ["living_guest_cross", "work_guest_cross", "living_work_cross"]:
                if ret_dict.get(cross_type, '0') != '0':
                    cross_cnt += 1
            ret_dict["cross_cnt"] = cross_cnt

        frame.explain_message[ce.EXPLAIN_VISUAL] = v_dict_lst
        frame.explain_message[ce.EXPLAIN_LINER] = ret_dict_lst

        return base_func(frame, *args, **kwargs)

    return item_func


@frame_prepare
@eval_general.area_wall
@eval_general.width_depth_face
@eval_general.area_size
@eval_general.window_door
@eval_single.single_general
@eval_global.v1
@feature_collect
@point_value_collect
@base_vars
def base_explain(frame, *args, **kwargs):
    """
    户型解读基础特征主函数，使用装饰器模式进行户型解读功能扩展
    :param frame: lib.entity.Frame 户型对象
    :param args: 定位参数
    :param kwargs: 仅限关键字参数
    :return: None
    """
    logging.debug("base_explain")
    # logging.debug(frame.explain_message)


@frame_prepare
@eval_general.area_wall
@eval_general.width_depth_face
@eval_general.area_size
@eval_general.window_door
@eval_single.single_general
@eval_global.v1
@decoration_feature_collect
def decoration_explain(frame, *args, **kwargs):
    """
    装修建议任务
    :param frame: lib.entity.Frame 户型对象
    :param args: 定位参数
    :param kwargs: 仅限关键字参数
    :return: None
    """
    logging.debug("decoration_explain")
    # logging.debug(frame.explain_message)


@frame_prepare  # explain_line_areas, explain_entrance
@eval_general.area_wall  # explain_wall
@eval_general.width_depth_face  # explain_width_depth, explain_face
@eval_general.area_size  # explain_size
@eval_general.window_door  # explain_window_door
@eval_single.single_general  # 分间解读，包括：toilet,room,kitchen,parlour,frame,french_window_areas,kitchen_closed_entrance
@eval_global.v1  # whole_frame
@eval_global.v1_bigC  # 主卧逻辑判定修改
@bigC_feature_collect
def bigC_explain(frame, *args, **kwargs):
    """
    大C装修解读任务
    :param frame: lib.entity.Frame 户型对象
    :param args: 定位参数
    :param kwargs: 仅限关键字参数
    :return:
    """
    logging.debug("bigC_explain")


@liner_worker
@point_value_collect
def liner_explain(frame, *args, **kwargs):
    """
    户型解读基础特征主函数，使用装饰器模式进行户型解读功能扩展
    :param frame: lib.entity.Frame 户型对象
    :param args: 定位参数
    :param kwargs: 仅限关键字参数
    :return: None
    """
    logging.debug("line_explain")
    # logging.debug(frame.explain_message)
