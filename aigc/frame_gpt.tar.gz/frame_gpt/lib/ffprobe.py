# -*- coding: utf-8 -*-
# ===============================================================
#
#    Copyright (C) 2020 Beike, Inc. All Rights Reserved.
#
#    @Create Author : gaixindong (gaixindong@ke.com)
#    @Create Time   : 2020/7/20 18:15
#    @Description   : ffprobe相关命令
#
# ===============================================================


import ast
import subprocess

from lib import errors
# from utils import common_util


def _run_ffprobe(ffprobe_cmd):
    """
    运行ffprobe命令

    Args:
        ffprobe_cmd (str): 命令

    Returns:
        命令返回结果
    """
    # chosen_logger = common_util.choose_logger()
    # chosen_logger.debug(f'ffprobe cmd: {ffprobe_cmd}')
    res = subprocess.run(ffprobe_cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if res.returncode != 0:
        # chosen_logger.error(f'stdout: {res.stdout}')
        # chosen_logger.error(f'stderr: {res.stderr}')
        raise errors.FFmpegError('something wrong when run ffprobe cmd')
    return res.stdout.decode().strip()


def video_info(video):
    """
    获取视频信息

    Args:
        video (str): 视频文件路径

    Returns:
        视频信息
    """
    cmd = f'ffprobe -loglevel error ' \
          f'-show_format -show_streams ' \
          f'-print_format json "{video}"'
    video_info = ast.literal_eval(_run_ffprobe(cmd))
    return video_info


def video_duration(video):
    """
    获取第一个视频流的时长

    Args:
        video (str): 视频文件路径

    Returns:
        视频时长
    """
    cmd = f'ffprobe -loglevel error ' \
          f'-select_streams v:0 -show_entries format=duration ' \
          f'-print_format default=noprint_wrappers=1:nokey=1 "{video}"'
    video_duration = ast.literal_eval(_run_ffprobe(cmd))
    return video_duration


def video_resolution(video):
    """
    获取视频分辨率

    Args:
        video (str): 视频文件路径

    Returns:
        视频分辨率
    """
    cmd = f'ffprobe -loglevel error ' \
          f'-select_streams v:0 -show_entries stream=width,height ' \
          f'-print_format json "{video}"'
    resolution_info = ast.literal_eval(_run_ffprobe(cmd))
    width = resolution_info['streams'][0]['width']
    height = resolution_info['streams'][0]['height']
    return width, height


def video_fps(video):
    """
    获取视频帧率

    Args:
        video (str): 视频文件路径

    Returns:
        视频fps
    """
    cmd = f'ffprobe -loglevel error ' \
          f'-select_streams v:0 -show_entries stream=r_frame_rate ' \
          f'-print_format default=noprint_wrappers=1:nokey=1 "{video}"'
    frames_and_seconds = _run_ffprobe(cmd).split('/')
    fps = int(frames_and_seconds[0]) / int(frames_and_seconds[1])
    return fps


def video_sar(video):
    """
    获取视频sar（采样纵横比）

    Args:
        video (str): 视频文件路径

    Returns:
        视频sar
    """
    cmd = f'ffprobe -loglevel error ' \
          f'-select_streams v:0 -show_entries stream=sample_aspect_ratio ' \
          f'-print_format default=noprint_wrappers=1:nokey=1 "{video}"'
    sample_aspect_ratio = _run_ffprobe(cmd)
    return sample_aspect_ratio


def audio_duration(audio):
    """
    获取第一个音频流的时长

    Args:
        audio (str): 音频文件路径

    Returns:
        音频时长
    """
    cmd = f'ffprobe -loglevel error ' \
          f'-select_streams a:0 -show_entries stream=duration ' \
          f'-print_format default=noprint_wrappers=1:nokey=1 "{audio}"'
    audio_duration = ast.literal_eval(_run_ffprobe(cmd))
    return audio_duration


def contain_audio(video):
    """
    判断视频是否包含音频流

    Args:
        video (str): 视频文件路径

    Returns:
        包含返回True，否则返回False
    """
    cmd = f'ffprobe -loglevel error ' \
          f'-select_streams a:0 -show_streams ' \
          f'-print_format default=noprint_wrappers=1:nokey=1 "{video}"'
    if _run_ffprobe(cmd):  # 包含音频流则输出信息不为空
        return True
    return False


def video_size(video):
    """
    获取视频流的大小

    Args:
        video (str): 视频文件路径

    Returns:
        视频大小（单位：字节）
    """
    cmd = f'ffprobe -loglevel error ' \
          f'-select_streams v:0 -show_entries format=size ' \
          f'-print_format default=noprint_wrappers=1:nokey=1 "{video}"'
    video_size = ast.literal_eval(_run_ffprobe(cmd))
    return video_size
