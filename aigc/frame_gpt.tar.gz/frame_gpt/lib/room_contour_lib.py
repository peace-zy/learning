#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2018 www.ke.com, Inc. All Rights Reserved
"""
提取轮廓特征lib
"""
from __future__ import division
import collections
import copy
import re
import os
import math
import logging
import json
from functools import reduce
from collections import Counter, defaultdict

import pandas as pd
from skimage.draw import polygon
from skimage.measure import moments, moments_central, moments_normalized, moments_hu
from shapely.geometry import LinearRing, LineString, Polygon
import numpy as np
from scipy.fftpack import fft

from lib import room_contour_entity as contour_entity
from lib.room_contour_entity import MAIN_DOOR_ROOM_TYPE_ORDER


#############
# 常量定义
#############
# 旋转的8个角度
ANGLE_SPLIT = 8
DEFAULT_ZOOM_BASE = 200

# 0: 单开门/1: 推拉门/2: 双开门/3: 子母门/16: 垭口
DOOR_TYPE = {0, 1, 2, 3, 4, 16}
# 5: 普通窗/6: 弧形窗/7: 普通飘窗/8: 落地窗/9: 落地窗1/10: 落地窗2/11:  落地飘窗/12: 落地拐角窗/17: 普通单面飘窗/18: 落地单面飘窗
WINDOW_TYPE = {5, 6, 7, 8, 9, 10, 11, 12, 17, 18}
# 阳台: 100900000005, 露台: 100900000006, 花园: 100900000007
BALCONY_TYPE = {'100900000005', '100900000006', '100900000007'}
SHI_TING_TYPE = {'100900000002', '100900000001'}
# 1: 客厅/2: 餐厅/23: 过道/25: 门厅/27: 玄关/37: 起居室
PUBLIC_DETAIL_TYPE = {1, 2, 23, 25, 27, 37}
# 飘窗类型: 普通飘窗、落地飘窗、普通单面飘窗、落地单面飘窗
BAY_WINDOW_TYPE = {7, 11, 17, 18}
# 墙体朝向阈值: 30度
TOWARDS_DIFF_THRESHOLD = 30
# 阳台匹配差加权
BALCONY_ITEM_DIFF_COST = 4
# 定义主要居室类型
SHI = (u'100900000001', u'100900000009')
SHI_GRAY_SCALE = 1
TING = (u'100900000002',)
TING_GRAY_SCALE = 0.7
CHU = (u'100900000003',)
CHU_GRAY_SCALE = 0.5
WEI = (u'100900000004',)
WEI_GRAY_SCALE = 0.3
YANG = (u'100900000005',)
YANG_GRAY_SCALE = 0.2
# default: 0
GRAY_SCALE_DICT = dict()
GRAY_SCALE_DICT.update({r_: SHI_GRAY_SCALE for r_ in SHI})
GRAY_SCALE_DICT.update({r_: TING_GRAY_SCALE for r_ in TING})
GRAY_SCALE_DICT.update({r_: CHU_GRAY_SCALE for r_ in CHU})
GRAY_SCALE_DICT.update({r_: WEI_GRAY_SCALE for r_ in WEI})
GRAY_SCALE_DICT.update({r_: YANG_GRAY_SCALE for r_ in YANG})
# 自定义一个入户门类型
DEFINED_HU = '100900000099'
HU = (DEFINED_HU,)
# 十进制转二进制
F_BIN_V = np.vectorize(lambda x: bin(x).count('1'))
#############
# mass_layout/mass_layout_geo 分间嵌入向量模板
#############
#  [[室-室], [室-厅], [室-厨], [室-卫],
#  [厅-厅], [厅-厨],  [厅-卫],
#  [厨-厨],  [厨-卫],
#  [卫-卫],
#  [户门-室], [户门-厅], [户门-厨], [户门-卫],
#  [阳台-室], [阳台-厅], [阳台-厨], [阳台-卫]]
FLOOR_SPLIT = '#'
UNIT_SPLIT = ','
DATA_SPLIT = '|'
VEC_CENTER_HOLDER = [
    (SHI, SHI), (SHI, TING), (SHI, CHU), (SHI, WEI),
    (TING, TING), (TING, CHU), (TING, WEI),
    (CHU, CHU), (CHU, WEI),
    (WEI, WEI),
    (HU, SHI), (HU, TING), (HU, CHU), (HU, WEI),
    (YANG, SHI), (YANG, TING), (YANG, CHU), (YANG, WEI),
    ]
# 分间面积嵌入向量 占位符
VEC_AREA_HOLDER = (SHI, TING, CHU, WEI, YANG)
# ENTRANCE_TOWARDS
ENTRANCE_TOWARDS = {'default': -1,
                    'north': 1, 'north-east': 2,
                    'east': 3, 'south-east': 4,
                    'south': 5, 'south-west': 6,
                    'west': 7, 'north-west': 8}


def get_room_cluster_feature(frame_id, json_dict, params):
    """
    计算分间聚类特征
    :param frame_id: frame_id
    :param json_dict: 整个户型的dict.
    :param params: 解析参数.
        'cal_room_type_set': Set, 需要解析哪些类别的分间类型.
        'max_rectangle_ratio': float, 最大矩形率, 值域: [0~1], 越接近0越像矩形, default: 0.2.
    :return:
        {
            'room_type_code_1': [
                {
                feature_1: '',
                feature_2: '',
                ...
                },
                ...]
        }
    """
    ret_dict = defaultdict(list)
    params['cal_room_type_set'] = {'100900000004', '100900000003', '100900000005'}
    frame_contour_dict = extract_frame_feature(frame_id, json_dict, params)
    for plan_idx in frame_contour_dict:
        frame_contour = frame_contour_dict[plan_idx]
        frame_ret_dict = frame_contour.dump()
        kitchen_dict_arr = frame_ret_dict['kitchen_dict']
        toilet_dict_arr = frame_ret_dict['toilet_dict']
        ret_dict['100900000003'].extend([_kitchen_dict['cluster_details'] for _kitchen_dict in kitchen_dict_arr])
        ret_dict['100900000004'].extend([_toilet_dict['cluster_details'] for _toilet_dict in toilet_dict_arr])
    return ret_dict


def get_floor_plan_contour_feature_spark(row, params):
    """
    计算户型/分间轮廓特征
    面积直方图, 面积归一化直方图, 附件距离特征, 附件相对夹角特征
    :param row:
    :param params: 参数配置
    :return:
    """
    floor_contour = contour_entity.FloorContour(row)
    try:
        f_id = row.frame_id
        floor_plan_str = row.json_str
        floor_plan_dict = json.loads(floor_plan_str)
        frame_contour_dict = extract_frame_feature(f_id, floor_plan_dict, params)
        step = params.get('sample', None)
        # with_room_hist = params.get('with_room_hist', False)
        angle_split = params.get('angle_split', ANGLE_SPLIT)

        # 计算户型所有分间的轮廓
        shi_sum = ting_sum = chu_sum = wei_sum = yang_sum = edge_len_sum = plan_area_sum = 0
        entrance_towards = ''
        mass_layout, mass_layout_geo, log_hu, w_log_hu, area_vec = (list() for _ in range(5))
        plans_dict = dict()
        is_vr = contour_entity.VRCode.default
        for plan_idx in frame_contour_dict:
            frame_contour = frame_contour_dict[plan_idx]
            # 计算整个平面图
            edge_points_dict_floor = frame_contour.edge_points_dict
            mass_center_floor = frame_contour.mass_center
            edge_points_array_floor = frame_contour.edge_points_array
            floor_points_to_line_map_floor = frame_contour.floor_points_to_line_map
            # 提取 轮廓附件特征
            line_offset_array_f, item_offset_array_f, door_offset_f, polygon_pts_f = edge_walk(edge_points_dict_floor,
                                                                                               floor_points_to_line_map_floor,
                                                                                               mass_center_floor, params)
            assert len(set(edge_points_array_floor)) == (len(set(polygon_pts_f))), \
                'polygon_pts do not match edge_points_array. plan_idx: {}, id: {}'.format(plan_idx, f_id)
            # 提取 area slice histogram
            edge_points_array_floor = (np.array(edge_points_array_floor)).astype(int)
            frame_contour_hist_dict = get_area_slice_histogram(edge_points_array_floor, line_offset_array_f,
                                                               item_offset_array_f, step=step, angle_split=angle_split)

            # ret_dict = {'angles': [list(rotate_idx), list(rotate_idx_reverse)],
            #             'areas': ret_area_serialized, 'areas_fd': areas_fd,
            #             'towards': ret_towards_serialized,
            #             'door_exist': ret_door_exist_serialized, 'door_fd': door_fd,
            #             'window_exist': ret_window_exist_serialized, 'window_fd': window_fd,
            #             'door_window_fd': door_window_fd,
            #             'area_type': ret_area_type_serialized,
            #             'wall': ret_wall_serialized}
            frame_contour.fourier_desc['door_window_fd'] = frame_contour_hist_dict['door_window_fd']
            frame_contour.fourier_desc['door_fd'] = frame_contour_hist_dict['door_fd']
            frame_contour.fourier_desc['window_fd'] = frame_contour_hist_dict['window_fd']
            frame_contour.fourier_desc['areas_fd'] = frame_contour_hist_dict['areas_fd']
            # 保存平面图特征
            frame_contour.set_wall_hist(frame_contour_hist_dict['wall'])
            frame_contour.set_area_type_hist(frame_contour_hist_dict['area_type'])
            frame_contour.set_window_exist_hist(frame_contour_hist_dict['window_exist'])
            frame_contour.set_door_exist_hist(frame_contour_hist_dict['door_exist'])
            frame_contour.set_areas_hist(frame_contour_hist_dict['areas'])
            frame_contour.set_towards_hist(frame_contour_hist_dict['towards'])
            frame_contour.set_angles_hist(frame_contour_hist_dict['angles'])

            frame_contour.set_line_offset_array(line_offset_array_f)
            frame_contour.set_item_offset_array(item_offset_array_f)

            area_id_dict = frame_contour.area_id_dict
            for area_id in area_id_dict:
                _area_contour = area_id_dict[area_id]
                edge_points_dict = _area_contour.edge_points_dict
                mass_center = _area_contour.mass_center
                edge_points_array = _area_contour.edge_points_array
                floor_points_to_line_map = _area_contour.floor_points_to_line_map
                with_room_hist = True
                # 提取 轮廓附件特征
                if with_room_hist:
                    # 是否计算分间的轮廓直方图
                    line_offset_array, item_offset_array, door_offset, polygon_pts = edge_walk(edge_points_dict,
                                                                                               floor_points_to_line_map,
                                                                                               mass_center, params)
                    assert len(set(edge_points_array)) == (len(set(polygon_pts))), \
                        'polygon_pts do not match edge_points_array. area_id: {}, id: {}'.format(area_id, f_id)
                    Polygon(polygon_pts).minimum_rotated_rectangle
                    # 提取 area slice histogram
                    if params.get('with_room_hist', False):
                        area_contour_hist_dict = get_area_slice_histogram(polygon_pts, line_offset_array, item_offset_array,
                                                              step=step, angle_split=angle_split)
                        # 保存平面图特征
                        _area_contour.fourier_desc['door_window_fd'] = area_contour_hist_dict['door_window_fd']
                        _area_contour.fourier_desc['door_fd'] = area_contour_hist_dict['door_fd']
                        _area_contour.fourier_desc['window_fd'] = area_contour_hist_dict['window_fd']
                        _area_contour.fourier_desc['areas_fd'] = area_contour_hist_dict['areas_fd']
                        # 保存平面图特征
                        _area_contour.set_wall_hist(area_contour_hist_dict['wall'])
                        _area_contour.set_area_type_hist(area_contour_hist_dict['area_type'])
                        _area_contour.set_window_exist_hist(area_contour_hist_dict['window_exist'])
                        _area_contour.set_door_exist_hist(area_contour_hist_dict['door_exist'])
                        _area_contour.set_areas_hist(area_contour_hist_dict['areas'])
                        _area_contour.set_towards_hist(area_contour_hist_dict['towards'])
                        _area_contour.set_angles_hist(area_contour_hist_dict['angles'])
                    _area_contour.set_line_offset_array(line_offset_array)
                    _area_contour.set_item_offset_array(item_offset_array)
            if frame_contour.entrance_angle:
                entrance_towards = frame_contour.entrance_angle
            edge_len_sum += frame_contour.edge_len
            plan_area_sum += frame_contour.area_size
            shi_sum += frame_contour.shi
            ting_sum += frame_contour.ting
            chu_sum += frame_contour.chu
            wei_sum += frame_contour.wei
            yang_sum += frame_contour.yang
            mass_layout.append(frame_contour.get_mass_layout())
            mass_layout_geo.append(frame_contour.get_mass_layout_geo())
            log_hu.append(frame_contour.log_hu)
            w_log_hu.append(frame_contour.w_log_hu)
            area_vec.append(frame_contour.get_area_vec())
            plans_dict[plan_idx] = frame_contour.dump()
            is_vr = frame_contour.is_vr
        floor_contour.set_rooms(shi_sum, ting_sum, chu_sum, wei_sum, yang_sum)
        floor_contour.set_entrance(entrance_towards)
        plans_len = len(frame_contour_dict)
        floor_contour.set_plans_len(plans_len)
        floor_contour.set_edge_len(edge_len_sum)
        floor_contour.set_plans_area(plan_area_sum)
        mass_layout_ret = serialize_layout_feature(mass_layout)
        floor_contour.set_mass_layout(mass_layout_ret)
        mass_layout_geo_ret = serialize_layout_feature(mass_layout_geo)
        floor_contour.set_mass_layout_geo(mass_layout_geo_ret)
        area_vec_ret = serialize_layout_feature(area_vec)
        floor_contour.set_area_vec(area_vec_ret)
        log_hu_ret = serialize_hu_feature(log_hu)
        floor_contour.set_log_hu(log_hu_ret)
        w_log_hu_ret = serialize_hu_feature(w_log_hu)
        floor_contour.set_w_log_hu(w_log_hu_ret)
        plans_dict_json_str = json.dumps(plans_dict, cls=contour_entity.ContourJsonEncoder)
        floor_contour.set_floors(plans_dict_json_str)
        floor_contour.set_is_vr(is_vr)
    except Exception as e:
        logging.exception(e)
        floor_contour.set_error(contour_entity.ErrorCode.area_analysis)
        return floor_contour.dump()
    return floor_contour.dump()


def get_floor_plan_contour_feature(f_id, floor_plan_str, params):
    """
    计算户型/分间轮廓特征
    面积直方图, 面积归一化直方图, 附件距离特征, 附件相对夹角特征
    :param f_id:
    :param floor_plan_str: 户型的字符串
    :param params: 参数配置
    :return:
    """
    try:
        floor_plan_dict = json.loads(floor_plan_str)
        frame_contour_dict = extract_frame_feature(f_id, floor_plan_dict, params)
        step = params.get('sample', None)
        angle_split = params.get('angle_split', 8)
        # 计算户型所有分间的轮廓
        for plan_idx, frame_contour in frame_contour_dict.items():
            # 计算整个平面图
            edge_points_dict_floor = frame_contour.edge_points_dict
            mass_center_floor = frame_contour.mass_center
            edge_points_array_floor = frame_contour.edge_points_array
            floor_points_to_line_map_floor = frame_contour.floor_points_to_line_map
            # 提取 轮廓附件特征
            line_offset_array_f, item_offset_array_f, door_offset_f, polygon_pts_f = edge_walk(edge_points_dict_floor,
                                                                                               floor_points_to_line_map_floor,
                                                                                               mass_center_floor, params)
            # if item_array_floor:
            # 提取 area slice histogram
            assert len(set(edge_points_array_floor)) == (len(set(polygon_pts_f))), \
                'polygon_pts do not match edge_points_array. plan_idx: {}, id: {}'.format(plan_idx, f_id)
            # 提取 area slice histogram
            edge_points_array_floor = (np.array(edge_points_array_floor)).astype(int)
            angles_f, areas_f, towards_f, door_exist_f, window_exist_f, area_type_f = get_area_slice_histogram(edge_points_array_floor,
                                                                                                               line_offset_array_f,
                                                                                                               item_offset_array_f,
                                                                                                               step=step, angle_split=angle_split)
            # 保存平面图特征
            frame_contour.set_area_type_hist(area_type_f)
            frame_contour.set_window_exist_hist(window_exist_f)
            frame_contour.set_door_exist_hist(door_exist_f)
            frame_contour.set_areas_hist(areas_f)
            frame_contour.set_towards_hist(towards_f)
            frame_contour.set_angles_hist(angles_f)
            frame_contour.set_line_offset_array(line_offset_array_f)
            frame_contour.set_item_offset_array(item_offset_array_f)

            area_id_dict = frame_contour.area_id_dict
            for area_id in area_id_dict:
                _area_contour = area_id_dict[area_id]
                edge_points_dict = _area_contour.edge_points_dict
                mass_center = _area_contour.mass_center
                edge_points_array = _area_contour.edge_points_array
                floor_points_to_line_map = _area_contour.floor_points_to_line_map
                # 提取 轮廓附件特征
                # _, _, item_array, door_offset, polygon_pts = merge_lines(edge_points_dict, floor_points_to_line_map,
                #                                                          init_point, params)
                line_offset_array, item_offset_array, door_offset, polygon_pts = edge_walk(edge_points_dict,
                                                                                           floor_points_to_line_map,
                                                                                           mass_center, params)
                # if item_array:
                assert len(set(edge_points_array)) == (len(set(polygon_pts))),\
                    'polygon_pts do not match edge_points_array. area_id: {}, id: {}'.format(area_id, f_id)
                # 提取 area slice histogram
                if params.get('with_room_hist', False):
                    angles_, areas_, towards_,  door_exist_, window_exist_, area_type_ = get_area_slice_histogram(polygon_pts,
                                                                                                              line_offset_array,
                                                                                                              item_offset_array,
                                                                                                              step=step, angle_split=angle_split)
                    # 保存平面图特征
                    _area_contour.set_area_type_hist(area_type_)
                    _area_contour.set_window_exist_hist(window_exist_)
                    _area_contour.set_door_exist_hist(door_exist_)
                    _area_contour.set_towards_hist(towards_)
                    _area_contour.set_areas_hist(areas_)
                    _area_contour.set_angles_hist(angles_)
                _area_contour.set_line_offset_array(line_offset_array)
                _area_contour.set_item_offset_array(item_offset_array)
    except Exception as e:
        print('===== frame_id: {} ===== '.format(f_id))
        print(e)
        return None
    return f_id, frame_contour_dict


def extract_frame_feature(f_id, floor_plan_dict, params):
    """
    提取轮廓相关特征预处理
    :param f_id:
    :param floor_plan_dict:
    :param params:
    :return: {楼层idx:FrameContour, ...}
    """
    plans = floor_plan_dict.get('floorplans', None)
    assert plans is not None, 'ErrorCode.plan_cnt, id:{}'.format(f_id)
    vr_data = floor_plan_dict.get('vrData', None)
    is_vr = contour_entity.VRCode.default
    if vr_data:
        # 存在是否是VR数据
        is_vr = contour_entity.VRCode.is_vr
    # #########################
    # 入户门查找
    # #########################
    entrance_angle = None  # 入户门朝向与正北夹角
    # entrance_line_id = None  # 入户门所在墙
    entrance_item_id = None  # 入户门所在墙ID
    entrance_plan_idx = 0   # 入户门所在楼层
    all_line_items_arr = []
    line_id_to_area_detail_type_dict = collections.defaultdict(set)
    line_id_to_area_type_dict = collections.defaultdict(set)
    line_id_to_area_id_dict = collections.defaultdict(set)
    line_id_to_towards_dict = collections.defaultdict(set)
    for i in range(len(plans)):
        # 全部信息抽取
        all_points = plans[i].get('points', None)
        all_line_items = plans[i].get('lineItems', None)
        all_line = plans[i].get('lines', None)
        all_areas = plans[i].get('areas', None)

        # 点、线、面数据缺失
        is_complete_conditions = [
            all_points is None,
            all_line_items is None,
            all_line is None,
            all_areas is None
        ]
        assert not any(is_complete_conditions), 'ErrorCode.lack_data, id:{}'.format(f_id)

        # ############### 遍历 墙体附属物 & 分间 ######################
        # 1. 获取入户门朝向
        # 2. 统计纳入计算的分间的点集合
        # 入户门查找
        all_line_items_dict = {}
        for _line_item in all_line_items:
            i_id = _line_item.get('id', None)
            all_line_items_dict[i_id] = _line_item
            if _line_item.get(u"entrance", None) is not None:
                entrance_angle = _line_item[u"entrance"]
                entrance_item_id = _line_item[u"id"]
                entrance_plan_idx = i
        all_line_items_arr.append(all_line_items_dict)

        # 遍历分间数据取分间墙朝向 找到门所在的墙体附件
        for area in all_areas:
            try:
                attachments_lines = area[u"attachments"][u"lines"]
                area_id = area[u"id"]
                area_type = area[u"roomType"]
                area_detail_type = area[u"type"]
                for room_line in attachments_lines:
                    room_line_id = room_line[u"id"]
                    room_line_towards = room_line[u"towardsRad"]
                    line_id_to_area_type_dict[room_line_id].add(area_type)
                    line_id_to_area_detail_type_dict[room_line_id].add(area_detail_type)
                    line_id_to_area_id_dict[room_line_id].add(area_id)
                    line_id_to_towards_dict[room_line_id].add(room_line_towards)
            except Exception as e:
                logging.exception(e)
                raise Exception('ErrorCode.area_analysis, id:{}'.format(f_id))
    # 遍历完所有楼层, 没有入户门
    if entrance_angle is None:
        raise Exception('ErrorCode.not_entrance, id:{}'.format(f_id))

    # #########################
    # 分间查找
    # #########################
    # 户型外墙之和
    edge_len = 0
    # 所有外墙除阳台的窗的数量
    edge_windows = 0
    zoom_base = params.get("zoom_base", DEFAULT_ZOOM_BASE)
    area_id_dict = dict()
    all_line_dict = dict()
    plan_dict = dict()
    area_info_dict = collections.defaultdict(list)  #分间特征字典
    for plan_idx in range(len(plans)):
        # ################### 统计数据初始化 ##########################
        point_dict = {}  # 点坐标字典
        # 全部信息抽取
        all_points = plans[plan_idx].get('points', None)
        all_line = plans[plan_idx].get('lines', None)
        all_areas = plans[plan_idx].get('areas', None)

        size_sum = 0.  # 分间面积和
        size_sum_without_line = 0.  # 分间面积和
        # #################### 遍历 所有点集合 ######################
        # 1. 获取户型坐标四至
        # 2. 旋转后坐标对齐到左下角
        # 3. 获取调整后户型长宽、中心点
        maxx = None
        maxy = None
        for p in all_points:
            p_id = p.get('id', None)
            # 所有的点截取小数
            x = round(p.get('x', None), 0)
            y = round(p.get('y', None), 0)
            if p_id is None or x is None or y is None:
                raise Exception('ErrorCode.point_iter, id:{}'.format(f_id))
            point_dict[p_id] = [x, y]
            if maxx is None:
                maxx = x
                maxy = y
            else:
                maxx = x if x > maxx else maxx
                maxy = y if y > maxy else maxy
        # 点数据为空
        if maxx is None or maxy is None:
            raise Exception('ErrorCode.empty_points, id:{}'.format(f_id))

        # 全部计入分间
        minx = maxx = miny = maxy = None
        for p_id in point_dict:
            x = point_dict[p_id][0]
            y = point_dict[p_id][1]
            if minx is None:
                minx = maxx = x
                miny = maxy = y
            else:
                minx, maxx = min(x, minx), max(x, maxx)
                miny, maxy = min(y, miny), max(y, maxy)
        # 外接矩形长宽
        x_len = float(maxx - minx)
        y_len = float(maxy - miny)
        # 调整坐标到左下角为原点， 不计入户型计算的分间坐标有可能出现负值
        for p_id in point_dict:
            point_dict[p_id][0] -= minx
            point_dict[p_id][1] -= miny

        # #################### 遍历 所有边集合 ######################
        all_line_items_dict = all_line_items_arr[plan_idx]
        points_to_line_map = dict()
        # 点坐标索引的字典
        points_to_line_map_real = dict()
        edge_points_dict = collections.defaultdict(set)
        # 入户门角点
        # door_points = None
        for l in all_line:
            edge_computed = l.get('edgeComputed', False)
            l_id = l.get('id', None)
            l_ps = l.get('points', None)
            l_curve = l.get('curve', 0)
            l_type = l.get('type', 0)
            l_items = l.get('items', [])
            a_x, a_y = point_dict[l_ps[0]]
            b_x, b_y = point_dict[l_ps[-1]]
            if a_x == b_x and a_y == b_y:
                continue
            all_line_dict[l_id] = l
            line_len = euclidean_dist(point_dict[l_ps[0]], point_dict[l_ps[-1]])
            line_center = ((a_x + b_x) / 2, (a_y + b_y) / 2)

            # 记录附件
            _line_items = []
            # 记录反向附件
            _line_items_reverse = []
            for tmp_item_id in l_items:
                tmp_item = all_line_items_dict[tmp_item_id]
                item_type = tmp_item['type']
                start_index = tmp_item['startIndex']
                item_length = tmp_item['length']
                try:
                    assert 'start' in tmp_item, 'FAILED! frame_id: {}, line_id: {}'.format(f_id, l_id)
                    item_start = tmp_item['start']
                    if start_index != 0:
                        item_start = line_len - item_length - item_start
                        start_index = 0
                except Exception as e:
                    logging.exception(e)
                    raise Exception('ErrorCode.item_start_err, id:{}'.format(f_id))
                if item_type == 16:
                    _is = 'door'
                else:
                    _is = tmp_item['is']
                _item_pts = np.array([(int(_['x']) - minx, int(_['y'] - miny)) for _ in
                                      [tmp_item['startPointAt'], tmp_item['endPointAt']]], dtype=int)
                _tmp_item = {'type': item_type, 'start_index': tuple(point_dict[l_ps[start_index]]),
                             'start': item_start, 'length': item_length, 'item_id': tmp_item_id, 'is': _is,
                             'pts': _item_pts, 'center': np.mean(_item_pts, 0)}
                if tmp_item_id == entrance_item_id:
                    _tmp_item['is_entrance'] = True
                    # 加入入户门area_info
                    entrance_line_s = LineString(((a_x, a_y), (b_x, b_y)))
                    item_center = entrance_line_s.interpolate(_tmp_item['start'] + item_length/2)
                    area_info_dict[DEFINED_HU].append({"area": 0, "mass_center": (item_center.x, item_center.y)})
                _line_items.append(_tmp_item)
                tmp_item_reverse = copy.deepcopy(_tmp_item)
                tmp_item_reverse['start_index'] = tuple(point_dict[l_ps[abs(start_index-1)]])
                tmp_item_reverse['start'] = line_len - _tmp_item['start'] - _tmp_item['length']
                _line_items_reverse.append(tmp_item_reverse)
            # 虚拟墙, 栅栏, 玻璃落地墙, 玻璃墙 等于普通窗, 如果已经是窗了, 忽略所有窗上窗.
            if str(l_type) in ('3', '4', '5', '6'):
                if edge_computed:
                    _l_is = 'window'
                    _i_type = 5
                else:
                    _l_is = 'door'
                    _i_type = 0
                _l_items_id = str(np.random.randint(0, 50000000))
                _line_items = [{'type': _i_type, 'start_index': tuple(point_dict[l_ps[0]]),
                                'start': 0, 'is': _l_is, 'item_id': _l_items_id, 'length': line_len,
                                'pts': np.array(((a_x, a_y), (b_x, b_y))), 'center': line_center},]
                _line_items_reverse = _line_items
            line_points = [(a_x, a_y)]
            # 对于弧线采样
            if l_curve != 0.0:
                try:
                    # 对弧墙采样
                    _x, _y, arc_len = get_cycle_radius(((a_x, a_y), (b_x, b_y), l_curve),
                                                       sample_cnt=params.get("sample_cnt", 15))
                    line_len = arc_len
                    if l_curve <= 0.0:
                        line_points.extend([m for m in reversed([x for x in zip(_x, _y)])])
                    else:
                        line_points.extend([x for x in zip(_x, _y)])
                except Exception as e:
                    logging.exception(e)
                    raise Exception('ErrorCode.get_cycle_radius_err, id:{}'.format(f_id))
            line_points.append((b_x, b_y))
            is_balcony_line = False
            # 阳台, 露台, 花园
            tmp_area_detail_type = line_id_to_area_detail_type_dict[l_id]
            tmp_area_type = line_id_to_area_type_dict[l_id]
            tmp_towards = line_id_to_towards_dict[l_id]
            if not BALCONY_TYPE.isdisjoint(set(tmp_area_detail_type)):
                is_balcony_line = True
            tmp_area_id = line_id_to_area_id_dict[l_id]
            _line_items = sorted(_line_items, key=lambda _x: _x['start'])
            _tmp_line = {'points': line_points, 'line_center': line_center, 'len': line_len, 'l_id': l_id,
                         'curve': l_curve, 'items': _line_items, 'is_balcony_line': is_balcony_line,
                         'area_type': tmp_area_type, 'type': l_type, 'area_detail_type': tmp_area_detail_type,
                         'area_id': tmp_area_id, 'towards': tmp_towards}

            # 加入线集合
            points_to_line_map[','.join(l_ps)] = _tmp_line
            _tmp_line_reversed = copy.deepcopy(_tmp_line)
            _line_items_reverse = list(reversed(_line_items_reverse))
            _tmp_line_reversed['items'] = _line_items_reverse
            _tmp_line_reversed['points'] = [m for m in reversed(line_points)]
            points_to_line_map[','.join(reversed(l_ps))] = _tmp_line_reversed

            points_to_line_map_real[((a_x, a_y), (b_x, b_y))] = _tmp_line
            points_to_line_map_real[((b_x, b_y), (a_x, a_y))] = _tmp_line_reversed

            if edge_computed:
                edge_len += line_len
                if not is_balcony_line:
                    edge_windows += len(_line_items)
                if (a_x, a_y) != (b_x, b_y):
                    edge_points_dict[(a_x, a_y)].add((b_x, b_y))
                    edge_points_dict[(b_x, b_y)].add((a_x, a_y))
        _offset = np.array(zoom_base * 0.1)
        room_cnt_dict = collections.defaultdict(int)  # 分间类型计数器
        # 设置画布
        zoom_ratio = DEFAULT_ZOOM_BASE / max(x_len, y_len)
        im_size = np.array([DEFAULT_ZOOM_BASE + int(zoom_base * 0.2),
                            DEFAULT_ZOOM_BASE + int(zoom_base * 0.2)], dtype='int32')
        im_all = np.zeros(im_size, dtype=np.float32)
        im_temp = np.zeros(im_size, dtype=np.float32)
        _offset = np.array(zoom_base * 0.1)
        for area in all_areas:
            # 分间的点
            area_id = area.get(u"id", None)
            # print(area_id)
            # 分间的点
            area_points = area.get(u"points", None)
            # 分间类型
            area_type = area.get(u"roomType", None)
            # 分间面积
            area_area = area.get('size', None)
            size_without_line = area.get('sizeWithoutLine', -1)
            # 是否空（空则不计入总面积）
            is_empty = area.get('empty', False)
            # 分间的点不存在
            if area_points is None or area_type is None or area_area is None:
                raise Exception('ErrorCode.area_info_empty')
            if not is_empty:
                size_sum += area_area
                size_sum_without_line += size_without_line
            # 分间类型计数
            room_cnt_dict[area_type] += 1

            # 过滤不需要的分间
            if area_type not in params.get('cal_room_type_set', []):
                continue

            tmp_area_points = list()
            tmp_dup_area_points_set = set()
            for _p_id in area_points:
                _tmp_real_point = point_dict[_p_id]
                if tuple(_tmp_real_point) in tmp_dup_area_points_set:
                    # 重复点容错处理
                    continue
                tmp_dup_area_points_set.add(tuple(_tmp_real_point))
                tmp_area_points.append(_tmp_real_point)

            _area_perimeter = 0
            _current_line_arr = []
            point_id_tuples, _ = contour_entity.array_2_combination(area_points, combination_len=2)
            _area_line_max_orders = []
            _area_doors = []
            for p_id_1, p_id_2 in point_id_tuples:
                points_cp_key = '{},{}'.format(p_id_1[0], p_id_2[0])
                cp_line = points_to_line_map.get(points_cp_key, None)
                if cp_line:
                    _area_perimeter += cp_line['len']
                    _current_line_arr.append(cp_line)
                    _room_order = min([MAIN_DOOR_ROOM_TYPE_ORDER.get(_, 2) for _ in cp_line['area_detail_type']])
                    _door_len_arr = [(_['length'], _) for _ in cp_line.get('items') if _.get('is', 'window') == 'door']
                    _area_doors.extend(_door_len_arr)
                    if _door_len_arr:
                        # _door_len_arr = sorted(_door_len_arr) bug修复
                        _door_len_arr = sorted(_door_len_arr, key=lambda x: x[0])
                        _main_door_item_len, _max_item = _door_len_arr[0][0], _door_len_arr[0][1]
                        item_is_entrance = _max_item.get('is_entrance', False)
                        if item_is_entrance:
                            _room_order = -1
                    else:
                        _main_door_item_len = -1
                        # 必须要有门
                        _room_order = 5
                        _max_item = None
                    _area_line_max_orders.append((_room_order, _main_door_item_len, _max_item,))
            # 重新sort lines
            start_line_index = sorted(_area_line_max_orders, key=lambda _: (_[0], -_[1]))
            _max_item = start_line_index[0][-1]
            # 分间重心
            if area_type not in GRAY_SCALE_DICT:
                area_gray_scale = 0.1
            else:
                area_gray_scale = GRAY_SCALE_DICT[area_type]
            area_im = fill_frame_poly(tmp_area_points, _offset, zoom_ratio, im_temp, area_gray_scale)
            area_centroid, area_log_hu = cal_frame_centroid(area_im, _offset, zoom_ratio)
            assert (not np.isnan(area_centroid[0])) and (not np.isnan(area_centroid[1])), 'frame_id: {}, centroid is nan'.format(f_id)
            im_all = area_im + im_all
            _room_contour_params = {'entrance_angle': 0,  # 这个暂时不需要
                                    'edge_len': _area_perimeter/1e3, 'area_size': area_area,
                                    'area_size_without_line': size_without_line, 'mass_center': area_centroid,
                                    'floor_points_to_line_map': points_to_line_map_real,
                                    'edge_points_array': tmp_area_points,
                                    'edge_points_dict': None,
                                    'room_type': area_type,
                                    'area_doors': _area_doors,
                                    'area_id': area_id,
                                    'log_hu': area_log_hu, 'sorted_line_arr': _current_line_arr,
                                    'main_item': _max_item
                                    }
            _area_contour = contour_entity.RoomContour(**_room_contour_params)
            area_id_dict[area_id] = _area_contour
            # 没有除墙面积使用含墙面积
            area_info_size = area_area
            if size_without_line > 0:
                area_info_size = size_without_line
            area_info_dict[area_type].append({"area": area_info_size, "mass_center": area_centroid})
        # 统计分间数
        shi = room_cnt_dict.get('100900000001', 0) + room_cnt_dict.get('100900000009', 0)
        ting = room_cnt_dict.get('100900000002', 0)
        chu = room_cnt_dict.get('100900000003', 0)
        wei = room_cnt_dict.get('100900000004', 0)
        yang = room_cnt_dict.get('100900000005', 0)
        # 求户型中心需要归一化
        frame_w_centroid, frame_w_log_hu = cal_frame_centroid(im_all, _offset, zoom_ratio)
        threshold_im = copy.deepcopy(im_all)
        threshold_im[threshold_im > 0] = 1
        frame_centroid, frame_log_hu = cal_frame_centroid(threshold_im, _offset, zoom_ratio)
        if entrance_plan_idx == plan_idx:
            entrance_towards = get_direction(entrance_angle)
        else:
            entrance_towards = ''
        _frame_contour_init_params = {'is_vr': is_vr, 'entrance_angle': entrance_towards,
                                      'edge_len': edge_len/1e3, 'area_size': size_sum,
                                      'area_size_without_line': size_sum_without_line,
                                      'mass_center': frame_centroid,
                                      'floor_points_to_line_map': points_to_line_map_real, 'edge_points_array': None,
                                      'edge_points_dict': edge_points_dict,
                                      'shi': shi, 'ting': ting, 'chu': chu, 'wei': wei, 'yang': yang,
                                      'area_id_dict': area_id_dict, 'log_hu': list(frame_log_hu),
                                      'w_log_hu': list(frame_w_log_hu),
                                      }
        _frame_contour = contour_entity.FrameContour(**_frame_contour_init_params)
        mass_layout, mass_layout_geo = get_room_pair_vec(area_info_dict)
        area_vec = get_room_direct_vec(area_info_dict)
        _frame_contour.set_mass_layout(mass_layout)
        _frame_contour.set_mass_layout_geo(mass_layout_geo)
        _frame_contour.set_area_vec(area_vec)
        plan_dict[plan_idx] = _frame_contour
    return plan_dict


def fft_coeff_descriptor(hist_feature, normalize=True, n=10, sample_num=360):
    """
    提取频域归一化振幅特征
    :param hist_feature:
    :param normalize: 是否归一化 傅里叶系数
    :param n: 取到最大n前的频率的振幅特征
    :param sample_num: 取到最大n前的频率的振幅特征
    :return:
    """
    if hist_feature is not None and len(hist_feature) > 0:
        fft_y = fft(hist_feature)
        inv_fft_y = fft(hist_feature[::-1])
        abs_y = np.abs(fft_y)  # 取复数的绝对值，即复数的模(双边频谱)
        normalization_y = abs_y / sample_num  # 归一化处理（双边频谱）
        normalization_half_y = normalization_y[range(int(sample_num / 2))]  # 由于对称性，只取一半区间（单边频谱）
        if normalize:
            if normalization_half_y[0] < 1e-9:
                fft_coeffs = np.zeros(n-1)
            else:
                fft_coeffs = (normalization_half_y[:n] / normalization_half_y[0])[1:]
        else:
            fft_coeffs = normalization_half_y[:n-1]
    else:
        fft_coeffs, fft_y, inv_fft_y = [], [], []
    return fft_coeffs, fft_y, inv_fft_y


def get_room_direct_vec(rooms_dict, feature_attr='area'):
    """
    获取分间直接属性的嵌入特征向量
    :param rooms_dict:
    :param feature_attr:
    :return:
    """
    vec_arr = []
    for r_type in VEC_AREA_HOLDER:
        tmp_dist_arr = []
        r_feature_arr = [rooms_dict[_type] for _type in r_type if _type in rooms_dict]
        if len(r_feature_arr) != 0:
            r_arr = reduce(lambda x, y: x+y, r_feature_arr)
            arr_len = len(r_arr)
            for i in range(arr_len):
                r_a = round(r_arr[i][feature_attr])
                tmp_dist_arr.append(r_a/1e6)
            tmp_dist_arr = sorted(tmp_dist_arr, reverse=True)
        vec_arr.append(tmp_dist_arr)
    return vec_arr


def get_room_pair_vec(rooms_dict, feature_attr='mass_center'):
    """
    获取分间成对的距离, 夹角嵌入特征向量
    :param rooms_dict:
    :param feature_attr: 使用的分间重心
    :return:
    """
    vec_dist_arr = []
    vec_angle_arr = []
    for r_1, r_2 in VEC_CENTER_HOLDER:
        tmp_dist_arr = []
        tmp_angle_arr = []
        r_1_feature_arr = [rooms_dict[_type] for _type in r_1 if _type in rooms_dict]
        r_2_feature_arr = [rooms_dict[_type] for _type in r_2 if _type in rooms_dict]
        if len(r_1_feature_arr) != 0 and len(r_2_feature_arr) != 0:
            r_1_arr = reduce(lambda x, y: x + y, r_1_feature_arr)
            r_2_arr = reduce(lambda x, y: x + y, r_2_feature_arr)
            if r_1 == r_2:
                arr_len = len(r_1_arr)
                if arr_len == 0:
                    continue
                else:
                    for i in range(arr_len):
                        r_1_p = r_1_arr[i][feature_attr]
                        if i + 1 >= arr_len:
                            break
                        for k in range(i + 1, arr_len):
                            r_2_p = r_1_arr[k][feature_attr]
                            l1_dist = round(math.sqrt((r_1_p[1] - r_2_p[1]) ** 2 + (r_1_p[0] - r_2_p[0]) ** 2))
                            _angle = round(get_relative_angle(r_1_p, r_2_p))
                            tmp_dist_arr.append(l1_dist)
                            tmp_angle_arr.append(_angle)
            else:
                for r_1_dict in r_1_arr:
                    for r_2_dict in r_2_arr:
                        r_1_p = r_1_dict[feature_attr]
                        r_2_p = r_2_dict[feature_attr]
                        l1_dist = round(math.sqrt((r_1_p[1] - r_2_p[1]) ** 2 + (r_1_p[0] - r_2_p[0]) ** 2))
                        _angle = round(get_relative_angle(r_1_p, r_2_p))
                        tmp_dist_arr.append(l1_dist)
                        tmp_angle_arr.append(_angle)
            tmp_dist_arr = sorted(tmp_dist_arr, reverse=True)
            tmp_angle_arr = sorted(tmp_angle_arr, reverse=True)
        vec_dist_arr.append(tmp_dist_arr)
        vec_angle_arr.append(tmp_angle_arr)
    return vec_dist_arr, vec_angle_arr


def get_relative_angle(end_f_p, f_p, precision=3):
    """
    获取两个点相对于定位点和x轴正向夹角(相反的)
    :param end_f_p:
    :param f_p:
    :param precision:
    :return:
    """
    x_diff = end_f_p[0] - f_p[0]
    y_diff = end_f_p[1] - f_p[1]
    oblique_diff = math.sqrt(x_diff * x_diff + y_diff * y_diff)
    if oblique_diff == 0:
        diff_angle = 0
    else:
        if y_diff < 0:
            diff_angle = 360 - math.acos(x_diff / oblique_diff) * 180 / math.pi
        else:
            diff_angle = math.acos(x_diff / oblique_diff) * 180 / math.pi
    return round(diff_angle, precision)


def fill_frame_poly(points, _offset, _ratio, im, gray_scale=1):
    """
    画户型图
    :param points: 轮廓点序列
    :param _offset: 坐标偏移
    :param _ratio: 放缩比例
    :param im: 图片模板
    :param gray_scale: 灰度
    :return:
    """
    _im = copy.deepcopy(im)
    b = np.array(points, dtype=int)
    c = b*_ratio + _offset
    c = c.astype(int)
    rr, cc = polygon(c[:, 0], c[:, 1], _im.shape)
    _im[rr, cc] = gray_scale
    return _im


def cal_frame_centroid(im, _offset, _ratio, cut_len=contour_entity.LOG_HU_CUT_SIZE):
    """
    计算图片重心
    :param im:
    :param _offset:
    :param _ratio:
    :param cut_len: hu截取长度
   :return:
    """
    M = moments(im)
    centroid_x, centroid_y = M[1, 0] / M[0, 0], M[0, 1] / M[0, 0]
    mo_center = moments_central(im, (centroid_x, centroid_y))
    nu = moments_normalized(mo_center)
    hu_moment = moments_hu(nu)
    hu_moment += 0.00000001
    log_hu = -1 * np.copysign(1.0, hu_moment[:, ]) * np.log10(abs(hu_moment[:, ]))
    log_hu[log_hu > 1000] = 99
    centroid_x_o = (centroid_x - _offset) / _ratio
    centroid_y_o = (centroid_y - _offset) / _ratio
    return (centroid_x_o, centroid_y_o), log_hu[:cut_len]


def serialize_layout_feature(arr):
    """
    序列化布局特征
    第一层分隔符: #
    第二层分隔符: ,
    第三层分隔符: |
    :param arr:
    :return:
    """
    floor_ret_arr = []
    for floor_arr in arr:
        unit_ret_arr = []
        for unit_arr in floor_arr:
            unit_ret_arr.append(DATA_SPLIT.join([str(x) for x in unit_arr]))
        floor_ret_arr.append(UNIT_SPLIT.join(unit_ret_arr))
    return FLOOR_SPLIT.join(floor_ret_arr)


def serialize_hu_feature(arr):
    """
    序列化轮廓系数特征
    第一层分隔符: #
    第二层分隔符: ,
    :param arr:
    :return:
    """
    floor_ret_arr = []
    for floor_arr in arr:
        floor_ret_arr.append(UNIT_SPLIT.join([str(x) for x in floor_arr]))
    return FLOOR_SPLIT.join(floor_ret_arr)


def serialize_hist(hist):
    """
    特征序列化成稀疏矩阵
    1. {value1: [(start1, end1), (start2, end2),...], .....}
    2. 只记录非零值
    :param hist:
    :return:
    """
    ret_dict = collections.defaultdict(list)
    current_v = hist[0]
    current_start = current_end = 0
    hist_len = len(hist)
    for _i in range(1, hist_len):
        _v = hist[_i]
        if _v == current_v:
            current_end += 1
            if _i == hist_len - 1 and current_v != 0:
                ret_dict[current_v].append((current_start, current_end+1))
        else:
            if current_v != 0:
                ret_dict[current_v].append((current_start, current_end+1))
            current_v = _v
            current_start = _i
            current_end = _i
    return dict(ret_dict)


def deserialize_hist(hist_dict, hist_len):
    """
    特征序列化成稀疏矩阵
    1. {value1: [(start1, end1), (start2, end2),...], .....}
    2. 只记录非零值
    :param hist_dict:
    :param hist_len:
    :return:
    """
    val_arr = np.zeros(hist_len)
    for _hist_val in hist_dict:
        idx_arr = hist_dict[_hist_val]
        for idx_start_end in idx_arr:
            _start = idx_start_end[0]
            _end = idx_start_end[1]
            val_arr[_start:_end] = _hist_val
    return val_arr


def majority_down_sampling(hist_arr, step):
    """
    非零主元素降采样
    例子:
    a = [0, 0, 0, 0,
         1, 2, 2, 0,
         0, 3, 0, 0]
    majority_down_sampling(a, 4)
    :param hist_arr:
    :param step:
    :return:
    """
    # 分块
    assert len(hist_arr) % 360 == 0, 'majority_down_sampling should be divisible.'
    hist_reshaped = np.array(hist_arr).reshape(-1, len(hist_arr)//step)
    ret_arr = []
    for _tmp_lst in hist_reshaped:
        _tmp_lst_non_zero = _tmp_lst[_tmp_lst > 0]
        if len(_tmp_lst_non_zero) > 0:
            _tmp_lst_non_zero_c = Counter(_tmp_lst_non_zero).most_common(1)[0][0]
            ret_arr.append(_tmp_lst_non_zero_c)
        else:
            ret_arr.append(0)
    return ret_arr


def mean_down_sampling(hist_arr, step):
    """
    降采样
    例子:
    a = [0, 0, 0, 0,
         1, 2, 2, 0,
         0, 3, 0, 0]
    mean_down_sampling(a, 4)
    :param hist_arr:
    :param step:
    :return:
    """
    assert len(hist_arr) % 360 == 0, 'majority_down_sampling should be divisible.'
    return np.mean(np.array(hist_arr).reshape(-1, len(hist_arr)//step), axis=1)


def sum_down_sampling(hist_arr, step):
    """
    降采样
    例子:
    a = [0, 0, 0, 0,
         1, 2, 2, 0,
         0, 3, 0, 0]
    mean_down_sampling(a, 4)
    :param hist_arr:
    :param step:
    :return:
    """
    assert len(hist_arr) % 360 == 0, 'majority_down_sampling should be divisible.'
    return np.sum(np.array(hist_arr).reshape(-1, len(hist_arr)//step), axis=1)


def get_area_slice_histogram(edge_points, line_offset_arr, item_offset_arr,
                             step=360, angle_split=8):
    """
    轮廓切片特征
    针对切分采样点提取:
    面积, 窗附件(存在), 门附件(存在), 朝向(采样点最小匹配), 墙体包含类型, 分间划分.
    :param edge_points: 边界list
    :param line_offset_arr: 边界线段分隔数组
    :param item_offset_arr: 附件线段分隔数组
    :param step: 步长
    :param angle_split: 旋转的方向
    :return:
    """
    # 初始化返回变量
    areas_hist = []
    wall_hist = []
    # 两条射线夹角
    angles_hist = []
    # 朝向夹角
    towards_hist = []
    door_exist_hist = []
    window_exist_hist = []
    area_type_hist = []

    points_ = edge_points
    room_polyline = np.array(points_).astype(int)
    line_ = LinearRing(room_polyline)
    line_len = line_.length
    # 最小附件长度
    min_item_len = min([l_end - l_start for l_start, l_end, _ in item_offset_arr])
    # 获取最小采样间隔
    min_sample_step = int(line_len / max(10, min(min_item_len, line_len/step)))
    if min_sample_step % 360 != 0:
        min_sample_step = math.ceil(min_sample_step / 360) * 360

    if not line_.is_ccw:
        line_.coords = list(line_.coords)[::-1]
        _line_offset_arr = [(line_len - l_end, line_len - l_start, _l) for l_start, l_end, _l in line_offset_arr]
        _item_offset_arr = [(line_len - l_end, line_len - l_start, _i) for l_start, l_end, _i in item_offset_arr]
    else:
        # reverse为了队尾pop方便
        _line_offset_arr = list(reversed(copy.deepcopy(line_offset_arr)))
        _item_offset_arr = list(reversed(copy.deepcopy(item_offset_arr)))

    _centriod = line_.centroid
    c_x, c_y = _centriod.x, _centriod.y
    values = np.linspace(0, line_len, num=min_sample_step)
    pts = []
    door_idx = 0
    window_idx = 0
    prev_item_id = float('inf')
    balcony_list = []
    last_line_id, line_idx = None, 0
    for val in values:
        pt = line_.interpolate(val)
        pts.append([pt.x, pt.y])
        line_ret = find_interval(val, _line_offset_arr)
        if last_line_id != line_ret['l_id']:
            line_idx += 1
            last_line_id = line_ret['l_id']
        wall_hist.append(line_idx)

        area_type_ret_val = -1
        balcony_param = 1
        if line_ret:
            area_type_ret_val = line_ret.get('area_type', -1)
            if not BALCONY_TYPE.isdisjoint(area_type_ret_val):
                balcony_param = -1
        balcony_list.append(balcony_param)
        item_ret = find_interval(val, _item_offset_arr)
        if item_ret:
            item_type_ret_val = item_ret.get('type', -99)
            item_id_ret_val = item_ret.get('item_id', -1)
            is_current_new_item = 0
            if prev_item_id != item_id_ret_val:
                is_current_new_item = 1
                prev_item_id = item_id_ret_val
            if item_type_ret_val in DOOR_TYPE:
                door_idx += is_current_new_item
                door_exist_hist.append(door_idx*balcony_param)
            else:
                door_exist_hist.append(0)
            if item_type_ret_val in WINDOW_TYPE:
                window_idx += is_current_new_item
                window_exist_hist.append(window_idx*balcony_param)
            else:
                window_exist_hist.append(0)
        else:
            window_exist_hist.append(0)
            door_exist_hist.append(0)
        if area_type_ret_val:
            area_type_code = 0b00
            for _area_type in area_type_ret_val:
                _area_type_code = 0b01 << int(_area_type[-3:])
                area_type_code |= _area_type_code
            area_type_hist.append(area_type_code)
        else:
            area_type_hist.append(0)

    ortho_point = [(abs(c_x)+abs(c_y))*2, c_y]
    v1 = [ortho_point[0] - c_x, ortho_point[1] - c_y]
    j = 0
    for pt in pts:
        if j < len(pts) - 1:
            ar_ = triangle_area(pts[j][0], pts[j][1], pts[j + 1][0], pts[j + 1][1], c_x, c_y)
            areas_hist.append(int(ar_))
            v2 = [pt[0] - c_x, pt[1] - c_y]
            angle = atan2_dist(v1, v2)
            _v3, _v4 = (pts[j][0] - pts[j + 1][0], pts[j][1]-pts[j + 1][1]), (pts[j + 1][0] - c_x, pts[j + 1][1] - c_y)
            _towards = np.degrees(np.abs(atan2_dist(_v3, _v4)))
            _towards_min = min(180-_towards, _towards)
            angles_hist.append(angle)
            _pt_dist = square_dist(pt, [c_x, c_y])
            towards_hist.append(_towards_min)
        j = j + 1
    # recenter angles to origin + to degrees
    angles_adjusted_d = np.degrees(np.array(angles_hist) - angles_hist[np.argmin(np.abs(angles_hist))])
    angles_adjusted_d[angles_adjusted_d < 0] = 360 + angles_adjusted_d[angles_adjusted_d < 0]
    angles_adjusted_d = angles_adjusted_d.astype(int).tolist()
    angles_adjusted_d.append(angles_adjusted_d[-1])
    areas_hist.append(areas_hist[-1])
    towards_hist.append(towards_hist[-1])

    # 降采样
    if min_sample_step != 360:
        angles_adjusted_d = mean_down_sampling(angles_adjusted_d, step)
        areas_hist = sum_down_sampling(areas_hist, step)
        towards_hist = mean_down_sampling(towards_hist, step)
        window_exist_hist = majority_down_sampling(window_exist_hist, step)
        wall_hist = majority_down_sampling(wall_hist, step)
        door_exist_hist = majority_down_sampling(door_exist_hist, step)
        area_type_hist = majority_down_sampling(area_type_hist, step)

    min_angle_index = np.argmin(angles_adjusted_d)
    index_ = np.arange(min_angle_index, min_angle_index + step - 1) % (step - 1)

    ret_area = list()
    ret_wall = list()
    ret_towards = list()
    ret_door_exist = list()
    ret_window_exist = list()
    ret_area_type = list()
    ret_angle = list()
    for _idx in index_:
        _sign = balcony_list[_idx]
        ret_area.append(_sign*areas_hist[_idx])
        # towards 变成编码
        ret_towards.append(_sign*int(towards_hist[_idx]))
        ret_door_exist.append(door_exist_hist[_idx])
        ret_window_exist.append(window_exist_hist[_idx])
        ret_area_type.append(area_type_hist[_idx])
        ret_wall.append(wall_hist[_idx])
        ret_angle.append(angles_adjusted_d[_idx])

    q_angles_hist_reverse = 360 - np.array(list(reversed(ret_angle)))
    rotate_idx = find_rotate_angle(ret_angle, angle_split)
    rotate_idx_reverse = find_rotate_angle(q_angles_hist_reverse, angle_split)

    # 序列化
    ret_area_serialized = serialize_hist(ret_area)
    ret_wall_serialized = serialize_hist(ret_wall)
    ret_towards_serialized = serialize_hist(ret_towards)
    ret_door_exist_serialized = serialize_hist(ret_door_exist)
    ret_window_exist_serialized = serialize_hist(ret_window_exist)
    ret_area_type_serialized = serialize_hist(ret_area_type)
    # angles_f, areas_f, towards_f, door_exist_f, window_exist_f, area_type_f, ret_wall_f
    areas_fd, areas_fft, inv_areas_fft = fft_coeff_descriptor(ret_area)
    ret_door_exist_vec = (np.array(ret_door_exist) != 0).astype(int)
    ret_window_exist_vec = (np.array(ret_window_exist) != 0).astype(int)
    ret_door_window_exist_vec = np.clip(1*ret_door_exist_vec + 0.5*ret_window_exist_vec, 0, 1)
    door_fd, door_fft, inv_door_fft = fft_coeff_descriptor(ret_door_exist_vec)
    window_fd, window_fft, inv_window_fft = fft_coeff_descriptor(ret_window_exist_vec)
    door_window_fd, door_window_fft, inv_door_window_fft = fft_coeff_descriptor(ret_door_window_exist_vec)
    ret_dict = {'angles': [list(rotate_idx), list(rotate_idx_reverse)],
                'areas': ret_area_serialized, 'areas_fd': list((areas_fd*1000).astype(int)),
                'towards': ret_towards_serialized,
                'door_exist': ret_door_exist_serialized, 'door_fd': list((door_fd*1000).astype(int)),
                'window_exist': ret_window_exist_serialized, 'window_fd': list((window_fd*1000).astype(int)),
                'door_window_fd': list((door_window_fd*1000).astype(int)),
                'area_type': ret_area_type_serialized,
                'wall': ret_wall_serialized}
    return ret_dict


def find_interval(val, _line_offset_arr):
    """
    找到当前值所在的间隔
    :param val:
    :param _line_offset_arr:
    :return:
    """
    if not _line_offset_arr:
        return
    start, end, top_entity = _line_offset_arr[-1]
    if val < start:
        return
    else:
        if start <= val <= end:
            return top_entity
        else:
            _line_offset_arr.pop()
            return find_interval(val, _line_offset_arr)


def get_direction(angle):
    """
    将角度转换成方向
    :param angle:
    :return:
    """
    if angle is not None:
        angle %= 360
        if angle >= 330 or angle <= 30:
            return ENTRANCE_TOWARDS[u'north']
        elif 30 < angle < 60:
            return ENTRANCE_TOWARDS[u'north-east']
        elif 60 <= angle <= 120:
            return ENTRANCE_TOWARDS[u'east']
        elif 120 < angle < 150:
            return ENTRANCE_TOWARDS[u'south-east']
        elif 150 <= angle <= 210:
            return ENTRANCE_TOWARDS[u'south']
        elif 210 < angle < 240:
            return ENTRANCE_TOWARDS[u'south-west']
        elif 240 <= angle <= 300:
            return ENTRANCE_TOWARDS[u'west']
        elif 300 < angle < 330:
            return ENTRANCE_TOWARDS[u'north-west']
        return ENTRANCE_TOWARDS['default']
    else:
        return angle


def find_init_point_line(line_dict):
    """
    找到起始item
    规则: 入户门 > 公共区域门 > 一般门 > 长附件 > 短附件
    :param line_dict:
    :return: 起点line_id, item_id
    """
    l_item_arr = []
    for _points_cp_key, _line in line_dict.items():
        _items = _line['items']
        area_detail_type_list = _line.get('area_detail_type', list)
        _is_face_public = int(not PUBLIC_DETAIL_TYPE.isdisjoint(set(area_detail_type_list)))
        for _item in _items:
            item_id = _item.get('item_id')
            _item_len = _item.get('length')
            _item_type = _item.get('type')

            _is_entrance = int(_item.get('is_entrance', False))
            _is_door = int(_item_type in DOOR_TYPE)
            l_item_arr.append([_points_cp_key, item_id, _is_entrance, _is_face_public, _is_door, _item_len])
    if l_item_arr:
        sort_line_items = sorted(l_item_arr, key=lambda x: (x[2], x[3], x[4], x[5]), reverse=True)
        ret_points_cp_key, ret_item_id, _, _, _, _ = sort_line_items[0]
    else:
        ret_points_cp_key, _ = line_dict.popitem()
        ret_item_id = None
    return ret_points_cp_key, ret_item_id


def bay_window_detect(line_offset_array, item_offset_array, door_offset, polygon_pts, center_pt, params, order_line=True):
    """
    飘窗检测规则 & 整理
    如果存在两面小于800的侧墙以及一个主墙有窗, 可以认为是飘窗
    -->D-                A----->-----
        |                |
      3 |                | 1
        |                |
        C->-****2******->B
    :param line_offset_array:
    :param item_offset_array:
    :param door_offset:
    :param polygon_pts:
    :param center_pt:
    :param params:
    :param order_line: 是否修改原数组进行飘窗合并
    :return:
    """
    is_bay_window = False
    if len(line_offset_array) < 3:
        # 小于3面墙不检测
        return is_bay_window, line_offset_array, item_offset_array, door_offset, polygon_pts

    pt_a = polygon_pts[-1]
    pt_d = polygon_pts[-4]

    start_1, end_1, line_1 = line_offset_array[-1]
    line_1_len = line_1['len']
    line_1_pts = line_1['points']
    line_1_area_type = line_1['area_type']

    start_2, end_2, line_2 = line_offset_array[-2]
    line_2_len = line_2['len']
    line_2_pts = line_2['points']
    line_2_items = line_2['items']
    line_2_area_type = line_1['area_type']

    start_3, end_3, line_3 = line_offset_array[-3]
    line_3_len = line_3['len']
    line_3_pts = line_3['points']
    line_3_area_type = line_1['area_type']

    # 飘窗只能在室, 厅中
    if (not SHI_TING_TYPE.isdisjoint(line_1_area_type)) and (not SHI_TING_TYPE.isdisjoint(line_2_area_type)) \
            and (not SHI_TING_TYPE.isdisjoint(line_3_area_type)):
        bay_side_line_len = params.get("bay_window_line_len", 800)
        # 如果侧边窗不超过 800
        if line_1_len < bay_side_line_len and line_3_len < bay_side_line_len:
            v1 = (line_1_pts[1][0] - line_1_pts[0][0], line_1_pts[1][1] - line_1_pts[0][1])
            v2 = (line_2_pts[1][0] - line_2_pts[0][0], line_2_pts[1][1] - line_2_pts[0][1])
            v3 = (line_3_pts[1][0] - line_3_pts[0][0], line_3_pts[1][1] - line_3_pts[0][1])
            angle_1_2 = np.degrees(np.abs(atan2_dist(v1, v2)))
            angle_2_3 = np.degrees(np.abs(atan2_dist(v2, v3)))
            # 第二条线有附件
            if line_2_items:
                # 计算两条线之间的夹角 都是90度
                if abs(angle_1_2 - 90.0) < 2.0 and abs(angle_2_3 - 90.0) < 2.0:
                    l_2_string = LineString(line_2_pts)
                    center_a_string = LineString([center_pt, pt_a])
                    center_d_string = LineString([center_pt, pt_d])
                    a_not_cross_2 = not center_a_string.crosses(l_2_string)
                    d_not_cross_2 = not center_d_string.crosses(l_2_string)
                    # 凹窗检测, 检查重心和A,B转角连线是否存在与2线相交
                    if a_not_cross_2 and d_not_cross_2:
                        is_bay_window = True
                        # 是否需要重新整理已经合并的线
                        if order_line:
                            new_item = {'type': '7', 'start_index': pt_d, 'start': 0, 'length': line_2_len}
                            new_line = copy.deepcopy(line_2)
                            new_line['line_points'] = (pt_d, pt_a)
                            _a_d_line = LineString([pt_d, pt_a])
                            new_line['line_center'] = (_a_d_line.centroid.x, _a_d_line.centroid.y)
                            new_line['len'] = _a_d_line.length
                            new_line['items'] = [new_item]
                            line_offset_array = line_offset_array[:-3]
                            line_offset_array.append((start_3, start_3 + line_2_len, new_line))
                            # 找到在a点起始之前的附件全部清除.
                            dump_item_idx = len(item_offset_array)
                            for _it_start, _it_end, _it in item_offset_array[::-1]:
                                if _it_start >= start_3:
                                    dump_item_idx -= 1
                                else:
                                    break
                            item_offset_array = item_offset_array[:dump_item_idx]
                            item_offset_array.append((start_3, start_3 + line_2_len, new_item))
                            polygon_pts = polygon_pts[:-3]
                            polygon_pts.append(pt_a)
                            door_offset = end_1
    return is_bay_window, line_offset_array, item_offset_array, door_offset, polygon_pts


def edge_walk(edge_points_dict, floor_points_to_line_map, center_pt, params):
    """
    户型(分间)轮廓游走算法:
    1. 从入户门所在墙体的第一个端点为起点作为合并墙体的起始点(墙体).
    2. 迭代寻找当前尾节点的下一个节点(头尾相接).
    3. 记录墙体, 附件边界距离

    处理细节:
    1. 飘窗检测, 如果存在两面小于800的侧墙以及一个主墙有窗, 可以认为是飘窗

    :param edge_points_dict: 记录边界, {角点: set({})}
    :param floor_points_to_line_map: 直接用坐标索引的字典, {point: line dict()}
    :param center_pt: 中心点
    :param params: 配置
    :return: line_offset_array: [(起点, 终点, 墙体)], item_offset_array: [(起点, 终点, 附件所在墙体)],
             door_offset: 整个户型周长, polygon_pts: 户型多边形的顺序点集
    """
    # 初始化返回值
    line_offset_array = []
    item_offset_array = []
    polygon_pts = []
    door_offset = 0

    triplet_dict_len = len(edge_points_dict)
    if triplet_dict_len < 3:
        # 如果小于3面墙返回空
        return line_offset_array, item_offset_array, door_offset, polygon_pts

    triplet_dict_cp = copy.deepcopy(edge_points_dict)
    (to_x, to_y), _pts = triplet_dict_cp.popitem()
    # 任意pop一个当起点
    from_x, from_y = _pts.pop()
    init_line_points = [(from_x, from_y), (to_x, to_y)]

    # 初始化起始线段
    assert not (round(from_x) == round(to_x) and round(from_y) == round(to_y)), 'start equals end fail'
    init_line = floor_points_to_line_map[((from_x, from_y), (to_x, to_y))]
    init_line_len = init_line['len']
    line_offset_array.append((0, init_line_len, init_line))
    door_offset += init_line_len
    init_items = init_line['items']
    for _it in init_items:
        _it_start = _it['start']
        _it_length = _it['length']
        item_offset_array.append((_it_start, _it_start + _it_length, _it))
    # 不加from留给最后一个
    polygon_pts.append((from_x, from_y))
    polygon_pts.append((to_x, to_y))

    existed_set = set(polygon_pts)
    is_over = False
    for i in range(triplet_dict_len + 1):
        if is_over:
            break
        next_point_set = edge_points_dict[(to_x, to_y)]
        for tmp_next_point in next_point_set:
            if tmp_next_point not in existed_set:
                next_x, next_y = tmp_next_point
                break
        if (next_x, next_y) in existed_set:
            is_over = True
            next_x, next_y = init_line_points[0]
        _line = floor_points_to_line_map[((to_x, to_y), (next_x, next_y))]
        _line_len = _line['len']
        _items = _line['items']
        for _it in _items:
            _it_start = _it['start']
            _it_length = _it['length']
            _it_type = _it['type']
            item_offset_array.append((door_offset + _it_start, door_offset + _it_start + _it_length, _it))
        line_offset_array.append((door_offset, door_offset + _line_len, _line))
        polygon_pts.append((next_x, next_y))
        existed_set.add((next_x, next_y))
        # 飘窗检测调整
        bay_window_detect(line_offset_array, item_offset_array, door_offset, polygon_pts, center_pt, params)
        to_x, to_y = next_x, next_y
        door_offset += _line_len
    return line_offset_array, item_offset_array, door_offset, polygon_pts


def cos_dist(v_1, v_2):
    tmp_norm = v_1.dot(v_2) / (np.linalg.norm(v_1) * np.linalg.norm(v_2))
    if abs(tmp_norm) > 1:
        tmp_norm = np.sign(tmp_norm)*1.0
    return np.degrees(math.acos(tmp_norm))


def atan2_dist(v1, v2):
    """
    计算角度差
    两个向量夹角绝对值的差: [-pi, pi]
    :param v1:
    :param v2:
    :return:
    """
    dot = v1[0] * v2[0] + v1[1] * v2[1]
    det = v1[0] * v2[1] - v1[1] * v2[0]
    angle = math.atan2(det, dot)
    return angle


def square_dist(p1, p2):
    return (p1[0]-p2[0])**2 + (p1[1]-p2[1])**2


def euclidean_dist(p1, p2):
    return math.sqrt(square_dist(p1, p2))


def triangle_area(x1, y1, x2, y2, x3, y3):
    """
    计算三角形面积
    :param x1:
    :param y1:
    :param x2:
    :param y2:
    :param x3:
    :param y3:
    :return:
    """
    return abs(0.5*(x1*(y2-y3)+x2*(y3-y1)+x3*(y1-y2)))


def quadratic(a, b, c):
    """
    解二元一次方程
    :param a:
    :param b:
    :param c:
    :return:
    """
    p = b*b - 4*a*c
    if abs(p-0.0) <= 1.0e-3:
        p = abs(p)
    if p >= 0 and a != 0:
        x1 = (-b+math.sqrt(p))/(2*a)
        x2 = (-b-math.sqrt(p))/(2*a)
        return x1, x2
    elif a == 0:
        x1 = -c/b
        return x1, x1
    else:
        raise Exception('quadratic math error, a: {}, b: {}, c: {}'.format(a, b, c))


def get_cycle_radius_co(p):
    """
    获取圆形坐标
    :param p:(起点坐标, 结束坐标), 弧高
    :return:x,y,弧长
    """
    p1 = p[0]
    p2 = p[1]
    h_not_positive = (p[2] <= 0.0)
    h = abs(p[2])
    # 圆半径
    half_p = ((p1[0] + p2[0])/2, (p1[1] + p2[1])/2)
    half_d = math.sqrt((p1[0]-half_p[0])**2+(p1[1]-half_p[1])**2)
    r = (half_d**2 + h**2)/(2*h)
    k = 0
    if (p1[0]-half_p[0]) != 0:
        if (p1[1]-half_p[1]) == 0:
            c_x = half_p[0]
            if h_not_positive:
                c_y = half_p[1] + (r-h)
            else:
                c_y = half_p[1] - (r-h)
            return c_x, c_y, r
        ori_k = (p1[1]-half_p[1])/(p1[0]-half_p[0])
        k = -1/ori_k
    b_offset = half_p[1]-k*half_p[0]
    # 圆心坐标
    d_h = r-h
    a = 1+k**2
    b = 2*(k*b_offset-half_p[0]-k*half_p[1])
    c = half_p[0]**2 + half_p[1]**2 + b_offset*b_offset - 2*b_offset*half_p[1] - d_h*d_h
    center_candidate = quadratic(a, b, c)

    c_x_min = min(center_candidate)
    c_x_max = max(center_candidate)
    c_y_min = k*c_x_min + b_offset
    c_y_max = k*c_x_max + b_offset

    if p1[0] == p2[0]:
        if h_not_positive:
            c_x = c_x_max
            c_y = c_y_max
        else:
            c_x = c_x_min
            c_y = c_y_min

    else:
        slope_ori = (p1[1] - p2[1])/(p1[0] - p2[0])
        if slope_ori > 0:
            if h_not_positive:
                c_x = c_x_min
                c_y = c_y_min
            else:
                c_x = c_x_max
                c_y = c_y_max
        elif slope_ori < 0:
            if h_not_positive:
                c_x = c_x_max
                c_y = c_y_max
            else:
                c_x = c_x_min
                c_y = c_y_min
        else:
            if h_not_positive:
                if c_y_min > c_y_max:
                    c_y = c_y_min
                    c_x = c_x_min
                else:
                    c_y = c_y_max
                    c_x = c_x_max
            else:
                if c_y_min < c_y_max:
                    c_y = c_y_min
                    c_x = c_x_min
                else:
                    c_y = c_y_max
                    c_x = c_x_max
    return c_x, c_y, r


def get_cycle_radius(p, sample_cnt=8):
    """
    获取圆弧上采样的点
    :param p: (起点坐标, 结束坐标), 弧高
    :param sample_cnt: 采样数目
    :return:
    """
    p1 = p[0]
    p2 = p[1]
    c_x, c_y, r = get_cycle_radius_co(p)
    # 角度
    angle_1 = math.atan2(p1[1] - c_y, p1[0] - c_x) / math.pi * 180
    angle_2 = math.atan2(p2[1] - c_y, p2[0] - c_x) / math.pi * 180
    v_1 = np.array([c_x - p1[0], c_y - p1[1]])
    v_2 = np.array([c_x - p2[0], c_y - p2[1]])
    angle_dist = cos_dist(v_1, v_2)
    # 分隔点数
    if p[2] > 0:
        start_angle = angle_1
        end_angle = angle_2
    else:
        start_angle = angle_2
        end_angle = angle_1
    if start_angle < end_angle:
        start_angle += 360
    ret_array = []
    x_s = []
    y_s = []
    for _a in np.arange(start_angle, end_angle, -angle_dist / sample_cnt):
        _x = c_x + r * math.cos(_a * math.pi / 180)
        _y = c_y + r * math.sin(_a * math.pi / 180)
        ret_array.append((_x, _y))
        x_s.append(round(_x, 0))
        y_s.append(round(_y, 0))
    arc_len = 2*r*angle_dist * math.pi / 360
    return x_s, y_s, arc_len


def extract_file_no(file_name):
    """
    获取文件名中frame_id
    :param file_name:
    :return:
    """
    return re.findall("\d+", file_name)[0]


def get_files(path, file_type):
    """
    Get files
    :param path:
    :param file_type:
    :return:
    """
    files = []
    ids = []
    for root, dirs, tmp_files in os.walk(path):
        for i in tmp_files:
            if i.endswith(file_type):
                files.append(os.path.join(path,i))
                ids.append(str(extract_file_no(i)))
    return files, ids


def find_rotate_angle(angles_hist, split=8):
    """

    :param angles_hist:
    :param split:
    :return:
    """
    if type(angles_hist) is not np.ndarray:
        angles_hist = np.array(angles_hist)
    _arr_step = (angles_hist.shape[0] + 1)//split
    angle_arr = np.arange(0, len(angles_hist), _arr_step)
    angle_idx_arr = []
    for _angle in angle_arr[:-1]:
        dist_arr = np.argmin(np.abs(angles_hist - _angle))
        angle_idx_arr.append(dist_arr)
    return np.array(angle_idx_arr)


def hist_dist(q, c, func, rotate_idx, reverse_flag=False):
    """
    比较转圈的距离大小
    :param q:
    :param c:
    :param func: 距离函数
    :param rotate_idx: 指定角度的array idx
    :param reverse_flag: 是否反向
    :return:
    """
    if reverse_flag:
        q = q[::-1]
    if type(q) is not np.ndarray:
        q = np.array(q)
    if type(c) is not np.ndarray:
        c = np.array(c)
    d = np.tile(q, (len(rotate_idx), 1))
    d_shifted = d[:, (np.arange(d.shape[1]) + np.array(rotate_idx).reshape((-1, 1))) % d.shape[1]]
    diff = func(d_shifted[0], c)
    return diff


def area_hist_func(a, b):
    """
    面积直方图距离
    如果阳台未匹配上, 加权误差.
    :param a:
    :param b:
    :return:
    """
    sign_a = np.signbit(a)
    sign_b = np.signbit(b)
    diff = np.abs(np.abs(a) - np.abs(b))
    # 负数代表阳台, 阳台误差惩罚加权
    diff[sign_a | sign_b] *= BALCONY_ITEM_DIFF_COST
    return np.sum(diff, axis=1)


def item_hist_func(a, b):
    return np.sum(np.abs(a - b), axis=1)


def area_type_hist_func(a, b):
    c = np.abs(a ^ b)
    ret = F_BIN_V(c)
    return np.sum(ret, axis=1)


def towards_hist_func(a, b):
    sign_a = np.signbit(a)
    sign_b = np.signbit(b)
    diff = np.abs(np.abs(a) - np.abs(b))
    over_idx = (diff >= TOWARDS_DIFF_THRESHOLD)
    diff[over_idx] = 1
    diff[~over_idx] = 0
    # 负数代表阳台, 阳台误差惩罚加权
    diff[sign_a | sign_b] *= BALCONY_ITEM_DIFF_COST
    return np.sum(diff, axis=1)


def item_rule_func(a_arr, b):
    """
    附件自定义的规则距离
    1. 如果两个户型有任意的一段在阳台上, 两段都不计算误差.
    2. group by a的item count b的item. 每个a的item可能会对应多个b的item,
       那么选出匹配数量最多的那个作为匹配的b附件.
       0不会参与抢附件, 例如 0/2->4, 1/2->3 这种情况只会记录窗户误差4,
       但是会认为1/2已经匹配上.
    3. 计算除了匹配上的a-b附件之外的所有a附件采样点数之和.
    :param a_arr: 经过不同角度旋转
    :param b:
    :return:
    """
    mismatch_arr = []
    mismatch_item_cnt = []
    for a in a_arr:
        ab_df = pd.DataFrame({'a': a, 'b': b, 'exist': np.ones(len(a), dtype=int)})
        ab_group_df = ab_df.groupby(by=['a', 'b']).count()
        ab_group_df_sorted = ab_group_df.sort_values(by='exist', ascending=False)
        a_idx_set = set([_x for _x in ab_df.a if _x > 0])
        b_idx_set = set([_x for _x in ab_df.b if _x > 0])
        mismatch_a = 0
        mismatch_b = 0
        exited_set_a, exited_set_b = set(), set()
        for _ab_group in ab_group_df_sorted.iterrows():
            a_idx, b_idx = _ab_group[0]
            if a_idx in exited_set_a or b_idx in exited_set_b:
                continue
            _cnt = _ab_group[1].values[0]
            if a_idx != 0 and b_idx != 0:
                exited_set_a.add(a_idx)
                exited_set_b.add(b_idx)
                a_idx_set -= exited_set_a
                b_idx_set -= exited_set_b
            elif a_idx == 0 < b_idx:
                mismatch_b += _cnt
            elif b_idx == 0 < a_idx:
                mismatch_a += _cnt
            # else 小于0为阳台模糊匹配
        mismatch_arr.append(mismatch_a + mismatch_b)
        mismatch_item_cnt.append(len(a_idx_set) + len(b_idx_set))
    return mismatch_arr, mismatch_item_cnt


def hamming_dist(a, b):
    return bin(a ^ b).count('1')


def extract_batch_feature(file_path, res_path, params, file_type='json'):
    """
    提取目录下所有轮廓特征
    :param file_path:
    :param res_path:
    :param params:
    :param file_type:
    :return:
    """
    from multiprocessing import Pool
    feature_name2type = [('realsee_id', str), ('floor_plan_dict', str), ('json_str', str)]
    feature_names_lst = [content[0] for content in feature_name2type]
    files, ids = get_files(file_path, file_type)
    ret_arr = []
    group_runner_cpu = params.get('runner_cpu', 5)
    pool = Pool(group_runner_cpu)
    ret_list = []
    try:
        for _file, _id in zip(files, ids):
            with open(_file, 'r', encoding='UTF-8') as f:
                _json_str = f.read()
            ret_list.append(pool.apply_async(get_floor_plan_contour_feature, (_id, _json_str, params)))
        pool.close()
        pool.join()
        for _thread_ret in ret_list:
            f_id, floor_plan_dict = _thread_ret.get()
            if floor_plan_dict:
                # 只读第一层平面图
                frame_contour = floor_plan_dict[0]
                dump_dict = frame_contour.dump()
                dump_dict_str = json.dumps(dump_dict, cls=contour_entity.ContourJsonEncoder)
                ret_arr.append([f_id, dump_dict_str, _json_str])
    except Exception as e:
        logging.exception(e)
        print('ERROR _id:{}'.format(_id))
    df_extracted_feature = pd.DataFrame(data=ret_arr, columns=feature_names_lst)
    df_extracted_feature.to_csv(res_path, index=None, header=None, sep='\t')


def all_dist_compare(q_contour, c_contour, params, reverse=False):
    """
    :param q_contour:
    :param c_contour:
    :param params:
    :param reverse:
    :return:
    """
    feature_len = params.get('sample', None)
    feature_len -= 1

    top_1_list = list()
    q_area_size = q_contour['area_size']
    q_angles_hist_index = q_contour['angles_hist']
    q_areas_hist_ori = q_contour['areas_hist']
    q_area_type_hist_ori = q_contour['area_type_hist']
    q_window_exist_hist_ori = q_contour['window_exist_hist']
    q_door_exist_hist_ori = q_contour['door_exist_hist']
    q_towards_hist_ori = q_contour['towards_hist']
    q_entrance_angle = q_contour['entrance_angle']

    c_areas_hist_ori = c_contour['areas_hist']
    c_area_type_hist_ori = c_contour['area_type_hist']
    c_window_exist_hist_ori = c_contour['window_exist_hist']
    c_door_exist_hist_ori = c_contour['door_exist_hist']
    c_towards_hist_ori = c_contour['towards_hist']
    c_entrance_angle = c_contour['entrance_angle']

    q_areas_hist = deserialize_hist(q_areas_hist_ori, feature_len)
    q_area_type_hist = deserialize_hist(q_area_type_hist_ori, feature_len)
    q_area_type_hist = q_area_type_hist.astype(int)

    q_window_exist_hist = deserialize_hist(q_window_exist_hist_ori, feature_len)
    q_door_exist_hist = deserialize_hist(q_door_exist_hist_ori, feature_len)
    q_towards_hist = deserialize_hist(q_towards_hist_ori, feature_len)

    c_areas_hist = deserialize_hist(c_areas_hist_ori, feature_len)
    c_area_type_hist = deserialize_hist(c_area_type_hist_ori, feature_len)
    c_area_type_hist = c_area_type_hist.astype(int)

    c_window_exist_hist = deserialize_hist(c_window_exist_hist_ori, feature_len)
    c_door_exist_hist = deserialize_hist(c_door_exist_hist_ori, feature_len)
    c_towards_hist = deserialize_hist(c_towards_hist_ori, feature_len)

    # 计算旋转角度的index
    rotate_idx = q_angles_hist_index[0]
    if reverse:
        rotate_idx = q_angles_hist_index[1]

    towards_diff_all = hist_dist(q_towards_hist, c_towards_hist, towards_hist_func, rotate_idx, reverse)
    min_towards_diff_all = np.min(towards_diff_all)
    if min_towards_diff_all / feature_len > params.get('towards_diff', 0.2):
        return top_1_list

    areas_diff_all = hist_dist(q_areas_hist, c_areas_hist, area_hist_func, rotate_idx, reverse)
    areas_diff_all = areas_diff_all / q_area_size / 1e6
    min_areas_diff_all = np.min(areas_diff_all)
    if min_areas_diff_all > params.get('areas_diff', 0.3):
        return top_1_list

    window_diff_all, window_cnt_diff = hist_dist(q_window_exist_hist, c_window_exist_hist, item_rule_func, rotate_idx, reverse)
    min_window_diff_all = np.min(window_diff_all)
    min_window_cnt_diff_all = np.min(window_cnt_diff)
    if min_window_cnt_diff_all > params.get('window_cnt_diff', 2):
        return top_1_list
    if min_window_diff_all/feature_len > params.get('window_diff', 0.2):
        return top_1_list

    door_diff_all, door_cnt_diff = hist_dist(q_door_exist_hist, c_door_exist_hist, item_rule_func, rotate_idx, reverse)
    min_door_diff_all = np.min(door_diff_all)
    min_door_cnt_diff_all = np.min(door_cnt_diff)
    if min_door_cnt_diff_all > params.get('door_cnt_diff', 2):
        return top_1_list
    if min_door_diff_all/feature_len > params.get('door_diff', 0.2):
        return top_1_list

    area_type_diff_all = hist_dist(q_area_type_hist, c_area_type_hist, area_type_hist_func, rotate_idx, reverse)
    # 入户门朝向
    entrance_angle = 1
    if reverse:
        reverse_val = -1
    else:
        reverse_val = 1
    try:
        final_dist_tuple = np.vstack((window_diff_all, door_diff_all,
                                      window_cnt_diff, door_cnt_diff,
                                      towards_diff_all,
                                      areas_diff_all, area_type_diff_all)).T
        final_dist_tuple_pad = np.pad(final_dist_tuple, ((0, 0), (1, 2)),
                                      'constant', constant_values=(0, (reverse_val, entrance_angle)))
    except Exception as e:
        print(e)
    feature_names_lst = params['feature_names_lst']
    _df = pd.DataFrame(data=final_dist_tuple_pad, columns=feature_names_lst)
    _df['score'] = (_df['window'] + 1)*(_df['door'] + 1)*(_df['window_cnt'] + 1)*(_df['door_cnt'] + 1)*_df['areas']
    _df = _df.sort_values(['score', 'areas'])
    rotate_idx = _df.index[0] + 1
    # 入户门朝向相等
    if q_entrance_angle == c_entrance_angle:
        entrance_angle = 0
    _df['entrance_angle'] = entrance_angle
    _df = _df.reset_index()
    _df['rotate'] = _df['rotate'] * rotate_idx
    top_1_list = list(_df.loc[0, ['score', 'window', 'door', 'window_cnt', 'door_cnt',
                                  'towards', 'areas', 'area_type', 'rotate', 'entrance_angle']].values)
    return top_1_list


def find_top_n_single(df_query, df_candidates, params):
    """
    :param df_query:
    :param df_candidates:
    :param params: 参数
    :return: 返回对应room_type的匹配值
            {area_id:id, area_size: size,
            item:[(id, area_id, size, score)],
            area_hist:(id, area_id, size, score, reverse_score)}, ...}
    """
    n = params.get('topN', 20)
    feature_names_lst = params['feature_names_lst']
    q_id = df_query.q_id
    query_contour = df_query.floor_plan_dict
    q_area_id_dict = query_contour['area_id_dict']

    all_res_dict = dict()
    for _q_are_id, q_area_contour in q_area_id_dict.items():
        q_room_type = q_area_contour['room_type']
        q_area_size = q_area_contour['area_size']
        q_edge_len = q_area_contour['edge_len']

        res_dict = dict()
        all_res_dict[_q_are_id] = res_dict
        res_dict['area_id'] = _q_are_id
        res_dict['room_type'] = q_room_type
        res_dict['area_size'] = q_area_size
        res_dict['all_dist'] = dict()

        for c_id, c_r in df_candidates.iterrows():
            c_contour = c_r.floor_plan_dict
            c_area_id_dict = c_contour['area_id_dict']
            for _c_are_id, c_area_contour in c_area_id_dict.items():
                c_room_type = c_area_contour['room_type']
                if c_room_type == q_room_type:
                    c_area_size = c_area_contour['area_size']
                    c_edge_len = c_area_contour['edge_len']
                    if abs(q_area_size - c_area_size)/q_area_size > params.get('area_size', 0.2):
                        continue
                    if abs(q_edge_len - c_edge_len)/q_edge_len > params.get('edge_len', 0.2):
                        continue
                    # print('q_area_size:{}, c_area_size:{}----------'.format(q_area_size, c_area_size))
                    dist_tuple = all_dist_compare(q_area_contour, c_area_contour, params)
                    # 逆时针
                    dist_tuple_reverse = all_dist_compare(q_area_contour, c_area_contour, params, reverse=True)
                    top_1_list = []
                    if dist_tuple and dist_tuple_reverse:
                        final_dist_arr = [dist_tuple, dist_tuple_reverse]
                        _df = pd.DataFrame(data=final_dist_arr, columns=feature_names_lst)
                        _df['score'] = (_df['window'] + 1)*(_df['door'] + 1)*(_df['towards'] + 1)*_df['areas']
                        _df = _df.sort_values(['score']).reset_index()
                        top_1_list = list(_df.loc[0, ['score', 'window', 'door', 'towards', 'areas', 'area_type', 'rotate']].values)
                    elif not dist_tuple and dist_tuple_reverse:
                        top_1_list = dist_tuple_reverse
                    elif dist_tuple and not dist_tuple_reverse:
                        top_1_list = dist_tuple
                    if top_1_list:
                        res_dict['all_dist'][(c_id, c_room_type, _c_are_id, c_area_size)] = tuple(top_1_list)
    # sort top n
    ret_dict = dict()
    for q_area_id, _res_dict in all_res_dict.items():
        q_room_type = _res_dict['room_type']
        q_area = _res_dict['area_size']
        all_dist_dict = _res_dict['all_dist']
        sorted_dict = sorted(all_dist_dict.items(), key=lambda x: (x[1][0]))
        ret_dict[(q_room_type, q_area, q_area_id)] = sorted_dict[:n]
    print('q_id:{} done'.format(q_id))
    return q_id, ret_dict


def is_over_threshold(v_1, v_2, threshold):
    """
    阈值判断
    :param v_1:
    :param v_2:
    :param threshold:
    :return:
    """
    _v_1, _v_2 = abs(v_1), abs(v_2)
    if _v_1 + _v_2 == 0:
        return False
    return abs(_v_1 - _v_2) / abs((_v_1 + _v_2) / 2) > threshold


def find_frame_top_n_single(res_df_query, res_df_candidates, params):
    """
    :param res_df_query:
    :param res_df_candidates:
    :param params: 参数
    :return: 返回对应room_type的匹配值
            {area_id:id, area_size: size,
            item:[(id, area_id, size, score)],
            area_hist:(id, area_id, size, score, reverse_score)}, ...}
    """
    n = params.get('topN', 20)
    feature_names_lst = params['feature_names_lst']
    _q_id = res_df_query.uuid
    q_frame_contour = res_df_query.floor_plan_dict

    q_area_size = q_frame_contour['area_size']
    q_area_size_without_line = q_frame_contour['area_size_without_line']
    q_edge_len = q_frame_contour['edge_len']

    res_dict = dict()
    res_dict['area_size'] = q_area_size
    res_dict['all_dist'] = dict()

    for _c_id, _c_row in res_df_candidates.iterrows():
        if _q_id == _c_id:
            continue
        c_frame_contour = _c_row.floor_plan_dict

        c_area_size = c_frame_contour['area_size']
        c_area_size_without_line = c_frame_contour['area_size_without_line']
        c_edge_len = c_frame_contour['edge_len']
        if q_area_size_without_line > 1 and c_area_size_without_line > 1:
            if is_over_threshold(q_area_size_without_line, c_area_size_without_line, params.get('area_size', 0.03)):
                continue
        else:
            if is_over_threshold(q_area_size, c_area_size, params.get('area_size', 0.03)):
                continue
        if is_over_threshold(q_edge_len, c_edge_len, params.get('edge_len', 0.15)):
            continue
        dist_tuple = all_dist_compare(q_frame_contour, c_frame_contour, params)
        # 逆时针
        dist_tuple_reverse = all_dist_compare(q_frame_contour, c_frame_contour, params, reverse=True)
        top_1_list = []
        if dist_tuple and dist_tuple_reverse:
            final_dist_arr = [dist_tuple, dist_tuple_reverse]
            _df = pd.DataFrame(data=final_dist_arr, columns=feature_names_lst)
            _df['score'] = (_df['window'] + 1)*(_df['door'] + 1)*(_df['window_cnt'] + 1)*(_df['door_cnt'] + 1)*_df['areas']
            _df = _df.sort_values(['score']).reset_index()
            top_1_list = list(_df.loc[0, ['score', 'window', 'door', 'window_cnt', 'door_cnt',
                                          'towards', 'areas', 'area_type', 'rotate', 'entrance_angle']].values)
        elif not dist_tuple and dist_tuple_reverse:
            top_1_list = dist_tuple_reverse
        elif dist_tuple and not dist_tuple_reverse:
            top_1_list = dist_tuple
        if top_1_list:
            res_dict['all_dist'][_c_id] = tuple(top_1_list)
    # sort top n
    all_dist_dict = res_dict['all_dist']
    sorted_dict = sorted(all_dist_dict.items(), key=lambda x: (x[1][0]))
    print('q_id:{} done'.format(_q_id))
    return _q_id, sorted_dict[:n]


def find_frame_top_n_batch(query_file, candidate_file, res_file, params):
    """
    找户型最佳匹配
    :param query_file:
    :param candidate_file:
    :param res_file:
    :param params:
    :return:
    """
    from multiprocessing import Pool
    feature_name2type = [('uuid', str), ('floor_plan_dict', str), ('json_str', str)]
    feature_names_lst = [content[0] for content in feature_name2type]
    # 加载候选集
    df_candidate = pd.read_table(candidate_file, header=None, sep='\t', encoding='gbk',
                                 names=feature_names_lst, dtype=dict(feature_name2type))
    df_candidate['json_str'] = ''
    df_candidate['floor_plan_dict'] = df_candidate['floor_plan_dict'].apply(json.loads)
    df_candidate.set_index('uuid', inplace=True, drop=False)

    # 加载查询集
    df_query = copy.deepcopy(df_candidate)
    # df_query = pd.read_table(query_file, header=None, sep='\t', encoding='gbk',
    #                          names=feature_names_lst, dtype=dict(feature_name2type))
    # df_query['floor_plan_dict'] = df_query['floor_plan_dict'].apply(json.loads)
    # df_query['json_str'] = ''
    # df_query.set_index('uuid', inplace=True, drop=False)
    # DEBUG
    # df_query = df_query.sample(frac=0.01, random_state=58)

    cols = [('score', float), ('window', int), ('door', int), ('window_cnt', int), ('door_cnt', int),
            ('towards', int), ('areas', int), ('area_type', int), ('rotate', int), ('entrance_angle', int)]
    feature_names_lst = [content[0] for content in cols]
    params['feature_names_lst'] = feature_names_lst

    group_runner_cpu = params.get('runner_cpu', 5)
    q_list = []
    pool = Pool(group_runner_cpu)
    for q_id, q_r in df_query.iterrows():
        # if q_id not in ('1120025013270569'):
        #     continue
        q_list.append(pool.apply_async(find_frame_top_n_single, (q_r, df_candidate, params)))
    pool.close()
    pool.join()
    logging.info('Thread Finished... ')

    final_pandas_array = []
    for thread_ret in q_list:
        q_id, c_sorted_list = thread_ret.get()
        if c_sorted_list:
            for c_id, dist_tuple in c_sorted_list:
                _score, window_diff, door_diff, window_cnt_diff, door_cnt_diff, \
                towards_diff, areas_diff, area_type_diff, rotate_diff, entrance_diff = dist_tuple
                final_pandas_array.append([q_id, c_id, _score,
                                           window_diff, door_diff, window_cnt_diff, door_cnt_diff,
                                           towards_diff, areas_diff,
                                           area_type_diff, rotate_diff, entrance_diff])

    feature_name2type = [('q_id', str),
                         ('c_id', str), ('score', float),
                         ('window_diff', int), ('door_diff', int),
                         ('window_cnt_diff', int), ('door_cnt_diff', int),
                         ('towards_diff', int),
                         ('areas_diff', int), ('area_type_diff', int), ('rotate_diff', int), ('entrance_diff', int)]
    feature_names_lst = [content[0] for content in feature_name2type]
    df_extracted_feature = pd.DataFrame(data=final_pandas_array, columns=feature_names_lst)
    df_extracted_feature.to_csv(res_file + '.txt', index=None, header=None, sep='\t')
    df_extracted_feature.to_csv(res_file, index=None, sep=',')


def find_frame_top_n_batch_spark(candidate_file, res_file, params):
    """
    找户型最佳匹配
    :param candidate_file:
    :param res_file:
    :param params:
    :return:
    """
    feature_name2type = [('frame_id', str), ('image_id', str), ('city_code', str),
                         ('resblock_id', str), ('map_cnt', int), ('build_area', float),
                         ('t_shi', int), ('t_ting', int), ('t_chu', int), ('t_wei', int), ('t_yang', int),
                         ('is_vr', int), ('entrance', int), ('plans_len', int),
                         ('edge_len', float), ('plans_area', float), ('mass_layout', str),
                         ('mass_layout_geo', str), ('log_hu', str), ('w_log_hu', str), ('area_vec', str),
                         ('floors', str), ('error', int), ('is_valid', int)]
    feature_names_lst = [content[0] for content in feature_name2type]
    # 加载候选集
    df_raw = pd.read_table(candidate_file, header=None, sep='\t', encoding='gbk',
                           names=feature_names_lst, dtype=dict(feature_name2type))
    df_raw['floors'] = df_raw['floors'].apply(json.loads)
    df_raw.set_index('frame_id', inplace=True, drop=False)

    result_name2type = [('frame_id', str),
                        ('image_id', str),
                        ('city_code', str),
                        ('resblock_id', str),

                        ('res_contour_id', str),
                        ('res_layout_id', str),
                        ('res_area_id', str),
                        ('res_rept_id', str),
                        ('res_rotate_idx', str),

                        ('city_rept_id', str),
                        ('city_rotate_idx', str),
                        ('city_layout_id', str),
                        ('city_area_id', str),

                        ('error', int),
                        ('is_valid', int)]


def layout_label(row_1, row_2, params):
    """
    分间排布是否在阈值内
    :return:
    """
    dist_vec_1 = row_1['dist_vec']
    dist_vec_2 = row_2['dist_vec']
    if len(dist_vec_1) != len(dist_vec_2):
        return False
    area_pass_2 = threshold_ruler(dist_vec_1, dist_vec_2, params['dist_any_threshold'], params['dist_sum_threshold'])
    if not area_pass_2:
        return False
    return True


def threshold_ruler(vec_1, vec_2, threshold_any, threshold_sum):
    """
    对分间排布, 面积向量做阈值判断
    :return:
    """
    try:
        if vec_1.shape != vec_2.shape:
            return False
        delta = np.abs(vec_1 - vec_2)/((vec_1 + vec_2)/2 + 0.0000001)
        if (delta > threshold_any).any():
            return False
        v_sum_1, v_sum_2 = np.sum(np.abs(vec_1)), np.sum(np.abs(vec_2))
        if abs(v_sum_1 - v_sum_2)/(np.mean([v_sum_1, v_sum_2]) + 0.0000001) > threshold_sum:
            return False
    except Exception as w:
        print(w)
    return True


def get_group_rep(rows):
    """
    选出组代表

    与挂接量最多的标准图重复的 是否有装修方案→VR标准图→挂接量最多的标准图→挂接量存在一致的情况下,
    选择组中居室数量占比最多的标准图（例如组中80%均为2居室,则选择一致挂接量中的2居室）
    :param rows:
    :return:组代表户型row
    """
    if len(rows) == 1:
        return rows[0]
    frame_sort_feature = []
    frame_type_counter = collections.Counter([])
    for row in rows:
        tmp_frame = "{}{}{}{}".format(row.t_shi, row.t_ting, row.t_chu, row.t_wei)
        tmp_vr = contour_entity.VRCode.not_vr
        if row.is_vr == contour_entity.VRCode.is_vr:
            tmp_vr = contour_entity.VRCode.is_vr
        tmp_map_cnt = row.map_cnt
        tmp_has_plan = row.has_plan
        frame_type_counter.update([tmp_frame])
        frame_sort_feature.append((row, tmp_has_plan, tmp_vr, tmp_map_cnt, tmp_frame))
    frame_sort_feature = [(tmp_row, tmp_has_plan, tmp_vr, tmp_map_cnt, frame_type_counter[tmp_frame])
                          for tmp_row, tmp_has_plan, tmp_vr, tmp_map_cnt, tmp_frame in frame_sort_feature]
    sorted_feature = sorted(frame_sort_feature, key=lambda a: (a[1], a[2], a[3], a[4]), reverse=True)
    return sorted_feature[0][0]


def single_dynamic_runner(uid, df_by_uid, label_col_name, group_func, params):
    """
    单维度分组-动态分组
    选一个未入组的遍历剩下的, 看谁能入组.
    :param uid:
    :param df_by_uid:
    :param label_col_name: 标签列名
    :param group_func: 分组规则函数
    :param params:
    :return:
    """
    try:
        df_by_uid = df_by_uid.copy()
        # 保存所有的户型id set
        list_frame_ids = list(df_by_uid.frame_id.values)
        existed_frame_set = set(list_frame_ids)
        # 保存成组关系
        frame_rep_dict = collections.defaultdict(list)
        # 记录本次循环中成组的户型id
        current_existed_frame_set = set([])

        current_anchor_frame_id = list_frame_ids[0]
        row_anchor = df_by_uid.loc[current_anchor_frame_id]
        # 初始化组关系
        frame_rep_dict[current_anchor_frame_id] = [row_anchor]
        current_existed_frame_set.add(current_anchor_frame_id)
        # 目前未入组的
        existed_frame_set_in = (existed_frame_set - current_existed_frame_set)
        while len(existed_frame_set_in) > 0:
            for tmp_frame_id in existed_frame_set_in:
                row_candidate = df_by_uid.loc[tmp_frame_id]
                # 规则函数
                tmp_dist = group_func(row_anchor, row_candidate, params)
                if tmp_dist:
                    tmp_frame_rep_arr = frame_rep_dict[current_anchor_frame_id]
                    tmp_frame_rep_arr.append(row_candidate)
                    new_rept_frame_row = get_group_rep(tmp_frame_rep_arr)
                    new_rept_frame_id = new_rept_frame_row.frame_id
                    if new_rept_frame_id != current_anchor_frame_id:
                        # 如果有新的组代表, 替换为新的.
                        anchor_group = frame_rep_dict.pop(current_anchor_frame_id)
                        current_anchor_frame_id = new_rept_frame_id
                        row_anchor = row_candidate
                        frame_rep_dict[current_anchor_frame_id] = anchor_group
                    current_existed_frame_set.add(tmp_frame_id)
            # 如果没有找到当前的原改, 保证一定可以去掉当前的比较户型(因为已经比过所有的了)
            existed_frame_set_in = existed_frame_set - current_existed_frame_set
            if not existed_frame_set_in:
                break
            current_anchor_frame_id = existed_frame_set_in.pop()
            row_anchor = df_by_uid.loc[current_anchor_frame_id]
            frame_rep_dict[current_anchor_frame_id] = [row_anchor]
            current_existed_frame_set.add(current_anchor_frame_id)
        group = 0
        ret_row_arr = []
        for rept_id, row_arr in frame_rep_dict.items():
            _tmp_row_arr = []
            for _row in row_arr:
                _row = _row.copy()
                _row[label_col_name] = group
                _tmp_row_arr.append(_row)
            ret_row_arr.extend(_tmp_row_arr)
            frame_rep_dict[rept_id] = _tmp_row_arr
            group += 1
        ret_row_df = pd.DataFrame(ret_row_arr)
    except Exception as e:
        logging.debug('complete resblock: {}'.format(uid))
        logging.exception(e)
        raise e
    return uid, frame_rep_dict, ret_row_df


def find_top_n_batch(query_file, candidate_file, res_file, params):
    """
    找分间最佳匹配
    :param query_file:
    :param candidate_file:
    :param res_file:
    :param params:
    :return:
    """
    from multiprocessing import Pool
    feature_name2type = [('q_id', str), ('floor_plan_dict', str), ('json_str', str)]
    feature_names_lst = [content[0] for content in feature_name2type]
    # 加载候选集
    df_candidate = pd.read_table(candidate_file, header=None, sep='\t', encoding='gbk',
                                 names=feature_names_lst, dtype=dict(feature_name2type))
    df_candidate['json_str'] = ''
    df_candidate['floor_plan_dict'] = df_candidate['floor_plan_dict'].apply(json.loads)
    df_candidate.set_index('q_id', inplace=True, drop=False)

    # 加载查询集
    df_query = pd.read_table(query_file, header=None, sep='\t', encoding='gbk',
                             names=feature_names_lst, dtype=dict(feature_name2type))
    df_query['floor_plan_dict'] = df_query['floor_plan_dict'].apply(json.loads)
    df_query['json_str'] = ''
    df_query.set_index('q_id', inplace=True, drop=False)
    # DEBUG
    # df_query = df_query.sample(frac=0.05, random_state=58)

    cols = [('score', int), ('window', int), ('door', int), ('towards', int), ('areas', int), ('area_type', int), ('rotate', int)]
    feature_names_lst = [content[0] for content in cols]
    params['feature_names_lst'] = feature_names_lst

    group_runner_cpu = params.get('runner_cpu', 5)
    q_list = []
    pool = Pool(group_runner_cpu)
    for q_id, q_r in df_query.iterrows():
        q_list.append(pool.apply_async(find_frame_top_n_single, (q_r, df_candidate, params)))
    pool.close()
    pool.join()
    logging.info('Thread Finished... ')

    final_pandas_array = []
    for thread_ret in q_list:
        q_id, _score_dict = thread_ret.get()
        for q_id_tuple, c_sorted_list in _score_dict.items():
            (q_room_type, q_area_size, q_area_id) = q_id_tuple
            if c_sorted_list:
                for c_id_tuple, dist_tuple in c_sorted_list:
                    window_diff, door_diff, towards_diff, areas_diff, area_type_diff, rotate_diff = dist_tuple
                    c_id, c_room_type, c_are_id, c_area_size = c_id_tuple
                    final_pandas_array.append([q_id, q_room_type, q_area_id, q_area_size,
                                               c_id, c_room_type, c_are_id, c_area_size,
                                               window_diff, door_diff, towards_diff, areas_diff,
                                               area_type_diff, rotate_diff])

    feature_name2type = [('q_id', str), ('q_room_type', str), ('q_area_id', str), ('q_area_size', float),
                         ('c_id', str), ('c_room_type', str), ('c_are_id', str), ('c_area_size', float),
                         ('window_diff', int), ('door_diff', int), ('towards_diff', int),
                         ('areas_diff', int), ('area_type_diff', int), ('rotate_diff', int)]
    feature_names_lst = [content[0] for content in feature_name2type]
    df_extracted_feature = pd.DataFrame(data=final_pandas_array, columns=feature_names_lst)
    df_extracted_feature.to_csv(res_file+'.txt', index=None, header=None, sep='\t')
    df_extracted_feature.to_csv(res_file, index=None, sep=',')


def extract_frame_batch_feature(file_path, res_path, params):
    feature_name2type = [('frame_id', str), ('image_id', str), ('house_id', str),
                         ('city_code', str), ('resblock_id', str), ('map_cnt', int),
                         ('build_area', float), ('json_str', str), ('is_valid', str)]
    feature_names_lst = [content[0] for content in feature_name2type]
    df_curve = pd.read_table(file_path, header=None, sep='\t',
                             names=feature_names_lst, dtype=dict(feature_name2type))
    df_curve.fillna('-1', inplace=True)
    df_curve.set_index('frame_id', inplace=True, drop=False)
    # debug
    # df_curve = df_curve.sample(frac=0.1)

    feature_name2type = [('frame_id', str), ('floor_plan_dict', str), ('json_str', str)]
    feature_names_lst = [content[0] for content in feature_name2type]
    ret_arr = []
    group_runner_cpu = params.get('runner_cpu', 1)
    from multiprocessing import Pool
    # pool = Pool(group_runner_cpu)
    ret_list = []
    params['cal_room_type_set'] = set(['100900000004', '100900000003', '100900000005'])
    params['max_rectangle_ratio'] = 0.2
    try:
        for _frame_id, _row in df_curve.iterrows():
            # if _frame_id not in ('1120026710705717', '1111699794227799'):
            #     continue
            _json_str = _row.json_str
            get_room_cluster_feature(_frame_id, json.loads(_json_str), params)
            # ret_list.append(pool.apply_async(get_floor_plan_contour_feature, (_frame_id, _json_str, params)))
            # ret_list.append(pool.apply_async(get_floor_plan_contour_feature_spark, (_row, params)))
        # pool.close()
        # pool.join()
        for _thread_ret in ret_list:
            ret_arr = _thread_ret.get()
            print('\t'.join(ret_arr))
    except Exception as e:
        logging.exception(e)
        print('ERROR _id:{}'.format(_frame_id))


def combine_all_frame(df_path, img_path, df=None):
    if df is None:
        feature_name2type = [('q_id', str),
                             ('c_id', str), ('score', float),
                             ('window_diff', int), ('door_diff', int),
                             ('window_cnt_diff', int), ('door_cnt_diff', int),
                             ('towards_diff', int),
                             ('areas_diff', float), ('area_type_diff', int), ('rotate_diff', int), ('entrance_diff', int)]
        feature_names_lst = [content[0] for content in feature_name2type]
        df = pd.read_table(df_path, header=None, sep='\t', encoding='gbk',
                           names=feature_names_lst, dtype=dict(feature_name2type))
        df.set_index('q_id', inplace=True, drop=False)
    existed_ids = set()
    group_set_arr = []
    for q_id, row in df.iterrows():
        c_id = row.c_id
        if q_id in existed_ids and c_id in existed_ids:
            continue
        # if row.window_cnt_diff == 0 and row.door_cnt_diff == 0 \
        #         and row.towards_diff < 30 and row.window_diff < 10 and row.door_diff < 10:
        if row.window_cnt_diff == 0 and row.door_cnt_diff == 0 \
                and row.towards_diff < 30 and row.rotate_diff == 1 and row.entrance_diff == 0:
            is_not_find = True
            for group_set in group_set_arr:
                if q_id in group_set or c_id in group_set:
                    group_set.update([q_id, c_id])
                    is_not_find = False
                    break
            if is_not_find:
                group_set_arr.append(set([q_id, c_id]))
    for _g_set in group_set_arr:
        print(_g_set)
    pass


def main():
    resblock_id = '1111027378138'
    # resblock_id = '001015'
    resblock_id_shorthand = resblock_id[-4:]

    parent_path = './data/contour'
    # parent_path_candidate = 'floorplan-test'
    parent_path_candidate = 'floorplans'
    parent_path_resblock = 'resblock'
    parent_path_query = 'allfloorplan'

    params = {
        'runner_cpu': 1,
        'sample': 360,
        'angle_split': 8,
        'topN': 20,
        'area_size': 0.35,
        'edge_len': 0.15,
        'window_diff': 0.1,
        'door_diff': 0.1,
        'window_cnt_diff': 2,
        'door_cnt_diff': 2,
        'towards_diff': 0.1,
        'areas_diff': 0.25,
        'with_room_hist': True
    }

    resblock_path = os.path.join(parent_path, parent_path_resblock)
    resblock_ret_path = os.path.join(resblock_path, 'resblock_feature_{}.txt'.format(resblock_id_shorthand))
    resblock_source_path = './data/mod/mod_{}.txt'.format(resblock_id)
    extract_frame_batch_feature(resblock_source_path, resblock_ret_path, params)
    resblock_top_res_path = os.path.join(parent_path, parent_path_resblock,
                                         'top_floor_plan_feature_{}.csv'.format(resblock_id_shorthand))

    # find_frame_top_n_batch_spark(find_frame_top_n_batch, resblock_ret_path, resblock_top_res_path, params)
    # find_frame_top_n_batch(find_frame_top_n_batch, resblock_ret_path, resblock_top_res_path, params)

    # combine_all_frame(resblock_top_res_path + '.txt', '')

    # candidate_path = os.path.join(parent_path, parent_path_candidate)
    # candidate_res_path = os.path.join(parent_path, 'candidate_floor_plan_feature.txt')
    #
    # query_path = os.path.join(parent_path, parent_path_query)
    # query_res_path = os.path.join(parent_path, 'query_floor_plan_feature.txt')
    #
    # extract_batch_feature(candidate_path, candidate_res_path, params)
    # logging.info('candidate done...')
    # # extract_batch_feature(query_path, query_res_path, params)
    # # logging.info('query done...')
    # top_res_path = os.path.join(parent_path, 'top_floor_plan_feature.csv')
    # find_top_n_batch(query_res_path, candidate_res_path, top_res_path, params)

    # main()
    logging.info('END...')
    pass


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG, format='%(asctime)s %(levelname)s %(message)s')
    logging.info('START...')
    main()

