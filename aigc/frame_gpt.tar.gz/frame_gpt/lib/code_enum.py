#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2018 www.ke.com, Inc. All Rights Reserved
"""
编码与键命名
Authors: yudonghai@ke.com
Date:    2019/01/08
"""
from __future__ import division
import enum


# 分间类型
class AreaType(enum.Enum):
    other = '100900000012'
    parlour = '100900000002'
    room = '100900000001'
    toilet = '100900000004'
    kitchen = '100900000003'
    balcony = '100900000005'
    terrace = '100900000006'
    storage = '100900000008'
    cloakroom = '100900000013'
    loft = '100900000011'
    garden = '100900000007'
    garage = '100900000010'
    babysitter = '100900000009'


# 装修分间类型
class DecorationAreaType(enum.Enum):
    main_room = "main_room"
    main_toilet = "main_toilet"
    sub_room = "sub_room"
    parlour = "parlour"
    kitchen = "kitchen"
    toilet = "toilet"
    parlour_toilet = "parlour_toilet"
    dinning_room = "dinning_room"
    other_toilet = "other_toilet"
    other = "other"


# 新房分间类型
class NewhouseAreaType(enum.Enum):
    main_room = "main_room"
    sub_room = "sub_room"
    parlour = "parlour"
    dinning_room = "dinning_room"
    kitchen = "kitchen"
    main_toilet = "main_toilet"
    parlour_toilet = "parlour_toilet"
    other_toilet = "other_toilet"
    other = "other"


# 户型解析状态码
class State(enum.Enum):
    valid = 0                                   # 有效
    lack_field = 1                              # 缺少字段
    invalid_json_format = 2                     # 矢量数据格式错误
    lack_plan_data = 3                          # 缺失 层 对应的数据
    empty_plan = 4                              # 空的 层 数据
    invalid_plan_data = 5                       # 层 中缺少点、墙体、墙体附件、分间中的任意一种
    illegal_point_lack_key = 6                  # 点 缺少必要键
    illegal_point_empty = 7                     # 空的 点 数据
    illegal_point_diff_line = 8                 # 点对应的墙体不在墙体字典中
    illegal_line_lack_key = 9                   # 墙体 缺少必要键
    illegal_line_lack_point = 10                # 组成墙体的点少于2个
    illegal_line_diff_point = 11                # 墙体对应的点不在点字典中
    illegal_line_item_lack_key = 12             # 墙体附件缺少必要键
    illegal_line_item_diff_line = 13            # 墙体附件对应的墙体不在墙体字典中
    illegal_area_lack_key = 14                  # 分间缺少必要键
    illegal_area_diff_point = 15                # 分间对应的点不在店字典中
    illegal_area_lack_attach_key = 16           # 分间缺少邻接关键字
    illegal_area_lack_attach_area_key = 17      # 分间邻接缺少分间
    illegal_area_diff_shared_line_item = 18     # 分间共享墙体附件不在墙体附件字典中
    illegal_area_diff_shared_line = 19          # 分间共享墙体不在墙体字典中
    illegal_area_lack_attach_lineItem_key = 20  # 分间邻接墙体附件缺少必要键
    illegal_area_diff_attach_line_item = 21     # 分间邻接的墙体附件不在墙体附件字典中
    illegal_area_lack_attach_line_key = 22      # 分间邻接墙体缺少必要键
    illegal_area_diff_attach_line = 23          # 分间邻接的墙体不在墙体字典中
    liner_error = 24                            # 动线解析出错
    layout_out_range = 25                       # 动线解析出错
    unknown_exception = 26                      # 未知而被捕获的异常
    img_lack = 27                               # 文案缺少图片
    score_fail = 28                             # 打分失败
    lack_entrance = 29                          # 缺少入户门
    attach_area_direction_none = 30             # 分间邻接分间方向为None
    border_wrong = 31                           # 提取四至坐标错误


# 围成分间的点的类型
class PointType(object):
    window_start = 0b1 << 0         # 窗开始点
    window_end = 0b1 << 1           # 窗结束点
    in_line = 0b1 << 2              # 墙体连接点
    corner = 0b1 << 3               # 拐角点
    divergence = 0b1 << 4           # 三叉点
    repeat = 0b1 << 5               # 回文点，合并分间时会出现，需要删除
    entrance_start = 0b1 << 6       # 入户门开始点
    entrance_end = 0b1 << 7         # 入户门结束点
    door_start = 0b1 << 8           # 门开始点
    door_end = 0b1 << 9             # 门结束点
    oblique_corner = 0b1 << 10      # 锐角/钝角点
    concave = 0b1 << 11             # 凹点
    convex = 0b1 << 12              # 凸点
    other_start = 0b1 << 13         # 其他墙体附件起点
    other_end = 0b1 << 14           # 其他墙体附件终点


# 卫生间标签
class ToiletLabel(object):
    sep = 0b1 << 0                  # 干湿分离
    private = 0b1 << 1              # 私卫
    face_entrance = 0b1 << 2        # 正对入户门
    face_kitchen = 0b1 << 3         # 正对厨房
    face_room = 0b1 << 4            # 正对卧室


# 卧室标签
class RoomLabel(object):
    with_toilet = 0b1 << 0          # 带卫生间
    with_cloakroom = 0b1 << 1       # 带衣帽/储物间
    with_balcony = 0b1 << 2         # 带阳台
    face_others = 0b1 << 3          # 与其他卧室对视
    face_toilet = 0b1 << 4          # 与卫生间相对
    neighbor_kitchen = 0b1 << 5     # 与厨房相邻
    face_entrance = 0b1 << 6        # 正对入户门


# 户型全局检测点标签
class FramePLabel(object):
    with_menting = 0b1 << 0             # 配置门厅
    parlour_with_balcony = 0b1 << 1     # 客厅配置阳台
    with_dining_room = 0b1 << 2         # 独立餐厅
    parlour_with_dining = 0b1 << 3      # 客餐厅相连
    cooking_area = 0b1 << 4             # 独立烹饪区
    kitchen_with_dining = 0b1 << 5      # 厨房餐厅相连
    kitchen_with_balcony = 0b1 << 6     # 厨房与生活阳台相连
    french_window = 0b1 << 7            # 有落地窗
    with_garden = 0b1 << 8              # 带花园
    with_loft = 0b1 << 9                # 带阁楼
    with_terrace = 0b1 << 10            # 带露台
    kitchen_with_entrance = 0b1 << 11   # 厨房近入户门


# 通透类型
class TransType(object):
    both_face = 0b1 << 0            # 双向
    neighbour_face = 0b1 << 1       # 邻向
    single_face = 0b1 << 2          # 单向


# 户型朝向类型
class FaceType(object):
    north_south = 0b1 << 0          # 南北
    south = 0b1 << 1                # 南
    east = 0b1 << 2                 # 东
    west = 0b1 << 3                 # 西
    north = 0b1 << 4                # 北

# ###########################################
# ############ 户型方正相关枚举值 ############


# 缺角位置标记，由 AxisFace 中的的值相加得到
class EmptyLocation(enum.Enum):
    bottom_left = 5
    top_left = 9
    upper_right = 10
    bottom_right = 6
    none = 0


# x,y坐标轴上的两端标记，保证 x 与 y 的不同组合值的和各不相同
class AxisFace(enum.Enum):
    left = 1
    right = 2
    bottom = 4
    upper = 8
    horizontal_mid = 16
    vertical_mid = 32


# 水平方向
HORIZONTAL_ORI = [AxisFace.bottom.value, AxisFace.upper.value]
# 竖直方向
VERTICAL_ORI = [AxisFace.left.value, AxisFace.right.value]

# 户型缺角位置与对应的找缺角极值函数
EMPTY_ANGLE_FIND_MAP = {
    EmptyLocation.bottom_left.value: (min, min),
    EmptyLocation.bottom_right.value: (max, min),
    EmptyLocation.upper_right.value: (max, max),
    EmptyLocation.top_left.value: (min, max)
}
# ################### end ###################
# ###########################################


# ###########################################
# ############ line item 相关枚举值 ############

# 飘窗 lineItem 类型
# 普通飘窗，落地飘窗，普通单面飘窗，落地单面飘窗
BAY_WINDOW_TYPES = {7, 11, 17, 18}
CONVEX_BAY_WINDOW_TYPES = {7, 11}

# 落地窗 LineItem 类型
# 落地窗
FRENCH_WINDOW_TYPES = {8}

# "带"相关标签的连通门的 lineItem 类型，单开门，推拉门，双开门，子母门，垭口
CONN_DOOR_TYPES = {0, 1, 2, 3, 16}

# 垭口
YAKOU = 16

# ################### end ###################
# ###########################################


# ###########################################
# ############## line 相关枚举值 ##############
# 通透墙 line 类型，虚拟墙和栅栏
TRANS_WALL_TYPE = {3, 5}

# 计入朝向的墙体 line 类型; 玻璃落地墙，栅栏，玻璃墙
OUT_WALL_TYPE = {4, 5, 6}

# 玻璃落地墙 line
GLASS_FRENCH_TYPE = 4

# ################### end ###################
# ###########################################


# ###########################################
# ############## area 相关枚举值 ##############

# 全明户型 area roomType 类型
ALL_WINDOW_ROOM_TYPES = {
    AreaType.room.value,
    AreaType.parlour.value,
    AreaType.kitchen.value,
    AreaType.toilet.value,
    AreaType.balcony.value,
    AreaType.terrace.value
}

# 有朝向的连接分间 roomType 类型
OUT_ROOM_TYPE = {
    AreaType.balcony.value,
    AreaType.garden.value,
    AreaType.terrace.value
}

# 通过过道关联的卧室、衣帽间、卫生间 roomType 类型
PASSAGE_INDIRECT_TYPES = {
    AreaType.toilet.value,
    AreaType.room.value,
    AreaType.cloakroom.value,
    AreaType.balcony.value,
    AreaType.storage.value
}

# '静'区分间类型
QUIET_ROOM_TYPES = {
    AreaType.room.value,
    AreaType.babysitter.value,
    AreaType.cloakroom.value
}

# 户型方正不考虑的分间类型
INVALID_AREA_TYPES = {
    AreaType.garden.value,
    AreaType.balcony.value,
    AreaType.loft.value,
    AreaType.garage.value
}

# 二期户型方正异形不考虑的分间类型
SQUARE_EXCEPT_TYPES = {
    AreaType.garden.value,
    AreaType.parlour.value,
    AreaType.loft.value,
    AreaType.terrace.value
}

# 全明户型不考虑的area type 类型
INVALID_ALL_WINDOW_TYPES = {
    2,      # 餐厅
    25,     # 门厅
    23,     # 过道
    # 5,      # 卫生间
    # 6,      # 淋浴间
    7       # 洗手间
}

# 开放厨房 area type 类型
OPEN_KITCHEN_TYPE = 9

# 过道 area type
GUODAO = 23
# 门厅
MEN_TING = 25
# 餐厅
DINING_ROOM = 2
# 客厅、起居室、共享大厅
REAL_PARLOUR = {1, 37, 44}

# ################### end ###################
# ###########################################


# ############################################
# ############### 标准矢量图通用键 ###############

# 重构的数据字典键
POINTS_DICT_KEY = "points_dict"
LINES_DICT_KEY = "lines_dict"
LINE_ITEMS_DICT_KEY = "line_items_dict"
AREAS_DICT_KEY = "areas_dict"
ROTATE_POINTS_DICT_KEY = "rotate_points_dict"

# 层 数据中的键
PLAN_AREAS_KEY = "areas"
PLAN_POINTS_KEY = "points"
PLAN_LINES_KEY = "lines"
PLAN_LINE_ITEMS_KEY = "lineItems"
PLAN_ITEMS_KEY = "items"

# 墙体附件 中的键
LINE_ITEM_TYPE_KEY = "type"
LINE_ITEM_LINE_KEY = "line"
LINE_ITEM_ID_KEY = "id"
LINE_ITEM_START_INDEX_KEY = "startIndex"
LINE_ITEM_START_KEY = "start"
LINE_ITEM_LENGTH_KEY = "length"

# 墙体 中的键
LINE_ID_KEY = "id"
LINE_TYPE_KEY = "type"
LINE_POINTS_KEY = "points"
LINE_CURVE_KEY = "curve"
LINE_ITEMS_KEY = "items"

# 点 中的键
POINT_ID_KEY = "id"
POINT_LINES_KEY = "lines"

# 分间中的键
AREA_ROOM_TYPE_KEY = "roomType"
AREA_TYPE_KEY = "type"
AREA_ATTACHMENTS_KEY = "attachments"
AREA_ID_KEY = "id"
AREA_POINTS_KEY = "points"
AREA_SIZE_KEY = "size"
AREA_EMPTY_KEY = "empty"
AREA_ROOM_NAME_KEY = "roomName"

# 分间 attachments 元素中的键
ATTACH_AREAS_KEY = "areas"
ATTACH_LINE_ITEMS_KEY = "lineItems"
ATTACH_LINE_ITEM_ID_KEY = "id"
ATTACH_AREA_ID_KEY = "id"
ATTACH_AREA_ROOM_TYPE_KEY = "roomType"
ATTACH_LINES_KEY = "lines"
ATTACH_LINE_ID_KEY = "id"

# 其他
SHARED_LINE_ITEMS_KEY = "sharedLineItems"
SHARED_LINES_KEY = "sharedLines"
DIRECTION_KEY = "direction"
EDGE_KEY = "edge"
EDGE_COMP_KEY = "edgeComputed"
LENGTH_KEY = "length"
TYPE_IS_KEY = "is"
ENTRANCE_KEY = "entrance"
X = "x"
Y = "y"
SUB_TYPE = "subType"

LABEL_KEY = "label"
LABEL_TYPE_KEY = "type"
LABEL_DATA_KEY = "data"
ROOM_CNT_KEY = "room_cnt"
LABEL_STR_KEY = "label_str"

# 分间附属结构属性
ATTACH_KEYS = [ATTACH_LINE_ITEMS_KEY, ATTACH_LINES_KEY, ATTACH_AREAS_KEY]
# 分间附属的墙体附件属性(外墙标记，方向，长度，类型，id)
EDLII = [EDGE_KEY, DIRECTION_KEY, LENGTH_KEY, TYPE_IS_KEY, ATTACH_LINE_ITEM_ID_KEY]
# 分间附属的墙体属性(方向，长度，id)
DLI = [DIRECTION_KEY, LENGTH_KEY, ATTACH_LINE_ID_KEY]
# 每层数据字典（点，墙体附件，墙体，分间）
DICTS = [POINTS_DICT_KEY, LINE_ITEMS_DICT_KEY, LINES_DICT_KEY, AREAS_DICT_KEY]
# 分间属性(ID， 点序列，类型，子类型，面积)
IPTTS = [AREA_ID_KEY, AREA_POINTS_KEY, AREA_ROOM_TYPE_KEY, AREA_TYPE_KEY, AREA_SIZE_KEY]
# 墙体属性(类型，点列表，墙体附件列表)
LTPT = [LINE_TYPE_KEY, LINE_POINTS_KEY, LINE_ITEMS_KEY]

# 分间附属墙体附件 is 属性值
IS_DOOR = "door"
IS_WINDOW = "window"
IS_OTHER = "other"

# ################### end ###################
# ###########################################


# ###########################################
# ################ 自定义通用键 ################
# 分间点类型键
CKEY_POINT_TYPE = "p_type"
# 朝向南向关键字
CKEY_SOUTH = "south"
CKEY_NORTH = "north"
CKEY_WEST = "west"
CKEY_EAST = "east"

# 静区
EXPLAIN_QUIET_ROOMS = "explain_quiet_rooms"
# 动区
EXPLAIN_MOVING_ROOMS = "explain_moving_rooms"
# 墙体对应的分间列表
EXPLAIN_LINE_AREAS = "explain_line_areas"
# 入户门信息
EXPLAIN_ENTRANCE = "explain_entrance"
# 面宽进深信息
EXPLAIN_WIDTH_DEPTH = "explain_width_depth"
# 朝向
EXPLAIN_FACE = "explain_face"
# 面积
EXPLAIN_SIZE = "explain_size"
# 墙体
EXPLAIN_WALL = "explain_wall"  # [分间点列表, 斜墙标记, 最大连续墙体, 分间墙列表, 入户门朝向向量]
# 门窗
EXPLAIN_WINDOW_DOOR = "explain_window_door"
# 卫生间
EXPLAIN_TOILET = "explain_toilet"
# 卧室
EXPLAIN_ROOM = "explain_room"
# 厨房
EXPLAIN_KITCHEN = "explain_kitchen"
# 客厅
EXPLAIN_PARLOUR = "explain_parlour"
# 户型单个特征
EXPLAIN_FRAME = "explain_frame"
# 户型总体特征
EXPLAIN_WHOLE_FRAME = "explain_whole_frame"
# 打分字典
EXPLAIN_POINT_VALUE_DICT = "explain_point_value_dict"
# 文案参数
EXPLAIN_VARS = "explain_vars"
# base message
EXPLAIN_BASE_MESSAGE = "explain_base_message"
# liner message
EXPLAIN_LINER = "explain_liner"
# 动线，可视域
EXPLAIN_VISUAL = "explain_visual"
# 多层时的有效层的动线可视域
EXPLAIN_REAL_LINER = "explain_real_liner"
# 动线，可视域
EXPLAIN_REAL_VISUAL = "explain_real_visual"
# 分间标签
AREA_LABEL = "area_label"
# 分间正对入户门距离
AREA_FACE_EN = "area_face_en"
# 卫生间正对厨房
TOILET_FACE_KITCHEN = "toilet_face_kitchen"
# 卫生间正对卧室
TOILET_FACE_ROOM = "toilet_face_room"

# 带阳台
WITH_BALCONY = "with_balcony"
# 靠近餐厅
WITH_DINNING = "with_dinning"
# 靠近入户门
WITH_ENTRANCE = "with_entrance"


# ################### end ###################
# ###########################################

# ###########################################
# ################## 常用值 ##################
# 墙体对应的分间列表
# 5度余弦值
COSIN_5 = 0.996195
# 85度余弦值
COSIN_85 = 0.087156
# 拐角点两侧边围城四边形面积最小值，太小认为不是有效拐角点
CORNER_LINE_AREA = 900
# 朝向向量在法向量列表中的位置
FACE_NORM_LINE_INDEX = 2
# 计算最大墙长度、是否有斜墙时考虑的点类型
KEY_POINT_TYPE = PointType.corner | PointType.divergence \
                 | PointType.window_start | PointType.window_end \
                 | PointType.door_start | PointType.door_end \
                 | PointType.other_start | PointType.other_end
# 墙体附件点类型
LINE_ITEM_POINT_TYPE = PointType.window_start | PointType.window_end \
                 | PointType.door_start | PointType.door_end \
                 | PointType.other_start | PointType.other_end
# 门类型，单个点
DOORS_TYPE = PointType.door_start | PointType.entrance_start | PointType.other_start

# 正对门计算考虑的点类型(门及入户门）
FACE_DOOR_POINT_TYPE = PointType.door_start | PointType.door_end | PointType.entrance_start | PointType.entrance_end
# 斜墙最小长度
OBLIQUE_LEN = 1000
# 主朝向的墙体间距离最大值，大于时策略删除超过阈值的
MAIN_FACE_DIFF = 1500
# 主朝向墙体最小长度，
# 当出现主朝向上墙体分散时也考虑删除小于此阈值的墙体
MIN_FACE_LEN = 910
# 进深计算墙体在法线两侧时的判断阈值
DEPTH_TH = 1000
# 门位面积因子
DOOR_MUL = 500
# 凸窗两肩错开距离阈值
CONVEX_WINDOW_BASE_DIFF = 455
# 凸窗包含窗户最小数量
CONVEX_WINDOW_WINDOW_CNT = 2
# 凸窗宽度最大阈值
CONVEX_WINDOW_WIDTH = 910
# 正对两门的最大距离阈值
FACE_DIST = 5000
# 独立烹饪区最小面积
COOKING_SIZE = 4000000.
# 户型朝向窗长度最小限制
FRAME_FACE_LEN = 600
# 可将光线传递给相邻分间的窗地比阈值
OUT_AREA_WDF_TH = 0.5
# 默认窗高(mm)
DEFAULT_WINDOW_H = 1500.
# 认为是靠近入户门的曼哈顿距离阈值
CLOSED_ENTRANCE_DIST = 3000.
# 门正对时允许交错的距离
FACE_DOOR_DIFF = 200
# 卧室门开向客厅判断时，门所在墙最短长度
MIN_WALL_LEN = 800 * 2

# ################### end ###################
# ###########################################


# ###########################################
# ################## 标签值 ##################
LABEL_DICT = {
    "nothing":                  (0, ""),
    "movement_clear":	        (0b1 << 0, "动静分明"),
    "separate_toilet":	        (0b1 << 1, "干湿分离"),
    "kitchen_window":	        (0b1 << 2, "明厨"),
    "toilet_window":	        (0b1 << 3, "明卫"),
    "north_south_trans":	    (0b1 << 4, "南北通透"),
    "all_window":	            (0b1 << 5, "全明格局"),
    "south_bedroom":	        (0b1 << 6, "卧室朝南"),
    "bedroom_toilet":	        (0b1 << 7, "卧室带卫"),
    "all_south":	            (0b1 << 8, "全南户型"),
    "south_parlour":	        (0b1 << 9, "客厅朝南"),
    "square":	                (0b1 << 10, "户型方正"),
    "bay_window":	            (0b1 << 11, "观景飘窗"),
    "french_window":	        (0b1 << 12, "观景落地窗"),
    "open_kitchen":	            (0b1 << 13, "开放厨房"),
    "bedroom_balcony":	        (0b1 << 14, "卧室带阳台"),
    "good_lighting":	        (0b1 << 15, "采光好"),
    "high_use_ratio":	        (0b1 << 16, "户型利用率高"),
    "good_geomancy":	        (0b1 << 17, "风水好"),
    "good_active_line":	        (0b1 << 18, "动线合理"),
    "garden":	                (0b1 << 19, "带花园"),
    "loft":	                    (0b1 << 20, "带阁楼"),
    "bedroom_cloakroom":	    (0b1 << 21, "卧室带衣帽间"),
    "area_logical":	            (0b1 << 22, "分间面积合理"),
    "terrace":	                (0b1 << 23, "露台"),
    "kitchen_face_toilet":	    (0b1 << 24, "厨卫对门"),
    "bedroom_bay_window":	    (0b1 << 25, "卧室有飘窗"),
    "bedroom_french_window":    (0b1 << 26, "卧室有落地窗"),
    "parlour_bay_window":	    (0b1 << 27, "客厅有飘窗"),
    "parlour_french_window":	(0b1 << 28, "客厅有落地窗"),
    "parlour_balcony":	        (0b1 << 29, "客厅带阳台"),
    "cloakroom":                (0b1 << 30, "带衣帽间"),
}

LABEL_NOTHING = "nothing"
LABEL_MOVEMENT_CLEAR = "movement_clear"
LABEL_SEPARATE_TOILET = "separate_toilet"
LABEL_KITCHEN_WINDOW = "kitchen_window"
LABEL_TOILET_WINDOW = "toilet_window"
LABEL_NORTH_SOUTH_TRANS = "north_south_trans"
LABEL_ALL_WINDOW = "all_window"
LABEL_SOUTH_BEDROOM = "south_bedroom"
LABEL_BEDROOM_TOILET = "bedroom_toilet"
LABEL_ALL_SOUTH = "all_south"
LABEL_SOUTH_PARLOUR = "south_parlour"
LABEL_SQUARE = "square"
LABEL_BAY_WINDOW = "bay_window"
LABEL_FRENCH_WINDOW = "french_window"
LABEL_OPEN_KITCHEN = "open_kitchen"
LABEL_BEDROOM_BALCONY = "bedroom_balcony"
LABEL_GOOD_LIGHTING = "good_lighting"
LABEL_HIGH_USE_RATIO = "high_use_ratio"
LABEL_GOOD_GEOMANCY = "good_geomancy"
LABEL_GOOD_ACTIVE_LINE = "good_active_line"
LABEL_GARDEN = "garden"
LABEL_LOFT = "loft"
LABEL_BEDROOM_CLOAKROOM = "bedroom_cloakroom"
LABEL_AREA_LOGICAL = "area_logical"
LABEL_TERRACE = "terrace"
LABEL_KITCHEN_FACE_TOILET = "kitchen_face_toilet"
LABEL_BEDROOM_BAY_WINDOW = "bedroom_bay_window"
LABEL_BEDROOM_FRENCH_WINDOW = "bedroom_french_window"
LABEL_PARLOUR_BAY_WINDOW = "parlour_bay_window"
LABEL_PARLOUR_FRENCH_WINDOW = "parlour_french_window"
LABEL_PARLOUR_BALCONY = "parlour_balcony"
LABEL_CLOAKROOM = "cloakroom"


# 标签分值
LABEL_SCORES = {
    'space': {
        LABEL_SQUARE: 30,
        LABEL_MOVEMENT_CLEAR: 30,
        LABEL_AREA_LOGICAL: 40
    },
    'trans': {
        LABEL_NORTH_SOUTH_TRANS: 20,
        LABEL_ALL_WINDOW: 10,
        LABEL_ALL_SOUTH: 10,
        LABEL_SOUTH_BEDROOM: 15,
        LABEL_SOUTH_PARLOUR: 15,
        LABEL_KITCHEN_WINDOW: 15,
        LABEL_TOILET_WINDOW: 15
    },
    'usage': {
        LABEL_SEPARATE_TOILET: 10,
        LABEL_BEDROOM_TOILET: 10,
        LABEL_BEDROOM_BALCONY: 15,
        LABEL_BEDROOM_CLOAKROOM: 10,
        LABEL_LOFT: 5,
        LABEL_GARDEN: 5,
        LABEL_TERRACE: 5,
        LABEL_BAY_WINDOW: 20,
        LABEL_FRENCH_WINDOW: 20
    }
}

# 标签文案
# <标签类型(0: 优势； 1：劣势), 有此标签时的文案, 没有此标签时的文案>
LABEL_DOCS = {
    LABEL_SQUARE: (0,
                   "该户型的格局规整，整体长宽比例协调，此类户型<span class='highlight'>通风较好，保温性强，空间利用率高</span>。",
                   None),
    LABEL_MOVEMENT_CLEAR: (0,
                           "将活动区分为动区，休息区分为静区，该户型可以使两个区域之间的活动<span class='highlight'>互不干扰</span>。",
                           "动区穿过静区，会存在一定程度上的相互干扰"),
    LABEL_AREA_LOGICAL: (0,
                         "该户型厅室面积适中合理，满足对应的功能布局需求，<span class='highlight'>空间浪费较少</span>，居住舒适。",
                         "该户型存在某一功能间面积比例较小的问题"),

    LABEL_NORTH_SOUTH_TRANS: (0,
                              ("此类户型存在南北可以贯穿的窗户，<span class='highlight'>采光通风极好</span>，"
                               "能够做到<span class='highlight'>冬暖夏凉</span>。"),
                              "该户型缺少贯通南北双方向的通风廊道"),
    LABEL_ALL_WINDOW: (0,
                       "该户型使用的主要功能间均有窗，每个房间都可以有<span class='highlight'>良好的采光与通风</span>。",
                       "该户型存在无外窗房间，需合理设置光源引入"),
    LABEL_ALL_SOUTH: (0,
                      ("全南户型又叫朝阳户型，主要功能间均朝南，<span class='highlight'>采光较好，冬暖夏凉</span>，"
                       "并且多为中间户，<span class='highlight'>空间利用率较高</span>。"),
                      None),
    LABEL_SOUTH_BEDROOM: (0,
                          "朝南的卧室在全年都可以不同程度的沐浴阳光，<span class='highlight'>暖人又节能</span>。",
                          "卧室没有直接朝南外窗。"),
    LABEL_SOUTH_PARLOUR: (0,
                          "客厅是一家人使用率最高的地方， 朝南可以保持<span class='highlight'>良好的采光和通风</span>，保证室内的清新和干燥。",
                          "客厅没有直接朝南外窗。"),
    LABEL_KITCHEN_WINDOW: (0,
                           ("厨房存在<span class='highlight'>采光和通风</span>的条件，避免了油烟排散不良的问题，"
                            "提供了更<span class='highlight'>健康的生活环境</span>。"),
                           "存在厨房无外窗情况，改造时请注意换气排风。"),
    LABEL_TOILET_WINDOW: (0,
                          ("卫生间存在<span class='highlight'>采光和通风</span>，避免暗卫的潮湿和闷热问题，有效抑制细菌的滋生，"
                           "使<span class='highlight'>生活环境更健康</span>。"),
                          "存在卫生间无外窗情况，改造时请注意换气排风。"),

    LABEL_SEPARATE_TOILET: (0,
                            "卫生间具备设置干湿分离的条件，干湿分离卫生间使卫浴物品避免因受潮而缩短使用寿命，并有<span class='highlight'>防潮防滑的效果</span>。",
                            None),
    LABEL_BEDROOM_TOILET: (0,
                           "卧室单独拥有卫生间，增加了个人私密性，多卫也<span class='highlight'>避免使用卫生间冲突</span>的情况。",
                           "卫生间数量少，可以考虑三分离设计以满足多人同时使用的需求。"),
    LABEL_BEDROOM_BALCONY: (0,
                            "卧室带阳台<span class='highlight'>采光通风都极好</span>，另外衣物<span class='highlight'>晾晒有隐私性</span>。",
                            None),
    LABEL_BEDROOM_CLOAKROOM: (0,
                              "卧室存在独立的衣帽间，<span class='highlight'>多了储物空间</span>可以使衣物分区明确，存储更多的物品。",
                              None),
    LABEL_LOFT: (0,
                 "阁楼可以<span class='highlight'>增加户型使用率</span>，大多阁楼不计入建筑面积中，可使用于储物、居住、休闲区域。",
                 None),
    LABEL_GARDEN: (0,
                   "该户型自带花园，<span class='highlight'>相当于多出一个房间</span>，休闲晾晒种植改造等灵活性高。",
                   None),
    LABEL_TERRACE: (0,
                    "该户型自带露台，适宜种植花草、纳凉晒太阳，欣赏夜景，为生活带来一丝<span class='highlight'>惬意</span>。",
                    None),
    LABEL_BAY_WINDOW: (0,
                       "飘窗可以增加一些<span class='highlight'>空间使用率</span>，在享受采光与景色的同时，种植盆栽或休闲小憩均可。",
                       None),
    LABEL_FRENCH_WINDOW: (0,
                          "落地窗<span class='highlight'>采光极好，视野宽阔</span>，视觉上可以使房子敞亮许多。",
                          None)
}

# 短句文案
# <标签类型(0: 优势； 1：劣势), 有此标签时的文案, 没有此标签时的文案>
SHORT_LABEL_DOCS = {
    LABEL_SQUARE: (0,
                   "户型方正，格局规整",
                   None),
    LABEL_MOVEMENT_CLEAR: (0,
                           "动静区分离，活动不影响休息",
                           "动区穿过静区，可能存在干扰"),
    LABEL_AREA_LOGICAL: (0,
                         "厅室面积适中合理",
                         "厅面积较小"),

    LABEL_NORTH_SOUTH_TRANS: (0,
                              "存在南北可以贯穿的窗户",
                              "缺少贯通南北方向的通风廊道"),
    LABEL_ALL_WINDOW: (0,
                       "主要功能间均有窗",
                       "存在无外窗房间，需合理设置光源引入"),
    LABEL_ALL_SOUTH: (0,
                      "主要功能间均朝南，采光较好",
                      None),
    LABEL_SOUTH_BEDROOM: (0,
                          "朝南的卧室，沐浴阳光",
                          "卧室没有直接朝南外窗"),
    LABEL_SOUTH_PARLOUR: (0,
                          "客厅朝南可以保持良好的采光和通风",
                          "客厅没有直接朝南外窗"),
    LABEL_KITCHEN_WINDOW: (0,
                           "厨房有外窗，利于油烟排散",
                           "存在厨房无外窗情况，请注意换气排风"),
    LABEL_TOILET_WINDOW: (0,
                          "卫生间存在采光和通风，避免暗卫的潮湿和闷热问题",
                          "存在卫生间无外窗情况，请注意换气排风"),

    LABEL_SEPARATE_TOILET: (0,
                            "卫生间干湿分离",
                            None),
    LABEL_BEDROOM_TOILET: (0,
                           "卧室单独拥有卫生间，增加了个人私密性",
                           "卫生间数量少，可以考虑三分离设计以满足多人同时使用的需求"),
    LABEL_BEDROOM_BALCONY: (0,
                            "卧室带阳台，采光通风好，方便晾晒衣物",
                            None),
    LABEL_BEDROOM_CLOAKROOM: (0,
                              "卧室有独立的衣帽间，衣服整理更方便",
                              None),
    LABEL_LOFT: (0,
                 "阁楼可以增加户型使用率",
                 None),
    LABEL_GARDEN: (0,
                   "自带花园，相当于多出一个房间",
                   None),
    LABEL_TERRACE: (0,
                    "自带露台，种植花草、纳凉晒太阳都挺好",
                    None),
    LABEL_BAY_WINDOW: (0,
                       "飘窗可以增加空间使用率",
                       None),
    LABEL_FRENCH_WINDOW: (0,
                          "落地窗采光极好，视野宽阔，使室内显得敞亮",
                          None)
}

# ################### end ###################
# ###########################################

if __name__ == "__main__":
    pass
    print(LABEL_DOCS[LABEL_KITCHEN_WINDOW][1])
