#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2018 www.ke.com, Inc. All Rights Reserved
"""
标签方法
Authors: yudonghai@ke.com
Date:    2019/01/08
"""
from __future__ import division
import math
import collections
import numpy as np

from lib import code_enum as ce
from lib import comm_lib
from lib import entity
from lib import log

# 南北通透南北两个有附件的墙体错开的最大允许距离（mm）
CONN_DISTANCE = 1000
# 朝向窗口宽度阈值，用于剔除不重要的朝向
MIN_FACE_WIDTH = 800
# 最小有效长度(默认绘图误差不会超过300mm)
MIN_LINE_LEN = 300
# 门正对错开允许范围
DOOR_DIFF_TH = 500

# S_ 代表南向
S_BEDROOM_CNT_KEY = "south_bedroom_cnt"
S_PARLOUR_CNT_KEY = "south_parlour_cnt"
S_IDS_KEY = "south_ids"
BEDROOM_CNT_KEY = "bedroom_cnt"
PARLOUR_CNT_KEY = "parlour_cnt"

# 朝向集合键
FACE_DICT_KEY = "face_dict"
# 朝向标记键
OUT_IDS_KEY = "out_ids"
# 邻接附件窗类型
IS_WINDOW = "window"
#
IS_DOOR = "door"

# 南向集合
SOUTH_DIRECTION_SET = {'south-east', 'south', 'south-west'}
# 北向集合
NORTH_DIRECTION_SET = {'north-east', 'north', 'north-west'}


def area_conn_areas(area, lines_dict, line_items_dict):
    """
    与当前分间连通的分间
    :param area: dict, 分间
    :param lines_dict: dict, 墙体字典
    :param line_items_dict: dict, 墙体附件字典
    :return: conn_items, list,
    [[分间id，分间类型，
    连通器（line/line_item）, 连通器类型， 连通器ID
    is 属性(line：line; line_item:door/window/other), 方向], ...]
    """
    conn_items = []
    attachments = area[ce.AREA_ATTACHMENTS_KEY]
    attach_areas = attachments[ce.ATTACH_AREAS_KEY]
    attach_lines = attachments[ce.ATTACH_LINES_KEY]
    attach_lines_dict = {attach_line[ce.ATTACH_LINE_ID_KEY]: attach_line[ce.DIRECTION_KEY]
                         for attach_line in attach_lines}
    attach_line_items = attachments[ce.ATTACH_LINE_ITEMS_KEY]
    attach_line_items_dict = {attach_li[ce.ATTACH_LINE_ITEM_ID_KEY]: attach_li[ce.DIRECTION_KEY]
                              for attach_li in attach_line_items}

    for attach_area in attach_areas:

        attach_area_type = attach_area[ce.ATTACH_AREA_ROOM_TYPE_KEY]
        shared_lines = attach_area[ce.SHARED_LINES_KEY]
        attach_area_id = attach_area[ce.ATTACH_AREA_ID_KEY]

        for line_id in shared_lines:
            line_info = lines_dict[line_id]
            line_type = line_info[ce.LINE_TYPE_KEY]
            if line_type in ce.TRANS_WALL_TYPE:
                conn_items.append([attach_area_id, attach_area_type,
                                   "line", line_type, line_id,
                                   "line", attach_lines_dict.get(line_id, '')])
            else:
                line_items = lines_dict[line_id][ce.LINE_ITEMS_KEY]
                for line_item_id in line_items:
                    line_item_info = line_items_dict[line_item_id]
                    line_item_type = line_item_info[ce.LINE_ITEM_TYPE_KEY]
                    line_item_is = line_item_info[ce.TYPE_IS_KEY]
                    conn_items.append([attach_area_id, attach_area_type,
                                       "line_item", line_item_type, line_item_id,
                                       line_item_is, attach_line_items_dict.get(line_item_id, '')])
    return conn_items


def area_conn_label(area, lines_dict, line_items_dict, label_factory):
    """
    分间 带xx 识别
    :param area: dict, 分间
    :param lines_dict: dict, 墙体字典
    :param line_items_dict: dict, 墙体附件字典
    :param label_factory: <src/entity.Label>, 标签工厂对象
    :return: add_message, quiet_room_set, <dict, set>, "带" 标签信息，计入静区的分间集合
    """
    add_message = collections.defaultdict(list)
    quiet_room_set = set()

    room_type = area[ce.AREA_ROOM_TYPE_KEY]
    area_id = area[ce.AREA_ID_KEY]
    conn_areas = area_conn_areas(area, lines_dict, line_items_dict)
    conn_type_set = {a_type for _, a_type, _, _, _, _, _ in conn_areas}
    conn_type_dict = {a_type: a_id for a_id, a_type, _, _, _, _, _ in conn_areas}

    # 客厅连接其他分间
    if room_type == ce.AreaType.parlour.value:
        for item in conn_areas:
            a_id, a_type, c_class, c_type, c_id, c_is, c_direction = item
            tmp_message = [area_id, a_id]

            if c_class != "line_item":
                continue
            # 客厅带阳台
            if a_type == ce.AreaType.balcony.value:
                add_message[label_factory[ce.LABEL_PARLOUR_BALCONY]].append(tmp_message)

    # 卧室连接其他分间
    if room_type == ce.AreaType.room.value:
        for item in conn_areas:

            a_id, a_type, c_class, c_type, c_id, c_is, c_direction = item
            tmp_message = [area_id, a_id]

            if c_class != "line_item":
                continue

            # 卧室带卫 & 这种卫生间计入'静'分区
            if a_type == ce.AreaType.toilet.value and c_type in ce.CONN_DOOR_TYPES:
                quiet_room_set.add(a_id)
                add_message[label_factory[ce.LABEL_BEDROOM_TOILET]].append(tmp_message)
            # 卧室带阳台
            elif a_type == ce.AreaType.balcony.value:
                add_message[label_factory[ce.LABEL_BEDROOM_BALCONY]].append(tmp_message)
            # 卧室带衣帽间/储藏室
            elif a_type in {ce.AreaType.cloakroom.value, ce.AreaType.storage.value} and c_type in ce.CONN_DOOR_TYPES:
                add_message[label_factory[ce.LABEL_BEDROOM_CLOAKROOM]].append(tmp_message)
                quiet_room_set.add(a_id)

    # 过道 或 衣帽间/储藏间 作为间接关联的中间分间
    elif area[ce.AREA_TYPE_KEY] == ce.GUODAO or room_type in {ce.AreaType.cloakroom.value, ce.AreaType.storage.value}:
        # 只连接了 (室， 卫， 衣帽间，阳台, 储藏间) 中的一种或几种
        if not (conn_type_set - ce.PASSAGE_INDIRECT_TYPES):
            # 卧室，卫生间通过 过道/衣帽间/储藏间 相连
            if {ce.AreaType.room.value, ce.AreaType.toilet.value}.issubset(conn_type_set):
                shi_id = conn_type_dict[ce.AreaType.room.value]
                wei_id = conn_type_dict[ce.AreaType.toilet.value]
                add_message[label_factory[ce.LABEL_BEDROOM_TOILET]].append([shi_id, wei_id])
                quiet_room_set.add(conn_type_dict[ce.AreaType.toilet.value])
            # 卧室，衣帽间通过 过道/(衣帽间) 相连
            if {ce.AreaType.room.value, ce.AreaType.cloakroom.value}.issubset(conn_type_set):
                shi_id = conn_type_dict[ce.AreaType.room.value]
                cloak_id = conn_type_dict[ce.AreaType.cloakroom.value]
                add_message[label_factory[ce.LABEL_BEDROOM_CLOAKROOM]].append([shi_id, cloak_id])
                quiet_room_set.add(conn_type_dict[ce.AreaType.cloakroom.value])
            if {ce.AreaType.room.value, ce.AreaType.storage.value}.issubset(conn_type_set):
                shi_id = conn_type_dict[ce.AreaType.room.value]
                cloak_id = conn_type_dict[ce.AreaType.storage.value]
                add_message[label_factory[ce.LABEL_BEDROOM_CLOAKROOM]].append([shi_id, cloak_id])
                quiet_room_set.add(conn_type_dict[ce.AreaType.storage.value])
            # 卧室、阳台间通过 过道/衣帽间 相连
            if {ce.AreaType.room.value, ce.AreaType.balcony.value}.issubset(conn_type_set):
                shi_id = conn_type_dict[ce.AreaType.room.value]
                yangtai_id = conn_type_dict[ce.AreaType.balcony.value]
                add_message[label_factory[ce.LABEL_BEDROOM_BALCONY]].append([shi_id, yangtai_id])
    return add_message, quiet_room_set


def is_movement_clear(plan, label_factory):
    """
    * ************************
    * 动静分明       | 用静区是否连通来判定
    * 卧室带卫       |
    * 卧室带阳台      |
    * 卧室带衣帽间    |
    * ************************
    :param plan: dict, 矢量户型一层数据
    :param label_factory: <src/entity.Label>, 标签工厂对象
    :return: (label, message), <int, dict>, 标签值， 附加信息
    """
    label = label_factory[ce.LABEL_NOTHING]
    message = collections.defaultdict(list)

    areas = plan[ce.PLAN_AREAS_KEY]
    areas_dict = plan[ce.AREAS_DICT_KEY]
    line_items_dict = plan[ce.LINE_ITEMS_DICT_KEY]
    lines_dict = plan[ce.LINES_DICT_KEY]

    # 静区分间列表
    quiet_room_lst = []
    attach_map = collections.defaultdict(set)

    # 计入"静"分区的分间集合
    quiet_room_set = set()

    # 连通队列
    # 双向队列在删除或添加首/尾元素时效率比列表更高
    connect_q = collections.deque()

    # 连通标记集合
    connect_set = set()
    # 分间集合
    areas_set = set()

    # 对每一个卧室遍历， 找到卧室带卫、阳台或衣帽间的情况，卧室带卫要用来判定动静分明
    for area in areas:

        add_message, tmp_quiet_rooms_set = area_conn_label(area, lines_dict, line_items_dict, label_factory)
        quiet_room_set.update(tmp_quiet_rooms_set)

        # 将 "带" 类标签更新到总记录里
        for l in add_message:
            label |= l
            tmp_message = add_message[l]
            if tmp_message:
                message[l].extend(tmp_message)

    # 静区分间互相关联关系
    for area in areas:
        room_id = area[ce.AREA_ID_KEY]
        room_type = area[ce.AREA_ROOM_TYPE_KEY]
        attachments = area[ce.AREA_ATTACHMENTS_KEY]
        if room_type not in ce.INVALID_AREA_TYPES:
            areas_set.add(room_id)

        if room_type not in ce.QUIET_ROOM_TYPES and room_id not in quiet_room_set:
            continue

        quiet_room_lst.append(room_id)
        attach_areas = attachments[ce.ATTACH_AREAS_KEY]

        for attach_area in attach_areas:

            attach_area_id = attach_area[ce.ATTACH_AREA_ID_KEY]
            attach_area_type = attach_area[ce.ATTACH_AREA_ROOM_TYPE_KEY]

            if attach_area_type in ce.QUIET_ROOM_TYPES or attach_area_id in quiet_room_set:
                attach_map[room_id].add(attach_area_id)

    # 至少一室一厅
    if len(quiet_room_lst) < 1:
        return label, message

    # 连通起始点
    start_bed_room = quiet_room_lst[0]

    connect_q.append(start_bed_room)
    connect_set.add(start_bed_room)

    # 广度优先搜索临近分间
    while connect_q:
        base_room = connect_q.popleft()
        maps = attach_map.get(base_room, [])
        for neighbor in maps:
            if neighbor not in connect_set:
                connect_q.append(neighbor)
                connect_set.add(neighbor)

    all_quiet_bed_rooms = set(quiet_room_lst)

    sub_room_set = all_quiet_bed_rooms - connect_set

    split_flag = sum([1 if areas_dict[x][ce.AREA_ROOM_TYPE_KEY] == ce.AreaType.room.value else 0 for x in sub_room_set])

    message[ce.EXPLAIN_QUIET_ROOMS] = [quiet_room_lst]
    message[ce.EXPLAIN_MOVING_ROOMS] = [list(areas_set - all_quiet_bed_rooms)]

    # 连通分间包含了所有静区分间，判定为动静分明
    if not split_flag:
        move_areas = areas_set - connect_set
        label |= label_factory[ce.LABEL_MOVEMENT_CLEAR]
        message[label_factory[ce.LABEL_MOVEMENT_CLEAR]] = [[list(connect_set), list(move_areas)]]

    return label, message


def is_separate_toilet(area, plan, label_factory):
    """
    * ************************
    * 干湿分离       | 判定卫生间内部有无一条线独享的点
    * ************************
    :param area: dict, 分间数据
    :param plan: dict, 层数据
    :param label_factory: <src/entity.Label>, 标签工厂对象
    :return: (label, message), <int, dict>, 标签值， 附加信息
    """

    label = label_factory[ce.LABEL_NOTHING]
    message = {}

    if area[ce.AREA_ROOM_TYPE_KEY] != ce.AreaType.toilet.value:
        return label, message

    lines_dict = plan[ce.LINES_DICT_KEY]
    points_dict = plan[ce.POINTS_DICT_KEY]
    # 分间外围墙的点坐标
    border_points = [points_dict[p] for p in area[ce.AREA_POINTS_KEY]]
    # 分间外围墙的点ID集合
    border_set = set(area[ce.AREA_POINTS_KEY])

    find_flag = False
    for p in border_points:
        p_id = p[ce.POINT_ID_KEY]

        # 对卫生间外围点通过线连接的所有点进行是否在分间内部的判断
        connected_lines = points_dict[p_id][ce.POINT_LINES_KEY]
        for conn_line_id in connected_lines:
            l_ps = lines_dict[conn_line_id][ce.LINE_POINTS_KEY]
            for conn_p in l_ps:
                # 点在分间内部条件 不在分间外围墙上 & 点在多边形内
                # in_conditions = [conn_p not in border_set,
                #                 comm_lib.point_in_polygon(points_dict[conn_p], border_points)]
                if conn_p not in border_set:
                    in_flag = comm_lib.point_in_polygon(points_dict[conn_p], border_points)
                    if not in_flag:
                        continue
                    label = label_factory[ce.LABEL_SEPARATE_TOILET]
                    find_flag = True
                    message[label_factory[ce.LABEL_SEPARATE_TOILET]] = [area[ce.AREA_ID_KEY]]
                    break
            if find_flag:
                break
        if find_flag:
            break

    return label, message


def face_door_label(area, plan, label_factory):
    """
    * ************************
    * 厨卫对门       |厨房和卫生间的门相对
    * ************************
    :param area: dict, 分间数据
    :param plan: dict, 层数据
    :param label_factory: <src/entity.Label>, 标签工厂对象
    :return: (label, message), <int, dict>, 标签值， 附加信息
    """

    label = label_factory[ce.LABEL_NOTHING]
    message = {}

    line_dict = plan[ce.LINES_DICT_KEY]
    line_item_dict = plan[ce.LINE_ITEMS_DICT_KEY]
    points_dict = plan[ce.POINTS_DICT_KEY]
    area_dict = plan[ce.AREAS_DICT_KEY]

    attach_areas = area[ce.AREA_ATTACHMENTS_KEY][ce.ATTACH_AREAS_KEY]
    # 当前分间邻接的分间ID -> 共享的通透墙或墙体附件两个端点
    conn_areas = collections.defaultdict(list)
    # 当前分间邻接的分间类型-> 分间ID集合
    conn_area_types = collections.defaultdict(set)
    for a in attach_areas:

        for li in a[ce.SHARED_LINE_ITEMS_KEY]:
            if line_item_dict[li][ce.TYPE_IS_KEY] == IS_DOOR:
                ps = comm_lib.get_endpoint(li, line_dict, line_item_dict, points_dict)
                conn_areas[a[ce.ATTACH_AREA_ID_KEY]].append(ps)
                conn_area_types[a[ce.ATTACH_AREA_ROOM_TYPE_KEY]].add(a[ce.ATTACH_AREA_ID_KEY])

        shared_lines = a[ce.SHARED_LINES_KEY]
        for l in shared_lines:
            if line_dict[l][ce.LINE_TYPE_KEY] in ce.TRANS_WALL_TYPE:
                l_points = line_dict[l][ce.LINE_POINTS_KEY]
                ps = [[points_dict[p][ce.X], points_dict[p][ce.Y]] for p in l_points]
                conn_areas[a[ce.ATTACH_AREA_ID_KEY]].append(ps)
                conn_area_types[a[ce.ATTACH_AREA_ROOM_TYPE_KEY]].add(a[ce.ATTACH_AREA_ID_KEY])

    # 连接了少于2个分间则不会存在对门情况
    if len(conn_areas) < 2:
        return label, message

    if {ce.AreaType.kitchen.value, ce.AreaType.toilet.value}.issubset(set(conn_area_types.keys())):

        # 厨卫的分间中心点
        cw_centers = {}
        # 厨卫对门记录
        face_pairs = set()

        chu_areas = conn_area_types[ce.AreaType.kitchen.value]
        wei_areas = conn_area_types[ce.AreaType.toilet.value]

        for tmp in chu_areas.union(wei_areas):
            c = comm_lib.get_area_center(tmp, area_dict, points_dict)
            cw_centers[tmp] = c

        cw_pairs = [[c, w] for c in chu_areas for w in wei_areas]

        for c, w in cw_pairs:
            chu_doors = conn_areas[c]
            wei_doors = conn_areas[w]

            cw_door_pairs = np.array([[cd, wd] for cd in chu_doors for wd in wei_doors])
            for cd, wd in cw_door_pairs:
                # 门范围扩展
                cd_expanded = comm_lib.expand_line(cd, DOOR_DIFF_TH)
                wd_expanded = comm_lib.expand_line(wd, DOOR_DIFF_TH)
                # 法线
                c_norm_line = comm_lib.get_normal_line(cd)
                w_norm_line = comm_lib.get_normal_line(wd)
                # 中心点
                c_center = cw_centers[c]
                w_center = cw_centers[w]

                area_left_flag = comm_lib.to_left_test(cd, np.array([c_center, w_center]))
                area_left_flag2 = comm_lib.to_left_test(wd, np.array([c_center, w_center]))
                # 厨卫在厨房门的同侧
                if area_left_flag[0] * area_left_flag[1] >= 0 or area_left_flag2[0] * area_left_flag2[1] >= 0:
                    continue

                for norm_l in c_norm_line:
                    left_flag = comm_lib.to_left_test(norm_l, wd_expanded)
                    if left_flag[0] * left_flag[1] < 0:
                        label |= label_factory[ce.LABEL_KITCHEN_FACE_TOILET]
                        face_pairs.add((c, w))

                for norm_l in w_norm_line:
                    left_flag = comm_lib.to_left_test(norm_l, cd_expanded)
                    if left_flag[0] * left_flag[1] < 0:
                        label |= label_factory[ce.LABEL_KITCHEN_FACE_TOILET]
                        face_pairs.add((c, w))
        if face_pairs:
            message[label_factory[ce.LABEL_KITCHEN_FACE_TOILET]] = [list(x) for x in face_pairs]

    return label, message


def room_iter(plan, label_factory):
    """
    分间标签生成器，内部有多重分间标签的判定函数
    :param plan: dict, 层数据
    :param label_factory: Label， 标签类
    :return: (label, info), (int/long, dict), 标签值, 附加信息
    """
    label = label_factory[ce.LABEL_NOTHING]
    message = collections.defaultdict(list)

    info = {
        S_BEDROOM_CNT_KEY: 0,
        S_PARLOUR_CNT_KEY: 0,
        BEDROOM_CNT_KEY: 0,
        PARLOUR_CNT_KEY: 0
    }
    areas = plan[ce.PLAN_AREAS_KEY]

    all_window_flag = True

    max_bedroom_size = 0
    max_parlour_size = 0
    parlour_cnt = 0

    out_ids_set = set()
    south_area_ids_lst = []

    for area in areas:
        tmp_size = area.get(ce.AREA_SIZE_KEY, 0)
        area_empty = area[ce.AREA_EMPTY_KEY]
        tmp_type = area[ce.AREA_ROOM_TYPE_KEY]

        if not area_empty:
            if tmp_type == ce.AreaType.parlour.value:
                max_parlour_size = max_parlour_size if max_parlour_size > tmp_size else tmp_size
                parlour_cnt += 1
            elif tmp_type == ce.AreaType.room.value:
                max_bedroom_size = max_bedroom_size if max_bedroom_size > tmp_size else tmp_size

        # 干湿分离
        is_separate_label, is_separate_message = is_separate_toilet(area, plan, label_factory)
        # 分间标签
        room_label, room_label_message, room_add_message = single_room_label(area, plan, label_factory)
        # 厨卫对门
        fd_label, face_door_message = face_door_label(area, plan, label_factory)

        label |= is_separate_label
        label |= room_label
        label |= fd_label

        for x_message in [is_separate_message, face_door_message, room_label_message]:
            for l in x_message:
                message[l].extend(x_message[l])

        # 统计室厅总数和朝南的数量
        for cnt_key in [S_BEDROOM_CNT_KEY, S_PARLOUR_CNT_KEY, BEDROOM_CNT_KEY, PARLOUR_CNT_KEY]:
            tmp_cnt = room_add_message.get(cnt_key, 0)
            info[cnt_key] += tmp_cnt
        if S_IDS_KEY in room_add_message:
            south_area_ids_lst.append([area[ce.AREA_ID_KEY], room_add_message[S_IDS_KEY]])

        # 全明格局一票否决制
        all_window_conditions = [
            not room_add_message[OUT_IDS_KEY],
            area[ce.AREA_ROOM_TYPE_KEY] in ce.ALL_WINDOW_ROOM_TYPES,
            # 非餐厅，门厅
            area[ce.AREA_TYPE_KEY] not in ce.INVALID_ALL_WINDOW_TYPES
        ]

        if all(all_window_conditions):
            all_window_flag = False
        else:
            out_ids_set.update(room_add_message[OUT_IDS_KEY])

    # 分间面积合理(至少一厅，且最大厅面积大于最大室)
    if parlour_cnt > 0 and max_parlour_size > max_bedroom_size:
        label |= label_factory[ce.LABEL_AREA_LOGICAL]
    # 全明格局
    if all_window_flag:
        label |= label_factory[ce.LABEL_ALL_WINDOW]
        message[label_factory[ce.LABEL_ALL_WINDOW]] = [x for x in out_ids_set]

    # 全南户型(所有卧室朝南且所有厅朝南)
    all_south_conditions = [
        info[BEDROOM_CNT_KEY] == info[S_BEDROOM_CNT_KEY],
        info[S_PARLOUR_CNT_KEY] == info[PARLOUR_CNT_KEY],
        info[BEDROOM_CNT_KEY] + info[PARLOUR_CNT_KEY] != 0
    ]
    if all(all_south_conditions):
        label |= label_factory[ce.LABEL_ALL_SOUTH]
        message[label_factory[ce.LABEL_ALL_SOUTH]] = south_area_ids_lst

    return label, message


def get_window_div_floor(area, lines_dict, line_items_dict):
    """
    获取分间窗地比
    :param area: dict, 分间
    :param lines_dict: dict, 墙体字典
    :param line_items_dict: dict, 墙体附件字典
    :return: float, 窗地比（米/平方米）
    """
    attachments = area[ce.AREA_ATTACHMENTS_KEY]
    attach_lines = attachments[ce.ATTACH_LINES_KEY]
    out_len = 0.
    area_size = area[ce.AREA_SIZE_KEY]

    # 朝外的透光墙及透光墙体附件
    for attach_line in attach_lines:
        conn_line_id = attach_line[ce.ATTACH_LINE_ID_KEY]
        line_len = attach_line[ce.LENGTH_KEY]

        line_info = lines_dict[conn_line_id]
        line_type = line_info[ce.LINE_TYPE_KEY]
        line_items = line_info[ce.LINE_ITEMS_KEY]

        if not line_info[ce.EDGE_COMP_KEY]:
            continue

        if line_type in ce.OUT_WALL_TYPE:
            out_len += line_len
        else:
            for line_item in line_items:
                if line_items_dict[line_item][ce.TYPE_IS_KEY] == IS_WINDOW:
                    out_len += line_items_dict[line_item][ce.LINE_ITEM_LENGTH_KEY]
    if area_size == 0:
        return 0.
    else:
        return out_len * 1000. / area_size


def area_face(area, lines_dict, line_items_dict, areas_dict):
    """
    分间朝向、"明"属性 分析
    :param area: dict, 分间数据
    :param lines_dict: dict, 墙体字典
    :param line_items_dict: dict, 墙体附件字典
    :param areas_dict: dict, 分间字典
    :return: face_dict, out_keys; 朝向-朝向窗/墙字典，"明"窗/墙集合
    """
    attachments = area[ce.AREA_ATTACHMENTS_KEY]
    attach_lines = attachments[ce.ATTACH_LINES_KEY]

    # 朝向-窗/墙集合 字典
    face_dict = collections.defaultdict(set)
    # 朝向宽度字典，用于区分主朝向
    face_size = collections.defaultdict(float)
    # "明"标记的窗/墙集合
    out_keys = set()

    conn_wall_dict = {}

    # 朝外的透光墙及透光墙体附件
    for attach_line in attach_lines:
        conn_line_id = attach_line[ce.ATTACH_LINE_ID_KEY]
        line_direction = attach_line[ce.DIRECTION_KEY]
        line_len = attach_line[ce.LENGTH_KEY]

        line_info = lines_dict[conn_line_id]
        line_type = line_info[ce.LINE_TYPE_KEY]
        line_items = line_info[ce.LINE_ITEMS_KEY]

        if line_type in ce.TRANS_WALL_TYPE:
            conn_wall_dict[conn_line_id] = line_len

        if not line_info[ce.EDGE_COMP_KEY]:
            continue

        if line_type in ce.OUT_WALL_TYPE:
            face_dict[line_direction].add(conn_line_id)
            face_size[line_direction] += line_len
            out_keys.add(conn_line_id)
        else:
            for line_item in line_items:
                if line_items_dict[line_item][ce.TYPE_IS_KEY] == IS_WINDOW:
                    face_dict[line_direction].add(line_item)
                    face_size[line_direction] += line_items_dict[line_item][ce.LINE_ITEM_LENGTH_KEY]
                    out_keys.add(line_item)

    # 查找朝外分间
    conn_areas = area_conn_areas(area, lines_dict, line_items_dict)
    for conn_area in conn_areas:

        a_id, a_type, c_class, c_type, c_id, c_is, c_direction = conn_area
        conn_line_id = c_id
        c_len = conn_wall_dict.get(c_id, 0)

        conn_area_obj = areas_dict[a_id]
        conn_area_wdf = get_window_div_floor(conn_area_obj, lines_dict, line_items_dict)
        # 连接的分间外窗/地面面积大于一定比例也认为是朝外
        if a_type not in ce.OUT_ROOM_TYPE:
            if conn_area_wdf < ce.OUT_AREA_WDF_TH:
                continue

        out_keys.add(c_id)

        if c_class == "line_item":
            c_len = line_items_dict[c_id][ce.LINE_ITEM_LENGTH_KEY]
            conn_line_id = line_items_dict[c_id][ce.LINE_ITEM_LINE_KEY]

        balcony_face_valid = False

        # 阳台要单独考虑，有的阳台只有侧面一个小窗
        if a_type == ce.AreaType.balcony.value:
            balcony_info = areas_dict[a_id]
            balcony_attachments = balcony_info[ce.AREA_ATTACHMENTS_KEY]
            balcony_lines = balcony_attachments[ce.ATTACH_LINES_KEY]
            for line in balcony_lines:
                line_direction = line[ce.DIRECTION_KEY]

                # 不可能是阳台朝向的条件：共享墙体；不是外墙；方向与分间方向不一致
                invalid_conditions = [
                    line[ce.ATTACH_LINE_ID_KEY] == conn_line_id,
                    line_direction not in c_direction and c_direction not in line_direction
                ]
                if any(invalid_conditions):
                    continue

                line_id = line[ce.ATTACH_LINE_ID_KEY]
                line_info = lines_dict[line_id]
                line_type = line_info[ce.LINE_TYPE_KEY]
                balcony_line_items = line_info[ce.LINE_ITEMS_KEY]

                if line_type in ce.OUT_WALL_TYPE:
                    balcony_face_valid = True
                else:
                    for line_item_id in balcony_line_items:
                        line_item_info = line_items_dict[line_item_id]
                        line_item_is = line_item_info[ce.TYPE_IS_KEY]
                        is_entrance = line_item_info[ce.ENTRANCE_KEY]
                        if (line_item_is in {IS_WINDOW, IS_DOOR} or line_item_info[ce.LINE_ITEM_TYPE_KEY] == ce.YAKOU) and is_entrance is None:
                            balcony_face_valid = True

        if a_type != ce.AreaType.balcony.value or balcony_face_valid:
            face_dict[c_direction].add(c_id)
            face_size[c_direction] += c_len

    # 认为朝向透光量较小可能会删掉的朝向
    sub_out = set()
    # 主朝向宽度
    main_face_len = 0
    # 主朝向
    main_face = None
    if len(face_size) > 1:
        for d in face_size:
            if face_size[d] <= MIN_FACE_WIDTH:
                sub_out.add(d)
            if face_size[d] > main_face_len:
                main_face_len = face_size[d]
                main_face = d
    if len(face_dict) == len(sub_out) and main_face is not None:
        face_dict = {main_face: face_dict[main_face]}
    else:
        for sub_key in sub_out:
            face_dict.pop(sub_key)
    return face_dict, out_keys, face_size


def single_room_label(area, plan, label_factory):
    """
    单个分间就可以判定的标签
    * ************************
    * 带阁楼       |
    * 带花园       |
    * 开放厨房      |
    * 明厨         |
    * 明卫         |
    * 卧室朝南      |
    * 客厅朝南      |
    * ************************
    :param area: dict, 分间数据
    :param plan: dict, 平面层数据
    :param label_factory: Label, 标签类
    :return: (label, message), (int/long, dict), 标签值, 附加信息
    """
    label = label_factory[ce.LABEL_NOTHING]
    message = {}
    # 为全局特征提供的分间信息
    add_message = {}

    area_type = area[ce.AREA_ROOM_TYPE_KEY]
    area_id = area[ce.AREA_ID_KEY]
    area_detailed_type = area[ce.AREA_TYPE_KEY]

    lines_dict = plan[ce.LINES_DICT_KEY]
    line_items_dict = plan[ce.LINE_ITEMS_DICT_KEY]
    areas_dict = plan[ce.AREAS_DICT_KEY]

    face_dict, out_keys, face_size = area_face(area, lines_dict, line_items_dict, areas_dict)
    face_set = set(face_dict.keys())

    add_message[FACE_DICT_KEY] = face_dict
    add_message[OUT_IDS_KEY] = out_keys

    only_south_bed_room = False
    only_south_parlor_room = False

    # 南向标记
    south_flag = SOUTH_DIRECTION_SET.intersection(face_set)
    south_ids = []
    for direction in SOUTH_DIRECTION_SET:
        south_ids.extend(face_dict.get(direction, []))
    # 纯南向标记
    only_south_flag = not (face_set - SOUTH_DIRECTION_SET)

    # 阁楼
    if area_type == ce.AreaType.loft.value:
        label |= label_factory[ce.LABEL_LOFT]
        message[label_factory[ce.LABEL_LOFT]] = [area_id]
    # 露台
    if area_type == ce.AreaType.terrace.value:
        label |= label_factory[ce.LABEL_TERRACE]
        message[label_factory[ce.LABEL_TERRACE]] = [area_id]

    # 花园
    elif area_type == ce.AreaType.garden.value:
        label |= label_factory[ce.LABEL_GARDEN]
        message[label_factory[ce.LABEL_GARDEN]] = [area_id]
    # 厨房
    elif area_type == ce.AreaType.kitchen.value:
        # 开放厨房
        if area_detailed_type == ce.OPEN_KITCHEN_TYPE:
            label |= label_factory[ce.LABEL_OPEN_KITCHEN]
        # 明厨
        if out_keys:
            label |= label_factory[ce.LABEL_KITCHEN_WINDOW]
            message[label_factory[ce.LABEL_KITCHEN_WINDOW]] = [area_id]
    # 明卫
    elif area_type == ce.AreaType.toilet.value and out_keys:

        label |= label_factory[ce.LABEL_TOILET_WINDOW]
        message[label_factory[ce.LABEL_TOILET_WINDOW]] = [area_id]
    # 衣帽间
    elif area_type == ce.AreaType.cloakroom.value:
        label |= label_factory[ce.LABEL_CLOAKROOM]
        message[label_factory[ce.LABEL_CLOAKROOM]] = [area_id]

    # 室
    elif area_type == ce.AreaType.room.value:
        add_message[BEDROOM_CNT_KEY] = 1
        # 卧室朝南
        if south_flag:
            label |= label_factory[ce.LABEL_SOUTH_BEDROOM]
            message[label_factory[ce.LABEL_SOUTH_BEDROOM]] = [[area_id, south_ids]]
        if face_dict and only_south_flag:
            only_south_bed_room = True

    elif area_type == ce.AreaType.cloakroom.value:
        # 卧室朝南
        if south_flag:
            label |= label_factory[ce.LABEL_SOUTH_BEDROOM]
            message[label_factory[ce.LABEL_SOUTH_BEDROOM]] = [[area_id, south_ids]]
        if face_dict and only_south_flag:
            only_south_bed_room = True
    # 厅
    elif area_type == ce.AreaType.parlour.value and area_detailed_type == 1:
        add_message[PARLOUR_CNT_KEY] = 1
        # 客厅朝南 room["type"] == 1 指客厅
        if south_flag:
            label |= label_factory[ce.LABEL_SOUTH_PARLOUR]
            message[label_factory[ce.LABEL_SOUTH_PARLOUR]] = [[area_id, south_ids]]
        if face_dict and only_south_flag:
            only_south_parlor_room = True

    # 次要功能中存在开放厨房
    if ce.SUB_TYPE in area and area[ce.SUB_TYPE] == ce.OPEN_KITCHEN_TYPE:
        label |= label_factory[ce.LABEL_OPEN_KITCHEN]

    if only_south_bed_room and area_type == ce.AreaType.room.value:
        add_message[S_BEDROOM_CNT_KEY] = 1
        add_message[S_IDS_KEY] = south_ids
    if only_south_parlor_room:
        add_message[S_PARLOUR_CNT_KEY] = 1
        add_message[S_IDS_KEY] = south_ids

    return label, message, add_message


def vertical_connect(min_x, max_x, current_y, line_item, line, point_dict, is_edge=False):
    """
    纵向通透判断函数，串联北向通透宽度与lineItem 的通透宽度
    :param min_x: 北向留下的通透区域最小x
    :param max_x: 北向留下的通透区域最大x
    :param current_y: 当前通透的纵向坐标
    :param line_item: 门窗，垭口
    :param line: 门窗，垭口所在墙
    :param point_dict: 坐标字典
    :param is_edge: 是否外墙
    :return:
    """
    new_min = new_max = new_y = 0
    type_flag = False
    # 窗、门、垭口，且在水平方向跨度大于最小限制
    if line_item is not None:
        is_window_door = line_item[ce.TYPE_IS_KEY] in {IS_WINDOW, IS_DOOR}
        is_yakou = line_item[ce.LINE_ITEM_TYPE_KEY] == ce.YAKOU
        if is_window_door or is_yakou:
            type_flag = True
    elif line[ce.LINE_TYPE_KEY] in ce.TRANS_WALL_TYPE and not is_edge:
        type_flag = True
    elif line[ce.LINE_TYPE_KEY] in ce.OUT_WALL_TYPE and is_edge:
        type_flag = True

    if not type_flag:
        return new_min, new_max, new_y

    x_p1, x_p2, y = line_points(line, point_dict)

    y_flag = (current_y - y) > MIN_LINE_LEN
    x_flag = (x_p2 - x_p1) > MIN_LINE_LEN

    if not x_flag or not y_flag:
        return new_min, new_max, new_y

    conn_flag = False
    if x_p1 < max_x and x_p2 > min_x:
        conn_flag = True
    # 左右容差
    elif abs(x_p1 - max_x) < CONN_DISTANCE or abs(x_p2 - min_x) < CONN_DISTANCE:
        conn_flag = True

    if conn_flag:
        new_min = x_p1
        new_max = x_p2
        new_y = y

    return new_min, new_max, new_y


def line_points(line, points_dict):
    """
    计算 line 的实际横跨坐标和纵向中点纵坐标
    横跨为 0 时 所有返回 0
    :param line: dict, 墙
    :param points_dict: dict, 坐标字典
    :return: (float, float, float), 墙左端点，墙右端点，墙纵向中心坐标
    """

    x1 = points_dict[line[ce.LINE_POINTS_KEY][0]][ce.X]
    y1 = points_dict[line[ce.LINE_POINTS_KEY][0]][ce.Y]

    x2 = points_dict[line[ce.LINE_POINTS_KEY][-1]][ce.X]
    y2 = points_dict[line[ce.LINE_POINTS_KEY][-1]][ce.Y]

    x_diff = abs(x1 - x2)
    y_diff = abs(y1 - y2)
    if x_diff == y_diff == 0:
        return 0, 0, 0

    return min(x1, x2), max(x1, x2), (y1 + y2) / 2


def is_south_north_trans(plan, label_factory):
    """
    * ************************
    * 南北通透       |
    * ************************
    :param plan: dict, 层数据
    :param label_factory: Label， 标签类
    :return: (label, message), (int/long, dict), 标签值, 附加信息
    """
    label = label_factory[ce.LABEL_NOTHING]
    message = {}

    # 如果有旋转则采用旋转后的坐标
    p_k = ce.ROTATE_POINTS_DICT_KEY if ce.ROTATE_POINTS_DICT_KEY in plan else ce.POINTS_DICT_KEY

    # 数据准备
    p_dict = plan[p_k]
    area_dict = plan[ce.AREAS_DICT_KEY]
    line_dict = plan[ce.LINES_DICT_KEY]
    line_item_dict = plan[ce.LINE_ITEMS_DICT_KEY]

    north_window_items = []     # 北向窗户列表
    room_cnt = 0                # 室 计数
    flow_lines = []             # 通透线记录

    # 找到朝北方向的窗
    for area in plan[ce.PLAN_AREAS_KEY]:

        area_type = area[ce.AREA_ROOM_TYPE_KEY]
        area_id = area[ce.AREA_ID_KEY]
        attach_lines = area[ce.AREA_ATTACHMENTS_KEY][ce.ATTACH_LINES_KEY]

        if area_type == ce.AreaType.room.value:
            room_cnt += 1

        for line in attach_lines:
            line_id = line[ce.ATTACH_LINE_ID_KEY]
            line_edge = line[ce.EDGE_KEY]
            line_direction = line[ce.DIRECTION_KEY]
            line_info = line_dict[line_id]
            line_items = line_info[ce.LINE_ITEMS_KEY]
            line_type = line_info[ce.LINE_TYPE_KEY]
            left_px, right_px, current_y = line_points(line_info, p_dict)
            diff_x = right_px - left_px

            # 非外墙或朝向非偏北时跳过判定
            if not line_edge or line_direction not in NORTH_DIRECTION_SET or diff_x <= MIN_LINE_LEN:
                continue

            # 根据墙体类型或墙体附件判定
            if line_type in ce.OUT_WALL_TYPE:
                north_window_items.append([line_id, area_id, left_px, right_px, current_y])
            else:
                for line_item in line_items:
                    line_item_state = line_item_dict[line_item][ce.TYPE_IS_KEY] == IS_WINDOW
                    if line_item_state:
                        north_window_items.append([line_item, area_id, left_px, right_px, current_y])

    # 从每一个北方窗往南找通透的通路
    for north_window in north_window_items:

        combine_node = collections.deque()
        combine_node.append(north_window)

        # 记录前后关联关系的字典，用于生成路径
        pre_dict = {}

        log.debug("start north-south searching")
        log.debug("north area: " + plan["areas_dict"][north_window[1]]["roomName"])

        # 深度优先搜索
        while combine_node:
            # line_item/line, area, 通透跨度左端点x, 通透跨度右端点x, 竖直方向坐标
            item_id, area_id, left_px, right_px, current_y = combine_node.pop()

            attachments = area_dict[area_id][ce.AREA_ATTACHMENTS_KEY]
            attach_areas = attachments[ce.ATTACH_AREAS_KEY]
            attach_lines = attachments[ce.ATTACH_LINES_KEY]

            # log.debug(area_dict[area_id]["roomName"])

            # 邻接分间
            for attach_room in attach_areas:

                shared_lines = attach_room[ce.SHARED_LINES_KEY]
                attach_room_id = attach_room[ce.ATTACH_AREA_ID_KEY]

                # 遍历邻接分间之间的共享墙体，判断是否可通透
                for shared_line in shared_lines:
                    shared_line_info = line_dict[shared_line]
                    shared_line_items = shared_line_info[ce.LINE_ITEMS_KEY]

                    check_items = []

                    # 有墙体附件
                    if shared_line_items:
                        for line_item_id in shared_line_items:
                            line_item_info = line_item_dict[line_item_id]
                            check_items.append([line_item_info, shared_line_info])
                    # 无墙体附件时判定墙体是否为通透类型
                    else:
                        check_items.append([None, shared_line_info])

                    for line_item, line in check_items:
                        v_info = vertical_connect(left_px, right_px, current_y, line_item, line, p_dict)
                        test_x_left, test_x_right, test_y = v_info
                        if test_x_left != 0 or test_x_right != 0:
                            current_id = shared_line
                            if line_item is not None:
                                current_id = line_item[ce.LINE_ITEM_ID_KEY]
                            combine_node.append([current_id, attach_room_id, test_x_left, test_x_right, test_y])
                            pre_dict[current_id, attach_room_id] = (item_id, area_id)

            # 邻接line，判定是否最南方通透外墙
            for attach_line in attach_lines:

                if not attach_line[ce.EDGE_KEY]:
                    continue

                attach_line_id = attach_line[ce.ATTACH_LINE_ID_KEY]
                attach_line_info = line_dict[attach_line_id]
                line_items = attach_line_info[ce.LINE_ITEMS_KEY]

                check_items = []

                if line_items:
                    for line_item_id in line_items:
                        line_item_info = line_item_dict[line_item_id]
                        # 非入户门才算通透
                        if line_item_info[ce.ENTRANCE_KEY] is None:
                            check_items.append([line_item_info, attach_line_info])
                # 无墙体附件时判定墙体是否为通透类型
                else:
                    check_items.append([None, attach_line_info])

                for line_item, line in check_items:
                    v_info = vertical_connect(left_px, right_px, current_y, line_item, line, p_dict, is_edge=True)
                    test_x_left, test_x_right, test_y = v_info
                    if test_x_left != 0 or test_x_right != 0:
                        current_id = attach_line_id
                        if line_item is not None:
                            current_id = line_item[ce.LINE_ITEM_ID_KEY]

                        pre_dict[current_id, area_id] = (item_id, area_id)

                        flow_line = []
                        area_line = []
                        step = current_id, area_id
                        while step != (north_window[0], north_window[1]):
                            flow_line.append(step[0])
                            area_line.append(step[1])
                            step = pre_dict[step]
                        flow_line.append(north_window[0])
                        area_line.append(north_window[1])
                        # 只有一个分间通透排除
                        if len(flow_line) <= 2:
                            continue
                        flow_lines.append(flow_line)

                        log.debug("\n\n find north-south track ( ^_^ ): ")
                        for a, l in zip(area_line[1:], flow_line[1:]):
                            log.debug("{} -- {}".format(area_dict[a]["roomName"].encode("utf-8"), l.encode("utf-8")))

    if flow_lines:
        label |= label_factory[ce.LABEL_NORTH_SOUTH_TRANS]
        message[label_factory[ce.LABEL_NORTH_SOUTH_TRANS]] = flow_lines

    return label, message


def is_square(plan, label_factory, **config):
    """
    * ************************
    * 户型方正       |
    * ************************
    :param plan: dict, 层数据
    :param label_factory: Label, 标签类
    :param config: dict, 参数
            应该包含:
                border_neighbor 点位移容差距离,
                slope_th        斜墙长度阈值,
                a_empty_th      单个缺角占比阈值,
                all_empty_th    所有缺角面积占比阈值,
                length_width_th 长宽比阈值

    :return: (label, message), (int/long, dict), 标签值, 附加信息
    """
    label = label_factory[ce.LABEL_NOTHING]
    message = {}

    p_k = ce.ROTATE_POINTS_DICT_KEY if ce.ROTATE_POINTS_DICT_KEY in plan else ce.POINTS_DICT_KEY

    p_dict = plan[p_k]
    areas = plan[ce.PLAN_AREAS_KEY]
    lines = plan[ce.PLAN_LINES_KEY]

    # 除了不计入方正的分间外其他分间的点
    wall_points = set()
    # 户型点坐标列表
    wall_points_lst = []
    # 总面积
    area_sum = 0.
    # 记录落在外接矩形上的点的字典
    border_points_dict = collections.defaultdict(list)
    # 缺角外接矩形探测
    empty_rectangle_dict = {}
    # 户型方正标记，默认为 True
    square_flag = True

    # 过滤有特殊墙的户型（斜、弧等）
    slope_flag = False
    for line in lines:
        start_point, end_point = line[ce.LINE_POINTS_KEY]
        x_diff = abs(p_dict[start_point][ce.X] - p_dict[end_point][ce.X])
        y_diff = abs(p_dict[start_point][ce.Y] - p_dict[end_point][ce.Y])
        line_len = math.sqrt(x_diff * x_diff + y_diff * y_diff)

        invalid_conditions = [
            # 弧墙
            line[ce.LINE_CURVE_KEY] != 0,
            # 斜墙
            all([x_diff > config["border_neighbor"],
                y_diff > config["border_neighbor"],
                line_len > config["slope_th"]])
        ]

        if any(invalid_conditions):
            slope_flag = True
            break

    # 发现弧墙或斜墙直接返回
    if slope_flag:
        return label, message

    for area in areas:
        if not area[ce.AREA_EMPTY_KEY]:
            area_sum += area[ce.AREA_SIZE_KEY]
        if area[ce.AREA_ROOM_TYPE_KEY] in ce.INVALID_AREA_TYPES:
            continue
        wall_points.update(set(area[ce.AREA_POINTS_KEY]))
        wall_points_lst.extend([p_dict[x] for x in area[ce.AREA_POINTS_KEY]])

    border_lst = comm_lib.get_circumscribed_rectangle(wall_points_lst)

    min_x = border_lst[comm_lib.MIN_X_INDEX]
    max_x = border_lst[comm_lib.MAX_X_INDEX]
    min_y = border_lst[comm_lib.MIN_Y_INDEX]
    max_y = border_lst[comm_lib.MAX_Y_INDEX]

    # 记录户型外接矩形四至的字典
    border_dict = {ce.AxisFace.left.value: min_x, ce.AxisFace.right.value: max_x,
                   ce.AxisFace.bottom.value: min_y, ce.AxisFace.upper.value: max_y}

    # 判断点是否落在外接矩形的边上
    for point_id in wall_points:
        point = p_dict[point_id]
        p_x = point[ce.X]
        p_y = point[ce.Y]

        # 与y轴平行的边
        for ori in ce.VERTICAL_ORI:
            if abs(p_x - border_dict[ori]) <= config["border_neighbor"]:
                border_points_dict[ori].append(p_y)
        # 与x轴平行的边
        for ori in ce.HORIZONTAL_ORI:
            if abs(p_y - border_dict[ori]) <= config["border_neighbor"]:
                border_points_dict[ori].append(p_x)

    # 外接矩形四条边必须都存在
    if len(border_points_dict) < 4:
        return label, message

    # 两条与x轴平行的边和两条与y轴平行的边组合得到四个角的方位，分别探测四个角有无缺角，并记录缺角外接矩形关键点
    orientation_lst = [[v, h] for v in ce.VERTICAL_ORI for h in ce.HORIZONTAL_ORI]
    for vertical_ori, horizontal_ori in orientation_lst:
        y_p_lst = border_points_dict[vertical_ori]
        x_p_lst = border_points_dict[horizontal_ori]
        # 缺角方位由横纵方向相加得到
        angle_position = vertical_ori + horizontal_ori

        x_fun, y_fun = ce.EMPTY_ANGLE_FIND_MAP[angle_position]

        extreme_x = x_fun(x_p_lst)
        extreme_y = y_fun(y_p_lst)

        x_sub = abs(extreme_x - border_dict[vertical_ori])
        y_sub = abs(extreme_y - border_dict[horizontal_ori])

        # 如果外接矩形边上的点中，极值与边的顶点的距离超过一定距离，则认为此处有缺角
        if x_sub > config["border_neighbor"] and y_sub > config["border_neighbor"]:
            x_end = [extreme_x, border_dict[vertical_ori]]
            y_end = [extreme_y, border_dict[horizontal_ori]]
            x_end.sort()
            y_end.sort()
            # x_end和y_end均为二元数组，表示缺角外接矩形在x和y方向的最小、最大值
            empty_rectangle_dict[angle_position] = [x_end, y_end]

    real_empty_cnt = 0
    # 缺角计数时小于2.5平米的不计入（2.5平米为国标最大卫生间面积）
    for p in empty_rectangle_dict:
        x_e, y_e = empty_rectangle_dict[p]
        x_len = abs(x_e[0] - x_e[1])
        y_len = abs(y_e[0] - y_e[1])
        empty_size = x_len * y_len / 1000000.
        if empty_size >= 2.5:
            real_empty_cnt += 1

    # 缺角数量不大于指定值
    if real_empty_cnt > config["max_empty_cnt"]:
        return label, message

    # 外接矩形面积
    out_rec_area = float(max_x - min_x) * float(max_y - min_y)
    # 户型方正要求最大缺角面积阈值
    max_empty_th = out_rec_area * config["a_empty_th"]

    # 对每一个缺角再识别缺角外接矩形内是否有有效面积
    for empty_position in empty_rectangle_dict:
        x_range, y_range = empty_rectangle_dict[empty_position]
        x_fun, y_fun = ce.EMPTY_ANGLE_FIND_MAP[empty_position]

        x_lst = []
        y_lst = []

        out_rectangle_x_len = abs(x_range[0] - x_range[1])
        out_rectangle_y_len = abs(y_range[0] - y_range[1])

        empty_area = out_rectangle_x_len * out_rectangle_y_len

        # 寻找落在缺角外接矩形中的点
        for p in wall_points_lst:
            if all([x_range[0] < p[ce.X] < x_range[1],
                    y_range[0] < p[ce.Y] < y_range[1]]):
                x_lst.append(p[ce.X])
                y_lst.append(p[ce.Y])

        if x_lst:
            extreme_x = x_fun(x_lst)
            extreme_y = y_fun(y_lst)
            inside_x = x_range[0] if x_fun(x_range) == x_range[1] else x_range[1]
            inside_y = y_range[0] if y_fun(y_range) == y_range[1] else y_range[1]

            # 由四至顶点和 extreme 点投影到四个方向的点组成的矩形，起始点为左下角顶点，逆时针方向
            #
            #
            # 6---5--4
            # |   |  |
            # 7---x--3
            # |   |  |
            # 0---1--2
            # 数字表示列表中的坐标顺序； x 代表找到"最接近"缺角的极点

            if all([abs(extreme_x - inside_x) > config["border_neighbor"],
                    abs(extreme_y - inside_y) > config["border_neighbor"]]):
                empty_area -= abs(extreme_x - inside_x) * abs(extreme_y - inside_y)
        if empty_area > max_empty_th:
            square_flag = False
            break

    # 通过外接矩形和实际建筑面积判断缺角总面积
    if square_flag:
        # 缺角总面积占比
        empty_ratio = (out_rec_area - area_sum) / out_rec_area
        if empty_ratio > config["all_empty_th"]:
            square_flag = False
        else:
            # 长宽比
            lens = [float(max_x - min_x), float(max_y - min_y)]
            lens.sort()
            short_len, long_len = lens
            if long_len == 0 or short_len / long_len < config["length_width_th"]:
                square_flag = False
    if square_flag:
        label = label_factory[ce.LABEL_SQUARE]
    return label, message


def label_base(frame_entity, **config):
    """
    * ************************
    * 观景飘窗       |
    * 观景落地窗      |
    * ************************
    :param frame_entity: class<Frame>, 户型对象
    :param config: dict, 配置参数
    :return: label, int, 标签值
    """
    vector = frame_entity.vector
    label_factory = entity.Label()
    label = label_factory[ce.LABEL_NOTHING]
    message = collections.defaultdict(list)

    # 层数据
    plans = vector[frame_entity.plan_key]

    bed_room_cnt = 0
    parlour_cnt = 0
    kitchen_cnt = 0
    toilet_cnt = 0

    # 每层全南判断
    all_south_flags = []
    # 每层全明判断
    all_window_flags = []
    # 每层动静分明判断
    invalid_movement_flags = []
    quiet_room_lst = None
    moving_room_lst = None

    for plan in plans:
        line_items_dict = plan[ce.LINE_ITEMS_DICT_KEY]
        areas = plan[ce.PLAN_AREAS_KEY]

        tmp_bed_room_cnt = 0
        tmp_parlour_cnt = 0
        out_lines = set()
        line_area_dict = {}
        for area in areas:
            area_id = area[ce.AREA_ID_KEY]
            area_room_type = area[ce.AREA_ROOM_TYPE_KEY]
            if area_room_type in {ce.AreaType.room.value, ce.AreaType.babysitter.value}:
                bed_room_cnt += 1
                tmp_bed_room_cnt += 1
            elif area_room_type == ce.AreaType.parlour.value:
                parlour_cnt += 1
                tmp_parlour_cnt += 1
            elif area_room_type == ce.AreaType.kitchen.value:
                kitchen_cnt += 1
            elif area_room_type == ce.AreaType.toilet.value:
                toilet_cnt += 1
            elif area_room_type == ce.AreaType.garden.value:
                for l in area[ce.AREA_ATTACHMENTS_KEY][ce.ATTACH_LINES_KEY]:
                    out_lines.add(l[ce.ATTACH_LINE_ID_KEY])

            for line in area[ce.AREA_ATTACHMENTS_KEY][ce.ATTACH_LINES_KEY]:
                line_id = line[ce.ATTACH_LINE_ID_KEY]
                line_area_dict[line_id] = (area_id, area_room_type)

        for plan_line in plan[ce.PLAN_LINES_KEY]:

            plan_line_id = plan_line[ce.LINE_ID_KEY]
            # 限制外墙会导致部分原来的观景落地窗和观景飘窗标签被删除，导致打分下降，因此暂时不限制
            # todo 等待与C端协调开通
            if not plan_line[ce.EDGE_COMP_KEY] and plan_line_id not in out_lines:
                continue

            l_area_id, l_area_type = line_area_dict.get(plan_line_id, (None, None))

            # 玻璃落地墙(观景落地窗)
            if plan_line[ce.LINE_TYPE_KEY] == ce.GLASS_FRENCH_TYPE:
                label |= label_factory[ce.LABEL_FRENCH_WINDOW]
                message[label_factory[ce.LABEL_FRENCH_WINDOW]].append(plan_line[ce.LINE_ID_KEY])
                if l_area_type == ce.AreaType.room.value:
                    label |= label_factory[ce.LABEL_BEDROOM_FRENCH_WINDOW]
                elif l_area_type == ce.AreaType.parlour.value:
                    label |= label_factory[ce.LABEL_PARLOUR_FRENCH_WINDOW]

            line_items = plan_line[ce.LINE_ITEMS_KEY]

            for line_item_id in line_items:
                line_item = line_items_dict.get(line_item_id, None)
                if line_item is None:
                    continue
                # 观景飘窗
                if line_item[ce.LINE_ITEM_TYPE_KEY] in ce.BAY_WINDOW_TYPES:
                    label |= label_factory[ce.LABEL_BAY_WINDOW]
                    message[label_factory[ce.LABEL_BAY_WINDOW]].append(line_item[ce.LINE_ITEM_ID_KEY])
                    if l_area_type == ce.AreaType.room.value:
                        label |= label_factory[ce.LABEL_BEDROOM_BAY_WINDOW]
                        message[label_factory[ce.LABEL_BEDROOM_BAY_WINDOW]].append([l_area_id, line_item[ce.LINE_ITEM_ID_KEY]])
                    elif l_area_type == ce.AreaType.parlour.value:
                        label |= label_factory[ce.LABEL_PARLOUR_BAY_WINDOW]
                        message[label_factory[ce.LABEL_PARLOUR_BAY_WINDOW]].append([l_area_id, line_item[ce.LINE_ITEM_ID_KEY]])
                # 观景落地窗
                elif line_item[ce.LINE_ITEM_TYPE_KEY] in ce.FRENCH_WINDOW_TYPES:
                    label |= label_factory[ce.LABEL_FRENCH_WINDOW]
                    message[label_factory[ce.LABEL_FRENCH_WINDOW]].append(line_item[ce.LINE_ITEM_ID_KEY])

                    if l_area_type == ce.AreaType.room.value:
                        label |= label_factory[ce.LABEL_BEDROOM_FRENCH_WINDOW]
                        message[label_factory[ce.LABEL_BEDROOM_FRENCH_WINDOW]].append([l_area_id, line_item[ce.LINE_ITEM_ID_KEY]])
                    elif l_area_type == ce.AreaType.parlour.value:
                        label |= label_factory[ce.LABEL_PARLOUR_FRENCH_WINDOW]
                        message[label_factory[ce.LABEL_PARLOUR_FRENCH_WINDOW]].append([l_area_id, line_item[ce.LINE_ITEM_ID_KEY]])

        # 南北通透
        sn_trans_label, sn_trans_message = is_south_north_trans(plan, label_factory)
        label |= sn_trans_label
        for l in sn_trans_message:
            message[l].extend(sn_trans_message[l])

        # 分间标签
        tmp_label, message_r = room_iter(plan, label_factory)
        label |= tmp_label
        for l in message_r:
            message[l].extend(message_r[l])

        # 本层全南记录
        if tmp_label & label_factory[ce.LABEL_ALL_SOUTH] != 0:
            all_south_flags.append(True)
        else:
            all_south_flags.append(False)

        # 本层全明格局记录
        if tmp_label & label_factory[ce.LABEL_ALL_WINDOW] != 0:
            all_window_flags.append(True)
        else:
            all_window_flags.append(False)

        # 动静分明
        tmp_label, message_m = is_movement_clear(plan, label_factory)
        label |= tmp_label
        for l in message_m:
            if l != ce.EXPLAIN_QUIET_ROOMS:
                message[l].extend(message_m[l])
        if quiet_room_lst is None:
            quiet_room_lst = message_m.get(ce.EXPLAIN_QUIET_ROOMS, [[]])
            moving_room_lst = message_m.get(ce.EXPLAIN_MOVING_ROOMS, [[]])
        else:
            quiet_room_lst[0].extend(message_m.get(ce.EXPLAIN_QUIET_ROOMS, [[]])[0])
            moving_room_lst[0].extend(message_m.get(ce.EXPLAIN_MOVING_ROOMS, [[]])[0])
        # 户型方正
        square_conf = config["square_conf"]
        square_label, square_message = is_square(plan, label_factory, **square_conf)
        label |= square_label

        # 一定是非动静分明的层记录为True
        if tmp_bed_room_cnt >= 2 and tmp_parlour_cnt >= 1 and label & label_factory[ce.LABEL_MOVEMENT_CLEAR] == 0:
            invalid_movement_flags.append(True)
        # 不满足动静分明居室数量或真为动静分明的记录为False
        else:
            invalid_movement_flags.append(False)

    # 要删除的标签列表
    sub_labels = []
    # 低于二室一厅限制时去掉动静分明标签
    if bed_room_cnt < 2 or parlour_cnt < 1 or any(invalid_movement_flags):
        sub_labels.append(label_factory[ce.LABEL_MOVEMENT_CLEAR])

    # 1 室 0 厅去掉卧室带卫
    if bed_room_cnt == 1 and parlour_cnt == 0:
        sub_labels.append(label_factory[ce.LABEL_BEDROOM_TOILET])

    # 去掉非所有层都全南的全南户型 和 已有南北通透标签的(保证南北通透和全南户型互斥)
    if (not all(all_south_flags)) or (label & label_factory[ce.LABEL_NORTH_SOUTH_TRANS] != 0):
        sub_labels.append(label_factory[ce.LABEL_ALL_SOUTH])

    # 去掉非所有层都全明格局的
    if not all(all_window_flags):
        sub_labels.append(label_factory[ce.LABEL_ALL_WINDOW])

    for sub_label in sub_labels:
        if label & sub_label == 0:
            continue
        else:
            label -= sub_label
            if sub_label in message:
                message.pop(sub_label)

    tmp_message = {ce.LABEL_KEY: []}
    for k in message:
        tmp_message[ce.LABEL_KEY].append({ce.LABEL_TYPE_KEY: k, ce.LABEL_DATA_KEY: message[k]})

    tmp_message[ce.ROOM_CNT_KEY] = [bed_room_cnt, parlour_cnt, kitchen_cnt, toilet_cnt]
    tmp_message[ce.LABEL_STR_KEY] = label_factory.code2str(label)
    tmp_message[ce.EXPLAIN_QUIET_ROOMS] = quiet_room_lst
    tmp_message[ce.EXPLAIN_MOVING_ROOMS] = moving_room_lst
    message = tmp_message

    return label, message


if __name__ == "__main__":
    n = comm_lib.get_normal_line(np.array([[0, 0], [1, 0.5]]))
    print(n)
