#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2019 www.ke.com, Inc. All Rights Reserved
"""
分间通用检测
Authors: yudonghai@ke.com
Date: 2019-06-10
"""
from __future__ import division
import logging
import sys
import collections
from operator import itemgetter
import copy

from lib import code_enum as ce
from lib import comm_lib
from lib import geometry_lib


def reorder_points(point_locations):
    """
    从左下角开始，逆时针重排序分间的点
    :param point_locations: list, 点坐标列表
    :return: result, list, 重排序后的点坐标列表
    """
    # 排序找到左下角的点
    current_x = sys.float_info.max
    current_y = sys.float_info.max
    restart_index = None
    current_p = None

    p_cnt = len(point_locations)
    for i, p in enumerate(point_locations):
        p_x, p_y = p[ce.X], p[ce.Y]
        p[ce.CKEY_POINT_TYPE] = 0
        # y值小的优先
        if p_y < current_y or (p_y == current_y and p_x < current_x):
            restart_index, current_x, current_y = i, p_x, p_y
            current_p = p

    if restart_index is None:
        logging.error("can not find left_bottom point")
        restart_index = 0

    pre_index = restart_index - 1
    after_index = (restart_index + 1) % p_cnt

    pre_p = point_locations[pre_index]
    after_p = point_locations[after_index]
    # 顺/逆时针判断
    left_flag = geometry_lib.to_left_test([current_p, after_p], [pre_p])[0]

    if left_flag > 0:
        result_lst = [point_locations[restart_index:p_cnt], point_locations[0:restart_index]]
    else:
        result_lst = [point_locations[restart_index::-1], point_locations[p_cnt - 1:restart_index:-1]]

    result = copy.deepcopy(result_lst[0] + result_lst[1])

    return result


def wall_track(area, dict_lst, line_areas_dict, entrance_info):
    """
    墙体分析
    :param area: dict, 分间数据
    :param dict_lst: list, 点、墙体附件、墙体、分间字典
    :param line_areas_dict: dict, 墙体-所属分间 映射字典
    :param entrance_info: list, <入户门角度，入户门所在墙， 入户门朝向向量>
    :return: wall_info,
    list<
        分间点列表<元素为字典，x和y为必备属性，p_type 为点类型，id为点ID，部分点有>,
        斜墙标记<bool, True表示有斜墙>,
        最大连续墙体<float, 单位mm>,
        分间墙列表<墙体ID，起、止点索引，外墙标记，朝向向量，门窗长度，邻接分间>,
        入户门朝向向量
    >
    """

    points_dict, line_items_dict, lines_dict, areas_dict = dict_lst
    area_id, points, room_type, detail_type, size = itemgetter(*ce.IPTTS)(area)

    point_locations = [{ce.POINT_ID_KEY: p_id,
                        ce.X: points_dict[p_id][ce.X],
                        ce.Y: points_dict[p_id][ce.Y]} for p_id in points]
    # 分间外轮廓点
    outline_points = reorder_points(point_locations)
    outline_points_set = set((p[ce.POINT_ID_KEY] for p in outline_points))
    p_cnt = len(outline_points)

    # 入户门信息
    entrance_value, entrance_line, _ = entrance_info
    entrance_line_id = entrance_line[ce.LINE_ID_KEY] if entrance_line is not None else None

    # 重构后的点列表(加入门窗、内墙点等)
    expand_points = []
    # 点列表分段信息记录，按原始点墙体分割
    line_info_lst = []

    # 入户门朝向向量
    entrance_vector = None
    # 斜墙标记
    oblique_flag = False

    for i, p in enumerate(outline_points):
        before_i = i - 1
        after_i = (i + 1) % p_cnt

        before_p = outline_points[before_i]
        after_p = outline_points[after_i]

        before_p_id = before_p[ce.POINT_ID_KEY]
        after_p_id = after_p[ce.POINT_ID_KEY]

        p_id = p[ce.POINT_ID_KEY]
        p_object = points_dict[p_id]

        # 外墙标记
        edge_flag = False
        # 朝外窗总长度
        out_len = 0.

        # 查找当前点和后一点对应的墙体ID
        candidate_lines = p_object[ce.POINT_LINES_KEY]
        current_line_id = None
        for l_id in candidate_lines:
            l_ps = lines_dict[l_id][ce.LINE_POINTS_KEY]
            if after_p_id in l_ps:
                current_line_id = l_id
                break
        if current_line_id is None:
            logging.error("can not find line for: p0:{} and p1:{}".format(p[ce.POINT_ID_KEY], after_p_id))
            return [[], oblique_flag, 0, line_info_lst, entrance_vector]

        # 当前墙体
        current_line = lines_dict[current_line_id]
        # 当前墙体上的墙体附件
        corr_line_items = current_line[ce.LINE_ITEMS_KEY]
        # 当前墙体连接的分间
        conn_areas = [areas_dict[a] for a in line_areas_dict[current_line_id] if a in areas_dict]

        if len(conn_areas) == 1:
            edge_flag = True

        # 凹凸检测
        to_left_flag = geometry_lib.to_left_test([before_p, p], [after_p])[0]
        to_left_flag = to_left_flag if abs(to_left_flag) > ce.CORNER_LINE_AREA else 0
        if to_left_flag > 0:
            p[ce.CKEY_POINT_TYPE] |= ce.PointType.convex
        elif to_left_flag < 0:
            p[ce.CKEY_POINT_TYPE] |= ce.PointType.concave

        # 墙体朝向，选择射线右侧的一条法线最为朝向向量，与 get_normal_line的实现有关
        norm_lines = geometry_lib.get_normal_line([p, after_p])
        if norm_lines is None:
            logging.error("failed to get normal lines in {}".format(area_id))
            return [[], oblique_flag, 0, line_info_lst, entrance_vector]
        face_line = norm_lines[ce.FACE_NORM_LINE_INDEX]

        # 记录入户门朝向向量
        if entrance_line_id == current_line_id:
            if not edge_flag:
                logging.error("entrance not edge!")
            entrance_vector = face_line

        # 直线中间点检验
        cosin_value, same_line_flag = geometry_lib.same_line(before_p, p, after_p)
        mid_type = ce.PointType.in_line if same_line_flag else ce.PointType.corner
        p[ce.CKEY_POINT_TYPE] |= mid_type

        # 斜边夹角检测（两侧边夹角在5-85度之间）
        if ce.COSIN_85 < abs(cosin_value) < ce.COSIN_5:
            p[ce.CKEY_POINT_TYPE] |= ce.PointType.oblique_corner

        # 内墙判断
        inner_nodes = collections.deque()
        inner_nodes.append(p_id)
        inner_nodes_set = set()
        inner_lines = []

        while inner_nodes:
            cur_node_id = inner_nodes.popleft()
            inner_candidate_lines = points_dict[cur_node_id][ce.POINT_LINES_KEY]

            for l_id in inner_candidate_lines:
                line = lines_dict[l_id]
                line_type, line_points, line_line_items = itemgetter(*ce.LTPT)(line)

                # 虚拟墙\栅栏不计
                if line_type in ce.TRANS_WALL_TYPE:
                    continue

                another_p_id = line_points[-1] if line_points[0] == cur_node_id else line_points[0]
                if another_p_id in inner_nodes_set:
                    continue
                if another_p_id not in outline_points_set:
                    inside_flag = comm_lib.point_in_polygon(points_dict[another_p_id], outline_points)
                    if not line_line_items and inside_flag:
                        p[ce.CKEY_POINT_TYPE] |= ce.PointType.divergence
                        inner_nodes.append(another_p_id)
                        inner_nodes_set.add(another_p_id)
                        inner_lines.append([points_dict[cur_node_id], points_dict[another_p_id]])
                # 垭口断墙形成的内墙
                elif another_p_id not in {before_p_id, after_p_id}:
                    for m_item in line_line_items:
                        if line_items_dict[m_item][ce.LINE_ITEM_TYPE_KEY] != ce.YAKOU:
                            continue
                        li_points = comm_lib.get_endpoint(m_item, lines_dict, line_items_dict, points_dict)
                        li_points = [{ce.X: x[0], ce.Y: x[1]} for x in li_points]
                        short_len = geometry_lib.ps_distance(p, li_points[0])
                        long_len = geometry_lib.ps_distance(p, li_points[1])

                        if short_len > long_len:
                            short_len, long_len = long_len, short_len
                            li_points[0], li_points[1] = li_points[1], li_points[0]

                        if comm_lib.point_in_polygon(li_points[0], outline_points):
                            inner_lines.append([points_dict[cur_node_id], li_points[0]])

        # 查找墙体上的附件，并转化为点，作为特殊标记的点计入轮廓中
        # 增加墙体附件的点到轮廓中
        # 当前墙体上的墙体附件信息列表(<距离当前点最近距离，附件长度，附件两点，附件两点类型>)
        line_items_infos = []
        for li in corr_line_items:
            li_points = comm_lib.get_endpoint(li, lines_dict, line_items_dict, points_dict)
            li_points = [{ce.X: x[0], ce.Y: x[1]} for x in li_points]
            short_len = geometry_lib.ps_distance(p, li_points[0])
            long_len = geometry_lib.ps_distance(p, li_points[1])
            item_len = line_items_dict[li][ce.LINE_ITEM_LENGTH_KEY]

            if short_len > long_len:
                short_len, long_len = long_len, short_len
                li_points[0], li_points[1] = li_points[1], li_points[0]
            is_type = line_items_dict[li][ce.TYPE_IS_KEY]
            line_item_type = line_items_dict[li][ce.LINE_ITEM_TYPE_KEY]
            type_flags = []
            if line_items_dict[li][ce.ENTRANCE_KEY] is not None:
                type_flags = [ce.PointType.entrance_start, ce.PointType.entrance_end]
            elif is_type == ce.IS_WINDOW:
                type_flags = [ce.PointType.window_start, ce.PointType.window_end]
                # 窗和其他认为是朝外
                out_len += item_len
            elif is_type == ce.IS_DOOR:
                type_flags = [ce.PointType.door_start, ce.PointType.door_end]
            elif line_item_type in {ce.YAKOU}:
                type_flags = [ce.PointType.door_start, ce.PointType.door_end]

            if type_flags:
                line_items_infos.append([short_len, item_len, li_points, type_flags])

        # 排序，从离当前点最近的一个附件开始
        line_items_infos = sorted(line_items_infos, key=lambda x: x[0])

        expand_start_index = len(expand_points)
        # 先添加当前点
        expand_points.append(p)
        # 再将当前对应点墙体内部关键点加入
        for lii in line_items_infos:
            # 依次加入两个点
            for k in range(2):
                line_inner_p = {ce.POINT_ID_KEY: None, ce.CKEY_POINT_TYPE: lii[3][k]}
                line_inner_p.update(lii[2][k])
                expand_points.append(line_inner_p)
        expand_end_index = len(expand_points)
        real_conn_area_lst = list(set(line_areas_dict[current_line_id]) - {area_id})
        # 墙为朝向墙时直接将门窗总长度置为墙体长度
        if current_line[ce.LINE_TYPE_KEY] in ce.OUT_WALL_TYPE:
            out_len = geometry_lib.ps_distance(p, after_p)
        # 该段墙体在点列表中的 墙体ID，起、止点，外墙标记，朝向向量，门窗长度，邻接分间
        line_info_lst.append([current_line_id, expand_start_index, expand_end_index,
                              edge_flag, face_line, out_len, real_conn_area_lst])

    # 斜墙、最大墙长度检测
    subline_ps = [sub_p for sub_p in expand_points if (sub_p[ce.CKEY_POINT_TYPE] & ce.KEY_POINT_TYPE)]

    max_line = 0
    subline_cnt = len(subline_ps)
    for i in range(len(subline_ps)):
        p1 = subline_ps[i - 1]
        p2 = subline_ps[i]
        current_item_dist = geometry_lib.ps_distance(p1, p2)
        if subline_ps[i][ce.CKEY_POINT_TYPE] & ce.PointType.oblique_corner:
            after_i = (i + 1) % subline_cnt
            p3 = subline_ps[after_i]
            after_item_dist = geometry_lib.ps_distance(p2, p3)
            # 锐角/钝角两侧墙体长度大于一定值时认为有斜墙
            if current_item_dist > ce.OBLIQUE_LEN and after_item_dist > ce.OBLIQUE_LEN:
                oblique_flag = True
        if not ((p1[ce.CKEY_POINT_TYPE] & ce.LINE_ITEM_POINT_TYPE) and (p2[ce.CKEY_POINT_TYPE] & ce.LINE_ITEM_POINT_TYPE)):
            max_line = current_item_dist if current_item_dist > max_line else max_line

    wall_info = [expand_points, oblique_flag, max_line, line_info_lst, entrance_vector]

    return wall_info


def face_detector(area, points_dict, lines_dict, line_items_dict, line_ps_order_dict):
    """
    朝向解析
    :param area:
    :param points_dict:
    :param lines_dict:
    :param line_items_dict:
    :param line_ps_order_dict:
    :return:
    """
    # 方向 - 窗宽之和
    face_dict = collections.defaultdict(lambda: [0., []])
    # 记录门的朝向，无窗时以门所在方向为面宽所在方向
    door_face_dict = collections.defaultdict(lambda: [0., []])

    # 该分间所关联到墙体附件ID - 长度
    item_len_dict = {}
    # line: direction, length
    line_dir_len_dict = {}

    # 分间附带墙体附件、墙体、其他分间
    area_line_items, area_lines, area_areas = itemgetter(*ce.ATTACH_KEYS)(area[ce.AREA_ATTACHMENTS_KEY])
    area_id, area_points, _, _, room_area_size = itemgetter(*ce.IPTTS)(area)

    # 一个点连接的两面外向弧形通透墙, 需要合并
    merge_lines = []
    merge_lines_set = set()
    real_merge = []
    for p in area_points:
        p_lines = points_dict.get(p, {}).get(ce.POINT_LINES_KEY, [])
        if len(p_lines) == 2:
            line1_id = p_lines[0]
            line2_id = p_lines[1]
            line1 = lines_dict.get(line1_id, {})
            line2 = lines_dict.get(line2_id, {})

            conditions = [
                line1.get(ce.LINE_CURVE_KEY, 0) != 0,
                line2.get(ce.LINE_CURVE_KEY, 0) != 0,
                line1.get(ce.EDGE_COMP_KEY, False),
                line2.get(ce.EDGE_COMP_KEY, False)
            ]
            if all(conditions):
                merge_lines.append([line1_id, line2_id])
                merge_lines_set.add(line1_id)
                merge_lines_set.add(line2_id)
    # 逐段墙体分析朝向
    for l in area_lines:
        line_id = l[ce.ATTACH_LINE_ID_KEY]
        edge = l[ce.EDGE_KEY]
        direction = l[ce.DIRECTION_KEY]
        line_len = l[ce.LENGTH_KEY]

        line_object = lines_dict[line_id]
        line_type, line_points, line_items = itemgetter(*ce.LTPT)(line_object)
        end_ps = line_ps_order_dict[line_id]

        line_dir_len_dict[line_id] = [direction, line_len]
        for li_i in line_items:
            item_len_dict[li_i] = [line_items_dict[li_i][ce.LINE_ITEM_LENGTH_KEY], direction]

        # 需要合并的墙体单独算
        if line_id in merge_lines_set:
            continue

        # 墙体可能为外向墙
        if line_type in ce.OUT_WALL_TYPE.union(ce.TRANS_WALL_TYPE):
            norm_lines = geometry_lib.get_normal_line(end_ps)
            if norm_lines is None:
                logging.error("can not get normal line in face detector")
                continue
            m_ps = geometry_lib.mid_p(end_ps[0], end_ps[1])
            if edge:
                face_dict[direction][0] += line_len
                face_dict[direction][1].append([end_ps, m_ps, norm_lines, 1])
            elif line_object[ce.LINE_TYPE_KEY] in ce.TRANS_WALL_TYPE:
                door_face_dict[direction][0] += line_len
                door_face_dict[direction][1].append([end_ps, m_ps, norm_lines, 1])
        # 再判断附件
        else:
            for line_item_id in line_items:
                line_item = line_items_dict.get(line_item_id, {})
                is_flag = line_item.get(ce.TYPE_IS_KEY, "")
                length = line_item.get(ce.LINE_ITEM_LENGTH_KEY, 0)
                if length == 0:
                    continue
                end_ps, m_ps = geometry_lib.get_endpoint(line_item_id, lines_dict, line_items_dict, points_dict,
                                                         line_ps_order_dict)
                norm_lines = geometry_lib.get_normal_line(end_ps)
                if norm_lines is None:
                    continue

                if edge and is_flag in {ce.IS_WINDOW, ce.IS_OTHER}:
                    face_dict[direction][0] += length
                    face_dict[direction][1].append([end_ps, m_ps, norm_lines, 1])
                elif not edge:
                    door_face_dict[direction][0] += length
                    door_face_dict[direction][1].append([end_ps, m_ps, norm_lines, 1])
    # 合并邻接弧形外墙体
    if merge_lines:
        for a_id, b_id in merge_lines:
            trans_flag = 0
            sum_len = 0.
            for lid in [a_id, b_id]:
                out_flag = False
                lo = lines_dict.get(lid, {})
                line_items = lo.get(ce.LINE_ITEMS_KEY, [])
                if lo.get(ce.LINE_TYPE_KEY, 0) in ce.OUT_WALL_TYPE:
                    out_flag = True
                    sum_len += line_dir_len_dict.get(lid, ['', 0])[1]
                else:
                    for lii in line_items:

                        if line_items_dict.get(lii, {}).get(ce.TYPE_IS_KEY, "") != ce.IS_DOOR:
                            out_flag = True
                            sum_len += line_items_dict.get(lii, {}).get(ce.LINE_ITEM_LENGTH_KEY, 0)
                if out_flag:
                    trans_flag += 1
            if trans_flag < 2:
                continue
            # 两面弧墙都通透
            a_direction, _ = line_dir_len_dict[a_id]
            b_direction, _ = line_dir_len_dict[b_id]
            ad = set(a_direction.split("-"))
            bd = set(b_direction.split("-"))
            comb_d = ad.intersection(bd)
            if not comb_d:
                continue
            merge_direction = list(comb_d)[0]
            a_ps = line_ps_order_dict[a_id]
            b_ps = line_ps_order_dict[b_id]
            close_flag, new_ps = close_lines(a_ps, b_ps)
            if close_flag:
                m_ps = geometry_lib.mid_p(*new_ps)
                norm_lines = geometry_lib.get_normal_line(new_ps)
                face_dict[merge_direction][0] += min(sum_len, geometry_lib.ps_distance(*new_ps))
                face_dict[merge_direction][1].append([new_ps, m_ps, norm_lines, 1])
                real_merge.append([[a_id, b_id], new_ps, merge_direction])

    # 邻接被认为是外到分间
    # todo 外向分间的不完全通透问题(如：只有侧面有窗）
    for att_area in area_areas:
        att_room_type = att_area[ce.ATTACH_AREA_ROOM_TYPE_KEY]
        if att_room_type in ce.OUT_ROOM_TYPE:
            face_type = 0
            if att_room_type in {ce.AreaType.garden.value, ce.AreaType.terrace.value}:
                face_type = 1
            for sli in att_area[ce.SHARED_LINE_ITEMS_KEY]:
                face_dict[item_len_dict[sli][1]][0] += item_len_dict[sli][0]
                end_ps, m_ps = geometry_lib.get_endpoint(sli, lines_dict, line_items_dict, points_dict, line_ps_order_dict)
                norm_lines = geometry_lib.get_normal_line(end_ps)
                if norm_lines is None:
                    continue
                face_dict[item_len_dict[sli][1]][1].append([end_ps, m_ps, norm_lines, face_type])
            for sl in att_area[ce.SHARED_LINES_KEY]:
                slo = lines_dict[sl]
                if slo[ce.LINE_TYPE_KEY] not in ce.TRANS_WALL_TYPE:
                    continue
                real_dir, real_len = line_dir_len_dict[sl]
                face_dict[real_dir][0] = line_dir_len_dict[sl][1]
                end_ps = line_ps_order_dict[sl]
                norm_lines = geometry_lib.get_normal_line(end_ps)
                m_ps = geometry_lib.mid_p(end_ps[0], end_ps[1])
                if norm_lines is None:
                    continue
                face_dict[real_dir][1].append([end_ps, m_ps, norm_lines, face_type])

    line_direction_len_dict = collections.defaultdict(float)
    for lid in line_dir_len_dict:
        line_direction_len_dict[line_dir_len_dict[lid][0]] += line_dir_len_dict[lid][1]

    max_direction_len = 0.
    max_len_direction = None
    for d in line_direction_len_dict:
        if line_direction_len_dict[d] > max_direction_len:
            max_len_direction = d
    # face_dict = face_combine(face_dict)
    return face_dict, door_face_dict, max_len_direction, real_merge


def face_combine(face_dict):
    """
    合并两个非常靠近的不同朝向，形成一个总朝向
    :param face_dict:
    :return:
    """

    merge_lst = []
    merge_set = set()
    for base_direction in face_dict:
        base_len, base_lines_lst = face_dict[base_direction]
        for comp_direction in face_dict:
            if base_direction == comp_direction:
                continue
            comp_len, comp_lines_lst = face_dict[comp_direction]

            for bi, base_item in enumerate(base_lines_lst):
                base_end_ps, base_m_ps, base_norm_lines, base_face_type = base_item
                for ci, comp_item in enumerate(comp_lines_lst):
                    if base_len < 1000 or comp_len < 1000:
                        continue
                    if (base_direction, bi) in merge_set or (comp_direction, ci) in merge_set:
                        continue
                    comp_end_ps, comp_m_ps, comp_norm_lines, comp_face_type = comp_item
                    flag, merge_ps = close_lines(base_end_ps, comp_end_ps)
                    if flag:
                        merge_lst.append([base_direction, comp_direction, bi, ci, merge_ps, base_face_type, comp_face_type])
                        merge_set.add((base_direction, bi))
                        merge_set.add((comp_direction, ci))

    real_merge_lst = []
    for i, item in enumerate(merge_lst):
        a_direction, b_direction, ai, bi, ps, at, bt = item
        m_p = geometry_lib.mid_p(*ps)
        norm_ls = geometry_lib.get_normal_line(ps)
        if norm_ls is None:
            continue
        final_type = at & bt
        sum_len = min(geometry_lib.ps_distance(*ps), face_dict[a_direction][0] + face_dict[b_direction][0])

        merge_direction = None
        if a_direction in b_direction:
            merge_direction = b_direction
        elif b_direction in a_direction:
            merge_direction = a_direction
        else:
            ad = set(a_direction.split("-"))
            bd = set(b_direction.split("-"))
            comb_d = ad.intersection(bd)
            if comb_d:
                merge_direction = list(comb_d)[0]
            else:
                if len(ad) == 1 and len(bd) == 1:
                    ad = list(ad)[0]
                    bd = list(bd)[0]
                    if ad in {ce.CKEY_NORTH, ce.CKEY_SOUTH} and bd in {ce.CKEY_WEST, ce.CKEY_EAST}:
                        merge_direction = ad + '-' + bd
                    elif bd in {ce.CKEY_NORTH, ce.CKEY_SOUTH} and ad in {ce.CKEY_WEST, ce.CKEY_EAST}:
                        merge_direction = bd + '-' + ad
        real_merge_lst.append([item, sum_len, merge_direction, [ps, m_p, norm_ls, final_type]])

    del_dict = collections.defaultdict(list)
    for item, sum_len, m_d, value in real_merge_lst:
        if m_d is None:
            continue
        a_direction, b_direction, ai, bi, ps, at, bt = item
        del_dict[a_direction].append(ai)
        del_dict[b_direction].append(bi)
    for d in del_dict:
        idxs = del_dict[d]
        idxs = sorted(idxs, reverse=True)
        for idx in idxs:
            del face_dict[d][1][idx]
            if len(face_dict[d][1]) == 0:
                del face_dict[d]

    for item, sum_len, m_d, value in real_merge_lst:
        if m_d is None:
            continue
        face_dict[m_d][0] = sum_len
        face_dict[m_d][1].append(value)
    return face_dict


def close_lines(line_a, line_b, diff_th=500):
    """
    分间外围有序点组成的线之间是否紧邻
    :param line_a:
    :param line_b:
    :param diff_th:
    :return:
    """
    at_dist = geometry_lib.ps_distance(line_a[1], line_b[0])
    bt_dist = geometry_lib.ps_distance(line_b[1], line_a[0])
    flag = False
    m_line = []
    target_p = None
    if min(at_dist, bt_dist) < diff_th:
        flag = True
        if at_dist < bt_dist:
            m_line = [line_a[0], line_b[1]]
            target_p = geometry_lib.mid_p(line_a[1], line_b[0])
        else:
            m_line = [line_b[0], line_a[1]]
            target_p = geometry_lib.mid_p(line_b[1], line_a[0])
    if flag:
        real_p = geometry_lib.mid_p(*m_line)
        diff_x = target_p[ce.X] - real_p[ce.X]
        diff_y = target_p[ce.Y] - real_p[ce.Y]
        m_line = [{ce.X: m_line[0][ce.X] + diff_x, ce.Y: m_line[0][ce.Y] + diff_y}, {ce.X: m_line[1][ce.X] + diff_x, ce.Y:  m_line[1][ce.Y] + diff_y}]
    return flag, m_line


def main_face(face_dict, door_face_dict, max_len_direction):
    """
    主朝向
    :param face_dict:
    :param door_face_dict:
    :param max_len_direction:
    :return:
    """
    m_face, main_face_len = None, 0

    use_face_dict = face_dict if face_dict else door_face_dict
    for k in use_face_dict:
        f_len = use_face_dict[k][0]
        if m_face is None:
            m_face = k
            main_face_len = f_len
            continue
        # 最大开窗方向，相同大小南向优先
        same_south = all([f_len == main_face_len, ce.CKEY_SOUTH in k, ce.CKEY_SOUTH not in m_face])
        if f_len > main_face_len or same_south:
            m_face = k
            main_face_len = f_len
    m_face = max_len_direction if m_face is None else m_face
    return m_face, main_face_len, use_face_dict


def width_group(area, m_face, merge_lines, lines_dict, points_dict):
    """
    面宽墙体分组，主要针对面宽墙体不在一条直线上时提供候选
    :param area:
    :param m_face:
    :param merge_lines: 需要合并的墙体
    :param lines_dict:
    :param points_dict:
    :return:
    """
    area_line_items, area_lines, area_areas = itemgetter(*ce.ATTACH_KEYS)(area[ce.AREA_ATTACHMENTS_KEY])
    merge_lines_set = set()
    width_line_ids = set()

    # 面宽计算
    width_lines = []
    for [a, b], m_ps, m_d in merge_lines:
        merge_lines_set.add(a)
        merge_lines_set.add(b)
        if not (m_d in m_face or m_face in m_d):
            continue
        width_lines.append([m_ps, geometry_lib.ps_distance(*m_ps)])

    for l in area_lines:
        direction, length, l_id = itemgetter(*ce.DLI)(l)
        if l_id in merge_lines_set:
            continue
        if direction != m_face:
            continue
        lo = lines_dict[l_id]
        lps_id = lo[ce.LINE_POINTS_KEY]
        if len(lps_id) != 2:
            continue
        width_line_ids.add(l_id)
        lps = [points_dict[lps_id[0]], points_dict[lps_id[1]]]
        width_lines.append([lps, length])
    width_line_ids = width_line_ids.union(merge_lines_set)
    width_lines = sorted(width_lines, key=lambda x: x[1], reverse=True)
    if not width_lines:
        return [[]]

    groups = []
    for ps, llen in width_lines:
        if not groups:
            groups.append([[ps, llen]])
        else:
            group_joined = False
            for g in groups:
                base_ps = g[0][0]
                dist = geometry_lib.p2line_distance(ps[0], base_ps)
                if dist < ce.MAIN_FACE_DIFF:
                    g.append([ps, llen])
                    group_joined = True
            if not group_joined:
                groups.append([[ps, llen]])
    return groups, width_line_ids


def width_depth_comb(width_groups, area_lines, lines_dict, points_dict, m_face, width_line_ids, room_area_size, track_info):
    """
    面宽进深组合优化器
    :param width_groups: 面宽分组
    :param area_lines: 分间墙体字典
    :param lines_dict: 墙体点字典
    :param points_dict: 点坐标字典
    :param m_face: 主朝向
    :param width_line_ids: 面宽墙体ID
    :param room_area_size: 分间面积
    :param track_info: 分间墙体点路径
    :return: [[面宽, 进深, 面宽 / 进深, 面宽*进深与分间面积差的绝对值, 面宽点坐标, 进深点坐标], ...]
    """
    real_result = []
    for g in width_groups:
        g_size = len(g)

        # 面宽墙体数量不超过3
        if g_size > 3 or g_size == 0:
            continue

        wd_paires = []

        index_width_len_lst = []
        for i in range(1, g_size + 1):
            width_indexes = []
            comm_lib.combination(range(g_size), i, 0, [], width_indexes)
            for index_lst in width_indexes:
                w_len = 0.
                for j in index_lst:
                    _, line_len = g[j]
                    w_len += line_len
                index_width_len_lst.append([copy.deepcopy(index_lst), w_len])

        for line_indexes, width_len in index_width_len_lst:
            min_diff = None
            min_diff_depth = None
            for line_index in line_indexes:
                line_ps, line_l = g[line_index]

                norm_ls = geometry_lib.get_normal_line(line_ps)
                if norm_ls is None:
                    continue

                # 三条法线，从面宽投影向正对面，取最小值作为进深参考值
                for nl in norm_ls:
                    for l in area_lines:
                        direction, length, l_id = itemgetter(*ce.DLI)(l)
                        l_ps = lines_dict[l_id][ce.LINE_POINTS_KEY]
                        l_ps = [points_dict[l_ps[0]], points_dict[l_ps[1]]]

                        if direction == m_face or l_id in width_line_ids:
                            continue
                        # 与面宽墙体角度不超过正负45度
                        cos_v = geometry_lib.line_angle(line_ps, l_ps)
                        if abs(cos_v) < 0.7:
                            continue
                        flags = geometry_lib.to_left_test(nl, l_ps)
                        if flags[0] * flags[1] <= 0 and (abs(flags[0]) + abs(flags[1])) > ce.DEPTH_TH:
                            # 法线与对面墙体的交点和法线在朝向面起点的距离
                            c_p = geometry_lib.cross_point(l_ps, nl)
                            if c_p is None:
                                continue
                            current_depth = geometry_lib.ps_distance(nl[0], c_p)
                            new_area = width_len * current_depth
                            area_diff = abs(new_area - room_area_size)
                            if min_diff is None or area_diff < min_diff:
                                min_diff = area_diff
                                min_diff_depth = geometry_lib.trans2mid([nl[0], c_p], line_ps)
            if min_diff_depth is None:
                continue
            wd_paires.append([line_indexes, width_len, min_diff_depth, min_diff])
        if not wd_paires:
            continue

        wd_pair = sorted(wd_paires, key=lambda x: x[3])[0]
        real_width = combine_width(wd_pair[1], wd_pair[2], track_info)

        if real_width is None:
            continue
        width_len_p = geometry_lib.ps_distance(*real_width)
        real_depth_p = geometry_lib.ps_distance(*wd_pair[2])

        real_size_diff = abs(room_area_size - width_len_p * real_depth_p)

        real_result.append([width_len_p, real_depth_p, width_len_p / real_depth_p, real_size_diff, real_width, wd_pair[2]])
    real_result = sorted(real_result, key=lambda x: x[3])
    return real_result


def approximate_width_depth(area, points_dict, main_face):
    size = area[ce.AREA_SIZE_KEY]
    area_ps = [points_dict[aid] for aid in area[ce.AREA_POINTS_KEY]]
    out_rectangle = comm_lib.get_circumscribed_rectangle(area_ps)
    # 没有中点，认为找轮廓失败
    if len(out_rectangle) == 4:
        return None
    max_x, max_y, min_x, min_y, mid_x, mid_y = out_rectangle
    # 默认窗在南北
    w = [{ce.X: min_x, ce.Y: mid_y}, {ce.X: max_x, ce.Y: mid_y}]
    d = [{ce.X: mid_x, ce.Y: min_y}, {ce.X: mid_x, ce.Y: max_y}]
    # 否则调换面宽进深
    if ce.CKEY_SOUTH not in main_face and ce.CKEY_NORTH not in main_face:
        w, d = d, w
    area_diff = abs((max_x - min_x) * (max_y - min_y) - size)

    # width_len, real_depth, width_len / real_depth, size_diff, real_width, cand_depths[0]
    width_len = abs(w[0][ce.X] - w[1][ce.X]) + abs(w[0][ce.Y] - w[1][ce.Y])
    depth_len = abs(d[0][ce.X] - d[1][ce.X]) + abs(d[0][ce.Y] - d[1][ce.Y])
    div_ratio = width_len / (depth_len + 0.)

    return [width_len, depth_len, div_ratio, area_diff, w, d]


def width_depth_face(base_func):
    """
    面宽进深和朝向
    Frame.explain_message 增加
    explain_width_depth: {area_id: }
    explain_face: {area_id: }
    :param base_func: function, 被装饰函数
    :return: 装饰器函数
    """
    def item_func(frame, *args, **kwargs):
        logging.debug("general.width_depth")
        explain_width_depth = {}
        explain_face = {}
        if frame.state != ce.State.valid:
            return base_func(frame, *args, **kwargs)

        frame_vector = frame.vector
        explain_wall = frame.explain_message[ce.EXPLAIN_WALL]
        # 逐层
        for plan_vector in frame_vector[frame.plan_key]:
            areas = plan_vector[ce.PLAN_AREAS_KEY]
            points_dict, line_items_dict, lines_dict, _ = itemgetter(*ce.DICTS)(plan_vector)
            # 逐分间
            for area in areas:
                room_area_size = area[ce.AREA_SIZE_KEY]
                area_name = area[ce.AREA_ROOM_NAME_KEY]
                area_id = area[ce.AREA_ID_KEY]
                area_line_items, area_lines, area_areas = itemgetter(*ce.ATTACH_KEYS)(area[ce.AREA_ATTACHMENTS_KEY])

                track_info = explain_wall[area_id]
                expand_points, oblique_flag, max_line, line_info_lst, entrance_vector = track_info
                line_ps_order_dict = {}
                if not expand_points:
                    continue
                for item in line_info_lst:
                    current_line_id, expand_start_index, expand_end_index, _, _, _, _ = item
                    if expand_end_index == len(expand_points):
                        expand_end_index = 0
                    line_ps_order_dict[current_line_id] = [expand_points[expand_start_index], expand_points[expand_end_index]]

                # 朝向字典
                face_dict, door_face_dict, max_len_direction, merge_lines = face_detector(area, points_dict, lines_dict, line_items_dict, line_ps_order_dict)
                # 主朝向
                m_face, main_face_len, use_face_dict = main_face(face_dict, door_face_dict, max_len_direction)
                if m_face is None:
                    logging.error(u"{} lack window/door".format(area[ce.AREA_ROOM_NAME_KEY]))
                    continue

                width_groups, width_line_ids = width_group(area, m_face, merge_lines, lines_dict, points_dict)

                wd_pairs = width_depth_comb(width_groups, area_lines, lines_dict, points_dict, m_face, width_line_ids, room_area_size, track_info)

                if wd_pairs:
                    explain_width_depth[area_id] = [area_name] + wd_pairs[0]
                else:
                    explain_width_depth[area_id] = [area_name] + [None] * 6
                explain_face[area_id] = [m_face, main_face_len, face_dict]
                logging.debug(u"{} -- width: {}, depth: {}, w_div_d: {}".format(*explain_width_depth[area_id]))
                logging.debug(u"width_face: {}, width_face_len: {}".format(*explain_face[area_id]))

            frame.explain_message[ce.EXPLAIN_WIDTH_DEPTH] = explain_width_depth
            frame.explain_message[ce.EXPLAIN_FACE] = explain_face

        return base_func(frame, *args, **kwargs)
    return item_func


def combine_width(width, depth_ps, wall_track_info):
    """
    组合面宽墙体
    :param width:
    :param depth_ps:
    :param wall_track_info:
    :return:
    """
    expand_points, oblique_flag, max_line, line_info_lst, entrance_vector = wall_track_info
    
    depth_mid_p = geometry_lib.mid_p(*depth_ps)

    shadow_ps = [[depth_ps[0], 0],
                 [depth_ps[1], geometry_lib.ps_distance(depth_ps[1], depth_ps[0])]]

    for p in expand_points:
        if not p[ce.CKEY_POINT_TYPE] & ce.PointType.corner:
            continue
        shadow_p = geometry_lib.shadow_point(depth_ps, p, on_segment=True)
        if shadow_p is None:
            continue
        shadow_ps.append([shadow_p, geometry_lib.ps_distance(shadow_p, depth_ps[0])])
    shadow_ps = sorted(shadow_ps, key=lambda x: x[1])
    cand_widths = []
    for i in range(len(shadow_ps) - 1):
        cur_p = shadow_ps[i][0]
        end_p = shadow_ps[i + 1][0]
        line_len = geometry_lib.ps_distance(cur_p, end_p)
        if line_len < 1:
            continue
        normals = geometry_lib.get_normal_line([cur_p, end_p])
        if normals is None:
            continue
        mid_norm, _, _ = normals
        cross_p_dict = collections.defaultdict(list)
        for line_item in line_info_lst:
            current_line_id, start_index, end_index, _, _, _, _ = line_item
            if end_index == len(expand_points):
                end_index = 0
            line_ps = [expand_points[start_index], expand_points[end_index]]
            min_x = min(line_ps[0][ce.X], line_ps[1][ce.X])
            min_y = min(line_ps[0][ce.Y], line_ps[1][ce.Y])
            max_x = max(line_ps[0][ce.X], line_ps[1][ce.X])
            max_y = max(line_ps[0][ce.Y], line_ps[1][ce.Y])
            cro_p = geometry_lib.cross_point(line_ps, mid_norm)
            if cro_p is None:
                continue
            # 粗略断定交点在线段上
            if not (min_x <= cro_p[ce.X] <= max_x and min_y <= cro_p[ce.Y] <= max_y):
                continue
            flag = geometry_lib.to_left_test(depth_ps, [cro_p])[0]
            if flag == 0:
                continue
            flag = -1 if flag < 0 else 1
            cross_p_dict[flag].append(cro_p)
        if 1 not in cross_p_dict or -1 not in cross_p_dict:
            logging.info("no crossing line")
            continue
        width_line = []
        for k in [1, -1]:
            cand_ps = cross_p_dict[k]
            dist_lst = [[x, geometry_lib.ps_distance(x, mid_norm[0])] for x in cand_ps]
            dist_lst = sorted(dist_lst, key=lambda x: x[1])
            width_line.append(dist_lst[0][0])
        width_len = geometry_lib.ps_distance(*width_line)
        cand_widths.append([width_line, width_len])
    flag_widths = [[x[0], abs(x[1] - width)] for x in cand_widths]
    flag_widths = sorted(flag_widths, key=lambda x: x[1])
    if not flag_widths:
        return None
    return flag_widths[0][0]


def area_size(base_func):
    """
    面积
    Frame.explain_message 增加
    explain_size: {area_id:}
    :param base_func: function, 被装饰函数
    :return: 装饰器函数
    """
    def item_func(frame, *args, **kwargs):
        logging.debug("general.area_size")
        if frame.state != ce.State.valid:
            return base_func(frame, *args, **kwargs)

        frame_vector = frame.vector
        explain_size = {}

        explain_width_depth = frame.explain_message[ce.EXPLAIN_WIDTH_DEPTH]
        explain_face = frame.explain_message[ce.EXPLAIN_FACE]
        # 逐层
        for plan_vector in frame_vector[frame.plan_key]:
            areas = plan_vector[ce.PLAN_AREAS_KEY]
            # 逐分间
            for area in areas:
                use_size = area[ce.AREA_SIZE_KEY]
                area_id = area[ce.AREA_ID_KEY]
                area_width, area_depth = explain_width_depth.get(area_id, ['', 0, 0, 0])[1:3]
                _, main_face_len, face_dict = explain_face.get(area_id, ['', 0, {}])
                gray_size = use_size
                if face_dict and area_width is not None:
                    gray_size = max(use_size - (area_width * 2 * main_face_len), 0)

                # 分间附带墙体附件、墙体、其他分间
                area_line_items, area_lines, area_areas = itemgetter(*ce.ATTACH_KEYS)(area[ce.AREA_ATTACHMENTS_KEY])

                door_cnt = 0
                # 外窗 / 门
                for li in area_line_items:
                    edge, direction, length, is_flag, li_id = itemgetter(*ce.EDLII)(li)
                    if is_flag == ce.IS_DOOR:
                        door_cnt += 1
                door_size = door_cnt * ce.DOOR_MUL
                explain_size[area_id] = [use_size, gray_size, door_size]

                area_name = area[ce.AREA_ROOM_NAME_KEY]
                logging.debug(u"{} -- size: {}, gray_size: {}, door_size: {}".format(area_name, *explain_size[area_id]))

        frame.explain_message[ce.EXPLAIN_SIZE] = explain_size
        return base_func(frame, *args, **kwargs)
    return item_func


def area_wall(base_func):
    """
    墙面
    Frame.explain_message 增加
    explain_wall: {area_id: list<
        分间点列表<元素为字典，x和y为必备属性，p_type 为点类型，id为点ID，部分点有>,
        斜墙标记<bool, True表示有斜墙>,
        最大连续墙体<float, 单位mm>,
        分间墙列表<墙体ID，起、止点索引，外墙标记，朝向向量，门窗长度，邻接分间>,
        入户门朝向向量
    >}
    :param base_func: function, 被装饰函数
    :return: 装饰器函数
    """
    def item_func(frame, *args, **kwargs):
        logging.debug("general.area_wall")
        if frame.state != ce.State.valid:
            return base_func(frame, *args, **kwargs)

        frame_vector = frame.vector
        line_areas_dict = frame.explain_message[ce.EXPLAIN_LINE_AREAS]
        explain_entrance = frame.explain_message[ce.EXPLAIN_ENTRANCE]

        explain_wall = {}
        # 逐层
        for plan_vector in frame_vector[frame.plan_key]:
            areas = plan_vector[ce.PLAN_AREAS_KEY]
            points_dict, line_items_dict, lines_dict, areas_dict = itemgetter(*ce.DICTS)(plan_vector)
            dict_lst = [points_dict, line_items_dict, lines_dict, areas_dict]
            # 逐分间
            for area in areas:
                track_info = wall_track(area, dict_lst, line_areas_dict, explain_entrance)
                _, _, _, _, entrance_vector = track_info
                if entrance_vector is not None:
                    frame.explain_message[ce.EXPLAIN_ENTRANCE][2] = entrance_vector
                explain_wall[area[ce.AREA_ID_KEY]] = track_info
        frame.explain_message[ce.EXPLAIN_WALL] = explain_wall
        return base_func(frame, *args, **kwargs)
    return item_func


def window_door(base_func):
    """
    门窗
    Frame.explain_message 增加
    explain_window_door: {area_id:}
    :param base_func: function, 被装饰函数
    :return: 装饰器函数
    """
    def item_func(frame, *args, **kwargs):
        logging.debug("general.window_door")
        if frame.state != ce.State.valid:
            return base_func(frame, *args, **kwargs)

        frame_vector = frame.vector
        explain_window_door = {}

        explain_face = frame.explain_message[ce.EXPLAIN_FACE]
        explain_wall = frame.explain_message[ce.EXPLAIN_WALL]

        # 逐层
        for plan_vector in frame_vector[frame.plan_key]:
            areas = plan_vector[ce.PLAN_AREAS_KEY]
            points_dict, line_items_dict, lines_dict, _ = itemgetter(*ce.DICTS)(plan_vector)
            for area in areas:
                # 分间属性
                area_id, _, _, _, current_area_size = itemgetter(*ce.IPTTS)(area)
                attach_items = area[ce.AREA_ATTACHMENTS_KEY][ce.ATTACH_LINE_ITEMS_KEY]
                # 统计属性
                m_face, _, face_dict = explain_face.get(area_id, [None, 0, {}])
                wall_info = explain_wall.get(area_id, [[], False, 0, [], []])

                expand_points, oblique_flag, max_line, line_info_lst, entrance_vector = wall_info
                faces = face_dict.keys()

                # 凸窗检测
                convex_window = convex_window_detect(attach_items, expand_points, line_info_lst, line_items_dict, lines_dict)
                # 朝外窗总长
                all_window_len = 0

                for face in face_dict:
                    all_window_len += face_dict[face][0]
                if current_area_size == 0.:
                    w_div_floor = -1
                else:
                    w_div_floor = all_window_len * ce.DEFAULT_WINDOW_H / (current_area_size + 0.)

                explain_window_door[area_id] = [all_window_len, w_div_floor, faces, m_face, convex_window]

        frame.explain_message[ce.EXPLAIN_WINDOW_DOOR] = explain_window_door
        return base_func(frame, *args, **kwargs)
    return item_func


def convex_window_detect(attach_items, expand_points, line_info_lst, line_items_dict, lines_dict):
    """
    凸窗检测
    :param attach_items:
    :param expand_points:
    :param line_info_lst:
    :param line_items_dict:
    :param lines_dict:
    :return:
    """
    # 飘窗算凸窗的一种
    for attach_line_item in attach_items:
        item_o = line_items_dict[attach_line_item[ce.ATTACH_LINE_ITEM_ID_KEY]]
        if item_o[ce.LINE_ITEM_TYPE_KEY] in ce.CONVEX_BAY_WINDOW_TYPES:
            return True

    # 凸窗起始于凹点
    wall_ps_cnt = len(expand_points)
    concave_index = [i for i in range(wall_ps_cnt)
                     if expand_points[i][ce.CKEY_POINT_TYPE] & ce.PointType.concave]
    concave_cnt = len(concave_index)

    for i, head in enumerate(concave_index):
        tail = concave_index[(i + 1) % concave_cnt]
        # 只查直角凹顶点之间，且中间隔两个顶点
        pair_type = expand_points[head][ce.CKEY_POINT_TYPE] | expand_points[tail][ce.CKEY_POINT_TYPE]
        if 0 < (tail - head) < 2 or (pair_type & ce.PointType.oblique_corner):
            continue
        # 两凹点水平/竖直距离
        end_dist = geometry_lib.p2line_distance(expand_points[tail], expand_points[head - 1: head + 1])
        if end_dist > ce.CONVEX_WINDOW_BASE_DIFF:
            continue
        # 两凹点之间的点序列
        seq = list(range(head + 1, tail)) if head < tail else (list(range(head + 1, wall_ps_cnt)) + list(range(tail)))

        # 中间凸顶点数量
        convex_cnt = sum([1 for k in seq if expand_points[k][ce.CKEY_POINT_TYPE] & ce.PointType.convex])
        if convex_cnt != 2:
            continue
        # 窗数量
        window_cnt = sum([1 for k in seq
                          if (expand_points[k][ce.CKEY_POINT_TYPE] & ce.PointType.window_start)])
        if window_cnt < ce.CONVEX_WINDOW_WINDOW_CNT:
            continue

        # 两凹点中间点离凹点连线最大距离不应超过阈值
        base_line = [expand_points[head], expand_points[tail]]
        max_dist = 0
        for j in seq:
            item_dist = geometry_lib.p2line_distance(expand_points[j], base_line)
            max_dist = item_dist if item_dist > max_dist else max_dist
        if max_dist > ce.CONVEX_WINDOW_WIDTH or max_dist == 0:
            continue
        return True

    # 弧形窗、墙检测
    for line_info in line_info_lst:
        current_line_id, expand_start_index, expand_end_index, edge_flag, face_line, out_len, real_conn_area_lst = line_info
        curve = lines_dict.get(current_line_id, {ce.LINE_CURVE_KEY: None})[ce.LINE_CURVE_KEY]
        if curve is None or out_len <= 0 or len(expand_points) == 0:
            continue
        if expand_end_index >= len(expand_points):
            expand_end_index = 0
        head = expand_points[expand_start_index]
        tail = expand_points[expand_end_index]
        curve_condition = -1.
        if head[ce.X] > tail[ce.X] or (head[ce.X] == tail[ce.X] and head[ce.Y] < tail[ce.Y]):
            curve_condition = 1.
        if curve_condition * curve > 0:
            return True

    return False
