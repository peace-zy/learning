#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2019 www.ke.com, Inc. All Rights Reserved
"""
计算几何方法
Authors: yudonghai@ke.com
Date: 2019-06-10
"""
from __future__ import division
import math

import numpy as np

import __init__
from lib import code_enum as ce


def to_left_test(seg_line, points):
    """
    TO-LEFT 测试，用于判断点在直线哪一侧(左侧为正值，右侧为负值）
    :param seg_line: list<[{'x': x_value, 'y': y_value},]> 直线的两点
    :param points: list<[{'x': x_value, 'y': y_value},]> 点坐标列表
    :return: flags, list<float>, TO-LEFT 计算结果
    """
    if not isinstance(seg_line, list) or len(seg_line) != 2:
        return None

    head = seg_line[0]
    tail = seg_line[1]

    flags = []
    for p in points:
        f1 = head[ce.X] * (tail[ce.Y] - p[ce.Y])
        f2 = -head[ce.Y] * (tail[ce.X] - p[ce.X])
        f3 = tail[ce.X] * p[ce.Y] - p[ce.X] * tail[ce.Y]
        result = f1 + f2 + f3
        flags.append(result)

    return flags


def get_endpoint(line_item_id, line_dict, line_item_dict, p_dict, line_ps_order_dict=None):
    """
    获取墙体附件的两个端点及中点
    :param line_item_id: string, 墙体附件ID
    :param line_dict: dict, 墙体字典
    :param line_item_dict: dict, 墙体附件字典
    :param p_dict: dict, 点坐标字典
    :param line_ps_order_dict: dict, 墙体有序点字典<str: [start_point, end_point]>, 用于生成指定顺序的点
    :return: end_ps: list<[{'x': x1, 'y': y1}, {'x': x2, 'y': y2}]>,
             mid_p: dict<{'x': x_mid, 'y': y_mid}>
             墙体附件真实两端坐标点
    """
    line_info = line_dict[line_item_dict[line_item_id][ce.LINE_ITEM_LINE_KEY]]
    line_item_info = line_item_dict[line_item_id]
    offset_type = 0  # 0: 从前往后offset; 1: 从后往前

    line_item_start_offset = line_item_info[ce.LINE_ITEM_START_KEY]
    line_item_length = line_item_info[ce.LINE_ITEM_LENGTH_KEY]

    line_points = line_info[ce.LINE_POINTS_KEY]
    start_index = line_item_info[ce.LINE_ITEM_START_INDEX_KEY]
    end_index = -1 if start_index == 0 else 0

    start_p = p_dict[line_points[start_index]]
    end_p = p_dict[line_points[end_index]]
    diff_x = end_p[ce.X] - start_p[ce.X]
    diff_y = end_p[ce.Y] - start_p[ce.Y]
    line_len = math.sqrt(diff_x * diff_x + diff_y * diff_y)

    if line_ps_order_dict is not None:
        ordered_points = line_ps_order_dict[line_item_dict[line_item_id][ce.LINE_ITEM_LINE_KEY]]
        if ps_distance(ordered_points[0], start_p) > ps_distance(ordered_points[0], end_p):
            start_p, end_p = end_p, start_p
            line_item_start_offset = line_len - line_item_start_offset - line_item_length
            diff_x = -diff_x
            diff_y = -diff_y

    # 竖线
    if start_p[ce.X] == end_p[ce.X]:
        head_x = tail_x = start_p[ce.X]

        add_direction = 1 if start_p[ce.Y] < end_p[ce.Y] else -1

        head_y = start_p[ce.Y] + add_direction * line_item_start_offset
        tail_y = start_p[ce.Y] + add_direction * (line_item_start_offset + line_item_length)

    # 横线
    elif start_p[ce.Y] == end_p[ce.Y]:
        head_y = tail_y = start_p[ce.Y]

        add_direction = 1 if start_p[ce.X] < end_p[ce.X] else -1

        head_x = start_p[ce.X] + add_direction * line_item_start_offset
        tail_x = start_p[ce.X] + add_direction * (line_item_start_offset + line_item_length)

    # 斜线
    else:
        head_x = (line_item_start_offset * diff_x) / line_len + start_p[ce.X]
        head_y = (line_item_start_offset * diff_y) / line_len + start_p[ce.Y]
        tail_x = ((line_item_start_offset + line_item_length) * diff_x) / line_len + start_p[ce.X]
        tail_y = ((line_item_start_offset + line_item_length) * diff_y) / line_len + start_p[ce.Y]

    end_ps = [{ce.X: head_x, ce.Y: head_y}, {ce.X: tail_x, ce.Y: tail_y}]
    mid_p = {ce.X: (head_x + tail_x) / 2., ce.Y: (head_y + tail_y) / 2.}

    return end_ps, mid_p


def p2line_distance(p, line):
    """
    点到直线距离
    :param p: dict<{'x': x_value, 'y': y_value}> 点坐标
    :param line: list<[{'x': x_value, 'y': y_value},]> 直线的两点
    :return: distance, float, 点到直线的垂直距离
    """
    distance = None
    if not isinstance(line, list) or len(line) != 2:
        return distance
    line_vec = np.array([line[1][ce.X] - line[0][ce.X], line[1][ce.Y] - line[0][ce.Y]])
    p_vec = np.array([p[ce.X] - line[0][ce.X], p[ce.Y] - line[0][ce.Y]])
    line_mod_square = float(line_vec.dot(line_vec))
    if line_mod_square == 0:
        return distance
    shadow_vec_len = line_vec.dot(p_vec) / line_mod_square
    shadow_vec = line_vec.dot(shadow_vec_len)
    distance_vec = p_vec - shadow_vec
    distance = np.sqrt(distance_vec.dot(distance_vec))
    return distance


def shadow_point(line, p, on_segment=False):
    """
    点在直线上的投影
    :param line:
    :param p:
    :param on_segment: bool, 是否限制在line线段内
    :return:
    """
    diff_x = line[0][ce.X] - line[1][ce.X]
    diff_y = line[0][ce.Y] - line[1][ce.Y]
    if diff_x == 0:
        vertical_p = {ce.X: p[ce.X] + 1, ce.Y: p[ce.Y]}
    else:
        vpx = -1 * diff_y / diff_x + p[ce.X]
        vertical_p = {ce.X: vpx, ce.Y: p[ce.Y] + 1}
    cro_p = cross_point(line, [p, vertical_p])
    if on_segment:
        p_pos = abs(ps_distance(cro_p, line[0]) + ps_distance(cro_p, line[1]) - ps_distance(*line))
        if p_pos > 0.1:
            return None
    return cro_p


def expand_line(line, add_len):
    """
    线段扩展
    :param line: list<[{'x': x_value, 'y': y_value},]> 直线的两点
    :param add_len: 单侧扩展的长度
    :return: list<[{'x': x_value, 'y': y_value},]> 直线的两点
    """
    m = math.sqrt(pow((line[0][ce.X] - line[-1][ce.X]), 2) + pow((line[0][ce.Y] - line[-1][ce.Y]), 2))
    if m == 0:
        return None
    k = (m + add_len + 0.) / m
    diff_x = line[-1][ce.X] - line[0][ce.X]
    diff_y = line[-1][ce.Y] - line[0][ce.Y]
    a_x = k * diff_x + line[0][ce.X]
    a_y = k * diff_y + line[0][ce.Y]

    b_x = line[-1][ce.X] - k * diff_x
    b_y = line[-1][ce.Y] - k * diff_y

    return [{ce.X: a_x, ce.Y: a_y}, {ce.X: b_x, ce.Y: b_y}]


def short_line(line, length):
    """
    截取直线尾部，获得指定长度的直线
    :param line: list<[{'x': x_value, 'y': y_value},]> 直线的两点
    :param length: int/float 生成直线的长度
    :return:
    """
    s_line = [{ce.X: line[0][ce.X], ce.Y: line[0][ce.Y]}]
    m = math.sqrt(pow((line[0][ce.X] - line[-1][ce.X]), 2) + pow((line[0][ce.Y] - line[-1][ce.Y]), 2))
    if m == 0:
        return None
    k = length / (m + 0.)
    diff_x = line[-1][ce.X] - line[0][ce.X]
    diff_y = line[-1][ce.Y] - line[0][ce.Y]
    if k == 0 or (diff_x == 0 and diff_y == 0):
        print(k, diff_x, diff_y)
    s_line.append({ce.X: line[0][ce.X] + k * diff_x, ce.Y: line[0][ce.Y] + k * diff_y})
    return s_line


def get_normal_line(line):
    """
    获得线段的法线
    :param line: list<[{'x': x_value, 'y': y_value},{.}]> 直线的两点
    :return: list: [[p1, p2], [p3, p4], [p5, p6]]
            起始点分别是参数线段line 的中点、左、右点的法线，p 指{'x': x, 'y': y} 形式的坐标
    """
    if not isinstance(line, list) or len(line) != 2:
        return None
    h = [line[0][ce.X], line[0][ce.Y]]
    t = [line[1][ce.X], line[1][ce.Y]]
    mid = [(h[0] + t[0]) / 2, (h[1] + t[1]) / 2]
    norm_mid = [mid[0] + t[1] - mid[1], mid[1] - t[0] + mid[0]]
    norm_h = [h[0] - mid[1] + h[1], h[1] + mid[0] - h[0]]
    norm_t = [t[0] - mid[1] + t[1], t[1] + mid[0] - t[0]]
    mid_norm_line = [{ce.X: mid[0], ce.Y: mid[1]}, {ce.X: norm_mid[0], ce.Y: norm_mid[1]}]
    mid_norm_line = short_line(mid_norm_line, 1000)
    if mid_norm_line is None:
        return None
    h_norm_line = [line[0], {ce.X: norm_h[0], ce.Y: norm_h[1]}]
    t_norm_line = [line[1], {ce.X: norm_t[0], ce.Y: norm_t[1]}]
    return [mid_norm_line, h_norm_line, t_norm_line]


def line_angle(line_a, line_b):
    """
    两条线的夹角余弦值
    :param line_a: list<[{'x': x_value, 'y': y_value},{.}]> 直线的两点
    :param line_b: list<[{'x': x_value, 'y': y_value},{.}]> 直线的两点
    :return: cosin_value, float, 夹角余弦值
    """
    a_h = line_a[0]
    a_t = line_a[1]
    b_h = line_b[0]
    b_t = line_b[1]
    v1 = np.array([a_t[ce.X] - a_h[ce.X], a_t[ce.Y] - a_h[ce.Y]])
    v2 = np.array([b_t[ce.X] - b_h[ce.X], b_t[ce.Y] - b_h[ce.Y]])
    cosin_value = v1.dot(v2) / (np.linalg.norm(v1) * np.linalg.norm(v2))
    return cosin_value


def same_line(start_p, mid_p, end_p):
    """
    三点是否共线， 区分点顺序
    :param start_p: dict<{'x': x_value, 'y': y_value}> 点坐标
    :param mid_p: dict<{'x': x_value, 'y': y_value}> 点坐标
    :param end_p: dict<{'x': x_value, 'y': y_value}> 点坐标
    :return: cosin_value, float, 余弦值([0, 1])
            True/False, bool, 是/否在一条直线上
    """
    cosin_value = line_angle([mid_p, start_p], [mid_p, end_p])
    # 夹角在5度以内认为是在一条直线上
    if abs(cosin_value) >= 0.9962:
        return cosin_value, True
    else:
        return cosin_value, False


def ps_distance(p1, p2):
    """
    两点距离
    :param p1: dict<{'x': x_value, 'y': y_value}> 点坐标
    :param p2: dict<{'x': x_value, 'y': y_value}> 点坐标
    :return: dist, float, 两点直线距离
    """
    vec1 = np.array([p1[ce.X], p1[ce.Y]], dtype=float)
    vec2 = np.array([p2[ce.X], p2[ce.Y]], dtype=float)
    dist = np.linalg.norm(vec1 - vec2)
    return dist


def cross_point(line1, line2):
    """
    两直线交点
    :param line1: list<[{'x': x_value, 'y': y_value},{.}]> 直线的两点
    :param line2: list<[{'x': x_value, 'y': y_value},{.}]> 直线的两点
    :return: dict<{'x': x_value, 'y': y_value}> 点坐标
            两直线平行时返回 None
    """
    x1 = line1[0][ce.X]
    y1 = line1[0][ce.Y]
    x2 = line1[1][ce.X]
    y2 = line1[1][ce.Y]

    x3 = line2[0][ce.X]
    y3 = line2[0][ce.Y]
    x4 = line2[1][ce.X]
    y4 = line2[1][ce.Y]

    # 保证 x1, x2 不相等，有斜率
    if x1 == x2:
        # 都为竖直方向，则平行
        if x3 == x4:
            return None
        # 保证 x1 != x2
        else:
            x1, y1, x2, y2, x3, y3, x4, y4 = x3, y3, x4, y4, x1, y1, x2, y2

    k1 = (y2 - y1) * 1.0 / (x2 - x1)
    b1 = y1 * 1.0 - x1 * k1
    if x3 == x4:
        k2 = None
        b2 = 0.
    else:
        k2 = (y4 - y3) * 1.0 / (x4 - x3)
        b2 = y3 * 1.0 - x3 * k2

    # 平行
    if k1 == k2:
        return None

    # 一条为竖直线
    if k2 is None:
        x = x3 + 0.
    else:
        x = (b2 - b1) / (k1 - k2)
    y = k1 * x + b1
    return {ce.X: x, ce.Y: y}


def mid_p(head_p, tail_p):
    """
    计算中点
    :param head_p:
    :param tail_p:
    :return:
    """
    m_p = {ce.X: (head_p[ce.X] + tail_p[ce.X]) / 2.,
           ce.Y: (head_p[ce.Y] + tail_p[ce.Y]) / 2.}
    return m_p


def trans2mid(line, to_line):
    """
    line平移至to_line 中点位置，要求line的一个端点必须在to_line上或to_line所在直线上
    :param line: list<[{'x': x_value, 'y': y_value},{.}]> 直线的两点
    :param to_line: list<[{'x': x_value, 'y': y_value},{.}]> 直线的两点
    :return:
    """
    to_p = mid_p(*to_line)
    head_dist = ps_distance(line[0], to_p)
    tail_dist = ps_distance(line[1], to_p)
    ref_p = line[0] if head_dist < tail_dist else line[1]
    diff_x = to_p[ce.X] - ref_p[ce.X]
    diff_y = to_p[ce.Y] - ref_p[ce.Y]
    head_p = {ce.X: line[0][ce.X] + diff_x, ce.Y: line[0][ce.Y] + diff_y}
    tail_p = {ce.X: line[1][ce.X] + diff_x, ce.Y: line[1][ce.Y] + diff_y}
    return [head_p, tail_p]


if __name__ == '__main__':
    p_a = {ce.X: 28687, ce.Y: 14896}
    p_b = {ce.X: 0, ce.Y: 0}
    p_c = {ce.X: 28687, ce.Y: 18759}
    p_d = {ce.X: 0, ce.Y: 5}
    p_e = {ce.X: -0.5, ce.Y: 0.5}
    p_f = {ce.X: 5, ce.Y: 4}

    # print(cross_point([p_a, p_b], [p_b, p_d]))
    # print(to_left_test([p_a, p_b], [p_c, p_d, p_e]))
    # print(get_normal_line([p_a, p_c]))
    # print(line_angle([p_a, p_b], [p_a, p_f]))
    # print(expand_line([p_d, p_e], 2))
    # print(trans2mid([p_b, p_d], [p_e, p_f]))
    print(shadow_point([p_b, p_d], p_e))
