#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2018 www.ke.com, Inc. All Rights Reserved
from math import sqrt
from shapely import affinity

GM = (sqrt(5) - 1.0) / 2.0
W = 8.0
H = W * GM
SIZE = (W, H)

BLUE = '#6699cc'
GRAY = '#999999'
DARKGRAY = '#333333'
YELLOW = '#ffcc33'
GREEN = '#339933'
RED = '#ff3333'
BLACK = '#000000'

COLOR_MAP = [
    "#8C0044", "#880000", "#A42D00", "#BB5500", "#886600", "#888800", "#668800", "#227700", "#008800", "#008844",
    "#008866", "#008888", "#007799", "#003377", "#000088", "#220088", "#3A0088", "#550088", "#660077", "#770077",
    "#A20055", "#AA0000", "#C63300", "#CC6600", "#AA7700", "#BBBB00", "#88AA00", "#55AA00", "#00AA00", "#00AA55",
    "#00AA88", "#00AAAA", "#0088A8", "#003C9D", "#0000AA", "#2200AA", "#4400B3", "#66009D", "#7A0099", "#990099",
    "#C10066", "#CC0000", "#E63F00", "#EE7700", "#DDAA00", "#EEEE00", "#99DD00", "#66DD00", "#00DD00", "#00DD77",
    "#00DDAA", "#00DDDD", "#009FCC", "#0044BB", "#0000CC", "#4400CC", "#5500DD", "#7700BB", "#A500CC", "#CC00CC",
    "#FF0088", "#FF0000", "#FF5511", "#FF8800", "#FFBB00", "#FFFF00", "#BBFF00", "#77FF00", "#00FF00", "#00FF99",
    "#00FFCC", "#00FFFF", "#00BBFF", "#0066FF", "#0000FF", "#5500FF", "#7700FF", "#9900FF", "#CC00FF", "#FF00FF",
    "#FF44AA", "#FF3333", "#FF7744", "#FFAA33", "#FFCC22", "#FFFF33", "#CCFF33", "#99FF33", "#33FF33", "#33FFAA",
    "#33FFDD", "#33FFFF", "#33CCFF", "#5599FF", "#5555FF", "#7744FF", "#9955FF", "#B94FFF", "#E93EFF", "#FF3EFF",
    "#FF88C2", "#FF8888", "#FFA488", "#FFBB66", "#FFDD55", "#FFFF77", "#DDFF77", "#BBFF66", "#66FF66", "#77FFCC",
    "#77FFEE", "#66FFFF", "#77DDFF", "#99BBFF", "#9999FF", "#9F88FF", "#B088FF", "#D28EFF", "#E38EFF", "#FF77FF",
    "#FFB7DD", "#FFCCCC", "#FFC8B4", "#FFDDAA", "#FFEE99", "#FFFFBB", "#EEFFBB", "#CCFF99", "#99FF99", "#BBFFEE",
    "#AAFFEE", "#99FFFF", "#CCEEFF", "#CCDDFF", "#CCCCFF", "#CCBBFF", "#D1BBFF", "#E8CCFF", "#F0BBFF", "#FFB3FF",
    "#8C0044", "#880000", "#A42D00", "#BB5500", "#886600", "#888800", "#668800", "#227700", "#008800", "#008844",
    "#008866", "#008888", "#007799", "#003377"
]

HATCH_MAP = [
    '/', '\\\\', '|', '-', '+', 'x', 'o', 'O', '.', '*'
]

LINE_STYLE = ['solid', 'dashed', 'dashdot', 'dotted']


COLOR_ISVALID = {
    True: BLUE,
    False: RED,
}


def plot_line(ax, ob, color=GRAY, zorder=1, linewidth=3, solid_capstyle='round', alpha=1):
    x, y = ob.xy
    ax.plot(x, y, color=color, linewidth=linewidth, solid_capstyle=solid_capstyle, zorder=zorder, alpha=alpha)


def plot_coords(ax, ob, color=GRAY, zorder=1, alpha=1):
    x, y = ob.xy
    ax.plot(x, y, 'o', color=color, zorder=zorder, alpha=alpha)


def color_isvalid(ob, valid=BLUE, invalid=RED):
    if ob.is_valid:
        return valid
    else:
        return invalid


def color_issimple(ob, simple=BLUE, complex=YELLOW):
    if ob.is_simple:
        return simple
    else:
        return complex


def plot_line_isvalid(ax, ob, **kwargs):
    kwargs["color"] = color_isvalid(ob)
    plot_line(ax, ob, **kwargs)


def plot_line_issimple(ax, ob, **kwargs):
    kwargs["color"] = color_issimple(ob)
    plot_line(ax, ob, **kwargs)


def plot_bounds(ax, ob, zorder=1, alpha=1):
    x, y = zip(*list((p.x, p.y) for p in ob.boundary))
    ax.plot(x, y, 'o', color=BLACK, zorder=zorder, alpha=alpha)


def add_origin(ax, geom, origin, desc=''):
    x, y = xy = affinity.interpret_origin(geom, origin, 2)
    ax.plot(x, y, 'o', color=GRAY, zorder=1)
    if not desc:
        desc = (int(x), int(y))
    ax.annotate(desc, xy=xy, ha='center',
                textcoords='offset points', xytext=(0, 8))


def set_limits(ax, x0, xN, y0, yN, interval=0.1):
    interval_tick_x = int(max(1, int(xN*interval)))
    interval_tick_y = int(max(1, int(yN*interval)))
    ax.set_xlim(x0, xN)
    ax.set_xticks(range(x0, xN + 1, interval_tick_x))
    ax.set_ylim(y0, yN)
    ax.set_yticks(range(y0, yN + 1, interval_tick_y))
    ax.set_aspect("equal")
