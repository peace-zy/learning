#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2018 www.ke.com, Inc. All Rights Reserved
"""
请求第三方api方法
Authors: yudonghai@ke.com
Date:    2019/04/15
"""
from __future__ import division
import json
import urllib
import hashlib
import datetime
import traceback

import boto3
from botocore.exceptions import ClientError


def send_mail(receiver_addr_lst, subject, message):
    """
    发送邮件
    :param receiver_addr_lst: list, 收件人列表
    :param subject: string, 邮件主题
    :param message: string, 邮件内容
    :return:
    """
    body = {
        "version": '1.0',
        "method": "mail.sent",
        "group": "bigdata",
        "auth": "yuoizSsKggkjOc8vbMwS0OqYHvwTGGbB",
        "params": {
            "to": receiver_addr_lst,
            "subject": subject,
            "body": message
        }
    }
    data = json.dumps(body)
    url = 'http://sms.lianjia.com/lianjia/sms/send'
    try:
        request = urllib.Request(url, data)
        urllib.urlopen(request)
    except Exception as e:
        traceback.print_exc()
        raise e


def get_sign(param_dict, key, secret, ts):
    """
    input:
        param_dict - 业务参数字典。如{"foo": 1, "bar": {"startDate":"20170427"}}
        key        - KEY。元数据平台申请项目时生成
        secret     - SECRET。元数据平台申请项目时生成
        ts         - 时间戳
    return:
        sign       - 生成的秘钥
    """
    # Step 0: 把字典转成tuple list, 方便后续处理
    param_list = param_dict.items()
    # Step 1-1: 加入公共参数key和ts
    param_list.append(("key", key))
    param_list.append(("ts", ts))
    # Step 1-2: 根据ascii码对对参数名称排序
    param_sort = sorted(param_list, cmp=lambda x, y: cmp(x[0], y[0]))
    # Step 2: 对key和value做urlencode
    param_link = [(str(key), str(value)) for (key, value) in param_sort]
    # Step 3: 用=链接key和value，用&链接各组参数
    param_merge = "&".join(["%s=%s" % (key, value) for (key, value) in param_link])
    # Step *: python的urlencode不保证按ascii升序,而quote又会把空格转成"%20"而不是"+"
    #  因此这里需要做个转化
    param_compliant = param_merge.replace("%20", "+")
    # Step 4: 将上边的字符串转为全小写字母
    param_lower = param_compliant.lower()
    # Step 5: sign = md5(md5(上边得到的字符串)secret))
    sign = get_md5(get_md5(param_lower) + secret)
    return sign


def get_headers(param_dict, key, secret, ts):
    """
    input:
        param_dict - 业务参数字典。如{"foo": 1, "bar": {"startDate":"20170427"}}
        key        - KEY。元数据平台申请项目时生成
        secret     - SECRET。元数据平台申请项目时生成
        ts         - 时间戳
    return:
        header     - header参数的字典
    """
    return {"key": key,
            "ts": ts,
            "sign": get_sign(param_dict, key, secret, ts)}


def get_md5(m_str):
    m1 = hashlib.md5(str(m_str))
    return m1.hexdigest()


def request_bigdata_api(url, params_dict, key, secret):
    """
    组织请求字符串, 访问大数据平台的在售和成交房源api, 并获取api请求结果
    :param url: string, 访问路径
    :param params_dict: dict, 参数字典
    :param key: string, 元数据平台申请项目时生成
    :param secret: string, 元数据平台申请项目时生成
    :return: result, api返回结果
    """
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    h = get_headers(params_dict, key, secret, timestamp)

    q_str = url + "?"
    params_list = []
    for param_key in params_dict:
        params_list.append(param_key + "=" + params_dict[param_key])
    q_str += "&".join(params_list)
    req = urllib.Request(q_str)

    for k, v in h.iteritems():
        req.add_header(k, v)

    result = None
    try:
        result = urllib.urlopen(req, timeout=5).read()
        result = eval(result)
    except Exception as e:
        print(e)
        pass
    return result


def request_bigdata_api_post(url, params_dict, key, secret):
    """
    post方法调用API
    """
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    h = get_headers(params_dict, key, secret, timestamp)

    data = urllib.urlencode(params_dict)
    request = urllib.Request(url, data=data, headers=h)
    result = None
    try:
        response = urllib.urlopen(request, timeout=5).read()
        result = eval(response)
    except Exception as e:
        print(e)
    return result


def create_presigned_url(s3_client, bucket_name, object_name, expiration=3600):
    """Generate a presigned URL to share an S3 object
    :param s3_client: s3 client
    :param bucket_name: string
    :param object_name: string
    :param expiration: Time in seconds for the presigned URL to remain valid
    :return: Presigned URL as string. If error, returns None.
    """

    # Generate a presigned URL for the S3 object

    try:
        response = s3_client.generate_presigned_url('get_object',
                                                    Params={'Bucket': bucket_name,
                                                            'Key': object_name},
                                                    ExpiresIn=expiration)
    except ClientError as e:
        return None

    # The response contains the presigned URL
    return response


if __name__ == "__main__":
    print("api_lib")
