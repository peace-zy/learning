# -*- coding: utf-8 -*-
from api_signature_python3 import SignatureUtil
import json, requests

AK = "fBKcP5W5matxpnmNi666"
SK = "6ciZjBmKRhKDBHDyyr7D2nG4CyszFeQeexXeyYkJ"

GEN_HEADER = {"Content-Type":"application/json"}

URL = "http://lingjing-open.ke.com"

# 获取模板: http://weapons.ke.com/project/9341/interface/api/743675
TEMPLATE_URL = '/api/open/template/list'

# 生成视频接口: https://weapons.ke.com/project/9341/interface/api/1588272
GEN_VIDEO_URL = '/api/open/video/gen'

def gen_video(script_dict, callback_url):
    req_url = URL + GEN_VIDEO_URL
    headers = {"Content-Type":"application/json"}
    headers = SignatureUtil.SignatureUtil(AK, SK).customSignature(req_url, "get", headers)
    print(headers)
    r = requests.get(req_url, headers=headers)
    # print(r.text)
    return r.text
