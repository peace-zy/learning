#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2018 www.ke.com, Inc. All Rights Reserved
"""
通用工具
Authors: yudonghai@ke.com
Date:    2018/12/21
"""
from __future__ import division
import sys
import math
import logging
import numpy as np
import collections

from lib import code_enum as ce
from lib import entity

# 统一边界值在边界值列表中的下标
MAX_X_INDEX = 0
MAX_Y_INDEX = 1
MIN_X_INDEX = 2
MIN_Y_INDEX = 3


def get_circumscribed_rectangle(points):
    """
    获取点集合的四至（外接矩形）的横纵坐标的最大最小值，中心点
    :param points: dict({id:{x:a, y:b}}) / list([[a, b]]), 点集合
    :return: border_lst, list, 四至及中心点坐标
    """
    # 四至列表，max_x, max_y, min_x, min_y
    border_lst = [-sys.float_info.max, -sys.float_info.max, sys.float_info.max, sys.float_info.max]
    bad_result = [-sys.float_info.max, -sys.float_info.max, sys.float_info.max, sys.float_info.max]
    if isinstance(points, dict):
        for point_id in points:
            point = points[point_id]
            p_x = point["x"]
            p_y = point["y"]
            if p_x is None or p_y is None:
                return bad_result
            update_max(border_lst, p_x, p_y)

    elif isinstance(points, list):
        for point in points:
            p_x, p_y = point["x"], point["y"]
            if p_x is None or p_y is None:
                return bad_result
            update_max(border_lst, p_x, p_y)

    if any([border_lst[MAX_X_INDEX] == -sys.float_info.max, border_lst[MIN_X_INDEX] == sys.float_info.max,
            border_lst[MAX_Y_INDEX] == -sys.float_info.max, border_lst[MIN_Y_INDEX] == sys.float_info.max]):
        return bad_result

    mid_x = (border_lst[MAX_X_INDEX] + border_lst[MIN_X_INDEX]) / 2
    mid_y = (border_lst[MAX_Y_INDEX] + border_lst[MIN_Y_INDEX]) / 2
    border_lst.extend([mid_x, mid_y])

    return border_lst


def update_max(border_lst, p_x, p_y):
    """
    更新x、y 最大、最小值
    :param border_lst: 外接矩形最大、最小的 x, y 坐标  
    :param p_x: 新的x
    :param p_y: 新的y
    :return: 
    """
    border_lst[MAX_X_INDEX] = max(p_x, border_lst[MAX_X_INDEX])
    border_lst[MAX_Y_INDEX] = max(p_y, border_lst[MAX_Y_INDEX])
    border_lst[MIN_X_INDEX] = min(p_x, border_lst[MIN_X_INDEX])
    border_lst[MIN_Y_INDEX] = min(p_y, border_lst[MIN_Y_INDEX])


def point_in_rectangle(p, rectangle):
    """
    点是否位于矩形内
    :param p: 点(含有x, y 属性)
    :param rectangle: list<float>, <maxx, maxy, minx, miny>格式矩形表示
    :return: result
    """
    result = False

    min_x, min_y = rectangle[MIN_X_INDEX], rectangle[MIN_Y_INDEX]
    max_x, max_y = rectangle[MAX_X_INDEX], rectangle[MAX_Y_INDEX]
    if min_x <= p["x"] <= max_x and min_y <= p["y"] <= max_y:
        result = True

    return result


def point_in_polygon(p, border_points):
    """
    点是否位于多边形内(射线法判定)
    射线为 p 点水平向右的射线
    :param p:
    :param border_points:
    :return:
    """
    result = False
    p_x = p["x"]
    p_y = p["y"]
    cross_point_cnt = 0
    border_size = len(border_points)

    for i in range(border_size):
        start = border_points[i - 1]
        end = border_points[i]

        s_x = start["x"]
        s_y = start["y"]
        e_x = end["x"]
        e_y = end["y"]
        min_x = min(s_x, e_x)
        max_x = max(s_x, e_x)
        min_y = min(s_y, e_y)
        max_y = max(s_y, e_y)
        # 边与射线重合，当此边连接的另外两条边分上下两条时，认为穿过多边形一次
        #
        if s_y == e_y and p_x < min_x and p_y == s_y:
            ss_y = border_points[i - 2]["y"]
            ee_y = border_points[-1 if (i + 1) == border_size else i + 1]["y"]
            if (ss_y - s_y) * (ee_y - e_y) < 0:
                pass
                # cross_point_cnt += 1
        # 边为非水平边且点一定不在线段右边时，看射线是否与线段相交
        elif s_y != e_y and p_x < max_x:
            # c_x 为 射线所在**直线**与线段所在**直线**的交点
            c_x = s_x + (e_x - s_x) * (p_y - s_y) / (e_y - s_y)
            # 交点 在 p 右侧且 y 在线段 y 的范围内，则记为射线穿过多边形一次
            if c_x > p_x and max_y > p_y >= min_y:
                cross_point_cnt += 1
    if cross_point_cnt % 2 == 1:
        result = True

    return result


def rotate(plans):
    """
    矢量户型图增加旋转后的坐标
    :param plans: list, 层列表
    :return: rotate_angle, int, 旋转角度
    """
    entrance = None
    entrance_line_id = None
    entrance_towards = None
    rotate_angle = 0

    for plan in plans:
        # 入户门查找
        line_items = plan["lineItems"]

        for lineItem in line_items:
            if lineItem["entrance"] is not None:
                entrance = lineItem["entrance"]
                entrance_line_id = lineItem["line"]

    if entrance is None or entrance_line_id is None:
        logging.error("lack entrance info")
        return rotate_angle, 0

    for plan in plans:
        for area in plan["areas"]:

            # 入户门与x轴夹角，x轴正向逆时针
            attachments_lines = area["attachments"]["lines"]
            for line_item in attachments_lines:
                if line_item.get("id", None) is None:
                    logging.error("lack entrance towards info")
                    return 0, 0
                if line_item["id"] == entrance_line_id:
                    # 弧度转角度
                    if line_item.get("towardsRad", None) is None:
                        logging.error("bad entrance towards info")
                        return 0, 0
                    entrance_towards = line_item["towardsRad"] * 180 / math.pi
                    break
    if entrance_towards is None:
        logging.error("lack entrance towards info")
        return rotate_angle, 0

    rotate_angle = entrance + entrance_towards - 90
    rotate_angle %= 360
    real_angle = rotate_angle

    angle_add = 90 if rotate_angle % 90 > 45 else 0
    disperse_angle = int(rotate_angle / 90)

    rotate_angle = 90 * disperse_angle + angle_add
    logging.debug("rotate angle: {}".format(rotate_angle))

    # 无需旋转
    if rotate_angle in (0, 360):
        logging.info("rotate not necessary")
        return rotate_angle, real_angle

    radians_value = math.radians(rotate_angle)
    sin_value = round(math.sin(radians_value))
    cos_value = round(math.cos(radians_value))
    x_add_maxy = 0 if sin_value > cos_value else 1
    y_add_maxx = 0 if sin_value <= 0 else 1

    # 每层都旋转
    for plan in plans:
        border_lst = get_circumscribed_rectangle(plan["points"])
        max_x = border_lst[MAX_X_INDEX]
        max_y = border_lst[MAX_Y_INDEX]
        if max_x == max_y == -sys.float_info.max:
            logging.error("can not get max_x in rotate")
            return rotate_angle, real_angle

        # x,y 方向的平移量，为了使得旋转后的图像平移到第一象限
        x_add = x_add_maxy * max_y * 2 - cos_value * max_x * 2
        y_add = y_add_maxx * max_x * 2 - cos_value * max_y * 2
        rotate_points = []
        for point in plan["points"]:
            tmpx = point["x"]
            tmpy = point["y"]
            new_x = tmpx * cos_value + tmpy * sin_value + x_add
            new_y = tmpy * cos_value - tmpx * sin_value + y_add
            rotate_points.append({"id": point["id"], "x": new_x, "y": new_y})
        plan["rotate_points"] = rotate_points
    return rotate_angle, real_angle


def get_area_center(area_id, area_dict, points_dict):
    """
    获取分间中心点
    :param area_id: string, 分间ID
    :param area_dict: dict, 分间字典
    :param points_dict: dict, 点坐标字典
    :return: numpy.array<float>, 中心点横纵坐标 [x, y]
    """
    area = area_dict[area_id]
    points = area[ce.AREA_POINTS_KEY]
    xs = []
    ys = []
    for p in points:
        xs.append(points_dict[p][ce.X])
        ys.append(points_dict[p][ce.Y])

    m_x = (min(xs) + max(xs)) / 2
    m_y = (min(ys) + max(ys)) / 2
    return np.array([m_x, m_y])


def expand_line(line, add_len):
    """
    线段扩展
    :param line: numpy.array, [[x1, y1], [x2, y2]] 形式的线段
    :param add_len: 单侧扩展的长度
    :return: numpy.array, 扩展后 [[x1, y1], [x2, y2]] 形式的线段
    """
    m = np.linalg.norm(line[0] - line[-1])
    k = (m + add_len) / m
    diff_x = line[-1][0] - line[0][0]
    diff_y = line[-1][1] - line[0][1]
    a_x = k * diff_x + line[0][0]
    a_y = k * diff_y + line[0][1]

    b_x = line[-1][0] - k * diff_x
    b_y = line[-1][1] - k * diff_y

    return np.array([[a_x, a_y], [b_x, b_y]])


def get_normal_line(line):
    """
    获得线段的法线
    :param line: list/np.array, [[x1, y1], [x2, y2]] 形式的线段
    :return: numpy.array, [[p1, p2], [p3, p4], [p5, p6]]
            起始点分别是line 中点、左、右点的法线，p 指[x, y] 形式的坐标
    """
    h = line[0]
    t = line[-1]
    mid = [(h[0] + t[0]) / 2, (h[1] + t[1]) / 2]
    norm_mid = [mid[0] - t[1] + mid[1], mid[1] + t[0] - mid[0]]
    norm_h = [h[0] - mid[1] + h[1], h[1] + mid[0] - h[0]]
    norm_t = [t[0] - mid[1] + t[1], t[1] + mid[0] - t[0]]
    return np.array([[mid, norm_mid], [h, norm_h], [t, norm_t]])


def to_left_test(seg_line, points):
    """
    TO-LEFT 测试，用于判断点在直线哪一侧
    :param seg_line: numpy.array, 直线的两点
    :param points: numpy.array, 点坐标列表
    :return: flags, list, TO-LEFT 计算结果
    """
    flags = []
    for p in points:
        det = np.insert(seg_line, 2, values=p, axis=0)
        det = np.insert(det, 2, [1] * 3, axis=1)
        # 行列式计算
        result = np.linalg.det(det)
        flags.append(result)

    return flags


def get_endpoint(line_item_id, line_dict, line_item_dict, p_dict):
    """
    获取墙体附件的两个端点
    :param line_item_id: string, 墙体附件ID
    :param line_dict: dict, 墙体字典
    :param line_item_dict: dict, 墙体附件字典
    :param p_dict: dict, 点坐标字典
    :return: list<[[x1, y1], [x2, y2]]>, 墙体附件真实两端坐标点
    """
    line_info = line_dict[line_item_dict[line_item_id][ce.LINE_ITEM_LINE_KEY]]
    line_item_info = line_item_dict[line_item_id]

    line_points = line_info[ce.LINE_POINTS_KEY]

    start_index = line_item_info[ce.LINE_ITEM_START_INDEX_KEY]
    end_index = -1 if start_index == 0 else 0
    start_p = p_dict[line_points[start_index]]
    end_p = p_dict[line_points[end_index]]

    diff_x = end_p[ce.X] - start_p[ce.X]
    diff_y = end_p[ce.Y] - start_p[ce.Y]
    line_len = math.sqrt(diff_x * diff_x + diff_y * diff_y)
    line_item_start_offset = line_item_info[ce.LINE_ITEM_START_KEY]
    line_item_length = line_item_info[ce.LINE_ITEM_LENGTH_KEY]

    # 竖线
    if start_p[ce.X] == end_p[ce.X]:
        head_x = tail_x = start_p[ce.X]

        add_direction = 1 if start_p[ce.Y] < end_p[ce.Y] else -1

        head_y = start_p[ce.Y] + add_direction * line_item_start_offset
        tail_y = start_p[ce.Y] + add_direction * (line_item_start_offset + line_item_length)

    # 横线
    elif start_p[ce.Y] == end_p[ce.Y]:
        head_y = tail_y = start_p[ce.Y]

        add_direction = 1 if start_p[ce.X] < end_p[ce.X] else -1

        head_x = start_p[ce.X] + add_direction * line_item_start_offset
        tail_x = start_p[ce.X] + add_direction * (line_item_start_offset + line_item_length)

    # 斜线
    else:
        head_x = (line_item_start_offset * diff_x) / line_len + start_p[ce.X]
        head_y = (line_item_start_offset * diff_y) / line_len + start_p[ce.Y]
        tail_x = ((line_item_start_offset + line_item_length) * diff_x) / line_len + start_p[ce.X]
        tail_y = ((line_item_start_offset + line_item_length) * diff_y) / line_len + start_p[ce.Y]

    return [[head_x, head_y], [tail_x, tail_y]]


def format_frame_score_params():
    """
    将户型打分参数的键值由string 转成对应的 标签值
    :return: params_dict, dict, 户型打分参数
    """
    params_dict = {}
    label_factory = entity.Label()
    # 标签-权重
    label_scores = collections.defaultdict(dict)
    for score_type in ce.LABEL_SCORES:
        for label_str in ce.LABEL_SCORES[score_type]:
            label_scores[score_type][label_factory[label_str]] = ce.LABEL_SCORES[score_type][label_str]
    # 标签-文案
    label_docs = {}
    for label_str in ce.LABEL_DOCS:
        label_docs[label_factory[label_str]] = ce.LABEL_DOCS[label_str]

    params_dict["label_scores"] = label_scores
    params_dict["label_docs"] = label_docs
    return params_dict


def format_short_frame_score_params():
    """
    将户型打分参数的键值由string 转成对应的 标签值
    :return: params_dict, dict, 户型打分参数
    """
    params_dict = {}
    label_factory = entity.Label()
    # 标签-权重
    label_scores = collections.defaultdict(dict)
    for score_type in ce.LABEL_SCORES:
        for label_str in ce.LABEL_SCORES[score_type]:
            label_scores[score_type][label_factory[label_str]] = ce.LABEL_SCORES[score_type][label_str]
    # 标签-文案
    label_docs = {}
    for label_str in ce.SHORT_LABEL_DOCS:
        label_docs[label_factory[label_str]] = ce.SHORT_LABEL_DOCS[label_str]

    params_dict["label_scores"] = label_scores
    params_dict["label_docs"] = label_docs
    return params_dict


def combination(source_lst, m, current, res, all_res):
    """
    组合生成器
    :param source_lst: 原始列表
    :param m: 组合size
    :param current: 当前组合内元素数量
    :param res: 当前组合结果
    :param all_res: 所有组合情况列表
    :return:
    """
    if m == 0:
        return all_res.append(res)
    if (len(source_lst) - current) < m:
        return None

    combination(source_lst, m, current + 1, res, all_res)
    combination(source_lst, m - 1, current + 1, res + [source_lst[current]], all_res)


if __name__ == '__main__':
    # print(array.array('b', [[1, 2]]))
    # tmp = get_circumscribed_rectangle(array.array([[1, 1], [2, 2], [4, 0]]))
    # print(tmp)
    border = []
    for x, y in [[0, 0], [2, 0], [2, 1], [1, 0.5], [1, 2], [0, 2]]:
        border.append({"x": x, "y": y})
    for x, y in [[0.5, 1], [1, 0.5], [1, 1], [-1, 2], [-1, 1], [1, -1], [3, 1]]:
        print(x, y)
        tmp = point_in_polygon({"x": x, "y": y}, border)
        print(tmp)
    m = []
    combination([0, 1, 2, 3, 4], 1, 0, [], m)
    print(m)
