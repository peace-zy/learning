#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2018 www.ke.com, Inc. All Rights Reserved
from __future__ import division

import json
import random
import math

import numpy as np
from shapely.geometry import LineString, Polygon, Point
import boto3

from lib.figures import set_limits, add_origin, COLOR_MAP, HATCH_MAP, LINE_STYLE


def s4():
    return hex(int(random.random()*1e10))[3:]


def create_uuid():
    """
    生成户型ID随机编码
    sample: u-f85c1958-32f6-4412-d588-7ab7aa785991
    :return:
    """
    return "u-{}{}-{}-4{}-{}-{}{}{}".format(s4(), s4(), s4(), s4()[0:3], s4(), s4(), s4(), s4())


def load_local_frame_json(frame_id):
    """
    加载本地的frame_id
    :param frame_id:
    :return:
    """
    json_file_path = 'data/mod_diff_res/json/{}.json'.format(frame_id)
    # with open(json_file_path, encoding='utf-8') as f:
    with open(json_file_path) as f:
        frame_json = json.load(f)
    return frame_json


def angle_between_vec(vector_1, vector_2):
    """
    计算两个向量间夹角
    :param vector_1:
    :param vector_2:
    :return: 夹角弧度
    """
    unit_vector_1 = vector_1 / np.linalg.norm(vector_1)
    unit_vector_2 = vector_2 / np.linalg.norm(vector_2)
    dot_product = np.dot(unit_vector_1, unit_vector_2)
    angle = np.arccos(dot_product)
    return angle


def get_relative_angle(end_f_p, f_p, precision=3):
    """
    获取两个点相对于定位点和x轴正向夹角(相反的)
    :param end_f_p: 结束点
    :param f_p: 起始点
    :param precision: 精度
    :return:
    """
    x_diff = end_f_p[0] - f_p[0]
    y_diff = end_f_p[1] - f_p[1]
    oblique_diff = math.sqrt(x_diff * x_diff + y_diff * y_diff)
    if oblique_diff == 0:
        diff_angle = 0
    else:
        if y_diff < 0:
            diff_angle = 360 - math.acos(x_diff / oblique_diff) * 180 / math.pi
        else:
            diff_angle = math.acos(x_diff / oblique_diff) * 180 / math.pi
    return round(diff_angle, precision)


def p2p_euclidean(p1, p2):
    """
    Euclidean distance between two points
    :param p1:
    :param p2:
    :return:
    """
    return ((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2) ** 0.5


def draw_shapes(polys_dicts, size=200, figsize=(10, 10), desc=''):
    """
    可视化图形
    :param polys_dicts:
    :param size:
    :param figsize:
    :param desc:
    :return:
    """
    import matplotlib.pyplot as plt
    from descartes.patch import PolygonPatch

    fig = plt.figure(1, figsize=figsize, dpi=90)
    ax = fig.add_subplot(111)

    all_pts = []
    for _poly_dict in polys_dicts:
        _polygon = _poly_dict['polygon_pts']
        all_pts.extend(list(_polygon))
    backgrnds_np = np.array(all_pts).reshape(-1, 2)
    smallest_side = np.min(backgrnds_np.reshape(-1, 2), axis=0)
    largest_side = np.max(backgrnds_np.reshape(-1, 2), axis=0)
    max_bbox = largest_side - smallest_side
    ori_max_width = max(max_bbox)
    scale = size / ori_max_width
    _offset = (np.array([size / 2, size / 2]) - max_bbox * scale / 2)

    for _poly_dict in polys_dicts:
        # shape: N, 2
        _polygon_pts = _poly_dict['polygon_pts']
        _polygon_np = np.array(_polygon_pts)
        polygon_resize_np = ((_polygon_np - smallest_side) * scale + _offset).astype(int)
        if len(polygon_resize_np) > 2:
            _polygon = Polygon(polygon_resize_np)
        elif len(polygon_resize_np) == 2:
            _polygon = LineString(polygon_resize_np).buffer(3)
        else:
            _polygon = Point(polygon_resize_np).buffer(3)
        _facecolor = _poly_dict.get('facecolor', random.choice(COLOR_MAP))
        _edgecolor = _poly_dict.get('edgecolor', random.choice(COLOR_MAP))
        _hatch = _poly_dict.get('hatch', '')
        _alpha = _poly_dict.get('alpha', 0.5)
        _zorder = _poly_dict.get('zorder', 1)
        _line_width = _poly_dict.get('linewidth', 1)

        patch = PolygonPatch(_polygon, facecolor=_facecolor, edgecolor=_edgecolor, hatch=_hatch, linewidth=_line_width,
                             alpha=_alpha, zorder=_zorder)
        ax.add_patch(patch)
        add_origin(ax, _polygon, 'center', desc=_poly_dict.get('name', ''))
    if desc:
        ax.set_title(desc)
    _margin = 10
    set_limits(ax, -_margin, size + _margin, -_margin, size + _margin)
    plt.show()


def get_s3_client():
    S3_AK = "223HG43LGIX9W3MWTOCL"
    S3_AKS = "tqWXh8kSyxM/QfgF34dMXFJcRrIIGfIIZkVVjSMH"
    s3_client = boto3.client('s3', region_name="cn-north-1", endpoint_url="http://storage.lianjia.com",
                             aws_access_key_id=S3_AK,
                             aws_secret_access_key=S3_AKS)
    return s3_client


def download_frame_json(frame_ids, with_json=True):
    s3_client = get_s3_client()
    return_json_list = []
    for _frame_id in frame_ids:
        _str_frame_id = str(_frame_id).strip()
        try:
            vector_response = s3_client.get_object(Bucket='frame-eval-image', Key=_str_frame_id + '.json')
            vector_str = vector_response['Body'].read().decode('utf-8')
            _vec = vector_str
            if with_json:
                _vec = json.loads(vector_str)
            return_json_list.append(_vec)
        except Exception as ex:
            print(ex, 'NOT FOUND JSON:{}'.format(_frame_id))
    return return_json_list


def generate_all_trans_matrix(center_a, center_b, rotations, reflection_flag=True):
    """
    枚举所有矩阵变换矩阵.

    REF: https://learnopencv.com/image-rotation-and-translation-using-opencv/

    :param center_a: center_a, 户型a的重心
    :param center_b: center_b, 户型b的重心
    :param rotations: [angle_1, angle_2, ...], 角度
    :param reflection_flag: 如果为True则增加反转.
    :return:
    """
    _p_x, _p_y = center_a[0], center_a[1]
    _delta_translation = center_b - center_a
    _d_x, _d_y = _delta_translation[0], _delta_translation[1]
    rot_mats = []
    for _theta in rotations:
        mat_temp = np.eye(3)
        _radius_angle = math.pi*_theta/180
        _alpha, _beta = math.cos(_radius_angle), math.sin(_radius_angle)
        rot_mat = np.array([[_alpha, _beta,  (1 - _alpha)*_p_x - _beta*_p_y + _d_x],
                            [-_beta, _alpha,  _beta*_p_x + (1-_alpha)*_p_y + _d_y]])
        mat_temp[:2, :] = rot_mat
        rot_mats.append(mat_temp)
        if reflection_flag:
            # 关于Y对称
            rot_mat_rev_y = np.eye(3)
            rot_mat_rev_y[0, 0] *= -1
            rot_mat_rev_y[0, 2] = 2*center_b[0]
            rot_mats.append(mat_temp.dot(rot_mat_rev_y))
    return rot_mats


def nearest_fit(a_np, b_np):
    """
    两个点集最近的距离
    :param a_np:
    :param b_np:
    :return:
    """
    if len(a_np) == 0 and len(b_np) == 0:
        return None, None, 0
    elif len(a_np) == 0 or len(b_np) == 0:
        return None, None, float('inf')
    d = np.sqrt(
        np.clip(
            np.sum(a_np ** 2, 1)[:, None] + np.sum(b_np ** 2, 1)[None, :] - 2 * a_np.dot(b_np.T)
            , 0, None)
    )
    choice = np.argmin(d, 1)
    dist = np.min(d, 1)
    return choice, dist, np.sum(dist)


def pt_at_line_side(p1, p2, p):
    """
    判断点在线的左右

    Tmp > 0 在左侧
    Tmp = 0 在线上
    Tmp < 0 在右侧

    # print(pt_at_line_side((1,1), (2,2), (4, 4)))

    :param p1:
    :param p2:
    :param p:
    :return:
    """
    x1, y1 = p1[0], p1[1]
    x2, y2 = p2[0], p2[1]
    x, y = p[0], p[1]
    return np.sign((y1 - y2) * x + (x2 - x1) * y + x1 * y2 - x2 * y1)


def is_false_diff_room(diff_room, counter_frame, line_cover_ratio=0.8):
    """
    检测是否是虚假的差异分间.

    用差异房间的每个实墙去对手户型上的墙体索引找重合比.

    :param diff_room: 差异房间.
    :param counter_frame: 待检测户型.
    :param line_cover_ratio: 线段的覆盖比例.
    :return: 返回true代表是假的diff.
    """
    # 得到差异房间的实墙
    all_wall_length, inter_length = 1e-10, 0
    for _wall in diff_room.room_lines:
        if _wall.type in {3}:
            # 过滤虚拟墙
            continue
        _wall_line_obj = _wall.obj
        for _wall_item in _wall.line_items:
            if _wall_item.type in {16}:
                # 擦除垭口
                _wall_line_obj = _wall_line_obj - _wall_item.diluted_wall_item
        all_wall_length += _wall_line_obj.length
        # 对手户型的墙体膨胀
        related_a_walls = counter_frame.wall_str_tree.query(_wall_line_obj)
        for _diluted_wall in related_a_walls:
            _diluted_wall_id = id(_diluted_wall)
            _a_wall = counter_frame.diluted_wall_id_to_wall[_diluted_wall_id]
            # 斜率是否一致
            if abs(int(_a_wall.angle // 90)) != abs(int(_wall.angle // 90)):
                continue
            inter_obj = _wall_line_obj.intersection(_diluted_wall)
            if not inter_obj.is_empty:
                _wall_line_obj -= inter_obj
                inter_length += inter_obj.length
    return inter_length / all_wall_length > line_cover_ratio


