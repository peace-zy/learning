#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2018 www.ke.com, Inc. All Rights Reserved
from __future__ import division
import __init__
import logging
import os
import collections
import copy
from functools import reduce
import json
from heapq import heappush, heappop
from operator import itemgetter

import numpy as np
from skimage import morphology
from skimage import measure
from skimage.draw import ellipse as circle, line_aa, polygon
from sklearn.neighbors import KDTree
from shapely.geometry import Polygon
from shapely.geometry import MultiPolygon
from shapely.ops import unary_union

from lib import mod_util_base as mod_util
from lib import entity
from lib import code_enum as ce


WORK_COLOR = 0.144              # 家务动线灰度值
GUEST_COLOR = 0.612             # 访客动线灰度值
LIVING_COLOR = 0.873            # 居住动线灰度值

DEFAULT_ZOOM_BASE = 200         # 缩放后长边的长度
DEFAULT_LINE_THICKNESS = 400    # 门厚度+膨胀系数
DEFAULT_THIN_DOOR_WIDTH = 100   # 收缩后的门宽（一半）
DEFAULT_SAMPLE_CNT = 15         # 弧形墙采样点数量

RAY_COLOR = 0.712
MAX_FLOAT = float("inf")


# 定义主要居室类型
SHI = (u'100900000001', u'100900000009')
TING = (u'100900000002',)
CHU = (u'100900000003',)
WEI = (u'100900000004',)
TAI = (u'100900000005',)
OTHER = (u'100900000012',)
KE_TING = u'1'
CAN_TING = u'2'
PASS_ROUTE = u'23'

# 分间嵌入向量 占位符
VEC_CENTER_HOLDER = [
    (SHI, SHI),
    (SHI, TING),
    (SHI, CHU),
    (SHI, WEI),
    (TING, TING),
    (TING, CHU),
    (TING, WEI),
    (WEI, WEI),
    (WEI, CHU),
    (CHU, CHU)
]

# 分间面积嵌入向量 占位符
VEC_AREA_HOLDER = (SHI, TING, WEI, CHU)
# 餐桌摆件
DINING_ITEM_TYPE = (u'3', u'63', u'74')
# 沙发摆件
SOFA_ITEM_TYPE = (u'48', u'52', u'56', u'64', u'65', u'68')
# 床摆件
BED_ITEM_TYPE = (u'37', u'40', u'41', u'44', u'51', u'62')
# 门类型(单开门，推拉门，双开门，子母门，电梯门，垭口)
DOOR_ITEM_TYPE = (u'0', u'1', u'2', u'3', u'4', u'16')
# 室
SHI_SET = set(SHI)
# 厅
TING_SET = set(TING)
# 厨
CHU_SET = set(CHU)
# 卫
WEI_SET = set(WEI)
# 阳台
TAI_SET = set(TAI)
# 其他
OTHER_SET = set(OTHER)

# 移动方向
NEIGHBORS = [(0, 1), (0, -1), (1, 0), (-1, 0)]

# 原始矢量信息[点，墙体附件，墙体，分间，附件]
ORIGIN_INFO_LST = ["all_points", "all_line_items", "all_line", "all_areas", "all_items"]
# 收集的二次处理信息[墙体附件字典，入户门对应ID，点字典，外轮廓信息tuple]
COLLECT_INFO_LST = ["line_items_dict", "entrance_id", "point_dict", "out_info"]

DATA_DICT = "data_dict"                     # 每层新增的特征数据键
ERROR = "error"                             # 错误码键
TRANS_POINT_DICT = "trans_point_dict"       # 左下角平移到原点的点坐标字典
OUT_INFO = "out_info"                       # 四至数据，minx, miny, maxx, maxy, x_len, y_len, max_axis_len
ZOOM_BASE = "zoom_base"                     # 放缩后长边长度配置参数键
LINE_THICKNESS = "line_thickness"           # 门厚度+膨胀系数配置参数键
H = "h"                                     # 收缩后的门宽（一半）配置参数键
SAMPLE_CNT = "sample_cnt"                   # 弧形墙采样点数量配置参数键
ZOOM_RATIO = "zoom_ratio"                   # 放缩比例配置参数键
ZOOM_OFFSET = "zoom_offset"                 # 平移配置参数键
IMG_SIZE = "img_size"                       # 画布大小配置参数键


def line_feature_extractor(frame, params):
    """
    提取可视域和动线特征
    :param frame: entity.Frame 对象
    :param params: 参数
    :return: feature_dict, dict, 特征字典
            error, 状态， mod_util.ErrorCode.ok 为正常
    """

    feature_dict = {ERROR: mod_util.ErrorCode.ok}

    conf_defaults = {
        ZOOM_BASE: DEFAULT_ZOOM_BASE,
        LINE_THICKNESS: DEFAULT_LINE_THICKNESS,
        H: DEFAULT_THIN_DOOR_WIDTH,
        SAMPLE_CNT: DEFAULT_SAMPLE_CNT
    }

    use_conf = {}
    for conf_key in conf_defaults:
        use_conf[conf_key] = params.get(conf_key, conf_defaults[conf_key])

    frame_vector = frame.vector
    plans = frame_vector[frame.plan_key]

    # 每一层左下角平移到坐标原点
    prepare_data(frame)

    # ################### 特征提取 ##########################
    # 户型外墙之和
    edge_len = 0
    liners = []

    for plan_idx in range(frame.plan_cnt):

        data_dict = plans[plan_idx][DATA_DICT]

        out_info = data_dict[OUT_INFO]

        # 绘图坐标放缩比例和偏移量
        zoom_ratio, zoom_offset, img_size = get_zoom(use_conf[ZOOM_BASE], out_info)

        data_dict[ZOOM_RATIO] = zoom_ratio
        data_dict[ZOOM_OFFSET] = zoom_offset
        data_dict[IMG_SIZE] = img_size

        # 墙体、门特征
        line_feature_dict = line_feature(frame, plan_idx, **use_conf)
        error = line_feature_dict[ERROR]
        if error != mod_util.ErrorCode.ok:
            feature_dict[ERROR] = error
            return feature_dict

        data_dict["points_to_line_map"] = line_feature_dict["points_to_line_map"]
        data_dict["entrance_point"] = line_feature_dict["entrance_point"]

        # 分间点特征
        area_feature_dict = area_feature(frame, plan_idx)
        area_error = area_feature_dict[ERROR]
        if area_error != mod_util.ErrorCode.ok and area_error != mod_util.ErrorCode.missing_entrance:
            feature_dict[ERROR] = area_error
            return feature_dict

        line_img_dict = line_map(img_size, line_feature_dict)

        edge_len_item = line_feature_dict["edge_len"]
        edge_len += edge_len_item

        # 组织特征对象
        steps = params.get('steps', 3)

        is_draw = params.get('is_draw', False)
        is_draw_v = params.get('is_draw_v', False)

        simple_info = {
            "minx": out_info[0],
            "miny": out_info[1],
            "frame_id": frame.frame_id,
            "city_code": frame.city_code,
            "zoom_base": use_conf[ZOOM_BASE],
            "zoom_ratio": zoom_ratio,
            "zoom_offset": zoom_offset,
            "img_size": img_size,
            "edge_len": edge_len,
            "steps": steps,
            "line_thickness": use_conf[LINE_THICKNESS],
            "thin_door_width": use_conf[H],
            "is_draw": is_draw,
            "is_draw_v": is_draw_v,

        }

        liner = entity.Liner(simple_info, line_feature_dict, line_img_dict, area_feature_dict, plans[plan_idx])
        if area_error == mod_util.ErrorCode.missing_entrance:
            liners.append(None)
        else:
            liners.append(liner)
    feature_dict["liners"] = liners

    return feature_dict


def prepare_data(frame):
    """
    准备数据, 为每一层增加 data_dict 字段， 包含平移后的点坐标集合以及外接矩形信息
    :param frame: entity.Frame 对象
    :return:
    """
    for plan_idx in range(frame.plan_cnt):
        data_dict = {ERROR: mod_util.ErrorCode.ok}
        trans_point_dict = {}  # 点坐标字典

        minx, miny, maxx, maxy = frame.border_key_points[plan_idx]
        points_dict = frame.vector[frame.plan_key][plan_idx][ce.POINTS_DICT_KEY]
        # 调整坐标到左下角为原点， 不计入户型计算的分间坐标有可能出现负值
        for p_id in points_dict:
            trans_point_dict[p_id] = [points_dict[p_id][ce.X] - minx, points_dict[p_id][ce.Y] - miny]

        # 外接矩形长宽
        x_len = float(maxx - minx)
        y_len = float(maxy - miny)
        max_axis_len = max(x_len, y_len)
        data_dict.update({
            TRANS_POINT_DICT: trans_point_dict,
            OUT_INFO: (minx, miny, maxx, maxy, x_len, y_len, max_axis_len)
        })
        frame.vector[frame.plan_key][plan_idx][DATA_DICT] = data_dict

    return


def get_zoom(zoom_base, out_info, offset_ratio=0.1, image_ratio=1.2):
    """
    放缩比例和偏移
    :param zoom_base: float/int, 放缩后长度
    :param out_info: list, 四至信息
    :param offset_ratio: float, 平移比例
    :param image_ratio: float, 画布比例, 大于1
    :return: zoom_ratio, 放缩比例
            zoom_offset, 放缩后整体偏移量
            image_size, 图片尺寸
    """
    _, _, _, _, _, _, max_axis_len = out_info
    zoom_ratio = zoom_base / max_axis_len
    zoom_offset = int(zoom_base * offset_ratio)
    image_size = int(image_ratio * zoom_base)
    return zoom_ratio, zoom_offset, image_size


def line_feature(frame, plan_idx, **conf):
    """
    线特征
    :param frame: entity.Frame 对象
    :param plan_idx: int, 层索引
    :param conf: 配置参数
    :return:
    """
    frame_vector = frame.vector
    plan = frame_vector[frame.plan_key][plan_idx]
    all_lines = plan[ce.PLAN_LINES_KEY]

    feature_dict = {ERROR: mod_util.ErrorCode.ok}

    edge_len = 0.
    points_to_line_map = dict()
    zoom_ps_dict = {
        "full_line_ps": [],
        "seg_lines_norm": [],
        "seg_lines_expand": []
    }
    all_bit_dict = {
        "full_line_ps": [[], []],
        "seg_lines_norm": [[], []],
        "seg_lines_expand": [[], []]
    }

    entrance_point = None
    entrance_line = None

    # #################### 遍历 所有边集合 ######################
    for line in all_lines:

        # ############ 可通过的门、垭口等切分后的墙体以及完整墙体提取 #####################
        # line_split_dict = line_split(line, plan, entrance_id, thin_door_width, sample_cnt)
        line_split_dict = line_split(line, plan, frame.entrance_item, **conf)
        error = line_split_dict[ERROR]
        if error != mod_util.ErrorCode.ok:
            feature_dict[ERROR] = error
            return feature_dict

        # 墙体切分分段坐标[正常门宽切分，收缩门宽切分，不切分]
        line_seg_info = ["seg_lines_norm", "seg_lines_expand", "full_line_ps"]
        # 墙体属性[弧度, 类型, 是否外墙, 两端点id, 墙体长度]
        line_info = ["l_curve", "l_type", "edge_computed", "l_ps", "line_len"]

        seg_lines_norm, seg_lines_expand, full_line_ps = itemgetter(*line_seg_info)(line_split_dict)

        l_curve, l_type, edge_computed, l_ps_ids, line_len = itemgetter(*line_info)(line_split_dict)

        # 外墙统计
        if edge_computed:
            edge_len += line_len

        _tmp_line = {'points': full_line_ps[0], 'len': line_len, 'curve': l_curve, 'type': l_type}
        # 加入线集合
        points_to_line_map[','.join(l_ps_ids)] = _tmp_line
        _tmp_line_reversed = copy.deepcopy(_tmp_line)
        _tmp_line_reversed['points'] = [m for m in reversed(full_line_ps[0])]
        points_to_line_map[','.join(reversed(l_ps_ids))] = _tmp_line_reversed

        # 放缩
        zoom_data_source = {
            "full_line_ps": full_line_ps,
            "seg_lines_norm": seg_lines_norm,
            "seg_lines_expand": seg_lines_expand
        }
        if "entrance_point" in line_split_dict:
            zoom_data_source["entrance_point"] = line_split_dict["entrance_point"]
            zoom_data_source["entrance_line"] = line_split_dict["entrance_line"]

        # 虚拟墙不绘制
        if str(l_type) == u'3':
            continue

        # ############### 放缩后生成位图坐标 ####################
        zoom_result = zoom_lines(plan[DATA_DICT][ZOOM_RATIO], plan[DATA_DICT][ZOOM_OFFSET], zoom_data_source)

        if "entrance_point" in zoom_result:
            entrance_point = zoom_result["entrance_point"]
            entrance_line = zoom_result["entrance_line"]
        bit_dict = vector2bitmap(zoom_result)
        all_line_types = ["full_line_ps", "seg_lines_norm", "seg_lines_expand"]
        for line_type in all_line_types:
            zoom_ps_dict[line_type].extend([(tuple(line[0]), tuple(line[1])) for line in zoom_result[line_type]])
            all_bit_dict[line_type][0].extend(bit_dict[line_type][0])
            all_bit_dict[line_type][1].extend(bit_dict[line_type][1])
    feature_dict.update({
        "edge_len": edge_len,
        "zoom_ps_dict": zoom_ps_dict,
        "all_bit_dict": all_bit_dict,
        "entrance_point": entrance_point,
        "entrance_line": entrance_line,
        "points_to_line_map": points_to_line_map
    })

    return feature_dict


def line_split(line_object, plan, entrance_item_id, **conf):
    """
    按可通过的墙体附件将墙体切割成多段不连续子墙体，及其他基本信息
    :param line_object: dict, 一面墙体数据
    :param plan: dict, 层矢量数据
    :param entrance_item_id: str, 入户门对应的墙体附件id
    :return: data_dict, dict:
        error, 状态，mod_util.ErrorCode.ok 为正常
        seg_lines_norm, 正常门宽切割的墙体列表
        seg_lines_expand, 收缩门宽切割的墙体列表
        line_ps, 墙体两端的点（坐标）
        line_len, 墙体长度
        l_curve, 弧度
        l_type, 墙体类型
        edge_computed, 是否外墙
        l_ps, 墙体两端点（id）
        entrance_point, 入户门中点（可无）
        entrance_line, 入户门两端点（可无）
    """
    data_dict = {ERROR: mod_util.ErrorCode.ok}

    l_curve = line_object.get(ce.LINE_CURVE_KEY, 0)
    l_type = line_object.get(ce.LINE_TYPE_KEY, 0)
    edge_computed = line_object.get(ce.EDGE_COMP_KEY, False)
    l_ps = line_object.get(ce.LINE_POINTS_KEY, None)
    l_items = line_object.get(ce.LINE_ITEMS_KEY, [])

    point_dict = plan[DATA_DICT][TRANS_POINT_DICT]
    all_line_items_dict = plan[ce.LINE_ITEMS_DICT_KEY]

    a_x, a_y = point_dict[l_ps[0]]
    b_x, b_y = point_dict[l_ps[-1]]
    line_len = mod_util.euclidean_dist([a_x, a_y], [b_x, b_y])
    line_ps = ((a_x, a_y), (b_x, b_y))
    if a_x > b_x:
        # 矫正脏数据
        line_ps = ((b_x, b_y), (a_x, a_y))

    # 切割后的线段（门宽正常）
    seg_lines_norm = []
    # 切割后的线段（门宽缩放）
    seg_lines_expand = []

    # 正常门线段
    doors_norm = []
    # 收缩门线段
    doors_thin = []

    # 找墙体附件中心点, 属性
    for tmp_item_id in l_items:
        tmp_item = all_line_items_dict[tmp_item_id]

        item_type = tmp_item[ce.LINE_ITEM_TYPE_KEY]
        start_index = tmp_item[ce.LINE_ITEM_START_INDEX_KEY]
        item_length = tmp_item[ce.LINE_ITEM_LENGTH_KEY]
        tmp_item_is = tmp_item[ce.TYPE_IS_KEY]
        item_start = tmp_item.get(ce.LINE_ITEM_START_KEY, None)

        if item_start is None:
            logging.error("line item lack start")
            data_dict[ERROR] = mod_util.ErrorCode.item_start_err
            return data_dict

        if tmp_item_is == ce.IS_DOOR or str(item_type) in DOOR_ITEM_TYPE:
            # 如果是门加入 边界点
            if start_index != 0:
                item_start = line_len - item_length - item_start
            if str(l_type) != u'3':
                norm_h = item_length / 2
                norm_l, norm_r, norm_m = None, None, None
                # 两种门线（正常和收缩的）
                for h_th, doors_lst in zip([conf[H], norm_h], [doors_thin, doors_norm]):
                    p_l, p_r, p_m = get_door_points_3(line_ps, l_len=line_len, l_s=item_start, l_d=item_length, h=h_th)
                    # 门中点距离墙体第一个点的距离，用于排序
                    head_off_set = mod_util.euclidean_dist([line_ps[0][0], line_ps[0][1]], [p_m[0], p_m[1]])
                    doors_lst.append((p_l, p_r, p_m, head_off_set))
                    if h_th == norm_h:
                        norm_l, norm_r, norm_m = p_l, p_r, p_m

                if entrance_item_id and tmp_item_id == entrance_item_id:
                    data_dict.update({
                        "entrance_point": norm_m,
                        "entrance_line": [norm_l, norm_r]
                    })
    # 排序，从一头开始依次计算墙体段，否则有可能因为附件顺序导致门被覆盖
    doors_thin = sorted(doors_thin, key=lambda x: x[3])
    doors_norm = sorted(doors_norm, key=lambda x: x[3])
    for doors, lines_lst in zip([doors_norm, doors_thin], [seg_lines_norm, seg_lines_expand]):
        new_start_p = line_ps[0]
        for p_l, p_r, p_m, head_off_set in doors:
            lines_lst.append((new_start_p, p_l))
            new_start_p = p_r
        lines_lst.append((new_start_p, line_ps[-1]))

    error, full_line_ps, new_line_len = extract_line_points(line_ps, l_curve, 15)
    if error != mod_util.ErrorCode.ok:
        data_dict[ERROR] = error
        return data_dict

    data_dict.update({
        "seg_lines_norm": np.array(seg_lines_norm),
        "seg_lines_expand": np.array(seg_lines_expand),
        "full_line_ps": np.array(full_line_ps),
        "line_len": line_len if new_line_len is None else new_line_len,
        "l_curve": l_curve,
        "l_type": l_type,
        "edge_computed": edge_computed,
        "l_ps": l_ps
    })
    return data_dict


def get_door_points_3(line_p, l_len, l_s, l_d, h, need_int=True):
    """
    计算门的左、右、中三个点
    :param line_p: 线的点(从左到右, 从上到下存储)
    :param l_len: 线段长度
    :param l_s: 起始点偏移(以第一个点为基准)
    :param l_d: 门长
    :param h: 离门中心点偏移
    :param need_int: bool, 是否强制整形坐标
    :return:
    """
    # 判断方位
    (x_0, y_0), (x_1, y_1) = line_p
    if y_0 < y_1:
        # 向右上
        x_offset = (x_1 - x_0)
        y_offset = (y_1 - y_0)
        l_offset = (l_s + l_d - h)
        x_l_h = l_offset * x_offset / l_len + x_0
        y_l_h = y_1 - (l_len - l_offset) * y_offset / l_len
        r_offset = (l_s + l_d/2 + h)
        x_r_h = r_offset * x_offset / l_len + x_0
        y_r_h = y_1 - (l_len - r_offset) * y_offset / l_len
    else:
        # 向右下
        x_offset = (x_1 - x_0)
        y_offset = (y_0 - y_1)
        l_offset = (l_s + l_d/2 - h)
        y_l_h = y_0 - l_offset * y_offset / l_len
        x_l_h = x_1 - (l_len - l_offset) * x_offset / l_len
        r_offset = (l_s + l_d/2 + h)
        y_r_h = y_0 - r_offset * y_offset / l_len
        x_r_h = x_1 - (l_len - r_offset) * x_offset / l_len
    if need_int:
        x_l_h, y_l_h, x_r_h, y_r_h = int(x_l_h), int(y_l_h), int(x_r_h), int(y_r_h)
    p_l, p_r = (x_l_h, y_l_h), (x_r_h, y_r_h)
    p_m = ((x_l_h + x_r_h)/2, (y_l_h+y_r_h)/2)
    return p_l, p_r, p_m


def extract_line_points(line_ps, l_curve, sample_cnt):
    """
    提取墙体点列表，特别是弧形墙，进行采样
    :param line_ps: 墙体两端点坐标
    :param l_curve: 弧度
    :param sample_cnt: 采样数量
    :return:
    """
    error = mod_util.ErrorCode.ok
    line_len = None

    (a_x, a_y), (b_x, b_y) = line_ps
    # 整面墙体的有序点列表
    full_line_ps = [(a_x, a_y)]
    # 对于弧线采样, 10 是弧顶离墙距离，太小则认为是直线
    if abs(l_curve) > 10.0:
        try:
            # 对弧墙采样
            _x, _y, arc_len = mod_util.get_cycle_radius(((a_x, a_y), (b_x, b_y), l_curve), sample_cnt=sample_cnt)
            line_len = arc_len
            if l_curve <= 0.0:
                full_line_ps.extend([m for m in reversed([x for x in zip(_x, _y)])])
            else:
                full_line_ps.extend([x for x in zip(_x, _y)])
        except Exception as e:
            error = mod_util.ErrorCode.get_cycle_radius_err
            logging.exception(e)
    full_line_ps.append((b_x, b_y))
    all_lines = [(full_line_ps[n], full_line_ps[n + 1]) for n in range(len(full_line_ps) - 1)]
    full_line_ps = np.array(all_lines)
    return error, full_line_ps, line_len


def area_feature(frame, plan_idx):
    """
    分间中提取中心点等特征
    :param frame: entity.Frame 对象
    :param plan_idx: int, 层索引
    :return:
    """
    frame_vector = frame.vector
    plan = frame_vector[frame.plan_key][plan_idx]
    all_areas = plan[ce.PLAN_AREAS_KEY]
    all_items = plan[ce.PLAN_ITEMS_KEY]
    data_dict = plan[DATA_DICT]

    feature_dict = {ERROR: mod_util.ErrorCode.ok}

    minx, miny, _, _, _, _, _ = data_dict["out_info"]
    zoom_ratio = data_dict["zoom_ratio"]
    zoom_offset = data_dict["zoom_offset"]
    point_dict = data_dict[TRANS_POINT_DICT]
    points_to_line_map = data_dict["points_to_line_map"]
    img_size = data_dict["img_size"]
    entrance_point = data_dict["entrance_point"]

    plan_line_im_shape = np.array([img_size, img_size], dtype='int32')
    plan_mask_im = np.zeros(plan_line_im_shape, dtype=np.float32)

    # #################### 动线相关 ######################
    # 起居动线(卧室,客厅,卫生间)
    shi_bed_center = set([])
    living_line_points_dict = collections.defaultdict(list)
    # 会客动线(大门, 客厅, 餐厅, 公卫)
    guest_line_points_dict = collections.defaultdict(list)
    # 家务动线(餐厅到厨房)
    work_line_points_dict = collections.defaultdict(list)

    # #################### 动线 找餐桌 ######################
    for tmp_item in all_items:
        tmp_item_type = tmp_item.get('type', None)
        tmp_item_x = tmp_item.get('x', None)
        tmp_item_y = tmp_item.get('y', None)
        if None in {tmp_item_type, tmp_item_x, tmp_item_y}:
            continue
        _point = tuple(coor_trans((tmp_item_x - minx, tmp_item_y - miny), zoom_ratio, zoom_offset))
        if tmp_item_type and str(tmp_item_type) in DINING_ITEM_TYPE:
            work_line_points_dict['can_ting_center'].append(_point)
            guest_line_points_dict['can_ting_center'].append(_point)
        elif tmp_item_type and str(tmp_item_type) in SOFA_ITEM_TYPE:
            guest_line_points_dict['ke_ting_center'].append(_point)
            living_line_points_dict['ke_ting_center'].append(_point)
        elif tmp_item_type and str(tmp_item_type) in BED_ITEM_TYPE:
            shi_bed_center.add(_point)

    inplace_area = 0.
    room_cnt_dict = collections.defaultdict(int)  # 分间类型计数器
    size_sum = 0.  # 分间面积和

    for area in all_areas:
        # 分间的点
        area_id = area.get(u"id", None)
        # 分间的点
        area_points = area.get(u"points", None)
        # 分间的功能大类类型
        area_type = area.get(u"roomType", None)
        # 分间的功能类型
        area_detail_type = area.get(u"type", None)
        # 分间面积
        area_area = area.get('size', None)
        # 分间附件
        area_attachments = area.get('attachments', None)
        # 是否空（空则不计入总面积）
        is_empty = area.get('empty', False)

        # 分间的点不存在
        if area_points is None or area_type is None or area_area is None:
            feature_dict["error"] = mod_util.ErrorCode.area_info_empty
            return feature_dict
        if not is_empty:
            size_sum += area_area
        # 总面积统计
        inplace_area += area_area
        # 分间类型计数
        room_cnt_dict[area_type] += 1
        area_minx = area_maxx = area_miny = area_maxy = None
        # 分间的点集(包含圆弧填充点)
        tmp_area_points = []

        area_points_cnt = len(area_points)
        for i in range(area_points_cnt):
            current_p_id = area_points[i]
            after_p_id = area_points[(i + 1) % area_points_cnt]
            current_p = point_dict.get(current_p_id, None)
            after_p = point_dict.get(after_p_id, None)

            if current_p is None or after_p is None:
                feature_dict["error"] = mod_util.ErrorCode.area_point_err
                return feature_dict

            if area_minx is None:
                area_minx = area_maxx = current_p[0]
                area_miny = area_maxy = current_p[1]
            else:
                area_minx, area_maxx = min(area_minx, current_p[0]), max(area_maxx, current_p[0])
                area_miny, area_maxy = min(area_miny, current_p[1]), max(area_maxy, current_p[1])

            points_cp_key = ','.join([current_p_id, after_p_id])
            cp_line = points_to_line_map.get(points_cp_key, None)
            if cp_line is not None:
                cp_line_points = cp_line['points']
                if not tmp_area_points:
                    tmp_area_points.extend(cp_line_points)
                else:
                    tmp_area_points.extend(cp_line_points[1:])
            else:
                logging.error('Not find{}'.format(points_cp_key))
                feature_dict["error"] = mod_util.ErrorCode.area_point_err
                return feature_dict

        # ############ 统计 动线关键点 ############
        # 缩放的分间的点集(包含圆弧填充点)
        tmp_scale_area_points = coor_trans(tmp_area_points, zoom_ratio, zoom_offset)
        rr_area, cc_area = get_area_polygon(tmp_scale_area_points, plan_line_im_shape)
        _shape_template_im = np.zeros(plan_line_im_shape, dtype=np.float32)
        _shape_template_im[rr_area, cc_area] = 1

        try:
            _mass_center = tuple([int(x) for x in measure.centroid(_shape_template_im)])
        except Exception as e:
            logging.error(e)
            feature_dict["error"] = mod_util.ErrorCode.area_center_error
            return feature_dict

        if area_type not in {ce.AreaType.garden.value, ce.AreaType.terrace}:
            plan_mask_im[rr_area, cc_area] = 1

        # 判断附件是否在分间内
        for i_x, i_y in list(shi_bed_center):
            if 0 <= i_x < img_size and 0 <= i_y < img_size and plan_mask_im[i_x, i_y] == 1:
                living_line_points_dict['key_points'].append((i_x, i_y))
                shi_bed_center.remove((i_x, i_y))
        # 入户门
        if entrance_point is not None:
            guest_line_points_dict['key_points'].append(tuple(entrance_point))
        else:
            feature_dict["error"] = mod_util.ErrorCode.missing_entrance
            logging.error('Can not find entrance')
            return feature_dict
        # 如果没找到餐桌就使用餐厅重心.
        if area_type in TING and str(area_detail_type) == CAN_TING \
                and not guest_line_points_dict['can_ting_center'] \
                and not work_line_points_dict['can_ting_center']:
            work_line_points_dict['can_ting_center'].append(_mass_center)
            guest_line_points_dict['can_ting_center'].append(_mass_center)

        # 如果没找到客厅沙发就使用客厅重心.
        if area_type in TING and str(area_detail_type) == KE_TING \
                and not guest_line_points_dict['ke_ting_center'] \
                and not living_line_points_dict['ke_ting_center']:
            guest_line_points_dict['ke_ting_center'].append(_mass_center)
            living_line_points_dict['ke_ting_center'].append(_mass_center)

        if area_type in CHU:
            # 厨房可能没有门
            work_line_points_dict['chu_center'].append(_mass_center)

        if area_type in WEI:
            living_line_points_dict['wei_center'].append(_mass_center)
    feature_dict.update({
        "living_line_points_dict": living_line_points_dict,
        "guest_line_points_dict": guest_line_points_dict,
        "work_line_points_dict": work_line_points_dict,
        "plan_mask_im": plan_mask_im,
        "plan_mask_im_reverse": 1 - plan_mask_im
    })
    return feature_dict


def heuristic_square(a, b):
    return (b[0] - a[0])**2 + (b[1] - a[1])**2


def draw_line_segments(line_pts_arr):
    """
    画分段线
    :param line_pts_arr:
    :return:
    """
    all_rows = []
    all_columns = []
    for line in line_pts_arr:
        rows, columns, _ = line_aa(line[0][0], line[0][1], line[1][0], line[1][1])
        all_rows.extend(rows)
        all_columns.extend(columns)
    return [all_rows, all_columns]


def coor_trans(points, zoom_ratio, offset, need_int=True, need_list=True):
    """
    坐标变换
    :param points:
    :param zoom_ratio:
    :param offset:
    :param need_int:
    :param need_list:
    :return:
    """
    if type(points) is not np.ndarray:
        points = np.array(points)
    _tmp_points = points * zoom_ratio + offset
    if need_int:
        _tmp_points = _tmp_points.astype(int)
    if need_list:
        _tmp_points = _tmp_points.tolist()
    return _tmp_points


def reverse_coor_trans(points, zoom_ratio, offset, need_int=True, need_list=True):
    """
    坐标反变换
    :param points:
    :param zoom_ratio:
    :param offset:
    :param need_int:
    :param need_list:
    :return:
    """
    if type(points) is not np.ndarray:
        points = np.array(list(points))
    _tmp_points = (points-offset)/zoom_ratio
    if need_int:
        _tmp_points = _tmp_points.astype(int)
    if need_list:
        _tmp_points = _tmp_points.tolist()
    return _tmp_points


def get_area_polygon(ordered_points, img_shape):
    """
    填充多边形
    :param ordered_points: 边界关键点
    :param img_shape: 图片尺寸
    :return:
    """
    if type(ordered_points) is not np.ndarray:
        ordered_points = np.array(ordered_points)
    row_coo_arr = ordered_points[:, 0]
    col_coo_arr = ordered_points[:, 1]
    rr, cc = polygon(row_coo_arr, col_coo_arr, img_shape)
    return rr, cc


def draw_skeleton(image):
    """
    画骨骼线
    :param image:
    :return:
    """
    _image = copy.deepcopy(image)
    _image[_image > 0.01] = 1.0
    _image = 1 - _image
    skeleton = morphology.skeletonize(_image)
    return skeleton


def sorted_points_to_line(line_dict):
    route_set = set([])
    for _y in line_dict:
        _x_list = line_dict[_y]
        if len(_x_list) < 3:
            continue
        _x_list = sorted(_x_list)
        list_holder = []
        tmp_arr = [_x_list[0]]
        for i in range(len(_x_list)-1):
            if _x_list[i+1] - _x_list[i] <= 1:
                tmp_arr.append(_x_list[i+1])
            else:
                list_holder.append(tuple(tmp_arr))
                tmp_arr = [_x_list[i+1]]
        list_holder.append(tmp_arr)
        for _l in list_holder:
            if len(_l) < 3:
                continue
            else:
                route_set.add(((_l[0], _y), (_l[-1], _y)))
    return list(route_set)


def post_process_path_points(route, key_points, zoom_ratio, offset, minx, miny):
    """
    对路径后处理
    0. 还原坐标系.
    1. 合并点为直线.
    2. 求还原的动线长度.
    :param route: 路径点
    :param key_points: 目标关键点
    :param zoom_ratio: 相交点
    :param offset: 相交点
    :param minx: 原始户型图最坐下角点x坐标
    :param miny: 原始户型图最坐下角点y坐标
    :return:
    """
    # 还原坐标系
    _key_points = reverse_coor_trans(key_points, zoom_ratio, offset)
    _key_points = [[p[0] + minx, p[1] + miny] for p in _key_points]
    # 合并点为直线
    x_line_dict = collections.defaultdict(list)
    y_line_dict = collections.defaultdict(list)
    for x, y in route:
        x_line_dict[x].append(y)
        y_line_dict[y].append(x)
    y_line_points = sorted_points_to_line(y_line_dict)
    y_line_len = sum([end[0] - start[0] for start, end in y_line_points])

    x_line_points = [((start[1], start[0]), (end[1], end[0]))for start, end in sorted_points_to_line(x_line_dict)]
    x_line_len = sum([end[1] - start[1] for start, end in x_line_points])

    line_points_com = y_line_points + x_line_points
    # 坐标还原
    _route = [(reverse_coor_trans(start, zoom_ratio, offset), reverse_coor_trans(end, zoom_ratio, offset))
              for start, end in line_points_com]

    _route = [[[l[0][0] + minx, l[0][1] + miny], [l[1][0] + minx, l[1][1] + miny]] for l in _route]
    return _route, _key_points, (y_line_len + x_line_len)/zoom_ratio


def find_the_closest_point(key_points, skeleton_coor):
    """
    找到最近的点
    :param key_points:
    :param skeleton_coor:
    :return:
    """
    _key_points = set([])
    skeleton_coor_points = list(np.array(skeleton_coor.nonzero()).T)
    for p in key_points:
        _closest_p = sorted([(heuristic_square(p, _cor), _cor) for _cor in skeleton_coor_points],
                            key=lambda x: x[0])[0][1]
        _key_points.add(tuple(_closest_p))
    return _key_points


def return_next_point(next_points, route):
    """
    找路径上一个点的下一个路径点, 存在断头路就返回None
    :param next_points:
    :param route: set
    :return: list 可能分叉情况
    """
    ret_next_points = []
    for current in next_points:
        tmp_find_points = []
        for i, j in NEIGHBORS:
            neighbor = current[0] + i, current[1] + j
            if neighbor in route:
                tmp_find_points.append(neighbor)
        if tmp_find_points:
            ret_next_points.extend(tmp_find_points)
        else:
            return []
    return ret_next_points


def post_process_cross(routes, zoom_ratio, offset, threshold=7):
    """
    相交线段后处理
    1. 过滤. 如果相交点在目标点附近, 检测两条路径是不是都还有余下的路径(大于一个阈值), 如果有就认为是相交, 否则, 不相交.
    2. 坐标变换.
    3. 序列化.
    :param routes:
    :param zoom_ratio:
    :param offset:
    :param threshold:
    :return:
    """
    _routes = copy.deepcopy(routes)
    cross_points = _routes[0].intersection(_routes[1])
    filtered_cross_points = []
    for _cross_pt in cross_points:
        # 对每条线每个交点进行延展 10 次 看是否能延申下去.
        is_not_cross = False
        for route in _routes:
            route_next_points = [_cross_pt]
            for i in range(int(threshold)):
                route = route - set(route_next_points)
                _next_points = return_next_point(route_next_points, route)
                if len(_next_points) > 1:
                    # 存在 并且大于 1 一个分支
                    route_next_points = _next_points
                else:
                    is_not_cross = True
                    break
            if is_not_cross:
                break
        if is_not_cross:
            continue
        else:
            filtered_cross_points.append(_cross_pt)

    _filtered_cross_points = reverse_coor_trans(filtered_cross_points, zoom_ratio, offset)
    ret_str = '0'
    if _filtered_cross_points:
        ret_str = mod_util.arr_to_str(_filtered_cross_points)
    return ret_str, set(filtered_cross_points)


def heuristic(a, b):
    return abs(b[0] - a[0]) + abs(b[1] - a[1])


def is_straight(a, b):
    return a[0] == b[0] or a[1] == b[1]


def cal_nearest_point_dist(current, existed_route_points, tree):
    """
    查找最近点
    :param current: tuple, x,y 当前点坐标
    :param existed_route_points: key(tuple): value(float), 坐标:额外惩罚值, 已经走过的点
    :param tree: 根据existed_route_points 构建的 KD-tree, 用于加速
    :return:
    """
    min_d = MAX_FLOAT
    b_p = None

    if tree is not None:
        nnp = tree.query([[current[0], current[1]]], k=1)
        min_d = nnp[0][0][0]
        b_p = tuple(tree.get_arrays()[0][nnp[1][0][0]])

    for b in existed_route_points:
        _cor = existed_route_points[b]
        d = abs(current[0] - b[0]) + abs(current[1] - b[1]) - _cor
        if d < min_d:
            min_d = d
            b_p = b

    min_d = max(1, min_d)
    return min_d, b_p


def a_star_test(array, start, goal, existed_route_points, thresh_hold=0.9):
    """
    不加约束的的找最近点(不找路径)
    :param array: 地图
    :param start: 起点
    :param goal: 目标点
    :param existed_route_points: 已经走过的路
    :param thresh_hold: 碰壁的阈值
    :return:
    """
    close_set = set()
    came_from = {}
    gscore = {start: 0}
    fscore = {start: heuristic(start, goal)}
    all_nn = NEIGHBORS + [(1, 1), (-1, -1), (-1, 1), (1, -1)]
    oheap = []
    oheap_dict = collections.defaultdict(int)
    heappush(oheap, (fscore[start], start))
    oheap_dict[start] += 1

    test_i = 0
    # closest_dict = dict()
    new_goal_point = goal
    max_ratio = float('-inf')

    # 必要时构建 kd-tree 加速
    zero_cor_lst = [[k[0], k[1]] for k in existed_route_points if existed_route_points[k] == 0]
    zero_cor_cnt = len(zero_cor_lst)
    new_existed_route_points = existed_route_points
    tree = None
    # 当可建树节点超过10个时构建KD-tree
    if zero_cor_cnt > 10:
        new_existed_route_points = {k: existed_route_points[k] for k in existed_route_points if existed_route_points[k] != 0}
        tree = KDTree(np.array(zero_cor_lst), leaf_size=3, metric='manhattan')

    while oheap:
        current = heappop(oheap)[1]
        oheap_dict[current] -= 1
        if current == goal or current in existed_route_points:
            # logging.debug('spend iter:{}'.format(test_i))
            return new_goal_point, max_ratio
        close_set.add(current)
        # 错过最近已知路径的惩罚
        if existed_route_points:
            # 计算已知路径最近点
            _nearest_point_dist, _point = cal_nearest_point_dist(current, new_existed_route_points, tree)
            # 计算当前点离目标点的距离
            _heuristic_current2goal = heuristic(current, goal)
            _ratio = _heuristic_current2goal/_nearest_point_dist
            if max_ratio < _ratio:
                new_goal_point = _point
                max_ratio = _ratio
            # closest_dict[current] = _ratio
        for i, j in all_nn:
            neighbor = current[0] + i, current[1] + j
            if neighbor in close_set:
                continue
            if (not 0 <= neighbor[0] < array.shape[0]) or (not 0 < neighbor[1] < array.shape[1]):
                continue
            heuristic_neighbor2goal = heuristic(neighbor, goal)
            # 忽略骨骼线奖励
            _road_status = max(0, array[neighbor[0]][neighbor[1]])
            tentative_g_score = gscore[current] + heuristic(current, neighbor)
            if _road_status > thresh_hold:
                continue
            if tentative_g_score < gscore.get(neighbor, 0) or oheap_dict[neighbor] == 0:
                came_from[neighbor] = current
                gscore[neighbor] = tentative_g_score
                fscore[neighbor] = tentative_g_score + heuristic_neighbor2goal
                heappush(oheap, (fscore[neighbor], neighbor))
                oheap_dict[neighbor] += 1
                test_i += 1
    return None, None


def a_star(array, start, goal, existed_route_points, gray_scale_status=None, thresh_hold=0.9, turn_cost=5.0):
    """
    训练算法
    :param array: 地图
    :param start: 起点
    :param goal: 目标点
    :param existed_route_points: 已经走过的路
    :param gray_scale_status: 需要加特殊惩罚的灰度值
    :param thresh_hold: 碰壁的阈值
    :param turn_cost: 完成路径的角点惩罚
    :return:
    """
    if gray_scale_status is None:
        gray_scale_status = collections.defaultdict(set)
    close_set = set()
    came_from = {}
    # 距离起点分值
    gscore = {start: 0}
    # 距离终点分值
    fscore = {start: heuristic(start, goal)}

    turn_penalty = 100 * thresh_hold
    cross_cost = turn_penalty + 2 * thresh_hold

    # <距终点分值，点坐标>
    oheap = []
    heappush(oheap, (fscore[start], start))

    oheap_dict = collections.defaultdict(int)
    oheap_dict[start] = 1

    is_cross = False
    cross_set = set([])
    test_i = 0
    color_set = gray_scale_status['color_set']
    skeleton_reward = gray_scale_status['skeleton_reward']
    min_heuristic_path2goal = float('inf')
    # 探索过程中最近的点距离
    while oheap:
        current = heappop(oheap)[1]
        oheap_dict[current] -= 1
        if current == goal or current in existed_route_points:
            data = []
            corner = [turn_cost, turn_cost]
            x_pos, y_pos = [], []
            while current in came_from:
                data.append(current)
                x_pos.append(current[0])
                y_pos.append(current[1])
                current = came_from[current]
                if len(data) > 2:
                    if not is_straight(current, data[-2]):
                        corner.append(1.5*turn_cost)
                    else:
                        corner.append(0)
            corner[-1] = turn_cost
            # 是否相交
            inter_set = cross_set.intersection(set(data)) - {start, goal}
            if inter_set:
                is_cross = True
            return data, corner, x_pos, y_pos, is_cross, inter_set, None
        close_set.add(current)
        for i, j in NEIGHBORS:
            neighbor = current[0] + i, current[1] + j
            if neighbor in close_set:
                continue
            if (not 0 <= neighbor[0] < array.shape[0]) or (not 0 < neighbor[1] < array.shape[1]):
                continue
            came_from_node = came_from.get(current, current)

            # 斜向移动时惩罚，正上下左右时不惩罚
            _turn_penalty = turn_penalty
            _is_straight = is_straight(came_from_node, neighbor)
            if _is_straight:
                _turn_penalty = 0

            heuristic_neighbor2goal = heuristic(neighbor, goal)
            # 当远离目标时增大不转弯成本
            _not_turn_penalty = 0
            if min_heuristic_path2goal == 0:
                continue
            if heuristic_neighbor2goal < min_heuristic_path2goal:
                min_heuristic_path2goal = heuristic_neighbor2goal
            elif heuristic_neighbor2goal / min_heuristic_path2goal > 2:
                _not_turn_penalty = 5

            _road_status = array[neighbor[0]][neighbor[1]]
            # 与其他动线交叉惩罚
            _cross_cost = 0
            if str(_road_status) in color_set:
                cross_set.add(neighbor)
                _cross_cost = cross_cost
            if _is_straight and _road_status == skeleton_reward:
                # 不连续奖励走在骨骼上的路线.
                _road_status = 0.1
            tentative_g_score = gscore[current] + heuristic(current, neighbor) + _road_status + _turn_penalty + _cross_cost  + _not_turn_penalty

            if _road_status > thresh_hold:
                continue
            # if tentative_g_score < gscore.get(neighbor, 0) or neighbor not in set([i[1] for i in oheap]):
            if tentative_g_score < gscore.get(neighbor, 0) or oheap_dict[neighbor] == 0:
                came_from[neighbor] = current
                gscore[neighbor] = tentative_g_score
                fscore[neighbor] = tentative_g_score + heuristic_neighbor2goal
                heappush(oheap, (fscore[neighbor], neighbor))
                oheap_dict[neighbor] += 1
                test_i += 1
    logging.debug('spend iter:{}'.format(test_i))
    return None, None, None, None, is_cross, None, None


def cal_single_moving_line(key_points, floor_map, gray_scale_status):
    """
    计算单个动线的路径
    1. 计算所有pair-distance.
    2. 从最远的距离开始算路径.
    3. 将上次的路径加入终点集合, 如果遇到就直接接上去, 不再继续寻找.
    4. 直到计算完所有的关键点.
    :param key_points:
    :param floor_map: 户型地图
    :param gray_scale_status: 需要加惩罚的颜色
    :return:
    """
    # 关键点
    _key_points = copy.deepcopy(key_points)
    # 地图
    floor_map_cp = copy.deepcopy(floor_map)
    # 组合 所有关键点
    points_len = len(_key_points)
    is_cross = False
    # todo ?
    inter_set = set([])
    if points_len < 2:
        return {x: 0 for x in _key_points}, False, set([])

    init_start = _key_points.pop()
    # 本次动线路径点记录<点坐标: todo ?>
    existed_route_points = {init_start: 0}
    un_visit_points = _key_points - {init_start}

    is_first_find = True
    while un_visit_points:
        tmp_min_d = float('inf')
        goal = None
        start_point = None
        # 未访问的关键点到已走过的路径的最近点对
        for _tmp_point in un_visit_points:
            # 从已有的路径点集中选一个最近的起点
            _d, _goal = sorted([(heuristic(_tmp_point, b) - existed_route_points[b] + floor_map_cp[b], b) for b in
                                existed_route_points], key=lambda x: x[0])[0]
            if tmp_min_d > _d:
                tmp_min_d = _d
                goal = _goal
                start_point = _tmp_point

        un_visit_points.remove(start_point)
        if goal in un_visit_points:
            print('remove goal:{}'.format(goal))
            un_visit_points.remove(goal)

        #
        _min_goal_point = goal
        if not is_first_find:
            # 高效探路
            _min_goal_point, _max_ratio = a_star_test(floor_map_cp, start_point, goal, existed_route_points)
        else:
            is_first_find = False
        if _min_goal_point:
            _data, _corner, _x_pos, _y_pos, _is_cross, _inter_set, _ = a_star(floor_map_cp, start_point,
                                                                              _min_goal_point,
                                                                              existed_route_points,
                                                                              gray_scale_status)
        else:
            logging.info("not find path.")
            continue
        if not _data:
            logging.info("still not find path.")
            continue
        else:
            floor_map_cp[_x_pos, _y_pos] = -1
            is_cross = is_cross or _is_cross
            inter_set.update(_inter_set)
            existed_route_points.update({x: y for x, y in zip(_data, _corner)})
            un_visit_points = un_visit_points - set(existed_route_points.keys())
    return existed_route_points, is_cross, inter_set


def zoom_lines(zoom_ratio, zoom_offset, data):
    """
    将坐标放缩到绘图尺寸
    :param zoom_ratio: 放缩比例
    :param zoom_offset: 整体偏移
    :param data: 需要放缩的坐标数据:
        entrance_point, 入户门中点
        entrance_line, 入户门端点
        full_line_ps, 无门墙体
        seg_lines_norm, 正常门切割墙体
        seg_lines_expand, 收缩门切割墙体
    :return:
    """
    zoom_result = {}
    if "entrance_point" in data:
        zoom_result["entrance_point"] = coor_trans(data["entrance_point"], zoom_ratio, zoom_offset, need_list=False)
        zoom_result["entrance_line"] = coor_trans(data["entrance_line"], zoom_ratio, zoom_offset, need_list=False)

    # 无门时只算一遍
    single_wall = None
    if len(data["seg_lines_norm"]) == 1 and len(data["seg_lines_expand"]) == 1:
        single_wall = coor_trans(data["full_line_ps"], zoom_ratio, zoom_offset)

    all_line_types = ["full_line_ps", "seg_lines_norm", "seg_lines_expand"]
    if single_wall is None:
        for data_type in all_line_types:
            zoom_result[data_type] = coor_trans(data[data_type], zoom_ratio, zoom_offset)
    else:
        for data_type in all_line_types:
            zoom_result[data_type] = copy.deepcopy(single_wall)

    return zoom_result


def vector2bitmap(line_vectors_dict):
    """
    矢量转位图
    :param line_vectors_dict: dict, 矢量线段
    :return: bit_dict, 位图信息
    """
    bit_dict = {}
    all_line_types = ["full_line_ps", "seg_lines_norm", "seg_lines_expand"]
    full_line_ps, seg_lines_norm, seg_lines_expand = itemgetter(*all_line_types)(line_vectors_dict)

    # 无门时只算一遍
    single_wall = None
    if len(seg_lines_norm) == 1 and len(seg_lines_expand) == 1:
        single_wall = draw_line_segments(full_line_ps)

    if single_wall is None:
        for data_type in all_line_types:
            bit_dict[data_type] = draw_line_segments(line_vectors_dict[data_type])
    else:
        for data_type in all_line_types:
            bit_dict[data_type] = copy.deepcopy(single_wall)

    return bit_dict


def line_map(img_size, line_feature_dict):
    """
    墙体图片生成
    :param img_size: 图片方阵尺寸
    :param line_feature_dict: 墙体特征字典
        all_bit_dict, 墙体在位图中的坐标
            full_line_ps, 整面墙体
            seg_lines_norm, 正常门宽切分墙体
            seg_lines_expand, 收缩墙体切分墙体
    :return:
    """
    all_bit_dict = line_feature_dict["all_bit_dict"]

    plan_line_im_shape = np.array([img_size, img_size], dtype='int32')

    map_dict = {}

    map_types = ["full_line_ps", "seg_lines_norm", "seg_lines_expand"]
    for map_type in map_types:
        rows, columns = all_bit_dict[map_type]
        lns = []
        ofs = []
        for ln, of in zip(rows, columns):
            if 0 <= ln < img_size and 0 <= of < img_size:
                lns.append(ln)
                ofs.append(of)

        map_matrix = np.zeros(plan_line_im_shape, dtype=np.float32)
        map_matrix[lns, ofs] = 1
        map_dict[map_type] = map_matrix
        # import matplotlib.pyplot as plt
        # plt.imshow(map_matrix)
        # plt.show()

    return map_dict


def entrance_visual_area(liner):
    """
    入户门-开/关门可视域
    """
    entrance_line = liner.entrance_line
    steps = liner.steps
    areas = liner.plan_vector["areas"]
    print(len(areas))
    point_dict = liner.plan_vector[DATA_DICT][TRANS_POINT_DICT]

    frame_polygon = None
    area_polygons = []
    try:
        for area in areas:
            area_points = area["points"]
            area_points = [[point_dict[pid][0], point_dict[pid][1]] for pid in area_points]
            area_polygon = Polygon(area_points)
            if not area_polygon.is_valid:
                area_polygon = area_polygon.buffer(0)
            area_polygons.append(area_polygon)

        frame_polygon = unary_union(area_polygons)
        if not frame_polygon.is_valid:
            frame_polygon = frame_polygon.buffer(0)
            logging.warning("{}: frame polygon invalid".format(liner.frame_id))
    except Exception:
        logging.error("{}: frame polygon invalid yyyy".format(liner.frame_id))

    # 关闭像素采样，简化采样点为两端点和中点
    e_r, e_c, _ = line_aa(entrance_line[0][0], entrance_line[0][1], entrance_line[1][0], entrance_line[1][1])
    route_points = list(zip(e_r, e_c))
    entrance_m = (int((entrance_line[0][0] + entrance_line[1][0]) / 2), int((entrance_line[0][1] + entrance_line[1][1]) / 2))
    route_points = [(entrance_line[0][0], entrance_line[0][1]), (entrance_line[1][0], entrance_line[1][1]), entrance_m]
    # 画开门可视域
    line_im_open = liner.plan_line_im_open
    area_ratio_o, pts_polygon_o = route_rays(liner, route_points, line_im_open,
                                             liner.line_pts_open, steps)
    trans_ps = {}
    try:
        for k in pts_polygon_o:
            tmp_lst = reverse_coor_trans(pts_polygon_o[k], liner.zoom_ratio, liner.offset)
            if tmp_lst is None:
                logging.error(" {}: None polygon params".format(liner.frame_id))
            varea_polygon = Polygon(tmp_lst)
            if not varea_polygon.is_valid:
                logging.warning("{}: varea polygon invalid".format(liner.frame_id))
                varea_polygon = varea_polygon.buffer(0)
            varea_polygon = varea_polygon.intersection(frame_polygon)
            # 放缩还原的多边形进行交集时会因为误差导致出现多个不连续区域的重叠，选择最大的
            if isinstance(varea_polygon, MultiPolygon):
                max_polygon_area = 0
                real_polygon = None
                for g in varea_polygon.geoms:
                    if g.area > max_polygon_area:
                        max_polygon_area = g.area
                        real_polygon = g
                varea_polygon = real_polygon
            if varea_polygon is None:
                logging.error(" {}: None polygon params end".format(liner.frame_id))
            trans_ps_items = list(varea_polygon.boundary.coords)
            trans_ps[k] = [(t[0] + liner.minx, t[1] + liner.miny) for t in trans_ps_items]
    except Exception:
        logging.error(" {}: None polygon params exp xxxx".format(liner.frame_id))
    pts_polygon_o = trans_ps

    # 画关门可视域
    line_im_close = liner.plan_line_im
    area_ratio_c, pts_polygon_c = route_rays(liner, route_points, line_im_close,
                                             liner.line_pts_close, steps)
    # print("frame:{}, close_visual_area:{}, open_visual_area:{}".format(liner.frame_id, area_ratio_c, area_ratio_o))
    logging.debug("frame:{}, close_visual_area:{}, open_visual_area:{}".format(liner.frame_id, area_ratio_c, area_ratio_o))
    return area_ratio_o, pts_polygon_o, area_ratio_c, pts_polygon_c


def route_rays(liner, route_points, line_im,  line_pts, steps=2):
    len_pts = len(route_points)
    pts_polygon = dict()
    plan_line_im_ray = line_im.copy()
    plan_line_im_ray_mask = plan_line_im_ray + liner.plan_mask_im_reverse
    plan_line_im_ray_mask[plan_line_im_ray_mask > 1.0] = 1.0
    for i in range(0, len_pts, steps):
        tmp_view_pt = route_points[i]
        _final_pts = point_ray_casting(liner, i, tmp_view_pt, line_pts, plan_line_im_ray_mask)
        pts_polygon[tmp_view_pt] = _final_pts
    # 计算户型内的光线点数
    dots_cnt = len(plan_line_im_ray_mask[plan_line_im_ray_mask == RAY_COLOR])
    all_indoor_dots_cnt = len(plan_line_im_ray_mask[plan_line_im_ray_mask < 0.999])
    area_ratio = dots_cnt / all_indoor_dots_cnt
    return area_ratio, pts_polygon


def point_ray_casting(liner, idx, view_point, line_pts, plan_line_im_ray_mask):
    """
    从一点出发的可视域
    :param liner:
    :param idx:
    :param view_point:
    :param rays_pic_path:
    :param line_pts:
    :param plan_line_im_ray_mask:
    :return:
    """
    # 计算交点
    final_pts = cast_rays(view_point, line_pts, liner.img_size)
    rr_area, cc_area = get_area_polygon(final_pts, liner.plan_line_im_shape)
    plan_line_im_ray_mask[rr_area, cc_area] = RAY_COLOR
    if liner.is_draw_v:
        from lib import line_util
        # 重新copy一副单独光线的
        plan_line_im_ray_cp = liner.plan_line_im_open.copy()
        plan_line_im_ray_cp[rr_area, cc_area] = RAY_COLOR
        plan_line_im_ray_cp_mask = plan_line_im_ray_cp + liner.plan_mask_im_reverse
        plan_line_im_ray_cp_mask[plan_line_im_ray_cp_mask > 1.0] = 1.0
        all_path = os.path.join("{frame_id}_{idx}.png".format(frame_id=liner.frame_id, idx=str(idx).zfill(4)))
        line_util.draw_image(plan_line_im_ray_cp_mask, [view_point], all_path)
    return final_pts


def line_maker(liner):
    """
    计算动线
    """
    # import matplotlib.pyplot as plt
    # ########### 参数准备 ###########
    line_thickness = liner.line_thickness
    zoom_ratio = liner.zoom_ratio
    thin_door_width = liner.thin_door_width
    _radius = max(4, int(thin_door_width * zoom_ratio))
    _offset = liner.offset
    # 基本特征
    _frame_id = liner.frame_id
    entrance_point = liner.entrance_pt
    # ########### 动线数据 整理 ###########
    dilate_radius = int(0.99 * liner.line_thickness * liner.zoom_ratio)
    # 腐蚀线宽 创建惩罚区域
    plan_line_im_h = liner.plan_line_im_h

    dilated_plan_line_coor = morphology.binary_dilation(plan_line_im_h, morphology.square(dilate_radius))
    dilated_plan_line_im = copy.deepcopy(plan_line_im_h)
    dilated_plan_line_im[dilated_plan_line_coor] = 0.95

    # 户外禁止区域遮罩
    plan_mask_im_reverse = liner.plan_mask_im_reverse
    # 骨骼图模板
    combined_plan_line_im_sk = plan_line_im_h + plan_mask_im_reverse
    # 恢复门 让骨骼先延申
    entrance_rr_fill, entrance_cc_fill = circle(entrance_point[0], entrance_point[1], _radius)
    combined_plan_line_im_sk[entrance_rr_fill, entrance_cc_fill] = 0

    skeleton_coor = draw_skeleton(combined_plan_line_im_sk)
    skeleton_im = np.zeros(liner.plan_line_im_shape, dtype=np.float32)
    skeleton_im[skeleton_coor] = 1.0
    dilated_skeleton_im = morphology.binary_dilation(skeleton_im,
                                                     morphology.square(int(0.6 * line_thickness * zoom_ratio)))
    # 画路径栅格
    dilated_plan_line_im += plan_mask_im_reverse

    # 给予骨架路径奖励
    skeleton_reward = 10.0
    skeleton_side_reward = 0.5
    dilated_plan_line_im[dilated_skeleton_im > 0.99] -= skeleton_side_reward
    dilated_plan_line_im[skeleton_coor] = -skeleton_reward
    # 补上实线, 防止走出户型.
    combined_plan_line_im = dilated_plan_line_im + plan_line_im_h
    # plt.imshow(combined_plan_line_im)
    # plt.show()

    # ########### 动线计算 ###########
    ret_dict = dict()
    # 访客动线
    guest_gray_scale_status = {'color_set': set(),
                               'skeleton_reward': -skeleton_reward}
    guest_route_array, guest_points, guest_line_im, _, _ = cal_guest_line(liner.guest_line_points_dict,
                                                                          combined_plan_line_im, GUEST_COLOR,
                                                                          guest_gray_scale_status, skeleton_coor)
    # 居住动线-基于访客线
    living_gray_scale_status = {'color_set': {str(GUEST_COLOR)},
                                'skeleton_reward': -skeleton_reward}
    living_route_array, living_points, living_line_im, \
        living_is_cross_guest, _ = cal_living_line(liner.living_line_points_dict, guest_line_im,
                                                   LIVING_COLOR, living_gray_scale_status, skeleton_coor)
    # 家务动线-基于访客线
    # 合并客和居动线结果
    work_gray_scale_status = {'color_set': {str(GUEST_COLOR), str(LIVING_COLOR)},
                              'skeleton_reward': -skeleton_reward}
    work_route_array, work_points, work_line_im, \
        work_is_cross_guest_living, _ = cal_work_line(liner.work_line_points_dict, living_line_im,
                                                      WORK_COLOR, work_gray_scale_status, skeleton_coor)
    # 客线
    guest_route_set = set(guest_route_array)
    ori_guest_line_pairs, ori_guest_points, guest_len = post_process_path_points(guest_route_set, guest_points,
                                                                                 zoom_ratio, _offset, liner.minx, liner.miny)
    guest_route_dict = {'pts': ori_guest_points, 'line': ori_guest_line_pairs}
    ret_dict['guest_lines'] = json.dumps(guest_route_dict)
    ret_dict['guest_len'] = guest_len

    # 居住动线
    living_route_set = set(living_route_array)
    ori_living_line_pairs, ori_living_points, living_len = post_process_path_points(living_route_set,
                                                                                              living_points,
                                                                                              zoom_ratio, _offset, liner.minx, liner.miny)
    living_route_dict = {'pts': ori_living_points, 'line': ori_living_line_pairs}
    ret_dict['living_lines'] = json.dumps(living_route_dict)
    ret_dict['living_len'] = living_len

    # 家务动线
    work_route_set = set(work_route_array)
    ori_work_line_pairs, ori_work_points, work_len = post_process_path_points(work_route_set, work_points, zoom_ratio,
                                                                              _offset, liner.minx, liner.miny)
    work_route_dict = {'pts': ori_work_points, 'line': ori_work_line_pairs}
    ret_dict['work_lines'] = json.dumps(work_route_dict)
    ret_dict['work_len'] = work_len

    # 居住和客线相交
    ret_dict['living_guest_cross'], living_guest_cross_set = post_process_cross((living_route_set, guest_route_set),
                                                                                zoom_ratio, _offset)
    # 家务和客线相交
    ret_dict['work_guest_cross'], work_guest_cross_set = post_process_cross((work_route_set, guest_route_set),
                                                                            zoom_ratio, _offset)
    # 居住和家务相交
    ret_dict['living_work_cross'], living_work_cross_set = post_process_cross((living_route_set, work_route_set),
                                                                              zoom_ratio, _offset)
    logging.debug('frame_id:{}, living_is_cross_guest@{}, '
                  'work_is_cross_living@{}, '
                  'living_is_cross_work@{}...'.format(_frame_id, living_guest_cross_set,
                                                      work_guest_cross_set,
                                                      living_work_cross_set))
    is_draw = liner.is_draw
    if is_draw:
        from lib import line_util
        full_path = liner.line_pic_path.format(frame_id=_frame_id)
        line_util.draw_route([guest_route_array, living_route_array, work_route_array],
                             [guest_points, living_points, work_points],
                             [living_guest_cross_set, work_guest_cross_set, living_work_cross_set],
                             [(0, 0, 1, 0.5), (0, 1, 0, 0.5), (1, 0, 0, 0.5)],
                             plan_line_im_h, full_path)
        logging.debug('save pic file at {}'.format(full_path))
    return ret_dict


def cal_guest_line(detail_dict, combined_plan_line_im, current_color, gray_scale_status, skeleton_coor):
    """
    会客动线 (大门, 客厅, 餐厅, 公卫)
    1. 准备关键点.
    2. 计算路径
    :param detail_dict:
    :param combined_plan_line_im:
    :param current_color:
    :param gray_scale_status: 记录惩罚和奖励的特殊灰度值
    :param skeleton_coor: 骨骼线坐标
    :return:
    """
    # 准备关键点
    tmp_key_points = set(detail_dict['key_points'])
    ke_ting_center = detail_dict['ke_ting_center']
    can_ting_center = detail_dict['can_ting_center']
    if ke_ting_center:
        _ke_ting_center = find_the_closest_point(set(ke_ting_center), skeleton_coor)
        tmp_key_points.update(_ke_ting_center)
    if can_ting_center:
        tmp_key_points.update(can_ting_center)
    existed_route_points, is_cross, inter_set = cal_single_moving_line(tmp_key_points, combined_plan_line_im,
                                                                       gray_scale_status)
    route = []
    if existed_route_points:
        route = list(existed_route_points.keys())
        if route:
            route_array = np.array(route)
            row_coo_arr = route_array[:, 0]
            col_coo_arr = route_array[:, 1]
            combined_plan_line_im[row_coo_arr, col_coo_arr] = current_color
    return route, tmp_key_points, combined_plan_line_im, is_cross, inter_set


def cal_living_line(detail_dict, combined_plan_line_im, current_color, gray_scale_status, skeleton_coor):
    """
    居住动线 (卧室,客厅,卫生间)
    1. 准备关键点.
    2. 计算路径
    :param detail_dict:
    :param combined_plan_line_im:
    :param current_color:
    :param gray_scale_status: 记录惩罚和奖励的特殊灰度值
    :param skeleton_coor: 骨骼线坐标
    :return:
    """
    # 准备关键点
    tmp_key_points = set(detail_dict['key_points'])
    ke_ting_center = detail_dict['ke_ting_center']
    if ke_ting_center:
        tmp_key_points.update(ke_ting_center)
    wei_center = detail_dict['wei_center']
    if wei_center:
        tmp_key_points.update(wei_center)
    _tmp_key_points = find_the_closest_point(tmp_key_points, skeleton_coor)
    existed_route_points, is_cross, inter_set = cal_single_moving_line(_tmp_key_points, combined_plan_line_im,
                                                                       gray_scale_status)
    route = []
    if existed_route_points:
        route = list(existed_route_points.keys())
        if route:
            route_array = np.array(route)
            row_coo_arr = route_array[:, 0]
            col_coo_arr = route_array[:, 1]
            combined_plan_line_im[row_coo_arr, col_coo_arr] = current_color
    return route, _tmp_key_points, combined_plan_line_im, is_cross, inter_set


def cal_work_line(detail_dict, combined_plan_line_im, current_color, gray_scale_status, skeleton_coor):
    """
    家务动线 (餐厅, 客厅, 厨房)
    :param detail_dict:
    :param combined_plan_line_im:
    :param current_color:
    :param gray_scale_status: 记录惩罚和奖励的特殊灰度值
    :param skeleton_coor: 骨骼线坐标
    :return:
    """
    # 准备关键点
    tmp_key_points = set(detail_dict['key_points'])
    can_ting_center = detail_dict.get('can_ting_center')
    chu_center = detail_dict.get('chu_center')
    if chu_center:
        _chu_center = find_the_closest_point(set(chu_center), skeleton_coor)
        tmp_key_points.update(_chu_center)
    if can_ting_center:
        tmp_key_points.update(can_ting_center)
    existed_route_points, is_cross, inter_set = cal_single_moving_line(tmp_key_points, combined_plan_line_im,
                                                                       gray_scale_status)
    route = []
    if existed_route_points:
        route = list(existed_route_points.keys())
        if route:
            route_array = np.array(route)
            row_coo_arr = route_array[:, 0]
            col_coo_arr = route_array[:, 1]
            combined_plan_line_im[row_coo_arr, col_coo_arr] = current_color
    return route, tmp_key_points, combined_plan_line_im, is_cross, inter_set


def cross(p1, p2, p3):
    """
    叉乘
    :param p1:
    :param p2:
    :param p3:
    :return:
    """
    x1 = p2.x - p1.x
    y1 = p2.y - p1.y
    x2 = p3.x - p1.x
    y2 = p3.y - p1.y
    return x1*y2-x2*y1


def _calculate_cross_lines_2(p1, p2, p3, p4):
    """
    The intersection point falls within the first line segment if 0.0 ≤ t ≤ 1.0,
    and it falls within the second line segment if 0.0 ≤ u ≤ 1.0.
    求两条直线直接的交点
    :param p1: 第一条直接的第一个点的坐标 wall
    :param p2: 第一条直接的第二个点的坐标 wall
    :param p3: 第二条直接的第一个点的坐标 ray
    :param p4: 第二条直接的第二个点的坐标 ray
    """
    # 快速排斥，以l1、l2为对角线的矩形必相交，否则两线段不相交
    if (max(p1.x, p2.x) >= min(p3.x, p4.x)  # 矩形1最右端大于矩形2最左端
            and max(p3.x, p4.x) >= min(p1.x, p2.x)  # 矩形2最右端大于矩形最左端
            and max(p1.y, p2.y) >= min(p3.y, p4.y)  # 矩形1最高端大于矩形最低端
            and max(p3.y, p4.y) >= min(p1.y, p2.y)):  # 矩形2最高端大于矩形最低端
        den = (p1.x - p2.x)*(p3.y - p4.y) - (p1.y - p2.y)*(p3.x-p4.x)
        if den == 0:
            return
        t = ((p1.x-p3.x)*(p3.y-p4.y) - (p1.y-p3.y)*(p3.x-p4.x))/den
        u = ((p1.x-p2.x)*(p1.y-p3.y) - (p1.y-p2.y)*(p1.x-p3.x))/-den
        if 0 < t <= 1 and u > 0:
            x = p1.x + t*(p2.x - p1.x)
            y = p1.y + t*(p2.y - p1.y)
            pt = entity.Point(x, y)
            return pt
    return None


def cast_rays(center_pt, line_pts, img_size):
    """
    计算光线投射结果
    :param center_pt: 中心点
    :param line_pts: 所有线段的点对(pairs)
    :param img_size: 画布大小
    :return:
    """

    # 把画布端点加入
    # line_pts.extend([((0, 0), (0, img_size)),
    #                  ((0, img_size), (img_size, img_size)),
    #                  ((img_size, img_size), (img_size, 0)),
    #                  ((img_size, 0), (0, 0))])
    all_dest_pt = set(reduce(lambda x, y: x+y, line_pts))
    ray_0 = entity.Point(*center_pt)
    _close_pt_set = set([])
    _close_pt_dict = collections.defaultdict(set)
    # 像素偏移
    _offset = 1.0
    pts_dict = dict()
    # 给所有角点加上左右偏移
    for _pt in all_dest_pt:
        _angle = mod_util.get_relative_angle(_pt, center_pt)
        pts_dict[_pt] = _angle
        _line_pt_0 = mod_util.get_rotate_coor(-_offset, 240, _pt, center_pt)
        pts_dict[_line_pt_0] = _angle - _offset
        _line_pt_1 = mod_util.get_rotate_coor(_offset, 240, _pt, center_pt)
        pts_dict[_line_pt_1] = _angle + _offset
    inter_to_line_dict = dict()
    for _dest_p in pts_dict.keys():
        ray_1 = entity.Point(*_dest_p)
        tmp_inter_pts = []
        for _line_pt in line_pts:
            # 检测
            dest_0 = entity.Point(*_line_pt[0])
            dest_1 = entity.Point(*_line_pt[1])
            _pt = _calculate_cross_lines_2(dest_0, dest_1, ray_0, ray_1)
            if _pt and _pt != ray_0:
                inter_to_line_dict[_pt] = _line_pt
                tmp_inter_pts.append(_pt)
        if tmp_inter_pts:
            _close_pts = sorted([(tmp_pt, heuristic_square(tmp_pt, ray_0)) for tmp_pt in tmp_inter_pts], key=lambda x: x[1])
            _close_pt = _close_pts[0][0]
            _close_pt_angle = mod_util.get_relative_angle(_close_pt, ray_0, precision=5)
            _close_pt_set.add((_close_pt, _close_pt_angle))
            _close_pt_dict[_close_pt_angle].add(_close_pt)
            if len(_close_pt_dict[_close_pt_angle]) > 1:
                _tmp_arr = _close_pt_dict[_close_pt_angle]
    final_pts = sorted(_close_pt_dict.items(), key=lambda x: x[0])
    ret_pts = list(final_pts[0][1])
    prev_pt = ret_pts[0]
    for _angle, pts_arr in final_pts[1:]:
        prev_line = inter_to_line_dict.get(prev_pt, None)
        if len(pts_arr) > 1:
            # 修正同角度的点次序: 是否在同一条线上-> 最近点
            sorted_pts_arr = sorted([(tmp_pt, -int(inter_to_line_dict.get(tmp_pt, None) == prev_line),
                                      heuristic_square(tmp_pt, prev_pt))
                                     for tmp_pt in pts_arr], key=lambda x: (x[1], x[2]))
            sorted_pts = [x for x, _, __ in sorted_pts_arr]
        else:
            sorted_pts = list(pts_arr)
        ret_pts.extend(sorted_pts)
        prev_pt = ret_pts[-1]
    final_ret = [x.get_tuple() for x in ret_pts]
    return final_ret
