#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2018 www.ke.com, Inc. All Rights Reserved
"""
计算原改-公共方法
Authors: liyulong008@ke.com
Date:    2019/1/08
"""
from __future__ import division

import os
import math
import collections
import numpy as np
import warnings
import functools
import shutil


def deprecated(func):
    """This is a decorator which can be used to mark functions
    as deprecated. It will result in a warning being emitted
    when the function is used."""
    @functools.wraps(func)
    def new_func(*args, **kwargs):
        warnings.simplefilter('always', DeprecationWarning)  # turn off filter
        warnings.warn("Call to deprecated function {}.".format(func.__name__),
                      category=DeprecationWarning,
                      stacklevel=2)
        warnings.simplefilter('default', DeprecationWarning)  # reset filter
        return func(*args, **kwargs)
    return new_func


class ErrorCode(object):
    """
    无法提取特征的错误码
    """
    ok = 0
    json_unquote = -1
    json_invalid = -2
    plan_cnt = -3
    lack_data = -4
    area_analysis = -5
    point_iter = -6
    empty_points = -7
    cannot_rotate = -8
    area_info_empty = -9
    area_point_err = -10
    item_start_err = -11
    merge_line_err = -12
    get_cycle_radius_err = -13
    plan_cnt_exceeded = -14  # 超过两层楼
    missing_entrance = -15
    border_err = -16
    lack_entrance = -17
    area_center_error = -18
    entrance_exceeded = -19 # 入户门超过一个


class GroupState(object):
    """
    分组表记录状态
    """
    deleted = -1
    unchanged = 0
    new = 1
    modified = 2
    refresh = 100


class ReptState(object):
    """
    组代表状态
    """
    default = -1
    not_rept = 0
    is_rept = 1


class VRCode(object):
    """
    组代表状态
    """
    default = -1
    not_vr = 0
    is_vr = 1


class ValidCode(object):
    """
    记录有效状态码
    """
    default = '-1'
    invalid = '0'
    valid = '1'


class ItemType(object):
    """
    墙体附件类型
    """
    # 门类型
    door_type = 'D'
    door_type_set = set(['0', '1', '2', '3'])

    # 电梯门
    elev_door_type = 'E'
    elev_door_type_set = set(['4'])

    # 窗
    window_type = 'W'
    window_type_set = set(['5', '6', '7', '8', '9', '10', '11', '12', '17', '18'])

    # 阳台
    balcony_type = 'B'
    balcony_type_set = set(['13', '14', '15'])

    # 垭口
    pass_type = 'P'
    pass_type_set = set(['16'])

    type_dict = collections.defaultdict(list)
    type_dict.update({'0': door_type, '1': door_type, '2': door_type, '3': door_type,
                     '4': elev_door_type, '5': window_type, '6': window_type, '7': window_type, '8': window_type,
                      '9': window_type, '10': window_type, '11': window_type, '12': window_type,
                      '16': pass_type, '17': window_type, '18': window_type})


class ThresholdCode(object):
    """
    户型比较的错误代码
    """
    # 楼层-数量
    plan_len_diff = 10000.
    # 入户门朝向
    door_direction_diff = 20000.

    # 主要分间朝向-数量
    rooms_direction_len_diff = 30000.
    # 主要分间朝向
    rooms_direction_diff = 35000.

    # 建筑面积-数量
    rooms_size_len_diff = 40000.
    # 建筑面积
    rooms_size_diff = 45000.
    # 户型周长
    rooms_len_diff = 46000.
    # 户型附件数量
    rooms_windows_diff = 47000.
    # 反户型
    rooms_reversed = 48000.

    # Hu矩-数量
    hu_arr_len_diff = 50000.
    # Hu矩
    hu_arr_diff = 55000.

    # 墙体-数组数量
    lines_floor_len_diff = 60000.
    # 墙体-数量
    lines_len_diff = 60000.
    # 墙体
    lines_diff = 65000.

    # 未找到近邻的线
    lines_dist_diff = 66000.

    # 附件数量不一致
    lines_items_len_diff = 67000.

    # 附件类型不一致
    lines_items_type_diff = 68000.

    # 附件位置不一致
    lines_items_pos_diff = 69000.

    # 附件类型不一致
    lines_items_type_diff = 69100.

    # 附件长度不一致
    lines_items_len_diff = 69200.

    # 附件墙体朝向不一致
    lines_items_angle_diff = 69300.

    # 户型附件数量不一致
    lines_items_cnt_diff = 69400.

    # 一个闭合另外一个没闭合
    closed_diff = 70000.

    # 未找到最近角点
    corner_min_dist_diff = 71000.

    # 墙体长度
    line_size_diff = 72000.


def get_direction(angle):
    """
    将角度转换成方向
    :param angle:
    :return:
    """
    if angle is not None:
        angle %= 360
        if angle >= 330 or angle <= 30:
            return u'north'
        elif 30 < angle < 60:
            return u'north-east'
        elif 60 <= angle <= 120:
            return u'east'
        elif 120 < angle < 150:
            return u'south-east'
        elif 150 <= angle <= 210:
            return u'south'
        elif 210 < angle < 240:
            return u'south-west'
        elif 240 <= angle <= 300:
            return u'west'
        elif 300 < angle < 330:
            return u'north-west'
        return ''
    else:
        return angle


def quadratic(a, b, c):
    """
    解二元一次方程
    :param a:
    :param b:
    :param c:
    :return:
    """
    p = b*b - 4*a*c
    if abs(p-0.0) <= 1.0e-3:
        p = abs(p)
    if p >= 0 and a != 0:
        x1 = (-b+math.sqrt(p))/(2*a)
        x2 = (-b-math.sqrt(p))/(2*a)
        return x1, x2
    elif a == 0:
        x1 = -c/b
        return x1, x1
    else:
        raise Exception('quadratic math error, a: {}, b: {}, c: {}'.format(a, b, c))


def get_cycle_radius_co(p):
    """
    获取圆形坐标
    :param p:(起点坐标, 结束坐标), 弧高
    :return:x,y,弧长
    """
    p1 = p[0]
    p2 = p[1]
    h_not_positive = (p[2] <= 0.0)
    h = abs(p[2])
    # 圆半径
    half_p = ((p1[0] + p2[0])/2, (p1[1] + p2[1])/2)
    half_d = math.sqrt((p1[0]-half_p[0])**2+(p1[1]-half_p[1])**2)
    r = (half_d**2 + h**2)/(2*h)
    k = 0
    # abs(a - b) < 1 用于解决精度问题导致的a == b 不进入条件问题
    if abs(p1[0]-half_p[0]) >= 1:
        if abs(p1[1]-half_p[1]) < 1:
            c_x = half_p[0]
            if h_not_positive:
                c_y = half_p[1] + (r-h)
            else:
                c_y = half_p[1] - (r-h)
            return c_x, c_y, r
        ori_k = (p1[1]-half_p[1])/(p1[0]-half_p[0])
        k = -1/ori_k
    b_offset = half_p[1]-k*half_p[0]
    # 圆心坐标
    d_h = r-h
    a = 1+k**2
    b = 2*(k*b_offset-half_p[0]-k*half_p[1])
    c = half_p[0]**2 + half_p[1]**2 + b_offset*b_offset - 2*b_offset*half_p[1] - d_h*d_h
    center_candidate = quadratic(a, b, c)

    c_x_min = min(center_candidate)
    c_x_max = max(center_candidate)
    c_y_min = k*c_x_min + b_offset
    c_y_max = k*c_x_max + b_offset

    if abs(p1[0] - p2[0]) < 1:
        if h_not_positive:
            c_x = c_x_max
            c_y = c_y_max
        else:
            c_x = c_x_min
            c_y = c_y_min

    else:
        slope_ori = (p1[1] - p2[1])/(p1[0] - p2[0])
        if slope_ori > 0:
            if h_not_positive:
                c_x = c_x_min
                c_y = c_y_min
            else:
                c_x = c_x_max
                c_y = c_y_max
        elif slope_ori < 0:
            if h_not_positive:
                c_x = c_x_max
                c_y = c_y_max
            else:
                c_x = c_x_min
                c_y = c_y_min
        else:
            if h_not_positive:
                if c_y_min > c_y_max:
                    c_y = c_y_min
                    c_x = c_x_min
                else:
                    c_y = c_y_max
                    c_x = c_x_max
            else:
                if c_y_min < c_y_max:
                    c_y = c_y_min
                    c_x = c_x_min
                else:
                    c_y = c_y_max
                    c_x = c_x_max
    return c_x, c_y, r


def get_cycle_radius(p, sample_cnt=8):
    """
    获取圆弧上采样的点
    :param p: (起点坐标, 结束坐标), 弧高
    :param sample_cnt: 采样数目
    :return:
    """
    p1 = p[0]
    p2 = p[1]
    c_x, c_y, r = get_cycle_radius_co(p)
    # 角度
    angle_1 = math.atan2(p1[1] - c_y, p1[0] - c_x) / math.pi * 180
    angle_2 = math.atan2(p2[1] - c_y, p2[0] - c_x) / math.pi * 180
    v_1 = np.array([c_x - p1[0], c_y - p1[1]])
    v_2 = np.array([c_x - p2[0], c_y - p2[1]])
    angle_dist = cos_dist(v_1, v_2)
    # 分隔点数
    if p[2] > 0:
        start_angle = angle_1
        end_angle = angle_2
    else:
        start_angle = angle_2
        end_angle = angle_1
    if start_angle < end_angle:
        start_angle += 360
    ret_array = []
    x_s = []
    y_s = []
    for _a in np.arange(start_angle, end_angle, -angle_dist / sample_cnt):
        _x = c_x + r * math.cos(_a * math.pi / 180)
        _y = c_y + r * math.sin(_a * math.pi / 180)
        ret_array.append((_x, _y))
        x_s.append(_x)
        y_s.append(_y)
    arc_len = 2*r*angle_dist * math.pi / 360
    return x_s, y_s, arc_len


def format_invalid_feature(error_no, float_cnt=10, string_cnt=1):
    """
    特征提取失败的户型返回数据格式化
    :param error_no: float, 错误码
    :param float_cnt: int, float 类型字段数量
    :param string_cnt: int, string 类型字段数量
    :return:
    """
    return [error_no] * float_cnt + [""] * string_cnt


def square_dist(p1, p2):
    return (p1[0]-p2[0])**2 + (p1[1]-p2[1])**2


def cos_dist(v_1, v_2):
    tmp_norm = v_1.dot(v_2) / (np.linalg.norm(v_1) * np.linalg.norm(v_2))
    if abs(tmp_norm) > 1:
        tmp_norm = np.sign(tmp_norm)*1.0
    return math.acos(tmp_norm)/math.pi * 180.0


def euclidean_dist(p1, p2):
    return math.sqrt(square_dist(p1, p2))


def segments(poly):
    """A sequence of (x,y) numeric coordinates pairs """
    return zip(poly, poly[1:] + [poly[0]])


def check_clockwise(poly):
    """
    检测点序列是否为顺时针-鞋带公式
    :param poly: 顺序点序列
    :return: 是否是顺时针
    """
    clockwise = False
    if (sum(p0[0]*p1[1] - p0[1]*p1[0] for (p0, p1) in segments(poly))) < 0:
        clockwise = not clockwise
    return clockwise


def hex2rgb(hex_str):
    h = hex_str.lstrip('#')
    rgb = tuple(int(h[i:i+2], 16) for i in (0, 2, 4))
    return rgb


def hu_dist(hu_1_arr, hu_2_arr):
    """
    hu矩
    :param hu_1_arr:
    :param hu_2_arr:
    :return:
    """
    return sum([abs(hu_1 - hu_2) for hu_1, hu_2 in zip(hu_1_arr, hu_2_arr)])


def read_ans(ans_path):
    """
    读取答案文件 csv
    :param ans_path:
    :return:
    """
    ret_arr_set = []
    ret_arr = []
    all_existed_set = set([])
    with open(ans_path, 'r') as f:
        for line in f:
            line_striped = line.strip()
            line_arr = line_striped.split('\t')
            ret_arr_set.append(set(line_arr))
            ret_arr.append(line_arr)
            all_existed_set.update(line_arr)
    return ret_arr, ret_arr_set, all_existed_set


def get_relative_angle(end_f_p, f_p, precision=3):
    """
    获取两个点相对于定位点和x轴正向夹角(相反的)
    :param end_f_p:
    :param f_p:
    :return:
    """
    x_diff = end_f_p[0] - f_p[0]
    y_diff = end_f_p[1] - f_p[1]
    oblique_diff = math.sqrt(x_diff * x_diff + y_diff * y_diff)
    if oblique_diff == 0:
        diff_angle = 0
    else:
        if y_diff < 0:
            diff_angle = 360 - math.acos(x_diff / oblique_diff) * 180 / math.pi
        else:
            diff_angle = math.acos(x_diff / oblique_diff) * 180 / math.pi
    return round(diff_angle, precision)


def get_rotate_coor(rotate_offset, scale_len, enb_f_p, origin_f_p):
    """
    根据旋转角度求新坐标
    :return:
    """
    x_diff = enb_f_p[0] - origin_f_p[0]
    y_diff = enb_f_p[1] - origin_f_p[1]
    oblique_diff = math.sqrt(x_diff * x_diff + y_diff * y_diff)
    if oblique_diff == 0:
        return origin_f_p
    else:
        if y_diff < 0:
            diff_angle = 360 - math.acos(x_diff / oblique_diff) * 180 / math.pi
        else:
            diff_angle = math.acos(x_diff / oblique_diff) * 180 / math.pi
        # 求弧度
        new_offset = rotate_offset/oblique_diff
        diff_angle_new = (diff_angle + (new_offset*180.0 / math.pi + 360.0)) % 360.0
        new_dx = (oblique_diff + scale_len)*math.cos(math.pi*diff_angle_new/180.0)
        new_dy = (oblique_diff + scale_len)*math.sin(math.pi*diff_angle_new/180.0)
        return origin_f_p[0] + new_dx, origin_f_p[1] + new_dy


def arr_to_str(arr, precision=0):
    """
    双层数字数组变成字符串
    :param arr:
    :param precision:
    :return:
    """
    tmp_str_arr = []
    for _arr in arr:
        tmp_str_arr.append('-'.join([str('{0:.'+str(precision)+'f}').format(i) for i in _arr]))
    return '_'.join(tmp_str_arr)


def arr_to_str_2(arr, precision=0):
    """
    双层数字数组变成字符串
    :param arr:
    :param precision:
    :return:
    """
    tmp_str_arr = []
    for _arr in arr:
        tmp_str_arr.append('|'.join([str('{0:.'+str(precision)+'f}').format(i) for i in _arr]))
    return '_'.join(tmp_str_arr)


def str_to_arr(arr_str, func=float):
    """
    字符串变成双层数组
    :param arr_str:
    :param func:
    :return:
    """
    if not arr_str:
        return [[]]
    tmp_str_arr = arr_str.split('_')
    ret_arr = []
    for _arr_str in tmp_str_arr:
        tmp_arr = [func(i) for i in _arr_str.split('-')]
        ret_arr.append(tmp_arr)
    return ret_arr


def copy_frame(src_folder, dst_folder, is_mkdir=True):
    """
    复制文件
    :param src_folder:
    :param dst_folder:
    :param is_mkdir:
    :return:
    """
    if not os.path.isfile(src_folder):
        print("%s not exist!" %src_folder)
    else:
        fpath, fname = os.path.split(dst_folder)  # 分离文件名和路径
        if is_mkdir and not os.path.exists(fpath):
            os.makedirs(fpath)  # 创建路径
        shutil.copyfile(src_folder, dst_folder)  # 复制文件
