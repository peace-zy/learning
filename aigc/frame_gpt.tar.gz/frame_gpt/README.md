# FrameGPT: AIGC for 户型


#### 文本生语音安装依赖：bash living_space/voice_production/voice_bin/install_api.sh
#### 文本生语音调用方式(输入文本返回url)：
#### from living_space.voice_production.inference import text2voice
#### res = text2voice('试试能不能把文本转语音接口部署到工程里面')
