#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2018 www.ke.com, Inc. All Rights Reserved
"""
户型解析——基础特征
Authors: yudonghai@ke.com
Date:    2019/06/27
"""
from __future__ import division
import logging
import yaml
import sys
import traceback

import json

from lib import entity
from lib import spark_util
from lib import eval_main
from lib import label_functions
from lib import code_enum as ce
from lib.file_util import get_file_stream


def frame_analysis_base(row, debug=False, **params):
    """
    :param row: str/Row/dict, 户型数据
            (str格式时各个字段用逗号分隔，且需要跟Frame类内各字段顺序一致)
    :param debug: boolean, 调试模式，返回户型对象
    :param params: dict, 参数
    :return:
    """
    frame = entity.Frame(row)
    
    try:
        # 标签
        frame.add_label(label_functions.label_base, **params)
        # 检测点
        eval_main.base_explain(frame, **params)
        result_vector = frame.base_feature()
        base_point_value_dict = frame.explain_message.get(ce.EXPLAIN_POINT_VALUE_DICT, {})
        base_vars_dict = frame.explain_message.get(ce.EXPLAIN_VARS, {})

        point_value_str = json.dumps(base_point_value_dict, encoding="utf-8")
        vars_str = json.dumps(base_vars_dict, encoding="utf-8")
        result_vector.extend([frame.frame_label, point_value_str, vars_str])
        result = [str(x) for x in result_vector]
    except Exception as e:
        traceback.print_exc()
        logging.error("{} get base explain feature exception!!".format(frame.frame_id))
        frame._state = ce.State.unknown_exception
        result_vector = frame.base_feature()
        result_vector.extend([0, '', ''])
        result = [str(x) for x in result_vector]
    if debug:
        return frame, result
    return result


def logic_func(driver, raw_df, **params):
    """
     spark 逻辑处理
    :param driver: spark_util.SparkSqlDriver, spark 执行类
    :param raw_df: pyspark.sql.dataframe.DataFrame， sql 查询结果
    :param params: dict, 参数字典
    :return: result_df, 处理后的 DataFrame
    """
    result_rdd = raw_df.rdd.map(lambda row: frame_analysis_base(row, **params))
    result_df = driver.rdd_2_df(result_rdd)
    names = params["table_names"]
    result_df = result_df.toDF(*names)
    return result_df


def main():
    """ 主函数 """
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    if len(sys.argv) < 3:
        logging.error("no less than 2 arguments!")
        sys.exit()

    pt_date = sys.argv[1]
    config_file = sys.argv[2]

    f = get_file_stream(config_file)
    conf = yaml.load(f)

    # with open(config_file, "r") as config_data:
    #     conf = yaml.load(config_data)

    # 从配置文件读取参数
    spark_config_key = "frame_eval_base_feature_config"
    spark_params = conf.get(spark_config_key, None)
    if spark_params is None:
        logging.error("lack {} in config file".format(spark_config_key))
        sys.exit(-1)

    # ## 补充参数
    # pt
    spark_params["sql_params"]["pt_date"] = pt_date
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_function"] = logic_func
    # 存储pt
    spark_params["save_params"]["partition_params"] = {"pt": "{}000000".format(pt_date)}

    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()


if __name__ == "__main__":

    logging.basicConfig(level=logging.WARN, format='%(asctime)s %(levelname)s %(message)s')

    main()
