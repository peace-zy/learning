# hdfs 上部署的python环境
HDFS_PYTHON_PATH="hdfs://ns-fed/user/strategy/yudonghai/python.tgz#python"
# 本地python命令, 21.21上的配置
PYTHON_CMD="/home/work/zhucheng011/python/python27/bin/python2"
source bin/utils.sh

function newhousev2_frame_compare_v2() {
    pt_date=$1
    hot_pt_date=$(get_nearst_pt ai_content.ai_content_new_house_similarity_ma)

    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.pyspark.driver.python=${PYTHON_CMD}\
    frame_eval/frame_compare/newhouse_spark_main_v2.py -hot_pt_date ${hot_pt_date}
#    frame_eval/frame_compare/newhouse_spark_main_v2.py "$pt_date" frame_eval/frame_compare/newhouse_frame_compare_v2.yml
}

function usage {
    echo "usage:"
    echo "bash frame_miner.sh <job_name> [job_params...]"
    echo "  <job_name>:"
    echo "      newhouse_v2"
    echo "  [job_params...]:"
    echo "      params for job if necessary"
    exit 1
}

function main
{
    if [[ $# -lt 1 ]] ; then
        echo "error! lack <job_name>"
        usage
    fi
    job_name=$1
    echo "TASK: ${job_name}  "

    zip -q -r ./lib.zip ./lib ./frame_remould ./frame_eval ./frame_score

    case ${job_name} in
        newhousev2_frame_compare_v2 )
        pt_date=$2
        newhousev2_frame_compare_v2 "$pt_date"
        ;;
        * )
        echo "error! invalid <job_name>"
        usage
        ;;

    esac
}

main $*