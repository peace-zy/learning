WITH frame_tab AS (
		SELECT f_explain.frame_id, tab_price.project_name, city_code, floor_area, tab_price.price
			, shi, ting, chu, wei, resblock_name
		FROM (
			SELECT frame_id
			FROM data_mining.data_mining_frame_newhouse_v2_da
			WHERE pt = '{pt_date}000000'
				AND error = ''
		) f_explain
			JOIN (
				SELECT frame_id, frame_info.project_name, city_code, floor_area
					, avg_price * floor_area AS price, room_cnt AS shi, parlor_cnt AS ting
					, kitchen_cnt AS chu, toilet_cnt AS wei, resblock_name
				FROM (
					SELECT frame_id, project_name, city_code, floor_area, room_cnt
						, parlor_cnt, kitchen_cnt, toilet_cnt, resblock_name
					FROM rpt.rpt_nh_build_resblock_frame_info_da
					WHERE pt = '{pt_date}000000'
						AND property_type IN (107500000002, 107500000003, 107500000004)
						AND frame_process_status = 120240002
				) frame_info
					LEFT JOIN (
						SELECT project_name, avg_price
						FROM rpt.rpt_nh_build_resblock_base_info_da
						WHERE pt = '{pt_date}000000'
					) resblock_base
					ON frame_info.project_name = resblock_base.project_name
			) tab_price
			ON f_explain.frame_id = tab_price.frame_id
	)
SELECT frame_id, frame_info_tab.project_name, resblock_name, city_code, floor_area
	, price, shi, ting, chu, wei
	, longitude, latitude, district_id, district_name
FROM (
	SELECT *
	FROM frame_tab
) frame_info_tab
	JOIN (
		SELECT project_name, longitude, latitude, district_id, district_name
		FROM rpt.rpt_nh_build_resblock_base_info_da
		WHERE pt = '{pt_date}000000'
	) res_pos_tab
	ON frame_info_tab.project_name = res_pos_tab.project_name