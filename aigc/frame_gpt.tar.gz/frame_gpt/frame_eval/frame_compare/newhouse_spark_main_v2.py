# -*- coding:utf-8 -*-
# 新房户型对比二期
import copy
import json
import yaml
import logging
import sys
import os
import pandas as pd
import numpy as np
import argparse
import datetime
from math import radians, cos, sin, asin, sqrt

reload(sys)
sys.setdefaultencoding("utf8")

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../"))
sys.path.insert(0, os.getcwd())

current_pt_date = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y%m%d")

parser = argparse.ArgumentParser(description='')
parser.add_argument("-env", default="online", help=" online or debug")
parser.add_argument("-pt_date", default=current_pt_date, help="")
parser.add_argument("-hot_pt_date", default=20210911)
# parser.add_argument("-hot_pt_date", required=True)
parser.add_argument("-config_file", default="frame_eval/frame_compare/newhouse_frame_compare_v2.yml", help="")

args = parser.parse_args()
if args.env == "debug":
    # spark 路径必须在import spark之前配置
    with open(r'./config/spark_debug.yml') as f:
        conf = yaml.load(f)
    spark_name = conf['local_spark_path']  # 注意spark路径
    sys.path.insert(0, os.path.join(spark_name, 'python'))
    sys.path.insert(0, os.path.join(spark_name, 'python/lib/py4j-0.10.4-src.zip'))

from lib import  spark_util_v2
from lib.file_util import get_file_stream


def get_same_project_similar_frame(frame_info_df, **params):
    """本楼盘相似户型"""
    proj_group = frame_info_df.rdd.groupBy(lambda row: row['project_name'])
    column_names = frame_info_df.schema.names
    def get_result(proj_name, proj_group, column_names):
        df = spark_util_v2.spark_group2pandas_df(proj_group, column_names)
        res = get_similar_frame(df)
        for r in res:
            r.append(0)
            r.append(params['params']['reason'][0])
        return res

    rdd_frame_proj = proj_group.flatMap(lambda row: get_result(row[0], row[1], column_names))
    names = params["table_names"]
    result_df = rdd_frame_proj.toDF(names)
    return result_df


def get_same_district_similar_frame(frame_info_df, **params):
    """同区域相似户型"""
    district_group = frame_info_df.rdd.groupBy(lambda row: (row['district_id'], row['district_name']))
    column_names = frame_info_df.schema.names
    def get_result(district_id_name, district_group, column_names):
        df = spark_util_v2.spark_group2pandas_df(district_group, column_names)
        res = get_similar_frame(df, run_mode=1)
        for r in res:
            r.append(1)
            r.append(params['params']['reason'][1].format(district_name=district_id_name[1]))
        return res
    rdd_frame_proj = district_group.flatMap(lambda row: get_result(row[0], row[1], column_names))
    names = params["table_names"]
    result_df = rdd_frame_proj.toDF(names)
    return result_df


def get_hot_project_similar_frame(spark_driver, frame_info_df, hot_project_df, **params):
    """热门楼盘相似户型"""
    # 热门楼盘户型表
    hot_frame_df = frame_info_df.\
        join(hot_project_df, frame_info_df.project_name == hot_project_df.project_name1).\
        drop(hot_project_df.city_code)
    # city_hot_frame_df = hot_frame_df.filter(hot_frame_df['city_code'] == city_code)
    hot_frame_pddf = hot_frame_df.toPandas()

    def get_result(frame_row, hot_frame_pddf):
        # 注意map函数中不能有spark数据格式
        res = get_similar_frame2(frame_row, hot_frame_pddf)
        for r in res:
            r.append(2)
            r.append(params['params']['reason'][2])
        return res

    rdd_frame_proj = frame_info_df.rdd.flatMap(lambda row: get_result(row, hot_frame_pddf))
    # result_df = spark_driver.rdd_2_df(rdd_frame_proj)
    names = params["table_names"]
    result_df = rdd_frame_proj.toDF(names)
    return result_df


def get_similar_frame2(row, hot_frame_df):
    """
    热盘相似户型
    :param row: 户型信息一行数据
    :param hot_frame_df: 热盘户型表
    :return:
    """
    city_code = long(row['city_code'])
    df0 = hot_frame_df[hot_frame_df['city_code'] == city_code]
    frame_id = long(row['frame_id'])
    shi, ting, wei = row['shi'], row['ting'], row['wei']
    price = float(row['price']) + 1  # 防止0值
    df0 = df0[df0['district_id'] != row['district_id']] # 排除同区域
    df0 = df0[(df0['shi'] == shi) & (df0['ting'] == ting)]
    df0 = df0[np.abs(df0['wei'] - wei) <= 1]
    delta_price = np.abs(df0['price'].astype(float) - price) / price
    df0['price_diff'] = delta_price
    df0 = df0[df0['price_diff'] < 0.2]
    df0 = calc_dis(float(row['longitude']), float(row['latitude']), df0)

    res = []
    for idx, row1 in df0.iterrows():
        res.append([frame_id, row['project_name'], row['resblock_name'],
                   row1['frame_id'], row1['project_name'], row1['resblock_name'],
                   row1['city_code'], row1['dis'], row1['price_diff']])

    return res


def get_similar_frame(df, run_mode=0):
    """
    根据户型相似条件，得到相似户型
    :param df: 楼盘、区域户型表
    :param run_mode: 0, 同楼盘；1，同区域
    :return:
    """
    res = []
    _df = df.drop_duplicates(subset=['frame_id'])
    for idx, row in _df.iterrows():
        frame_id = row['frame_id']
        shi, ting, wei = row['shi'], row['ting'], row['wei']
        price = float(row['price']) + 1 # 防止0值
        df0 = copy.deepcopy(_df)
        if run_mode == 1:
            # 排除同小区
            df0 = df0[df0['project_name'] != row['project_name']]
        elif run_mode == 2:
            # 排除同小区
            df0 = df0[df0['project_name'] != row['project_name']]
            df0 = df0[df0['district_id'] != row['district_id']]

        # df0 = df0.drop(labels=idx)
        df0 = df0[df0['frame_id'] != frame_id]
        df0 = df0[(df0['shi'] == shi) & (df0['ting'] == ting) ]
        df0 = df0[np.abs(df0['wei'] - wei) <= 1]
        delta_price = np.abs(df0['price'].astype(float) - price) / price
        df0['price_diff'] = delta_price
        df0 = df0[df0['price_diff'] < 0.2]

        df0 = calc_dis(row['longitude'], row['latitude'], df0)
        for idx1, row1 in df0.iterrows():
            res.append([frame_id, row['project_name'], row['resblock_name'],
                        row1['frame_id'], row1['project_name'], row1['resblock_name'],
                        row['city_code'], row1['dis'], row1['price_diff']])
    return res


def calc_dis(lng, lat, df):
    """通过经纬度，计算距离"""
    lng_r = np.radians(float(lng))
    lat_r = np.radians(float(lat))
    lngs_r = np.radians(df['longitude'].astype(float))
    lats_r = np.radians(df['latitude'].astype(float))
    dlon = lngs_r - lng_r
    dlat = lats_r - lat_r
    a = np.sin(dlat / 2) ** 2 + np.cos(lat_r) * np.cos(lats_r) * np.sin(dlon / 2) ** 2
    distance = 2 * np.arcsin(np.sqrt(a)) * 6371 * 1000  # 地球平均半径，6371km
    distance = np.round(distance / 1000, 3)
    df['dis'] = distance
    return df


def calc_dis_old(lng1,lat1,lng2,lat2):
    lng1, lat1, lng2, lat2 = map(radians, [float(lng1), float(lat1), float(lng2), float(lat2)])  # 经纬度转换成弧度
    dlon = lng2 - lng1
    dlat = lat2 - lat1
    a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
    distance = 2 * asin(sqrt(a)) * 6371 * 1000  # 地球平均半径，6371km
    distance = round(distance / 1000, 3)
    return distance


class FrameCompareV2(spark_util_v2.SparkLogic):
    def logic_func(self, spark_driver, raw_df_dict, **params):
        frame_info_df = spark_driver.raw_df_dict['frame_info'].cache()
        hot_project_df = spark_driver.raw_df_dict['hot_project'].cache()
        same_proj_df = get_same_project_similar_frame(frame_info_df, **params)
        same_distr_df = get_same_district_similar_frame(frame_info_df, **params)
        sim_hot_pro_df = get_hot_project_similar_frame(spark_driver, frame_info_df, hot_project_df, **params)

        res = same_proj_df.union(same_distr_df)
        res = res.union(sim_hot_pro_df)

        save_dict = {
            "frame_compare_v2_table": res
        }
        return save_dict


def main(pt_date, hot_pt_date, config_file, debug=False):
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')

    # pt_date = sys.argv[1]
    # config_file = sys.argv[2]

    f = get_file_stream(config_file)
    conf = yaml.load(f)

    spark_config_key = "newhouse_frame_compare_v2"
    spark_params = conf.get(spark_config_key, None)

    spark_params["sql_params"]["sql_vars"] = {
        "pt_date": pt_date,
        "hot_pt_date": hot_pt_date,
    }
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_class"] = FrameCompareV2
    # 存储pt
    for save_name in spark_params["save_params"]:
        spark_params["save_params"][save_name]["partition_params"] = {
            "pt": "{}000000".format(pt_date)
        }

    spark_driver = spark_util_v2.SparkSqlDriver(debug=debug, **spark_params)
    spark_driver.run()
    return spark_driver


def test():
    row = {'chu': 0,
     'city_code': u'210100',
     'city_name': u'\u6c88\u9633\u5e02',
     'district_id': 23008745,
     'district_name': u'\u4e8e\u6d2a',
     'floor_area': '95.00',
     'frame_id': u'3120049904408148',
     'latitude': '41.765693',
     'longitude': '123.301154',
     'price': '1187500.0000',
     'project_name': u'blhdgybjusd',
     'project_name1': u'blhdgybjusd',
     'resblock_name': u'\u4fdd\u5229\u6d77\u5fb7\u516c\u56ed',
     'shi': 3,
     'ting': 2,
     'wei': 1}
    with open(r'frame_eval/frame_compare/newhouse_frame_compare_v2.yml') as f:
        conf = yaml.load(f)
    hot_frame = pd.read_csv(r'D:\hot_frame.csv')
    # res = get_similar_frame(hot_frame)
    res = get_similar_frame2(row, hot_frame)
    for r in res:
        tmp = 0
        r.append(0)
        r.append(conf['params']['reason'][0])
    return None


if __name__ == "__main__":
    # test()

    if args.env == "debug":
        spark_driver = main(args.pt_date, args.hot_pt_date, args.config_file, debug=True)
    else:
        main(args.pt_date, args.hot_pt_date, args.config_file)