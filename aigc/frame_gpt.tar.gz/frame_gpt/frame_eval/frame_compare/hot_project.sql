SELECT DISTINCT project_name1, city_code, city_name
FROM ai_content.ai_content_new_house_similarity_ma
WHERE pt = '{hot_pt_date}000000'