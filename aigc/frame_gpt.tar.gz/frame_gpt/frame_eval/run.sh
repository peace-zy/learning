# hdfs 上部署的python环境
HDFS_PYTHON_PATH="hdfs://ns-fed/user/strategy/yudonghai/python.tgz#python"
# 本地python命令, 21.21上的配置
PYTHON_CMD="/home/work/zhucheng011/python/python27/bin/python2"

function upload_vector() {
  # 上传矢量值到s3(增量日更子任务)
  if [ ! -f "./lib/hadoop-aws-2.7.0.jar" ];then
    wget https://repo1.maven.org/maven2/org/apache/hadoop/hadoop-aws/2.7.0/hadoop-aws-2.7.0.jar -P ./lib
  fi

  if [ ! -f "./lib/aws-java-sdk-1.7.4.jar" ];then
    wget https://repo1.maven.org/maven2/com/amazonaws/aws-java-sdk/1.7.4/aws-java-sdk-1.7.4.jar -P ./lib
  fi

  pt_date=$1
  spark-submit --py-files lib.zip \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --jars lib/hadoop-aws-2.7.0.jar,lib/aws-java-sdk-1.7.4.jar \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    --conf spark.pyspark.driver.python=${PYTHON_CMD} \
    frame_upload/upload_vector.py "$pt_date" config/upload.yml
}

function frame_eval_line_di(){
    # 户型解读动线和可视域特征增量日更
    pt_date=$1
    # 上传矢量数据到S2(增量)
    upload_vector "$pt_date"

    echo "---------- finish upload_vector."

    spark-submit --py-files lib.zip \
    --conf spark.yarn.executor.memoryOverhead=7G \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    --conf spark.pyspark.driver.python=${PYTHON_CMD} \
    frame_eval/feature_liner_spark_di.py "$pt_date" config/eval_liner_conf.yml
}

function upload_draw_feature_di() {
    # 上传绘图特征到redis(增量日更子任务)
    pt_date=$1
    spark-submit --py-files lib.zip \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.pyspark.driver.python=${PYTHON_CMD} \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_eval/feature_draw_spark_di.py "$pt_date" config/upload.yml
}

function frame_eval_final(){
    # 户型解读二期评分和文案生成全量日更
    pt_date=$1
    # 上传绘图特征
#    upload_draw_feature_di "$pt_date"
#    echo "---------- finish upload_draw_feature_di."
    # 标签生成任务
    # 使用自行打包的python环境，有集成的必需包
    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.pyspark.driver.python=${PYTHON_CMD} \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_eval/eval_spark.py "$pt_date" config/eval_conf.yml
}

function frame_decoration(){
    # 户型解读基础特征全量日更
    pt_date=$1

    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=400 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.pyspark.driver.python=${PYTHON_CMD} \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_eval/decoration_spark.py "$pt_date" config/decoration_conf.yml
}

function api_short_update() {
    # 更新户型解读简介api 全量日更
    pt_date=$1
    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=300 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    --conf spark.pyspark.driver.python=${PYTHON_CMD} \
    frame_eval/feature_api_spark.py "$pt_date" 0 config/eval_api.yml
}

function frame_tag_lib_feature {
    # 更新户型标签 增量日更
    pt_date=$1
    city_code=$2
    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=300 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    --conf spark.pyspark.driver.python=${PYTHON_CMD} \
    frame_eval/frame_tag_lib/spark_main_feature.py frame_eval/frame_tag_lib/conf.yml "$pt_date" "$city_code"
}

function main
{
    if [[ $# -lt 1 ]] ; then
        echo "error! lack <job_name>"
        usage
    fi
    job_name=$1
    echo "TASK: ${job_name}  "

    zip -q -r ./lib.zip ./*

    case ${job_name} in
        frame_eval_line_di )
        pt_data=$2
        frame_eval_line_di "$pt_data"
        ;;

        frame_eval_final )
        pt_date=$2
        frame_eval_final ${pt_date}
        ;;

        frame_decoration )
        pt_date=$2
        frame_decoration ${pt_date}
        ;;

        api_short_update )
        pt_date=$2
        api_short_update ${pt_date}
        ;;

        frame_tag_lib_feature )
        pt_date=$2
        city_code=$3
        frame_tag_lib_feature ${pt_date} ${city_code}
        ;;

        * )

        echo "error! invalid <job_name>"
        usage
        ;;

    esac
}

main $*