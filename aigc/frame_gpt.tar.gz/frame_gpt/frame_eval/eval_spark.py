#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2018 www.ke.com, Inc. All Rights Reserved
"""
主入口
Authors: yudonghai@ke.com
Date:    2019/08/19
"""
from __future__ import division
import logging
import yaml
import sys

import json

from lib import spark_util
from lib import code_enum as ce
from lib import eval_score
from lib import entity
from lib.file_util import get_file_stream


def legend_check(row, vars_dict):
    """
    图例检出
    :param row: sql 记录
    :param vars_dict: 基础特征变量字典
    :return:
    """
    legend_dict = {}

    # 动线图例
    line_types = ["guest_lines", "living_lines", "work_lines"]
    for line_type in line_types:
        vector_str = getattr(row, line_type)
        legend_flag = False
        if vector_str is not None and vector_str != "":
            vector = json.loads(vector_str)
            lines_len = len(vector.get("line", []))
            if lines_len > 0:
                legend_flag = True
        legend_dict[line_type] = legend_flag
    wd_vectors = vars_dict.get("wd_vectors", [])
    quiet_areas = vars_dict.get("quiet_areas", [])
    moving_areas = vars_dict.get("moving_areas", [])
    width_depth_flag = False
    quiet_flag = False
    moving_flag = False
    if len(wd_vectors) > 0:
        width_depth_flag = True
    if len(quiet_areas) > 0:
        quiet_flag = True
    if len(moving_areas) > 0:
        moving_flag = True

    legend_dict.update({"width": width_depth_flag,
                        "depth": width_depth_flag,
                        "quiet_areas": quiet_flag,
                        "moving_areas": moving_flag})
    return legend_dict


def frame_eval(row, **params):
    """
    :param row:
    :param params: dict, 参数
    :return:
    """
    score_config = params.get("score_config", None)
    if score_config is None:
        logging.error("lack score_config in conf file!")
        sys.exit(-1)

    state = row.state if not isinstance(row, entity.Frame) else row.state.value
    img_dict = {}
    for img_type in ["moving_lines", "visual_areas", "face_vectors", "wd_vectors", "movement_areas", "main_img"]:
        img_dict[img_type] = row[img_type] if not isinstance(row, entity.Frame) else 'xxx'
        if img_dict[img_type] is None or img_dict[img_type] == '':
            state = ce.State.img_lack.value
            break
    head_info = [
        row.frame_id,
        row.city_code,
        state,
        row.room,
        row.parlour,
        row.kitchen,
        row.toilet,
        row.frame_size,
        row.frame_label
    ]
    if state != ce.State.valid.value:
        result = head_info + [''] * 11
        result = [str(x) for x in result]
        return result

    base_point_value = "{}" if (row.eval_base_text is None or row.eval_base_text == '') else row.eval_base_text
    liner_info = "{}" if (row.eval_liner_text is None or row.eval_liner_text == '') else row.eval_liner_text
    base_vars = "{}" if (row.message_text is None or row.message_text == '') else row.message_text

    base_point_value_dict = json.loads(base_point_value, encoding="utf-8")
    liner_info_dict = json.loads(liner_info, encoding="utf-8")
    liner_point_value_dict = liner_info_dict.get(ce.EXPLAIN_POINT_VALUE_DICT, {})

    point_value_dict = base_point_value_dict
    for d in liner_point_value_dict:
        if d in point_value_dict:
            point_value_dict[d].update(liner_point_value_dict[d])
        else:
            point_value_dict[d] = liner_point_value_dict[d]

    base_var_dict = json.loads(base_vars, encoding="utf-8")
    base_var_dict["frame_id"] = row.frame_id
    vars_dict = base_var_dict
    vars_dict.update(liner_info_dict.get(ce.EXPLAIN_VARS, {}))

    # 打分
    score_result, add_vars_dict = eval_score.score_collect(row, point_value_dict, **score_config)
    if "all" not in score_result or score_result["all"] is None:
        head_info[2] = ce.State.score_fail.value
        result = head_info + [''] * 11
        result = [str(x) for x in result]
        return result
    vars_dict.update(add_vars_dict)
    vars_dict.update({"doc_img": img_dict})
    score_result["label"] = row.frame_label

    # 补丁 户型方正标签改为二期分数判断
    # 补丁 南北通透标签改为二期分数判断
    label_factory = entity.Label()
    square_score_lst = score_result.get("check_point", {}).get("C", {}).get("0", None)
    global_face_score_lst = score_result.get("check_point", {}).get("D", {}).get("1", None)

    add_label = 0
    label_values = [label_factory[ce.LABEL_SQUARE], label_factory[ce.LABEL_NORTH_SOUTH_TRANS]]
    for label_value, score_lst, th in zip(label_values, [square_score_lst, global_face_score_lst], [params["square_th"], params["n_s_trans_th"]]):
        conditions = []
        if score_lst is not None:
            real_score = score_lst[0]
            if not isinstance(real_score, list):
                real_score = [real_score]
            for s in real_score:
                if s >= th:
                    conditions.append(True)
                else:
                    conditions.append(False)
        if len(conditions) > 0 and all(conditions):
            add_label |= label_value

    pre_label = int(row.frame_label)
    for check_label in label_values:
        if (pre_label & check_label) > 0:
            pre_label -= check_label
    new_label = pre_label | add_label
    head_info[-1] = new_label

    # 补丁 图例信息
    legend_dict = legend_check(row, vars_dict)
    vars_dict["legends"] = legend_dict
    # 文案
    docs = eval_score.doc_formatter(score_result, vars_dict, row.frame_label, **params)

    body = [
        score_result["all"],
        score_result["A"],
        score_result["B"],
        score_result["C"],
        score_result["D"],
        score_result["E"],
        json.dumps(docs, encoding="utf-8"),
        json.dumps(score_result, encoding="utf-8"),
        json.dumps(vars_dict, encoding="utf-8"),
        row.plan_cnt,
        row.image_id
    ]

    result = head_info + body
    result = [str(x) for x in result]
    return result


def logic_func(driver, raw_df, **params):
    """
     spark 逻辑处理
    :param driver: spark_util.SparkSqlDriver, spark 执行类
    :param raw_df: pyspark.sql.dataframe.DataFrame， sql 查询结果
    :param params: dict, 参数字典
    :return: result_df, 处理后的 DataFrame
    """
    result_rdd = raw_df.rdd.map(lambda row: frame_eval(row, **params))
    result_df = driver.rdd_2_df(result_rdd)
    names = params["table_names"]
    result_df = result_df.toDF(*names)
    return result_df


def main():
    """ 主函数 """
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    if len(sys.argv) < 3:
        logging.error("no less than 2 arguments!")
        sys.exit()

    pt_date = sys.argv[1]
    config_file = sys.argv[2]

    f = get_file_stream(config_file)
    conf = yaml.load(f)
    # with open(config_file, "r") as config_data:
    #     conf = yaml.load(config_data)

    # 从配置文件读取参数
    spark_config_key = "frame_eval_config"
    spark_params = conf.get(spark_config_key, None)
    if spark_params is None:
        logging.error("lack {} in config file".format(spark_config_key))
        sys.exit(1)

    # ## 补充参数
    # pt
    spark_params["sql_params"]["pt_date"] = pt_date
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_function"] = logic_func
    # 存储pt
    spark_params["save_params"]["partition_params"] = {"pt": "{}000000".format(pt_date)}

    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()


if __name__ == "__main__":

    logging.basicConfig(level=logging.WARN, format='%(asctime)s %(levelname)s %(message)s')

    main()
