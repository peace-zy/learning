# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/4/18 14:27
# ===================================
from __future__ import division
import copy
import math
import traceback

import boto3
import json
import requests
from PIL import Image
from io import BytesIO
import pandas as pd

from collections import defaultdict

from frame_eval.room_label.entity import Frame
from frame_eval.room_label.room_contour_lib import extract_frame_feature
from frame_eval.room_label.main_room_feature import frame_prepare, area_wall, single_general
from shapely.geometry import Polygon, MultiPolygon, Point


def get_s3_client():
    S3_AK = "223HG43LGIX9W3MWTOCL"
    S3_AKS = "tqWXh8kSyxM/QfgF34dMXFJcRrIIGfIIZkVVjSMH"
    s3_client = boto3.client('s3', region_name="cn-north-1", endpoint_url="http://storage.lianjia.com",
                             aws_access_key_id=S3_AK,
                             aws_secret_access_key=S3_AKS)
    return s3_client


def get_frame_vector(frame_id):
    frame_id = str(frame_id)
    s3_client = get_s3_client()
    vector_response = s3_client.get_object(Bucket='frame-eval-image', Key=str(frame_id) + '.json')
    frame_json = vector_response['Body'].read().decode('utf-8')
    return frame_json


class RoomCombine(object):

    def __init__(self, frame_id='No', frame_json='No', **kwargs):
        """
        组合分间类，可以使用户型id或户型矢量初始化，并通过分间id或分间名称获取对应的分间对象
        :param frame_id:
        :param frame_json:
        :param kwargs:
        """
        frame_id = str(frame_id)
        if frame_id == 'No' and frame_json == 'No':
            raise KeyError('Missing parameter called frame_id or frame_json')
        if frame_id != 'No' and frame_json == 'No':
            frame_json = get_frame_vector(frame_id)
        self.frame_id = frame_id

        self.frame_json = frame_json
        self.frame_dict = json.loads(self.frame_json)
        self.room_id_set = set([area['id'] for area in self.frame_dict['floorplans'][0]['areas']])
        self.room_name_set = set([area['roomName'] for area in self.frame_dict['floorplans'][0]['areas']])

    @property
    def pt_id_dict(self):
        # 存储了顶点标号与顶点坐标之间的映射关系
        id_dict = dict()
        for point in self.frame_dict['floorplans'][0]['points']:
            id_dict[point['id']] = [point['x'], point['y']]
        return id_dict

    @property
    def frame_info_total(self):
        info_dict = {
            'points': {point['id']: point for point in self.frame_dict['floorplans'][0]['points']},
            'lines': {line['id']: line for line in self.frame_dict['floorplans'][0]['lines']},
            'areas': {area['id']: area for area in self.frame_dict['floorplans'][0]['areas']},
            'lineItems': {lineItem['id']: lineItem for lineItem in self.frame_dict['floorplans'][0]['lineItems']},
            'items': {item['id']: item for item in self.frame_dict['floorplans'][0]['items']},
        }
        return info_dict

    @property
    def name_area_id_dict(self):
        """
        分间名称：分间id字典
        """
        res = {area['roomName']: area['id'] for area in self.frame_dict['floorplans'][0]['areas']}
        return res

    def get_empty_frame_json(self):
        frame_dict = copy.deepcopy(self.frame_dict)
        frame_dict['floorplans'][0]['points'] = []
        frame_dict['floorplans'][0]['lines'] = []
        frame_dict['floorplans'][0]['areas'] = []
        frame_dict['floorplans'][0]['lineItems'] = []
        frame_dict['floorplans'][0]['items'] = []
        return json.dumps(frame_dict)

    def show(self, hide_compass=False, show=True, save_path=None, url='http://10.200.40.29:8898/print-polygon'):
        payload = {
            'source': self.frame_json,
            "pngSize": '1440x1080',
            'hideCompass': hide_compass,
        }
        try:
            res = requests.post(url, data=payload)
            img_bytes = res.content
            img = Image.open(BytesIO(img_bytes))
        except Exception as e:
            raise Exception('Draw image error')
        if show:
            img.show()
        if save_path:
            img.save(save_path)
        return img_bytes

    def get_id_object(self, area_id):
        empty_json = self.get_empty_frame_json()
        res_dict = json.loads(empty_json)
        if area_id not in self.room_id_set:
            return RoomCombine(frame_json=self.get_empty_frame_json())
        area = self.frame_info_total['areas'][area_id]
        res_dict['floorplans'][0]['areas'].append(copy.deepcopy(area))

        for point_id in area['points']:
            res_dict['floorplans'][0]['points'].append(copy.deepcopy(self.frame_info_total['points'][point_id]))
        attach_lines = area['attachments']['lines']
        attach_lineItems = area['attachments']['lineItems']
        for line in attach_lines:
            res_dict['floorplans'][0]['lines'].append(copy.deepcopy(self.frame_info_total['lines'][line['id']]))
        for lineItem in attach_lineItems:
            res_dict['floorplans'][0]['lineItems'].append(
                copy.deepcopy(self.frame_info_total['lineItems'][lineItem['id']]))
        res_json = json.dumps(res_dict)
        return RoomCombine(frame_id=self.frame_id, frame_json=res_json)

    def get_name_object(self, roomName):
        if roomName not in self.name_area_id_dict:
            print("该户型没有名为{}的分间".format(roomName))
            return None
        area_id = self.name_area_id_dict[roomName]
        return self.get_id_object(area_id)

    def get_outer_pt_list(self):
        """
        :return: 返回带顺序的户型外点坐标，顺时针或逆时针不一定
        """
        edge_list = list()
        pt_coord_list = list()
        # 存储户型的外墙
        edge_cnt_dict = defaultdict(lambda: 0)
        for area_id, area in self.frame_info_total['areas'].items():
            for line in area['attachments']['lines']:
                edge_cnt_dict[line['id']] = edge_cnt_dict[line['id']] + 1
        for line_id in edge_cnt_dict:
            if edge_cnt_dict[line_id] == 1 and line_id in self.frame_info_total['lines']:
                edge_list.append(copy.deepcopy(self.frame_info_total['lines'][line_id]))

        # 存储墙体id和墙体端点的映射关系、墙体端点与相连接的墙体id映射关系
        line_pt_dict = defaultdict(list)
        pt_line_dict = defaultdict(list)
        for line in edge_list:
            line_pt_dict[line['id']].append(line['points'][0])
            line_pt_dict[line['id']].append(line['points'][1])
            pt_line_dict[line['points'][0]].append(line['id'])
            pt_line_dict[line['points'][1]].append(line['id'])
        # 以外墙列表第一个墙体的第一个端点为起始点
        start_pt = edge_list[0]['points'][0]
        pt_coord_list.append(self.pt_id_dict[start_pt])
        now_line = pt_line_dict[start_pt][0]
        now_pt = line_pt_dict[now_line][1] if start_pt == line_pt_dict[now_line][0] else line_pt_dict[now_line][0]
        while now_pt != start_pt:
            pt_coord_list.append(self.pt_id_dict[now_pt])
            now_line = pt_line_dict[now_pt][1] if now_line == pt_line_dict[now_pt][0] else pt_line_dict[now_pt][0]
            now_pt = line_pt_dict[now_line][1] if now_pt == line_pt_dict[now_line][0] else line_pt_dict[now_line][0]

        pt_coord_list_final = list()
        _n = len(pt_coord_list)
        for index in range(len(pt_coord_list)):
            pt = pt_coord_list[index]
            pt_pre = pt_coord_list[((index - 1) + _n) % _n]
            pt_hou = pt_coord_list[(index + 1) % _n]
            vec1 = (pt[0] - pt_pre[0], pt[1] - pt_pre[1])
            vec2 = (pt_hou[0] - pt[0], pt_hou[1] - pt[1])
            if abs(vec1[0]*vec2[1] - vec1[1]*vec2[0]) < 1e-3:
                continue
            pt_coord_list_final.append(pt_coord_list[index])
        return pt_coord_list_final

    def get_min_max(self):
        result = [1000000, 0, 1000000, 0]
        for point_id, point in self.frame_info_total['points'].items():
            result[0] = min(result[0], point['x'])
            result[1] = max(result[1], point['x'])
            result[2] = min(result[2], point['y'])
            result[3] = max(result[3], point['y'])
        return result

    def plot(self):
        """
        用matplotlib绘制当前组合分间外轮廓
        """
        pt_list = self.get_outer_pt_list()
        pt_list.append(pt_list[0])
        import matplotlib.pyplot as plt
        plt.plot([p[0] for p in pt_list], [p[1] for p in pt_list], 'o')
        n = len(pt_list)
        for index in range(n):
            if index == n-1:
                continue
            plt.plot([pt_list[index][0], pt_list[index + 1][0]], [pt_list[index][1], pt_list[index + 1][1]], 'b')
        plt.show()


def std_length(length):
    if length > 15:
        return length / 1000
    return length


def std_area_size(area_size):
    if area_size > 1000:
        return area_size / 1000000
    return area_size


class FrameInfo(object):
    def __init__(self, frame_id='No', frame_json='No', **kwargs):
        frame_id = str(frame_id)
        if frame_id == 'No' and frame_json == 'No':
            raise KeyError('Missing parameter called frame_id or frame_json')
        if frame_id != 'No' and frame_json == 'No':
            frame_json = get_frame_vector(frame_id)
        self.frame_id = frame_id
        self.frame_json = frame_json
        self.frame_dict = json.loads(self.frame_json)
        self.cal_room_type_set = {'100900000001', '100900000002', '100900000004', '100900000003', '100900000005'}
        pass

    @property
    def areaid_name_map(self):
        res = dict()
        for area in self.frame_dict['floorplans'][0]['areas']:
            res[area['id']] = area['roomName']
        return res

    def get_feature_v1(self, column_name='default', **kwargs):
        if column_name == 'default':
            column_name = ['uid', 'room_id', 'frame_id', 'room_vector', 'main_width', 'main_deep', 'area_size',
                           'room_type', 'door_at_side', 'has_side_400_cnt', 'has_side_1300_cnt', 'door_balcony_pos',
                           'has_parallel_balcony', 'has_vertical_balcony', 'balcony_has_800', 'has_side_800_cnt',
                           'toilet_area_size_label', 'door_cnt', 'with_cloakroom', 'has_balcony']
        params = dict()
        params['cal_room_type_set'] = self.cal_room_type_set
        frame_contour_dict = extract_frame_feature(self.frame_id, self.frame_dict, params)

        line = '\t'.join([self.frame_id, self.frame_json])
        frame = Frame(line.encode('utf-8'))
        # frame = Frame(line)

        frame = frame_prepare(frame)
        frame = area_wall(frame)
        frame = single_general(frame)
        explain_room = frame.explain_message['explain_room']

        ret_dict = defaultdict(list)
        for plan_idx in frame_contour_dict:
            frame_contour = frame_contour_dict[plan_idx]
            frame_contour.set_explain_room(explain_room)
            frame_ret_dict = frame_contour.dump()

            main_room_dict_arr = frame_ret_dict['main_room_dict']
            kitchen_dict_arr = frame_ret_dict['kitchen_dict']
            toilet_dict_arr = frame_ret_dict['toilet_dict']
            balcony_dict_arr = frame_ret_dict['balcony_dict']
            parlor_dict_arr = frame_ret_dict['parlor_dict']

            ret_dict['100900000001'].extend(
                [_main_rom_dict['cluster_details'] for _main_rom_dict in main_room_dict_arr])
            ret_dict['100900000003'].extend([_kitchen_dict['cluster_details'] for _kitchen_dict in kitchen_dict_arr])
            ret_dict['100900000004'].extend([_toilet_dict['cluster_details'] for _toilet_dict in toilet_dict_arr])
            ret_dict['100900000005'].extend([_balcony_dict['cluster_details'] for _balcony_dict in balcony_dict_arr])
            ret_dict['100900000002'].extend([_parlor_dict['cluster_details'] for _parlor_dict in parlor_dict_arr])

        final_list = list()
        for room_type in self.cal_room_type_set:
            if room_type not in ret_dict:
                continue
            _current_area_type_list = sorted([(room['area_size'], room_type, room) for room in ret_dict[room_type]], key=lambda x: x[0])
            for index, (_, room_type, room) in enumerate(_current_area_type_list):
                _room_type = int(room_type)
                # _room_id = str(_room_type % 100).zfill(3) + str(_room_id).zfill(3)
                _room_id = 100 + index
                room_dict = {
                    'uid': int(self.frame_id + str(_room_type % 100).zfill(2) + str(index % 100).zfill(2)),
                    # 'room_id': int(_room_id),
                    'room_id': 100 + index,
                    'frame_id': int(self.frame_id),
                    'room_vector': [room['main_width'], room['main_deep'], room['area_size_without_line']],
                    'area_id': room['area_id'],
                    'main_width': std_length(room['main_width']),
                    'main_deep': std_length(room['main_deep']),
                    'area_size': std_area_size(room['area_size_without_line'] if room['area_size_without_line'] > 0.01 else room['area_size']),
                    'room_type': str(_room_type),
                    'door_at_side': room.get('door_at_side', -2),
                    'has_side_400_cnt': room.get('has_side_400_cnt', -2),
                    'has_side_1300_cnt': room.get('has_side_1300_cnt', -2),
                    'door_balcony_pos': room.get('door_balcony_pos', -2),
                    'has_parallel_balcony': room.get('has_parallel_balcony', -2),
                    'has_vertical_balcony': room.get('has_vertical_balcony', -2),
                    'balcony_has_800': room.get('balcony_has_800', -2),
                    'has_side_800_cnt': room.get('has_side_800_cnt', -2),
                    'toilet_area_size_label': room.get('toilet_area_size_label', -2),
                    'door_cnt': room.get('door_cnt', -2),
                    'with_cloakroom': room.get('with_cloakroom', -2),
                    'has_balcony': room.get('has_balcony', -2)
                }
                final_list.append(copy.deepcopy(room_dict))
        return final_list


class ContourPolygon(object):
    def __init__(self, multiPolygon):
        self.multiPolygon = multiPolygon

    def find_largest_inscribed_rectangle(self):
        res_polygon = Polygon([[0, 0],[0, 0],[0, 0]])
        polygon_list = list(self.multiPolygon)
        for _polygon in polygon_list:
            _contour_pts_list = _polygon.exterior.coords
            _n = len(_contour_pts_list) - 1
            for index in range(_n):
                pt1 = _contour_pts_list[index]
                pt2 = _contour_pts_list[(index + 1) % _n]
                pt3 = _contour_pts_list[(index + 2) % _n]
                vec1 = (pt2[0] - pt1[0], pt2[1] - pt1[1])
                vec2 = (pt3[0] - pt2[0], pt3[1] - pt2[1])
                dot = vec1[0]*vec2[0] + vec1[1]*vec2[1]
                if dot > 1e-3:
                    continue
                minx, miny, maxx, maxy = min(pt1[0], pt3[0]), min(pt1[1], pt3[1]), max(pt1[0], pt3[0]), max(pt1[1], pt3[1])
                inscribed_polygon = MultiPolygon([Polygon([[minx, miny], [minx, maxy], [maxx, maxy], [maxx, miny]])])
                sub_polygon = inscribed_polygon.difference(MultiPolygon([_polygon]))
                if sub_polygon.area < 1e-3 and inscribed_polygon.area > res_polygon.area:
                    res_polygon = inscribed_polygon
                else:
                    continue
        return res_polygon

    def __sub__(self, other_polygon):
        return ContourPolygon(MultiPolygon([self.multiPolygon.difference(other_polygon)]))


class LabelGenerator(object):
    def __init__(self, feature):
        self.feature = feature

    def get_bedroom_feature(self):
        width = self.feature['main_width']
        depth = self.feature['main_deep']
        width_sep = [2.7, 3.0, 3.2, 4.1, 10000]
        depth_sep = [2.3, 2.8, 3.1, 3.3, 3.6, 4, 4.5, 5.1, 10000]
        label1 = 0
        label2 = 0
        for index, sep1 in enumerate(width_sep):
            if width < sep1:
                label1 = index
                break
        for index, sep2 in enumerate(depth_sep):
            if depth < sep2:
                label2 = index
                break
        with_cloakroom = self.feature['with_cloakroom']
        res = '|'.join([str(label1), str(label2), str(with_cloakroom)])
        return res

    def get_kitchen_feature(self):
        width = self.feature['main_width']
        depth = self.feature['main_deep']
        width_sep = [1.4, 1.9, 10000]
        depth_sep = [1.3, 2.2, 10000]
        label1 = 0
        label2 = 0
        for index, sep1 in enumerate(width_sep):
            if width < sep1:
                label1 = index
                break
        for index, sep2 in enumerate(depth_sep):
            if depth < sep2:
                label2 = index
                break
        area_size_label = 0
        if 5 < self.feature['area_size'] <= 7:
            area_size_label = 1
        elif 5 < self.feature['area_size'] <= 9:
            area_size_label = 2
        elif self.feature['area_size'] > 9:
            area_size_label = 3
        res = '|'.join([str(self.feature['has_balcony']), str(label1), str(label2), str(self.feature['has_side_400_cnt']),
                        str(self.feature['has_side_1300_cnt']), str(self.feature['door_balcony_pos']),
                        str(self.feature['has_parallel_balcony']), str(self.feature['has_vertical_balcony']), str(self.feature['balcony_has_800']),
                        str(area_size_label), str(self.feature['toilet_area_size_label']), str(self.feature['door_cnt'])])
        return res

    def get_toilet_feature(self):
        width = self.feature['main_width']
        depth = self.feature['main_deep']
        width_sep = [0.9, 1.1, 1.4, 1.55, 1.75, 2.35, 3.0, 10000]
        depth_sep = [0.9, 1.1, 1.4, 1.55, 1.75, 2.35, 3.0, 10000]
        label1 = 0
        label2 = 0
        for index, sep1 in enumerate(width_sep):
            if width < sep1:
                label1 = index
                break
        for index, sep2 in enumerate(depth_sep):
            if depth < sep2:
                label2 = index
                break
        door_at_side = str(self.feature['door_at_side'])
        has_side_800_cnt = str(self.feature['has_side_800_cnt'])
        if door_at_side == '0':
            has_side_800_cnt = '-1'
        res = '|'.join([str(label1), str(label2), door_at_side, has_side_800_cnt])
        return res

    def get_balcony_feature(self, **kwargs):
        depth = self.feature['main_deep']
        if depth < 0:
            return -1
        depth_sep = [1, 1.2, 1.4, 1.6, 10000]
        label1 = 0
        for index, sep1 in enumerate(depth_sep):
            if depth < sep1:
                label1 = index
                break

        res = '|'.join([str(label1)])
        return res

    def get_parlor_feature(self, frame_json, area_id):
        label1, label2 = '-1', '-1'

        if self.feature['area_size'] < 15:
            label1 = '0'
        elif 15 < self.feature['area_size'] < 35:
            label1 = '1'
        elif self.feature['area_size'] > 35:
            label1 = '2'
        else:
            label1 = '-1'

        RC = RoomCombine(frame_json=frame_json)
        parlor_object = RC.get_id_object(area_id)
        parlor_contour = parlor_object.get_outer_pt_list()
        # parlor_object.plot()
        CP = ContourPolygon(MultiPolygon([Polygon(parlor_contour)]))
        inscribed_polygon_first = CP.find_largest_inscribed_rectangle()
        CP = CP - inscribed_polygon_first
        if len(CP.multiPolygon.bounds) == 0 or abs(CP.multiPolygon.bounds[0] - CP.multiPolygon.bounds[2]) < 100 or \
                abs(CP.multiPolygon.bounds[1] == CP.multiPolygon.bounds[3]) < 100:
            label2 = '0'
            label_res = '|'.join([label1, label2])
            return label_res

        inscribed_polygon_second = CP.find_largest_inscribed_rectangle()

        std_first_area = std_area_size(inscribed_polygon_first.area)
        std_second_area = std_area_size(inscribed_polygon_second.area)

        if std_first_area < 1:
            label2 = '-1'
        elif std_second_area < 1:
            label2 = '0'
        elif std_first_area * 0.2 > std_second_area:
            label2 = '0'
        else:
            cnt1, cnt2 = 0, 0
            polygon_first_pts = list(inscribed_polygon_first)[0].exterior.coords
            for _index in range(len(polygon_first_pts) - 1):
                _pt = polygon_first_pts[_index]
                _dis = Point(_pt).distance(inscribed_polygon_second)
                if _dis < 200:
                    cnt1 += 1
                pass
            polygon_second_pts = list(inscribed_polygon_second)[0].exterior.coords
            for _index in range(len(polygon_second_pts) - 1):
                _pt = polygon_second_pts[_index]
                _dis = Point(_pt).distance(inscribed_polygon_first)
                if _dis < 200:
                    cnt2 += 1
                pass
            if cnt1 > cnt2:
                cnt1, cnt2 = cnt2, cnt1
            if (cnt1 == 0 and cnt2 == 0) or (cnt1 == 0 and cnt2 == 1):
                label2 = '4'
            elif cnt1 == 0 and cnt2 == 2:
                label2 = '2'
            elif cnt1 == 1 and cnt2 == 1:
                label2 = '3'
            elif cnt1 == 1 and cnt2 == 2:
                label2 = '1'
            elif cnt1 == 2 and cnt2 == 2:
                label2 = '0'
            else:
                label2 = '-1'

        label_res = '|'.join([label1, label2])
        return label_res


def result_duplicate(res_dict):
    for room_type, room_info in res_dict.items():
        room_list = room_info['room_list']
        code_dict = dict()
        for _room in room_list:
            if _room['code'] not in code_dict:
                code_dict[_room['code']] = copy.deepcopy(_room)
            elif _room['room_size'] > code_dict[_room['code']]['room_size']:
                code_dict[_room['code']] = copy.deepcopy(_room)
        room_list_duplicate = list()
        for _, _room in code_dict.items():
            room_list_duplicate.append(copy.deepcopy(_room))
        res_dict[room_type]['room_list'] = room_list_duplicate
    return res_dict


def generate_room_label(row, **kwargs):
    frame_id = str(int(row.frame_id))
    frame_json = row.frame_json
    city_code = row.city_code
    res_dict = defaultdict(dict)
    try:
        frame_info = FrameInfo(frame_id=frame_id, frame_json=frame_json, **kwargs)
        final_list = frame_info.get_feature_v1()
        res_dict['kitchen']['room_type'], res_dict['kitchen']['room_list'] = '厨房', list()
        res_dict['toilet']['room_type'], res_dict['toilet']['room_list'] = '卫生间', list()
        res_dict['bedroom']['room_type'], res_dict['bedroom']['room_list'] = '卧室', list()
        res_dict['balcony']['room_type'], res_dict['balcony']['room_list'] = '阳台', list()
        res_dict['parlor']['room_type'], res_dict['parlor']['room_list'] = '客厅', list()

        for area_feature in final_list:
            if area_feature['area_id'] not in frame_info.areaid_name_map:
                continue
            LG = LabelGenerator(area_feature)
            room_code_dict = dict()
            room_code_dict['room_name'] = frame_info.areaid_name_map[area_feature['area_id']]
            room_code_dict['room_size'] = area_feature['area_size']
            room_code_dict['width'] = area_feature['main_width']
            room_code_dict['depth'] = area_feature['main_deep']

            if area_feature['room_type'] == '100900000001':
                bedroom_label = LG.get_bedroom_feature()
                room_code_dict['code'] = bedroom_label
                res_dict['bedroom']['room_list'].append(room_code_dict)
            elif area_feature['room_type'] == '100900000002':
                parlor_label = LG.get_parlor_feature(row.frame_json, area_feature['area_id'])
                room_code_dict['code'] = parlor_label
                res_dict['parlor']['room_list'].append(room_code_dict)
            elif area_feature['room_type'] == '100900000003':
                kitchen_label = LG.get_kitchen_feature()
                room_code_dict['code'] = kitchen_label
                res_dict['kitchen']['room_list'].append(room_code_dict)
            elif area_feature['room_type'] == '100900000004':
                toilet_label = LG.get_toilet_feature()
                room_code_dict['code'] = toilet_label
                res_dict['toilet']['room_list'].append(room_code_dict)
            elif area_feature['room_type'] == '100900000005':
                balcony_label = LG.get_balcony_feature(area_feature=area_feature)
                room_code_dict['code'] = balcony_label

                frame_dict = json.loads(frame_json)
                door_dict = defaultdict(list)
                roomtype_dict = dict()
                for _area in frame_dict['floorplans'][0]['areas']:
                    roomtype_dict[_area['id']] = _area['roomType']
                    _lineitems = _area['attachments']['lineItems']
                    for _lineitem in _lineitems:
                        if _lineitem['is'] == 'door':
                            door_dict[_lineitem['id']].append(_area['id'])

                what_room = -1
                for _lineitem_id, _area_list in door_dict.items():
                    if len(_area_list) != 2:
                        continue
                    if area_feature['area_id'] == _area_list[0]:
                        what_room = roomtype_dict[_area_list[1]]
                    elif area_feature['area_id'] == _area_list[1]:
                        what_room = roomtype_dict[_area_list[0]]
                    pass

                if what_room == '100900000001':
                    what_room = 0
                elif what_room == '100900000003':
                    what_room = 1
                elif what_room == '100900000002':
                    what_room = 2
                else:
                    what_room = -1
                room_code_dict['code'] = str(what_room) + '|' + room_code_dict['code']

                res_dict['balcony']['room_list'].append(room_code_dict)

        res_dict = result_duplicate(res_dict)
        return [frame_id, json.dumps(res_dict), 1, '', city_code]
    except Exception as e:
        error_str = str(traceback.format_exc())
        res_dict = dict()
        return [frame_id, json.dumps(res_dict), 0, error_str, city_code]


def main():
    # res = generate_room_label(frame_id='11000031559853')
    """
    df = pd.read_csv('frame_eval/room_label/debug.csv', sep='\t')
    for index, row in df.iterrows():
        res = generate_room_label(row)
        print(res[3])
        pass
    """
    frame_id = '11000013451112'
    frame_json = get_frame_vector(frame_id)
    q_list = [[frame_id, frame_json, '110000']]
    df = pd.DataFrame(q_list, columns=['frame_id', 'frame_json', 'city_code'])
    for index, row in df.iterrows():
        res = generate_room_label(row)
        print(res[3])
        pass
    pass


if __name__ == '__main__':
    main()
    pass
