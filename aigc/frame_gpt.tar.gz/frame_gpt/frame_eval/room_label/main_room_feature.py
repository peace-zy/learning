# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/4/18 17:15
# ===================================
import sys
import copy
import logging
import collections

from operator import itemgetter

import lib.geometry_lib as geometry_lib
import lib.code_enum as ce
import lib.comm_lib as comm_lib


def reorder_points(point_locations):
    """
    从左下角开始，逆时针重排序分间的点
    :param point_locations: list, 点坐标列表
    :return: result, list, 重排序后的点坐标列表
    """
    # 排序找到左下角的点
    current_x = sys.float_info.max
    current_y = sys.float_info.max
    restart_index = None
    current_p = None

    p_cnt = len(point_locations)
    for i, p in enumerate(point_locations):
        p_x, p_y = p[ce.X], p[ce.Y]
        p[ce.CKEY_POINT_TYPE] = 0
        # y值小的优先
        if p_y < current_y or (p_y == current_y and p_x < current_x):
            restart_index, current_x, current_y = i, p_x, p_y
            current_p = p

    if restart_index is None:
        logging.error("can not find left_bottom point")
        restart_index = 0

    pre_index = restart_index - 1
    after_index = (restart_index + 1) % p_cnt

    pre_p = point_locations[pre_index]
    after_p = point_locations[after_index]
    # 顺/逆时针判断
    left_flag = geometry_lib.to_left_test([current_p, after_p], [pre_p])[0]

    if left_flag > 0:
        result_lst = [point_locations[restart_index:p_cnt], point_locations[0:restart_index]]
    else:
        result_lst = [point_locations[restart_index::-1], point_locations[p_cnt - 1:restart_index:-1]]

    result = copy.deepcopy(result_lst[0] + result_lst[1])

    return result


def wall_track(area, dict_lst, line_areas_dict, entrance_info):
    """
    墙体分析
    :param area: dict, 分间数据
    :param dict_lst: list, 点、墙体附件、墙体、分间字典
    :param line_areas_dict: dict, 墙体-所属分间 映射字典
    :param entrance_info: list, <入户门角度，入户门所在墙， 入户门朝向向量>
    :return: wall_info,
    list<
        分间点列表<元素为字典，x和y为必备属性，p_type 为点类型，id为点ID，部分点有>,
        斜墙标记<bool, True表示有斜墙>,
        最大连续墙体<float, 单位mm>,
        分间墙列表<墙体ID，起、止点索引，外墙标记，朝向向量，门窗长度，邻接分间>,
        入户门朝向向量
    >
    """

    points_dict, line_items_dict, lines_dict, areas_dict = dict_lst
    area_id, points, room_type, detail_type, size = itemgetter(*ce.IPTTS)(area)

    point_locations = [{ce.POINT_ID_KEY: p_id,
                        ce.X: points_dict[p_id][ce.X],
                        ce.Y: points_dict[p_id][ce.Y]} for p_id in points]
    # 分间外轮廓点
    outline_points = reorder_points(point_locations)
    outline_points_set = set((p[ce.POINT_ID_KEY] for p in outline_points))
    p_cnt = len(outline_points)

    # 入户门信息
    entrance_value, entrance_line, _ = entrance_info
    entrance_line_id = entrance_line[ce.LINE_ID_KEY] if entrance_line is not None else None

    # 重构后的点列表(加入门窗、内墙点等)
    expand_points = []
    # 点列表分段信息记录，按原始点墙体分割
    line_info_lst = []

    # 入户门朝向向量
    entrance_vector = None
    # 斜墙标记
    oblique_flag = False

    for i, p in enumerate(outline_points):
        before_i = i - 1
        after_i = (i + 1) % p_cnt

        before_p = outline_points[before_i]
        after_p = outline_points[after_i]

        before_p_id = before_p[ce.POINT_ID_KEY]
        after_p_id = after_p[ce.POINT_ID_KEY]

        p_id = p[ce.POINT_ID_KEY]
        p_object = points_dict[p_id]

        # 外墙标记
        edge_flag = False
        # 朝外窗总长度
        out_len = 0.

        # 查找当前点和后一点对应的墙体ID
        candidate_lines = p_object[ce.POINT_LINES_KEY]
        current_line_id = None
        for l_id in candidate_lines:
            l_ps = lines_dict[l_id][ce.LINE_POINTS_KEY]
            if after_p_id in l_ps:
                current_line_id = l_id
                break
        if current_line_id is None:
            logging.error("can not find line for: p0:{} and p1:{}".format(p[ce.POINT_ID_KEY], after_p_id))
            return [[], oblique_flag, 0, line_info_lst, entrance_vector]

        # 当前墙体
        current_line = lines_dict[current_line_id]
        # 当前墙体上的墙体附件
        corr_line_items = current_line[ce.LINE_ITEMS_KEY]
        # 当前墙体连接的分间
        conn_areas = [areas_dict[a] for a in line_areas_dict[current_line_id] if a in areas_dict]

        if len(conn_areas) == 1:
            edge_flag = True

        # 凹凸检测
        to_left_flag = geometry_lib.to_left_test([before_p, p], [after_p])[0]
        to_left_flag = to_left_flag if abs(to_left_flag) > ce.CORNER_LINE_AREA else 0
        if to_left_flag > 0:
            p[ce.CKEY_POINT_TYPE] |= ce.PointType.convex
        elif to_left_flag < 0:
            p[ce.CKEY_POINT_TYPE] |= ce.PointType.concave

        # 墙体朝向，选择射线右侧的一条法线最为朝向向量，与 get_normal_line的实现有关
        norm_lines = geometry_lib.get_normal_line([p, after_p])
        if norm_lines is None:
            logging.error("failed to get normal lines in {}".format(area_id))
            return [[], oblique_flag, 0, line_info_lst, entrance_vector]
        face_line = norm_lines[ce.FACE_NORM_LINE_INDEX]

        # 记录入户门朝向向量
        if entrance_line_id == current_line_id:
            if not edge_flag:
                logging.error("entrance not edge!")
            entrance_vector = face_line

        # 直线中间点检验
        cosin_value, same_line_flag = geometry_lib.same_line(before_p, p, after_p)
        mid_type = ce.PointType.in_line if same_line_flag else ce.PointType.corner
        p[ce.CKEY_POINT_TYPE] |= mid_type

        # 斜边夹角检测（两侧边夹角在5-85度之间）
        if ce.COSIN_85 < abs(cosin_value) < ce.COSIN_5:
            p[ce.CKEY_POINT_TYPE] |= ce.PointType.oblique_corner

        # 内墙判断
        inner_nodes = collections.deque()
        inner_nodes.append(p_id)
        inner_nodes_set = set()
        inner_lines = []

        while inner_nodes:
            cur_node_id = inner_nodes.popleft()
            inner_candidate_lines = points_dict[cur_node_id][ce.POINT_LINES_KEY]

            for l_id in inner_candidate_lines:
                line = lines_dict[l_id]
                line_type, line_points, line_line_items = itemgetter(*ce.LTPT)(line)

                # 虚拟墙\栅栏不计
                if line_type in ce.TRANS_WALL_TYPE:
                    continue

                another_p_id = line_points[-1] if line_points[0] == cur_node_id else line_points[0]
                if another_p_id in inner_nodes_set:
                    continue
                if another_p_id not in outline_points_set:
                    inside_flag = comm_lib.point_in_polygon(points_dict[another_p_id], outline_points)
                    if not line_line_items and inside_flag:
                        p[ce.CKEY_POINT_TYPE] |= ce.PointType.divergence
                        inner_nodes.append(another_p_id)
                        inner_nodes_set.add(another_p_id)
                        inner_lines.append([points_dict[cur_node_id], points_dict[another_p_id]])
                # 垭口断墙形成的内墙
                elif another_p_id not in {before_p_id, after_p_id}:
                    for m_item in line_line_items:
                        if line_items_dict[m_item][ce.LINE_ITEM_TYPE_KEY] != ce.YAKOU:
                            continue
                        li_points = comm_lib.get_endpoint(m_item, lines_dict, line_items_dict, points_dict)
                        li_points = [{ce.X: x[0], ce.Y: x[1]} for x in li_points]
                        short_len = geometry_lib.ps_distance(p, li_points[0])
                        long_len = geometry_lib.ps_distance(p, li_points[1])

                        if short_len > long_len:
                            short_len, long_len = long_len, short_len
                            li_points[0], li_points[1] = li_points[1], li_points[0]

                        if comm_lib.point_in_polygon(li_points[0], outline_points):
                            inner_lines.append([points_dict[cur_node_id], li_points[0]])

        # 查找墙体上的附件，并转化为点，作为特殊标记的点计入轮廓中
        # 增加墙体附件的点到轮廓中
        # 当前墙体上的墙体附件信息列表(<距离当前点最近距离，附件长度，附件两点，附件两点类型>)
        line_items_infos = []
        for li in corr_line_items:
            li_points = comm_lib.get_endpoint(li, lines_dict, line_items_dict, points_dict)
            li_points = [{ce.X: x[0], ce.Y: x[1]} for x in li_points]
            short_len = geometry_lib.ps_distance(p, li_points[0])
            long_len = geometry_lib.ps_distance(p, li_points[1])
            item_len = line_items_dict[li][ce.LINE_ITEM_LENGTH_KEY]

            if short_len > long_len:
                short_len, long_len = long_len, short_len
                li_points[0], li_points[1] = li_points[1], li_points[0]
            is_type = line_items_dict[li][ce.TYPE_IS_KEY]
            line_item_type = line_items_dict[li][ce.LINE_ITEM_TYPE_KEY]
            type_flags = []
            if line_items_dict[li][ce.ENTRANCE_KEY] is not None:
                type_flags = [ce.PointType.entrance_start, ce.PointType.entrance_end]
            elif is_type == ce.IS_WINDOW:
                type_flags = [ce.PointType.window_start, ce.PointType.window_end]
                # 窗和其他认为是朝外
                out_len += item_len
            elif is_type == ce.IS_DOOR:
                type_flags = [ce.PointType.door_start, ce.PointType.door_end]
            elif line_item_type in {ce.YAKOU}:
                type_flags = [ce.PointType.door_start, ce.PointType.door_end]

            if type_flags:
                line_items_infos.append([short_len, item_len, li_points, type_flags])

        # 排序，从离当前点最近的一个附件开始
        line_items_infos = sorted(line_items_infos, key=lambda x: x[0])

        expand_start_index = len(expand_points)
        # 先添加当前点
        expand_points.append(p)
        # 再将当前对应点墙体内部关键点加入
        for lii in line_items_infos:
            # 依次加入两个点
            for k in range(2):
                line_inner_p = {ce.POINT_ID_KEY: None, ce.CKEY_POINT_TYPE: lii[3][k]}
                line_inner_p.update(lii[2][k])
                expand_points.append(line_inner_p)
        expand_end_index = len(expand_points)
        real_conn_area_lst = list(set(line_areas_dict[current_line_id]) - {area_id})
        # 墙为朝向墙时直接将门窗总长度置为墙体长度
        if current_line[ce.LINE_TYPE_KEY] in ce.OUT_WALL_TYPE:
            out_len = geometry_lib.ps_distance(p, after_p)
        # 该段墙体在点列表中的 墙体ID，起、止点，外墙标记，朝向向量，门窗长度，邻接分间
        line_info_lst.append([current_line_id, expand_start_index, expand_end_index,
                              edge_flag, face_line, out_len, real_conn_area_lst])

    # 斜墙、最大墙长度检测
    subline_ps = [sub_p for sub_p in expand_points if (sub_p[ce.CKEY_POINT_TYPE] & ce.KEY_POINT_TYPE)]

    max_line = 0
    subline_cnt = len(subline_ps)
    for i in range(len(subline_ps)):
        p1 = subline_ps[i - 1]
        p2 = subline_ps[i]
        current_item_dist = geometry_lib.ps_distance(p1, p2)
        if subline_ps[i][ce.CKEY_POINT_TYPE] & ce.PointType.oblique_corner:
            after_i = (i + 1) % subline_cnt
            p3 = subline_ps[after_i]
            after_item_dist = geometry_lib.ps_distance(p2, p3)
            # 锐角/钝角两侧墙体长度大于一定值时认为有斜墙
            if current_item_dist > ce.OBLIQUE_LEN and after_item_dist > ce.OBLIQUE_LEN:
                oblique_flag = True
        if not ((p1[ce.CKEY_POINT_TYPE] & ce.LINE_ITEM_POINT_TYPE) and (p2[ce.CKEY_POINT_TYPE] & ce.LINE_ITEM_POINT_TYPE)):
            max_line = current_item_dist if current_item_dist > max_line else max_line

    wall_info = [expand_points, oblique_flag, max_line, line_info_lst, entrance_vector]

    return wall_info


def frame_prepare(frame):

    frame_vector = frame.vector

    # 准备墙体-分间映射字典
    explain_line_areas = collections.defaultdict(set)
    entrance_value = None
    entrance_line = None

    # 逐层
    for plan_vector in frame_vector[frame.plan_key]:
        areas = plan_vector[ce.PLAN_AREAS_KEY]
        line_items = plan_vector[ce.PLAN_LINE_ITEMS_KEY]
        lines_dict = plan_vector[ce.LINES_DICT_KEY]

        # 查找入户门
        for line_item in line_items:
            entrance = line_item[ce.ENTRANCE_KEY]
            if entrance is not None:
                entrance_value = entrance
                entrance_line = lines_dict[line_item[ce.LINE_ITEM_LINE_KEY]]
        # 逐分间
        for area in areas:
            area_id = area[ce.AREA_ID_KEY]
            attachments = area[ce.AREA_ATTACHMENTS_KEY]
            attache_lines = attachments[ce.ATTACH_LINES_KEY]
            for line in attache_lines:
                line_id = line[ce.ATTACH_LINE_ID_KEY]
                explain_line_areas[line_id].add(area_id)

    explain_line_areas = {area_id: list(explain_line_areas[area_id]) for area_id in explain_line_areas}

    frame.explain_message[ce.EXPLAIN_LINE_AREAS] = explain_line_areas
    frame.explain_message[ce.EXPLAIN_ENTRANCE] = [entrance_value, entrance_line, None]

    return frame


def area_wall(frame):
    frame_vector = frame.vector
    line_areas_dict = frame.explain_message[ce.EXPLAIN_LINE_AREAS]
    explain_entrance = frame.explain_message[ce.EXPLAIN_ENTRANCE]

    explain_wall = {}
    # 逐层
    for plan_vector in frame_vector[frame.plan_key]:
        areas = plan_vector[ce.PLAN_AREAS_KEY]
        points_dict, line_items_dict, lines_dict, areas_dict = itemgetter(*ce.DICTS)(plan_vector)
        dict_lst = [points_dict, line_items_dict, lines_dict, areas_dict]
        # 逐分间
        for area in areas:
            track_info = wall_track(area, dict_lst, line_areas_dict, explain_entrance)
            _, _, _, _, entrance_vector = track_info
            if entrance_vector is not None:
                frame.explain_message[ce.EXPLAIN_ENTRANCE][2] = entrance_vector
            explain_wall[area[ce.AREA_ID_KEY]] = track_info
    frame.explain_message[ce.EXPLAIN_WALL] = explain_wall
    return frame


def single_general(frame):
    frame_vector = frame.vector

    explain_wall = frame.explain_message[ce.EXPLAIN_WALL]

    explain_room = dict()

    for plan_vector in frame_vector[frame.plan_key]:
        areas = plan_vector[ce.PLAN_AREAS_KEY]
        points_dict, line_items_dict, lines_dict, areas_dict = itemgetter(*ce.DICTS)(plan_vector)

        room_dict = collections.defaultdict(lambda: {
            ce.AREA_LABEL: 0,
            ce.AREA_FACE_EN: float('inf'),
            ce.TOILET_FACE_ROOM: float('inf'),
        })

        # 逐分间
        for area in areas:
            area_id, area_points, room_type, detail_type, area_size = itemgetter(*ce.IPTTS)(area)
            att_line_items, att_lines, _ = itemgetter(*ce.ATTACH_KEYS)(area[ce.AREA_ATTACHMENTS_KEY])

            wall_info = explain_wall[area_id]
            expand_points, oblique_flag, max_line, line_info_lst, entrance_vector = wall_info

            conn_area_room_type_set = set()

            for i, line_info in enumerate(line_info_lst):
                line_id, s_i, e_i, edge_flag, face_line, out_len, real_conn_area_lst = line_info

                if lines_dict[line_id][ce.LINE_TYPE_KEY] in ce.TRANS_WALL_TYPE:
                    door_cnt = 1
                else:
                    door_cnt = sum([1 for k in expand_points[s_i: e_i]
                                    if k[ce.CKEY_POINT_TYPE] & ce.PointType.door_start])
                    items = lines_dict[line_id][ce.LINE_ITEMS_KEY]
                    for item in items:
                        if line_items_dict[item][ce.LINE_ITEM_TYPE_KEY] == ce.YAKOU:
                            door_cnt += 1
                if door_cnt == 0:
                    for conn_area in real_conn_area_lst:
                        if conn_area not in areas_dict:
                            logging.error("lack {} in areas_dict".format(conn_area))
                            continue
                        c_area_id, _, conn_room_type, c_detail_type, _ = itemgetter(*ce.IPTTS)(areas_dict[conn_area])

                else:
                    for conn_area in real_conn_area_lst:
                        if conn_area not in areas_dict:
                            logging.error("lack {} in areas_dict".format(conn_area))
                            continue
                        c_area_id, _, conn_room_type, c_detail_type, _ = itemgetter(*ce.IPTTS)(areas_dict[conn_area])
                        conn_area_room_type_set.add(conn_room_type)

            # 室
            if room_type == ce.AreaType.room.value:
                # 卧室带卫生间
                if ce.AreaType.toilet.value in conn_area_room_type_set:
                    room_dict[area_id][ce.AREA_LABEL] |= ce.RoomLabel.with_toilet
                # 卧室带衣帽/储物间
                if {ce.AreaType.cloakroom.value, ce.AreaType.storage.value}.intersection(conn_area_room_type_set):
                    room_dict[area_id][ce.AREA_LABEL] |= ce.RoomLabel.with_cloakroom
                # 卧室带阳台
                if ce.AreaType.balcony.value in conn_area_room_type_set:
                    room_dict[area_id][ce.AREA_LABEL] |= ce.RoomLabel.with_balcony

        r_dict = {ri: [areas_dict[ri][ce.AREA_ROOM_NAME_KEY], room_dict[ri][ce.AREA_LABEL],
                       room_dict[ri][ce.AREA_FACE_EN], room_dict[ri][ce.TOILET_FACE_ROOM]] for ri in room_dict}

        explain_room.update(r_dict)

    frame.explain_message[ce.EXPLAIN_ROOM] = explain_room
    return frame


if __name__ == '__main__':
    pass
