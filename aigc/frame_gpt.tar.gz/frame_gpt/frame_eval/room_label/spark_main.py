# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/7/13 11:05
# ===================================
import sys
import argparse
import logging
import datetime
import yaml

from lib import spark_util_v2
from lib.file_util import get_file_stream
from frame_eval.room_label.get_feature import generate_room_label


class GenerateRoomLabel(spark_util_v2.SparkLogic):
    def logic_func(self, spark_driver, raw_df_dict, **kwargs):
        frame_info = raw_df_dict['frame_info']
        room_label_rdd = frame_info.rdd.map(lambda row: generate_room_label(row, **kwargs))
        room_label_df = room_label_rdd.toDF(kwargs['params']['final_data_cols'])
        save_dict = {
            "room_label_table": room_label_df
        }
        return save_dict


def main(debug=False, **kwargs):
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    # 今天和昨天的pt
    pt_date = kwargs['pt_data']
    cur_date = datetime.datetime.strptime(pt_date, "%Y%m%d")
    pre_date = cur_date - datetime.timedelta(days=1)
    last_pt_date = pre_date.strftime("%Y%m%d")
    # 读取业务配置文件
    f = get_file_stream(kwargs['config_file'])
    conf = yaml.load(f)
    spark_config_key = "room_label_config_params"
    spark_params = conf.get(spark_config_key, None)

    # sql对应的变量字典，当sql中存在需要替换的变量时可以在该字典中定义
    spark_params["sql_params"]["sql_vars"] = {
        "pt_date": pt_date,
        "city_code": kwargs['city_code'],
    }
    # 逻辑处理类
    spark_params["logic_params"]["logic_class"] = GenerateRoomLabel
    # 存储pt
    for save_name in spark_params["save_params"]:
        spark_params["save_params"][save_name]["partition_params"] = {
            "pt": "{}000000".format(pt_date)
        }
    spark_driver = spark_util_v2.SparkSqlDriver(debug=debug, **spark_params)
    spark_driver.run()
    return spark_driver


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('-pt_date', type=str, default='20220712')
    parser.add_argument('-config_file', type=str, default='')
    parser.add_argument('-city_code', type=str, default='110000')
    args = parser.parse_args()
    if sys.platform not in ["win32", "darwin"]:
        params = {
            'pt_data': args.pt_date,
            'config_file': args.config_file,
            'city_code': args.city_code
        }
        main(**params)
    else:
        pass
    pass
