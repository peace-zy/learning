# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/4/15 11:36
# ===================================
import copy
import math
import logging
import collections

import numpy as np
from functools import reduce
from skimage.draw import polygon
from shapely.geometry import LineString
from skimage.measure import moments, moments_central, moments_normalized, moments_hu

import frame_eval.room_label.room_contour_entity as contour_entity

MAIN_DOOR_ROOM_TYPE_ORDER = {
    1: 0,      # 客厅
    2: 0,      # 餐厅
    25: 0,     # 门厅
    27: 0,     # 玄关
    37: 0,     # 起居室
    23: 1,     # 过道
    0: 1,      # 其他
    3: 1,      # 卧室
    8: 2,      # 厨房
    9: 2,      # 开放厨房
    26: 4,     # 入户花园
    12: 5,     # 阳台
    13: 5,     # 露台
    17: 5,     # 花园
}

DEFAULT_ZOOM_BASE = 200
DEFINED_HU = '100900000099'
HU = (DEFINED_HU,)
BALCONY_TYPE = {'100900000005', '100900000006', '100900000007'}

# 定义主要居室类型
SHI = (u'100900000001', u'100900000009')
SHI_GRAY_SCALE = 1
TING = (u'100900000002',)
TING_GRAY_SCALE = 0.7
CHU = (u'100900000003',)
CHU_GRAY_SCALE = 0.5
WEI = (u'100900000004',)
WEI_GRAY_SCALE = 0.3
YANG = (u'100900000005',)
YANG_GRAY_SCALE = 0.2
# default: 0
GRAY_SCALE_DICT = dict()
GRAY_SCALE_DICT.update({r_: SHI_GRAY_SCALE for r_ in SHI})
GRAY_SCALE_DICT.update({r_: TING_GRAY_SCALE for r_ in TING})
GRAY_SCALE_DICT.update({r_: CHU_GRAY_SCALE for r_ in CHU})
GRAY_SCALE_DICT.update({r_: WEI_GRAY_SCALE for r_ in WEI})
GRAY_SCALE_DICT.update({r_: YANG_GRAY_SCALE for r_ in YANG})

VEC_CENTER_HOLDER = [
    (SHI, SHI), (SHI, TING), (SHI, CHU), (SHI, WEI),
    (TING, TING), (TING, CHU), (TING, WEI),
    (CHU, CHU), (CHU, WEI),
    (WEI, WEI),
    (HU, SHI), (HU, TING), (HU, CHU), (HU, WEI),
    (YANG, SHI), (YANG, TING), (YANG, CHU), (YANG, WEI),
    ]
# 分间面积嵌入向量 占位符
VEC_AREA_HOLDER = (SHI, TING, CHU, WEI, YANG)
# ENTRANCE_TOWARDS
ENTRANCE_TOWARDS = {'default': -1,
                    'north': 1, 'north-east': 2,
                    'east': 3, 'south-east': 4,
                    'south': 5, 'south-west': 6,
                    'west': 7, 'north-west': 8}


def square_dist(p1, p2):
    return (p1[0]-p2[0])**2 + (p1[1]-p2[1])**2


def euclidean_dist(p1, p2):
    return math.sqrt(square_dist(p1, p2))


def cos_dist(v_1, v_2):
    tmp_norm = v_1.dot(v_2) / (np.linalg.norm(v_1) * np.linalg.norm(v_2))
    if abs(tmp_norm) > 1:
        tmp_norm = np.sign(tmp_norm)*1.0
    return np.degrees(math.acos(tmp_norm))


def quadratic(a, b, c):
    """
    解二元一次方程
    :param a:
    :param b:
    :param c:
    :return:
    """
    p = b*b - 4*a*c
    if abs(p-0.0) <= 1.0e-3:
        p = abs(p)
    if p >= 0 and a != 0:
        x1 = (-b+math.sqrt(p))/(2*a)
        x2 = (-b-math.sqrt(p))/(2*a)
        return x1, x2
    elif a == 0:
        x1 = -c/b
        return x1, x1
    else:
        raise Exception('quadratic math error, a: {}, b: {}, c: {}'.format(a, b, c))


def get_cycle_radius_co(p):
    """
    获取圆形坐标
    :param p:(起点坐标, 结束坐标), 弧高
    :return:x,y,弧长
    """
    p1 = p[0]
    p2 = p[1]
    h_not_positive = (p[2] <= 0.0)
    h = abs(p[2])
    # 圆半径
    half_p = ((p1[0] + p2[0])/2, (p1[1] + p2[1])/2)
    half_d = math.sqrt((p1[0]-half_p[0])**2+(p1[1]-half_p[1])**2)
    r = (half_d**2 + h**2)/(2*h)
    k = 0
    if (p1[0]-half_p[0]) != 0:
        if (p1[1]-half_p[1]) == 0:
            c_x = half_p[0]
            if h_not_positive:
                c_y = half_p[1] + (r-h)
            else:
                c_y = half_p[1] - (r-h)
            return c_x, c_y, r
        ori_k = (p1[1]-half_p[1])/(p1[0]-half_p[0])
        k = -1/ori_k
    b_offset = half_p[1]-k*half_p[0]
    # 圆心坐标
    d_h = r-h
    a = 1+k**2
    b = 2*(k*b_offset-half_p[0]-k*half_p[1])
    c = half_p[0]**2 + half_p[1]**2 + b_offset*b_offset - 2*b_offset*half_p[1] - d_h*d_h
    center_candidate = quadratic(a, b, c)

    c_x_min = min(center_candidate)
    c_x_max = max(center_candidate)
    c_y_min = k*c_x_min + b_offset
    c_y_max = k*c_x_max + b_offset

    if p1[0] == p2[0]:
        if h_not_positive:
            c_x = c_x_max
            c_y = c_y_max
        else:
            c_x = c_x_min
            c_y = c_y_min

    else:
        slope_ori = (p1[1] - p2[1])/(p1[0] - p2[0])
        if slope_ori > 0:
            if h_not_positive:
                c_x = c_x_min
                c_y = c_y_min
            else:
                c_x = c_x_max
                c_y = c_y_max
        elif slope_ori < 0:
            if h_not_positive:
                c_x = c_x_max
                c_y = c_y_max
            else:
                c_x = c_x_min
                c_y = c_y_min
        else:
            if h_not_positive:
                if c_y_min > c_y_max:
                    c_y = c_y_min
                    c_x = c_x_min
                else:
                    c_y = c_y_max
                    c_x = c_x_max
            else:
                if c_y_min < c_y_max:
                    c_y = c_y_min
                    c_x = c_x_min
                else:
                    c_y = c_y_max
                    c_x = c_x_max
    return c_x, c_y, r


def get_cycle_radius(p, sample_cnt=8):
    """
    获取圆弧上采样的点
    :param p: (起点坐标, 结束坐标), 弧高
    :param sample_cnt: 采样数目
    :return:
    """
    p1 = p[0]
    p2 = p[1]
    c_x, c_y, r = get_cycle_radius_co(p)
    # 角度
    angle_1 = math.atan2(p1[1] - c_y, p1[0] - c_x) / math.pi * 180
    angle_2 = math.atan2(p2[1] - c_y, p2[0] - c_x) / math.pi * 180
    v_1 = np.array([c_x - p1[0], c_y - p1[1]])
    v_2 = np.array([c_x - p2[0], c_y - p2[1]])
    angle_dist = cos_dist(v_1, v_2)
    # 分隔点数
    if p[2] > 0:
        start_angle = angle_1
        end_angle = angle_2
    else:
        start_angle = angle_2
        end_angle = angle_1
    if start_angle < end_angle:
        start_angle += 360
    ret_array = []
    x_s = []
    y_s = []
    for _a in np.arange(start_angle, end_angle, -angle_dist / sample_cnt):
        _x = c_x + r * math.cos(_a * math.pi / 180)
        _y = c_y + r * math.sin(_a * math.pi / 180)
        ret_array.append((_x, _y))
        x_s.append(round(_x, 0))
        y_s.append(round(_y, 0))
    arc_len = 2*r*angle_dist * math.pi / 360
    return x_s, y_s, arc_len


def fill_frame_poly(points, _offset, _ratio, im, gray_scale=1):
    """
    画户型图
    :param points: 轮廓点序列
    :param _offset: 坐标偏移
    :param _ratio: 放缩比例
    :param im: 图片模板
    :param gray_scale: 灰度
    :return:
    """
    _im = copy.deepcopy(im)
    b = np.array(points, dtype=int)
    c = b*_ratio + _offset
    c = c.astype(int)
    rr, cc = polygon(c[:, 0], c[:, 1], _im.shape)
    _im[rr, cc] = gray_scale
    return _im


def cal_frame_centroid(im, _offset, _ratio, cut_len=contour_entity.LOG_HU_CUT_SIZE):
    """
    计算图片重心
    :param im:
    :param _offset:
    :param _ratio:
    :param cut_len: hu截取长度
   :return:
    """
    M = moments(im)
    centroid_x, centroid_y = M[1, 0] / M[0, 0], M[0, 1] / M[0, 0]
    mo_center = moments_central(im, (centroid_x, centroid_y))
    nu = moments_normalized(mo_center)
    hu_moment = moments_hu(nu)
    hu_moment += 0.00000001
    log_hu = -1 * np.copysign(1.0, hu_moment[:, ]) * np.log10(abs(hu_moment[:, ]))
    log_hu[log_hu > 1000] = 99
    centroid_x_o = (centroid_x - _offset) / _ratio
    centroid_y_o = (centroid_y - _offset) / _ratio
    return (centroid_x_o, centroid_y_o), log_hu[:cut_len]


def get_direction(angle):
    """
    将角度转换成方向
    :param angle:
    :return:
    """
    if angle is not None:
        angle %= 360
        if angle >= 330 or angle <= 30:
            return ENTRANCE_TOWARDS[u'north']
        elif 30 < angle < 60:
            return ENTRANCE_TOWARDS[u'north-east']
        elif 60 <= angle <= 120:
            return ENTRANCE_TOWARDS[u'east']
        elif 120 < angle < 150:
            return ENTRANCE_TOWARDS[u'south-east']
        elif 150 <= angle <= 210:
            return ENTRANCE_TOWARDS[u'south']
        elif 210 < angle < 240:
            return ENTRANCE_TOWARDS[u'south-west']
        elif 240 <= angle <= 300:
            return ENTRANCE_TOWARDS[u'west']
        elif 300 < angle < 330:
            return ENTRANCE_TOWARDS[u'north-west']
        return ENTRANCE_TOWARDS['default']
    else:
        return angle


def get_relative_angle(end_f_p, f_p, precision=3):
    """
    获取两个点相对于定位点和x轴正向夹角(相反的)
    :param end_f_p:
    :param f_p:
    :param precision:
    :return:
    """
    x_diff = end_f_p[0] - f_p[0]
    y_diff = end_f_p[1] - f_p[1]
    oblique_diff = math.sqrt(x_diff * x_diff + y_diff * y_diff)
    if oblique_diff == 0:
        diff_angle = 0
    else:
        if y_diff < 0:
            diff_angle = 360 - math.acos(x_diff / oblique_diff) * 180 / math.pi
        else:
            diff_angle = math.acos(x_diff / oblique_diff) * 180 / math.pi
    return round(diff_angle, precision)


def get_room_pair_vec(rooms_dict, feature_attr='mass_center'):
    """
    获取分间成对的距离, 夹角嵌入特征向量
    :param rooms_dict:
    :param feature_attr: 使用的分间重心
    :return:
    """
    vec_dist_arr = []
    vec_angle_arr = []
    for r_1, r_2 in VEC_CENTER_HOLDER:
        tmp_dist_arr = []
        tmp_angle_arr = []
        r_1_feature_arr = [rooms_dict[_type] for _type in r_1 if _type in rooms_dict]
        r_2_feature_arr = [rooms_dict[_type] for _type in r_2 if _type in rooms_dict]
        if len(r_1_feature_arr) != 0 and len(r_2_feature_arr) != 0:
            r_1_arr = reduce(lambda x, y: x + y, r_1_feature_arr)
            r_2_arr = reduce(lambda x, y: x + y, r_2_feature_arr)
            if r_1 == r_2:
                arr_len = len(r_1_arr)
                if arr_len == 0:
                    continue
                else:
                    for i in range(arr_len):
                        r_1_p = r_1_arr[i][feature_attr]
                        if i + 1 >= arr_len:
                            break
                        for k in range(i + 1, arr_len):
                            r_2_p = r_1_arr[k][feature_attr]
                            l1_dist = round(math.sqrt((r_1_p[1] - r_2_p[1]) ** 2 + (r_1_p[0] - r_2_p[0]) ** 2))
                            _angle = round(get_relative_angle(r_1_p, r_2_p))
                            tmp_dist_arr.append(l1_dist)
                            tmp_angle_arr.append(_angle)
            else:
                for r_1_dict in r_1_arr:
                    for r_2_dict in r_2_arr:
                        r_1_p = r_1_dict[feature_attr]
                        r_2_p = r_2_dict[feature_attr]
                        l1_dist = round(math.sqrt((r_1_p[1] - r_2_p[1]) ** 2 + (r_1_p[0] - r_2_p[0]) ** 2))
                        _angle = round(get_relative_angle(r_1_p, r_2_p))
                        tmp_dist_arr.append(l1_dist)
                        tmp_angle_arr.append(_angle)
            tmp_dist_arr = sorted(tmp_dist_arr, reverse=True)
            tmp_angle_arr = sorted(tmp_angle_arr, reverse=True)
        vec_dist_arr.append(tmp_dist_arr)
        vec_angle_arr.append(tmp_angle_arr)
    return vec_dist_arr, vec_angle_arr


def get_room_direct_vec(rooms_dict, feature_attr='area'):
    """
    获取分间直接属性的嵌入特征向量
    :param rooms_dict:
    :param feature_attr:
    :return:
    """
    vec_arr = []
    for r_type in VEC_AREA_HOLDER:
        tmp_dist_arr = []
        r_feature_arr = [rooms_dict[_type] for _type in r_type if _type in rooms_dict]
        if len(r_feature_arr) != 0:
            r_arr = reduce(lambda x, y: x+y, r_feature_arr)
            arr_len = len(r_arr)
            for i in range(arr_len):
                r_a = round(r_arr[i][feature_attr])
                tmp_dist_arr.append(r_a/1e6)
            tmp_dist_arr = sorted(tmp_dist_arr, reverse=True)
        vec_arr.append(tmp_dist_arr)
    return vec_arr


def extract_frame_feature(f_id, floor_plan_dict, params):
    """
    提取轮廓相关特征预处理
    :param f_id:
    :param floor_plan_dict:
    :param params:
    :return: {楼层idx:FrameContour, ...}
    """
    plans = floor_plan_dict.get('floorplans', None)
    assert plans is not None, 'ErrorCode.plan_cnt, id:{}'.format(f_id)
    vr_data = floor_plan_dict.get('vrData', None)
    is_vr = contour_entity.VRCode.default
    if vr_data:
        # 存在是否是VR数据
        is_vr = contour_entity.VRCode.is_vr
    # #########################
    # 入户门查找
    # #########################
    entrance_angle = None  # 入户门朝向与正北夹角
    # entrance_line_id = None  # 入户门所在墙
    entrance_item_id = None  # 入户门所在墙ID
    entrance_plan_idx = 0   # 入户门所在楼层
    all_line_items_arr = []
    line_id_to_area_detail_type_dict = collections.defaultdict(set)
    line_id_to_area_type_dict = collections.defaultdict(set)
    line_id_to_area_id_dict = collections.defaultdict(set)
    line_id_to_towards_dict = collections.defaultdict(set)
    for i in range(len(plans)):
        # 全部信息抽取
        all_points = plans[i].get('points', None)
        all_line_items = plans[i].get('lineItems', None)
        all_line = plans[i].get('lines', None)
        all_areas = plans[i].get('areas', None)

        # 点、线、面数据缺失
        is_complete_conditions = [
            all_points is None,
            all_line_items is None,
            all_line is None,
            all_areas is None
        ]
        assert not any(is_complete_conditions), 'ErrorCode.lack_data, id:{}'.format(f_id)

        # ############### 遍历 墙体附属物 & 分间 ######################
        # 1. 获取入户门朝向
        # 2. 统计纳入计算的分间的点集合
        # 入户门查找
        all_line_items_dict = {}
        for _line_item in all_line_items:
            i_id = _line_item.get('id', None)
            all_line_items_dict[i_id] = _line_item
            if _line_item.get(u"entrance", None) is not None:
                entrance_angle = _line_item[u"entrance"]
                entrance_item_id = _line_item[u"id"]
                entrance_plan_idx = i
        all_line_items_arr.append(all_line_items_dict)

        # 遍历分间数据取分间墙朝向 找到门所在的墙体附件
        for area in all_areas:
            try:
                attachments_lines = area[u"attachments"][u"lines"]
                area_id = area[u"id"]
                area_type = area[u"roomType"]
                area_detail_type = area[u"type"]
                for room_line in attachments_lines:
                    room_line_id = room_line[u"id"]
                    room_line_towards = room_line[u"towardsRad"]
                    line_id_to_area_type_dict[room_line_id].add(area_type)
                    line_id_to_area_detail_type_dict[room_line_id].add(area_detail_type)
                    line_id_to_area_id_dict[room_line_id].add(area_id)
                    line_id_to_towards_dict[room_line_id].add(room_line_towards)
            except Exception as e:
                logging.exception(e)
                raise Exception('ErrorCode.area_analysis, id:{}'.format(f_id))
    # 遍历完所有楼层, 没有入户门
    if entrance_angle is None:
        raise Exception('ErrorCode.not_entrance, id:{}'.format(f_id))

    # #########################
    # 分间查找
    # #########################
    # 户型外墙之和
    edge_len = 0
    # 所有外墙除阳台的窗的数量
    edge_windows = 0
    zoom_base = params.get("zoom_base", DEFAULT_ZOOM_BASE)
    area_id_dict = dict()
    all_line_dict = dict()
    plan_dict = dict()
    area_info_dict = collections.defaultdict(list)  # 分间特征字典
    for plan_idx in range(len(plans)):
        # ################### 统计数据初始化 ##########################
        point_dict = {}  # 点坐标字典
        # 全部信息抽取
        all_points = plans[plan_idx].get('points', None)
        all_line = plans[plan_idx].get('lines', None)
        all_areas = plans[plan_idx].get('areas', None)

        size_sum = 0.  # 分间面积和
        size_sum_without_line = 0.  # 分间面积和
        # #################### 遍历 所有点集合 ######################
        # 1. 获取户型坐标四至
        # 2. 旋转后坐标对齐到左下角
        # 3. 获取调整后户型长宽、中心点
        maxx = None
        maxy = None
        for p in all_points:
            p_id = p.get('id', None)
            # 所有的点截取小数
            x = round(p.get('x', None), 0)
            y = round(p.get('y', None), 0)
            if p_id is None or x is None or y is None:
                raise Exception('ErrorCode.point_iter, id:{}'.format(f_id))
            point_dict[p_id] = [x, y]
            if maxx is None:
                maxx = x
                maxy = y
            else:
                maxx = x if x > maxx else maxx
                maxy = y if y > maxy else maxy
        # 点数据为空
        if maxx is None or maxy is None:
            raise Exception('ErrorCode.empty_points, id:{}'.format(f_id))

        # 全部计入分间
        minx = maxx = miny = maxy = None
        for p_id in point_dict:
            x = point_dict[p_id][0]
            y = point_dict[p_id][1]
            if minx is None:
                minx = maxx = x
                miny = maxy = y
            else:
                minx, maxx = min(x, minx), max(x, maxx)
                miny, maxy = min(y, miny), max(y, maxy)
        # 外接矩形长宽
        x_len = float(maxx - minx)
        y_len = float(maxy - miny)
        # 调整坐标到左下角为原点， 不计入户型计算的分间坐标有可能出现负值
        for p_id in point_dict:
            point_dict[p_id][0] -= minx
            point_dict[p_id][1] -= miny

        # #################### 遍历 所有边集合 ######################
        all_line_items_dict = all_line_items_arr[plan_idx]
        points_to_line_map = dict()
        # 点坐标索引的字典
        points_to_line_map_real = dict()
        edge_points_dict = collections.defaultdict(set)
        # 入户门角点
        # door_points = None
        for l in all_line:
            edge_computed = l.get('edgeComputed', False)
            l_id = l.get('id', None)
            l_ps = l.get('points', None)
            l_curve = l.get('curve', 0)
            l_type = l.get('type', 0)
            l_items = l.get('items', [])
            a_x, a_y = point_dict[l_ps[0]]
            b_x, b_y = point_dict[l_ps[-1]]
            if a_x == b_x and a_y == b_y:
                continue
            all_line_dict[l_id] = l
            line_len = euclidean_dist(point_dict[l_ps[0]], point_dict[l_ps[-1]])
            line_center = ((a_x + b_x) / 2, (a_y + b_y) / 2)

            # 记录附件
            _line_items = []
            # 记录反向附件
            _line_items_reverse = []
            for tmp_item_id in l_items:
                tmp_item = all_line_items_dict[tmp_item_id]
                item_type = tmp_item['type']
                start_index = tmp_item['startIndex']
                item_length = tmp_item['length']
                try:
                    assert 'start' in tmp_item, 'FAILED! frame_id: {}, line_id: {}'.format(f_id, l_id)
                    item_start = tmp_item['start']
                    if start_index != 0:
                        item_start = line_len - item_length - item_start
                        start_index = 0
                except Exception as e:
                    logging.exception(e)
                    raise Exception('ErrorCode.item_start_err, id:{}'.format(f_id))
                if item_type == 16:
                    _is = 'door'
                else:
                    _is = tmp_item['is']
                _item_pts = np.array([(int(_['x']) - minx, int(_['y'] - miny)) for _ in
                                      [tmp_item['startPointAt'], tmp_item['endPointAt']]], dtype=int)
                _tmp_item = {'type': item_type, 'start_index': tuple(point_dict[l_ps[start_index]]),
                             'start': item_start, 'length': item_length, 'item_id': tmp_item_id, 'is': _is,
                             'pts': _item_pts, 'center': np.mean(_item_pts, 0)}
                if tmp_item_id == entrance_item_id:
                    _tmp_item['is_entrance'] = True
                    # 加入入户门area_info
                    entrance_line_s = LineString(((a_x, a_y), (b_x, b_y)))
                    item_center = entrance_line_s.interpolate(_tmp_item['start'] + item_length/2)
                    area_info_dict[DEFINED_HU].append({"area": 0, "mass_center": (item_center.x, item_center.y)})
                _line_items.append(_tmp_item)
                tmp_item_reverse = copy.deepcopy(_tmp_item)
                tmp_item_reverse['start_index'] = tuple(point_dict[l_ps[abs(start_index-1)]])
                tmp_item_reverse['start'] = line_len - _tmp_item['start'] - _tmp_item['length']
                _line_items_reverse.append(tmp_item_reverse)
            # 虚拟墙, 栅栏, 玻璃落地墙, 玻璃墙 等于普通窗, 如果已经是窗了, 忽略所有窗上窗.
            if str(l_type) in ('3', '4', '5', '6'):
                if edge_computed:
                    _l_is = 'window'
                    _i_type = 5
                else:
                    _l_is = 'door'
                    _i_type = 0
                _l_items_id = str(np.random.randint(0, 50000000))
                _line_items = [{'type': _i_type, 'start_index': tuple(point_dict[l_ps[0]]),
                                'start': 0, 'is': _l_is, 'item_id': _l_items_id, 'length': line_len,
                                'pts': np.array(((a_x, a_y), (b_x, b_y))), 'center': line_center},]
                _line_items_reverse = _line_items
            line_points = [(a_x, a_y)]
            # 对于弧线采样
            if l_curve != 0.0:
                try:
                    # 对弧墙采样
                    _x, _y, arc_len = get_cycle_radius(((a_x, a_y), (b_x, b_y), l_curve),
                                                       sample_cnt=params.get("sample_cnt", 15))
                    line_len = arc_len
                    if l_curve <= 0.0:
                        line_points.extend([m for m in reversed([x for x in zip(_x, _y)])])
                    else:
                        line_points.extend([x for x in zip(_x, _y)])
                except Exception as e:
                    logging.exception(e)
                    raise Exception('ErrorCode.get_cycle_radius_err, id:{}'.format(f_id))
            line_points.append((b_x, b_y))
            is_balcony_line = False
            # 阳台, 露台, 花园
            tmp_area_detail_type = line_id_to_area_detail_type_dict[l_id]
            tmp_area_type = line_id_to_area_type_dict[l_id]
            tmp_towards = line_id_to_towards_dict[l_id]
            if not BALCONY_TYPE.isdisjoint(set(tmp_area_detail_type)):
                is_balcony_line = True
            tmp_area_id = line_id_to_area_id_dict[l_id]
            _line_items = sorted(_line_items, key=lambda _x: _x['start'])
            _tmp_line = {'points': line_points, 'line_center': line_center, 'len': line_len, 'l_id': l_id,
                         'curve': l_curve, 'items': _line_items, 'is_balcony_line': is_balcony_line,
                         'area_type': tmp_area_type, 'type': l_type, 'area_detail_type': tmp_area_detail_type,
                         'area_id': tmp_area_id, 'towards': tmp_towards}

            # 加入线集合
            points_to_line_map[','.join(l_ps)] = _tmp_line
            _tmp_line_reversed = copy.deepcopy(_tmp_line)
            _line_items_reverse = list(reversed(_line_items_reverse))
            _tmp_line_reversed['items'] = _line_items_reverse
            _tmp_line_reversed['points'] = [m for m in reversed(line_points)]
            points_to_line_map[','.join(reversed(l_ps))] = _tmp_line_reversed

            points_to_line_map_real[((a_x, a_y), (b_x, b_y))] = _tmp_line
            points_to_line_map_real[((b_x, b_y), (a_x, a_y))] = _tmp_line_reversed

            if edge_computed:
                edge_len += line_len
                if not is_balcony_line:
                    edge_windows += len(_line_items)
                if (a_x, a_y) != (b_x, b_y):
                    edge_points_dict[(a_x, a_y)].add((b_x, b_y))
                    edge_points_dict[(b_x, b_y)].add((a_x, a_y))
        _offset = np.array(zoom_base * 0.1)
        room_cnt_dict = collections.defaultdict(int)  # 分间类型计数器
        # 设置画布
        zoom_ratio = DEFAULT_ZOOM_BASE / max(x_len, y_len)
        im_size = np.array([DEFAULT_ZOOM_BASE + int(zoom_base * 0.2),
                            DEFAULT_ZOOM_BASE + int(zoom_base * 0.2)], dtype='int32')
        im_all = np.zeros(im_size, dtype=np.float32)
        im_temp = np.zeros(im_size, dtype=np.float32)
        _offset = np.array(zoom_base * 0.1)
        for area in all_areas:
            if area['roomType'] == '100900000002' and area['type'] != 1:
                continue
            # 分间的点
            area_id = area.get(u"id", None)
            # print(area_id)
            # 分间的点
            area_points = area.get(u"points", None)
            # 分间类型
            area_type = area.get(u"roomType", None)
            # 分间面积
            area_area = area.get('size', None)
            size_without_line = area.get('sizeWithoutLine', -1)
            # 是否空（空则不计入总面积）
            is_empty = area.get('empty', False)
            # 分间的点不存在
            if area_points is None or area_type is None or area_area is None:
                raise Exception('ErrorCode.area_info_empty')
            if not is_empty:
                size_sum += area_area
                size_sum_without_line += size_without_line
            # 分间类型计数
            room_cnt_dict[area_type] += 1

            # 过滤不需要的分间
            if area_type not in params.get('cal_room_type_set', []):
                continue

            tmp_area_points = list()
            tmp_dup_area_points_set = set()
            for _p_id in area_points:
                _tmp_real_point = point_dict[_p_id]
                if tuple(_tmp_real_point) in tmp_dup_area_points_set:
                    # 重复点容错处理
                    continue
                tmp_dup_area_points_set.add(tuple(_tmp_real_point))
                tmp_area_points.append(_tmp_real_point)

            _area_perimeter = 0
            _current_line_arr = []
            point_id_tuples, _ = contour_entity.array_2_combination(area_points, combination_len=2)
            _area_line_max_orders = []
            _area_doors = []
            for p_id_1, p_id_2 in point_id_tuples:
                points_cp_key = '{},{}'.format(p_id_1[0], p_id_2[0])
                cp_line = points_to_line_map.get(points_cp_key, None)
                if cp_line:
                    _area_perimeter += cp_line['len']
                    _current_line_arr.append(cp_line)
                    _room_order = min([MAIN_DOOR_ROOM_TYPE_ORDER.get(_, 2) for _ in cp_line['area_detail_type']])
                    _door_len_arr = [(_['length'], _) for _ in cp_line.get('items') if _.get('is', 'window') == 'door']
                    _area_doors.extend(_door_len_arr)
                    if _door_len_arr:
                        # _door_len_arr = sorted(_door_len_arr) bug修复
                        _door_len_arr = sorted(_door_len_arr, key=lambda x: x[0])
                        _main_door_item_len, _max_item = _door_len_arr[0][0], _door_len_arr[0][1]
                        item_is_entrance = _max_item.get('is_entrance', False)
                        if item_is_entrance:
                            _room_order = -1
                    else:
                        _main_door_item_len = -1
                        # 必须要有门
                        _room_order = 5
                        _max_item = None
                    _area_line_max_orders.append((_room_order, _main_door_item_len, _max_item,))
            # 重新sort lines
            start_line_index = sorted(_area_line_max_orders, key=lambda _: (_[0], -_[1]))
            _max_item = start_line_index[0][-1]
            # 分间重心
            if area_type not in GRAY_SCALE_DICT:
                area_gray_scale = 0.1
            else:
                area_gray_scale = GRAY_SCALE_DICT[area_type]
            area_im = fill_frame_poly(tmp_area_points, _offset, zoom_ratio, im_temp, area_gray_scale)
            area_centroid, area_log_hu = cal_frame_centroid(area_im, _offset, zoom_ratio)
            assert (not np.isnan(area_centroid[0])) and (not np.isnan(area_centroid[1])), 'frame_id: {}, centroid is nan'.format(f_id)
            im_all = area_im + im_all
            _room_contour_params = {'entrance_angle': 0,  # 这个暂时不需要
                                    'edge_len': _area_perimeter/1e3, 'area_size': area_area,
                                    'area_size_without_line': size_without_line, 'mass_center': area_centroid,
                                    'floor_points_to_line_map': points_to_line_map_real,
                                    'edge_points_array': tmp_area_points,
                                    'edge_points_dict': None,
                                    'room_type': area_type,
                                    'area_doors': _area_doors,
                                    'area_id': area_id,
                                    'log_hu': area_log_hu, 'sorted_line_arr': _current_line_arr,
                                    'main_item': _max_item
                                    }
            _area_contour = contour_entity.RoomContour(**_room_contour_params)
            area_id_dict[area_id] = _area_contour
            # 没有除墙面积使用含墙面积
            area_info_size = area_area
            if size_without_line > 0:
                area_info_size = size_without_line
            area_info_dict[area_type].append({"area": area_info_size, "mass_center": area_centroid})
        # 统计分间数
        shi = room_cnt_dict.get('100900000001', 0) + room_cnt_dict.get('100900000009', 0)
        ting = room_cnt_dict.get('100900000002', 0)
        chu = room_cnt_dict.get('100900000003', 0)
        wei = room_cnt_dict.get('100900000004', 0)
        yang = room_cnt_dict.get('100900000005', 0)
        # 求户型中心需要归一化
        frame_w_centroid, frame_w_log_hu = cal_frame_centroid(im_all, _offset, zoom_ratio)
        threshold_im = copy.deepcopy(im_all)
        threshold_im[threshold_im > 0] = 1
        frame_centroid, frame_log_hu = cal_frame_centroid(threshold_im, _offset, zoom_ratio)
        if entrance_plan_idx == plan_idx:
            entrance_towards = get_direction(entrance_angle)
        else:
            entrance_towards = ''
        _frame_contour_init_params = {'is_vr': is_vr, 'entrance_angle': entrance_towards,
                                      'edge_len': edge_len/1e3, 'area_size': size_sum,
                                      'area_size_without_line': size_sum_without_line,
                                      'mass_center': frame_centroid,
                                      'floor_points_to_line_map': points_to_line_map_real, 'edge_points_array': None,
                                      'edge_points_dict': edge_points_dict,
                                      'shi': shi, 'ting': ting, 'chu': chu, 'wei': wei, 'yang': yang,
                                      'area_id_dict': area_id_dict, 'log_hu': list(frame_log_hu),
                                      'w_log_hu': list(frame_w_log_hu),
                                      }
        _frame_contour = contour_entity.FrameContour(**_frame_contour_init_params)
        mass_layout, mass_layout_geo = get_room_pair_vec(area_info_dict)
        area_vec = get_room_direct_vec(area_info_dict)
        _frame_contour.set_mass_layout(mass_layout)
        _frame_contour.set_mass_layout_geo(mass_layout_geo)
        _frame_contour.set_area_vec(area_vec)
        plan_dict[plan_idx] = _frame_contour
    return plan_dict


if __name__ == '__main__':
    pass
