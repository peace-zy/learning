#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2018 www.ke.com, Inc. All Rights Reserved
"""
按户型数量将城市分组，使得每组户型数量基本一致
Authors: yudonghai@ke.com
Date:    2019/08/29
"""
from __future__ import division
import logging
import yaml
import sys

import __init__


def main():
    if len(sys.argv) < 3:
        logging.error("no less than 2 arguments!")
        sys.exit()

    config_file = sys.argv[1]
    groups_file = sys.argv[2]

    with open(config_file, "r") as config_data:
        conf = yaml.load(config_data)
    
    file_path = conf.get("frame_cnt_config", {}).get("save_params", {}).get("file_or_table_name", None)
    if file_path is None:
        logging.error("can not get frame count(group by city_code) file!")
        sys.exit(1)
    
    groups = []
    with open(file_path, "r") as data:
        item_group = []
        item_cnt = 0
        for line in data:
            items = line.strip().split("\t")
            city_code = items[0]
            frame_cnt = int(items[1])
            item_cnt += frame_cnt
            item_group.append(city_code)
            if item_cnt >= 400000:
                groups.append([x for x in item_group])
                item_cnt = 0
                item_group = []
        if item_cnt > 0:
            groups.append([x for x in item_group])
    with open(groups_file, "w") as result:
        for g in groups:
            result.writelines(",".join(g) + "\n")


if __name__ == "__main__":

    logging.basicConfig(level=logging.WARN, format='%(asctime)s %(levelname)s %(message)s')

    main()
