#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2019 www.ke.com, Inc. All Rights Reserved
"""
装修户型检测点
Authors: yudonghai@ke.com
Date:    2020/10/27
"""
from __future__ import division
import logging
import yaml
import sys
import traceback

import json

import __init__
from lib import entity
from lib import spark_util
from lib import eval_main
from lib import label_functions
from lib import code_enum as ce
from frame_remould.floorplan import House


def condition_check(key_dict, conditions, condition_conn):
    cond_results = []
    for cond in conditions:
        k, comp, target = cond
        if comp == "notnull":
            cond_results.append(key_dict[k] is not None)
        elif comp == "<":
            cond_results.append(key_dict[k] < target)
        elif comp == "<=":
            cond_results.append(key_dict[k] <= target)
        elif comp == ">":
            cond_results.append(key_dict[k] > target)
        elif comp == ">=":
            cond_results.append(key_dict[k] >= target)
        elif comp == "==":
            cond_results.append(key_dict[k] == target)
        elif comp == "true":
            cond_results.append(key_dict[k] is True)
        elif comp == "false":
            cond_results.append(key_dict[k] is False)
        elif comp == "in":
            cond_results.append(key_dict[k] in set(target.strip().split(",")))
        else:
            logging.error("unknown operator！")
            return None
    result = None
    if condition_conn == "all":
        result = all(cond_results)
    elif condition_conn == "any":
        result = any(cond_results)
    else:
        logging.error("unknown condition connection {}!!".format(condition_conn))
    return result


def doc_group_getter(doc_vars, room_keys):
    new_result = {}
    for doc_group in doc_vars:
        for doc_item in doc_group:
            item_cond = doc_item["cond"]
            item_cond_conn = doc_item["cond_conn"]
            new_vars = doc_item["vars"]
            item_flag = condition_check(room_keys, item_cond, item_cond_conn)
            if item_flag is None:
                return None
            if item_flag:
                new_result.update(new_vars)
                break
    return new_result


def one_room_doc(vars, dims_conf):
    one_room_result = []
    for dim in dims_conf:
        dim_name = dim.get("dim_name", "")
        # if dim_name == "kitchen_type":
        #     tmp = 0  # zhuc
            
        dim_condition = dim.get("dim_condition", [])
        dim_condition_conn = dim.get("dim_condition_conn", "")
        title = unicode(dim.get("title", u""))
        detail = unicode(dim.get("detail", u""))
        annotation = unicode(dim.get("annotation", u""))
        merit = unicode(dim.get("merit", u""))
        display = unicode(dim.get("display", u""))
        doc_vars = dim.get("doc_vars", [])

        dim_flag = condition_check(vars, dim_condition, dim_condition_conn)
        if dim_flag is None:
            return None

        if not dim_flag:
            continue

        dim_result = doc_group_getter(doc_vars, vars)
        if not dim_result:
            continue
        if dim_result is None:
            return None
        full_vars = dict(vars, **dim_result)
        # full_vars = {unicode(k, encoding="utf-8"): full_vars[k] for k in full_vars}
        one_room_result.append({
            "dim_name": dim_name,
            "title": title.format(**full_vars),
            "detail": detail.format(**full_vars),
            "annotation": annotation.format(**full_vars),
            "merit": merit.format(**full_vars),
            "display": display.format(**full_vars)
        })
    return one_room_result


def space_doc(key_vars_lst, space_conf):
    space_name = space_conf["name"]
    pro_range = space_conf["range"]
    dims_conf = space_conf["dims"]

    if not key_vars_lst:
        return None

    vars_lst = key_vars_lst
    if pro_range == "max":
        vars_lst = [sorted(key_vars_lst, key=lambda x: x["area_size"])[-1]]

    room_items = []
    for vars in vars_lst:
        room_item = one_room_doc(vars, dims_conf)
        room_items.append({"dims": room_item, "area_id": vars["base_info"]["area_id"], "vars": vars})
    return {"space_name": space_name, "doc": room_items}


def doc_format(key_vars_dict, conf_params):
    room_type_lst = conf_params["room_type_order"]
    space_dict = conf_params["spaces"]

    final_doc = {}
    for room_type in room_type_lst:
        key_vars_lst = key_vars_dict.get(room_type, [])
        space_conf = space_dict.get(room_type, {})
        if not space_conf:
            continue
        space_docs = space_doc(key_vars_lst, space_conf)
        if space_docs is None:
            continue

        final_doc[room_type] = space_docs
    if not final_doc:
        return None
    return final_doc


def frame_decoration_feature(row, debug=False, **params):
    """
    :param row: str/Row/dict, 户型数据
            (str格式时各个字段用逗号分隔，且需要跟Frame类内各字段顺序一致)
    :param debug: boolean, 调试模式，返回户型对象
    :param params: dict, 参数
    :return:
    """
    frame = entity.Frame(row)

    try:
        frame_vector = frame.vector
        house = House()
        house.set_json_str(json.dumps(frame_vector))
        frame.set_house(house)
        res_dict, js_dict = house.run()

        # 标签
        frame.add_label(label_functions.label_base, **params["label_params"])
        # 检测点
        eval_main.decoration_explain(frame, **params)

        decoration_dict = frame.explain_message.get("decoration_dict", {})
        decoration_sug_dict = frame.explain_message.get("decoration_sug_dict", {})
        # 自动摆放字段
        decoration_sug_dict.update(js_dict)

        # 厨房类型
        if debug:
            # kitchen_type = get_kitchen_type("[{'kitchen_type': 'U'}]")
            kitchen_type = get_kitchen_type('[{}]')
        else:
            kitchen_type = get_kitchen_type(row['result'])
        if decoration_dict.get('kitchen') is not None:
            decoration_dict['kitchen'][0].update(kitchen_type)
        # decoration_dict['kitchen'][0].update(kitchen_type)

        docs = doc_format(decoration_dict, params["dec_conf"])
        docs = json.dumps(docs, encoding="utf-8")

        decoration_sugs = json.dumps(decoration_sug_dict, encoding="utf-8")
        result_vector = frame.base_feature() + [frame.frame_label, docs, decoration_sugs]
        result = [str(x) for x in result_vector]
    except Exception as e:
        traceback.print_exc()
        logging.error("{} get decoration feature exception!!".format(frame.frame_id))
        frame._state = ce.State.unknown_exception
        result_vector = frame.base_feature() + [0, "", ""]
        result = [str(x) for x in result_vector]
    if debug:
        return frame, result
    return result


def get_kitchen_type(row_result):
    try:
        kitchen_types = json.loads(row_result)
        for t in kitchen_types:
            if t.get('kitchen_type') is None:
                continue
            else:
                return {'kitchen_type': t.get('kitchen_type')}
    except Exception as e:
        return {'kitchen_type': "None"}
    return {'kitchen_type': "None"}


def logic_func(driver, raw_df, **params):
    """
     spark 逻辑处理
    :param driver: spark_util.SparkSqlDriver, spark 执行类
    :param raw_df: pyspark.sql.dataframe.DataFrame， sql 查询结果
    :param params: dict, 参数字典
    :return: result_df, 处理后的 DataFrame
    """
    result_rdd = raw_df.rdd.map(lambda row: frame_decoration_feature(row, **params))
    result_df = driver.rdd_2_df(result_rdd)
    names = params["table_names"]
    result_df = result_df.toDF(*names)
    return result_df


def main():
    """ 主函数 """
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    if len(sys.argv) < 3:
        logging.error("no less than 2 arguments!")
        sys.exit()

    pt_date = sys.argv[1]
    config_file = sys.argv[2]

    with open(config_file, "r") as config_data:
        conf = yaml.load(config_data)

    # 从配置文件读取参数
    spark_config_key = "frame_decoration_config"
    spark_params = conf.get(spark_config_key, None)
    if spark_params is None:
        logging.error("lack {} in config file".format(spark_config_key))
        sys.exit(-1)

    # ## 补充参数
    # pt
    spark_params["sql_params"]["pt_date"] = pt_date
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_function"] = logic_func
    # 存储pt
    spark_params["save_params"]["partition_params"] = {"pt": "{}000000".format(pt_date)}

    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()


if __name__ == "__main__":
    logging.basicConfig(level=logging.WARN, format='%(asctime)s %(levelname)s %(message)s')

    main()
