SELECT
    frame_tab.frame_id,
    frame_tab.image_id,
    frame_tab.vector_value,
    frame_tab.city_code,
    ke_auto_tab.result
FROM
(SELECT
    frame_id
    ,image_id
    ,vector_value
    ,city_code
FROM
(SELECT
    mapping.entity_id as frame_id
    ,image_id
    ,reflect("java.net.URLDecoder", "decode", trim(vector_value), "UTF-8") AS vector_value
    ,city_code
    ,ROW_NUMBER() OVER(PARTITION BY mapping.entity_id ORDER BY update_time desc) AS rn
FROM
(SELECT
    id
    ,vector_value
    ,city_code
FROM dw.dw_house_frame_vector_da
WHERE pt='{pt_date}000000'
AND is_valid=1
AND city_code='110000'
) vector
JOIN
(SELECT
    image_id
    ,entity_id
    ,update_time
FROM dw.dw_house_image_entity_mapping_da
WHERE pt='{pt_date}000000'
AND image_type_code = 110028006
AND entity_type_code = 110029002
AND is_valid = 1
) mapping
ON mapping.image_id=vector.id
) tb
WHERE tb.rn=1) frame_tab
LEFT JOIN
(SELECT frame_id, result FROM data_mining.data_mining_ke_auto_result_da WHERE pt='{pt_date}000000') ke_auto_tab
ON frame_tab.frame_id=ke_auto_tab.frame_id

