# coding=utf-8
from __future__ import division
import logging
import yaml
import sys
import traceback
import json
import exceptions
import os

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../../"))
sys.path.insert(0, os.getcwd())

from lib import entity
import frame_remould.utils.spark_util as spark_util
from lib import eval_main
from lib import label_functions
from lib import code_enum as ce
from frame_remould.floorplan import House


def statistic_main_room(row, **conf):
    frame = entity.Frame(row)
    try:
        frame_vector = frame.vector
        house = House()
        house.set_json_str(json.dumps(frame_vector))
        house.run()

        frame.set_house(house)
        frame.add_label(label_functions.label_base, **conf["label_params"])
        eval_main.decoration_explain(frame, **conf)

        result = get_result(frame.frame_id, frame)
    except Exception as e:
        traceback.print_exc()
        result = get_result(frame.frame_id, e)
    return result


def get_result(frame_id, frame):
    result = [frame_id]

    def get_error_result(result):
        n = 7
        for i in range(n):
            result.append('')
        return result

    if isinstance(frame, exceptions.Exception):
        result = get_error_result(result)
    else:
        features = frame.explain_message['decoration_dict']
        house = frame.house
        if house.res_dict.get('main_room') is None:
            result = get_error_result(result)
            return result
        if features.get('main_room') is None:
            result = get_error_result(result)
            return result
        # main_room_feats = features.get('main_room')
        main_room_feats = features.get('parlour')
        if main_room_feats is None:
            return get_error_result(result)

        main_room_feat = main_room_feats[0]
        result.append(str(main_room_feat['room']))
        # result.append(str(house.res_dict.get('main_room')[0]['space_analysis']['depth']/1000))
        # result.append(str(house.res_dict.get('main_room')[0]['space_analysis']['width']/1000))
        result.append(str(main_room_feat['depth'] - 0.12))
        result.append(str(main_room_feat['width'] - 0.12))
        result.append(str(int(main_room_feat['with_toilet'] if main_room_feat['with_toilet'] is not None else 0)))
        result.append(str(int(main_room_feat['with_cloakroom'] if main_room_feat['with_cloakroom'] is not None else 0)))
        result.append(str(int(main_room_feat['convex'])))
        result.append(str(int(main_room_feat['with_balcony'])))

    return result


def logic_func(driver, raw_df, **params):
    result_rdd = raw_df.rdd.map(lambda row: statistic_main_room(row, **params))
    result_df = driver.rdd_2_df(result_rdd)
    names = params["table_names"]
    result_df = result_df.toDF(*names)
    return result_df


def main():
    """ 主函数 """
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    if len(sys.argv) < 3:
        logging.error("no less than 2 arguments!")
        sys.exit()

    pt_date = sys.argv[1]
    config_file = sys.argv[2]

    with open(config_file, "r") as config_data:
        conf = yaml.load(config_data)

    # 从配置文件读取参数
    spark_config_key = "frame_decoration_config"
    spark_params = conf.get(spark_config_key, None)
    if spark_params is None:
        logging.error("lack {} in config file".format(spark_config_key))
        sys.exit(-1)

    # ## 补充参数
    # pt
    spark_params["sql_params"]["pt_date"] = pt_date
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_function"] = logic_func
    # 存储pt
    spark_params["save_params"]["partition_params"] = {"pt": "{}000000".format(pt_date)}

    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()


def get_frame_statistic(frame):
    """
    frame: frame id or frame json file path
    离线得到户型的统计结果
    """
    import frame_eval.newhouse_v2.utils as utils
    frame_id, line = utils.get_frame_vector(frame)
    conf = dict()
    utils.collect_conf(r"frame_eval/decoration_v2/statistic/conf_main_room.yml", conf)

    result = statistic_main_room(line, **conf)
    return result


if __name__ == "__main__":
    logging.basicConfig(level=logging.WARN, format='%(asctime)s %(levelname)s %(message)s')


    if os.name != "nt":
        main()
    else:
        # frame_id = 1116734796657371
        # test(frame_id)
        frame_id_list, room_cnt_list = [], []
        depth_list, width_list = [], []
        with_toilet, with_cloakroom = [], []
        with_balcony, convex = [], []

        path = r'D:\ke\data\more_frame_json0'
        files = os.listdir(path)
        for idx, f in enumerate(files):
            print(idx)
            f_id = f.split('.')[0]
            f_path = os.path.join(path, f)
            result = get_frame_statistic(f_path)
            frame_id_list.append(f_id)
            room_cnt_list.append(result[1])
            depth_list.append(result[2])
            width_list.append(result[3])
            with_toilet.append(result[4])
            with_cloakroom.append(result[5])
            convex.append(result[6])
            with_balcony.append(result[7])

        import pandas as pd
        res_df = pd.DataFrame(columns=[
            'frame_id',
            'room_cnt',
            'depth',
            'width',
            'with_balcony',
        ])
            # 'with_toilet',
            # 'with_cloakroom'])
        res_df['frame_id'] = frame_id_list
        res_df['room_cnt'] = room_cnt_list
        res_df['depth'] = depth_list
        res_df['width'] = width_list
        # res_df['with_toilet'] = with_toilet
        # res_df['with_cloakroom'] = with_cloakroom
        # res_df['convex'] = convex
        res_df['with_balcony'] = with_balcony
        res_df.to_csv(r'D:\res.csv')
        # res_df.to_csv(r'D:\res.csv', index=None, header=None, sep='\t')
