select
    frame_id
    ,image_id
    ,city_code
    ,t_shi
    ,t_ting
    ,t_chu
    ,t_wei
    ,plans_len
    ,edge_len
    ,inplace_area
    ,guest_len
    ,living_len
    ,work_len
    ,guest_lines
    ,living_lines
    ,work_lines
    ,living_guest_cross
    ,work_guest_cross
    ,living_work_cross
    ,error
    ,is_valid
    ,update_time
    ,show_area_o
    ,eval_liner_text
from data_mining.data_mining_frame_line_da
where pt='{pt_date}000000'
and plans_len=1
