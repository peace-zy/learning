#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2018 www.ke.com, Inc. All Rights Reserved
"""
户型解析——动线、可视域特征（增量合并）
Authors: yudonghai@ke.com
Date:    2019/09/13
"""
from __future__ import division
import logging
import yaml
import sys
import datetime

from lib import spark_util
from lib.file_util import get_file_stream


def main():
    """ 主函数 """
    if len(sys.argv) < 3:
        logging.error("no less than 2 arguments!")
        sys.exit()

    pt_date = sys.argv[1]
    config_file = sys.argv[2]

    f = get_file_stream(config_file)
    conf = yaml.load(f)
    # with open(config_file, "r") as config_data:
    #     conf = yaml.load(config_data)

    # 从配置文件读取参数
    spark_config_key = "line_feature_collect_config"
    spark_params = conf.get(spark_config_key, None)
    if spark_params is None:
        logging.error("lack {} in config file".format(spark_config_key))
        sys.exit(1)

    # ## 补充参数
    # pt
    spark_params["sql_params"]["pt_date"] = pt_date
    cur_date = datetime.datetime.strptime(pt_date, "%Y%m%d")
    pre_date = cur_date - datetime.timedelta(days=1)
    spark_params["sql_params"]["pre_pt_date"] = pre_date.strftime("%Y%m%d")
    # 存储pt
    spark_params["save_params"]["partition_params"] = {"pt": "{}000000".format(pt_date)}

    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()


if __name__ == "__main__":

    logging.basicConfig(level=logging.WARN, format='%(asctime)s %(levelname)s %(message)s')

    main()
