SELECT
    all_vec.frame_id
    ,image_id
    ,vector_value
    ,city_code
FROM
(SELECT
    frame_id
    ,image_id
    ,vector_value
    ,city_code
FROM
(SELECT
    mapping.entity_id as frame_id
    ,image_id
    ,reflect("java.net.URLDecoder", "decode", trim(vector_value), "UTF-8") AS vector_value
    ,city_code
    ,ROW_NUMBER() OVER(PARTITION BY mapping.entity_id ORDER BY update_time desc) AS rn
FROM
(SELECT
    id
    ,vector_value
    ,city_code
FROM dw.dw_house_frame_vector_da
WHERE pt='{pt_date}000000'
AND is_valid=1
) vector
JOIN
(SELECT
    image_id
    ,entity_id
    ,update_time
FROM dw.dw_house_image_entity_mapping_da
WHERE pt='{pt_date}000000'
AND image_type_code = 110028006
AND entity_type_code = 110029002
AND is_valid = 1
) mapping
ON mapping.image_id=vector.id
) tb
WHERE tb.rn=1
) all_vec
JOIN
(SELECT DISTINCT
    cast(frame_id AS string) AS frame_id,
    house_id
FROM dw.dw_house_house_frame_mapping_da
WHERE pt = '{pt_date}000000'
AND is_valid=1
) frame_house
on frame_house.frame_id=all_vec.frame_id
JOIN
(SELECT
    housedel_id,
    house_id
FROM dw.dw_allinfo_housedel_da
WHERE pt = '{pt_date}000000'
AND housedel_status_code IN (
    120011001, -- 有效
    120011002, -- 意向金起草
    120011003, -- 意向金盖章
    120011004, -- 意向金签订
    120011019, -- 意向金无效
    120011020, -- 意向金退意向
    120011023, -- 意向金完结
    120011009  -- 合同起草
)  -- 认为在售状态
) housedel
ON housedel.house_id=frame_house.house_id
LEFT JOIN
(SELECT
    frame_id
    ,1 AS line_valid
FROM data_mining.data_mining_frame_line_da
WHERE pt='{pre_pt_date}000000'
AND error=0
) line_state
ON line_state.frame_id=all_vec.frame_id
WHERE line_valid IS NULL
