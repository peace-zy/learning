SELECT resblock_info.resblock_id, newhouse_v2.frame_id,
       resblock_info.room_cnt, resblock_info.parlor_cnt, resblock_info.toilet_cnt, resblock_info.floor_area,
       frame_feature.label_value, newhouse_v2.feature, newhouse_v2.doc, newhouse_img.image_url,
       line_cross.living_guest_cross, line_cross.work_guest_cross, line_cross.living_work_cross,
       resblock_info.city_code
    FROM (
        SELECT resblock_id, frame_id, room_cnt, parlor_cnt, toilet_cnt, floor_area, city_code
        FROM rpt.rpt_nh_build_resblock_frame_info_da
        WHERE pt = '{pt_date}000000' and is_valid=1
    ) resblock_info
    JOIN (
        select frame_id, feature, doc, basic_info
        from data_mining.data_mining_frame_newhouse_v2_da
        WHERE pt = '{pt_date}000000' and feature!='' and doc!='' and error=''
    ) newhouse_v2 ON resblock_info.frame_id=newhouse_v2.frame_id
    JOIN (
        SELECT frame_id, label_value
        FROM data_mining.data_mining_frame_label
        WHERE pt = '{pt_date}000000' and state=0
    ) frame_feature ON newhouse_v2.frame_id=frame_feature.frame_id
    JOIN (
        SELECT frame_id, living_guest_cross, work_guest_cross, living_work_cross
        FROM data_mining.data_mining_frame_line_da
        WHERE pt = '{pt_date}000000' and is_valid=1
    ) line_cross ON newhouse_v2.frame_id=line_cross.frame_id
    JOIN (
        SELECT url_tabel.frame_id, url_tabel.image_url
        FROM (
          SELECT frame_id, image_url, update_time, ROW_NUMBER() OVER (PARTITION BY frame_id ORDER BY update_time DESC) AS rn
          FROM dw.dw_house_newhouse_resblock_standard_frame_da sf
          WHERE pt = '{pt_date}000000' and image_url!=''
        )url_tabel
        where url_tabel.rn=1
    ) newhouse_img ON newhouse_v2.frame_id=newhouse_img.frame_id