# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/1/7 15:42
# ===================================
import json

import lib.code_enum as ce


str_map = {
    'all_window1': '全明格局',
    'north_south_trans1': '南北通透',
    'kitchen_window1': '明厨',
    'toilet_window1': '明卫',

    'all_window2': '全明格局',
    'north_south_trans2': '南北通透',

    'main_room3': '主卧',

    'visual4': '隐私性保护方面',
    'movement_clear4': '动静分区方面',

    'square5': '格局方正',
    'movement_clear5': '动静分区分明',
    'good_active_line5': '起居动线合理',

    'sub_room6': '次卧',
    'kitchen6': '厨房',
    'parlour_toilet6': '卫生间',

    'garden7': '带花园',
    'loft7': '带阁楼',
    'terrace7': '带露台',
    'cloakroom7': '带衣帽间'
}


def compare_rule(v1, v2):
    """
    v1和v2都是[room_cnt, [other_label1, other_label2, other_label3...], QA_obj]形式
    自定义排序，先按other_label数组的长度最大的优先在前，如果长度相等就以户型总分高的在前(QA_obj.total_score)
    """
    if len(v1[1]) == len(v2[1]):
        if float(v1[2].total_score) > float(v2[2].total_score):
            return -1
        else:
            return 1
    else:
        if len(v1[1]) > len(v2[1]):
            return -1
        else:
            return 1


class QuestionDetect(object):
    def __init__(self, row):
        self.frame_id = str(int(row['frame_id']))
        self.room_cnt = int(row['room_cnt'])
        self.parlor_cnt = int(row['parlor_cnt'])
        self.toilet_cnt = int(row['toilet_cnt'])
        self.floor_area = float(row['floor_area'])

        self.label_value = int(row['label_value'])
        self.feature = json.loads(row['feature'])
        self.doc = json.loads(row['doc'])
        self.function = self.doc['function']
        self.space = self.doc['space']
        self.summary = self.doc['summary']
        self.lighting = self.doc['lighting']
        self.total_score = self.solve_dict(self.summary, ['whole', 0, 'summary_total_score', 'simple_explain'])
        self.living_guest_cross_cnt = 0 if row['living_guest_cross'] == '0' else len(row['living_guest_cross'].split('_'))
        self.work_guest_cross_cnt = 0 if row['work_guest_cross'] == '0' else len(row['work_guest_cross'].split('_'))
        self.living_work_cross_cnt = 0 if row['living_work_cross'] == '0' else len(row['living_work_cross'].split('_'))
        self.line_cross_cnt = self.work_guest_cross_cnt + self.living_work_cross_cnt + self.living_guest_cross_cnt

        self.img_url = 'https://ke-image.ljcdn.com/' + row['image_url'] + '!l_fbk'

        if self.total_score is None:
            self.total_score = 0

    def solve_dict(self, dict_now, key_list):
        """
        :param dict_now: 一个多层字典，里面可能有嵌套数组
        :param key_list: key值列表
        :return: 返回dict_now[key_list[0]][key_list[1]][key_list[2]]...对应的值，中间任意一环没有都返回None
        """
        value = dict_now
        for key in key_list:
            if isinstance(value, dict):
                value = value.get(key, None)
            elif isinstance(value, list):
                value = value[key]
            if value is None:
                return None
        return value

    def detectQ1(self):
        """
        问题1检测：
        必备：整屋朝南、主卧采光优秀、客厅采光优秀
        辅助：全明格局、南北通透、明厨、明卫
        :return: [flag, [other_label1, ohter_label2....]], flag表示必备检测点是否全部满足，都满足为True，第二个参数为辅助标签字符串列表。
        """
        # 必备检测点检测
        flag = True
        if flag:
            lighting_face = self.solve_dict(self.lighting, ['whole', 0, 'lighting_face', 'level'])
            flag = flag & (lighting_face == '1')
        if flag:
            lighting_light = self.solve_dict(self.lighting, ['main_room', 0, 'lighting_light', 'level'])
            flag = flag & (lighting_light == '1')
        if flag:
            lighting_light = self.solve_dict(self.lighting, ['parlour', 0, 'lighting_light', 'level'])
            flag = flag & (lighting_light == '1')

        # 辅助检测点检测
        other_label = [ce.LABEL_ALL_WINDOW, ce.LABEL_NORTH_SOUTH_TRANS, ce.LABEL_KITCHEN_WINDOW, ce.LABEL_TOILET_WINDOW]
        other_label_list = list()
        if flag:
            for label in other_label:
                if self.label_value & ce.LABEL_DICT[label][0]:
                    other_label_list.append(label)
        return flag, other_label_list

    def detectQ2(self):
        """
        问题2检测：
        必备：对侧通风、明厨、明卫
        辅助：全明格局、南北通透
        :return: [flag, [other_label1, ohter_label2....]], flag表示必备检测点是否全部满足，都满足为True，第二个参数为辅助标签字符串列表。
        """
        # 必备检测点检测
        flag = True
        if flag:
            lighting_transparent = self.solve_dict(self.lighting, ['whole', 0, 'lighting_transparent', 'level'])
            flag = flag & (lighting_transparent == '1')
        main_label = [ce.LABEL_KITCHEN_WINDOW, ce.LABEL_TOILET_WINDOW]
        if flag:
            for label in main_label:
                if not (self.label_value & ce.LABEL_DICT[label][0]):
                    flag = False

        # 辅助检测点检测
        other_label = [ce.LABEL_ALL_WINDOW, ce.LABEL_NORTH_SOUTH_TRANS]
        other_label_list = list()
        if flag:
            for label in other_label:
                if self.label_value & ce.LABEL_DICT[label][0]:
                    other_label_list.append(label)
        return flag, other_label_list

    def detectQ3(self):
        """
        问题3检测：
        必备：户型方正、视线设计好、动线合理、动静分明
        辅助：主卧与入户门距离合理
        :return: [flag, [other_label1, ohter_label2....]], flag表示必备检测点是否全部满足，都满足为True，第二个参数为辅助标签字符串列表。
        """
        # 必备检测点检测
        flag = True
        main_label = [ce.LABEL_SQUARE, ce.LABEL_MOVEMENT_CLEAR]
        if flag:
            for label in main_label:
                if not (self.label_value & ce.LABEL_DICT[label][0]):
                    flag = False
        if flag:
            flag = flag & (self.line_cross_cnt < 3)
        if flag:
            summary_tag_visual_ratio = self.solve_dict(self.summary, ['whole', 0, 'summary_tag_visual_ratio'])
            flag = flag & (summary_tag_visual_ratio is not None)

        # 辅助检测点检测
        other_label_list = list()
        if flag:
            space_entrance_dis = self.solve_dict(self.space, ['main_room', 0, 'space_entrance_dis', 'level'])
            if space_entrance_dis == '1':
                other_label_list.append('main_room')

        return flag, other_label_list

    def detectQ4(self):
        """
        问题4检测：
        必备：户型方正、动线合理
        辅助：视线设计好、动静分明
        :return: [flag, [other_label1, ohter_label2....]], flag表示必备检测点是否全部满足，都满足为True，第二个参数为辅助标签字符串列表。
        """
        # 必备检测点检测
        flag = True
        main_label = [ce.LABEL_SQUARE]
        if flag:
            for label in main_label:
                if not (self.label_value & ce.LABEL_DICT[label][0]):
                    flag = False
        if flag:
            flag = flag & (self.line_cross_cnt < 3)

        # 辅助检测点检测
        other_label_list = list()
        if flag:
            summary_tag_visual_ratio = self.solve_dict(self.summary, ['whole', 0, 'summary_tag_visual_ratio'])
            if summary_tag_visual_ratio is not None:
                other_label_list.append('visual')

            other_label = [ce.LABEL_MOVEMENT_CLEAR]
            for label in other_label:
                if self.label_value & ce.LABEL_DICT[label][0]:
                    other_label_list.append(label)
        return flag, other_label_list

    def detectQ5(self):
        """
        问题5检测：
        必备：视线设计好、厨卫不对门、主卧与入户门距离合理
        辅助：户型方正、动线合理、动静分明
        :return: [flag, [other_label1, ohter_label2....]], flag表示必备检测点是否全部满足，都满足为True，第二个参数为辅助标签字符串列表。
        """
        # 必备检测点检测
        flag = True
        if flag:
            summary_tag_visual_ratio = self.solve_dict(self.summary, ['whole', 0, 'summary_tag_visual_ratio'])
            flag = flag & (summary_tag_visual_ratio is not None)
        if flag:
            summary_not_kitchen_face_toilet_space = self.solve_dict(self.summary, ['whole', 0, 'summary_not_kitchen_face_toilet_space'])
            flag = flag & (summary_not_kitchen_face_toilet_space is not None)
        if flag:
            space_entrance_dis = self.solve_dict(self.space, ['main_room', 0, 'space_entrance_dis', 'level'])
            flag = flag & (space_entrance_dis == '1')

        # 辅助检测点检测
        other_label_list = list()
        other_label = [ce.LABEL_SQUARE, ce.LABEL_MOVEMENT_CLEAR]
        if flag:
            for label in other_label:
                if self.label_value & ce.LABEL_DICT[label][0]:
                    other_label_list.append(label)
            good_active_line = (self.line_cross_cnt < 3)
            if good_active_line is not None:
                other_label_list.append('good_active_line')
        return flag, other_label_list

    def detectQ6(self):
        """
        问题6检测：
        必备：分间面积合理、客餐厅面积大/适中、主卧面积大/适中
        辅助：次卧面积大/适中、厨房面积大/适中、卫生间面积大/合理
        :return: [flag, [other_label1, ohter_label2....]], flag表示必备检测点是否全部满足，都满足为True，第二个参数为辅助标签字符串列表。
        """
        # 必备检测点检测
        flag = True
        if flag:
            summary_area_logical = self.solve_dict(self.summary, ['whole', 0, 'summary_area_logical'])
            flag = flag & (summary_area_logical is not None)
        if flag:
            function_area_size = self.solve_dict(self.function, ['main_room', 0, 'function_area_size', 'level'])
            flag = flag & (function_area_size == '1' or function_area_size == '2')
        if flag:
            function_area_size = self.solve_dict(self.function, ['parlour', 0, 'function_area_size', 'level'])
            flag = flag & (function_area_size == '1' or function_area_size == '2')

        # 辅助检测点检测
        other_label_list = list()
        if flag:
            function_area_size = self.solve_dict(self.function, ['kitchen', 0, 'function_area_size', 'level'])
            if function_area_size == '1' or function_area_size == '2':
                other_label_list.append('kitchen')
            function_area_size = self.solve_dict(self.function, ['sub_room', 0, 'function_area_size', 'level'])
            if function_area_size == '1' or function_area_size == '2':
                other_label_list.append('sub_room')
            function_area_size = self.solve_dict(self.function, ['parlour_toilet', 0, 'function_area_size', 'level'])
            if function_area_size == '1' or function_area_size == '2':
                other_label_list.append('parlour_toilet')
        return flag, other_label_list

    def detectQ7(self):
        """
        问题7检测：
        必备：分间面积合理、带阳台、主卧带卫生间
        辅助：带衣帽间、带花园、带阁楼、带露台
        :return: [flag, [other_label1, ohter_label2....]], flag表示必备检测点是否全部满足，都满足为True，第二个参数为辅助标签字符串列表。
        """
        # 必备检测点检测
        flag = True
        if flag:
            summary_area_logical = self.solve_dict(self.summary, ['whole', 0, 'summary_area_logical'])
            flag = flag & (summary_area_logical is not None)
        if flag:
            balcony_flag = False
            function_with_balcony = self.solve_dict(self.function, ['main_room', 0, 'function_with_balcony'])
            balcony_flag |= (function_with_balcony is not None)
            function_with_balcony = self.solve_dict(self.function, ['parlour', 0, 'function_with_balcony'])
            balcony_flag |= (function_with_balcony is not None)
            function_with_balcony = self.solve_dict(self.function, ['sub_room', 0, 'function_with_balcony'])
            balcony_flag |= (function_with_balcony is not None)
            flag = flag & balcony_flag

        # 辅助检测点检测
        other_label_list = list()
        if flag:
            summary_tag_garden = self.solve_dict(self.summary, ['whole', 0, 'summary_tag_garden'])
            if summary_tag_garden is not None:
                other_label_list.append('garden')
            summary_tag_loft = self.solve_dict(self.summary, ['whole', 0, 'summary_tag_loft'])
            if summary_tag_loft is not None:
                other_label_list.append('loft')
            summary_tag_terrace = self.solve_dict(self.summary, ['whole', 0, 'summary_tag_terrace'])
            if summary_tag_terrace is not None:
                other_label_list.append('terrace')
            summary_tag_bedroom_cloakroom = self.solve_dict(self.summary, ['whole', 0, 'summary_tag_bedroom_cloakroom'])
            if summary_tag_bedroom_cloakroom is not None:
                other_label_list.append('cloakroom')

        return flag, other_label_list

    def convert_str(self, question, other_label_list):
        """
        将ohter_label_list列表中的字符串映射并拼接成other_label_str
        :param question: 该label_list属于哪个问题
        :param other_label_list: 辅助标签字符串列表
        :return: other_label_str字符串，用于生成文案
        """
        res_str = ''
        num = question[1]
        for index, label in enumerate(other_label_list):
            label = label + num
            if index == len(other_label_list) - 1:
                res_str = res_str + str_map[label]
            else:
                res_str = res_str + str_map[label] + '、'
        return res_str


if __name__ == '__main__':
    pass
