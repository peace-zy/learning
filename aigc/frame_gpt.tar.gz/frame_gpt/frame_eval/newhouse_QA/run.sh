# hdfs 上部署的python环境
HDFS_PYTHON_PATH="hdfs://ns-fed/user/strategy/yudonghai/python.tgz#python"
# 本地python命令, 21.21上的配置
PYTHON_CMD="/home/work/zhucheng011/python/python27/bin/python2"
source bin/utils.sh

function frame_newhouse_QA(){
    pt_date=$1

    spark-submit --py-files lib.zip \
    --conf spark.yarn.executor.memoryOverhead=7G \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    --conf spark.pyspark.driver.python=${PYTHON_CMD} \
    frame_eval/newhouse_QA/spark_main.py -pt_date  "$pt_date" -config_file frame_eval/newhouse_QA/conf_newhouse_QA.yml
}

function main
{
    if [[ $# -lt 1 ]] ; then
        echo "error! lack <job_name>"
        usage
    fi
    job_name=$1
    echo "TASK: ${job_name}  "

    zip -q -r ./lib.zip ./*

    case ${job_name} in
        frame_newhouse_QA )
        pt_data=$2
        frame_newhouse_QA "$pt_data"
        ;;

        * )

        echo "error! invalid <job_name>"
        usage
        ;;

    esac
}

main $*