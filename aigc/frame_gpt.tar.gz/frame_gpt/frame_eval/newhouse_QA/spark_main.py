# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/1/4 12:00
# ===================================

import argparse
import collections
import copy
import datetime
import json
import logging
import sys
import yaml

import functools
from collections import defaultdict

from lib import spark_util_v2
from lib.file_util import get_file_stream
import frame_eval.frame_tag_lib.utils as tag_utils
from frame_eval.newhouse_QA.qa_lib import QuestionDetect, compare_rule


def generateQA(resblock_id, frame_group, column_names, **params):
    """
    通过spark的flagMap调用函数，生成最终落表的数据
    :param resblock_id: 小区id
    :param frame_group: 通过小区id group by后的数据
    :param column_names: 列名
    :param params: 包含yml配置文件里的文案
    :return: [[], [], []....]列表中的每个列表都对应该小区不同居室数对应的落表数据
    """
    result = list()
    city_code = None
    df = spark_util_v2.spark_group2pandas_df(frame_group, column_names)
    QA_dict = defaultdict(list)
    # 对每个户型检测7个问题，如果有对应的问题则存储在QA_dict中，key为Q1234567，value为[room_cnt, [label1,label2...], QA_obj对象]
    for index, row in df.iterrows():
        try:
            QA_obj = QuestionDetect(row)
            flag1, other_label_list1 = QA_obj.detectQ1()
            if flag1:
                QA_dict['Q1'].append([int(row['room_cnt']), other_label_list1, QA_obj])
            flag2, other_label_list2 = QA_obj.detectQ2()
            if flag2:
                QA_dict['Q2'].append([int(row['room_cnt']), other_label_list2, QA_obj])
            flag3, other_label_list3 = QA_obj.detectQ3()
            if flag3:
                QA_dict['Q3'].append([int(row['room_cnt']), other_label_list3, QA_obj])
            flag4, other_label_list4 = QA_obj.detectQ4()
            if flag4:
                QA_dict['Q4'].append([int(row['room_cnt']), other_label_list4, QA_obj])
            flag5, other_label_list5 = QA_obj.detectQ5()
            if flag5:
                QA_dict['Q5'].append([int(row['room_cnt']), other_label_list5, QA_obj])
            flag6, other_label_list6 = QA_obj.detectQ6()
            if flag6:
                QA_dict['Q6'].append([int(row['room_cnt']), other_label_list6, QA_obj])
            flag7, other_label_list7 = QA_obj.detectQ7()
            if flag7:
                QA_dict['Q7'].append([int(row['room_cnt']), other_label_list7, QA_obj])
            city_code = row['city_code']
        except Exception as e:
            continue

    # id_used集合查看哪些居室数出现过
    id_used = set()
    for _key, _value in QA_dict.items():
        # 将每个问题下的list按照辅助标签长度和总分排序
        QA_dict[_key] = sorted(QA_dict[_key], key=functools.cmp_to_key(compare_rule))
        list_tmp = list()
        use_tmp = collections.defaultdict(lambda: False)
        for v in QA_dict[_key]:
            if use_tmp[v[0]] is False:
                list_tmp.append(v)
                id_used.add(v[0])
                use_tmp[v[0]] = True
        QA_dict[_key] = copy.deepcopy(list_tmp)
    tmp_default = {'resblock_id': str(int(resblock_id)),
                   'room_cnt': -1,
                   'q_cnt': 0,
                   'id_list': list()}
    # result_dict的key为居室数，value为qa_doc字典
    result_dict = dict()
    for _value in id_used:
        tmp_default['room_cnt'] = _value
        result_dict[_value] = copy.deepcopy(tmp_default)
    for _Q, _l in QA_dict.items():
        for _frame in _l:
            Q_dict = dict()
            room_cnt = _frame[0]

            var_dict = dict()
            var_dict['room_cnt'] = room_cnt
            var_dict['floor_area'] = _frame[2].floor_area
            var_dict['parlor_cnt'] = _frame[2].parlor_cnt
            var_dict['toilet_cnt'] = _frame[2].toilet_cnt

            Q_dict['id'] = params[_Q]['id']
            Q_dict['class'] = params[_Q]['class']
            Q_dict['question'] = params[_Q]['question'].format(**var_dict)
            Q_dict['answer'] = params[_Q]['answer'].format(**var_dict)
            if len(_frame[1]) > 0:
                other_label_str = _frame[2].convert_str(_Q, _frame[1]).decode('utf8')
                var_dict['other_label_str'] = other_label_str
                Q_dict['answer'] += params[_Q]['addition'].format(**var_dict)
            Q_dict['frame_id'] = _frame[2].frame_id
            Q_dict['img_url'] = _frame[2].img_url
            result_dict[room_cnt][_Q] = Q_dict
            result_dict[room_cnt]['q_cnt'] += 1
            result_dict[room_cnt]['id_list'].append(Q_dict['id'])
            result_dict[room_cnt]['id_list'] = list(set(result_dict[room_cnt]['id_list']))
    for _rt, _value in result_dict.items():
        result.append([str(int(resblock_id)), _rt, json.dumps(_value), _value['q_cnt'], city_code, ''])
    return result


class FrameNewhouseQA(spark_util_v2.SparkLogic):
    def logic_func(self, spark_driver, raw_df_dict, **params):
        frame_feature_df = raw_df_dict['frame_feature']
        names = ['resblock_id', 'frame_id', 'room_cnt', 'parlor_cnt', 'toilet_cnt', 'floor_area',
                 'label_value', 'feature', 'doc', 'image_url',
                 'living_guest_cross', 'work_guest_cross', 'living_work_cross', 'city_code']
        frame_feature_df = frame_feature_df.toDF(*names)
        column_names = frame_feature_df.schema.names
        # 按照小区id进行group
        frame_group = frame_feature_df.rdd.groupBy(lambda row: row['resblock_id'])

        params_conf = params['params']['doc']
        result_rdd = frame_group.flatMap(lambda row: generateQA(row[0], row[1], column_names, **params_conf))

        name_result = ['resblock_id', 'room_cnt', 'qa_doc', 'question_cnt', 'city_code', 'error']
        result_df = spark_driver.rdd_2_df(result_rdd).toDF(*name_result)

        save_dict = {
            "frame_newhouse_qa": result_df
        }
        return save_dict


def main(pt_date, config_file, debug=False):
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    f = get_file_stream(config_file)
    conf = yaml.load(f)
    spark_config_key = "frame_newhouse_qa"
    spark_params = conf.get(spark_config_key, None)

    conf_param_tmp = dict()
    tag_utils.collect_conf_on_spark(r"frame_eval/newhouse_QA/conf_doc.yml", conf_param_tmp)
    spark_params['logic_params']['logic_function_params']['params'].update(conf_param_tmp)

    city_code = conf["params"]["city_code"]
    spark_params["sql_params"]["sql_vars"] = {
        "pt_date": pt_date,
        "city_code": city_code
    }
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_class"] = FrameNewhouseQA
    # 存储pt
    for save_name in spark_params["save_params"]:
        spark_params["save_params"][save_name]["partition_params"] = {
            "pt": "{}000000".format(pt_date)
        }
    spark_driver = spark_util_v2.SparkSqlDriver(debug=debug, **spark_params)
    spark_driver.run()
    return spark_driver


def case_study():
    import pandas as pd
    df = pd.read_csv('D:/newhouse_line_group.tsv', sep='\t')
    names = ['resblock_id', 'frame_id', 'room_cnt', 'parlor_cnt', 'toilet_cnt', 'floor_area',
             'label_value', 'feature', 'doc', 'basic_info', 'city_code']
    f = get_file_stream('frame_eval/newhouse_QA/conf_newhouse_QA.yml')
    conf = yaml.load(f)
    result = generateQA('3511063924482', df, names, **conf['params']['doc'])
    pass


if __name__ == '__main__':
    current_pt_date = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y%m%d")

    parser = argparse.ArgumentParser(description='')
    parser.add_argument("-pt_date", default=current_pt_date, help="")
    parser.add_argument("-config_file", default="frame_eval/newhouse_QA/conf_newhouse_QA.yml", help="")
    args = parser.parse_args()

    if sys.platform not in ["win32", "darwin"]:
        main(args.pt_date, args.config_file)
    else:
        case_study()
    pass
