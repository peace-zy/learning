# coding=utf-8
import json
import logging
import sys
import yaml
import os
import traceback

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../.."))
sys.path.insert(0, os.getcwd())

import frame_remould.utils.spark_util as spark_util
from lib import entity
from lib import label_functions
from lib import eval_main
from lib import code_enum as ce


def get_result(frame):

    # 每个功能区朝向
    sta_ke_list = ['living', 'dining', 'room', 'schoolroom', 'toilet', 'kitchen', 'sub_room', 'main_room']
    # all_list = ['living', 'dining', 'room', 'schoolroom', 'toilet', 'kitchen', 'sub_room', 'main_room'
    #             'frame_size', 'floor_area', 'original_url', 'standard_url']
    all_list = sta_ke_list + ['frame_size', 'floor_area', 'original_url', 'standard_url']
    statistic_key = {
        'living': 'living',
        'dining': 'dining',
        'room': 'room',
        'schoolroom': 'schoolroom',
        'toilet': 'toilet',
        'kitchen': 'kitchen',
        'sub_room': 'sub_room',
        'main_room': 'main_room',
    }
    statistic_key2 = dict()
    for k, v in statistic_key.items():
        statistic_key2[k] = set()

    if frame is None:
        # 注意： 返回空的个数和table names个数一直
        result = []
        result.append('888')
        for k in all_list:
            result.append('')
        # for k, v in statistic_key.items():
        #     result.append('')
        # result.append('')
        # result.append('')
        return result

    frame_vector = frame.vector
    areas_dict = {}
    for plan_vector in frame_vector[frame.plan_key]:
        areas_dict.update(plan_vector[ce.AREAS_DICT_KEY])

    for plan_vector in frame_vector[frame.plan_key]:
        areas = plan_vector[ce.PLAN_AREAS_KEY]
        floor_vectors = []
        # 逐分间
        for area in areas:
            area_id = area[ce.AREA_ID_KEY]
            area_type = areas_dict[area_id][ce.AREA_ROOM_TYPE_KEY]
            area_type_key = areas_dict[area_id][ce.AREA_TYPE_KEY]
            main_room_id = frame.explain_message["explain_whole_frame"][1]

            # res_dict = frame.explain_message['explain_face'].get(area_id)
            res_dict = frame.explain_message['explain_size'][area_id]
            if res_dict is None:
                continue

            res = res_dict[0] * 1.0 / 1000 / 1000

            if area_type == ce.AreaType.toilet.value:
                statistic_key2['toilet'].add(res)
            elif area_type == ce.AreaType.kitchen.value:
                statistic_key2['kitchen'].add(res)
            elif area_type == ce.AreaType.room.value:
                if area_type_key == 3:
                    statistic_key2['room'].add(res)
                    if area_id == main_room_id:
                        statistic_key2['main_room'].add(res)
                    else:
                        statistic_key2['sub_room'].add(res)
                elif area_type_key == 4:
                    statistic_key2['schoolroom'].add(res)
            elif area_type == ce.AreaType.parlour.value:
                if area_type_key == 1:
                    statistic_key2['living'].add(res)
                elif area_type_key == 2:
                    statistic_key2['dining'].add(res)
    result = [frame.frame_id]
    for r_type in sta_ke_list:
        res = list(statistic_key2[r_type])
        # res = [d.encode('utf8') for d in res]
        result.append(json.dumps(res))

    # 套内面积
    result.append(round(frame.frame_size, 1))

    return result


def get_row_result(row, **params):
    input = {
        'frame_id': row['frame_id'],
        'image_id': 'image_id',
        'vector_value': row['vector'],
        'city_code': 'city_code',
    }
    res = get_every_frame_result(input, **params)
    if res[1] != '':
        update_result(res, row)
    return res


def update_result(res, row):
    """更新一些frame类中没有，从其他表中拉取的数据"""
    floor_area = row['floor_area']
    res.append(round(floor_area, 1))
    res.append(row['original_url'])
    res.append(row['standard_url'])


def get_every_frame_result(row, **params):
    frame = entity.Frame(row)
    try:
        # 标签
        frame.add_label(label_functions.label_base, **params)
        # 检测点
        eval_main.base_explain(frame, **params)
        result = get_result(frame)
    except Exception as e:
        traceback.print_exc()
        result = get_result(None)
    return result


def logic_func(driver, raw_df, **params):
    result_rdd = raw_df.rdd.map(lambda row: get_row_result(row, **params))
    result_df = driver.rdd_2_df(result_rdd)
    names = params["table_names"]
    result_df = result_df.toDF(*names)
    return result_df


def main():
    """ 主函数 """
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    if len(sys.argv) < 3:
        logging.error("no less than 2 arguments!")
        sys.exit()

    pt_date = sys.argv[1]
    config_file = sys.argv[2]

    with open(config_file, "r") as config_data:
        conf = yaml.load(config_data)

    # 从配置文件读取参数
    spark_config_key = "static_newhouse_config"
    spark_params = conf.get(spark_config_key, None)
    if spark_params is None:
        logging.error("lack {} in config file".format(spark_config_key))
        sys.exit(-1)

    # ## 补充参数
    # pt
    spark_params["sql_params"]["pt_date"] = pt_date
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_function"] = logic_func
    # 存储pt
    spark_params["save_params"]["partition_params"] = {"pt": "{}000000".format(pt_date)}

    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()


def test(frameid):
    from frame_eval.test.local_deco_test import get_frame_vector
    from frame_eval.test.local_deco_test import collect_conf_single
    conf = collect_conf_single("config/eval_base_conf.yml")
    with open("config/eval_liner_conf.yml", "r") as conf_data:
        eval_liner_conf = yaml.load(conf_data)
        conf.update(eval_liner_conf)
    with open("config/eval_conf.yml", "r") as conf_data:
        eval_conf = yaml.load(conf_data)
        conf.update(eval_conf)
    with open("frame_eval/test/conf_static_newhouse.yml", "r") as conf_data:
        eval_conf = yaml.load(conf_data)
        conf.update(eval_conf)

    frameid, line = get_frame_vector(frameid)
    # res = get_every_area_face(line, **conf['eval_base'])

    items = line.split('\t')
    input = {
        'frame_id': items[0],
        'vector': items[2],
        'floor_area': 87.1,
        'original_url': 'a',
        'standard_url': 'b',
    }
    res = get_row_result(input, **conf['eval_base'])
    tmp = 0


if __name__ == "__main__":
    main()
    # test(12000011795551)
