SELECT table_1.frame_id, original_url, standard_url, vector, floor_area
FROM (SELECT table_0.frame_id, original_url, standard_url, vector, floor_area, ROW_NUMBER() OVER(PARTITION BY table_0.frame_id ORDER BY floor_area desc) AS rn
 FROM (SELECT vector_table.frame_id, original_url, standard_url, vector, floor_area
	  FROM (SELECT frame_id, original_url, standard_url, vector FROM data_mining.data_mining_framex_vector_hbase_da WHERE pt='{pt_date}000000'
	  and original_from=2 and original_type = 5 and vector_from = 2) vector_table
	  JOIN
	  (SELECT frame_id, floor_area
	  FROM dw.dw_house_newhouse_resblockdel_frame_mapping_da
	  WHERE pt='{pt_date}000000') mapping
	  ON vector_table.frame_id=mapping.frame_id) table_0) table_1
WHERE table_1.rn=1