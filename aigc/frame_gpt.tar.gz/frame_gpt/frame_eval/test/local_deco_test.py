# coding=utf-8
import os
import json
import yaml
import boto3
import logging
import requests

import frame_eval.decoration_v2.decoration_spark as decoration_spark
import frame_remould.utils.vis as vis
import frame_eval.feature_base_spark as feature_base_spark
import web_server.api_lib as api_lib

SAVE_PATH = r"../../data/decoration/"

S3_AK = "223HG43LGIX9W3MWTOCL"
S3_AKS = "tqWXh8kSyxM/QfgF34dMXFJcRrIIGfIIZkVVjSMH"

FRAME_MINER_URL = r'http://i.data.api.lianjia.com/v2/meta/frame_miner'
APPKEY = 'frame_analysis'
SECRET = 'c338b06a92d4400edcbf11c03979241a'
PERFIX = r'http://storage.lianjia.com/'


def get_s3_client():
    logging.basicConfig(level=logging.DEBUG, format='%(asctime)s %(levelname)s %(message)s')
    s3_client = boto3.client('s3', region_name="cn-north-1", endpoint_url="http://storage.lianjia.com",
                             aws_access_key_id=S3_AK,
                             aws_secret_access_key=S3_AKS)
    return s3_client


def res2md(res, frame_vector):
    frame_id = res[0]
    img_path = os.path.join(SAVE_PATH, frame_id + ".png")
    if frame_id != '888':
        img = vis.plot_floorplan(frame_vector)
        img.save(os.path.join(SAVE_PATH, frame_id + ".png"))
    frame_file = os.path.join(SAVE_PATH, frame_id + ".md")
    file_write_obj = open(frame_file, 'w')
    frame_label = json.loads(res[11])
    for room, label in frame_label.items():
        title0 = " ".join(["#", label['space_name'].encode('utf8')])
        file_write_obj.writelines(title0)
        file_write_obj.writelines('\n')

        img_md = ''.join(['![avatar](', img_path, ') \n'])
        # ![avatar](. / 11000005438640.png)
        file_write_obj.writelines(img_md)

        for doc in label['doc']:
            for dim in doc['dims']:
                title1 = " ".join(['###', 'title:', dim['title'].encode('utf8'), '\n\n'])
                file_write_obj.writelines(title1)
                annotation = ' '.join(['-', 'annotation:', dim['annotation'].encode('utf8'), '\n'])
                file_write_obj.writelines(annotation)
                detail = ' '.join(['-', 'detail:', dim['detail'].encode('utf8'), '\n'])
                file_write_obj.writelines(detail)
                merit = ' '.join(['-', 'merit:', dim['merit'].encode('utf8'), '\n'])
                file_write_obj.writelines(merit)
                merit = ' '.join(['-', 'display:', dim['display'].encode('utf8'), '\n'])
                file_write_obj.writelines(merit)

    file_write_obj.close()


def get_img_url(frame_id):
    url = '888'
    if frame_id != '888':
        r = api_lib.request_bigdata_api(FRAME_MINER_URL,
                                    {'frame_ids': frame_id},
                                    key=APPKEY,
                                    secret=SECRET)
        url = PERFIX + r['data'][0]['image_url']
    return url

def res2md_v2(res, frame_vector):
    frame_id = res[0]
    img_path = get_img_url(frame_id)
    # if frame_id != '888':
    #     img = vis.plot_floorplan(frame_vector)
    frame_file = os.path.join(SAVE_PATH, frame_id + ".md")
    file_write_obj = open(frame_file, 'w')
    frame_label = json.loads(res[11])
    for room, label in frame_label.items():
        title0 = " ".join(["#", label['space_name'].encode('utf8')])
        file_write_obj.writelines(title0)
        file_write_obj.writelines('\n')

        img_md = ''.join(['![avatar](', img_path, ') \n'])
        # ![avatar](. / 11000005438640.png)
        file_write_obj.writelines(img_md)

        for doc in label['doc']:
            for dim in doc['dims']:
                title1 = " ".join(['###', 'title:', dim['title'].encode('utf8'), '\n\n'])
                file_write_obj.writelines(title1)
                annotation = ' '.join(['-', 'annotation:', dim['annotation'].encode('utf8'), '\n'])
                file_write_obj.writelines(annotation)
                detail = ' '.join(['-', 'detail:', dim['detail'].encode('utf8'), '\n'])
                file_write_obj.writelines(detail)
                merit = ' '.join(['-', 'merit:', dim['merit'].encode('utf8'), '\n'])
                file_write_obj.writelines(merit)
                merit = ' '.join(['-', 'display:', dim['display'].encode('utf8'), '\n'])
                file_write_obj.writelines(merit)

    file_write_obj.close()


def collect_conf():
    total_conf = {}
    # with open("../../config/eval_base_conf.yml", "r") as conf_data:
    #     eval_base_conf = yaml.load(conf_data)
    #     total_conf.update(eval_base_conf)
    # with open("../../config/frame_label_conf.yml", "r") as conf_data:
    #     eval_base_conf = yaml.load(conf_data)
    #     total_conf.update(eval_base_conf)
    # with open("../../config/eval_liner_conf.yml", "r") as conf_data:
    #     eval_liner_conf = yaml.load(conf_data)
    #     total_conf.update(eval_liner_conf)
    # with open("../../config/eval_conf.yml", "r") as conf_data:
    #     eval_conf = yaml.load(conf_data)
    #     total_conf.update(eval_conf)
    with open("../../config/decoration_conf_v2.yml", "r") as conf_data:
        # with open("../../config/decoration_conf.yml", "r") as conf_data:
        eval_conf = yaml.load(conf_data)
        total_conf.update(eval_conf)

    return total_conf


def collect_conf_single(config_path):
    total_conf = {}
    with open(config_path, "r") as conf_data:
        eval_conf = yaml.load(conf_data)
        total_conf.update(eval_conf)

    # with open(r'D:\a.yml', "w") as f:
    #     f = yaml.safe_dump(total_conf, f)
    return total_conf


def ana_single_deco(frame):
    conf = collect_conf()
    frame_id, line = get_frame_vector(frame)
    _, res = decoration_spark.frame_decoration_feature(line, debug=True, **conf)
    res2md_v2(res, line.split('\t')[2])
    return None


def get_frame_vector(frame):
    if type(frame) != str:
        frame_id = str(frame)
        s3_client = get_s3_client()
        vector_response = s3_client.get_object(Bucket='frame-eval-image', Key=str(frame_id) + '.json')
        vector_str = vector_response['Body'].read()
        line = "\t".join([frame_id, 'image_id', vector_str, 'city_code'])
    elif type(frame) == str:
        with open(frame, 'r') as f:
            ke_json = json.load(f)
        frame_id = str(888)
        line = "\t".join([frame_id, 'image_id', json.dumps(ke_json), 'city_code'])

    return frame_id, line


def ana_base_feature(frame):
    conf = collect_conf_single("../../config/eval_base_conf.yml")
    # conf = collect_conf_single("../../config/decoration_conf_v2.yml")
    frame_id, line = get_frame_vector(frame)

    base_frame, base_result = feature_base_spark.frame_analysis_base(line, debug=True, **conf["eval_base"])

    return None


if __name__ == "__main__":
    # json_path = r"D:\ke\data\more_frame_json\11000002082029.json"
    json_path = r"D:\frame.json"
    # for frame_id in (11000002380307, 11000013003179, 11000001064656,11000005438640, 11000002244109,11000002348507,11000002324206,11000002289129,11000002263368,11000002244203,
    #                11000002040904,11000001946790,11000001609082,11000001357643,11000000432934,11000000633475,):
    #     frame_id = 11000005438640
        # ana_single_deco(frame_id)
    # frame_id = 11000005039640
    # frame_id = 11000013003179  # 两个卧室带卫
    ana_single_deco(json_path)
    # ana_base_feature(json_path)
