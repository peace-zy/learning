zip -q -r ./lib.zip ./lib ./frame_remould ./frame_eval

spark-submit --conf spark.dynamicAllocation.maxExecutors=160 \
             --conf spark.yarn.dist.archives="hdfs://ns-fed/user/strategy/zhuc/python2713.zip#python" \
             --conf spark.pyspark.python="python/bin/python2.7" \
             --conf spark.pyspark.driver.python="/home/work/zhuc/python/python2713/bin/python2.7" \
              --py-files lib.zip \
             frame_eval/test/static_newhouse.py 20210426 frame_eval/test/conf_static_newhouse.yml
