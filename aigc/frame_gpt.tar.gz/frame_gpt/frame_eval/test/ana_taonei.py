# coding=utf-8

import requests
import base64
import os

import sys
reload(sys)
sys.setdefaultencoding('utf-8')


def get_access_token():
    host = 'https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=HaGSONhiaikDddxR4LfGWkiA&client_secret=EIT5S5UWuLhYawW5D3md0bvb79rntvLm'
    response = requests.get(host)
    if response:
        print(response.json())
        access_token = response.json()['access_token']
        return access_token
    return None


def if_img_contain_taonei(img_file, access_token):
    request_url = "https://aip.baidubce.com/rest/2.0/ocr/v1/accurate_basic"
    # 二进制方式打开图片文件
    f = open(img_file, 'rb')
    img = base64.b64encode(f.read())

    params = {"image": img}
    # access_token = '24.cc7c36e50d8bbdf2f04db3a0bb48c00e.2592000.1573816544.282335-16614180'
    request_url = request_url + "?access_token=" + access_token
    headers = {'content-type': 'application/x-www-form-urlencoded'}
    response = requests.post(request_url, data=params, headers=headers)
    if response:
        print (response.json())
        taonei = '套内'
        taone_u = taonei.encode('unicode-escape').decode()
        word_dict = response.json()['words_result']
        flag = False
        for w in word_dict:
            if taonei in w['words']:
                flag = True
        return flag
    else:
        # assert False, "abc"
        return False


def main1():
    import shutil
    source_dir = r"D:\tsv\newhouse"
    # source_dir = r"D:\tsv\taonei_0"
    all_img = os.listdir(source_dir)
    access_token = get_access_token()
    target_dir = r"D:\tsv\taonei"
    for idx, img in enumerate(all_img):
        if idx < 800:
            continue
        print(idx)
        img_file = os.path.join(r"D:\tsv\newhouse", img)
        flag = if_img_contain_taonei(img_file, access_token)
        if flag:
            shutil.copy(img_file, os.path.join(target_dir, img))

        tmp =0
    tmp = 0

if __name__ == "__main__":
    main1()