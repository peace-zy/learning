# coding=utf-8
import pandas as pd
import os
import json
import sys

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../.."))
sys.path.insert(0, os.getcwd())


STATIC_KEY = {
    "moving_line": "moving_line",
    "width_depth": "width_depth",
    "square": "square",
    "chuwei_face": "chuwei_face",
    "toilet_face_entrance": "toilet_face_entrance",
    "room_face_others": "room_face_others",
    "gray_zone": "gray_zone",
    "wdf": "wdf",
    "moving_quiet": "moving_quiet",
    "convex": "convex",
}


def get_sta(df_notnull, col_str):
    null_num = df_notnull[df_notnull[col_str].isnull()].shape[0]
    m1_num = df_notnull[df_notnull[col_str]==-1].shape[0]
    p1_num = df_notnull[df_notnull[col_str]==1].shape[0]
    z0_num = df_notnull[df_notnull[col_str] == 0].shape[0]
    return [null_num, m1_num, p1_num, z0_num]


def main1():
    file_path = r"D:\tsv\res.tsv"
    df = pd.read_csv(file_path, sep="\t", encoding='cp1252')

    df_null = df[df['moving_line'].isnull() & df['width_depth'].isnull()]
    df_notnull = df[df['moving_line'].notnull() & df['width_depth'].notnull()]

    sta = dict()
    sta_pre = dict()
    notnull_num = df_notnull.shape[0]

    for k, v in STATIC_KEY.items():
        sta[k] = get_sta(df_notnull, v)
        sta_pre[k] = [a/float(notnull_num) for a in sta[k]]


def main2():
    """分析得房率"""
    import math
    file_path = r"D:\tsv\zhuc.txt"
    # file_path = r"D:\tsv\zhuc_318.txt"
    df = pd.read_csv(file_path, sep="\t", encoding='cp1252')

    area_rates = []
    for idx, row in df.iterrows():
        frame_size = row['frame_size']
        floor_area = row['floor_area']
        if math.isnan(frame_size):
            continue
        if floor_area != 0:
            area_rates.append(floor_area)
            # area_rates.append(frame_size / floor_area)

    tmp = 0
    import matplotlib.pylab as plt
    import numpy as np
    plt.hist(area_rates, bins=50, range=(0, 2))


def get_original_url():
    """提取开发商图片"""
    save_path = r"D:\tsv\newhouse_std"
    file_path = r"D:\tsv\new318_all.tsv"
    df = pd.read_csv(file_path, sep="\t", encoding='cp1252')

    import requests
    from io import BytesIO
    from PIL import Image
    import yaml
    from frame_eval.test.local_deco_test import collect_conf_single
    from frame_eval.test.local_deco_test import get_frame_vector
    from lib import entity

    conf = collect_conf_single("config/eval_base_conf.yml")
    with open("config/eval_liner_conf.yml", "r") as conf_data:
        eval_liner_conf = yaml.load(conf_data)
        conf.update(eval_liner_conf)
    with open("config/eval_conf.yml", "r") as conf_data:
        eval_conf = yaml.load(conf_data)
        conf.update(eval_conf)
    with open("frame_eval/test/conf_static_newhouse.yml", "r") as conf_data:
        eval_conf = yaml.load(conf_data)
        conf.update(eval_conf)

    for idx, row in df.iterrows():
        print(idx)
        ori_url = row['original_url']
        frame_id = row['frame_id']
        vector = row['vector'].encode('utf8')
        standard_url = row['standard_url']

        # response = requests.get(ori_url)
        # image = Image.open(BytesIO(response.content))
        # img_name = str(frame_id) + '.jpg'
        # image.save(os.path.join(save_path, img_name))
        #
        response = requests.get(standard_url)
        image = Image.open(BytesIO(response.content))
        img_name = str(frame_id) + '_std.png'
        image.save(os.path.join(save_path, img_name))

        # vec_file = os.path.join(save_path, str(frame_id) + '.json')
        # with open(vec_file, "w") as f:
        #     json.dump(json.loads(vector), f, indent=4)
        # frameid, line = get_frame_vector(vec_file)
        # frame = entity.Frame(line)
        # tmp = 0


def get_rule_fp_rate():
    """有标尺的得房率"""
    import math
    file_path = r"D:\tsv\newhouse_318_all.txt"
    df = pd.read_csv(file_path, sep="\t", encoding='cp1252')

    rule_dir = r"D:\tsv\newhouse_rule"

    rule_files = os.listdir(rule_dir)

    frame_id_large_rate = dict()
    area_rates = []

    living_areas, ding_areas, room_areas, schoolroom_areas = [], [], [], []
    toilet_areas, kitchen_areas, sub_room_areas, main_room_areas = [], [], [], []
    for file in rule_files:
        frame_id = long(file.split('.')[0])
        row = df[df['frame_id']==frame_id]
        if row.shape[0] >= 1:
            frame_size = row.iloc[0]['frame_size']
            floor_area = row.iloc[0]['floor_area']
            if math.isnan(frame_size):
                continue
            if floor_area == 0:
                continue
            area_rates.append(frame_size / floor_area)

            if frame_size / floor_area > 1:
                frame_id_large_rate[frame_id] = frame_size / floor_area

            if frame_size / floor_area < 0.9:
                living_areas.extend(json.loads(row.iloc[0]['living']))
                ding_areas.extend(json.loads(row.iloc[0]['dining']))
                room_areas.extend(json.loads(row.iloc[0]['room']))
                schoolroom_areas.extend(json.loads(row.iloc[0]['schoolroom']))
                toilet_areas.extend(json.loads(row.iloc[0]['toilet']))
                kitchen_areas.extend(json.loads(row.iloc[0]['kitchen']))
                sub_room_areas.extend(json.loads(row.iloc[0]['sub_room']))
                main_room_areas.extend(json.loads(row.iloc[0]['main_room']))

    import matplotlib.pylab as plt
    plt.hist(area_rates, bins=50, range=(0, 2))

    target_dir = r"D:\tsv\house_rate"
    std_dir = r"D:\tsv\newhouse_std"
    vec_dir = r"D:\tsv\newhouse_json"

    import shutil
    for k, v in frame_id_large_rate.items():
        ori_img = os.path.join(rule_dir, str(k) + ".jpg")
        ori_img2 = os.path.join(target_dir, str(k) + ".jpg")
        shutil.copy(ori_img, ori_img2)



    for k, v in frame_id_large_rate.items():
        ori_img = os.path.join(rule_dir, str(k) + ".jpg")
        std_img = os.path.join(std_dir, str(k) + "_std.png")
        ori_img2 = os.path.join(target_dir, str(k) + ".jpg")
        std_img2 = os.path.join(target_dir, str(k) + "_std.png")
        ori_json = os.path.join(vec_dir, str(k) + ".json")
        ori_json2 = os.path.join(target_dir, str(k) + ".json")

        shutil.copy(ori_img, ori_img2)
        shutil.copy(std_img, std_img2)
        shutil.copy(ori_json, ori_json2)


if __name__ == "__main__":
    # main2()
    # get_original_url()
    get_rule_fp_rate()