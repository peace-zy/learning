# coding=utf-8
import yaml
import json
import pandas as pd
from multiprocessing import Pool
import os
import sys
import time

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../"))
sys.path.insert(0, os.getcwd())

# from frame_eval.test.local_deco_test import collect_conf_single, get_frame_vector
import frame_eval.feature_base_spark as feature_base_spark
import frame_eval.feature_liner_spark as feature_liner_spark
import frame_eval.eval_spark as eval_spark
from lib import entity
from lib import code_enum as ce

THREADS = 8

STATIC_KEY = {
    "moving_line": "moving_line",
    "width_depth": "width_depth",
    "square": "square",
    "chuwei_face": "chuwei_face",
    "toilet_face_entrance": "toilet_face_entrance",
    "room_face_others": "room_face_others",
    "gray_zone": "gray_zone",
    "wdf": "wdf",
    "moving_quiet": "moving_quiet",
    "convex": "convex",
}


def get_sep_t_list(file_path):
    df = pd.read_csv(file_path, sep="\t", encoding='cp1252')
    return df


def collect_conf_single(config_path):
    total_conf = {}
    with open(config_path, "r") as conf_data:
        eval_conf = yaml.load(conf_data)
        total_conf.update(eval_conf)
    return total_conf


def get_single_result(line):
    res_dict = dict()

    label_factory = entity.Label()

    # conf = collect_conf_single("../../config/eval_base_conf.yml")
    conf = collect_conf_single("config/eval_base_conf.yml")
    with open("config/eval_liner_conf.yml", "r") as conf_data:
        eval_liner_conf = yaml.load(conf_data)
        conf.update(eval_liner_conf)
    with open("config/eval_conf.yml", "r") as conf_data:
        eval_conf = yaml.load(conf_data)
        conf.update(eval_conf)

    base_frame, base_result = feature_base_spark.frame_analysis_base(line, debug=True, **conf["eval_base"])
    liner_frame, liner_result = feature_liner_spark.frame_analysis(line, debug=True, **conf["eval_line"])

    combine_frame = base_frame
    combine_frame.eval_base_text = base_result[-2]
    combine_frame.eval_liner_text = liner_result[-1]
    combine_frame.guest_lines = liner_result[13]
    combine_frame.living_lines = liner_result[14]
    combine_frame.work_lines = liner_result[15]
    combine_frame.message_text = base_result[-1]

    # eval_result = eval_spark.frame_eval(combine_frame, **conf["eval"])
    # eval_header = conf["eval"]["table_names"]
    # simple_field_range = range(15) + range(18, 20)
    # # doc_html = format_html(json.loads(eval_result[15], encoding="utf-8"), frame_id)
    # label_factory = entity.Label()

    if base_frame.state != ce.State.valid:
        return dict()
    # 动线
    if json.loads(liner_result[13]).get('line') is None or \
        json.loads(liner_result[14]).get('line') is None or \
            json.loads(liner_result[15]).get('line') is None:
        res_dict["moving_line"] = -1
    else:
        if len(json.loads(liner_result[13])['line']) + \
                len(json.loads(liner_result[14])['line']) + \
                len(json.loads(liner_result[15])['line']) > 0:
            res_dict["moving_line"] = 1
        else:
            res_dict["moving_line"] = 0

    # 进深面宽
    if combine_frame.explain_message.get('explain_width_depth') is None:
        res_dict["width_depth"] = -1
    else:
        for aid, v in combine_frame.explain_message['explain_width_depth'].items():
            if v[1] is None or v[2] is None:
                res_dict["width_depth"] = -1
            else:
                res_dict["width_depth"] = 1

    # 方正指数
    if combine_frame.explain_message.get('explain_whole_frame') is None:
        res_dict["square"] = -1
    else:
        res_dict["square"] = 1
    # oblique_ratio, abnormal_ratio = combine_frame.explain_message['explain_whole_frame'][5][0]
    # if oblique_ratio <= 0 or abnormal_ratio <= 0:
    #     res_dict["square"] = 0
    # else:
    #     res_dict["square"] = 1

    # 厨卫不对
    frame_labels_set = set(label_factory.code2lst(combine_frame.frame_label)[1])
    if '厨卫对门' in frame_labels_set:
        res_dict["chuwei_face"] = 1
    else:
        res_dict["chuwei_face"] = 0

    # 卫生间正对入户门
    # res_dict['toilet_face_entrance'] = 0
    if combine_frame.explain_message['collect_features'].get('toilet') is None:
        res_dict['toilet_face_entrance'] = -1
    else:
        res_dict['toilet_face_entrance'] = 1
    # face_entrance_list = combine_frame.explain_message['collect_features']['toilet'][3]
    # for dis in face_entrance_list:
    #     if dis != float('inf'):
    #         res_dict['toilet_face_entrance'] = 1

    # 卧室对视
    # res_dict["room_face_others"] = 0
    if combine_frame.explain_message['collect_features'].get('room') is None:
        res_dict["room_face_others"] = -1
    else:
        res_dict["room_face_others"] = 1
    # room_labels = combine_frame.explain_message['collect_features']['room'][0]
    # for lab in room_labels:
    #     if lab & ce.RoomLabel.face_others != 0:
    #         res_dict["room_face_others"] = 1

    # 灰区
    if combine_frame.explain_message['collect_features'].get('room') is None:
        res_dict["gray_zone"] = -1
    else:
        res_dict["gray_zone"] = 1
    # res_dict["gray_zone"] = 1
    # gray_zones = combine_frame.explain_message['collect_features']['room'][4]
    # for g in gray_zones:
    #     if g < 0 or g is None:
    #         res_dict["gray_zone"] = -1

    # 窗地比
    if combine_frame.explain_message.get('explain_window_door') is None:
        res_dict['wdf'] = -1
    else:
        res_dict['wdf'] = 1

    # 动静
    if combine_frame.explain_message.get('explain_quiet_rooms') is None \
        or combine_frame.explain_message.get('explain_moving_rooms') is None:
        res_dict["moving_quiet"] = -1
    else:
        res_dict["moving_quiet"] = 1
    # 凸窗
    if combine_frame.explain_message.get('explain_window_door') is None:
        res_dict['convex'] = -1
    else:
        res_dict['convex'] = 1

    tmp = 0
    return res_dict


def get_static_table(table_path):
    frame_id_list = []
    moving_line = []
    width_depth = []
    square = []
    chuwei_face = []
    toilet_face_entrance = []
    gray_zone = []
    wdf = []
    moving_quiet = []
    convex = []

    df = get_sep_t_list(table_path)
    for index, row in df.iterrows():
        vec = row['vector'].encode('utf8')
        frame_id = row['frame_id']
        print(frame_id)
        line = "\t".join([str(frame_id), 'image_id', vec, 'city_code'])

        result = get_single_result(line)

        frame_id_list.append(frame_id)
        moving_line.append(result.get('moving_line'))
        width_depth.append(result.get('width_depth'))
        square.append(result.get('square'))
        chuwei_face.append(result.get('chuwei_face'))
        toilet_face_entrance.append(result.get('toilet_face_entrance'))
        gray_zone.append(result.get("gray_zone"))
        if index > 200:
            break

    res_df = pd.DataFrame(columns=[
        'frame_id', 'moving_line', 'width_depth', 'square', 'chuwei_face',
        'toilet_face_entrance', 'gray_zone'])
    res_df['frame_id'] = frame_id_list
    res_df['moving_line'] = moving_line
    res_df['width_depth'] = width_depth
    res_df['square'] = square
    res_df['chuwei_face'] = chuwei_face
    res_df['toilet_face_entrance'] = toilet_face_entrance
    res_df['gray_zone'] = gray_zone
    res_df['wdf'] = wdf
    res_df['moving_quiet'] = moving_quiet
    res_df['convex'] = convex

    res_df.to_csv('res.tsv', index=None, header=None, sep='\t')
    tmp = 0


def multi_get_static_table(table_path):
    p = Pool(THREADS)
    t0 = time.time()
    df = get_sep_t_list(table_path)
    print("read tsv time: ", time.time() - t0)
    t0 = time.time()

    res_list = list()

    frame_id_list = []
    moving_line = []
    width_depth = []
    square = []
    chuwei_face = []
    toilet_face_entrance = []
    room_face_others = []
    gray_zone = []
    wdf = []
    moving_quiet = []
    convex = []

    for index, row in df.iterrows():
        vec = row['vector'].encode('utf8')
        frame_id = row['frame_id']
        line = "\t".join([str(frame_id), 'image_id', vec, 'city_code'])
        result = p.apply_async(get_single_result, args=(line, ))
        res_list.append((frame_id, result))

        if index > 200:
            break
    p.close()
    p.join()

    del df

    for frame_id, res in res_list:
        result = res.get()
        frame_id_list.append(frame_id)
        moving_line.append(result.get('moving_line'))
        width_depth.append(result.get('width_depth'))
        square.append(result.get('square'))
        chuwei_face.append(result.get('chuwei_face'))
        toilet_face_entrance.append(result.get('toilet_face_entrance'))
        room_face_others.append(result.get('room_face_others'))
        gray_zone.append(result.get("gray_zone"))
        wdf.append(result.get('wdf'))
        moving_quiet.append(result.get("moving_quiet"))
        convex.append(result.get("convex"))

    res_df = pd.DataFrame(columns=[
        'frame_id', 'moving_line', 'width_depth', 'square', 'chuwei_face',
        'toilet_face_entrance', 'room_face_others', "gray_zone", 'wdf', 'moving_quiet', 'convex'])
    res_df['frame_id'] = frame_id_list
    res_df['moving_line'] = moving_line
    res_df['width_depth'] = width_depth
    res_df['square'] = square
    res_df['chuwei_face'] = chuwei_face
    res_df['toilet_face_entrance'] = toilet_face_entrance
    res_df['room_face_others'] = room_face_others
    res_df['gray_zone'] = gray_zone
    res_df['wdf'] = wdf
    res_df['moving_quiet'] = moving_quiet
    res_df['convex'] = convex

    res_df.to_csv('res.tsv', index=None, sep='\t')
    tmp = 0
    print("time: ", time.time() - t0)


if __name__ == "__main__":
    # table_path = r"data_mining_framex_vector_hbase_da.tsv"
    # table_path = r"D:\tsv\data_mining_framex_vector_hbase_da.tsv"
    table_path = r"D:\tsv\data_mining_framex_vector_hbase_da_small.tsv"
    get_static_table(table_path)
    # multi_get_static_table(table_path)

