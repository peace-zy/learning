# coding=utf-8
import os
import sys
import json

from flask import Flask
from flask import request

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../"))
sys.path.insert(0, os.getcwd())
import frame_eval.decoration_spark as decoration_spark
import frame_eval.test.local_deco_test as local_deco_test
from lib import code_enum as ce

CONFIG_FILE = "frame_eval/test/decoration_conf_test.yml"
app = Flask(__name__)


def after_request(resp):
    resp.headers['Access-Control-Allow-Origin'] = '*'
    return resp


app.after_request(after_request)


@app.route("/decoration_interpretation", methods=['GET', 'POST'])
def decoration_interpretation():
    try:
        frame_vector = request.form.get('vectorValue').encode('utf8')
        frame_id = str(request.form.get('frame_id'))
        conf = local_deco_test.collect_conf_single(CONFIG_FILE)
        line = "\t".join([frame_id, 'image_id', frame_vector, 'city_code'])
        frame, result = decoration_spark.frame_decoration_feature(line, debug=True, **conf)
        if frame.state != ce.State.valid:
            raise Exception("户型异常, 请检查户型, 如入户门设置等......")
        md = deco_resultmd_string(result)

        res = {"decorationInterpretation": md}

    except Exception as error:
        res = {"error": error.message}
    return res


def deco_resultmd_string(result):
    frame_id = result[0]
    # img_path = "http"
    img_path = local_deco_test.get_img_url(frame_id)
    frame_label = json.loads(result[11])
    lines = []
    for room, label in frame_label.items():
        title0 = " ".join(["#", label['space_name'].encode('utf8')])
        lines.append(title0)
        lines.append('\n')

        img_md = ''.join(['![avatar](', img_path, ') \n'])
        lines.append(img_md)

        for doc in label['doc']:
            for dim in doc['dims']:
                title1 = " ".join(['###', 'title:', dim['title'].encode('utf8'), '\n\n'])
                lines.append(title1)
                annotation = ' '.join(['-', 'annotation:', dim['annotation'].encode('utf8'), '\n'])
                lines.append(annotation)
                detail = ' '.join(['-', 'detail:', dim['detail'].encode('utf8'), '\n'])
                lines.append(detail)
                merit = ' '.join(['-', 'merit:', dim['merit'].encode('utf8'), '\n'])
                lines.append(merit)
                merit = ' '.join(['-', 'display:', dim['display'].encode('utf8'), '\n'])
                lines.append(merit)
    res = ''.join(lines)
    return res


@app.route("/frame_vector", methods=['GET', 'POST'])
def frame_vector():
    try:
        frame_id = request.form.get('frame_id')
        s3_client = local_deco_test.get_s3_client()
        vector_response = s3_client.get_object(Bucket='frame-eval-image', Key=str(frame_id) + '.json')
        vector_str = vector_response['Body'].read()
        vector_dict = json.loads(vector_str)
        for fp in vector_dict['floorplans']:
            if fp.get('items') is not None:
                fp['items'] = []
                # del fp['items']

        res = {'frame_vector': json.dumps(vector_dict)}
    except Exception as error:
        if hasattr(error, 'message'):
            res = {"error": error.message}
        else:
            res = {"error": "Unkonw error"}
    return res


if __name__ == "__main__":
    # app.run(debug=True, host='0.0.0.0', port=7001)
    app.run(host='0.0.0.0', port=7001)