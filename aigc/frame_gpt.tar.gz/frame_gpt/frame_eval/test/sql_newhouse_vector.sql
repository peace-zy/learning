SELECT table_1.frame_id, vector, floor_area
FROM
	(SELECT table_0.frame_id, vector, floor_area, ROW_NUMBER() OVER(PARTITION BY table_0.frame_id ORDER BY floor_area desc) AS rn
FROM
    (SELECT vector_base_da.frame_id, vector
    FROM
        (SELECT frame_id, vector
        FROM data_mining.data_mining_framex_vector_base_da
        WHERE pt='{pt_date}000000' ) vector_base_da
        JOIN
        (SELECT frame_id
        FROM data_mining.data_mining_frame_eval_plus_da
        WHERE pt='{pt_date}000000'
        AND state=0
        ) eval_plus_da
        ON vector_base_da.frame_id=eval_plus_da.frame_id) table_0
    JOIN
    (SELECT frame_id, floor_area
    FROM dw.dw_house_newhouse_resblockdel_frame_mapping_da
    WHERE pt='{pt_date}000000') mapping
    ON table_0.frame_id=mapping.frame_id) table_1
WHERE table_1.rn=1