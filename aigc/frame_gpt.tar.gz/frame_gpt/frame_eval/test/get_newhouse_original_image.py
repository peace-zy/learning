# coding=utf-8
"""给标注人员提供数据的脚本"""
from __future__ import print_function
import pandas as pd
import os
import json
import sys
import requests
from io import BytesIO
from PIL import Image

SAVE_DIR = r'D:\tsv\newhouse_415_420'
INPUT_PATH = r'D:\tsv\newhouse_415_420.tsv'

def get_original_image():
    """
    SELECT frame_id, original_url, update_time FROM data_mining.data_mining_framex_vector_base_da
    WHERE pt='20210609000000'
    AND update_time > '2021-04-15'
    AND update_time < '2021-04-20'
    """
    df = pd.read_csv(INPUT_PATH, sep="\t", encoding='cp1252')
    for idx, row in df.iterrows():
        ori_url = row['original_url']
        frame_id = row['frame_id']
        try:
            response = requests.get(ori_url)
            image = Image.open(BytesIO(response.content))
            if image.mode != 'CMYK':
                image = image.convert('CMYK')
            img_name = str(frame_id) + '_ori.jpg'
            image.save(os.path.join(SAVE_DIR, img_name))
        except Exception as e:
            print(e, idx)


if __name__ == "__main__":
    get_original_image()
