# coding=utf-8
# Copyright (c) 2019 www.ke.com, Inc. All Rights Reserved
"""
户型解读样例调试
Authors: yudonghai@ke.com
Date: 2019-06-10
"""
from __future__ import division
import __init__
import logging
import os
import sys
import json
import yaml
import boto3
from botocore.errorfactory import ClientError
import redis

import frame_remould.settings as settings
settings.PLOT = True

from lib import code_enum as ce
from lib import entity
import feature_liner_spark
import eval_spark
import feature_base_spark
import decoration_spark

S3_AK = "223HG43LGIX9W3MWTOCL"
S3_AKS = "tqWXh8kSyxM/QfgF34dMXFJcRrIIGfIIZkVVjSMH"


def save_result(result):

    check_single_head = [
        "frame_id",
        "room_name",
        "width",
        "depth",
        "wid_div_dep",
        "size",
        "gray_size",
        "door_size",
        "is_oblique",
        "max_line",
        "window_width",
        "wind_div_floor",
        "face",
        "convex_window"
    ]

    total_head = [
        "frame_id",
        "menting",
        "parlour_balcony",
        "dining",
        "parlour_dining",
        "cooking",
        "kitchen_dining",
        "kitchen_balcony",
        "trans_type",
        "face_type",
        "is_rectangle",
        "main_room_conn_cnt"
    ]

    toilet_head = [
        "frame_id",
        "room_name",
        "sep",
        "duwei",
        "face_entrance",
        "face_kitchen"
    ]

    room_head = [
        "frame_id",
        "room_name",
        "with_toilet",
        "with_cloakroom",
        "with_balcony",
        "face_others"
    ]

    trans_info = [[ce.TransType.both_face, u"双向"], [ce.TransType.neighbour_face, u"邻向"], [ce.TransType.single_face, u"单向"]]
    face_info = [[ce.FaceType.north_south, u"南北"], [ce.FaceType.south, u"南"],
                 [ce.FaceType.east, u"东"], [ce.FaceType.west, u"西"], [ce.FaceType.north, u"北"]]

    total_result = open("./data/case_check_frame.txt", "w")
    toilet_result = open("./data/case_check_toilet.txt", "w")
    room_result = open("./data/case_check_bedroom.txt", "w")
    single_result = open("./data/case_check_single.txt", "w")

    total_result.writelines(u",".join(total_head) + "\n")
    toilet_result.writelines(u",".join(toilet_head) + "\n")
    room_result.writelines(u",".join(room_head) + "\n")
    single_result.writelines(u",".join(check_single_head) + "\n")

    for all_info in result:
        frame_id, width_dep, size_f, wall_f, window_f, toilet_f, room_f, frame_f, face_f, whole_f = all_info
        for area_id in size_f:
            name, w, d, w_div_d = width_dep.get(area_id, ['', 0, 0, 0])
            use_size, gray_size, door_size = size_f[area_id]
            expand_points, oblique_flag, max_line, line_info_lst, entrance_vector = wall_f[area_id]
            all_window_len, w_div_floor, faces, main_face, convex_window = window_f[area_id]
            if max_line > 10000:
                logging.debug(u"{} outmaxlen {} {}".format(frame_id, max_line, name))
            features = [frame_id, name, w, d, w_div_d, use_size, gray_size, door_size, oblique_flag, max_line,
                        all_window_len, w_div_floor, main_face, convex_window]
            features = [unicode(x) for x in features]

            single_result.writelines(u",".join(features).encode("utf-8") + "\n")

    for all_info in result:
        frame_id, width_dep, size_f, wall_f, window_f, toilet_f, room_f, frame_f, face_f, whole_f = all_info
        frame_label = frame_f
        area_inf_dict, main_room_id, sub_rooms, trans_flag, face_flag, frame_rec, surround_sub_room_cnt = whole_f

        features = [frame_id] + [1 if (0b1 << i) & frame_label else 0 for i in range(7)]

        trans_v = None
        for v, doc in trans_info:
            if trans_flag & v:
                trans_v = doc
                break
        face_v = None
        for v, doc in face_info:
            if face_flag & v:
                face_v = doc
                break

        features += [trans_v, face_v, frame_rec, surround_sub_room_cnt]
        features = [unicode(x) for x in features]
        total_result.writelines(u",".join(features).encode("utf-8") + "\n")

        for i in toilet_f:
            n, v = toilet_f[i]
            v_lst = [1 if t & v else 0 for t in [1, 2, 4, 8]]
            t_features = [frame_id, n] + v_lst
            t_features = [unicode(x) for x in t_features]
            toilet_result.writelines(u",".join(t_features).encode("utf-8") + "\n")

        for i in room_f:
            n, v = room_f[i]
            v_lst = [1 if t & v else 0 for t in [1, 2, 4, 8]]
            r_features = [frame_id, n] + v_lst
            r_features = [unicode(x) for x in r_features]
            room_result.writelines(u",".join(r_features).encode("utf-8") + "\n")

    total_result.close()
    toilet_result.close()
    room_result.close()
    single_result.close()


def save_docs(result):
    with open("./data/frame_docs.txt", "w") as f:
        for frame_id, doc in result:
            f.writelines("\t".join([frame_id, doc.encode(encoding="utf-8")]) + "\n")


def format_html(doc_dict, frame_id):
    html = u"<html><head><meta charset='utf-8'><title>户型报告</title></head><body><table style='margin: auto;table-layout:fixed;width:800px;'>{}</table></body></html>"
    inner_content = u"<tr><td><img src='{}', style='width:600px;margin: auto;'></td></tr><tr><td>{}</td></tr>".format(doc_dict["main_img"], doc_dict["pre_doc"])
    for dim in ["square", "visual", "light", "movement", "wd"]:
        dim_top = doc_dict[dim]["dim_pre"]
        inner_content += u"<tr style='height: 30px;'><td></td></tr><tr><td><h2 style='color: #4474e4;'>{}</h2></td></tr>".format(dim_top)
        dim_images = doc_dict[dim]["imgs"]
        for img in dim_images:
            inner_content += u"<tr><td><div style='position: relative;'><div style='position: absolute;'><img src='{dim_img}' style='width:600px;margin: auto;'/></div><img src='{main_img}', style='width:600px;margin: auto;'></div></td></tr>".format(**{"dim_img": img, "main_img": doc_dict["main_img"]})
        inner_content += u"<tr><td>{}</td></tr>".format(doc_dict[dim]["dim_content"])
    return html.format(inner_content)


def analysis_a_deco_case(frame_id, s3_client, conf):
    """
    实时请求s3获取矢量值进行分析
    :param frame_id:
    :param s3_client:
    :param conf:
    :return:
    """
    try:
        vector_response = s3_client.get_object(Bucket='frame-eval-image', Key=frame_id + '.json')
        vector_str = vector_response['Body'].read()
    except ClientError as e:
        logging.error(e)
        return None

    line = "\t".join([frame_id, 'image_id', vector_str, 'city_code'])

    logging.debug("***** explain: {} *****".format(frame_id))

    _, deco_frame = decoration_spark.frame_decoration_feature(line, debug=True, **conf)
    return deco_frame


def analysis_a_case(frame_id, s3_client, conf):
    """
    实时请求s3获取矢量值进行分析
    :param frame_id:
    :param s3_client:
    :param conf:
    :return:
    """
    try:
        vector_response = s3_client.get_object(Bucket='frame-eval-image', Key=frame_id + '.json')
        vector_str = vector_response['Body'].read()
    except ClientError as e:
        logging.error(e)
        return None

    line = "\t".join([frame_id, 'image_id', vector_str, 'city_code'])

    logging.debug("***** explain: {} *****".format(frame_id))

    from frame_label.spark_main import get_frame_label

    base_frame, base_result = feature_base_spark.frame_analysis_base(line, debug=True, **conf["eval_base"])
    if base_frame.state != ce.State.valid:
        return

    liner_frame, liner_result = feature_liner_spark.frame_analysis(line, debug=True, **conf["eval_line"])

    combine_frame = base_frame
    combine_frame.eval_base_text = base_result[-2]
    combine_frame.eval_liner_text = liner_result[-1]
    combine_frame.guest_lines = liner_result[13]
    combine_frame.living_lines = liner_result[14]
    combine_frame.work_lines = liner_result[15]
    combine_frame.message_text = base_result[-1]

    eval_result = eval_spark.frame_eval(combine_frame, **conf["eval"])
    eval_header = conf["eval"]["table_names"]
    simple_field_range = range(15) + range(18, 20)
    # doc_html = format_html(json.loads(eval_result[15], encoding="utf-8"), frame_id)
    label_factory = entity.Label()
    for i in simple_field_range:
        if eval_header[i] == "label":
            label_str = label_factory.code2str(int(eval_result[i]))
            logging.debug("{}: {}-{}".format(eval_header[i], eval_result[i], label_str))
        else:
            logging.debug("{}: {}".format(eval_header[i], eval_result[i]))

    logging.debug(eval_result[15])
    plan_cnt = combine_frame.plan_cnt
    visual_liner_idx = json.loads(liner_result[-1])[ce.EXPLAIN_VARS]["visual_liner_idx"]
    result = [frame_id, [{} for _ in range(plan_cnt)], [{} for _ in range(plan_cnt)], [{} for _ in range(plan_cnt)],
              [{} for _ in range(plan_cnt)], [{} for _ in range(plan_cnt)]]
    result[1][visual_liner_idx] = {"guest_line": json.loads(liner_result[13]),
                                   "living_line": json.loads(liner_result[14]),
                                   "work_line": json.loads(liner_result[15])}
    if len(result[1]) > 1:
        result[1][1] = {"guest_line": {"line": [], "pts": []}, "living_line": {"line": [], "pts": []},
                        "work_line": {"line": [], "pts": []}}
    result[2][visual_liner_idx] = json.loads(liner_result[-1])[ce.EXPLAIN_VARS]["visual_areas"]
    if len(result[2]) > 1:
        result[2][1] = []
    result[3] = json.loads(base_result[-1])["face_vectors"]
    result[4] = json.loads(base_result[-1])["wd_vectors"]
    result[5] = json.loads(base_result[-1])["quiet_areas"]
    # result = [
    #     frame_id,
    #     json.dumps({"guest_line": json.loads(liner_result[13]), "living_line": json.loads(liner_result[14]), "work_line": json.loads(liner_result[15])}),
    #     json.dumps(json.loads(liner_result[-1])[ce.EXPLAIN_VARS]["visual_areas"]),
    #     json.dumps(json.loads(base_result[-1])["face_vectors"]),
    #     json.dumps(json.loads(base_result[-1])["wd_vectors"]),
    #     json.dumps(json.loads(base_result[-1])["quiet_areas"])
    # ]
    return result

def collect_conf():
    total_conf = {}
    with open("../config/eval_base_conf.yml", "r") as conf_data:
        eval_base_conf = yaml.load(conf_data)
        total_conf.update(eval_base_conf)
    with open("../config/frame_label_conf.yml", "r") as conf_data:
        eval_base_conf = yaml.load(conf_data)
        total_conf.update(eval_base_conf)

    with open("../config/eval_liner_conf.yml", "r") as conf_data:
        eval_liner_conf = yaml.load(conf_data)
        total_conf.update(eval_liner_conf)

    with open("../config/eval_conf.yml", "r") as conf_data:
        eval_conf = yaml.load(conf_data)
        total_conf.update(eval_conf)

    with open("../config/decoration_conf.yml", "r") as conf_data:
        eval_conf = yaml.load(conf_data)
        total_conf.update(eval_conf)

    return total_conf

def main(*args):

    logging.basicConfig(level=logging.DEBUG, format='%(asctime)s %(levelname)s %(message)s')

    s3_client = boto3.client('s3', region_name="cn-north-1", endpoint_url="http://storage.lianjia.com",
                             aws_access_key_id=S3_AK,
                             aws_secret_access_key=S3_AKS)

    total_conf = collect_conf()

    result_lst = []
    html_lst = []

    # "24000000652634", "1116734796657371", "117670161223771", "1117778944257848", "1120035958572863",
    # "2420035224376055", "1113431168053689", "11000001320585", "1113431168053689", 12000000983294, 1120039796306744
    # for frame_id in ["11000000535785", "1116734796657371", "11000000535785", "1116734796657371", "36000004826883"]:
    # for frame_id in ["11000002082147"]:
    # for frame_id in ["1120037356792536"]:
    # for frame_id in ["11000000535785", "11000000535785", "11000000535785"]:
    # for frame_id in ["36000005399186"]:
    # for frame_id in ["87570000911375"]:
    # for frame_id in ["24000005862432"]:
    # for frame_id in ["24000005958778"]:
    # for frame_id in ["11000006502037"]:
    # for frame_id in ["11000000694743"]:

    # import pandas as pd
    # df = pd.read_csv(r'D:\100frameid.CSV')
    # frame_ids = list(df['frameid'])
    dpts = []
    # for idx, frame_id in enumerate(frame_ids):
    for frame_id in ["1112728111215342"]:
        # result = analysis_a_case(frame_id, s3_client, total_conf)
        result = analysis_a_deco_case(str(frame_id), s3_client, total_conf)
        for x in result:
            print(x)
        # res2md(result)

        # print("\t".join(result))
        # html_lst.append([frame_id, result[-1]])
        result = [result[0]] + [json.dumps(x) for x in result[1:]]
        result_lst.append("\t".join(result))

        # 统计检测点
        # dpt_cnt = 0
        # dpt = json.loads(result[11])
        # for k, v in dpt.items():
        #     for docs in v['doc']:
        #         dpt_cnt += len(docs['dims'])
        # dpts.append(dpt_cnt)

    with open("../data/draw_feature.txt", "w") as save_f:
        for i in range(1):
            for result in result_lst:
                save_f.writelines(result + "\n")

    #
    # for frame_id, html in html_lst:
    #     with open("../show_case/static/{}.html".format(frame_id), "w") as save_h:
    #         save_h.writelines(html.encode("utf-8"))


def upload():
    """
    上传绘图特征到 redis 测试队列
    :return:
    """
    redis_conn = redis.StrictRedis(host="m12013.zeus.redis.ljnode.com",
                                   port=12013,
                                   db=0,
                                   password="2e6l5b9n31RSNHL4")
    pipeline = redis_conn.pipeline()
    with open("../data/draw_feature.txt", "r") as f:
        for l in f.readlines():
            pipeline.rpush("draw_feature_test", l.strip())
        pipeline.execute()
    pipeline.close()


def res2md(result):
    SAVE_PATH = r'D:\tmp\md'

    from frame_eval.newhouse_v2.spark_main import get_img_url
    frame_id = result[0]
    img_path = get_img_url(frame_id)

    frame_file = os.path.join(SAVE_PATH, frame_id + ".md")
    file_write_obj = open(frame_file, 'w')
    frame_label = json.loads(result[11])

    img_md = ''.join(['![avatar](', img_path, ') \n'])
    file_write_obj.writelines(img_md)

    for room_type, label in frame_label.items():
        room_line = " ".join(['#', room_type.encode('utf8')])
        file_write_obj.writelines(room_line)
        file_write_obj.writelines('\n')
        for doc in label['doc']:
            for dim in doc['dims']:
                title1 = " ".join(['###', 'title:', dim['title'].encode('utf8'), '\n\n'])
                file_write_obj.writelines(title1)
                detail = ' '.join(['-', 'detail:', dim['detail'].encode('utf8'), '\n'])
                file_write_obj.writelines(detail)
                annotation = ' '.join(['-', 'annotation:', dim['annotation'].encode('utf8'), '\n'])
                file_write_obj.writelines(annotation)
    file_write_obj.close()


if __name__ == "__main__":
    # main(*sys.argv[1:])
    main()
    # upload()
