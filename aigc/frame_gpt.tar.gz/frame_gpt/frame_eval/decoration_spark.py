#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2019 www.ke.com, Inc. All Rights Reserved
"""
装修户型检测点
Authors: yudonghai@ke.com
Date:    2020/10/27
"""
from __future__ import division
import logging
import yaml
import sys
import traceback
import copy

import json

from lib import entity
from lib import spark_util
from lib import eval_main
from lib import label_functions
from lib import code_enum as ce
from frame_remould.floorplan import House
from lib.file_util import get_file_stream


def condition_check(key_dict, conditions, condition_conn):
    cond_results = []
    for cond in conditions:
        k, comp, target = cond
        if comp == "notnull":
            cond_results.append(key_dict[k] is not None)
        elif comp == "<":
            cond_results.append(key_dict[k] < target)
        elif comp == "<=":
            cond_results.append(key_dict[k] <= target)
        elif comp == ">":
            cond_results.append(key_dict[k] > target)
        elif comp == ">=":
            cond_results.append(key_dict[k] >= target)
        elif comp == "==":
            cond_results.append(key_dict[k] == target)
        elif comp == "true":
            cond_results.append(key_dict[k] is True)
        elif comp == "false":
            cond_results.append(key_dict[k] is False)
        elif comp == "in":
            cond_results.append(key_dict[k] in set(target.strip().split(",")))
        else:
            logging.error("unknown operator！")
            return None
    result = None
    if condition_conn == "all":
        result = all(cond_results)
    elif condition_conn == "any":
        result = any(cond_results)
    else:
        logging.error("unknown condition connection {}!!".format(condition_conn))
    return result


def doc_group_getter(doc_vars, room_keys):
    new_result = {}
    for doc_group in doc_vars:
        for doc_item in doc_group:
            item_cond = doc_item["cond"]
            item_cond_conn = doc_item["cond_conn"]
            new_vars = doc_item["vars"]
            item_flag = condition_check(room_keys, item_cond, item_cond_conn)
            if item_flag is None:
                return None
            if item_flag:
                new_result.update(new_vars)
                break
    return new_result


def one_room_doc(vars, dims_conf):
    one_room_result = []
    for dim in dims_conf:
        dim_name = dim.get("dim_name", "")
        dim_condition = dim.get("dim_condition", [])
        dim_condition_conn = dim.get("dim_condition_conn", "")
        title = unicode(dim.get("title", u""))
        detail = unicode(dim.get("detail", u""))
        annotation = unicode(dim.get("annotation", u""))
        doc_vars = dim.get("doc_vars", [])

        dim_flag = condition_check(vars, dim_condition, dim_condition_conn)
        if dim_flag is None:
            return None

        if not dim_flag:
            continue

        dim_result = doc_group_getter(doc_vars, vars)
        if not dim_result:
            # 解决条件不完备时，文档格式化程序不通过
            continue
        if dim_result is None:
            return None
        full_vars = dict(vars, **dim_result)
        # full_vars = {unicode(k, encoding="utf-8"): full_vars[k] for k in full_vars}
        """
        one_room_result.append({
            "dim_name": dim_name,
            "title": title.format(**full_vars),
            "detail": detail.format(**full_vars),
            "annotation": annotation.format(**full_vars)
        })
        """
        try:
            one_room_dict = {
                "dim_name": dim_name,
                "title": title.format(**full_vars),
                "detail": detail.format(**full_vars),
                "annotation": annotation.format(**full_vars)
            }
            one_room_result.append(one_room_dict)
        except Exception as e:
            continue
    return one_room_result


def space_doc(key_vars_lst, space_conf):
    space_name = space_conf["name"]
    pro_range = space_conf["range"]
    dims_conf = space_conf["dims"]

    if not key_vars_lst:
        return None

    vars_lst = key_vars_lst
    if pro_range == "max":
        vars_lst = [sorted(key_vars_lst, key=lambda x: x["area_size"])[-1]]

    room_items = []
    for vars in vars_lst:
        room_item = one_room_doc(vars, dims_conf)
        for k, v in vars.items():
            # float('inf') 会在json格式化时变为Infinity, 出现问题
            if v == float('inf'):
                vars[k] = 'inf'

        room_items.append({"dims": room_item, "area_id": vars["base_info"]["area_id"], "vars": vars})
    return {"space_name": space_name, "doc": room_items}


def doc_format(key_vars_dict, conf_params):
    room_type_lst = conf_params["room_type_order"]
    space_dict = conf_params["spaces"]

    final_doc = {}
    for room_type in room_type_lst:
        key_vars_lst = key_vars_dict.get(room_type, [])
        space_conf = space_dict.get(room_type, {})
        if not space_conf:
            continue
        space_docs = space_doc(key_vars_lst, space_conf)
        if space_docs is None:
            continue

        final_doc[room_type] = space_docs
    if not final_doc:
        return None
    return final_doc


def frame_decoration_feature(row, debug=False, **params):
    """
    :param row: str/Row/dict, 户型数据
            (str格式时各个字段用逗号分隔，且需要跟Frame类内各字段顺序一致)
    :param debug: boolean, 调试模式，返回户型对象
    :param params: dict, 参数
    :return:
    """
    frame = entity.Frame(row)

    try:
        frame_vector = frame.vector
        house = House()
        house.set_json_str(json.dumps(frame_vector))
        frame.set_house(house)
        res_dict, js_dict = house.run()

        # 标签
        frame.add_label(label_functions.label_base, **params["label_params"])
        # 检测点
        eval_main.decoration_explain(frame, **params)

        decoration_dict = frame.explain_message.get("decoration_dict", {})
        decoration_sug_dict = frame.explain_message.get("decoration_sug_dict", {})
        # 自动摆放字段
        # frame_vector = frame.vector
        # house = House()
        # house.set_json_str(json.dumps(frame_vector))
        # res_dict, js_dict = house.run()
        decoration_sug_dict.update(js_dict)

        docs = doc_format(decoration_dict, params["dec_conf"])
        postprocess(docs, decoration_sug_dict)
        docs = json.dumps(docs, encoding="utf-8")

        decoration_sugs = json.dumps(decoration_sug_dict, encoding="utf-8")
        result_vector = frame.base_feature() + [frame.frame_label, docs, decoration_sugs]
        result = [str(x) for x in result_vector]
    except Exception as e:
        traceback.print_exc()
        logging.error("{} get decoration feature exception!!".format(frame.frame_id))
        frame._state = ce.State.unknown_exception
        result_vector = frame.base_feature() + [0, "", ""]
        result = [str(x) for x in result_vector]
    if debug:
        return frame, result
    return result


def postprocess(docs, decoration_sug_dict):
    """后处理方法，更新卧室标签"""
    # 主卧
    if docs.get('main_room') is not None:
        decoration_sug_dict['main_room_tag'] = copy.deepcopy(docs.get('main_room'))
        dim_names = ['width_label', 'depth_label', 'cloakroom_label']
        for doc in docs.get('main_room').get('doc'):
            docs_dims = []
            tags_dims = []
            for mroom in doc.get('dims'):
                if mroom.get('dim_name') in dim_names:
                    tags_dims.append(mroom)
                else:
                    docs_dims.append(mroom)
                    # doc.get('dims').remove(mroom)
            docs['main_room']['doc'][0]['dims'] = docs_dims
            decoration_sug_dict['main_room_tag']['doc'][0]['dims'] = tags_dims
    return None

def logic_func(driver, raw_df, **params):
    """
     spark 逻辑处理
    :param driver: spark_util.SparkSqlDriver, spark 执行类
    :param raw_df: pyspark.sql.dataframe.DataFrame， sql 查询结果
    :param params: dict, 参数字典
    :return: result_df, 处理后的 DataFrame
    """
    result_rdd = raw_df.rdd.map(lambda row: frame_decoration_feature(row, **params))
    result_df = driver.rdd_2_df(result_rdd)
    names = params["table_names"]
    result_df = result_df.toDF(*names)
    return result_df


def main():
    """ 主函数 """
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    if len(sys.argv) < 3:
        logging.error("no less than 2 arguments!")
        sys.exit()

    pt_date = sys.argv[1]
    config_file = sys.argv[2]

    f = get_file_stream(config_file)
    conf = yaml.load(f)

    # with open(config_file, "r") as config_data:
    #     conf = yaml.load(config_data)

    # 从配置文件读取参数
    spark_config_key = "frame_decoration_config"
    spark_params = conf.get(spark_config_key, None)
    if spark_params is None:
        logging.error("lack {} in config file".format(spark_config_key))
        sys.exit(-1)

    # ## 补充参数
    # pt
    spark_params["sql_params"]["pt_date"] = pt_date
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_function"] = logic_func
    # 存储pt
    spark_params["save_params"]["partition_params"] = {"pt": "{}000000".format(pt_date)}

    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()


def test():
    import pandas as pd
    decoration_data = pd.read_csv(r'D:\decoration.tsv', sep='\t')
    f = get_file_stream('config/decoration_conf.yml')
    conf = yaml.load(f)
    deco_list = decoration_data.values.tolist()[0]
    row = {
        'frame_id': deco_list[0],
        'image_id': deco_list[1],
        'vector_value': deco_list[2].decode('utf-8'),
        'city_code': deco_list[3],
    }
    # deco_list = '\t'.join(deco_list)
    res = frame_decoration_feature(row, **conf)
    pass


if __name__ == "__main__":
    # test()
    logging.basicConfig(level=logging.WARN, format='%(asctime)s %(levelname)s %(message)s')

    main()
