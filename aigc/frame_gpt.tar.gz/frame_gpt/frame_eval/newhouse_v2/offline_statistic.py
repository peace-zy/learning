# coding=utf-8
import pandas as pd
import os
import json
import sys
import matplotlib.pylab as plt

def ana_rooms_dongxian():
    """统计动线，动静"""
    file_path = r"D:\tsv\room_sep_ana.tsv"
    df = pd.read_csv(file_path, sep="\t", encoding='cp1252')
    df = df.dropna()
    # 动静 VS 面积
    df0 = df[df['area_size']<50]
    df0_0 = df0[df0['movement_clear'] == 1]

    df1 =df[(df['area_size']<100) & (df['area_size']>50)]
    df1_0 = df1[df1['movement_clear'] == 1]

    df2 =df[(df['area_size']<150) & (df['area_size']>100)]
    df2_0 = df2[df2['movement_clear'] == 1]

    df3 =df[(df['area_size']<200) & (df['area_size']>150)]
    df3_0 = df3[df3['movement_clear'] == 1]

    df4 = df[df['area_size']>200]
    df4_0 = df4[df4['movement_clear'] == 1]

    m_q_rates = [
        df0_0.shape[0] * 1.0 / df0.shape[0],
        df1_0.shape[0] * 1. / df1.shape[0],
        df2_0.shape[0] * 1. / df2.shape[0],
        df3_0.shape[0] * 1. / df3.shape[0],
        df4_0.shape[0] * 1. / df4.shape[0],
    ]

    #动静VSrooms
    df0 = df[df['shi']==1]
    df0_0 = df0[df0['movement_clear'] == 1]
    df1 = df[df['shi']==2]
    df1_0 = df1[df1['movement_clear'] == 1]
    df2 = df[df['shi']==3]
    df2_0 = df2[df2['movement_clear'] == 1]
    df3 = df[df['shi']==4]
    df3_0 = df3[df3['movement_clear'] ==1]
    df4 = df[df['shi']>=5]
    df4_0 = df4[df4['movement_clear'] ==1]

    m_q_rates = [
        df0_0.shape[0] * 1.0 / df0.shape[0],
        df1_0.shape[0] * 1. / df1.shape[0],
        df2_0.shape[0] * 1. / df2.shape[0],
        df3_0.shape[0] * 1. / df3.shape[0],
        df4_0.shape[0] * 1. / df4.shape[0],
    ]

    # 动线
    df1 = df[df['shi'] == 1]
    df2 = df[df['shi'] == 2]
    df3 = df[df['shi'] == 3]
    df4 = df[df['shi'] == 4]
    df5 = df[df['shi'] >= 5]

    plt.hist(df1['living_len'], bins=100)
    plt.hist(df1['gurest_len'], bins=100)
    tmp = 0


if __name__ == "__main__":
    ana_rooms_dongxian()