# coding=utf-8
import os
import pandas as pd
import matplotlib.pylab as plt


def statistic_newhouse_feature(fpath, save_path):
    df = pd.read_csv(fpath, dtype='str', sep="\t", encoding='cp1252')

    # # total_score
    # df_1 = df[['frame_id', 'total_score']]
    # df_1[df_1['total_score'].isnull()] = 0
    # list(pd.to_numeric(df_1['total_score']))
    # total_score_list = list(pd.to_numeric(df_1['total_score']))
    # plt.hist(total_score_list, bins=50)
    # plt.savefig(os.path.join(save_path, "total_score.png"))
    # plt.clf()
    #
    # # space_score
    # df_1 = df[['frame_id', 'space_score']]
    # df_1[df_1['space_score'].isnull()] = 0
    # list(pd.to_numeric(df_1['space_score']))
    # space_score_list = list(pd.to_numeric(df_1['space_score']))
    # plt.hist(space_score_list, bins=50)
    # plt.savefig(os.path.join(save_path, "space_score.png"))
    # plt.clf()
    #
    # # trans_score
    # df_1 = df[['frame_id', 'trans_score']]
    # df_1[df_1['trans_score'].isnull()] = 0
    # list(pd.to_numeric(df_1['trans_score']))
    # trans_score_list = list(pd.to_numeric(df_1['trans_score']))
    # plt.hist(trans_score_list, bins=50)
    # plt.savefig(os.path.join(save_path, "trans_score.png"))
    # plt.clf()
    #
    # # usage_score
    # df_1 = df[['frame_id', 'usage_score']]
    # df_1[df_1['usage_score'].isnull()] = 0
    # list(pd.to_numeric(df_1['usage_score']))
    # usage_score_list = list(pd.to_numeric(df_1['usage_score']))
    # plt.hist(usage_score_list, bins=50)
    # plt.savefig(os.path.join(save_path, "usage_score.png"))
    # plt.clf()
    #
    # # movement_clear
    # df_1 = df[['frame_id', 'movement_clear']]
    # df_1[df_1['movement_clear'].isnull()] = -1
    # df_1[df_1['movement_clear'] == 'true'] = 1
    # df_1[df_1['movement_clear'] == 'false'] = 0
    # list(pd.to_numeric(df_1['movement_clear']))
    # movement_clear_list = list(pd.to_numeric(df_1['movement_clear']))
    # plt.hist(movement_clear_list, bins=50)
    # plt.savefig(os.path.join(save_path, "movement_clear.png"))
    # plt.clf()
    #
    # # moving_line_cross_cnt
    # df_1 = df[['frame_id', 'moving_line_cross_cnt']]
    # df_1[df_1['moving_line_cross_cnt'].isnull()] = -1
    # list(pd.to_numeric(df_1['moving_line_cross_cnt']))
    # moving_line_cross_cnt_list = list(pd.to_numeric(df_1['moving_line_cross_cnt']))
    # plt.hist(moving_line_cross_cnt_list, bins=20)
    # plt.savefig(os.path.join(save_path, "moving_line_cross_cnt.png"))
    # plt.clf()
    #
    # # good_active_line
    # df_1 = df[['frame_id', 'good_active_line']]
    # df_1[df_1['good_active_line'].isnull()] = -1
    # df_1[df_1['good_active_line'] == 'true'] = 1
    # df_1[df_1['good_active_line'] == 'false'] = 0
    # list(pd.to_numeric(df_1['good_active_line']))
    # good_active_line_list = list(pd.to_numeric(df_1['good_active_line']))
    # plt.hist(good_active_line_list, bins=50)
    # plt.savefig(os.path.join(save_path, "good_active_line.png"))
    # plt.clf()
    #
    # # visual_ratio
    # df_1 = df[['frame_id', 'visual_ratio']]
    # df_1[df_1['visual_ratio'].isnull()] = -1
    # list(pd.to_numeric(df_1['visual_ratio']))
    # visual_ratio_list = list(pd.to_numeric(df_1['visual_ratio']))
    # plt.hist(visual_ratio_list, bins=20)
    # plt.savefig(os.path.join(save_path, "visual_ratio.png"))
    # plt.clf()

    # # is_square
    # df_1 = df[['frame_id', 'is_square']]
    # df_1[df_1['is_square'].isnull()] = -1
    # df_1[df_1['is_square'] == 'true'] = 1
    # df_1[df_1['is_square'] == 'false'] = 0
    # list(pd.to_numeric(df_1['is_square']))
    # is_square_list = list(pd.to_numeric(df_1['is_square']))
    # plt.hist(is_square_list, bins=50)
    # plt.savefig(os.path.join(save_path, "is_square.png"))
    # plt.clf()
    #
    # # face_label
    # df_1 = df[['frame_id', 'face_label']]
    # df_1[df_1['face_label'].isnull()] = -1
    # list(pd.to_numeric(df_1['face_label']))
    # result_list = list(pd.to_numeric(df_1['face_label']))
    # plt.hist(result_list, bins=50)
    # plt.savefig(os.path.join(save_path, "face_label.png"))
    # plt.clf()

    # # trans_label
    # df_1 = df[['frame_id', 'trans_label']]
    # df_1[df_1['trans_label'].isnull()] = -1
    # list(pd.to_numeric(df_1['trans_label']))
    # result_list = list(pd.to_numeric(df_1['trans_label']))
    # plt.hist(result_list, bins=50)
    # plt.savefig(os.path.join(save_path, "trans_label.png"))
    # plt.clf()
    #
    # # all_window
    # df_1 = df[['frame_id', 'all_window']]
    # df_1[df_1['all_window'].isnull()] = -1
    # df_1[df_1['all_window'] == 'true'] = 1
    # df_1[df_1['all_window'] == 'false'] = 0
    # list(pd.to_numeric(df_1['all_window']))
    # result_list = list(pd.to_numeric(df_1['all_window']))
    # plt.hist(result_list, bins=20)
    # plt.savefig(os.path.join(save_path, "all_window.png"))
    # plt.clf()

    # # kitchen_window
    # df_1 = df[['frame_id', 'kitchen_window']]
    # df_1[df_1['kitchen_window'].isnull()] = -1
    # df_1[df_1['kitchen_window'] == 'true'] = 1
    # df_1[df_1['kitchen_window'] == 'false'] = 0
    # list(pd.to_numeric(df_1['kitchen_window']))
    # result_list = list(pd.to_numeric(df_1['kitchen_window']))
    # plt.hist(result_list, bins=20)
    # plt.savefig(os.path.join(save_path, "kitchen_window.png"))
    # plt.clf()
    #
    # # toilet_window
    # df_1 = df[['frame_id', 'toilet_window']]
    # df_1[df_1['toilet_window'].isnull()] = -1
    # df_1[df_1['toilet_window'] == 'true'] = 1
    # df_1[df_1['toilet_window'] == 'false'] = 0
    # list(pd.to_numeric(df_1['toilet_window']))
    # result_list = list(pd.to_numeric(df_1['toilet_window']))
    # plt.hist(result_list, bins=20)
    # plt.savefig(os.path.join(save_path, "toilet_window.png"))
    # plt.clf()

    # # north_south_trans
    # df_1 = df[['frame_id', 'north_south_trans']]
    # df_1[df_1['north_south_trans'].isnull()] = -1
    # df_1[df_1['north_south_trans'] == 'true'] = 1
    # df_1[df_1['north_south_trans'] == 'false'] = 0
    # list(pd.to_numeric(df_1['north_south_trans']))
    # result_list = list(pd.to_numeric(df_1['north_south_trans']))
    # plt.hist(result_list, bins=20)
    # plt.savefig(os.path.join(save_path, "north_south_trans.png"))
    # plt.clf()
    #
    # # bedroom_toilet
    # df_1 = df[['frame_id', 'bedroom_toilet']]
    # df_1[df_1['bedroom_toilet'].isnull()] = -1
    # df_1[df_1['bedroom_toilet'] == 'true'] = 1
    # df_1[df_1['bedroom_toilet'] == 'false'] = 0
    # list(pd.to_numeric(df_1['bedroom_toilet']))
    # result_list = list(pd.to_numeric(df_1['bedroom_toilet']))
    # plt.hist(result_list, bins=20)
    # plt.savefig(os.path.join(save_path, "bedroom_toilet.png"))
    # plt.clf()

    # # bedroom_balcony
    # df_1 = df[['frame_id', 'bedroom_balcony']]
    # df_1[df_1['bedroom_balcony'].isnull()] = -1
    # df_1[df_1['bedroom_balcony'] == 'true'] = 1
    # df_1[df_1['bedroom_balcony'] == 'false'] = 0
    # list(pd.to_numeric(df_1['bedroom_balcony']))
    # result_list = list(pd.to_numeric(df_1['bedroom_balcony']))
    # plt.hist(result_list, bins=20)
    # plt.savefig(os.path.join(save_path, "bedroom_balcony.png"))
    # plt.clf()
    #
    # # garden
    # df_1 = df[['frame_id', 'garden']]
    # df_1[df_1['garden'].isnull()] = -1
    # df_1[df_1['garden'] == 'true'] = 1
    # df_1[df_1['garden'] == 'false'] = 0
    # list(pd.to_numeric(df_1['garden']))
    # result_list = list(pd.to_numeric(df_1['garden']))
    # plt.hist(result_list, bins=20)
    # plt.savefig(os.path.join(save_path, "garden.png"))
    # plt.clf()

    # # loft
    # df_1 = df[['frame_id', 'loft']]
    # df_1[df_1['loft'].isnull()] = -1
    # df_1[df_1['loft'] == 'true'] = 1
    # df_1[df_1['loft'] == 'false'] = 0
    # list(pd.to_numeric(df_1['loft']))
    # result_list = list(pd.to_numeric(df_1['loft']))
    # plt.hist(result_list, bins=20)
    # plt.savefig(os.path.join(save_path, "loft.png"))
    # plt.clf()
    #
    # # toilet_face_ketchen_dis
    # df_1 = df[['frame_id', 'toilet_face_ketchen_dis']]
    # df_1[df_1['toilet_face_ketchen_dis'].isnull()] = -1
    # list(pd.to_numeric(df_1['toilet_face_ketchen_dis']))
    # result_list = list(pd.to_numeric(df_1['toilet_face_ketchen_dis']))
    # plt.hist(result_list, bins=50)
    # plt.savefig(os.path.join(save_path, "toilet_face_ketchen_dis.png"))
    # plt.clf()

    # # room_min_wdf
    # df_1 = df[['frame_id', 'room_min_wdf']]
    # df_1[df_1['room_min_wdf'].isnull()] = -1
    # list(pd.to_numeric(df_1['room_min_wdf']))
    # result_list = list(pd.to_numeric(df_1['room_min_wdf']))
    # plt.hist(result_list, bins=50)
    # plt.savefig(os.path.join(save_path, "room_min_wdf.png"))
    # plt.clf()
    #
    # # main_room_face_south
    # df_1 = df[['frame_id', 'main_room_face_south']]
    # df_1[df_1['main_room_face_south'].isnull()] = -1
    # df_1[df_1['main_room_face_south'] == 'true'] = 1
    # df_1[df_1['main_room_face_south'] == 'false'] = 0
    # list(pd.to_numeric(df_1['main_room_face_south']))
    # result_list = list(pd.to_numeric(df_1['main_room_face_south']))
    # plt.hist(result_list, bins=20)
    # plt.savefig(os.path.join(save_path, "main_room_face_south.png"))
    # plt.clf()

    # # main_room_wdf
    # df_1 = df[['frame_id', 'main_room_wdf']]
    # df_1[df_1['main_room_wdf'].isnull()] = -1
    # list(pd.to_numeric(df_1['main_room_wdf']))
    # result_list = list(pd.to_numeric(df_1['main_room_wdf']))
    # plt.hist(result_list, bins=50)
    # plt.savefig(os.path.join(save_path, "main_room_wdf.png"))
    # plt.clf()
    #
    # # main_room_face_entrance_dis
    # df_1 = df[['frame_id', 'main_room_face_entrance_dis']]
    # df_1[df_1['main_room_face_entrance_dis'].isnull()] = -1
    # df_1['main_room_face_entrance_dis'] = df_1['main_room_face_entrance_dis'].astype('float')
    # df_1[df_1['main_room_face_entrance_dis'] > 999] = -2
    # result_list = list(pd.to_numeric(df_1['main_room_face_entrance_dis']))
    # plt.hist(result_list, bins=50, log=True)
    # plt.savefig(os.path.join(save_path, "main_room_face_entrance_dis.png"))
    # plt.clf()

    # # main_room_face_toilet_dis
    # df_1 = df[['frame_id', 'main_room_face_toilet_dis']]
    # df_1[df_1['main_room_face_toilet_dis'].isnull()] = -1
    # df_1['main_room_face_toilet_dis'] = df_1['main_room_face_toilet_dis'].astype('float')
    # df_1[df_1['main_room_face_toilet_dis'] > 999] = -2
    # result_list = list(pd.to_numeric(df_1['main_room_face_toilet_dis']))
    # plt.hist(result_list, bins=50, log=True)
    # plt.savefig(os.path.join(save_path, "main_room_face_toilet_dis.png"))
    # plt.clf()
    #
    # # main_room_neighbor_kitchen
    # df_1 = df[['frame_id', 'main_room_neighbor_kitchen']]
    # df_1[df_1['main_room_neighbor_kitchen'].isnull()] = -1
    # df_1[df_1['main_room_neighbor_kitchen'] == 'true'] = 1
    # df_1[df_1['main_room_neighbor_kitchen'] == 'false'] = 0
    # list(pd.to_numeric(df_1['main_room_neighbor_kitchen']))
    # result_list = list(pd.to_numeric(df_1['main_room_neighbor_kitchen']))
    # plt.hist(result_list, bins=20)
    # plt.savefig(os.path.join(save_path, "main_room_neighbor_kitchen.png"))
    # plt.clf()

    # main_room_area_size
    df_1 = df[['frame_id', 'main_room_area_size']]
    df_1[df_1['main_room_area_size'].isnull()] = -1
    df_1['main_room_area_size'] = df_1['main_room_area_size'].astype('float')
    df_1[df_1['main_room_area_size'] > 999] = -2
    result_list = list(pd.to_numeric(df_1['main_room_area_size']))
    plt.hist(result_list, bins=50, range=(0, 50))
    plt.savefig(os.path.join(save_path, "main_room_area_size.png"))
    plt.clf()
    #
    # # main_room_toilet_size
    # df_1 = df[['frame_id', 'main_room_toilet_size']]
    # df_1[df_1['main_room_toilet_size'].isnull()] = -1
    # df_1['main_room_toilet_size'] = df_1['main_room_toilet_size'].astype('float')
    # df_1[df_1['main_room_toilet_size'] > 999] = -2
    # result_list = list(pd.to_numeric(df_1['main_room_toilet_size']))
    # plt.hist(result_list, bins=50)
    # plt.savefig(os.path.join(save_path, "main_room_toilet_size.png"))
    # plt.clf()
    #
    # # main_room_with_balcony
    # df_1 = df[['frame_id', 'main_room_with_balcony']]
    # df_1[df_1['main_room_with_balcony'].isnull()] = -1
    # df_1[df_1['main_room_with_balcony'] == 'true'] = 1
    # df_1[df_1['main_room_with_balcony'] == 'false'] = 0
    # list(pd.to_numeric(df_1['main_room_with_balcony']))
    # result_list = list(pd.to_numeric(df_1['main_room_with_balcony']))
    # plt.hist(result_list, bins=20)
    # plt.savefig(os.path.join(save_path, "main_room_with_balcony.png"))
    # plt.clf()
    #
    # # kitchen_wdf
    # df_1 = df[['frame_id', 'kitchen_wdf']]
    # df_1[df_1['kitchen_wdf'].isnull()] = -1
    # df_1['kitchen_wdf'] = df_1['kitchen_wdf'].astype('float')
    # df_1[df_1['kitchen_wdf'] > 999] = -2
    # result_list = list(pd.to_numeric(df_1['kitchen_wdf']))
    # plt.hist(result_list, bins=50)
    # plt.savefig(os.path.join(save_path, "kitchen_wdf.png"))
    # plt.clf()

    # # kitchen_kitchen_entrance_dis
    # df_1 = df[['frame_id', 'kitchen_kitchen_entrance_dis']]
    # df_1[df_1['kitchen_kitchen_entrance_dis'].isnull()] = -1
    # df_1['kitchen_kitchen_entrance_dis'] = df_1['kitchen_kitchen_entrance_dis'].astype('float')
    # df_1[df_1['kitchen_kitchen_entrance_dis'] > 999] = -2
    # result_list = list(pd.to_numeric(df_1['kitchen_kitchen_entrance_dis']))
    # plt.hist(result_list, bins=50)
    # plt.savefig(os.path.join(save_path, "kitchen_kitchen_entrance_dis.png"))
    # plt.clf()
    #
    # # kitchen_dinning_kitchen_dis
    # df_1 = df[['frame_id', 'kitchen_dinning_kitchen_dis']]
    # df_1[df_1['kitchen_dinning_kitchen_dis'].isnull()] = -1
    # df_1['kitchen_dinning_kitchen_dis'] = df_1['kitchen_dinning_kitchen_dis'].astype('float')
    # df_1[df_1['kitchen_dinning_kitchen_dis'] > 999] = -2
    # result_list = list(pd.to_numeric(df_1['kitchen_dinning_kitchen_dis']))
    # plt.hist(result_list, bins=50)
    # plt.savefig(os.path.join(save_path, "kitchen_dinning_kitchen_dis.png"))
    # plt.clf()
    #
    # # kitchen_area_size
    # df_1 = df[['frame_id', 'kitchen_area_size']]
    # df_1[df_1['kitchen_area_size'].isnull()] = -1
    # df_1['kitchen_area_size'] = df_1['kitchen_area_size'].astype('float')
    # df_1[df_1['kitchen_area_size'] > 999] = -2
    # result_list = list(pd.to_numeric(df_1['kitchen_area_size']))
    # plt.hist(result_list, bins=50)
    # plt.savefig(os.path.join(save_path, "kitchen_area_size.png"))
    # plt.clf()
    #
    # # parlour_wdf
    # df_1 = df[['frame_id', 'parlour_wdf']]
    # df_1[df_1['parlour_wdf'].isnull()] = -1
    # df_1['parlour_wdf'] = df_1['parlour_wdf'].astype('float')
    # df_1[df_1['parlour_wdf'] > 999] = -2
    # result_list = list(pd.to_numeric(df_1['parlour_wdf']))
    # plt.hist(result_list, bins=50, range=(-1, 1))
    # plt.savefig(os.path.join(save_path, "parlour_wdf.png"))
    # plt.clf()

    # # parlour_face_south
    # df_1 = df[['frame_id', 'parlour_face_south']]
    # df_1[df_1['parlour_face_south'].isnull()] = -1
    # df_1[df_1['parlour_face_south'] == 'true'] = 1
    # df_1[df_1['parlour_face_south'] == 'false'] = 0
    # list(pd.to_numeric(df_1['parlour_face_south']))
    # result_list = list(pd.to_numeric(df_1['parlour_face_south']))
    # plt.hist(result_list, bins=20)
    # plt.savefig(os.path.join(save_path, "parlour_face_south.png"))
    # plt.clf()
    #
    # parlour_area_size
    df_1 = df[['frame_id', 'parlour_area_size']]
    df_1[df_1['parlour_area_size'].isnull()] = -1
    df_1['parlour_area_size'] = df_1['parlour_area_size'].astype('float')
    df_1[df_1['parlour_area_size'] > 999] = -2
    result_list = list(pd.to_numeric(df_1['parlour_area_size']))
    plt.hist(result_list, bins=50, range=(0, 80))
    plt.savefig(os.path.join(save_path, "parlour_area_size.png"))
    plt.clf()
    #
    # # parlour_with_balcony
    # df_1 = df[['frame_id', 'parlour_with_balcony']]
    # df_1[df_1['parlour_with_balcony'].isnull()] = -1
    # df_1[df_1['parlour_with_balcony'] == 'true'] = 1
    # df_1[df_1['parlour_with_balcony'] == 'false'] = 0
    # list(pd.to_numeric(df_1['parlour_with_balcony']))
    # result_list = list(pd.to_numeric(df_1['parlour_with_balcony']))
    # plt.hist(result_list, bins=20)
    # plt.savefig(os.path.join(save_path, "parlour_with_balcony.png"))
    # plt.clf()
    #
    # # main_toilet_wdf
    # df_1 = df[['frame_id', 'main_toilet_wdf']]
    # df_1[df_1['main_toilet_wdf'].isnull()] = -1
    # df_1['main_toilet_wdf'] = df_1['main_toilet_wdf'].astype('float')
    # df_1[df_1['main_toilet_wdf'] > 999] = -2
    # result_list = list(pd.to_numeric(df_1['main_toilet_wdf']))
    # plt.hist(result_list, bins=50, range=(-1, 1))
    # plt.savefig(os.path.join(save_path, "main_toilet_wdf.png"))
    # plt.clf()
    #
    # # main_toilet_area_size
    # df_1 = df[['frame_id', 'main_toilet_area_size']]
    # df_1[df_1['main_toilet_area_size'].isnull()] = -1
    # df_1['main_toilet_area_size'] = df_1['main_toilet_area_size'].astype('float')
    # df_1[df_1['main_toilet_area_size'] > 999] = -2
    # result_list = list(pd.to_numeric(df_1['main_toilet_area_size']))
    # plt.hist(result_list, bins=50)
    # plt.savefig(os.path.join(save_path, "main_toilet_area_size.png"))
    # plt.clf()
    #
    # # parlour_toilet_wdf
    # df_1 = df[['frame_id', 'parlour_toilet_wdf']]
    # df_1[df_1['parlour_toilet_wdf'].isnull()] = -1
    # df_1['parlour_toilet_wdf'] = df_1['parlour_toilet_wdf'].astype('float')
    # df_1[df_1['parlour_toilet_wdf'] > 999] = -2
    # result_list = list(pd.to_numeric(df_1['parlour_toilet_wdf']))
    # plt.hist(result_list, bins=50, range=(-1, 1))
    # plt.savefig(os.path.join(save_path, "parlour_toilet_wdf.png"))
    # plt.clf()
    #
    # # parlour_toilet_area_size
    # df_1 = df[['frame_id', 'parlour_toilet_area_size']]
    # df_1[df_1['parlour_toilet_area_size'].isnull()] = -1
    # df_1['parlour_toilet_area_size'] = df_1['parlour_toilet_area_size'].astype('float')
    # df_1[df_1['parlour_toilet_area_size'] > 999] = -2
    # result_list = list(pd.to_numeric(df_1['parlour_toilet_area_size']))
    # plt.hist(result_list, bins=50, range=(-1, 20))
    # plt.savefig(os.path.join(save_path, "parlour_toilet_area_size.png"))
    # plt.clf()
    #
    # # parlour_toilet_face_kitchen_dis
    # df_1 = df[['frame_id', 'parlour_toilet_face_kitchen_dis']]
    # df_1[df_1['parlour_toilet_face_kitchen_dis'].isnull()] = -1
    # df_1['parlour_toilet_face_kitchen_dis'] = df_1['parlour_toilet_face_kitchen_dis'].astype('float')
    # df_1[df_1['parlour_toilet_face_kitchen_dis'] > 999] = -2
    # result_list = list(pd.to_numeric(df_1['parlour_toilet_face_kitchen_dis']))
    # plt.hist(result_list, bins=50)
    # plt.savefig(os.path.join(save_path, "parlour_toilet_face_kitchen_dis.png"))
    # plt.clf()

    # # parlour_toilet_face_entrance_dis
    # df_1 = df[['frame_id', 'parlour_toilet_face_entrance_dis']]
    # df_1[df_1['parlour_toilet_face_entrance_dis'].isnull()] = -1
    # df_1['parlour_toilet_face_entrance_dis'] = df_1['parlour_toilet_face_entrance_dis'].astype('float')
    # df_1[df_1['parlour_toilet_face_entrance_dis'] > 999] = -2
    # result_list = list(pd.to_numeric(df_1['parlour_toilet_face_entrance_dis']))
    # plt.hist(result_list, bins=50)
    # plt.savefig(os.path.join(save_path, "parlour_toilet_face_entrance_dis.png"))
    # plt.clf()
    #
    # # parlour_toilet_parlour_dis
    # df_1 = df[['frame_id', 'parlour_toilet_parlour_dis']]
    # df_1[df_1['parlour_toilet_parlour_dis'].isnull()] = -1
    # df_1['parlour_toilet_parlour_dis'] = df_1['parlour_toilet_parlour_dis'].astype('float')
    # df_1[df_1['parlour_toilet_parlour_dis'] > 999] = -2
    # result_list = list(pd.to_numeric(df_1['parlour_toilet_parlour_dis']))
    # plt.hist(result_list, bins=50)
    # plt.savefig(os.path.join(save_path, "parlour_toilet_parlour_dis.png"))
    # plt.clf()

    tmp = 0


def get_city_sta_table(tsv_path):
    frame_df0 = pd.read_csv(tsv_path, dtype='str', sep="\t", encoding='cp1252')
    frame_df0 = frame_df0[frame_df0['city_code'] != 'None']
    frame_df0 = frame_df0[frame_df0['city_code'].notnull()]
    all_city_code = frame_df0['city_code'].unique()
    all_face_label = frame_df0['face_label'].unique()

    city_list = []
    all_window_0_list = []
    all_window_1_list = []
    all_face_label_1_list = []
    all_face_label_2_list = []
    all_face_label_4_list = []
    all_face_label_8_list = []
    all_face_label_16_list = []

    for city in all_city_code:
        city_list.append(city)

        df_city = frame_df0[frame_df0['city_code'] == city]
        city_frame_num = df_city.shape[0] * 1.0
        # 全明
        all_window_0 = df_city[df_city['all_window'] == 'True'].shape[0] / city_frame_num
        all_window_1 = 1 - all_window_0
        all_window_0_list.append(all_window_0)
        all_window_1_list.append(all_window_1)
        # 朝向
        all_face_label_1 = df_city[df_city['face_label'] == '1'].shape[0] / city_frame_num
        all_face_label_2 = df_city[df_city['face_label'] == '2'].shape[0] / city_frame_num
        all_face_label_4 = df_city[df_city['face_label'] == '4'].shape[0] / city_frame_num
        all_face_label_8 = df_city[df_city['face_label'] == '8'].shape[0] / city_frame_num
        all_face_label_16 = df_city[df_city['face_label'] == '16'].shape[0] / city_frame_num
        all_face_label_1_list.append(all_face_label_1)
        all_face_label_2_list.append(all_face_label_2)
        all_face_label_4_list.append(all_face_label_4)
        all_face_label_8_list.append(all_face_label_8)
        all_face_label_16_list.append(all_face_label_16)
        #
        tmp = 0

    res_df = pd.DataFrame(columns=[
        'city_code',
        'all_window_0', 'all_window_1',
    ])
    res_df['city_code'] = city_list
    res_df['all_window_0'] = all_window_0_list
    res_df['all_window_1'] = all_window_1_list
    res_df['all_face_label_1'] = all_face_label_1_list
    res_df['all_face_label_2'] = all_face_label_2_list
    res_df['all_face_label_4'] = all_face_label_4_list
    res_df['all_face_label_8'] = all_face_label_8_list
    res_df['all_face_label_16'] = all_face_label_16_list
    res_df.to_csv(r'D:\newhouse_v2_annotation.csv')
    tmp = 0

if __name__ == "__main__":
    # tsv_path = r'D:\tsv\zhuc_newhouse_524.tsv'
    # tsv_path = r'D:\zhuc_newhouse.tsv'
    # get_city_sta_table(tsv_path)

    newhouse_feature_file = r'D:\tsv\newhouse_feature.tsv'
    save_path = r'D:\tsv\statistic_png'
    statistic_newhouse_feature(newhouse_feature_file, save_path)
