HDFS_PYTHON_PATH="hdfs://ns-fed/user/strategy/yudonghai/python.tgz#python"

zip -q -r ./lib.zip ./lib ./frame_remould ./frame_eval ./frame_score

spark-submit --py-files lib.zip \
--conf spark.dynamicAllocation.maxExecutors=120 \
--conf spark.dynamicAllocation.minExecutors=80 \
--conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
--conf spark.driver.maxResultSize=10G \
--conf spark.pyspark.python="python/bin/python" \
--conf spark.pyspark.driver.python="python2.7" \
frame_eval/newhouse_v2/statistic/spark_main_all.py 20210516 frame_eval/newhouse_v2/statistic/conf_all.yml
