# coding=utf-8
import json
import logging
import sys
import os
import yaml
import exceptions

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../../"))
sys.path.insert(0, os.getcwd())

import frame_eval.newhouse_v2.utils as utils
import frame_remould.utils.spark_util as spark_util


def frame_feature_propressor(row, **params):
    frame, result = utils.get_whole_frame_info(row, params["explain_params"], get_result)
    # basic = get_basic_info(row)
    # result.append(basic)
    return result


def get_result(frame_id, frame, doc_conf):
    result = [frame_id]
    if isinstance(frame, exceptions.Exception):
        n = 18
        for i in range(n):
            result.append('')
        # result.append(str(frame))
    else:
        newhouse_dict = frame.explain_message['newhouse_dict']
        result.append(str(frame.city_code))
        result.append(str(frame.room_cnt[0]))  # shi
        result.append(str(frame.room_cnt[1]))  # ting
        result.append(str(newhouse_dict['whole'][0]['face_label']))  # face_label
        result.append(str(newhouse_dict['whole'][0]['trans_label']))  # trans_label
        result.append(str(newhouse_dict['whole'][0]['all_window']))  # all_window
        # 主卧
        if newhouse_dict.get('main_room') is not None:
            result.append(str(newhouse_dict['main_room'][0]['wdf']))  # main_room_wdf
            result.append(str(newhouse_dict['main_room'][0]['face_south']))  # main_room_face_south
            result.append(str(newhouse_dict['main_room'][0]['area_size']))  # main_room_area_size
        else:
            result.append('')
            result.append('')
            result.append('')
        # 客厅
        if newhouse_dict.get('parlour') is not None:
            result.append(str(newhouse_dict['parlour'][0]['wdf']))  # parlour_wdf
            result.append(str(newhouse_dict['parlour'][0]['face_south']))  # parlour_face_south
            result.append(str(newhouse_dict['parlour'][0]['area_size']))  # parlour_area_size
        else:
            result.append('')
            result.append('')
            result.append('')
        # 厨房
        if newhouse_dict.get('kitchen') is not None:
            result.append(str(newhouse_dict['kitchen'][0]['wdf']))  # kitchen_wdf
            result.append(str(newhouse_dict['kitchen'][0]['area_size']))  # kitchen_area_size
        else:
            result.append('')
            result.append('')
        # 主卫
        if newhouse_dict.get('main_toilet') is not None:
            result.append(str(newhouse_dict['main_toilet'][0]['wdf']))  # main_toilet_wdf
            result.append(str(newhouse_dict['main_toilet'][0]['area_size']))  # main_area_size
        else:
            result.append('')
            result.append('')
        # 客卫
        if newhouse_dict.get('parlour_toilet') is not None:
            result.append(str(newhouse_dict['parlour_toilet'][0]['wdf']))  # parlour_toilet_wdf
            result.append(str(newhouse_dict['parlour_toilet'][0]['area_size']))  # parlour_area_size
        else:
            result.append('')
            result.append('')

    return result


def logic_func(driver, raw_df, **params):
    result_rdd = raw_df.rdd.map(lambda row: frame_feature_propressor(row, **params))
    result_df = driver.rdd_2_df(result_rdd)
    names = params["table_names"]
    result_df = result_df.toDF(*names)
    return result_df


def main():
    """ 主函数 """
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    if len(sys.argv) < 3:
        logging.error("no less than 2 arguments!")
        sys.exit()

    pt_date = sys.argv[1]
    config_file = sys.argv[2]

    with open(config_file, "r") as config_data:
        conf = yaml.load(config_data)
    with open("frame_eval/newhouse_v2/doc.yml", "r") as config_data:
        conf.update(yaml.load(config_data))
        conf["explain_params"]["doc"] = conf["doc"]

    # 从配置文件读取参数
    spark_config_key = "newhouse_v2_config"
    spark_params = conf.get(spark_config_key, None)
    if spark_params is None:
        logging.error("lack {} in config file".format(spark_config_key))
        sys.exit(-1)
    # ## 补充参数
    # pt
    spark_params["sql_params"]["pt_date"] = pt_date
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_function"] = logic_func
    # 存储pt
    spark_params["save_params"]["partition_params"] = {"pt": "{}000000".format(pt_date)}

    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()


def test(frame):
    """
    frame: frame id or frame json file path
    """
    frame_id, line = utils.get_frame_vector(frame)
    conf = dict()
    utils.collect_conf(r"frame_eval/newhouse_v2/conf_newhouse_v2.yml", conf)
    utils.collect_conf(r"frame_eval/newhouse_v2/doc.yml", conf)

    conf["explain_params"]["doc"] = conf["doc"]

    frame, result = utils.get_whole_frame_info(line, conf["explain_params"], get_result)


if __name__ == "__main__":
    if sys.platform not in ["win32", "darwin"]:
        main()
    else:
        # frame_id = 12000012004657
        # test(frame_id)
        frame_json = r'D:\frame.json'
        test(frame_json)