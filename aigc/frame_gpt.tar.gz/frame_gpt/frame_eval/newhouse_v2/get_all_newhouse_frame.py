# coding=utf-8
import argparse
import os
import sys

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../"))
sys.path.insert(0, os.getcwd())

from lib.file_util import get_file_stream

parser = argparse.ArgumentParser(description='')
parser.add_argument('--pt_data', default='',  required=True)
parser.add_argument('--sql_file', required=True)
# parser.add_argument('--sql_file', default='get_all_newhouse_frame.sql')
# parser.add_argument('--pt_data', default='2021')
args = parser.parse_args()

if __name__ == "__main__":
    pt_data = args.pt_data
    sql_file = args.sql_file

    f = get_file_stream(sql_file)
    sql_str = f.readlines()
    sql_str = "".join(sql_str).format(**{"pt_data": pt_data})

    save_sql_file = sql_file.split('.')
    save_sql_file[-2] += "_tmp"
    sql_file_tmp = ".".join(save_sql_file)
    with open(sql_file_tmp, "w") as f:
        f.write(sql_str)

    cmd = 'hive -f {sql_file} > frame_eval/newhouse_v2/all_newhouse_frame.tsv'.format(sql_file=sql_file_tmp)
    print(cmd)
    os.system(cmd)

    # if os.path.exists(sql_file):
    #     with open(sql_file, "r") as sql_data:
    #         sql_str = "".join(sql_data.readlines()).format(**{"pt_data": pt_data})
    #     print('zhuc after read all_nh')
    #     save_sql_file = sql_file.split('.')
    #     save_sql_file[-2] += "_tmp"
    #     sql_file_tmp = ".".join(save_sql_file)
    #     with open(sql_file_tmp, "w") as f:
    #         f.write(sql_str)
    #     print('zhuc after read tmp')
    # cmd = 'hive -f {sql_file} > frame_eval/newhouse_v2/all_newhouse_frame.tsv'.format(sql_file=sql_file_tmp)
    # print(cmd)
    # os.system(cmd)
    # tmp = 0

