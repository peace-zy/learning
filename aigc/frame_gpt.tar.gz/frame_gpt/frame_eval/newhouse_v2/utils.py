# coding=utf-8
import yaml
import json
import boto3
import os
import sys
import traceback
import pandas as pd
import pkg_resources
import numpy as np

# if os.name in ["nt", "posix"]:
if sys.platform in ["win32", "darwin"]:
    os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../"))
    sys.path.insert(0, os.getcwd())

from lib import entity
from lib import label_functions
from lib import eval_main
import frame_eval.feature_base_spark as feature_base_spark
import frame_eval.feature_liner_spark as feature_liner_spark
from lib import code_enum as ce
from frame_remould.floorplan import House

from frame_eval.newhouse_v2.lib_eval_main import newhouse_explain


def is_number(s):
    try:
        float(s)
        return True
    except Exception as e:
        pass
    # except ValueError:
    #     pass

    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except Exception as e:
        pass
    # except (TypeError, ValueError):
    #     pass

    return False


def collect_conf(conf_path, conf):
    """增加配置参数"""
    with open(conf_path, 'r') as conf_data:
        conf0 = yaml.load(conf_data)
        conf.update(conf0)


def get_s3_client():
    S3_AK = "223HG43LGIX9W3MWTOCL"
    S3_AKS = "tqWXh8kSyxM/QfgF34dMXFJcRrIIGfIIZkVVjSMH"
    s3_client = boto3.client('s3', region_name="cn-north-1", endpoint_url="http://storage.lianjia.com",
                             aws_access_key_id=S3_AK,
                             aws_secret_access_key=S3_AKS)
    return s3_client


def get_frame_vector(frame, city_code=110000):
    frame_id, line = None, None
    city_code = str(city_code)
    if is_number(frame):
        frame_id = str(frame)
        s3_client = get_s3_client()
        vector_response = s3_client.get_object(Bucket='frame-eval-image', Key=str(frame_id) + '.json')
        vector_str = vector_response['Body'].read()
        line = "\t".join([frame_id, 'image_id', vector_str, city_code])
    elif type(frame) == str:
        with open(frame, 'r') as f:
            ke_json = json.load(f)
        frame_id = str(888)
        line = "\t".join([frame_id, 'image_id', json.dumps(ke_json), city_code])
    elif type(frame) == unicode:
        frame_id = str(np.random.randint(100000))
        line = "\t".join([frame_id, 'image_id', frame.encode('utf8'), city_code])

    return frame_id, line


def get_whole_frame_info(row, conf, get_result, update_basic2frame):
    """
    conf: 必须含有关键key字段
    get_result: 得到结果的函数
    """
    frame = entity.Frame(row)
    try:
        frame_vector = frame.vector
        house = House()
        house.set_json_str(json.dumps(frame_vector))
        house.run()

        frame.set_house(house)
        frame.add_label(label_functions.label_base, **conf["label_params"])
        newhouse_explain(frame, **conf)
        update_basic2frame(row, frame)
        result = get_result(frame.frame_id, frame, conf["doc"])
    except Exception as e:
        traceback.print_exc()
        e1 = traceback.format_exc()
        result = get_result(frame.frame_id, e, conf["doc"])
    return frame, result


def get_offline_result(frame):
    """
    frame: frame id or frame json file path
    """
    frame_id, line = get_frame_vector(frame)
    conf = dict()
    collect_conf(r"frame_eval/newhouse_v2/conf_newhouse_v2.yml", conf)

    frame, result = get_whole_frame_info(line, conf["explain_params"], debug=True)


def get_annotation_features(features, frame, final_doc):
    """
    得到贝壳大数据分析特征
    :param features: 特征向量
    :param frame: frame类
    :param final_doc: 文案
    :return:
    """
    get_module_res = lambda *res: pkg_resources.resource_stream("frame_eval.newhouse_v2", os.path.join(*res))
    # conf = dict()
    f = get_module_res("doc.yml")
    conf = yaml.load(f)

    try:
        f = get_module_res("all_newhouse_frame.tsv")
        # f = open('frame_eval/newhouse_v2/all_newhouse_frame.tsv')
    except Exception as e:
        return dict(), conf['annotation_doc']
    df = pd.read_csv(f, dtype='str', sep="\t")
    city_code = str(frame.city_code)
    city_df = df[df['city_code'] == city_code]

    def get_enum_format(all_df, same_df):
        # 格式化枚举变量
        same_num = same_df.shape[0] * 1.0
        all_num = all_df.shape[0]
        ratio = same_num / all_num

        # 城市的总户型数太少, 不展示文案
        if all_num < 10:
            return None

        if ratio < 0.05:
            info = u'不足5%'
        elif ratio > 0.95:
            info = u'大于95%'
        else:
            info = unicode(str(round(ratio * 100, 1)) + '%')
        return info

    def get_continuous_format(all_series, value):
        """
        格式化连续变量
        all_series： 所有值的序列
        value: 当前数值
        """

        all_series = pd.to_numeric(all_series)
        sub_series = all_series[all_series < value]
        all_num = all_series.shape[0] * 1.0
        sub_num = sub_series.shape[0] * 1.0
        median = all_series.median()
        if all_num < 10:
            return None, None

        ratio = sub_num / all_num
        if ratio < 0.05:
            info = u'5%'
        elif ratio > 0.95:
            info = u'95%'
        else:
            info = unicode(str(round(ratio * 100, 1)) + '%')
        return info, median

    def get_percentage(all_series, value):
        all_series = pd.to_numeric(all_series)
        sub_series = all_series[all_series < value]
        all_num = all_series.shape[0] * 1.0
        sub_num = sub_series.shape[0] * 1.0
        ratio = sub_num / all_num * 100.0
        return round(ratio, 2)

    try:
        # 整屋朝向
        whole_face_df = city_df[city_df['whole_face'].notnull()]
        # if whole_face_df.shape[0] == 0:
        #     return dict(), conf['annotation_doc']

        this_lighting_face = final_doc['lighting']['whole'][0].get('lighting_face')
        if this_lighting_face is not None and whole_face_df.shape[0] != 0:
            this_whole_face = this_lighting_face['enum']
            same_whole_face_df = whole_face_df[whole_face_df['whole_face'] == this_whole_face.encode('utf8')]

            info = get_enum_format(whole_face_df, same_whole_face_df)
            if info is not None:
                features['whole'][0]['anno_whole_face'] = info
        # 通透性
        whole_trans_df = city_df[city_df['whole_trans'].notnull()]
        this_lighting_trans = final_doc['lighting']['whole'][0].get('lighting_transparent')
        if this_lighting_trans is not None and whole_trans_df.shape[0] != 0:
            this_value = this_lighting_trans['enum']
            same_df = whole_trans_df[whole_trans_df['whole_trans'] == this_value.encode('utf8')]
            face_dict = {
                u'优秀': u'南北通透',
                u'良好': u'邻侧通风',
                u'一般': u'单侧通风',
            }
            info = get_enum_format(whole_trans_df, same_df)
            # if info not in [None, u'不足5%', u'大于95%']:
            if info not in [None]:
                features['whole'][0]['anno_whole_trans'] = info
                features['whole'][0]['anno_whole_trans_str'] = face_dict[this_value]
        # 全明格局
        whole_all_win_df = city_df[city_df['whole_all_win'].notnull()]
        this_all_win = final_doc['lighting']['whole'][0].get('lighting_all_window')
        if this_all_win is not None:
            this_value = this_all_win['enum'].encode('utf8')
            same_df = whole_all_win_df[whole_all_win_df['whole_all_win'] == this_value]
            info = get_enum_format(whole_all_win_df, same_df)
            if info not in [None, u'不足5%']:
                features['whole'][0]['anno_whole_all_win'] = info
        # 主卧采光
        main_lighting_df = city_df[city_df['main_room_light'].notnull()]
        main_room_doc = final_doc['lighting'].get('main_room')
        if main_room_doc is not None:
            this_main_light = main_room_doc[0].get('lighting_light')
            if this_main_light is not None:
                this_value = this_main_light['enum'].encode('utf8')
                same_df = main_lighting_df[main_lighting_df['main_room_light'] == this_value]
                info = get_enum_format(main_lighting_df, same_df)
                if info not in [None]:
                    features['main_room'][0]['anno_lighting'] = info
        # 客厅采光
        parlour_lighting_df = city_df[city_df['parlour_light'].notnull()]
        parlour_doc = final_doc['lighting'].get('parlour')
        if parlour_doc is not None:
            this_parlor_light = parlour_doc[0].get('lighting_light')
            if this_parlor_light is not None:
                this_value = this_parlor_light['enum'].encode('utf8')
                same_df = parlour_lighting_df[parlour_lighting_df['parlour_light'] == this_value]
                info = get_enum_format(parlour_lighting_df, same_df)
                if info not in [None]:
                    features['parlour'][0]['anno_lighting'] = info
        # 厨房采光
        kitchen_lighting_df = city_df[city_df['kitchen_light'].notnull()]
        kitchen_doc = final_doc['lighting'].get('kitchen')
        if kitchen_doc is not None:
            this_kitchen_light = kitchen_doc[0].get('lighting_light')
            if this_kitchen_light is not None:
                this_value = this_kitchen_light['enum'].encode('utf8')
                same_df = kitchen_lighting_df[kitchen_lighting_df['kitchen_light'] == this_value]
                info = get_enum_format(kitchen_lighting_df, same_df)
                if info not in [None]:
                    features['kitchen'][0]['anno_lighting'] = info
        # 主卫采光
        main_toilet_lighting_df = city_df[city_df['main_toilet_light'].notnull()]
        main_toilet_doc = final_doc['lighting'].get('main_toilet')
        if main_toilet_doc is not None:
            this_main_toilet_light = main_toilet_doc[0].get('lighting_light')
            if this_main_toilet_light is not None:
                this_value = this_main_toilet_light['enum'].encode('utf8')
                same_df = main_toilet_lighting_df[main_toilet_lighting_df['main_toilet_light'] == this_value]
                info = get_enum_format(main_toilet_lighting_df, same_df)
                if info not in [None]:
                    features['main_toilet'][0]['anno_lighting'] = info
        # 客卫采光
        parlour_toilet_lighting_df = city_df[city_df['parlour_toilet_light'].notnull()]
        parlour_toilet_doc = final_doc['lighting'].get('parlour_toilet')
        if parlour_toilet_doc is not None:
            this_parlour_toilet_light = parlour_toilet_doc[0].get('lighting_light')
            if this_parlour_toilet_light is not None:
                this_value = this_parlour_toilet_light['enum'].encode('utf8')
                same_df = parlour_toilet_lighting_df[parlour_toilet_lighting_df['main_toilet_light'] == this_value]
                info = get_enum_format(parlour_toilet_lighting_df, same_df)
                if info not in [None]:
                    features['parlour_toilet'][0]['anno_lighting'] = info
        # 主卧面积
        main_room_area_df = city_df[city_df['main_room_area_size'].notnull()]
        main_room_feature = features.get('main_room')
        # this_main_room_area = None
        if main_room_feature is not None:
            this_main_room_area = main_room_feature[0]['area_size']
            all_series = main_room_area_df['main_room_area_size']
            info, median = get_continuous_format(all_series, this_main_room_area)
            if info not in [None]:
                features['main_room'][0]['anno_area_size_info'] = info
                median = str(int(median))
                features['main_room'][0]['anno_area_size_median'] = median
        # 客厅面积
        parlour_area_df = city_df[city_df['parlour_area_size'].notnull()]
        parlour_feature = features.get('parlour')
        if parlour_feature is not None:
            this_parlour_area = parlour_feature[0]['area_size']
            all_series = parlour_area_df['parlour_area_size']
            info, median = get_continuous_format(all_series, this_parlour_area)
            if info not in [None]:
                features['parlour'][0]['anno_area_size_info'] = info
                median = str(int(median))
                features['parlour'][0]['anno_area_size_median'] = median
        # 厨房面积
        kitchen_area_df = city_df[city_df['kitchen_area_size'].notnull()]
        kitchen_feature = features.get('kitchen')
        if kitchen_feature is not None:
            this_kitchen_area = kitchen_feature[0]['area_size']
            all_series = kitchen_area_df['kitchen_area_size']
            info, median = get_continuous_format(all_series, this_kitchen_area)
            if info not in [None]:
                features['kitchen'][0]['anno_area_size_info'] = info
                median = str(int(median))
                features['kitchen'][0]['anno_area_size_median'] = median
        # 主卫面积
        main_toilet_area_df = city_df[city_df['main_toilet_area_size'].notnull()]
        main_toilet_feature = features.get('main_toilet')
        if main_toilet_feature is not None:
            this_main_toilet_area = main_toilet_feature[0]['area_size']
            all_series = main_toilet_area_df['main_toilet_area_size']
            info, median = get_continuous_format(all_series, this_main_toilet_area)
            if info not in [None]:
                features['main_toilet'][0]['anno_area_size_info'] = info
                median = str(int(median))
                features['main_toilet'][0]['anno_area_size_median'] = median
        # 客卫面积
        parlour_toilet_area_df = city_df[city_df['parlour_toilet_area_size'].notnull()]
        parlour_toilet_feature = features.get('parlour_toilet')
        if parlour_toilet_feature is not None:
            this_parlour_toilet_area = parlour_toilet_feature[0]['area_size']
            all_series = parlour_toilet_area_df['parlour_toilet_area_size']
            info, median = get_continuous_format(all_series, this_parlour_toilet_area)
            if info not in [None]:
                features['parlour_toilet'][0]['anno_area_size_info'] = info
                median = str(int(median))
                features['parlour_toilet'][0]['anno_area_size_median'] = median
        # 总得分排位
        total_score_df = city_df[city_df['total_score'].notnull()]
        total_score = features.get('whole')[0].get('total_score')
        if total_score is not None:
            all_series = total_score_df['total_score'].astype(float)
            info, median = get_continuous_format(all_series, float(total_score))
            if info not in [None]:
                features['whole'][0]['anno_total_score_info'] = info
                median = str(int(median))
                features['whole'][0]['anno_total_score_median'] = median
                # 新房3.0增加百分比判断
                features['whole'][0]['anno_total_score_percentage'] = get_percentage(all_series, float(total_score))

        return features, conf['annotation_doc']
    except Exception as e:
        return dict(), conf['annotation_doc']


if __name__ == "__main__":
    frame_id = 11000005039640
    get_offline_result(frame_id)
