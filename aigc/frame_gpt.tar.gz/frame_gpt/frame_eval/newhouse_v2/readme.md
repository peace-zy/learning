## 大数据分析文件的获取
1. 修改 get_all_newhouse_frame.sql 中的pt
2. 运行
`
hive -f get_all_newhouse_frame.sql > all_newhouse_frame.tsv
`
