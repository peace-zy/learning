# coding=utf-8
import json
import logging
import sys
import os
import yaml
import exceptions
import pandas as pd
import collections
import functools
import pkg_resources
import traceback

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../"))
sys.path.insert(0, os.getcwd())

import frame_eval.newhouse_v2.utils as utils
from lib import  spark_util
from lib.file_util import get_file_stream

ROOM_TYPE_ORDER = ['whole', 'main_room', 'sub_room', 'parlour', 'kitchen', 'main_toilet', 'parlour_toilet']

STAT_FUNCTION_CODE_DICT = {
    "110006002": u"普通住宅",
}

FITMENT_STATUS_CODE_DICT = {
    "120002002": u"毛坯",
    "120002003": u"非毛坯",
    # "120002003": u"精装"
}

# bind_building = [ {'building_id':2012048946864,'building_name':'1号楼','desc':'边户'}, {'building_id':2012048159601,'building_name':'3号楼','desc':'边户'}, {'building_id':2012048223571,'building_name':'4号楼','desc':'边户'}]
bind_building = [{"building_id": 16000000029876, "building_name": "3号楼", "desc": ""}]
BASIC_INFO = {
    "face_vectors_img": "url",
    "visual_areas_img": "url",
    "movement_areas_img": "url",
    "wd_vectors_img": "url",
    "moving_lines_img": "url",
    "main_img": "url",
    "standard_url": "url",
    "floor_area": "101.00",
    "bind_building_json": "",
    # "bind_building_json": json.dumps(bind_building),
    "avg_price": "64000",
    "stat_function_code": "110006002",
    "fitment_status_code": "120002003",
    "resblockdel_id": "3711063706435",
    "face_vectors_legend": [{"title": "通风方向", "color": "#3bc48b"}],
    "visual_areas_legend": [{"title": "入户门可见范围", "color": "#3bc48b"}],
    "movement_areas_legend": [{"title": "静区", "color": "#3bc48b"}, {"title": "动区", "color": "#fa5741"}],
    "wd_vectors_legend": [{"title": "面宽", "color": "#3bc48b"}, {"title": "进深", "color": "#fa5741"}],
    "moving_lines_legend": [{"title": "访客动线", "color": "#3bc48b"},
                            {"title": "家务动线", "color": "#fa5741"},
                            {"title": "居住动线", "color": "#3072f6"}],
    "room_cnt": 3,
    "parlor_cnt": 2,
    "toilet_cnt": 2,
}


# debug使用
# BASIC_INFO = 'xxxx'


def frame_feature_propressor(row, **params):
    """特征处理方法"""
    frame, result = utils.get_whole_frame_info(
        row, params["explain_params"], get_result, update_basic2frame)
    basic = json.dumps(get_basic_info(row, frame))
    result.append(basic)
    return result


def get_basic_info(row, frame):
    """debug使用的，模拟其它表数据"""
    basic_info = {
        "floor_area": str(row["floor_area"]),
        "resblockdel_id": str(row["resblockdel_id"]),
        "bind_building_json": row["bind_building_json"],
        "fitment_status_code": str(row["fitment_status_code"]),
        "stat_function_code": str(row["stat_function_code"]),
        "moving_lines_img": row["moving_lines_img"],
        "visual_areas_img": row["visual_areas_img"],
        "face_vectors_img": row["face_vectors_img"],
        "wd_vectors_img": row["wd_vectors_img"],
        "movement_areas_img": row["movement_areas_img"],
        "main_img": row["main_img"],
        "city_code": frame.city_code,
        "standard_url": row["standard_url"],
        "avg_price": row["avg_price"],

        "face_vectors_legend": [{"title": "通风方向", "color": "#3bc48b"}],
        "visual_areas_legend": [{"title": "入户门可见范围", "color": "#3bc48b"}],
        "movement_areas_legend": [{"title": "静区", "color": "#3bc48b"}, {"title": "动区", "color": "#fa5741"}],
        "wd_vectors_legend": [{"title": "面宽", "color": "#3bc48b"}, {"title": "进深", "color": "#fa5741"}],
        "moving_lines_legend": [{"title": "访客动线", "color": "#3bc48b"},
                                {"title": "家务动线", "color": "#fa5741"},
                                {"title": "居住动线", "color": "#3072f6"}],
        "room_cnt": row["room_cnt"],
        "parlor_cnt": row["parlor_cnt"],
        "toilet_cnt": row["toilet_cnt"],
    }

    def update_moving_lines_legend(basic_info, frame):
        # 更新基本信息中的动线图例，如果某个动线长度为0，不显示图例
        if frame.explain_message.get('newhouse_dict') is None:
            return None
        if frame.explain_message['newhouse_dict'].get('whole') is None:
            return None
        work_len = frame.explain_message['newhouse_dict']['whole'][0].get('work_len', 0)
        guest_len = frame.explain_message['newhouse_dict']['whole'][0].get('guest_len', 0)
        living_len = frame.explain_message['newhouse_dict']['whole'][0].get('living_len', 0)
        all_legend = []
        if work_len > 0:
            all_legend.append({"title": "家务动线", "color": "#fa5741"})
        if guest_len > 0:
            all_legend.append({"title": "访客动线", "color": "#3bc48b"})
        if living_len > 0:
            all_legend.append({"title": "居住动线", "color": "#3072f6"})
        basic_info['moving_lines_legend'] = all_legend

    if basic_info.get('moving_lines_legend') is not None:
        update_moving_lines_legend(basic_info, frame)

    return basic_info


def logic_func(driver, raw_df, **params):
    result_rdd = raw_df.rdd.map(lambda row: frame_feature_propressor(row, **params))
    result_df = driver.rdd_2_df(result_rdd)
    names = params["table_names"]
    result_df = result_df.toDF(*names)
    return result_df


def update_basic2frame(row, frame):
    """
    更新其它表中的信息到特征中
    :param row: 户型每行数据
    :param frame: frame基础类
    :return:
    """
    if sys.platform in ['win32', 'darwin']:
        basic_info = BASIC_INFO
    else:
        basic_info = get_basic_info(row, frame)

    def update_bind_building_json(basic_info, frame):
        # 更新户型所在楼栋信息
        res_list = []
        if basic_info['bind_building_json'] != '':
            for building in json.loads(basic_info['bind_building_json']):
                building_str = building['building_name']
                if building['desc'] != '':
                    building_str += u'(' + building['desc'] + u')'
                res_list.append(building_str)
        res = ';'.join(res_list)
        # res = unicode(res, 'utf-8')
        frame.explain_message['newhouse_dict']['whole'][0]['bind_building_json'] = res

    def update_stat_function_code(basic_info, frame):
        # 更新物业信息
        if STAT_FUNCTION_CODE_DICT.get(basic_info['stat_function_code']) is not None:
            stat = STAT_FUNCTION_CODE_DICT.get(basic_info['stat_function_code'])
        else:
            stat = '其它'
        frame.explain_message['newhouse_dict']['whole'][0]['stat_function_code'] = stat

    def update_fitment_status_code(basic_info, frame):
        # 更新装修信息
        if FITMENT_STATUS_CODE_DICT.get(basic_info['fitment_status_code']) is not None:
            fitment = FITMENT_STATUS_CODE_DICT.get(basic_info['fitment_status_code'])
            if fitment is not None:
                frame.explain_message['newhouse_dict']['whole'][0]['fitment_status_code'] = fitment

    def update_floor_area(basic_info, frame):
        # 更新建筑面积信息
        if utils.is_number(basic_info.get('floor_area')):
            floor_area = int(float(basic_info.get('floor_area')))
        else:
            floor_area = ''
        frame.explain_message['newhouse_dict']['whole'][0]['floor_area'] = floor_area

    def update_price(basic_info, frame):
        # 更新价格信息
        floor_area = basic_info.get('floor_area')
        avg_price = basic_info.get('avg_price')
        if floor_area == 0 or floor_area is None:
            return None
        if avg_price == 0 or avg_price is None:
            return None
        frame.explain_message['newhouse_dict']['whole'][0]['avg_price'] = int(float(avg_price))
        total_price = int(float(avg_price) * float(floor_area) / 10000)
        frame.explain_message['newhouse_dict']['whole'][0]['total_price'] = total_price
    def update_room_cnt(basic_info, frame):
        # 更新厅室卫信息
        frame.explain_message['newhouse_dict']['whole'][0]['room_cnt'] = int(basic_info.get('room_cnt'))
        frame.explain_message['newhouse_dict']['whole'][0]['parlor_cnt'] = int(basic_info.get('parlor_cnt'))
        frame.explain_message['newhouse_dict']['whole'][0]['toilet_cnt'] = int(basic_info.get('toilet_cnt'))

    if basic_info.get('bind_building_json') is not None:
        update_bind_building_json(basic_info, frame)
    if basic_info.get('fitment_status_code') is not None:
        update_fitment_status_code(basic_info, frame)
    if basic_info.get('stat_function_code') is not None:
        update_stat_function_code(basic_info, frame)
    if basic_info.get('floor_area') is not None:
        update_floor_area(basic_info, frame)
    if basic_info.get('avg_price') is not None:
        update_price(basic_info, frame)
    if basic_info.get('room_cnt') is not None \
        and basic_info.get('parlor_cnt') is not None \
        and basic_info.get('toilet_cnt') is not None:
        update_room_cnt(basic_info, frame)

    return None


def collect_docs_into_function_module(final_doc):
    origin_key = ['space', 'lighting']
    target_key = 'function'
    ignore_key = ['whole']
    for _fea_key in origin_key:
        for _key, _value in final_doc[_fea_key].items():
            if _key in ignore_key or _key not in final_doc[target_key]:
                continue
            for _index, _room in enumerate(_value):
                final_doc[target_key][_key][_index].update(_room)


def get_result(frame_id, frame, doc_conf):
    """
    后处理结果
    :param frame_id:
    :param frame: frame 基础类
    :param doc_conf: 文案配置参数
    :return:
    """
    result = []
    result.append(frame_id)
    if isinstance(frame, exceptions.Exception) or isinstance(frame, str):
        result.append('')  # feature
        result.append('')  # result
        result.append(str(frame))
    else:
        error = ''
        features = frame.explain_message['newhouse_dict']

        set_usable_area(frame_id, features)

        docs = doc_format(features, doc_conf)
        final_doc = postprocess_doc(docs)
        # 获取户型大数据分析注释文案
        anno_features, anno_conf = utils.get_annotation_features(features, frame, final_doc)
        anno_docs = doc_format(features, anno_conf)
        final_anno_doc = postprocess_doc(anno_docs)

        merge_docs(final_doc, final_anno_doc)
        update_preview(final_doc, final_anno_doc)

        # 户型解读3.0版本将分间解读的信息添加到房屋功能中
        collect_docs_into_function_module(final_doc)

        result.append(json.dumps(features))
        result.append(json.dumps(final_doc))
        result.append(error)

    return result


def set_usable_area(frame_id, features):
    """离线增加得房率和使用面积信息"""
    f = get_file_stream('frame_eval/newhouse_v2/newhouse_usable_area.CSV')
    df = pd.read_csv(f)

    df0 = df[df['frame_id'] == str(frame_id)].reset_index()
    if df0.shape[0] == 0:
        return None
    usable_area = df0.iloc[0]['usable_area']
    floor_area = df0.iloc[0]['floor_area']
    if is_number(features['whole'][0].get('floor_area')):
        floor_area = features['whole'][0].get('floor_area')
    usage_ratio = float(usable_area) / float(floor_area)
    features['whole'][0]['usable_area'] = str(int(usable_area))
    features['whole'][0]['usage_ratio'] = str(int(usage_ratio * 100)) + '%'
    return None


def update_preview(final_doc, final_anno_doc):
    """增加预览preview内容"""
    preview = {
        "lighting_preview": "",
        "space_preview": "",
        "function_preview": "",
    }
    if final_doc["lighting"].get('whole') is not None:
        for k, v in final_doc["lighting"]["whole"][0].items():
            preview["lighting_preview"] = v["simple_explain"]
            if preview["lighting_preview"] != "":
                break
    for k, v in final_doc["space"]["whole"][0].items():
        preview["space_preview"] = v["simple_explain"]
        if preview["space_preview"] != "":
            break
    for k, v in final_doc["function"].items():
        if k == 'whole' or k == 'sub_room':
            continue
        for vi in v:
            for k1, v1 in vi.items():
                if 'function_area_size_detail' in k1:
                    if final_anno_doc["function"].get(k) is None:
                        preview["function_preview"] = final_doc["function"][k][0][k1]['detailed_explain']
                    else:
                        preview["function_preview"] = final_anno_doc["function"][k][0][k1]["annotation"]
                    break
            if preview["function_preview"] != "":
                break
        if preview["function_preview"] != "":
            break

    final_doc["preview"] = preview
    return None


def merge_docs(final_doc, final_anno_doc):
    """合并文案, 增加贝壳大数据统计"""
    for k1, v1 in final_anno_doc.items():
        if k1 == "statistic":
            continue
        for k2, v2 in v1.items():
            for k3, v3 in v2[0].items():
                final_doc[k1][k2][0][k3]['annotation'] = v3['annotation']
                final_doc[k1][k2][0][k3]['detailed_explain'] += u'\n' + v3['annotation']


def doc_format(features, doc_conf):
    """
    生成文案模块
    features: 各个功能区的特征字典
    doc_conf: 配置文案
    """
    room_type_lst = doc_conf["room_type_order"]
    exp_dict = doc_conf["explain"]

    final_doc = dict()
    for room_type in room_type_lst:
        room_feature_list = features.get(room_type)
        room_exp_dict = exp_dict.get(room_type)

        if room_feature_list is None:
            continue
        docs = get_room_doc(room_feature_list, room_exp_dict)

        final_doc[room_type] = docs
    return final_doc


def postprocess_doc(final_doc):
    """
    后处理文案成最终输出形式
    :param final_doc:
    :return:
    """
    post_doc = {
        "lighting": collections.OrderedDict(),
        "summary": collections.OrderedDict(),
        "space": collections.OrderedDict(),
        "function": collections.OrderedDict(),
    }
    for rm, docs0 in final_doc.items():
        rm_type = docs0['room_type']
        for k, v in post_doc.items():
            post_doc[k][rm_type] = list()
        for doc_idx, docs1 in enumerate(docs0['doc']):
            for k, v in post_doc.items():
                post_doc[k][rm_type].append(dict())

    for rm, docs0 in final_doc.items():
        rm_type = docs0['room_type']
        # rm_type_name = docs0['room_type_name']
        for doc_idx, docs1 in enumerate(docs0['doc']):
            for dim_idx, dim in enumerate(docs1['dims']):
                rm_dict = dict()
                rm_dict['dim_name'] = dim['dim_name']
                rm_dict['enum'] = dim['enum']
                rm_dict['level'] = dim['level']
                rm_dict['compare_desc'] = dim['compare_desc']
                rm_dict['compare_label'] = dim['compare_label']
                rm_dict['compare_lev'] = dim['compare_lev']
                rm_dict['simple_explain'] = dim['simple_explain']
                rm_dict['detailed_explain'] = dim['detailed_explain']
                rm_dict['annotation'] = dim['annotation']
                rm_dict['display_item'] = dim['display_item']
                rm_dict['display_sub_item'] = dim['display_sub_item']
                # 次卧需要排序
                # if dim['room_type_name'] == u'次卧':
                #     rm_dict['room_type_name'] += str(doc_idx + 1)
                if dim['display_sub_item'] == u'次卧' and len(docs0['doc']) > 1:
                    rm_dict['display_sub_item'] += str(doc_idx + 1)
                module = dim['module']

                # post_doc[module][rm_type][doc_idx].append(rm_dict)
                post_doc[module][rm_type][doc_idx][dim['dim_name']] = rm_dict
    # 删除空list
    for module, rms in post_doc.items():
        for rm_type, rm_list in rms.items():
            rms[rm_type] = filter(lambda x: len(x) > 0, rm_list)
            if len(rms[rm_type]) == 0:
                rms.pop(rm_type)

    statistic = dict()
    total_cnt = 0
    for k0, v0 in post_doc.items():
        for k1, v1 in v0.items():
            total_cnt += len(v1)

    # 功能区排序
    def compare_room_type(type1, type2):
        idx1, idx2 = 100, 100
        if type1[0] in ROOM_TYPE_ORDER:
            idx1 = ROOM_TYPE_ORDER.index(type1[0])
        if type2[0] in ROOM_TYPE_ORDER:
            idx2 = ROOM_TYPE_ORDER.index(type2[0])
        return idx1 - idx2

    for k, v in post_doc.items():
        post_doc[k] = collections.OrderedDict(sorted(v.items(), key=functools.cmp_to_key(compare_room_type)))

    statistic['total_cnt'] = total_cnt
    post_doc['statistic'] = statistic
    # 全明格局和南北通透同时命中，删除一个副标题
    if post_doc['lighting'].get("whole") is not None:
        if post_doc['lighting']['whole'][0].get('lighting_all_window') is not None \
                and post_doc['lighting']['whole'][0].get('lighting_transparent') is not None:
            post_doc['lighting']['whole'][0]['lighting_all_window']['display_sub_item'] = u''

    return post_doc


def get_room_doc(room_feature_list, room_exp_dict):
    """参考decoration_spark.py"""
    room_type_name = room_exp_dict["name"]
    room_type = room_exp_dict["type"]
    room_range = room_exp_dict["range"]
    dims_conf = room_exp_dict["dims"]

    # if not key_vars_lst:
    #     return None
    room_feature_list2 = room_feature_list
    if room_range == "max":
        room_feature_list2 = [sorted(room_feature_list, key=lambda x: x["area_size"])[-1]]

    room_doc_list = []
    for room_fea in room_feature_list2:
        room_doc = one_room_doc(room_fea, dims_conf)
        for d in room_doc:
            d.update({'room_type_name': room_type_name})
        room_doc_list.append({
            "dims": room_doc,
            "area_id": room_fea.get("area_id"),
        })
    return {
        "room_type_name": room_type_name,
        "room_type": room_type,
        "doc": room_doc_list,
    }


def one_room_doc(room_fea, dims_conf):
    one_room_doc = []
    for dim in dims_conf:
        dim_name = dim.get("dim_name", None)
        dim_condition = dim.get("dim_condition", [])
        dim_condition_conn = dim.get("dim_condition_conn", "")
        simple_explain = unicode(dim.get("simple_explain", u""))
        detailed_explain = unicode(dim.get("detailed_explain", u""))
        annotation = unicode(dim.get("annotation", u""))
        compare_desc = unicode(dim.get("compare_desc", u""))
        compare_label = unicode(dim.get("compare_label", u""))
        compare_lev = unicode(dim.get("compare_lev", u""))
        module = unicode(dim.get("module", u""))
        enum = unicode(dim.get("enum", u""))
        level = unicode(dim.get("level", u""))
        display_item = unicode(dim.get("display_item", u""))
        display_sub_item = unicode(dim.get("display_sub_item", u""))
        doc_vars = dim.get("doc_vars", [])

        # 删除None值的key
        # for k, v in room_fea.items():
        #     if v is None:
        #         room_fea.pop(k)

        dim_flag = condition_check(room_fea, dim_condition, dim_condition_conn)
        if dim_flag is None:
            return None
        if not dim_flag:
            continue

        dim_result = doc_group_getter(doc_vars, room_fea)
        if not dim_result:
            continue
        if dim_result is None:
            return None
        full_vars = dict(room_fea, **dim_result)
        # 格式化str到unicode
        for k, v in full_vars.items():
            if isinstance(v, str):
                v1 = unicode(v, 'utf-8')
                full_vars[k] = v1

        one_room_doc.append({
            "dim_name": dim_name,
            "simple_explain": simple_explain.format(**full_vars),
            "detailed_explain": detailed_explain.format(**full_vars),
            "module": module.format(**full_vars),
            "enum": enum.format(**full_vars),
            "level": level.format(**full_vars),
            "display_item": display_item.format(**full_vars),
            "display_sub_item": display_sub_item.format(**full_vars),
            "annotation": annotation.format(**full_vars),
            "compare_desc": compare_desc.format(**full_vars),
            "compare_label": compare_label.format(**full_vars),
            "compare_lev": compare_lev.format(**full_vars),
        })
    return one_room_doc


def is_number(s):
    try:
        float(s)
        return True
    except Exception as e:
        pass
    # except ValueError:
    #     pass

    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except Exception as e:
        pass
    # except (TypeError, ValueError):
    #     pass

    return False


def condition_check(key_dict, conditions, condition_conn):
    cond_results = []
    for cond in conditions:
        k, comp, target = cond
        if is_number(target):
            target = float(target)
        value = key_dict.get(k)
        if is_number(value):
            value = float(value)
        if comp == "notnull":
            cond_results.append(value is not None)
        elif comp == "<":
            cond_results.append(value < target)
        elif comp == "<=":
            cond_results.append(value <= target)
        elif comp == ">":
            cond_results.append(value > target)
        elif comp == ">=":
            cond_results.append(value >= target)
        elif comp == "==":
            cond_results.append(value == target)
        elif comp == "!=":
            cond_results.append(value != target)
        elif comp == "true":
            cond_results.append(value is True)
        elif comp == "false":
            cond_results.append(value is False)
        elif comp == "in":
            cond_results.append(value in set(target.strip().split(",")))
        else:
            logging.error("unknown operator！")
            return None
    result = None
    if condition_conn == "all":
        result = all(cond_results)
    elif condition_conn == "any":
        result = any(cond_results)
    else:
        logging.error("unknown condition connection {}!!".format(condition_conn))
    return result


def doc_group_getter(doc_vars, room_keys):
    new_result = {}
    for doc_group in doc_vars:
        for doc_item in doc_group:
            item_cond = doc_item["cond"]
            item_cond_conn = doc_item["cond_conn"]
            new_vars = doc_item["vars"]
            item_flag = condition_check(room_keys, item_cond, item_cond_conn)
            if item_flag is None:
                return None
            if item_flag:
                new_result.update(new_vars)
                break
    return new_result


def main():
    """ 主函数 """
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    if len(sys.argv) < 3:
        logging.error("no less than 2 arguments!")
        sys.exit()

    pt_date = sys.argv[1]
    config_file = sys.argv[2]

    f = get_file_stream(config_file)
    conf = yaml.load(f)
    f = get_file_stream("frame_eval/newhouse_v2/doc.yml")
    conf.update(yaml.load(f))
    conf["explain_params"]["doc"] = conf["doc"]

    # with open(config_file, "r") as config_data:
    #     conf = yaml.load(config_data)
    # with open("frame_eval/newhouse_v2/doc.yml", "r") as config_data:
    #     conf.update(yaml.load(config_data))
    #     conf["explain_params"]["doc"] = conf["doc"]

    # 从配置文件读取参数
    spark_config_key = "newhouse_v2_config"
    spark_params = conf.get(spark_config_key, None)
    if spark_params is None:
        logging.error("lack {} in config file".format(spark_config_key))
        sys.exit(-1)
    # ## 补充参数
    # pt
    spark_params["sql_params"]["pt_date"] = pt_date
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_function"] = logic_func
    # 存储pt
    spark_params["save_params"]["partition_params"] = {"pt": "{}000000".format(pt_date)}

    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()


def get_img_url(frame_id):
    PREFIX = r'http://storage.lianjia.com/'
    import web_server.api_lib as api_lib
    APPKEY = 'frame_analysis'
    SECRET = 'c338b06a92d4400edcbf11c03979241a'
    FRAME_MINER_URL = r'http://i.data.api.lianjia.com/v2/meta/frame_miner'
    url = '888'
    if frame_id != '888':
        r = api_lib.request_bigdata_api(FRAME_MINER_URL,
                                        {'frame_ids': frame_id},
                                        key=APPKEY,
                                        secret=SECRET)
        if r['data']:
            url = r['data'][0]['image_url']
    if url[0:4] != 'http':
        url = PREFIX + url
    return url


def res2md_v2(result):
    """结果转存问markdonw文件"""
    SAVE_PATH = r'D:\tmp\md'
    frame_id = result[0]
    img_path = get_img_url(frame_id)

    frame_file = os.path.join(SAVE_PATH, frame_id + ".md")
    file_write_obj = open(frame_file, 'w')
    frame_label = json.loads(result[2])

    img_md = ''.join(['![avatar](', img_path, ') \n'])
    file_write_obj.writelines(img_md)

    for module, label in frame_label.items():
        if module == 'statistic' or module == 'preview':
            continue
        module_line = " ".join(['#', module.encode('utf8')])
        file_write_obj.writelines(module_line)
        file_write_obj.writelines('\n')
        for rm, docs in label.items():
            rm_line = " ".join(['##', 'room:', rm.encode('utf8'), '\n'])
            file_write_obj.writelines(rm_line)
            for idx, doc in enumerate(docs):
                dim_name = " ".join(['###', 'index:', str(idx), '\n'])
                file_write_obj.writelines(dim_name)
                for k, dim in doc.items():
                    dim_name = " ".join(['#### ', 'dim_name:', dim['dim_name'].encode('utf8'), '\n'])
                    file_write_obj.writelines(dim_name)
                    display_item = ' '.join(['-', 'display_item:', dim['display_item'].encode('utf8'), '\n'])
                    file_write_obj.writelines(display_item)
                    display_sub_item = ' '.join(
                        ['-', 'display_sub_item:', dim['display_sub_item'].encode('utf8'), '\n'])
                    file_write_obj.writelines(display_sub_item)
                    enum = ' '.join(['-', 'enum:', dim['enum'].encode('utf8'), '\n'])
                    file_write_obj.writelines(enum)
                    simple_explain = ' '.join(['-', 'simple_explain:', dim['simple_explain'].encode('utf8'), '\n'])
                    file_write_obj.writelines(simple_explain)
                    detailed_explain = ' '.join(
                        ['-', 'detailed_explain:', dim['detailed_explain'].encode('utf8'), '\n\n'])
                    file_write_obj.writelines(detailed_explain)
                    annotation = ' '.join(['-', 'annotation:', dim['annotation'].encode('utf8'), '\n\n'])
                    file_write_obj.writelines(annotation)
                    detailed_explain = ' '.join(['-', 'level:', dim['level'].encode('utf8'), '\n'])
                    file_write_obj.writelines(detailed_explain)
                    detailed_explain = ' '.join(['-', 'compare_label:', dim['compare_label'].encode('utf8'), '\n'])
                    file_write_obj.writelines(detailed_explain)
                    detailed_explain = ' '.join(['-', 'compare_desc:', dim['compare_desc'].encode('utf8'), '\n'])
                    file_write_obj.writelines(detailed_explain)
                    detailed_explain = ' '.join(['-', 'compare_lev:', dim['compare_lev'].encode('utf8'), '\n'])
                    file_write_obj.writelines(detailed_explain)
                    # detailed_explain = ' '.join(['-', 'room_type_name:', dim['room_type_name'].encode('utf8'), '\n'])
                    # file_write_obj.writelines(detailed_explain)

    file_write_obj.close()


def res2md(result):
    SAVE_PATH = r'D:\tmp\md'
    frame_id = result[0]
    img_path = get_img_url(frame_id)

    frame_file = os.path.join(SAVE_PATH, frame_id + ".md")
    file_write_obj = open(frame_file, 'w')
    frame_label = json.loads(result[2])

    img_md = ''.join(['![avatar](', img_path, ') \n'])
    file_write_obj.writelines(img_md)

    for room, label in frame_label.items():
        room_type_name = " ".join(["#", label['room_type_name'].encode('utf8')])
        file_write_obj.writelines(room_type_name)
        file_write_obj.writelines('\n')
        for doc in label['doc']:
            for dim in doc['dims']:
                dim_name = " ".join(['###', 'title:', dim['dim_name'].encode('utf8'), '\n\n'])
                file_write_obj.writelines(dim_name)
                module = ' '.join(['-', 'module:', dim['module'].encode('utf8'), '\n'])
                file_write_obj.writelines(module)
                enum = ' '.join(['-', 'enum:', dim['enum'].encode('utf8'), '\n'])
                file_write_obj.writelines(enum)
                simple_explain = ' '.join(['-', 'simple_explain:', dim['simple_explain'].encode('utf8'), '\n'])
                file_write_obj.writelines(simple_explain)
                detailed_explain = ' '.join(['-', 'detailed_explain:', dim['detailed_explain'].encode('utf8'), '\n'])
                file_write_obj.writelines(detailed_explain)
                detailed_explain = ' '.join(['-', 'level:', dim['level'].encode('utf8'), '\n'])
                file_write_obj.writelines(detailed_explain)
    file_write_obj.close()


def case_study(frame):
    """
    frame: frame id or frame json file path
    """
    frame_id, line = utils.get_frame_vector(frame, city_code=370300)
    conf = dict()
    utils.collect_conf(r"frame_eval/newhouse_v2/conf_newhouse_v2.yml", conf)
    utils.collect_conf(r"frame_eval/newhouse_v2/doc.yml", conf)

    conf["explain_params"]["doc"] = conf["doc"]

    frame, result = utils.get_whole_frame_info(
        line, conf["explain_params"], get_result, update_basic2frame)
    result.append(json.dumps(get_basic_info(BASIC_INFO, frame)))

    res2md_v2(result)
    return result


if __name__ == "__main__":
    if sys.platform not in ["win32", "darwin"]:
        main()
    else:
        # sys.argv.append("20210505")
        # sys.argv.append("frame_eval/newhouse_v2/conf_newhouse_v2.yml")
        # main()

        frame_id = 11000000807741
        # frame_id = 3320036797822647
        case_study(frame_id)
        # frame_json = r"D:\11000001232084.json"
        # case_study(frame_json)

        # import pandas as pd
        # frame_id_file = r'D:\loupanzidian.tsv'
        # df = pd.read_csv(frame_id_file, dtype='str', sep="\t", encoding='cp1252')
        # # frame_id_list = list(df['frame_id'])
        # frame_id_list = list(df['vector'])
        # for frame_id in frame_id_list:
        #     try:
        #         case_study(frame_id)
        #     except Exception as e:
        #         traceback.print_exc()
        #         print(e)
