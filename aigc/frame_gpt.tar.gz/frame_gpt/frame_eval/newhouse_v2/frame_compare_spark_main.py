# -*- coding:utf-8 -*-
import copy
import json
import yaml
import logging
import sys
import os
import pandas as pd
import numpy as np

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../"))
sys.path.insert(0, os.getcwd())

from lib import  spark_util
from lib.file_util import get_file_stream


def frame_compare_test(row, **params):
    res = [row['frame_id'], row['project_name'], row['frame_id'], 0.1]
    return res


def get_result(city, city_group, columns_names):
    _data = [[_x[_col] for _col in columns_names] for _x in city_group]
    group_df_pd = pd.DataFrame(data=_data, columns=columns_names)
    res = get_frame_project_list(group_df_pd)

    return res


def logic_func(driver, raw_df, **params):
    city_group = raw_df.rdd.groupBy(lambda row: row['city_code'])
    column_names = raw_df.schema.names
    rdd_frame_project = city_group.flatMap(lambda row: get_result(row[0], row[1], column_names))
    names = params["table_names"]
    result_df = rdd_frame_project.toDF(names)
    # df_frame_project = driver.session.createDataFrame(*names)
    # driver.rdd_2_df(df_frame_project)
    # result_df = df_frame_project.toDF(*names)
    return result_df


def main():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')

    pt_date = sys.argv[1]
    config_file = sys.argv[2]

    f = get_file_stream(config_file)
    conf = yaml.load(f)

    spark_config_key = "frame_compare"
    spark_params = conf.get(spark_config_key, None)

    spark_params["sql_params"]["pt_date"] = pt_date
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_function"] = logic_func
    # 存储pt
    spark_params["save_params"]["partition_params"] = {"pt": "{}000000".format(pt_date)}

    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()


def get_frame_project_list(city_df):
    res = []
    for idx, row in city_df.iterrows():
        frame_id = row['frame_id']
        shi, ting, wei = row['shi'], row['ting'], row['wei']
        price = row['price'] + 1 # 防止0值
        df0 = copy.deepcopy(city_df)
        df0 = df0.drop(labels=idx)
        df0 = df0[(df0['shi'] == shi) & (df0['ting'] == ting) ]
        df0 = df0[np.abs(df0['wei'] - wei) <= 1]
        delta_price = np.abs(df0['price'] - price) / price
        df0['d_price'] = delta_price
        df0 = df0[df0['d_price'] < 0.2]
        df0 = df0.sort_values('d_price', ascending=True).groupby('project_name').first().reset_index()
        for idx1, row1 in df0.iterrows():
            res.append([frame_id, row1['project_name'], row1['frame_id'], row1['d_price']])
    return res


def test():
    tsv_path = r'D:\frame_compare.tsv'
    df =  pd.read_csv(tsv_path, sep="\t")
    groups = list(df.groupby('city_code'))
    for city_code, city_df in groups:
        get_frame_project_list(city_df)
        tmp = 0


if __name__ == "__main__":
    main()
    #
    # test()