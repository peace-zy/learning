SELECT tab1.frame_id, tab1.project_name, city_code, floor_area, tab1.price
	, shi, ting, chu, wei
FROM (
	SELECT f_explain.frame_id, tab_price.project_name, city_code, floor_area, tab_price.price
		, shi, ting, chu, wei
	FROM (
		SELECT frame_id
		FROM data_mining.data_mining_frame_newhouse_v2_da
		WHERE pt = '{pt_date}000000'
			AND error = ''
	) f_explain
		JOIN (
			SELECT frame_id, frame_info.project_name, city_code, floor_area
				, avg_price * floor_area AS price, room_cnt AS shi, parlor_cnt AS ting
				, kitchen_cnt AS chu, toilet_cnt AS wei
			FROM (
				SELECT frame_id, project_name, city_code, floor_area, room_cnt
					, parlor_cnt, kitchen_cnt, toilet_cnt
				FROM rpt.rpt_nh_build_resblock_frame_info_da
				WHERE pt = '{pt_date}000000'
					AND property_type IN (107500000002, 107500000003, 107500000004)
			) frame_info
				LEFT JOIN (
					SELECT project_name, avg_price
					FROM rpt.rpt_nh_build_resblock_base_info_da
					WHERE pt = '{pt_date}000000'
				) resblock_base
				ON frame_info.project_name = resblock_base.project_name
		) tab_price
		ON f_explain.frame_id = tab_price.frame_id
    ) tab1
	INNER JOIN (
	    -- 筛选端上显示的有效户型
		SELECT t1.frame_id, t3.pid, t3.project_name, t3.resblock_name, t3.city_name
		FROM (
			SELECT frame_id
			FROM dw.dw_plat_lianjia_newhouse_frame_report_da
			WHERE pt = '{pt_date}000000'
				AND versions = '2'
				AND is_deleted = '0'
				AND is_black = '0'
		) t1
			INNER JOIN (
				SELECT frame_id, resblockdel_id
				FROM dw.dw_house_newhouse_resblockdel_frame_mapping_da
				WHERE pt = '{pt_date}000000'
					AND is_valid = '1'
					AND is_show = '1'
-- 				    AND sell_status_code = '120240002' -- 在售房源
				GROUP BY frame_id, resblockdel_id
			) t2
			ON t1.frame_id = t2.frame_id
			INNER JOIN (
				SELECT pid, project_name, resblock_name, city_name
				FROM rpt.rpt_nh_build_resblock_base_info_da
				WHERE pt = '{pt_date}000000'
					AND property_type = '107500000003'
					AND is_ke_status = '1'
					AND process_status IN ('1', '3')
				GROUP BY pid, project_name, resblock_name, city_name
			) t3
			ON t3.pid = t2.resblockdel_id
	) tab2
	ON tab1.frame_id = tab2.frame_id