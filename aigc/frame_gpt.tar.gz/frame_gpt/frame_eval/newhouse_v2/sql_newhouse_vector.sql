SELECT framex_6.frame_id AS frame_id, image_id, vector_value, city_code, standard_url
	, floor_area, framex_6.resblockdel_id AS resblockdel_id, bind_building_json, fitment_status_code, stat_function_code
	, moving_lines AS moving_lines_img, visual_areas AS visual_areas_img, face_vectors AS face_vectors_img, wd_vectors AS wd_vectors_img, movement_areas AS movement_areas_img
	, main_img, CAST(framex_6.avg_price AS STRING)
    , framex_6.room_cnt, framex_6.parlor_cnt, framex_6.toilet_cnt
FROM (
	SELECT framex_5.frame_id AS frame_id, image_id, vector_value, city_code, standard_url
		, floor_area, framex_5.resblockdel_id, bind_building_json, fitment_status_code, stat_function_code
		, tab_price.avg_price, tab_price.room_cnt, tab_price.parlor_cnt, tab_price.toilet_cnt
	FROM (
		SELECT framex_4.frame_id_4 AS frame_id, image_id, vector_value, city_code, standard_url
			, floor_area, framex_4.resblockdel_id, bind_building_json, fitment_status_code, stat_function_code
		FROM (
			SELECT framex_3.frame_id_3 AS frame_id_4, image_id, vector_value, city_code, standard_url
				, floor_area, framex_3.resblockdel_id, bind_building_json, ROW_NUMBER() OVER (PARTITION BY framex_3.frame_id_3 ORDER BY update_time DESC) AS rn, fitment_status_code
				, stat_function_code
			FROM (
				SELECT framex_2.frame_id AS frame_id_3, image_id, vector_value, city_code, standard_url
					, floor_area, resblockdel_id, bind_building_json, create_time, update_time
				FROM (
					SELECT framex_1.frame_id, image_id, vector_value, city_code, standard_url
						, floor_area, resblockdel_id
					FROM (
						SELECT DISTINCT frame_id, 'img' AS image_id, vector AS vector_value, city_code, standard_url
						FROM data_mining.data_mining_framex_vector_base_da
						WHERE pt = '{pt_date}000000'
							AND censor_level IN (0, 2)
							AND is_valid = 1
							AND original_from = 2
--                             AND frame_id in (11000016657824, 1120046003072550, 11000016657815)
					) framex_1
						LEFT JOIN (
							SELECT frame_id, floor_area, resblockdel_id
							FROM dw.dw_house_newhouse_resblockdel_frame_mapping_da
							WHERE pt = '{pt_date}000000'
								AND is_valid = 1
						) resblock
						ON resblock.frame_id = framex_1.frame_id
				) framex_2
					LEFT JOIN (
						SELECT frame_id, bind_building_json, create_time, update_time
						FROM dw.dw_house_newhouse_resblockdel_frame_ext_da
						WHERE pt = '{pt_date}000000'
					) dw_house_newhouse_resblockdel_frame_ext_da
					ON dw_house_newhouse_resblockdel_frame_ext_da.frame_id = framex_2.frame_id
			) framex_3
				LEFT JOIN (
					SELECT resblockdel_id, fitment_status_code, stat_function_code
					FROM dw.dw_hdel_newhouse_resblockdel_da
					WHERE pt = '{pt_date}000000'
				) dw_hdel_newhouse_resblockdel_da
				ON dw_hdel_newhouse_resblockdel_da.resblockdel_id = framex_3.resblockdel_id
		) framex_4
		WHERE framex_4.rn = 1
	) framex_5
		LEFT JOIN (
			SELECT frame_id, frame_info.project_name, resblock_base.avg_price
			     , frame_info.room_cnt, frame_info.parlor_cnt, frame_info.toilet_cnt
			FROM (
				SELECT frame_id, project_name, room_cnt, parlor_cnt, toilet_cnt
				FROM rpt.rpt_nh_build_resblock_frame_info_da
				WHERE pt = '{pt_date}000000'
			) frame_info
				LEFT JOIN (
					SELECT project_name, avg_price
					FROM rpt.rpt_nh_build_resblock_base_info_da
					WHERE pt = '{pt_date}000000'
				) resblock_base
				ON frame_info.project_name = resblock_base.project_name
		) tab_price
		ON framex_5.frame_id = tab_price.frame_id
) framex_6
	JOIN (
		SELECT frame_id, moving_lines, visual_areas, face_vectors, wd_vectors
			, movement_areas, main_img
		FROM ods.ods_frame_miner_frame_eval_img_inf_da
		WHERE pt = '{pt_date}000000'
	) img
	ON framex_6.frame_id = img.frame_id