# coding=utf-8
import logging
import yaml
import os
import pkg_resources
from operator import itemgetter
import collections
import numpy as np

from lib import comm_lib
import lib.eval_main as eval_main
import lib.eval_general as eval_general
import lib.eval_single as eval_single
import lib.eval_global as eval_global
from lib import code_enum as ce
import frame_score.frame_score as frame_score
from lib.eval_main import dinning_kitchen_distance, get_toilet_parlour_dis
from frame_remould.geometry.polygon import Polygon

FACE_MAP = {
    "north": u"北",
    "north-east": u"东北",
    "north-west": u"西北",
    "east": u"东",
    "south": u"南",
    "south-east": u"东南",
    "south-west": u"西南",
    "west": u"西",
    "": u"",
}


def newhouse_feature_collect(base_func):
    """
    收集新房相关特征
    """

    def item_func(frame, *args, **kwargs):
        logging.debug("newhouse_feature_collect")

        if frame.state != ce.State.valid and frame.state != ce.State.liner_error:
            return base_func(frame, *args, **kwargs)
        # 动线出错要特殊处理
        if frame.state == ce.State.liner_error:
            frame.explain_message.pop('explain_real_liner')
        # 一期解读的打分信息
        scores = get_score_result(frame)
        newhouse_addition = {
            "scores": scores,
        }
        # frame的附加信息
        frame.explain_message["newhouse_addition"] = newhouse_addition
        # 构建每个功能区（包括整屋）的特征
        frame.explain_message['newhouse_dict'] = {}

        initial_every_room_features(frame)
        get_whole_house_features(frame)

    return item_func


def get_dining_features(area_id, frame, plan_idx):
    pass


def get_parlour_features(area_id, frame, plan_idx):
    """
    得到客厅特征
    :param area_id: 功能区id
    :param frame:
    :param plan_idx: 第几层
    :return:
    """
    frame_label = frame.explain_message[ce.EXPLAIN_FRAME]
    with_dining = True if (frame_label & ce.FramePLabel.with_dining_room) else False

    plan_vector = frame.vector[frame.plan_key][plan_idx]
    points_dict, line_items_dict, lines_dict, areas_dict = itemgetter(*ce.DICTS)(plan_vector)
    _, area_points, room_type_id, detail_type, area_size = itemgetter(*ce.IPTTS)(areas_dict[area_id])
    living_area = 0
    for living in frame.house.res_dict['livingroom']:
        contours = living['space_analysis']['contours']
        poly = Polygon(*[p for p in contours])
        living_area = poly.area
    max_rec_ratio = np.fabs(living_area) * 1. / area_size

    message = frame.explain_message
    explain_parlour = message.get(ce.EXPLAIN_PARLOUR, {})
    with_balcony = explain_parlour.get(area_id, {}).get(ce.WITH_BALCONY, False)
    parlour_dict = {
        "with_dining": with_dining,
        "max_rec_ratio": max_rec_ratio,
        "with_balcony": with_balcony,
    }
    return parlour_dict


def get_parlour_toilet_features(area_id, frame, plan_idx):
    toilet_dict = get_toilet_features(area_id, frame, plan_idx)
    return toilet_dict


def get_main_toilet_features(area_id, frame, plan_idx):
    toilet_dict = get_toilet_features(area_id, frame, plan_idx)
    return toilet_dict


def get_toilet_features(area_id, frame, plan_idx):
    """卫生间特征"""
    message = frame.explain_message
    explain_toilet = message.get(ce.EXPLAIN_TOILET, {})
    room_name, room_label, face_entrance_dis, face_kitchen_dis, face_room_dis = explain_toilet.get(
        area_id, ["", 0])
    if face_entrance_dis == float('inf'):
        face_entrance_dis = 999999.
    else:
        face_entrance_dis = face_entrance_dis / 1000

    if face_kitchen_dis == float('inf'):
        face_kitchen_dis = 999999.
    else:
        face_kitchen_dis = face_kitchen_dis

    if face_room_dis == float('inf'):
        face_room_dis = 999999.
    else:
        face_room_dis = face_room_dis
    parlour_dis = get_toilet_parlour_dis(frame, plan_idx, area_id)
    # 更新窗户数量
    win_cnt = update_toilet_win_cnt(frame, plan_idx, area_id)
    toilet_dict = {
        "face_entrance_dis": face_entrance_dis,
        "face_kitchen_dis": face_kitchen_dis,
        "parlour_dis": parlour_dis,
        "face_room_dis": face_room_dis,
        "win_cnt": win_cnt,
    }
    return toilet_dict


def update_toilet_win_cnt(frame, plan_idx, area_id):
    """更新卫生间窗户数量，如果相通的淋浴房等有窗，算明卫"""
    win_cnt_0 = frame.house.get_window_cnt(area_id)
    connected_id = frame.house.get_connect_areas4area_id(area_id)
    for cid in connected_id:
        room_type = frame.house.get_room_type(cid)
        if room_type != ce.AreaType.toilet.value:
            continue
        win_cnt = frame.house.get_window_cnt(cid)
        win_cnt_0 = max(win_cnt_0, win_cnt)
    return win_cnt_0


def get_kitchen_features(area_id, frame, plan_idx):
    """厨房特征"""
    message = frame.explain_message
    explain_kitchen = message.get(ce.EXPLAIN_KITCHEN, {})
    # with_entrance = explain_kitchen.get(area_id, {}).get(ce.WITH_ENTRANCE, None)
    kitchen_entrance_dis = explain_kitchen.get(area_id, {}).get(ce.WITH_ENTRANCE, float("inf"))
    if kitchen_entrance_dis == float('inf'):
        kitchen_entrance_dis = 999999.
    else:
        kitchen_entrance_dis /= 1000

    plan_vector = frame.vector[frame.plan_key][plan_idx]
    dinning_kitchen_dis = dinning_kitchen_distance(plan_vector, explain_kitchen)
    if dinning_kitchen_dis is None:
        dinning_kitchen_dis = 999999.
    else:
        dinning_kitchen_dis /= 1000.

    points_dict, line_items_dict, lines_dict, areas_dict = itemgetter(*ce.DICTS)(plan_vector)
    _, area_points, room_type, detail_type, area_size = itemgetter(*ce.IPTTS)(areas_dict[area_id])
    open_kitchen = True if detail_type == ce.OPEN_KITCHEN_TYPE else False

    kitchen_dict = {
        "kitchen_entrance_dis": kitchen_entrance_dis,
        "dinning_kitchen_dis": dinning_kitchen_dis,
        "open_kitchen": open_kitchen,
    }
    return kitchen_dict


def get_main_room_features(area_id, frame):
    room_dict = get_room_features(area_id, frame)
    main_room_dict = room_dict
    return main_room_dict


def get_room_features(area_id, frame):
    """卧室特有特征"""

    explain_room = frame.explain_message.get(ce.EXPLAIN_ROOM, {})
    room_name, room_label, face_entrance_dis, face_toilet_dis = explain_room.get(
        area_id, ["", 0, float("inf"), float("inf")])

    with_balcony = True if (room_label & ce.RoomLabel.with_balcony) else False
    with_toilet = True if (room_label & ce.RoomLabel.with_toilet) else False
    with_cloakroom = True if (room_label & ce.RoomLabel.with_cloakroom) else False
    face_room = True if (room_label & ce.RoomLabel.face_others) else False
    neighbor_kitchen = True if (room_label & ce.RoomLabel.neighbor_kitchen) else False
    if face_entrance_dis == float("inf"):
        face_entrance_dis = 999999.
    else:
        face_entrance_dis /= 1000.
    if face_toilet_dis == float("inf"):
        face_toilet_dis = 999999.
    else:
        # face_toilet_dis /= 1000.
        face_toilet_dis = face_toilet_dis
    room_dict = {
        "face_entrance_dis": face_entrance_dis,
        "face_toilet_dis": face_toilet_dis,
        "neighbor_kitchen": neighbor_kitchen,
        "with_toilet": with_toilet,
        "with_balcony": with_balcony,
        "with_cloakroom": with_cloakroom,
        "face_room": face_room,
    }
    return room_dict


def get_whole_house_features(frame):
    """得到新房整屋特征"""
    score_list = frame.explain_message['newhouse_addition']['scores']
    # total_score = str(round(float(score_list[11]), 1))  # 总得分
    space_score = str(round(float(score_list[10]), 1))  # 空间布局得分
    trans_score = str(round(float(score_list[9]), 1))  # 采光同构得分
    usage_score = str(round(float(score_list[8]), 1))  # 房屋功能得分
    total_score = 0.3 * float(space_score) + 0.5 * float(trans_score) + 0.2 * float(usage_score)
    total_score = str(round(total_score, 1))

    frame_label = frame.frame_label
    # moving_line_len_dict = get_moving_line_length(frame)
    if frame.explain_message.get('explain_real_liner') is None:
        living_len = 0
        work_len = 0
        guest_len = 0
    else:
        living_len = frame.explain_message['explain_real_liner']['living_len'] / 1000
        work_len = frame.explain_message['explain_real_liner']['work_len'] / 1000
        guest_len = frame.explain_message['explain_real_liner']['guest_len'] / 1000

    # 可视域比例
    if frame.explain_message.get('explain_real_visual') is None:
        visual_ratio = 0
    else:
        visual_ratio = frame.explain_message['explain_real_visual']['area_ratio_o']

    # 整屋朝向
    total_face = None
    face_label = frame.explain_message[ce.EXPLAIN_WHOLE_FRAME][8]
    for label, ft in zip([1, 2, 4, 8, 16], [u"南北", u"南", u"东", u"西", u"北"]):
        if label & face_label:
            total_face = ft
            break
    # 通透性
    trance_type = None
    trans_label = frame.explain_message[ce.EXPLAIN_WHOLE_FRAME][3]
    for label, tt in zip([1, 2, 4], [u"对侧", u"邻侧", u"单侧"]):
        if label & trans_label:
            trance_type = tt
            break
    # 厨卫对门距离
    parlour_toi_list = frame.explain_message["newhouse_dict"].get('parlour_toilet')
    if parlour_toi_list is not None and len(parlour_toi_list) > 0:
        toilet_face_kitchen_dis = parlour_toi_list[0]['face_kitchen_dis']
    else:
        toilet_face_kitchen_dis = 999999.
    # 卧室最小窗落比
    newhouse_message = frame.explain_message["newhouse_dict"]
    room_list = []
    if newhouse_message.get('main_room') is not None:
        room_list.extend(newhouse_message.get('main_room'))
    if newhouse_message.get('sub_room') is not None:
        room_list.extend(newhouse_message.get('sub_room'))
    wdfs = [rm['wdf'] for rm in room_list]
    room_min_wdf = 0
    if len(wdfs) != 0:
        room_min_wdf = min(wdfs)
    # 卧室是否对视
    face_rooms = False
    for r in room_list:
        if r['face_room'] is True:
            face_rooms = True
            break
    # 朝南房间数量
    south_bedrooms = 0
    south_rooms = 0
    for k, v in newhouse_message.items():
        for room in v:
            face = room['face'].encode('utf8')
            if 'south' not in face:
                continue
            south_rooms += 1
            if k == ce.NewhouseAreaType.main_room.value:
                south_bedrooms += 1
            if k == ce.NewhouseAreaType.sub_room.value:
                south_bedrooms += 1
    # 面宽进深
    width_depth_dict = get_with_depth_dict(frame)
    # 面积
    area_size_dict = get_room_area_size_dict(frame)
    # 带保姆间
    with_babysitter = if_contain_area_type(frame, ce.AreaType.babysitter.value)
    # 储物间
    with_storage = if_contain_area_type(frame, ce.AreaType.storage.value)
    with_cloakroom = if_contain_area_type(frame, ce.AreaType.cloakroom.value)
    with_storage_cloakroom = with_storage or with_cloakroom

    whole_dict = {
        "label": frame_label,
        "area_size": frame.frame_size,
        "total_score": total_score,
        "space_score": space_score,
        "trans_score": trans_score,
        "usage_score": usage_score,
        "shi": frame.room_cnt[0],
        "ting": frame.room_cnt[1],
        "chu": frame.room_cnt[2],
        "wei": frame.room_cnt[3],
        "movement_clear": is_label_hit(frame_label, "movement_clear"),  # 是否动静分明
        "moving_line_cross_cnt": get_moving_line_cross_cnt(frame),  # 动线交叉数量
        "living_len": living_len,
        "work_len": work_len,
        "guest_len": guest_len,
        "good_active_line": is_label_hit(frame_label, "good_active_line"),  # 是否动线合理
        "visual_ratio": visual_ratio, # 可视域比例
        "is_square": is_label_hit(frame_label, "square"),  # 是否方正
        "total_face_str": total_face,  # 总体朝向
        "face_label": face_label,  # 总体朝向编码
        "trance_type_str": trance_type,  # 通透性
        "trans_label": trans_label,  # 通透性编码
        "all_window": is_label_hit(frame_label, "all_window"),  # 全明格局
        "kitchen_window": is_label_hit(frame_label, "kitchen_window"),  # 明厨
        "toilet_window": is_label_hit(frame_label, "toilet_window"),  # 明卫
        "all_south": is_label_hit(frame_label, "all_south"),  # 全南
        "south_bedroom": is_label_hit(frame_label, "south_bedroom"),  # 卧室朝南
        "south_parlour": is_label_hit(frame_label, "south_parlour"),  # 客厅朝南
        "bay_window": is_label_hit(label, "bay_window"),  # 观景飘窗
        "french_window": is_label_hit(frame_label, "french_window"),  # 观景落地飘窗
        "kitchen_face_toilet": is_label_hit(frame_label, "kitchen_face_toilet"),  # 厨卫对门
        "open_kitchen": is_label_hit(frame_label, "open_kitchen"),  # 开放厨房
        "area_logical": is_label_hit(frame_label, "area_logical"),  # 分间面积合理
        "north_south_trans": is_label_hit(frame_label, "north_south_trans"),
        "bedroom_toilet": is_label_hit(frame_label, "bedroom_toilet"),  # 卧室带卫
        "bedroom_balcony": is_label_hit(frame_label, "bedroom_balcony"),  # 卧室带阳台
        "bedroom_cloakroom": is_label_hit(frame_label, "bedroom_cloakroom"),  # 卧室带衣帽间
        "terrace": is_label_hit(frame_label, "terrace"),  # 露台
        "garden": is_label_hit(frame_label, "garden"),  # 带花园
        "loft": is_label_hit(frame_label, "loft"),  # 带阁楼
        "toilet_face_kitchen_dis": toilet_face_kitchen_dis,
        "room_min_wdf": room_min_wdf,  # 卧室最小窗地比
        # "south_room_cnt": south_bedrooms,  # 朝南卧室数量
        # "south_all_room_cnt": south_rooms,  # 朝南房间数量
        "face_rooms": face_rooms,  # 卧室对视
        "with_storage_cloakroom": with_storage_cloakroom,  # 带衣帽间储物间
        "with_babysitter": with_babysitter,  # 带保姆间
    }
    if south_bedrooms > 0:
        whole_dict.update({"south_room_cnt": south_bedrooms})
    whole_dict.update(width_depth_dict)
    whole_dict.update(area_size_dict)
    # whole_dict.update(moving_line_len_dict)

    frame.explain_message["newhouse_dict"].update({
        "whole": [whole_dict]
    })
    return None


def is_label_hit(label, key):
    """判断某一标签是否命中"""
    if ce.LABEL_DICT.get(key) is None:
        raise ValueError("no this tag")
    if label & ce.LABEL_DICT[key][0] == 0:
        return False
    else:
        return True


def if_contain_area_type(frame, area_type):
    """判断户型是否存在指定房间类别"""
    frame_vector = frame.vector

    for plan_idx, plan_vector in enumerate(frame_vector[frame.plan_key]):
        points_dict, line_items_dict, lines_dict, areas_dict = itemgetter(*ce.DICTS)(plan_vector)
        for area_id in areas_dict:
            _, area_points, room_type_id, detail_type, area_size = itemgetter(*ce.IPTTS)(areas_dict[area_id])
            if room_type_id == area_type:
                return True
    return False



def get_moving_line_cross_cnt(frame):
    """动线交叉点数"""
    if frame.explain_message.get('explain_real_liner') is None:
        return None
    return frame.explain_message['explain_real_liner']['cross_cnt']


# def get_moving_line_length(frame):
#     """动线长度, 三种"""
#     return {
#         "living_len": frame.explain_message['explain_real_liner']['living_len'] / 1000,
#         "work_len": frame.explain_message['explain_real_liner']['work_len'] / 1000,
#         "guest_len": frame.explain_message['explain_real_liner']['guest_len'] / 1000,
#     }


def get_with_depth_dict(frame):
    """得到面宽进深"""
    newhouse_message = frame.explain_message["newhouse_dict"]
    width_depth_dict = dict()
    if newhouse_message.get('main_room') is not None:
        main_room_width = newhouse_message['main_room'][0]["width"]
        main_room_depth = newhouse_message['main_room'][0]["depth"]
        width_depth_dict["main_room_width"] = main_room_width
        width_depth_dict["main_room_depth"] = main_room_depth
    if newhouse_message.get('parlour') is not None:
        parlour_width = newhouse_message['parlour'][0]["width"]
        parlour_depth = newhouse_message['parlour'][0]["depth"]
        width_depth_dict["parlour_width"] = parlour_width
        width_depth_dict["parlour_depth"] = parlour_depth
    if newhouse_message.get('kitchen') is not None:
        kitchen_width = newhouse_message['kitchen'][0]["width"]
        kitchen_depth = newhouse_message['kitchen'][0]["depth"]
        width_depth_dict["kitchen_width"] = kitchen_width
        width_depth_dict["kitchen_depth"] = kitchen_depth
    if newhouse_message.get('main_toilet') is not None:
        main_toilet_width = newhouse_message['main_toilet'][0]["width"]
        main_toilet_depth = newhouse_message['main_toilet'][0]["depth"]
        width_depth_dict["main_toilet_width"] = main_toilet_width
        width_depth_dict["main_toilet_depth"] = main_toilet_depth
    if newhouse_message.get('parlour_toilet') is not None:
        parlour_toilet_width = newhouse_message['parlour_toilet'][0]["width"]
        parlour_toilet_depth = newhouse_message['parlour_toilet'][0]["depth"]
        width_depth_dict["parlour_toilet_width"] = parlour_toilet_width
        width_depth_dict["parlour_toilet_depth"] = parlour_toilet_depth
    return width_depth_dict

def get_room_area_size_dict(frame):
    newhouse_message = frame.explain_message["newhouse_dict"]
    area_size_dict = dict()
    if newhouse_message.get('main_room') is not None:
        main_room_area_size = newhouse_message['main_room'][0]["area_size"]
        area_size_dict["main_room_area_size"] = main_room_area_size
    if newhouse_message.get('parlour') is not None:
        parlour_area_size = newhouse_message['parlour'][0]["area_size"]
        area_size_dict["parlour_area_size"] = parlour_area_size
    # if newhouse_message.get('kitchen') is not None:
    #     kitchen_width = newhouse_message['kitchen'][0]["width"]
    #     kitchen_depth = newhouse_message['kitchen'][0]["depth"]
    #     width_depth_dict["kitchen_width"] = kitchen_width
    #     width_depth_dict["kitchen_depth"] = kitchen_depth
    # if newhouse_message.get('main_toilet') is not None:
    #     main_toilet_width = newhouse_message['main_toilet'][0]["width"]
    #     main_toilet_depth = newhouse_message['main_toilet'][0]["depth"]
    #     width_depth_dict["main_toilet_width"] = main_toilet_width
    #     width_depth_dict["main_toilet_depth"] = main_toilet_depth
    # if newhouse_message.get('parlour_toilet') is not None:
    #     parlour_toilet_width = newhouse_message['parlour_toilet'][0]["width"]
    #     parlour_toilet_depth = newhouse_message['parlour_toilet'][0]["depth"]
    #     width_depth_dict["parlour_toilet_width"] = parlour_toilet_width
    #     width_depth_dict["parlour_toilet_depth"] = parlour_toilet_depth
    return area_size_dict


def get_score_result(frame):
    """得到一期打分"""
    get_module_res = lambda *res: pkg_resources.resource_stream(__name__, os.path.join(*res))
    f = get_module_res('config/frame_score_conf.yml')
    conf = yaml.load(f)
    f = get_module_res('config/frame_label_conf.yml')
    conf["label_params"] = yaml.load(f)["label_params"]
    # with open("config/frame_score_conf.yml", "r") as config_data:
    #         conf = yaml.load(config_data)
    # with open("config/frame_label_conf.yml", "r") as config_data:
    #     conf["label_params"] = yaml.load(config_data)["label_params"]
    spark_config_key = "frame_score_config"
    spark_params = conf.get(spark_config_key, None)
    use_params = comm_lib.format_frame_score_params()
    use_params["score_weight"] = spark_params["logic_params"]["logic_function_params"]["score_weight"]
    use_params["score_add"] = spark_params["logic_params"]["logic_function_params"]["score_add"]
    use_params["max_score"] = spark_params["logic_params"]["logic_function_params"]["max_score"]
    use_params["min_score"] = spark_params["logic_params"]["logic_function_params"]["min_score"]
    data_dict = frame.report_dict()
    row = {
        "frame_id": "",
        "label_value": data_dict["label_value"],
        "city_code": "",
        "shi": frame.room_cnt[0],
        "ting": frame.room_cnt[1],
        "chu": frame.room_cnt[2],
        "wei": frame.room_cnt[3]
    }
    scores = frame_score.score_func(row, **use_params)
    return scores


@eval_main.frame_prepare
@eval_general.area_wall
@eval_general.width_depth_face
@eval_general.area_size
@eval_general.window_door
@eval_single.single_general
@eval_global.v1
@eval_main.liner_worker
@newhouse_feature_collect
def newhouse_explain(frame, *args, **kwargs):
    logging.debug("newhouse_explain")


def initial_every_room_features(frame):
    """
    初始化每个房间的公共特征
    """
    fea_dict0 = {
        "shi": frame.room_cnt[0],
        "ting": frame.room_cnt[1],
        "chu": frame.room_cnt[2],
        "wei": frame.room_cnt[3],
        "total_area_size": frame.frame_size,
    }
    message = frame.explain_message
    frame_vector = frame.vector

    newhouse_dict = collections.defaultdict(list)
    for plan_idx, plan_vector in enumerate(frame_vector[frame.plan_key]):
        points_dict, line_items_dict, lines_dict, areas_dict = itemgetter(*ce.DICTS)(plan_vector)
        area_inf_dict, main_room_id, sub_rooms, _, _, _, _, _, _ = message[ce.EXPLAIN_WHOLE_FRAME]
        main_room_connected_id = frame.house.get_connect_areas4area_id(main_room_id)
        room_type_kwargs = {
            "area_dict": areas_dict,
            "main_room": main_room_id,
            "main_room_connected_id": main_room_connected_id,
        }
        for area_id in areas_dict:
            _, area_points, room_type_id, detail_type, area_size = itemgetter(*ce.IPTTS)(areas_dict[area_id])

            # 功能区面积
            size_without_line = areas_dict[area_id].get("sizeWithoutLine", None)
            norm_area_size = area_size if size_without_line is None else size_without_line
            norm_area_size = None if norm_area_size is None else norm_area_size / 1000000.

            # 面宽进深
            wd_info = message.get(ce.EXPLAIN_WIDTH_DEPTH, {}).get(area_id, None)
            if wd_info is None or wd_info[1] is None or wd_info[2] is None:
                width = None
                depth = None
            else:
                width = wd_info[1] / 1000.
                depth = wd_info[2] / 1000.
            # 朝向
            face = message.get(ce.EXPLAIN_FACE, {}).get(area_id, [None])[0]
            face_south = False
            if face is None:
                face = ''
            if 'south' in face:
                face_south = True
            # 窗地比
            window_door = message.get(ce.EXPLAIN_WINDOW_DOOR, {}).get(area_id, None)
            if window_door is None:
                wdf = None
                convex = None
            else:
                wdf = window_door[1]
                convex = window_door[4]

            win_cnt = frame.house.get_window_cnt(area_id)

            basic_fea = {
                "area_id": area_id,
                "area_size": norm_area_size,
                "width": width,
                "depth": depth,
                "face": face,
                "face_text": FACE_MAP[face],
                "face_south": face_south,
                "wdf": wdf,
                "convex": convex,
                "win_cnt": win_cnt,
            }
            basic_fea.update(fea_dict0)

            room_type_kwargs["area_id"] = area_id
            room_key = get_newhouse_room_type(room_type_id, frame, **room_type_kwargs)
            feas = get_room_type_specific_features(room_key, area_id, frame, plan_idx)
            basic_fea.update(feas)
            newhouse_dict[room_key].append(basic_fea)

    update_main_toilet2main_room(newhouse_dict)
    frame.explain_message['newhouse_dict'].update(newhouse_dict)


def update_main_toilet2main_room(newhouse_dict):
    """增加主卧中主卫面积字段"""
    if newhouse_dict.get(ce.NewhouseAreaType.main_toilet.value) is None:
        return None
    area = newhouse_dict.get(ce.NewhouseAreaType.main_toilet.value)[0]['area_size']
    newhouse_dict.get(ce.NewhouseAreaType.main_room.value)[0]['toilet_size'] = area


def get_newhouse_room_type(room_type_id, frame, **kwargs):
    """
    room_type: 户型编辑器中的room_type编号，
    """
    area_id = kwargs["area_id"]
    areas_dict = kwargs["area_dict"]
    main_room_connected_id = kwargs["main_room_connected_id"]
    # 主卧和次卧
    if room_type_id == ce.AreaType.room.value:
        main_room_id = kwargs.get("main_room")
        if area_id == main_room_id:
            return ce.NewhouseAreaType.main_room.value
        else:
            return ce.NewhouseAreaType.sub_room.value
    # 客厅, 餐厅
    if room_type_id == ce.AreaType.parlour.value:
        if areas_dict[area_id].get('type', None) == 2:
            return ce.NewhouseAreaType.dinning_room.value
        else:
            return ce.NewhouseAreaType.parlour.value
    # 厨房
    if room_type_id == ce.AreaType.kitchen.value:
        return ce.NewhouseAreaType.kitchen.value
    # 主卫和客卫，其它卫生间
    if room_type_id == ce.AreaType.toilet.value:
        if area_id in main_room_connected_id:
            return ce.NewhouseAreaType.main_toilet.value
        elif is_parlour_toilet(area_id, frame):
            return ce.NewhouseAreaType.parlour_toilet.value
        else:
            return ce.NewhouseAreaType.other_toilet.value
    return ce.NewhouseAreaType.other.value


def is_parlour_toilet(area_id, frame):
    """判断是否是客卫"""
    connected_id = frame.house.get_connect_areas4area_id(area_id)
    for conn in connected_id:
        for fp in frame.house.floorplans:
            if conn not in fp.id_regions:
                continue
            roomType = fp.id_regions[conn]._roomType
            if roomType == ce.AreaType.other.value or roomType == ce.AreaType.parlour.value:
                return True
    return False


def get_room_type_specific_features(room_key, area_id, frame, plan_idx):
    """分流不同功能区特征"""
    if room_key == ce.NewhouseAreaType.main_room.value:
        return get_main_room_features(area_id, frame)
    if room_key == ce.NewhouseAreaType.sub_room.value:
        return get_room_features(area_id, frame)
    if room_key == ce.NewhouseAreaType.kitchen.value:
        return get_kitchen_features(area_id, frame, plan_idx)
    if room_key == ce.NewhouseAreaType.parlour_toilet.value:
        return get_parlour_toilet_features(area_id, frame, plan_idx)
    if room_key == ce.NewhouseAreaType.main_toilet.value:
        return get_main_toilet_features(area_id, frame, plan_idx)
    if room_key == ce.NewhouseAreaType.other_toilet.value:
        return get_toilet_features(area_id, frame, plan_idx)
    if room_key == ce.NewhouseAreaType.parlour.value:
        return get_parlour_features(area_id, frame, plan_idx)
    return {}
