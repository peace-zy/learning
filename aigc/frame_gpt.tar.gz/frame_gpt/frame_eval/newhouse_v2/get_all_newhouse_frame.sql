set hive.cli.print.header=true;
SELECT frame_id, get_json_object(basic_info, '$.city_code') AS city_code
, get_json_object(doc, '$.lighting.whole[0].lighting_face.enum') AS whole_face
, get_json_object(doc, '$.lighting.whole[0].lighting_transparent.enum') AS whole_trans
, get_json_object(doc, '$.lighting.whole[0].lighting_all_window.enum') AS whole_all_win
, get_json_object(doc, '$.lighting.main_room[0].lighting_light.enum') AS main_room_light
, get_json_object(doc, '$.lighting.parlour[0].lighting_light.enum') AS parlour_light
, get_json_object(doc, '$.lighting.kitchen[0].lighting_light.enum') AS kitchen_light
, get_json_object(doc, '$.lighting.main_toilet[0].lighting_light.enum') AS main_toilet_light
, get_json_object(doc, '$.lighting.parlour_toilet[0].lighting_light.enum') AS parlour_toilet_light
, get_json_object(feature, '$.main_room[0].area_size') AS main_room_area_size
, get_json_object(feature, '$.sub_room[0].area_size') AS subroom_area_size
, get_json_object(feature, '$.parlour[0].area_size') AS parlour_area_size
, get_json_object(feature, '$.kitchen[0].area_size') AS kitchen_area_size
, get_json_object(feature, '$.main_toilet[0].area_size') AS main_toilet_area_size
, get_json_object(feature, '$.parlour_toilet[0].area_size') AS parlour_toilet_area_size
, get_json_object(feature, '$.whole[0].total_score') AS total_score
FROM data_mining.data_mining_frame_newhouse_v2_da
WHERE pt = '{pt_data}000000'
