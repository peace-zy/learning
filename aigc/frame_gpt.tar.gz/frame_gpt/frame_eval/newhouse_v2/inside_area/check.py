# -*- coding:utf-8 -*-
# 生成使用面积检查图片
import json
import os
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

JSON_DIR = r'D:\tmp\inside_area\20210101-20210724_city_3city_res'
IMG_DIR = r'D:\tmp\inside_area\20210101-20210724_city_3city'
SAVE_DIR = r'D:\tmp\inside_area\20210101-20210724_city_3city_check'

def test(json_path):
    with open(json_path) as f:
        vector = json.load(f)

    frame_id = os.path.split(json_path)[-1][0:-5]

    for post in ['.jpg', '.png', '.jpeg']:
        img_path = os.path.join(os.path.dirname(json_path), frame_id + post)
        if os.path.exists(img_path):
            break
    # img = Image.open(img_path).convert('L')
    img = Image.open(img_path).convert('RGB')
    img = np.array(img)

    # plt.imshow(img)
    # plt.show()

    scale = vector['property']['scale']
    scale_coord = get_scale2img_coord(scale)
    fp = vector['floorplans'][0]
    outer_wall_coord = get_outerwall2img_coord(scale, fp)
    draw_img(img, scale_coord, scale['value'], outer_wall_coord, save_path=r'D:\a.png', show=False)


def draw_img(img, scale_coord, scale_value, outer_wall_coord, save_path=None, show=True):
    plt.imshow(img)
    ax = plt.gca()
    # 绘制标尺
    scale_x = [scale_coord[0], scale_coord[2]]
    scale_y = [scale_coord[1], scale_coord[3]]
    ax.add_line(Line2D(scale_x, scale_y, color='#D200D2', alpha=0.4))
    text_x = (scale_x[0] + scale_x[1]) / 2
    text_y = (scale_y[0] + scale_y[1]) / 2
    ax.text(text_x, text_y, scale_value, color='#D200D2')
    # 绘制外墙
    for line in outer_wall_coord:
        wall_x = [line[0][0], line[1][0]]
        wall_y = [line[0][1], line[1][1]]
        ax.add_line(Line2D(wall_x, wall_y, color='#FF0000'))

    if save_path is not None:
        plt.savefig(save_path, dpi=1000, bbox_inches='tight')
        plt.close()
    if show:
        plt.show()


def get_scale2img_coord(scale):
    default_mm_per_px = 25
    o_xy = (0, 75000) # 图像左上角坐标
    dx1 = (scale['p1']['x'] - o_xy[0]) / default_mm_per_px
    dx2 = (scale['p2']['x'] - o_xy[0]) / default_mm_per_px
    dy1 = (-scale['p1']['y'] + o_xy[1]) / default_mm_per_px
    dy2 = (-scale['p2']['y'] + o_xy[1]) / default_mm_per_px

    return [dx1, dy1, dx2, dy2]


def get_outerwall2img_coord(scale, fp):
    mm_per_px = scale['mmPerPx']
    lines = []
    def get_point(pid, points, mm_per_px):
        o_xy = (0, 3000)  # 图像左上角坐标
        for p in points:
            if p['id'] != pid:
                continue
            xx = (p['x'] - o_xy[0]) / mm_per_px
            yy = (-p['y'] + o_xy[1] * mm_per_px) / mm_per_px
            return  xx, yy

    for l in fp['lines']:
        thickness = l['thicknessComputed']
        if thickness != 240:
            continue
        line = []
        for pid in l['points']:
            x, y = get_point(pid, fp['points'], mm_per_px)
            line.append((x, y))
        lines.append(line)

    return lines


def main():
    json_files = os.listdir(JSON_DIR)
    for idx, json_path in enumerate(json_files):
        print(idx)
        try:
            json_path = os.path.join(JSON_DIR, json_path)
            with open(json_path) as f:
                vector = json.load(f)

            frame_id = os.path.split(json_path)[-1][0:-5]

            for post in ['.jpg', '.png', '.jpeg']:
                img_path = os.path.join(IMG_DIR, frame_id + post)
                if os.path.exists(img_path):
                    break
            img = Image.open(img_path).convert('RGB')
            img = np.array(img)

            scale = vector['property']['scale']
            scale_coord = get_scale2img_coord(scale)
            fp = vector['floorplans'][0]
            outer_wall_coord = get_outerwall2img_coord(scale, fp)

            save_path = os.path.join(SAVE_DIR, frame_id + '.png')
            draw_img(img, scale_coord, scale['value'], outer_wall_coord,
                     save_path=save_path, show=False)
        except Exception as e:
            print(json_path, "   :   ", e)


if __name__ == '__main__':
    # test(r'D:\1220030707308956.json')
    main()
