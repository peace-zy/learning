# -*- coding:utf-8 -*-

import base64
import requests

if __name__ == '__main__':
    _request_id = 't'
    with open(r'D:\3620055159660504.jpg', 'rb') as f:
        _image_bytes = f.read()

    img_base64 = base64.b64encode(_image_bytes)
    data = {'imgBase64': img_base64}
    api_url = 'http://i.ocr.jiaoyi.ke.com/api/ocr/natural?appkey=SHUJUZHINENG-WYS9U'
    r = requests.post(api_url, data=data, timeout=3).json()

    tmp = 0