# -*- coding:utf-8 -*-
# 合并离线户型矢量json和建筑面积的表格
"""
下载建筑面积的sql
SELECT frame_id, get_json_object(basic_info, '$.floor_area') AS floor_area
FROM data_mining.data_mining_frame_newhouse_v2_da
WHERE pt = '20210815000000'
AND get_json_object(basic_info, '$.city_code') = 120000
"""
import json
import pandas as pd
import os

import web_server.api_lib as api_lib


FLOOR_ARE_TSV = r'D:\ke\personal_work_log\usage_area\floor_area\20210101-20210724_city_120000.tsv'

JSON_PATH = r'D:\ke\personal_work_log\usage_area\20210101-20210724_city_3'
APPKEY = 'frame_analysis'
SECRET = 'c338b06a92d4400edcbf11c03979241a'
API_URL = 'http://i.data.api.lianjia.com/v2/meta/frame_newhouse_v2'

def main1():
    floor_area_df = pd.read_csv(FLOOR_ARE_TSV, sep="\t")
    json_files = os.listdir(JSON_PATH)

    data = []
    for j in json_files:
        json_path = os.path.join(JSON_PATH, j)
        with open(json_path) as f:
            vector = json.load(f)
        floorplans = vector['floorplans']
        a = 0
        for f in floorplans:
            a += f['areas'][0]['sizeWithoutLine'] / 1000000
        a = round(a, 1)
        frame_id = long(j.split('.')[0])
        id_list = floor_area_df[floor_area_df['frame_id'] == frame_id].index.tolist()
        floor_area = 0
        if len(id_list) > 0:
            floor_area_idx = id_list[0]
            floor_area = floor_area_df.loc[floor_area_idx]['floor_area']
        r = a / (float(floor_area) + 0.01)
        data.append([frame_id, a, floor_area, r])
    df = pd.DataFrame(data=data, columns=['frame_id', 'usage_area', 'floor_area', 'ratio'])

    return None


def main2():
    json_files = os.listdir(JSON_PATH)
    data = []
    for idx, j in enumerate(json_files):
        print(idx)
        json_path = os.path.join(JSON_PATH, j)
        with open(json_path) as f:
            vector = json.load(f)
        floorplans = vector['floorplans']
        a = 0
        for f in floorplans:
            a += f['areas'][0]['sizeWithoutLine'] / 1000000
        a = round(a, 1)
        frame_id = j.split('.')[0]
        result = api_lib.request_bigdata_api_post(API_URL, {"frame_id": frame_id},
                                              APPKEY, SECRET)
        floor_area = 0
        try:
            basic_info = result['data'][0]['basic_info']
            basic_info = eval(basic_info)
            floor_area = basic_info['floor_area']
        except Exception as e:
            pass
        r = a / (float(floor_area) + 0.01)
        data.append([frame_id, a, floor_area, r])
    df = pd.DataFrame(data=data, columns=['frame_id', 'usage_area', 'floor_area', 'ratio'])
    df0 = df[(df['ratio'] > 0.9) | (df['ratio'] < 0.6)]

    df.to_excel(r'D:\all_usage_area.xlsx')
    df0.to_excel(r'D:\abnormal_frame.xlsx')


if __name__ == '__main__':
    # main1()
    main2()