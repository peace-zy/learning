# -*- coding:utf-8 -*-
import pandas as pd
import base64
import requests
from io import BytesIO
from PIL import Image
import os


FILE_PATH = r'D:\ori_image.tsv'
SAVE_PATH = r'D:\tmp\taonei_img'
INSIDE_TEXT = ['套内']

def get_ocr_result(img_base64):
    data = {'imgBase64': img_base64}
    api_url = 'http://i.ocr.jiaoyi.ke.com/api/ocr/natural?appkey=SHUJUZHINENG-WYS9U'
    res = requests.post(api_url, data=data, timeout=15).json()

    return res


def is_contain_inside_area(ocr_result):
    if ocr_result['data'] is None:
        return False
    if len(ocr_result['data']) == 0:
        return False

    res = ocr_result['data']['WEN_BEN_XIN_XI']
    for idx, text in enumerate(res):
        text_str = text.encode('utf8')
        for in_txt in INSIDE_TEXT:
            # in_txt_u = in_txt.encode('unicode-escape').decode()
            if in_txt in text_str:
                return True
    return False


def get_inside_area_img_orc(file_path):
    """得到有套内的字段图像"""
    df = pd.read_csv(file_path, sep="\t", encoding='cp1252')
    for idx, row in df.iterrows():
        # if idx < 359:
        #     continue
        print('idx: ', idx)
        frame_id = str(row['frame_id'])
        img_url = row['original_url']
        if type(img_url) != unicode:
            continue
        try:
            response = requests.get(img_url).content
            img_base64 = base64.b64encode(response)
            ocr_res = get_ocr_result(img_base64)

            if is_contain_inside_area(ocr_res):
                image = Image.open(BytesIO(response))
                if image.mode != 'CMYK':
                    image = image.convert('CMYK')
                img_name = str(frame_id) + '.jpg'
                image.save(os.path.join(SAVE_PATH, img_name))
        except Exception as e:
            pass


def get_original_image(file_path):
    df = pd.read_csv(file_path, sep="\t", encoding='cp1252')
    for idx, row in df.iterrows():
        print('idx: ', idx)
        frame_id = str(row['frame_id'])
        img_url = row['original_url']
        if type(img_url) != unicode:
            continue
        try:
            response = requests.get(img_url).content

            image = Image.open(BytesIO(response))
            if image.mode != 'CMYK':
                image = image.convert('CMYK')
            img_name = str(frame_id) + '.jpg'
            image.save(os.path.join(SAVE_PATH, img_name))
        except Exception as e:
            print(e)
            pass


if __name__ == '__main__':
    # get_inside_area_img_orc(FILE_PATH)
    get_original_image(FILE_PATH)

