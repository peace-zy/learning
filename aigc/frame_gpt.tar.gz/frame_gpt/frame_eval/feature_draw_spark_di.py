#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2019 www.ke.com, Inc. All Rights Reserved
"""
Authors: yudonghai@ke.com
Date: 2019/12/4
"""
from __future__ import division
import logging
import sys
import datetime
import time

import yaml
import redis
import json

from lib import spark_util
from lib import code_enum as ce
from lib.file_util import get_file_stream


def write2redis(rows):
    redis_conn = redis.StrictRedis(host="m12013.zeus.redis.ljnode.com",
                                   port=12013,
                                   db=0,
                                   password="2e6l5b9n31RSNHL4")
    pipeline = redis_conn.pipeline()
    write_cnt = 0
    for row in rows:
        write_cnt += 1
        liner_info = json.loads(row.liner_info)
        visual_liner_idx = liner_info[ce.EXPLAIN_VARS]["visual_liner_idx"]
        base_vars = json.loads(row.base_vars)

        plan_cnt = row.plan_cnt

        moving_lines = []
        visual_areas = []
        face_vectors = []
        wd_vectors = []
        for i in range(plan_cnt):
            if i == visual_liner_idx:
                moving_lines.append({"guest_line": json.loads(row.guest_lines),
                                     "living_line": json.loads(row.living_lines),
                                     "work_line": json.loads(row.work_lines)})
                visual_areas.append(liner_info[ce.EXPLAIN_VARS]["visual_areas"])
            else:
                moving_lines.append({"guest_line": {"line": [], "pts": []}, "living_line": {"line": [], "pts": []}, "work_line": {"line": [], "pts": []}})
                visual_areas.append([])
            face_vectors.append(base_vars["face_vectors"][i])
            wd_vectors.append(base_vars["wd_vectors"][i])

        feature_lst = [
            row.frame_id,
            json.dumps(moving_lines),
            json.dumps(visual_areas),
            json.dumps(face_vectors),
            json.dumps(wd_vectors),
            json.dumps(base_vars["quiet_areas"])
        ]
        draw_feature = "\t".join(feature_lst)
        frame_type = row.frame_type
        if frame_type == "ershou":
            pipeline.lpush("draw_feature", draw_feature)
        elif frame_type == "xinfang":
            pipeline.lpush("draw_feature_new", draw_feature)
        if write_cnt % 100 == 0:
            pipeline.execute()
            time.sleep(0.05)
    pipeline.execute()
    pipeline.close()


def upload_all(driver, raw_df, **params):
    """
     spark 逻辑处理
    :param driver: spark_util.SparkSqlDriver, spark 执行类
    :param raw_df: pyspark.sql.dataframe.DataFrame， sql 查询结果
    :param params: dict, 参数字典
    :return: result_df, 处理后的 DataFrame
    """
    # 分30个partiton 进行上传，即30个进程
    raw_df.repartition(30).foreachPartition(write2redis)
    result_df = raw_df.describe()
    return result_df


def main():
    """ 主函数 """
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    if len(sys.argv) < 3:
        logging.error("no less than 2 arguments!")
        sys.exit()

    pt_date = sys.argv[1]
    config_file = sys.argv[2]

    f = get_file_stream(config_file)
    conf = yaml.load(f)
    # with open(config_file, "r") as config_data:
    #     conf = yaml.load(config_data)

    # 从配置文件读取参数
    spark_config_key = "draw_feature_upload_di_config"
    spark_params = conf.get(spark_config_key, None)
    if spark_params is None:
        logging.error("lack {} in config file".format(spark_config_key))
        sys.exit(1)

    # ## 补充参数
    spark_params["sql_params"]["pt_date"] = pt_date
    current_date = datetime.datetime.strptime(pt_date, "%Y%m%d")
    pre_pt_date_str = (current_date - datetime.timedelta(days=1)).strftime("%Y%m%d")
    spark_params["sql_params"]["pre_pt_date"] = pre_pt_date_str
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_function"] = upload_all

    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()


if __name__ == "__main__":
    main()
