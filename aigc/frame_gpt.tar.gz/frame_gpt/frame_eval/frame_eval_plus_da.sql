SELECT
    base.frame_id,
    image_id,
    city_code,
    frame_size,
    state,
    plan_cnt,
    room,
    parlour,
    kitchen,
    toilet,
    frame_label,
    eval_base_text,
    eval_liner_text,
    message_text,
    moving_lines,
    visual_areas,
    face_vectors,
    wd_vectors,
    movement_areas,
    main_img,
    guest_lines,
    living_lines,
    work_lines
FROM
(SELECT DISTINCT
    frame_id
FROM data_mining.data_mining_framex_vector_base_da
WHERE pt='{pt_date}000000'
AND censor_level=2  -- 审核通过
AND is_valid=1
) fil
JOIN
(SELECT
    frame_id,
    image_id,
    city_code,
    frame_size,
    state,
    plan_cnt,
    room,
    parlour,
    kitchen,
    toilet,
    frame_label,
    eval_base_text,
    message_text
FROM data_mining.data_mining_frame_eval_base_da
WHERE pt='{pt_date}000000'
) base
ON base.frame_id=fil.frame_id
LEFT JOIN
(SELECT
    frame_id,
    guest_lines,
    living_lines,
    work_lines,
    eval_liner_text
FROM data_mining.data_mining_frame_line_da
WHERE pt='{pt_date}000000'
) liner
ON base.frame_id=liner.frame_id
INNER JOIN
(SELECT
    frame_id,
    moving_lines,
    visual_areas,
    face_vectors,
    wd_vectors,
    movement_areas,
    main_img
FROM ods.ods_frame_miner_frame_eval_img_inf_da
where pt='{pt_date}000000'
) img
ON base.frame_id=img.frame_id
