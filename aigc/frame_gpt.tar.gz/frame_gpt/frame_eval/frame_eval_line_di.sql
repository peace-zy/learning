SELECT
    NVL(current.frame_id, pre.frame_id) as frame_id
    ,current.image_id as image_id
    ,current.vector_value as vector_value
    ,current.city_code as city_code
FROM
(SELECT
    frame_id
    ,image_id
    ,vector_value
    ,city_code
    ,vector_md5
FROM
(SELECT
    mapping.entity_id as frame_id
    ,image_id
    ,reflect("java.net.URLDecoder", "decode", trim(vector_value), "UTF-8") AS vector_value
    ,md5(vector_value) as vector_md5
    ,city_code
    ,ROW_NUMBER() OVER(PARTITION BY mapping.entity_id ORDER BY update_time desc) AS rn
FROM
(SELECT
    id
    ,vector_value
    ,city_code
FROM dw.dw_house_frame_vector_da
WHERE pt='{pt_date}000000'
AND is_valid=1
) vector
JOIN
(SELECT
    image_id
    ,entity_id
    ,update_time
FROM dw.dw_house_image_entity_mapping_da
WHERE pt='{pt_date}000000'
AND image_type_code = 110028006
AND entity_type_code = 110029002
AND is_valid = 1
) mapping
ON mapping.image_id=vector.id
) tb
WHERE tb.rn=1
) current
FULL OUTER JOIN
(SELECT
    frame_id
    ,image_id
    ,vector_value
    ,city_code
    ,vector_md5
FROM
(SELECT
    mapping.entity_id as frame_id
    ,image_id
    ,reflect("java.net.URLDecoder", "decode", trim(vector_value), "UTF-8") AS vector_value
    ,md5(vector_value) as vector_md5
    ,city_code
    ,ROW_NUMBER() OVER(PARTITION BY mapping.entity_id ORDER BY update_time desc) AS rn
FROM
(SELECT
    id
    ,vector_value
    ,city_code
FROM dw.dw_house_frame_vector_da
WHERE pt='{pre_pt_date}000000'
AND is_valid=1
) vector
JOIN
(SELECT
    image_id
    ,entity_id
    ,update_time
FROM dw.dw_house_image_entity_mapping_da
WHERE pt='{pre_pt_date}000000'
AND image_type_code = 110028006
AND entity_type_code = 110029002
AND is_valid = 1
) mapping
ON mapping.image_id=vector.id
) tb
WHERE tb.rn=1
) pre
ON pre.frame_id=current.frame_id
WHERE pre.frame_id IS NULL or current.frame_id IS NULL
or pre.image_id!=current.image_id
or pre.vector_md5!=current.vector_md5
or pre.city_code!=current.city_code
UNION ALL
SELECT
    NVL(new_cur.frame_id, new_pre.frame_id) as frame_id
    ,''  as image_id
    ,new_cur.vector as vector_value
    ,new_cur.city_code as city_code
FROM
(SELECT
    frame_id
    ,vector
    ,city_code
    ,md5(vector) as new_md5
FROM data_mining.data_mining_framex_vector_base_da
WHERE pt='{pt_date}000000'
) new_cur
FULL OUTER JOIN
(SELECT
    frame_id
    ,vector
    ,city_code
    ,md5(vector) as new_md5
FROM data_mining.data_mining_framex_vector_base_da
WHERE pt='{pre_pt_date}000000'
 ) new_pre
ON new_pre.frame_id=new_cur.frame_id
WHERE new_pre.frame_id IS NULL OR new_cur.frame_id IS NULL
OR new_pre.new_md5!=new_cur.new_md5
OR new_pre.city_code!=new_cur.city_code
