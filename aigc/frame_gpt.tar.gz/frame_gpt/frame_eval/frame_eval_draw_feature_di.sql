SELECT
    frame_id
    ,base_vars
    ,guest_lines
    ,living_lines
    ,work_lines
    ,liner_info
    ,frame_type
    ,plan_cnt
FROM
(SELECT
    base.frame_id
    ,im.frame_id AS im_frame_id
    ,base_vars
    ,guest_lines
    ,living_lines
    ,work_lines
    ,liner_info
    ,frame_type
    ,plan_cnt
FROM
(SELECT
    frame_id,
    message_text AS base_vars,
    plan_cnt
FROM data_mining.data_mining_frame_eval_base_da
WHERE pt='{pt_date}000000'
AND state=0
) base
JOIN
(SELECT
    frame_id
    ,guest_lines
    ,living_lines
    ,work_lines
    ,eval_liner_text AS liner_info
FROM data_mining.data_mining_frame_line_da
WHERE pt='{pt_date}000000'
) liner
ON liner.frame_id=base.frame_id
JOIN
(SELECT
    frame_id
    ,'ershou' as frame_type
FROM
((SELECT DISTINCT
    cast(frame_id AS string) AS frame_id,
    house_id
FROM dw.dw_house_house_frame_mapping_da
WHERE pt = '{pt_date}000000'
AND is_valid=1
) frame_house
JOIN
(SELECT
    housedel_id,
    house_id
FROM dw.dw_allinfo_housedel_da
WHERE pt = '{pt_date}000000'
AND housedel_status_code IN (
    120011001, -- 有效
    120011002, -- 意向金起草
    120011003, -- 意向金盖章
    120011004, -- 意向金签订
    120011019, -- 意向金无效
    120011020, -- 意向金退意向
    120011023, -- 意向金完结
    120011009  -- 合同起草
)  -- 认为在售状态
) housedel
ON housedel.house_id=frame_house.house_id
) onsale_housedel
UNION ALL
SELECT DISTINCT
    frame_id
    ,'xinfang' as frame_type
FROM data_mining.data_mining_framex_vector_base_da
WHERE pt = '{pt_date}000000'
) filter_frame
ON filter_frame.frame_id=base.frame_id
LEFT JOIN
(SELECT
    frame_id
FROM ods.ods_frame_miner_frame_eval_img_inf_da
WHERE pt='{pt_date}000000'
) im
ON im.frame_id=base.frame_id
) x
WHERE x.im_frame_id IS NULL
