# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/8/11 11:26
# ===================================
import copy
import os
import base64
import cv2
import numpy as np
import pandas as pd
import requests
from PIL import Image
from io import BytesIO


def judge_furniture(image):
    app_key = '293dfff6x1921x11edxbabcx7cd30a5d8060'

    API_URL = "http://gaia.api.ke.com/furniture_detection?appkey={}".format(app_key)
    data = {'request_id': '29176262,try',
            'input_mode': 'file'}
    files = {'img_file': image}
    r = requests.post(API_URL, data=data, files=files).json()
    return len(r['furniture_list']['result'])


def judge_url(url):
    app_key = '293dfff6x1921x11edxbabcx7cd30a5d8060'

    API_URL = "http://gaia.api.ke.com/furniture_detection?appkey={}".format(app_key)
    data = {'request_id': '29176262,try',
            'img_url': url,
            'input_mode': 'url'}
    r = requests.post(API_URL, data=data).json()
    if r['error_code'] == 0:
        return len(r['furniture_list']['result'])
    else:
        return -1


def main():
    df = pd.read_csv('frame_eval/room_rendering_v2/room_rendering_class2.csv', sep='\t')
    # url 去重
    df2 = df.drop_duplicates(subset='url', keep='first', inplace=False)
    df3 = pd.DataFrame(columns=df2.columns)
    for index, row in df2.iterrows():
        if index >= 100:
            break
        try:
            _url = row.url
            cnt = judge_url(_url)
            if cnt == -1:
                response = requests.get(_url)
                image = Image.open(BytesIO(response.content))
                dim_origin = (image.size[0], image.size[1])
                dim = dim_origin
                if dim_origin[0] > 4000 or dim_origin[1] > 4000:
                    dim = (int(dim_origin[0] / 2), int(dim_origin[1] / 2))
                image = image.resize(dim, Image.ANTIALIAS)
                img_byte = BytesIO()
                image.save(img_byte, format='JPEG')
                binary_str = img_byte.getvalue()
                cnt = judge_furniture(binary_str)

            print(index, _url, cnt)
            if cnt >= 1:
               df3.loc[len(df3)] = row
        except Exception as e:
            print(e)
        pass

    df3.to_csv('frame_eval/room_rendering_v2/room_rendering_class_drop_duplicates2.csv', index=False, sep='\t')
    pass


def drop_small_img():
    df = pd.read_csv('frame_eval/room_rendering_v2/room_rendering_class_drop_duplicates2.csv', sep='\t', error_bad_lines=False)
    df2 = pd.DataFrame(columns=df.columns)
    for index, row in df.iterrows():
        try:
            _url = row.url
            response = requests.get(_url)
            image = Image.open(BytesIO(response.content))
            dim_origin = (image.size[0], image.size[1])
            if dim_origin[0] > 900 or dim_origin[1] > 900:
                df2.loc[len(df2)] = row
                print(index, row.url, 1)
            else:
                print(index, row.url, 0)
        except Exception as e:
            print(e)
        pass
    df2.to_csv('frame_eval/room_rendering_v2/room_rendering_class_drop_duplicates3.csv', index=False, sep='\t')
    pass


if __name__ == '__main__':
    # main()
    drop_small_img()
    pass
