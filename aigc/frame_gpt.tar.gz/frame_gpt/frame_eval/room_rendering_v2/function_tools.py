# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/6/22 16:44
# ===================================
from __future__ import division

import copy
import boto3
import math
import json

import pandas as pd
import requests
from PIL import Image
from io import BytesIO

from collections import defaultdict


def get_s3_client():
    S3_AK = "223HG43LGIX9W3MWTOCL"
    S3_AKS = "tqWXh8kSyxM/QfgF34dMXFJcRrIIGfIIZkVVjSMH"
    s3_client = boto3.client('s3', region_name="cn-north-1", endpoint_url="http://storage.lianjia.com",
                             aws_access_key_id=S3_AK,
                             aws_secret_access_key=S3_AKS)
    return s3_client


def get_frame_vector(frame_id):
    frame_id = str(frame_id)
    s3_client = get_s3_client()
    vector_response = s3_client.get_object(Bucket='frame-eval-image', Key=str(frame_id) + '.json')
    frame_json = vector_response['Body'].read().decode('utf-8')
    return frame_json


class RoomCombine(object):

    def __init__(self, frame_id='No', frame_json='No', **kwargs):
        """
        组合分间类，可以使用户型id或户型矢量初始化，并通过分间id或分间名称获取对应的分间对象
        :param frame_id:
        :param frame_json:
        :param kwargs:
        """
        frame_id = str(frame_id)
        if frame_id == 'No' and frame_json == 'No':
            raise KeyError('Missing parameter called frame_id or frame_json')
        if frame_id != 'No' and frame_json == 'No':
            frame_json = get_frame_vector(frame_id)
        self.frame_id = frame_id

        self.frame_json = frame_json
        self.frame_dict = json.loads(self.frame_json)
        self.room_id_set = set([area['id'] for area in self.frame_dict['floorplans'][0]['areas']])
        self.room_name_set = set([area['roomName'] for area in self.frame_dict['floorplans'][0]['areas']])

    @property
    def pt_id_dict(self):
        # 存储了顶点标号与顶点坐标之间的映射关系
        id_dict = dict()
        for point in self.frame_dict['floorplans'][0]['points']:
            id_dict[point['id']] = [point['x'], point['y']]
        return id_dict

    @property
    def frame_info_total(self):
        info_dict = {
            'points': {point['id']: point for point in self.frame_dict['floorplans'][0]['points']},
            'lines': {line['id']: line for line in self.frame_dict['floorplans'][0]['lines']},
            'areas': {area['id']: area for area in self.frame_dict['floorplans'][0]['areas']},
            'lineItems': {lineItem['id']: lineItem for lineItem in self.frame_dict['floorplans'][0]['lineItems']},
            'items': {item['id']: item for item in self.frame_dict['floorplans'][0]['items']},
        }
        return info_dict

    @property
    def name_area_id_dict(self):
        """
        分间名称：分间id字典
        """
        res = {area['roomName']: area['id'] for area in self.frame_dict['floorplans'][0]['areas']}
        return res

    def get_empty_frame_json(self):
        frame_dict = copy.deepcopy(self.frame_dict)
        frame_dict['floorplans'][0]['points'] = []
        frame_dict['floorplans'][0]['lines'] = []
        frame_dict['floorplans'][0]['areas'] = []
        frame_dict['floorplans'][0]['lineItems'] = []
        frame_dict['floorplans'][0]['items'] = []
        return json.dumps(frame_dict)

    def show(self, hide_compass=False, show=True, save_path=None, url='http://10.200.40.29:8898/print-polygon'):
        payload = {
            'source': self.frame_json,
            "pngSize": '1440x1080',
            'hideCompass': hide_compass,
        }
        try:
            res = requests.post(url, data=payload)
            img_bytes = res.content
            img = Image.open(BytesIO(img_bytes))
        except Exception as e:
            raise Exception('Draw image error')
        if show:
            img.show()
        if save_path:
            img.save(save_path)
        return img_bytes

    def get_id_object(self, area_id):
        empty_json = self.get_empty_frame_json()
        res_dict = json.loads(empty_json)
        if area_id not in self.room_id_set:
            return RoomCombine(frame_json=self.get_empty_frame_json())
        area = self.frame_info_total['areas'][area_id]
        res_dict['floorplans'][0]['areas'].append(copy.deepcopy(area))

        for point_id in area['points']:
            res_dict['floorplans'][0]['points'].append(copy.deepcopy(self.frame_info_total['points'][point_id]))
        attach_lines = area['attachments']['lines']
        attach_lineItems = area['attachments']['lineItems']
        for line in attach_lines:
            res_dict['floorplans'][0]['lines'].append(copy.deepcopy(self.frame_info_total['lines'][line['id']]))
        for lineItem in attach_lineItems:
            res_dict['floorplans'][0]['lineItems'].append(
                copy.deepcopy(self.frame_info_total['lineItems'][lineItem['id']]))
        res_json = json.dumps(res_dict)
        return RoomCombine(frame_id=self.frame_id, frame_json=res_json)

    def get_name_object(self, roomName):
        if roomName not in self.name_area_id_dict:
            print("该户型没有名为{}的分间".format(roomName))
            return None
        area_id = self.name_area_id_dict[roomName]
        return self.get_id_object(area_id)

    def get_outer_pt_list(self):
        """
        :return: 返回带顺序的户型外点坐标，顺时针或逆时针不一定
        """
        edge_list = list()
        pt_coord_list = list()
        # 存储户型的外墙
        edge_cnt_dict = defaultdict(lambda: 0)
        for area_id, area in self.frame_info_total['areas'].items():
            for line in area['attachments']['lines']:
                edge_cnt_dict[line['id']] = edge_cnt_dict[line['id']] + 1
        for line_id in edge_cnt_dict:
            if edge_cnt_dict[line_id] == 1 and line_id in self.frame_info_total['lines']:
                edge_list.append(copy.deepcopy(self.frame_info_total['lines'][line_id]))

        # 存储墙体id和墙体端点的映射关系、墙体端点与相连接的墙体id映射关系
        line_pt_dict = defaultdict(list)
        pt_line_dict = defaultdict(list)
        for line in edge_list:
            line_pt_dict[line['id']].append(line['points'][0])
            line_pt_dict[line['id']].append(line['points'][1])
            pt_line_dict[line['points'][0]].append(line['id'])
            pt_line_dict[line['points'][1]].append(line['id'])
        # 以外墙列表第一个墙体的第一个端点为起始点
        start_pt = edge_list[0]['points'][0]
        pt_coord_list.append(self.pt_id_dict[start_pt])
        now_line = pt_line_dict[start_pt][0]
        now_pt = line_pt_dict[now_line][1] if start_pt == line_pt_dict[now_line][0] else line_pt_dict[now_line][0]
        while now_pt != start_pt:
            pt_coord_list.append(self.pt_id_dict[now_pt])
            now_line = pt_line_dict[now_pt][1] if now_line == pt_line_dict[now_pt][0] else pt_line_dict[now_pt][0]
            now_pt = line_pt_dict[now_line][1] if now_pt == line_pt_dict[now_line][0] else line_pt_dict[now_line][0]

        return pt_coord_list

    def get_min_max(self):
        result = [1000000, 0, 1000000, 0]
        for point_id, point in self.frame_info_total['points'].items():
            result[0] = min(result[0], point['x'])
            result[1] = max(result[1], point['x'])
            result[2] = min(result[2], point['y'])
            result[3] = max(result[3], point['y'])
        return result

    def plot(self):
        """
        用matplotlib绘制当前组合分间外轮廓
        """
        pt_list = self.get_outer_pt_list()
        pt_list.append(pt_list[0])
        import matplotlib.pyplot as plt
        plt.plot([p[0] for p in pt_list], [p[1] for p in pt_list], 'o')
        n = len(pt_list)
        for index in range(n):
            if index == n-1:
                continue
            plt.plot([pt_list[index][0], pt_list[index + 1][0]], [pt_list[index][1], pt_list[index + 1][1]], 'b')
        plt.show()


def area_convert(area_size):
    if area_size > 5000:
        return area_size / 1000000
    return area_size


def convert_name(detailType):
    if detailType == 1:
        return '客厅'
    if detailType == 2:
        return '餐厅'
    if detailType == 3:
        return '卧室'
    if detailType == 4:
        return '书房'
    if detailType == 5 or detailType == 7:
        return '卫生间'
    if detailType == 8 or detailType == 9:
        return '厨房'
    if detailType == 12:
        return '阳台'
    if detailType == 15:
        return '衣帽间'
    if detailType == 25:
        return '门厅'
    if detailType == 27:
        return '玄关'
    return 'undefined'


def cal_dis(p1, p2):
    return math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)


def judge_room_class(area_id, frame_json):
    RC = RoomCombine(frame_json=frame_json)
    frame_dict = json.loads(frame_json)
    area_size = 0
    # area_id = None
    for area in frame_dict['floorplans'][0]['areas']:
        if area['id'] != area_id:
            continue
        area_size = area_convert(area['size'])
        # key_name = convert_name(area['roomType'], area['type'])
        # if key_name != room_name:
        #    continue
        # S = area_convert(area['size'])
        # if S > area_size:
        #     area_id = area['id']
        #     area_size = S
    if area_id is None:
        return -1, -1
    rc = RC.get_id_object(area_id)

    [minx, maxx, miny, maxy] = rc.get_min_max()
    rec_area = (maxx - minx) / 1000.0 * (maxy - miny) / 1000.0
    rec_ratio = area_size / rec_area
    if rec_ratio < 0.9:
        pt_list = rc.get_outer_pt_list()
        horizen_line_list = list()
        vertical_line_list = list()
        inclined_line_list = list()
        for index, point in enumerate(pt_list):
            n_index = (index + 1) % len(pt_list)
            pt1, pt2 = point, pt_list[n_index]
            at = math.atan2(pt2[1] - pt1[1], pt2[0] - pt1[0])
            eps = 0.1
            if 3.14 - eps < abs(at) < 3.14 + eps:
                horizen_line_list.append([pt1, pt2, cal_dis(pt1, pt2)])
                continue
            if 0.0 - eps < abs(at) < 0.0 + eps:
                horizen_line_list.append([pt1, pt2, cal_dis(pt1, pt2)])
                continue
            if 1.57 - eps < abs(at) < 1.57 + eps:
                vertical_line_list.append([pt1, pt2, cal_dis(pt1, pt2)])
                continue
            inclined_line_list.append([pt1, pt2, cal_dis(pt1, pt2)])
        if len(inclined_line_list) == 0 :
            horizen_line_list = sorted(horizen_line_list, key=lambda x: x[0][1])
            vertical_line_list = sorted(vertical_line_list, key=lambda x: x[0][0])

            width = maxx - minx
            height = maxy - miny

            low_h, high_h = 0, len(horizen_line_list) - 1
            low_v, high_v = 0, len(vertical_line_list) - 1

            for index in range(len(horizen_line_list)):
                if horizen_line_list[index][2] / width < 0.01:
                    continue
                low_h = index
                break
            for index in range(len(horizen_line_list) - 1, -1, -1):
                if horizen_line_list[index][2] / width < 0.01:
                    continue
                high_h = index
                break
            for index in range(len(vertical_line_list)):
                if vertical_line_list[index][2] / height < 0.01:
                    continue
                low_v = index
                break
            for index in range(len(vertical_line_list) - 1, -1, -1):
                if vertical_line_list[index][2] / height < 0.01:
                    continue
                high_v = index
                break
            ratio_h = min(horizen_line_list[low_h][2], horizen_line_list[high_h][2]) / max(horizen_line_list[low_h][2],
                                                                                           horizen_line_list[high_h][2])
            ratio_v = min(vertical_line_list[low_v][2], vertical_line_list[high_v][2]) / max(vertical_line_list[low_v][2],
                                                                                             vertical_line_list[high_v][2])

            lei = 0
            if ratio_h < 0.2 and ratio_v < 0.2:
                lei = 4
            elif 0.2 < ratio_h < 0.666 and 0.2 < ratio_v < 0.666:
                lei = 5
            elif ratio_h > 0.666 and ratio_v > 0.666:
                lei = 6
            elif 0.2 < ratio_h < 0.666 and ratio_v < 0.2:
                lei = 7
            elif 0.2 < ratio_v < 0.666 and ratio_h < 0.2:
                lei = 7
            elif ratio_v < 0.666 and ratio_h > 0.666:
                lei = 8
            elif ratio_h < 0.666 and ratio_v > 0.666:
                lei = 8
        else:
            lei = -1
    else:
        duan = min(maxx - minx, maxy - miny)
        chang = max(maxx - minx, maxy - miny)
        lei = 0
        if 1 > duan / chang > 0.75:
            lei = 1
        elif 0.75 > duan / chang > 0.5:
            lei = 2
        else:
            lei = 3
    return area_size, lei


def url_shuffle(url_info_list):
    style_cnt_dict = defaultdict(int)
    index_list = list()
    for info in url_info_list:
        index_list.append([style_cnt_dict[info['area_size']], copy.deepcopy(info)])
        style_cnt_dict[info['area_size']] += 1
    index_list = sorted(index_list, key=lambda x: x[0])
    url_info_list = [info[1] for info in index_list]
    return url_info_list


def city_shuffle(city_code, url_info_list):
    self_city_info = list()
    other_city_info = list()
    for info in url_info_list:
        if info['city_code'] == city_code:
            self_city_info.append(info)
        else:
            other_city_info.append(info)
    total_city_info = self_city_info + other_city_info
    return total_city_info[0:100]


def case_study():
    frame_house_df = pd.read_csv('D:/python_project/data/houseid_frameid.csv', sep='\t')
    rendering_df = pd.read_csv('frame_eval/room_rendering_v2/room_rendering_class_drop_duplicates3.csv', sep='\t', error_bad_lines=False)
    output_list = list()
    for index, row in frame_house_df.iterrows():
        print(index)
        try:
            frame_id = str(int(row.frame_id))
            # room_name = '厨房'
            frame_json = get_frame_vector(frame_id)
            frame_dict = json.loads(frame_json)
            result_dict = dict()

            max_bedroom_area = 0
            for area in frame_dict['floorplans'][0]['areas']:
                if area['type'] != 3:
                    continue
                S = area_convert(area['size'])
                max_bedroom_area = max(max_bedroom_area, S)

            for area in frame_dict['floorplans'][0]['areas']:
                key_name = convert_name(area['type'])
                if key_name == 'undefined':
                    continue
                S = area_convert(area['size'])
                if area['type'] == 3 and S != max_bedroom_area:
                    key_name = '次卧'
                if area['type'] == 3 and S == max_bedroom_area:
                    key_name = '主卧'

                room_result_dict = dict()
                room_result_dict['room_name'] = key_name
                area_size = area_convert(area['size'])
                room_result_dict['area_size'] = area_size
                room_result_dict['style'] = defaultdict(list)

                ans = judge_room_class(area['id'], frame_json)
                rendering_df_filter = rendering_df[rendering_df['class'] == ans[1]]
                rendering_df_filter = rendering_df_filter[0.5 * ans[0] < rendering_df_filter['area_size']]
                rendering_df_filter = rendering_df_filter[rendering_df_filter['area_size'] < 1.5 * ans[0]]
                rendering_df_filter = rendering_df_filter[rendering_df_filter['space_name'] == key_name]
                if area['type'] == 3:
                    rendering_df_bedroom = rendering_df[rendering_df['class'] == ans[1]]
                    rendering_df_bedroom = rendering_df_bedroom[0.5 * ans[0] < rendering_df_bedroom['area_size']]
                    rendering_df_bedroom = rendering_df_bedroom[rendering_df_bedroom['area_size'] < 1.5 * ans[0]]
                    rendering_df_bedroom = rendering_df_bedroom[rendering_df_bedroom['space_name'] == '卧室']
                    rendering_df_filter = pd.concat([rendering_df_filter, rendering_df_bedroom], axis=0)

                for index2, _row in rendering_df_filter.iterrows():
                    # room_result_dict['style'][_row['style_name']].append([_row['area_size'], _row['beauty'], _row['clarity'], _row['url'], ans[1], _row['content_id']])
                    room_result_dict['style'][_row['style_name']].append({
                        'area_size': _row['area_size'],
                        'url': _row['url'],
                        'content_id': _row['content_id']
                    })

                for _style, _style_info in room_result_dict['style'].items():
                    _style_info_tmp = sorted(_style_info, key=lambda x: abs(room_result_dict['area_size'] - x['area_size']))
                    room_result_dict['style'][_style] = url_shuffle(_style_info_tmp)[0:12]
                    pass
                if key_name not in result_dict:
                    result_dict[key_name] = room_result_dict
                elif area_size > result_dict[key_name]['area_size']:
                    result_dict[key_name] = room_result_dict
                pass
            pass

            url_set = set()

            for _room_typle, style_info in result_dict.items():
                for style_name, _area_url in style_info['style'].items():
                    for _info in _area_url:
                        if _info['url'] in url_set:
                            continue
                        url_set.add(_info['url'])
                        output = list()
                        output.append(row.resblock_name)
                        output.append(str(int(row.house_id)))
                        output.append(frame_id)
                        output.append(round(style_info['area_size'], 2))
                        output.append(style_info['room_name'])
                        # output.append(shape_class)
                        output.append(style_name)
                        output.append(_info['area_size'])
                        output.append(_info['content_id'])
                        output.append(_info['url'])
                        output_list.append(output)

        except Exception as e:
            print(e)
            continue
    df_result = pd.DataFrame(output_list, columns=['小区id', '房屋id', '户型id', '分间面积', '分间类型', '装修风格', '装修分间面积', 'content_id', '装修图片url'])
    df_result.to_csv('frame_eval/room_rendering_v2/result2.csv', index=False, sep='\t', encoding='utf-8')
    pass


def case_study2():
    rendering_with_json = pd.read_csv('D:/python_project/data/rendering_data_20220805.tsv', sep='\t', encoding='gbk')
    rendering_class_list = list()
    for index, row in rendering_with_json.iterrows():
        if index % 10 == 0:
            print(index)
        try:
            if str(row.frame_id) != '0':
                frame_json = row.frame_json.encode('utf-8')
                if type(frame_json) != str:
                    continue
                frame_dict = json.loads(frame_json)
                RC = RoomCombine(frame_json=frame_json)

                max_bedroom_area = 0
                for area in frame_dict['floorplans'][0]['areas']:
                    if area['type'] != 3:
                        continue
                    S = area_convert(area['size'])
                    max_bedroom_area = max(max_bedroom_area, S)

                area_size = 0
                area_id = None

                for area in frame_dict['floorplans'][0]['areas']:
                    key_name = convert_name(area['type'])
                    S = area_convert(area['size'])
                    if area['type'] == 3 and S != max_bedroom_area:
                        key_name = '次卧'
                    if area['type'] == 3 and S == max_bedroom_area:
                        key_name = '主卧'
                    if area['type'] == 3:
                        if row.space_name.encode('utf-8') != '卧室' and row.space_name.encode('utf-8') != key_name:
                            continue
                    else:
                        if key_name != row.space_name.encode('utf-8'):
                            continue
                    if S > area_size:
                        area_id = area['id']
                        area_size = S
                if area_id is None:
                    continue
                rc = RC.get_id_object(area_id)

                [minx, maxx, miny, maxy] = rc.get_min_max()
                rec_area = (maxx - minx) / 1000.0 * (maxy - miny) / 1000.0
                rec_ratio = area_size / rec_area
                if rec_ratio < 0.9:
                    pt_list = rc.get_outer_pt_list()
                    horizen_line_list = list()
                    vertical_line_list = list()
                    for index, point in enumerate(pt_list):
                        n_index = (index + 1) % len(pt_list)
                        pt1, pt2 = point, pt_list[n_index]
                        at = math.atan2(pt2[1] - pt1[1], pt2[0] - pt1[0])
                        eps = 0.1
                        if 3.14 - eps < abs(at) < 3.14 + eps:
                            horizen_line_list.append([pt1, pt2, cal_dis(pt1, pt2)])
                        if 0.0 - eps < abs(at) < 0.0 + eps:
                            horizen_line_list.append([pt1, pt2, cal_dis(pt1, pt2)])
                        if 1.57 - eps < abs(at) < 1.57 + eps:
                            vertical_line_list.append([pt1, pt2, cal_dis(pt1, pt2)])
                    horizen_line_list = sorted(horizen_line_list, key=lambda x: x[0][1])
                    vertical_line_list = sorted(vertical_line_list, key=lambda x: x[0][0])

                    width = maxx - minx
                    height = maxy - miny

                    low_h, high_h = 0, len(horizen_line_list) - 1
                    low_v, high_v = 0, len(vertical_line_list) - 1

                    for index in range(len(horizen_line_list)):
                        if horizen_line_list[index][2] / width < 0.01:
                            continue
                        low_h = index
                        break
                    for index in range(len(horizen_line_list) - 1, -1, -1):
                        if horizen_line_list[index][2] / width < 0.01:
                            continue
                        high_h = index
                        break
                    for index in range(len(vertical_line_list)):
                        if vertical_line_list[index][2] / height < 0.01:
                            continue
                        low_v = index
                        break
                    for index in range(len(vertical_line_list) - 1, -1, -1):
                        if vertical_line_list[index][2] / height < 0.01:
                            continue
                        high_v = index
                        break
                    ratio_h = min(horizen_line_list[low_h][2], horizen_line_list[high_h][2])/max(horizen_line_list[low_h][2], horizen_line_list[high_h][2])
                    ratio_v = min(vertical_line_list[low_v][2], vertical_line_list[high_v][2]) / max(vertical_line_list[low_v][2], vertical_line_list[high_v][2])

                    lei = 0
                    if ratio_h < 0.2 and ratio_v < 0.2:
                        lei = 4
                    elif 0.2 < ratio_h < 0.666 and 0.2 < ratio_v < 0.666:
                        lei = 5
                    elif ratio_h > 0.666 and ratio_v > 0.666:
                        lei = 6
                    elif 0.2 < ratio_h < 0.666 and ratio_v < 0.2:
                        lei = 7
                    elif 0.2 < ratio_v < 0.666 and ratio_h < 0.2:
                        lei = 7
                    elif ratio_v < 0.666 and ratio_h > 0.666:
                        lei = 8
                    elif ratio_h < 0.666 and ratio_v > 0.666:
                        lei = 8
                else:
                    duan = min(maxx-minx, maxy-miny)
                    chang = max(maxx-minx, maxy-miny)
                    lei = 0
                    if 1 > duan/chang > 0.75:
                        lei = 1
                    elif 0.75 > duan/chang > 0.5:
                        lei = 2
                    else:
                        lei = 3
                # print(str(int(row.frame_id)), lei)
                # print(row.space_name)
                rendeing_info = list()
                rendeing_info.append(row.content_id)
                rendeing_info.append(row.space_type)
                rendeing_info.append(row.space_name.encode('utf-8'))
                rendeing_info.append(row.url)
                rendeing_info.append(row.style)
                rendeing_info.append(row.style_name.encode('utf-8'))
                rendeing_info.append(row.color)
                rendeing_info.append(row.color_name.encode('utf-8'))
                rendeing_info.append(str(int(row.frame_id)))
                rendeing_info.append(round(area_size, 2))
                rendeing_info.append(lei)
            else:
                rendeing_info = list()
                rendeing_info.append(row.content_id)
                rendeing_info.append(row.space_type)
                rendeing_info.append(row.space_name.encode('utf-8'))
                rendeing_info.append(row.url)
                rendeing_info.append(row.style)
                rendeing_info.append(row.style_name.encode('utf-8'))
                rendeing_info.append(row.color)
                rendeing_info.append(row.color_name.encode('utf-8'))
                rendeing_info.append(str(int(row.frame_id)))
                rendeing_info.append(round(row.area, 2))
                rendeing_info.append(-1)

            rendeing_info.append(int(row.parlor_count))
            rendeing_info.append(int(row.room_count))
            rendeing_info.append(int(row.cook_room_count))
            rendeing_info.append(int(row.toilet_count))
            rendeing_info.append(row.city_code)
            rendering_class_list.append(rendeing_info)
        except Exception as e:
            print(e)
            continue
    df = pd.DataFrame(rendering_class_list, columns=['content_id', 'space_type', 'space_name', 'url', 'style', 'style_name',
                                                     'color', 'color_name', 'frame_id', 'area_size', 'class',
                                                     'parlor_count', 'room_count', 'cook_room_count', 'toilet_count', 'city_code'])
    df.to_csv('frame_eval/room_rendering_v2/room_rendering_class2.csv', index=False, sep='\t')
    pass


if __name__ == '__main__':
    case_study()
    pass
