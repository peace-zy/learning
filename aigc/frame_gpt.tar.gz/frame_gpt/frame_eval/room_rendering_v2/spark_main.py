# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/6/20 14:23
# ===================================
from __future__ import division

import json
import sys

import yaml
import random
import logging
import datetime
import argparse
import traceback
import pandas as pd
from collections import defaultdict

from lib import spark_util_v2
from lib.file_util import get_file_stream
from frame_eval.room_rendering_v2.function_tools import city_shuffle, judge_room_class, url_shuffle
from frame_eval.room_rendering_v2.function_tools import area_convert, convert_name


def find_rendering_case(row, **params):
    try:
        rendering_df = params['rendering_df']
        frame_id = str(int(row.frame_id))
        frame_json = row.frame_json
        frame_dict = json.loads(frame_json)
        result_dict = dict()

        max_bedroom_area = 0
        for area in frame_dict['floorplans'][0]['areas']:
            if area['type'] != 3:
                continue
            S = area_convert(area['size'])
            max_bedroom_area = max(max_bedroom_area, S)

        for area in frame_dict['floorplans'][0]['areas']:
            key_name = convert_name(area['type'])
            if key_name == 'undefined':
                continue
            S = area_convert(area['size'])
            if area['type'] == 3 and S != max_bedroom_area:
                key_name = '次卧'
            if area['type'] == 3 and S == max_bedroom_area:
                key_name = '主卧'

            room_result_dict = dict()
            room_result_dict['room_name'] = key_name
            area_size = area_convert(area['size'])
            room_result_dict['area_size'] = area_size
            room_result_dict['style'] = defaultdict(list)

            ans = judge_room_class(area['id'], frame_json)
            rendering_df_filter = rendering_df[rendering_df['class'] == ans[1]]
            rendering_df_filter = rendering_df_filter[0.5 * ans[0] < rendering_df_filter['area_size']]
            rendering_df_filter = rendering_df_filter[rendering_df_filter['area_size'] < 1.5 * ans[0]]
            rendering_df_filter = rendering_df_filter[rendering_df_filter['space_name'] == key_name]
            if area['type'] == 3:
                rendering_df_bedroom = rendering_df[rendering_df['class'] == ans[1]]
                rendering_df_bedroom = rendering_df_bedroom[0.5 * ans[0] < rendering_df_bedroom['area_size']]
                rendering_df_bedroom = rendering_df_bedroom[rendering_df_bedroom['area_size'] < 1.5 * ans[0]]
                rendering_df_bedroom = rendering_df_bedroom[rendering_df_bedroom['space_name'] == '卧室']
                rendering_df_filter = pd.concat([rendering_df_filter, rendering_df_bedroom], axis=0)

            for index2, _row in rendering_df_filter.iterrows():
                room_result_dict['style'][_row['style_name']].append({
                    'area_size': _row['area_size'],
                    'url': _row['url'],
                    'content_id': _row['content_id'],
                    'city_code': str(int(_row['city_code']))
                })

            l_len = 0

            for _style, _style_info in room_result_dict['style'].items():
                _style_info_tmp = sorted(_style_info, key=lambda x: abs(room_result_dict['area_size'] - x['area_size']))
                # room_result_dict['style'][_style] = url_shuffle(_style_info_tmp)[0:12]
                _style_info_tmp = url_shuffle(_style_info_tmp)
                room_result_dict['style'][_style] = city_shuffle(str(int(row.city_code)), _style_info_tmp)
                l_len = max(l_len, len(_style_info))
                pass

            style_result_all = list()
            for _index in range(l_len):
                for _style, _style_info in room_result_dict['style'].items():
                    if _index >= len(_style_info):
                        continue
                    style_result_all.append(_style_info[_index])
                    pass
            room_result_dict['style']['全部'] = style_result_all

            if key_name not in result_dict:
                result_dict[key_name] = room_result_dict
            elif area_size > result_dict[key_name]['area_size']:
                result_dict[key_name] = room_result_dict
            pass

        return [frame_id, json.dumps(result_dict), row.city_code, 1, '']
    except Exception as e:
        return [row.frame_id, json.dumps(dict()), row.city_code, 0, str(traceback.format_exc())]


class RoomRendering(spark_util_v2.SparkLogic):
    def __init__(self):
        pass

    def logic_func(self, spark_driver, raw_df_dict, **params):
        frame_info = raw_df_dict['frame_info']
        final_data_cols = params['params']['final_data_cols']
        # 业务表筛选昨日计算过的数据
        business_data_done = frame_info.filter('status!=3').select(final_data_cols).distinct()
        # 业务表筛选今日未计算的增量数据
        business_data_undo = frame_info.filter('status=3').distinct()

        result_rdd = business_data_undo.rdd.map(lambda row: find_rendering_case(row, **params['params']))

        if result_rdd.count() == 0:
            business_data_union = business_data_done
            save_dict = {
                "AI_room_rendering": business_data_union
            }
        else:
            eval_content_undo_df = result_rdd.toDF(final_data_cols)
            business_data_union = business_data_done.union(eval_content_undo_df)
            save_dict = {
                "AI_room_rendering": business_data_union
            }

        return save_dict


def main(debug=False, **kwargs):
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    pt_date = kwargs['pt_data']
    cur_date = datetime.datetime.strptime(pt_date, "%Y%m%d")
    pre_date = cur_date - datetime.timedelta(days=1)
    last_pt_date = pre_date.strftime("%Y%m%d")

    # 读取业务配置文件
    f = get_file_stream(kwargs['config_file'])
    conf = yaml.load(f)
    spark_config_key = "room_rendering"
    spark_params = conf.get(spark_config_key, None)

    rendering_df = pd.read_csv('room_rendering_class_drop_duplicates.csv', sep='\t')
    spark_params['logic_params']['logic_function_params']['params']['rendering_df'] = rendering_df

    spark_params["sql_params"]["sql_vars"] = {
        "pt_date": pt_date,
        "last_date": last_pt_date,
        "city_code": kwargs['city_code']
    }
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_class"] = RoomRendering
    # 存储pt
    for save_name in spark_params["save_params"]:
        spark_params["save_params"][save_name]["partition_params"] = {
            "pt": "{}000000".format(pt_date)
        }
    spark_driver = spark_util_v2.SparkSqlDriver(debug=debug, **spark_params)
    spark_driver.run()
    return spark_driver


def case_study(**params):
    rendering_df = pd.read_csv('frame_eval/room_rendering_v2/room_rendering_class_drop_duplicates.csv', sep='\t')
    params['rendering_df'] = rendering_df
    frame_df = pd.read_csv('frame_eval/room_rendering_v2/debug.csv', sep='\t')
    for index, row in frame_df.iterrows():
        res = find_rendering_case(row, **params)
        ydx = json.loads(res[1])
        pass
    pass


if __name__ == '__main__':
    current_pt_date = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y%m%d")

    parser = argparse.ArgumentParser(description='')
    parser.add_argument("-pt_date", default=current_pt_date, help="")
    parser.add_argument("-city_code", default='110000', help="")
    parser.add_argument("-config_file", default="frame_eval/room_rendering_v2/room_rendering.yml", help="")
    args = parser.parse_args()

    if sys.platform not in ["win32", "darwin"]:
        params = {
            'pt_data': args.pt_date,
            'config_file': args.config_file,
            'city_code': args.city_code,
        }
        main(**params)
    else:
        params = dict()
        case_study(**params)
    pass


