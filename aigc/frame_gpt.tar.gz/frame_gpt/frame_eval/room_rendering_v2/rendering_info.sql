SELECT url_info.content_id, img_info.album_case_id, url_info.url, img_info.style, img_info.style_name
	, img_info.color, img_info.color_name, img_info.city_code, img_info.city_name, img_info.space_type
	, img_info.space_name, album_case_info.frame_id, json_info.frame_json
FROM (
	SELECT cid, album_case_id, style, style_name, color
		, color_name, space_type, space_name, city_code, city_name
		, frame_id
	FROM dw.dw_plat_utopia_feed_image_feeds_da
	WHERE pt = '20220802000000'
		AND style != '' and space_type != ''
) img_info
	JOIN (
		SELECT url, content_id
		FROM dw.dw_dec_shj_album_image_da
		WHERE pt = '20220802000000'
	) url_info
	ON img_info.cid = url_info.content_id
	LEFT JOIN (
		SELECT content_id, frame_id
		FROM dw.dw_dec_shj_album_case_da
		WHERE pt = '20220802000000'
	) album_case_info
	ON album_case_info.content_id = img_info.album_case_id
	LEFT JOIN (
		SELECT frame_id
			, reflect('java.net.URLDecoder', 'decode', trim(vector_value), 'UTF-8') AS frame_json
		FROM (
			SELECT mapping.frame_id, vector_value
			FROM (
				SELECT id, vector_value
				FROM dw.dw_house_frame_vector_da
				WHERE pt = '20220703000000'
					AND is_valid = 1
			) vector
				JOIN (
					SELECT image_id, entity_id AS frame_id, ROW_NUMBER() OVER (
                        PARTITION BY entity_id
                        ORDER BY
                            update_time DESC
                    ) AS rn
					FROM dw.dw_house_image_entity_mapping_da
					WHERE pt = '20220703000000'
						AND image_type_code = 110028006
						AND entity_type_code = 110029002
						AND is_valid = 1
				) mapping
				ON mapping.image_id = vector.id
				JOIN (
					SELECT DISTINCT frame_id
					FROM dw.dw_house_house_frame_mapping_da
					WHERE pt = '20220703000000'
						AND is_valid = 1
				) h_m
				ON mapping.frame_id = h_m.frame_id
				where rn =1
		) aaa
	)json_info
	ON json_info.frame_id = album_case_info.frame_id