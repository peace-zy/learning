WITH frame_info AS (
    SELECT frame_id, image_id, vector_value, city_code
    FROM (
        SELECT mapping.entity_id as frame_id, image_id,
            reflect("java.net.URLDecoder", "decode", trim(vector_value), "UTF-8") AS vector_value, city_code,
            ROW_NUMBER() OVER(PARTITION BY mapping.entity_id ORDER BY update_time desc) AS rn
        FROM (
            SELECT id, vector_value, city_code
            FROM dw.dw_house_frame_vector_da
            WHERE pt='{pt_date}000000' AND is_valid=1 AND city_code IN ({city_code})
        ) vector
        JOIN (
            SELECT image_id, entity_id, update_time
            FROM dw.dw_house_image_entity_mapping_da
            WHERE pt='{pt_date}000000' AND image_type_code = 110028006 AND entity_type_code = 110029002 AND is_valid = 1
        ) mapping
        ON mapping.image_id=vector.id
    ) tb
    WHERE tb.rn=1
),
line_img AS (
    SELECT line_table.frame_id, line_table.moving_lines, line_table.visual_areas, line_table.face_vectors,
           line_table.wd_vectors, line_table.movement_areas, line_table.main_img, line_cross.living_guest_cross,
           line_cross.work_guest_cross, line_cross.living_work_cross
    FROM (
        SELECT frame_id, moving_lines, visual_areas, face_vectors, wd_vectors, movement_areas, main_img
        FROM ods.ods_frame_miner_frame_eval_img_inf_da
        WHERE pt = '{pt_date}000000' and status=0
    ) line_table
    JOIN (
        SELECT frame_id, living_guest_cross, work_guest_cross, living_work_cross
        FROM data_mining.data_mining_frame_line_da
        WHERE pt = '{pt_date}000000' and is_valid=1
    ) line_cross ON line_table.frame_id=line_cross.frame_id
)
SELECT frame_info.frame_id AS frame_id,
    frame_info.image_id AS image_id,
    frame_info.vector_value AS vector_value,
    frame_info.city_code AS city_code,
    nvl(line_img.moving_lines, '') AS moving_lines,
    nvl(line_img.visual_areas, '') AS visual_areas,
    nvl(line_img.face_vectors, '') AS face_vectors,
    nvl(line_img.wd_vectors, '') AS wd_vectors,
    nvl(line_img.movement_areas, '') AS movement_areas,
    nvl(line_img.main_img, '') AS main_img,
    line_img.living_guest_cross AS living_guest_cross,
    line_img.work_guest_cross AS work_guest_cross,
    line_img.living_work_cross AS living_work_cross
FROM frame_info
LEFT JOIN line_img ON frame_info.frame_id = line_img.frame_id