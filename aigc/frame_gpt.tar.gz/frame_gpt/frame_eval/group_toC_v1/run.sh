# hdfs 上部署的python环境
HDFS_PYTHON_PATH="hdfs://ns-fed/user/strategy/yudonghai/python.tgz#python"
# 本地python命令, 21.21上的配置
PYTHON_CMD="/home/work/zhucheng011/python/python27/bin/python2"

function frame_eval_groupC_v1() {
    pt_date=$1
    city_code=$2

    spark-submit --py-files lib.zip \
                 --conf spark.dynamicAllocation.maxExecutors=150 \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.pyspark.driver.python=${PYTHON_CMD}\
    frame_eval/group_toC_v1/spark_main.py \
                 -pt_date "${pt_date}" \
                 -city_code "${city_code}" \
                 -config_file frame_eval/group_toC_v1/decoration_conf.yml \
                 -sql_file frame_eval/group_toC_v1/frame_decoration_da.sql
}

function main
{
    if [[ $# -lt 1 ]] ; then
        echo "error! lack <job_name>"
        usage
    fi
    job_name=$1
    echo "TASK: ${job_name}  "

    zip -q -r ./lib.zip ./*

    case ${job_name} in
        frame_eval_groupC_v1 )
        pt_data=$2
        city_code=$3
        frame_eval_groupC_v1 "$pt_data" "$city_code"
        ;;

        * )
        echo "error! invalid <job_name>"
        usage
        ;;

    esac
}

main $*