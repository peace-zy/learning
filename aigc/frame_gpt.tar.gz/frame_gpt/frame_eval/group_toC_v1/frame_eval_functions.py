# -*- coding:utf-8 -*-
# Copyright (c) 2022 www.ke.com, Inc. All Rights Reserved
"""
Author: luyonghui006@ke.com
 Date : 2022/5/19
"""
from __future__ import division
import logging
import yaml
import traceback

import json

from lib import entity
from lib import eval_main
from lib import label_functions
from lib import code_enum as ce
from frame_remould.floorplan import House
from lib.file_util import get_file_stream


def condition_check(key_dict, conditions, condition_conn):
    """
    条件判断
    :param key_dict: dict, 特征字典
    :param conditions: list, 条件列表
    :param condition_conn: str, ['all', 'any'], 条件判断方式
    :return:
    """
    cond_results = []
    for cond in conditions:
        k, comp, target = cond
        if comp == 'notnull':
            cond_results.append(key_dict[k] is not None)
        elif key_dict[k] is None:  # 针对本次配置中存在没有doc_vars的情况，防止出现None<1-->True
            cond_results.append(False)
        elif comp == '<':
            cond_results.append(key_dict[k] < target)
        elif comp == '<=':
            cond_results.append(key_dict[k] <= target)
        elif comp == '>':
            cond_results.append(key_dict[k] > target)
        elif comp == '>=':
            cond_results.append(key_dict[k] >= target)
        elif comp == '==':
            cond_results.append(key_dict[k] == target)
        elif comp == 'true':
            cond_results.append(key_dict[k] is True)
        elif comp == 'false':
            cond_results.append(key_dict[k] is False)
        elif comp == 'in':
            cond_results.append(key_dict[k] in set(target.strip().split(',')))
        else:
            logging.error('unknown operator！')
            return None
    result = None
    if condition_conn == 'all':
        result = all(cond_results)
    elif condition_conn == 'any':
        result = any(cond_results)
    else:
        logging.error('unknown condition connection {}!!'.format(condition_conn))
    return result


def dim_var(doc_vars, space_feature):
    """
    单个检测点文案变量获取
    :param doc_vars: dict, 变量配置
    :param space_feature: dict, 单个分间特征
    :return:
    """
    dim_var_result = {}
    for doc_group in doc_vars:
        for doc_item in doc_group:
            item_cond = doc_item['cond']
            item_cond_conn = doc_item['cond_conn']
            new_vars = doc_item['vars']
            item_flag = condition_check(space_feature, item_cond, item_cond_conn)
            if item_flag is None:  # 条件格式错误
                return None
            if item_flag:
                dim_var_result.update(new_vars)
                break  # 同一组条件下，取第一个判定成功的即可
    return dim_var_result


def space_doc(space_feature, dims_conf):
    """
    单个分间文案生成
    :param space_feature: 单个分间特征
    :param dims_conf: 单个分间类型对应的所有检测点文案配置
    :return:
    """
    space_doc_result = []
    for dim in dims_conf:
        # 注意有变量的地方需要转换为Unicode类型
        dim_name = dim.get('dim_name', '')
        dim_value = dim.get('dim_value', '')
        dim_condition = dim.get('dim_condition', [])
        dim_condition_conn = dim.get('dim_condition_conn', '')
        movement_title = unicode(dim.get('movement_title', u''))
        movement_content = unicode(dim.get('movement_content', u''))
        movement_url = unicode(dim.get('movement_url', u''))
        goods_title = unicode(dim.get('goods_title', u''))
        goods_content = unicode(dim.get('goods_content', u''))
        goods_url = unicode(dim.get('goods_url', u''))
        positive = dim.get('positive', '1')
        group_index = dim.get('group_index', '1')  # 给定默认值，防止后面int转换时报错
        group_order_index = unicode(dim.get('group_order_index', u'1'))  # 给定默认值，防止后面int转换时报错
        main_url = unicode(dim.get('main_url', u''))  # 如果doc_conf.yaml中没有进行配置，则默认为空
        doc_vars = dim.get('doc_vars', [])  # 返回空列表，表示当前检测点对应的文案中没有需要format的变量

        dim_flag = condition_check(space_feature, dim_condition, dim_condition_conn)
        if dim_flag is None:  # 判定条件格式错误
            return None  # 这里为什么要返回None?而不是直接continue。是为了区分条件格式错误和条件不满足这两个情况吗？

        if not dim_flag:  # 条件不满足，不生成对应的文案
            continue

        if not len(doc_vars):  # 文案配置中没有进行doc_vars配置
            full_vars = space_feature
        else:
            dim_var_result = dim_var(doc_vars, space_feature)
            if dim_var_result is None:  # 条件格式错误
                return None
            if not len(dim_var_result):  # 没有找到符合条件的情况，因此跳过后续的文案生成步骤
                continue
            full_vars = dict(space_feature, **dim_var_result)

        # 在这里去掉try/except,让最外围的try/except可以正常捕获到异常
        one_dim_dict = {
            'dim_name': dim_name,
            'dim_value': dim_value,
            'movement_title': movement_title.format(**full_vars),
            'movement_content': movement_content.format(**full_vars),
            'movement_url': movement_url.format(**full_vars),
            'goods_title': goods_title.format(**full_vars),
            'goods_content': goods_content.format(**full_vars),
            'goods_url': goods_url.format(**full_vars),
            'positive': positive,
            'group_index': int(group_index),  # 用于排序，转为int
            'group_order_index': int(group_order_index.format(**full_vars)),  # 用于排序，转为int
            'main_url': main_url.format(**full_vars)
        }
        space_doc_result.append(one_dim_dict)

    # 同一逻辑分组的检测点，每个分组下取order_index最小的那个
    sorted_doc_result = sorted(space_doc_result, key=lambda x: (x['group_index'], x['group_order_index']),
                               reverse=False)  # 从小到大
    space_filtered_doc_result = []
    pre_index = 0
    for sorted_doc in sorted_doc_result:
        if pre_index == sorted_doc['group_index']:
            continue
        else:
            pre_index = sorted_doc['group_index']
            space_filtered_doc_result.append(sorted_doc)

    # 对于整屋，需要优点兜底
    if space_feature.get('label', None) is not None:
        # 首先统计非兜底优点数量
        positive_cnt = 0
        valid_index = []  # 兜底优点index
        for idx, filtered_doc in enumerate(space_filtered_doc_result):
            # 这里是通过指定兜底优点的group_index来实现，如果修改了兜底优点，需要更新这里的index!!!
            if filtered_doc['positive'] == '1' and filtered_doc['group_index'] < 6:
                positive_cnt += 1
            if filtered_doc['group_index'] == 6:
                valid_index.append(idx)
        # 如果非兜底优点数量大于1，则去掉兜底优点
        if positive_cnt > 1:
            for idx in sorted(valid_index, reverse=True):  # 从后往前删除
                space_filtered_doc_result.pop(idx)

    # group_index和group_order_index格式转换为str
    for doc_result in space_filtered_doc_result:
        doc_result['group_index'] = str(doc_result['group_index'])
        doc_result['group_order_index'] = str(doc_result['group_order_index'])

    return space_filtered_doc_result


def spaces_doc(spaces_feature, space_conf):
    """
    单个分间类型文案生成
    :param spaces_feature: dict, 单个分间类型对应的特征
    :param space_conf: dict, 单个分间类型对应的
    :return:
    """
    dims_conf = space_conf['dims']

    if not len(spaces_feature):  # 当前分间类型下没有对应的特征数据
        return None

    # 默认所有分间类型都取面积最大的那个分间用于生成对应分间类型的文案
    space_feature = sorted(spaces_feature, key=lambda x: x["area_size"])[-1]
    space_doc_result = space_doc(space_feature, dims_conf)

    return space_doc_result


def doc_format(feature_dict, conf_params):
    """
    文案生成
    :param feature_dict: dict, 所有分间的特征
    :param conf_params: dict, 所有文案配置
    :return:
    """
    room_type_order_lst = conf_params['room_type_order']
    spaces_conf_dict = conf_params['spaces']

    doc_result = {}
    for room_type in room_type_order_lst:
        spaces_feature = feature_dict.get(room_type, [])  # 多个相同类型的分间特征
        space_conf = spaces_conf_dict.get(room_type, {})  # 单个分间类型对应的文案配置
        if not space_conf:  # 如果文案配置没有对应分间类型，则直接跳过
            continue
        spaces_doc_result = spaces_doc(spaces_feature, space_conf)
        if spaces_doc_result is None:  # 如果没有对应分间类型的特征，结果中就不会有对应分间文案
            continue

        doc_result[room_type] = spaces_doc_result
    if not doc_result:
        return None
    return doc_result


def judge_good_active_line(row):
    """
    东线合理判断逻辑
    :param row: Row/dict, 户型数据
    :return: bool
    """
    try:
        living_guest_cross_cnt = 0 if row['living_guest_cross'] == '0' else len(row['living_guest_cross'].split('_'))
        work_guest_cross_cnt = 0 if row['work_guest_cross'] == '0' else len(row['work_guest_cross'].split('_'))
        living_work_cross_cnt = 0 if row['living_work_cross'] == '0' else len(row['living_work_cross'].split('_'))
        line_cross_cnt = work_guest_cross_cnt + living_work_cross_cnt + living_guest_cross_cnt
    except Exception as e:  # 如果出现异常，则直接返回False
        return False
    if line_cross_cnt < 3:
        return True
    return False


def generate_groupC_content(row, **params):
    """
    :param row: str/Row/dict, 户型数据, (str格式时各个字段用逗号分隔，且需要跟Frame类内各字段顺序一致)
    :param params: dict, 配置参数
    :return:
    """
    frame = entity.Frame(row)

    try:
        frame_vector = frame.vector
        house = House()
        house.set_json_str(json.dumps(frame_vector))
        frame.set_house(house)
        house.run()

        # 标签
        frame.add_label(label_functions.label_base, **params['label_params'])
        # 检测点
        eval_main.bigC_explain(frame, **params)
        # 特征
        feature_dict = frame.explain_message.get('feature_dict', {})

        # 更新动线合理标签
        feature_dict['whole'][0]['good_active_line'] = judge_good_active_line(row)

        # 把动线图、动静分区图、面宽进深图补充到整屋分间特征
        feature_dict['whole'][0]['main_url'] = row['main_img'] if len(row['main_img']) > 0 else ""
        feature_dict['whole'][0]['moving_lines'] = row['moving_lines'] if len(row['moving_lines']) > 0 else ""
        feature_dict['whole'][0]['movement_areas'] = row['movement_areas'] if len(row['movement_areas']) > 0 else ""
        feature_dict['whole'][0]['wd_vectors'] = row['wd_vectors'] if len(row['wd_vectors']) > 0 else ""

        # 结果整理
        decoration_sug = doc_format(feature_dict, params['docs'])
        docs = dict({
            'frame_id': str(frame.frame_id),
            # 'project_name': row.resblock_name,  # 一个frame_id会对应多个楼盘名称
            'room_count': str(frame.room),
            'parlour_count': str(frame.parlour),
            'frame_size': '%.1f' % frame.frame_size,
            # 'frame_url': row.frame_url,
            'frame_label': str(frame.frame_label),
            'decoration_sug': decoration_sug
        })
        docs_str = json.dumps(docs, encoding="utf-8")

        base_feature = frame.base_feature()
        result_vector = [base_feature[idx] for idx in [0, 2]] + [docs_str, '1', '']
        result = [str(x) for x in result_vector]
    except Exception as e:
        error_str = str(traceback.format_exc())
        logging.error('{} get decoration feature exception!!\t{}'.format(frame.frame_id, str(e)))
        frame._state = ce.State.unknown_exception
        base_feature = frame.base_feature()
        result_vector = [base_feature[idx] for idx in [0, 2]] + ['', '0', error_str]
        result = [str(x) for x in result_vector]

    return result


def case_study():
    # # 本地加载数据
    import pandas as pd
    # df = pd.read_csv(r'D:\PycharmProjects\frame_miner\decoration.tsv', dtype=str, header=0, sep='\t')
    # data_list = df.values.tolist()[0]
    # row = {
    #     'city_code': data_list[0],
    #     'frame_id': data_list[1],
    #     'image_id': data_list[2],
    #     'vector_value': data_list[3].decode('utf-8'),
    # }
    # # 从S3上下载户型矢量
    from utils import get_frame_vector
    frame_id = '18000000513509'
    frame_vector_str = get_frame_vector(frame_id)
    row = {
        'city_code': '110000',
        'frame_id': frame_id,
        'image_id': '888',
        'vector_value': frame_vector_str,
        'main_img': '',
        'moving_lines': '',
        'movement_areas': '',
        'wd_vectors': ''
    }

    # 加载配置
    conf_file = get_file_stream('frame_eval/group_toC_v1/decoration_conf.yml')
    conf = yaml.load(conf_file, Loader=yaml.FullLoader)
    doc_conf_file = get_file_stream('frame_eval/group_toC_v1/doc_conf.yaml')
    doc_conf = yaml.load(doc_conf_file, Loader=yaml.FullLoader)
    conf.update(doc_conf)

    generate_groupC_content(row, **conf)

    # # 批量测试
    # df = pd.read_csv(r'D:\PycharmProjects\frame_miner\outs_33.txt', dtype=str, header=None, sep='\t',
    #                  names=['frame_id', 'image_id', 'vector_value', 'city_code', 'moving_lines', 'visual_areas',
    #                         'face_vectors', 'wd_vectors', 'movement_areas', 'main_img', 'living_guest_cross',
    #                         'work_guest_cross', 'living_work_cross'])
    # for idx, row in df.iterrows():
    #     generate_groupC_content(row, **conf)


if __name__ == '__main__':
    case_study()

    # 获取分间对应检测点
    # doc_conf_file = get_file_stream('frame_eval/group_toC_v1/doc_conf.yaml')
    # doc_conf = yaml.load(doc_conf_file, Loader=yaml.FullLoader)
    #
    # dim_result = []
    # room_order = doc_conf['docs']['room_type_order']
    # for space_name in room_order:
    #     print space_name
    #     space_content = doc_conf['docs']['spaces'][space_name]
    #     cur_result = dict({
    #         "name": space_content['name'],
    #         "value": space_name,
    #         "dims": []
    #     })
    #     for dim in space_content["dims"]:
    #         cur_result["dims"].append(dict({
    #             dim["dim_name"]: dim["dim_value"]
    #         }))
    #
    #     dim_result.append(cur_result)
    # print dim_result
    # json_text = json.dumps(dim_result, encoding="utf-8", ensure_ascii=True)
    #
    # # out = open("space_dims.json", mode="w+")
    # # out.write(json_text)
    # # out.close()
