# -*- coding:utf-8 -*-
# Copyright (c) 2022 www.ke.com, Inc. All Rights Reserved
"""
Author: luyonghui006@ke.com
 Date : 2022/5/19
"""
import csv
import random
import yaml
import json
import pandas as pd


if __name__ == '__main__':
    df = pd.read_excel(r'D:\PycharmProjects\PlanGen-zh\data\dataset\sample_1000_good.xlsx', header=0)
    df = df[['resblock_name', 'label', 'desc']]
    df = df.loc[range(100)]

    mock_data = dict({
        'frame_id': [],
        'city_code': [],
        'docs': [],
        'status': [],
        'error_msg': []
    })

    docs_json = dict({
        'frame_id': '',
        'project_name': '',
        'room_count': '',
        'parlour_count': '',
        'frame_size': '',
        'frame_label': '',
        'frame_url': '',
        'decoration_sug': ''
    })

    decoration_sug_json = dict({
        'whole': {
            'north_south_dis': {
                'dim_name': '南北通透',
                'movement_title': '',
                'movement_content': '',
                'goods_title': '',
                'goods_content': '',
                'goods_url': ''
            }
        }
    })

    conf = yaml.load(open('./doc_conf.yaml', mode='r'), Loader=yaml.FullLoader)
    spaces = conf['docs']['spaces']

    for _ in range(10):
        project_idx = random.randint(0, 9)
        project_name = df.loc[project_idx].values[0]

        frame_id = '11000000' + '%06d' % random.randint(1000, 999999)
        city_code = '%06d' % random.randint(100, 999999)
        doc = dict({
            'frame_id': frame_id,
            'project_name': project_name,
            'room_count': str(random.randint(0, 5)),
            'parlour_count': str(random.randint(0, 3)),
            'frame_size': str(random.randint(50, 150)),
            'frame_label': str((0b1 << random.randint(1, 31)) | (0b1 << random.randint(1, 31))),
            'frame_url': 'http://storage.lianjia.com/hdic-frame/' + str(random.randint(50000, 200000))
        })

        # 按道理每个分间都会有结果
        sug_dict = dict()
        for space in spaces:
            sug_dict[space] = []
            for dim in spaces[space]['dims']:
                if random.random() < 0.5:
                    continue
                positive_value = '1'
                if space == "whole":
                    if random.random() < 0.5:
                        positive_value = '0'
                content_idx = random.randint(0, 99)
                contents = df.loc[content_idx].values
                sentence = contents[1]
                sug_dict[space].append({
                        'dim_name': dim.get('dim_name', ''),
                        'dim_value': dim.get('dim_value', ''),
                        'movement_title': sentence,
                        'movement_content': sentence,
                        'movement_url': 'http://storage.lianjia.com/hdic-frame/' + str(random.randint(50000, 200000)),
                        'goods_title': sentence,
                        'goods_content': sentence,
                        'goods_url': 'http://storage.lianjia.com/hdic-frame/' + str(random.randint(50000, 200000)),
                        'positive': positive_value,
                        'group_index': str(random.randint(0, 15)),
                        'group_order_index': str(random.randint(0, 3))
                    })

        doc.update({
            'decoration_sug': sug_dict
        })

        doc_str = json.dumps(doc)

        mock_data['frame_id'].append(frame_id)
        mock_data['city_code'].append(city_code)
        mock_data['docs'].append(json.dumps(doc))
        mock_data['status'].append(u'1')
        mock_data['error_msg'].append(u'')

    out_df = pd.DataFrame(mock_data)
    out_df.to_csv('./mock_data.csv', sep='\t', header=False, index=False, encoding='utf-8',
                  quoting=csv.QUOTE_NONE,  # 去除多余的引号
                  columns=['frame_id', 'city_code', 'docs', 'status', 'error_msg'])  # 指定保存结果中列的顺序
