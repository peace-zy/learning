# !/bin/env python3
# -*- coding:utf-8 -*-
# Copyright (c) 2022 www.ke.com, Inc. All Rights Reserved
"""
Author: luyonghui006@ke.com
 Date : 2022/5/19
"""
import boto3


def get_s3_client():
    S3_AK = '223HG43LGIX9W3MWTOCL'
    S3_AKS = 'tqWXh8kSyxM/QfgF34dMXFJcRrIIGfIIZkVVjSMH'
    s3_client = boto3.client('s3', region_name='cn-north-1', endpoint_url='http://storage.lianjia.com',
                             aws_access_key_id=S3_AK,
                             aws_secret_access_key=S3_AKS)
    return s3_client


def get_frame_vector(frame_id):
    frame_id = str(frame_id)
    s3_client = get_s3_client()
    vector_response = s3_client.get_object(Bucket='frame-eval-image', Key=str(frame_id) + '.json')
    frame_json = vector_response['Body'].read().decode('utf-8')
    return frame_json


if __name__ == '__main__':
    pass
