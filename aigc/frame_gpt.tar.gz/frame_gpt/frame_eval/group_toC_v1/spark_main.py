# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/5/17 17:16
# ===================================
import sys
import yaml
import logging
import datetime
import argparse

from lib import spark_util_v2
from lib.file_util import get_file_stream
import frame_eval.frame_tag_lib.utils as tag_utils

from frame_eval.group_toC_v1.frame_eval_functions import generate_groupC_content


class FrameEvalGroupC(spark_util_v2.SparkLogic):
    def logic_func(self, spark_driver, raw_df_dict, **params):
        frame_vector_info = raw_df_dict['frame_vector_info']
        content_info = frame_vector_info.rdd.map(lambda row: generate_groupC_content(row, **params))
        spark_driver.rdd_2_df(content_info).toDF(*params['params']['eval_content_names'])
        save_dict = {
            "frame_eval_content": content_info
        }
        return save_dict


def main(debug=False, **kwargs):
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    pt_date = kwargs['pt_data']

    # 读取业务配置文件
    f = get_file_stream(kwargs['config_file'])
    conf = yaml.load(f)
    spark_config_key = "frame_eval_groupC"
    spark_params = conf.get(spark_config_key, None)

    conf_param_tmp = dict()
    tag_utils.collect_conf_on_spark(r"frame_eval/group_toC_v1/decoration_conf.yml", conf_param_tmp)
    spark_params['logic_params']['logic_function_params']['params'].update(conf_param_tmp)

    doc_info = dict()
    tag_utils.collect_conf_on_spark(r"frame_eval/group_toC_v1/doc_conf.yaml", doc_info)
    spark_params['logic_params']['logic_function_params'].update(doc_info)

    spark_params["sql_params"]["sql_vars"] = {
        "pt_date": pt_date,
        "city_code": kwargs['city_code']
    }
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_class"] = FrameEvalGroupC
    # 存储pt
    for save_name in spark_params["save_params"]:
        spark_params["save_params"][save_name]["partition_params"] = {
            "pt": "{}000000".format(pt_date)
        }
    spark_driver = spark_util_v2.SparkSqlDriver(debug=debug, **spark_params)
    spark_driver.run()
    return spark_driver


if __name__ == '__main__':
    current_pt_date = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y%m%d")

    parser = argparse.ArgumentParser(description='')
    parser.add_argument("-pt_date", default=current_pt_date, help="")
    parser.add_argument("-city_code", default='110000', help="")
    parser.add_argument("-config_file", default="frame_eval/group_toC_v1/decoration_conf.yml", help="")
    parser.add_argument("-sql_file", default="frame_eval/group_toC_v1/frame_decoration_da.sql", help="")
    args = parser.parse_args()

    if sys.platform not in ["win32", "darwin"]:
        params = {
            'pt_data': args.pt_date,
            'config_file': args.config_file,
            'sql_file': args.sql_file,
            'city_code': args.city_code,
        }
        main(**params)
    else:
        pass
    pass
