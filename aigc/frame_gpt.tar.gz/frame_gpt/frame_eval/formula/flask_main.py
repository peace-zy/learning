# coding=utf-8
import requests
import json
import os
import sys
import yaml

from flask import Flask
from flask import request

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../"))
sys.path.insert(0, os.getcwd())

import frame_eval.decoration_v2.decoration_spark as decoration_spark
import frame_eval.test.local_deco_test as local_deco_test
from lib import code_enum as ce

sceneId = "decoration_floorplan_2"
formula_url = "http://utopia-formula.beta4app.cto.test.ke.com/api/formula/v1/scene/strategy/query"
CONFIG_TEMP = "frame_eval/formula/decoration_conf_temp.yml"
CONFIG_FILE = "frame_eval/formula/decoration_conf_test.yml"
ROOMTYPE_SCENEID = {
    "main_room": "floorplan_interpretation_2_main_room",
    "main_toilet": "floorplan_interpretation_2_main_toilet",
    "sub_room": "floorplan_interpretation_2_sub_room",
    "kitchen": "floorplan_interpretation_2_kitchen",
    # "toilet": "floorplan_interpretation_2_toilet",
    "hallway": "floorplan_interpretation_2_hallway",
    "parlour_toilet": "floorplan_interpretation_2_parlour_toilet",
    "dinning_room": "floorplan_interpretation_2_dinning_room",
}
app = Flask(__name__)


def after_request(resp):
    resp.headers['Access-Control-Allow-Origin'] = '*'
    return resp


def get_formula_res():
    # params = {"sceneId": sceneId}
    # res = requests.get(formula_url, params=params)
    # deco_dict = json.loads(res.content)["data"]["sceneStrategyList"]

    deco_conf = dict()
    for k, v in ROOMTYPE_SCENEID.items():
        params = {"sceneId": v}
        res = requests.get(formula_url, params=params)
        deco_conf[k] = json.loads(res.content)["data"]["sceneStrategyList"]

    return deco_conf


def deco_resultmd_string(result):
    frame_id = result[0]
    # img_path = "http"
    img_path = local_deco_test.get_img_url(frame_id)
    frame_label = json.loads(result[11])
    lines = []
    for room, label in frame_label.items():
        title0 = " ".join(["#", label['space_name'].encode('utf8')])
        lines.append(title0)
        lines.append('\n')

        img_md = ''.join(['![avatar](', img_path, ') \n'])
        lines.append(img_md)

        for doc in label['doc']:
            for dim in doc['dims']:
                title1 = " ".join(['###', 'title:', dim['title'].encode('utf8'), '\n\n'])
                lines.append(title1)
                annotation = ' '.join(['-', 'annotation:', dim['annotation'].encode('utf8'), '\n'])
                lines.append(annotation)
                detail = ' '.join(['-', 'detail:', dim['detail'].encode('utf8'), '\n'])
                lines.append(detail)
                merit = ' '.join(['-', 'merit:', dim['merit'].encode('utf8'), '\n'])
                lines.append(merit)
                merit = ' '.join(['-', 'display:', dim['display'].encode('utf8'), '\n'])
                lines.append(merit)
    res = ''.join(lines)
    return res


def update_conf_old(conf, formula_res):
    def update_conf_2(conf, cond_dict):
        for rm_type in conf['dec_conf']['spaces']:
            for dim in conf['dec_conf']['spaces'][rm_type]['dims']:
                if dim['dim_name'] != cond_dict['dim_name']:
                    continue
                for vars in dim['doc_vars'][0]:
                    if if_var_condition_hit(vars, cond_dict):
                        vars['merit_doc'] = cond_dict['output']
                        vars['merit'] = cond_dict['merit']
                        vars['display'] = cond_dict['display']
                        break

    def if_var_condition_hit(vars, cond_dict):
        """判断vars中的condition是否对应配置"""
        const_split = ["dim_name", "merit", "display", "output"]
        for idx, c in enumerate(vars['cond']):
            if cond_dict.get(c[0]) is None:
                return False
            if cond_dict.get(c[0])[1] != c[1]:
                return False
            vars['cond'][idx] = (c[0], c[1], cond_dict[c[0]][2])
            return True

    for condition in formula_res:
        formulaContent = condition['formulaContent'].encode('utf8')
        cond_dict = split_formulaContent(formulaContent)
        cond_dict['output'] = formula_res[0]['output']
        update_conf_2(conf, cond_dict)


def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        pass

    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except (TypeError, ValueError):
        pass

    return False


def update_conf(conf, formula_res):
    def if_var_condition_hit(doc_var, content_dict):
        """判断doc_var中的content_dict是否对应配置"""
        for idx, c in enumerate(doc_var['cond']):
            if content_dict.get(c[0]) is None:
                return False
            if content_dict.get(c[0])[1] != c[1]:
                return False
            if is_number(content_dict[c[0]][2]):
                n = float(content_dict[c[0]][2])
                doc_var['cond'][idx] = (c[0], c[1], n)
            return True

    def update_room_type_conf(rm_conf, condiction):
        for c in condiction:
            desc = c['formulaDesc']
            output = c['output']
            content = c['formulaContent']
            desc_dict = split_formulaContent(desc)
            content_dict = split_formulaContent(content)

            for dim in rm_conf['dims']:
                if dim['dim_name'] != desc_dict['dim_name']:
                    continue
                for doc_var in dim['doc_vars'][0]:
                    if_hit = if_var_condition_hit(doc_var, content_dict)
                    if if_hit:
                        doc_var['vars']['merit_doc'] = output
                        doc_var['vars']['merit'] = float(desc_dict['merit'])
                        doc_var['vars']['display'] = float(desc_dict['display'])


    space_conf = conf['dec_conf']['spaces']
    for room_type, fml_v in formula_res.items():
        rm_conf = space_conf[room_type]
        update_room_type_conf(rm_conf, fml_v)


def split_formulaContent(formulaContent):
    res_dict = dict()
    all_split = ["==", ">", "<", ">=", "<=", "!=", "(in)"]
    const_split = ["dim_name", "merit", "display"]
    for condtion in formulaContent.split("&&"):
        for sp in all_split:
            if sp not in condtion:
                continue
            kvs = condtion.split(sp)
            if kvs[0] in const_split:
                res_dict[kvs[0]] = kvs[1]
            else:
                if sp[0] == "(" and sp[-1] == ")":
                    sp = sp[1:-1]
                res_dict[kvs[0]] = (kvs[0], sp, kvs[1])
    return res_dict


@app.route("/decoration_interpretation", methods=['GET', 'POST'])
def decoration_interpretation():
    try:
        frame_vector = request.form.get('vectorValue').encode('utf8')
        frame_id = str(request.form.get('frame_id'))
        if frame_id != '':
            s3_client = local_deco_test.get_s3_client()
            vector_response = s3_client.get_object(Bucket='frame-eval-image', Key=str(frame_id) + '.json')
            frame_vector = vector_response['Body'].read()

        conf = local_deco_test.collect_conf_single(CONFIG_FILE)
        line = "\t".join([frame_id, 'image_id', frame_vector, 'city_code'])
        frame, result = decoration_spark.frame_decoration_feature(line, debug=True, **conf)
        if frame.state != ce.State.valid:
            raise Exception("户型异常, 请检查户型, 如入户门设置等......")
        md = deco_resultmd_string(result)

        res = {"decorationInterpretation": md}
    except Exception as error:
        res = {"error": error.message}
    return res


@app.route("/frame_vector", methods=['GET', 'POST'])
def frame_vector():
    try:
        frame_id = request.form.get('frame_id')
        s3_client = local_deco_test.get_s3_client()
        vector_response = s3_client.get_object(Bucket='frame-eval-image', Key=str(frame_id) + '.json')
        vector_str = vector_response['Body'].read()
        vector_dict = json.loads(vector_str)
        for fp in vector_dict['floorplans']:
            if fp.get('items') is not None:
                fp['items'] = []

        res = {'frame_vector': json.dumps(vector_dict)}
    except Exception as error:
        if hasattr(error, 'message'):
            res = {"error": error.message}
        else:
            res = {"error": "Unkonw error"}
    return res


@app.route("/update_config", methods=["GET", "POST"])
def update_config():
    formula_res = get_formula_res()
    conf = local_deco_test.collect_conf_single(CONFIG_TEMP)
    update_conf(conf, formula_res)
    with open(CONFIG_FILE, "w") as f:
        yaml.dump(conf, f, encoding='utf-8', allow_unicode=True)
    return {"code": "ok"}


if __name__ == "__main__":
    # #
    # formula_res = get_formula_res()
    #
    # conf = local_deco_test.collect_conf_single(CONFIG_TEMP)
    # import copy
    # conf2 = copy.deepcopy(conf)
    # update_conf(conf2, formula_res)
    # with open("frame_eval/formula/decoration_conf_test.yml", "w") as f:
    #     yaml.dump(conf2, f, encoding='utf-8', allow_unicode=True)
    #
    # #
    # frame_id = str(11000013003179)
    # s3_client = local_deco_test.get_s3_client()
    # vector_response = s3_client.get_object(Bucket='frame-eval-image', Key=str(frame_id) + '.json')
    # frame_vector = vector_response['Body'].read()
    #
    # conf = local_deco_test.collect_conf_single(CONFIG_FILE)
    # line = "\t".join([frame_id, 'image_id', frame_vector, 'city_code'])
    # frame, result = decoration_spark.frame_decoration_feature(line, debug=True, **conf)
    # md = deco_resultmd_string(result)
    # with open(r"D:\a.md", "w") as f:
    #     f.writelines(md)
    # tmp = 0

    app.after_request(after_request)
    app.run(host='0.0.0.0', port=8881)
