# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/6/20 14:23
# ===================================
from __future__ import division

import json
import sys

import math
import yaml
import logging
import datetime
import argparse
import traceback
import pandas as pd
from collections import defaultdict

from lib import spark_util_v2
from lib.file_util import get_file_stream
from frame_eval.room_rendering.function_tools import RoomCombine, judge_room_class, url_shuffle
from frame_eval.room_rendering.function_tools import area_convert, convert_name


def find_rendering_case(row, **params):
    try:
        rendering_df = params['rendering_df']
        frame_id = str(int(row.frame_id))
        frame_json = row.frame_json
        frame_dict = json.loads(frame_json)
        result_dict = dict()

        max_bedroom_area = 0
        for area in frame_dict['floorplans'][0]['areas']:
            if area['type'] != 3:
                continue
            S = area_convert(area['size'])
            max_bedroom_area = max(max_bedroom_area, S)

        for area in frame_dict['floorplans'][0]['areas']:
            key_name = convert_name(area['type'])
            if key_name == 'undefined':
                continue
            S = area_convert(area['size'])
            if area['type'] == 3 and S != max_bedroom_area:
                key_name = '次卧'
            if area['type'] == 3 and S == max_bedroom_area:
                key_name = '主卧'

            room_result_dict = dict()
            room_result_dict['room_name'] = key_name
            area_size = area_convert(area['size'])
            room_result_dict['area_size'] = area_size
            room_result_dict['style'] = defaultdict(list)

            ans = judge_room_class(area['id'], frame_json)
            rendering_df_filter = rendering_df[rendering_df['class'] == ans[1]]
            rendering_df_filter = rendering_df_filter[0.7 * ans[0] < rendering_df_filter['area_size']]
            rendering_df_filter = rendering_df_filter[rendering_df_filter['area_size'] < 1.3 * ans[0]]
            rendering_df_filter = rendering_df_filter[rendering_df_filter['space_name'] == key_name]
            if area['type'] == 3:
                rendering_df_bedroom = rendering_df[rendering_df['class'] == ans[1]]
                rendering_df_bedroom = rendering_df_bedroom[0.7 * ans[0] < rendering_df_bedroom['area_size']]
                rendering_df_bedroom = rendering_df_bedroom[rendering_df_bedroom['area_size'] < 1.3 * ans[0]]
                rendering_df_bedroom = rendering_df_bedroom[rendering_df_bedroom['space_name'] == '卧室']
                rendering_df_filter = pd.concat([rendering_df_filter, rendering_df_bedroom], axis=0)

            for index2, _row in rendering_df_filter.iterrows():
                room_result_dict['style'][_row['style_name']].append({
                    'area_size': _row['area_size'],
                    'beauty': _row['beauty'],
                    'clarity': _row['clarity'],
                    'url': _row['url'],
                    'content_id': _row['content_id']
                })

            for _style, _style_info in room_result_dict['style'].items():
                _style_info_tmp = sorted(_style_info, key=lambda x: abs(room_result_dict['area_size'] - x['area_size']))
                room_result_dict['style'][_style] = url_shuffle(_style_info_tmp)[0:12]
                pass
            if key_name not in result_dict:
                result_dict[key_name] = room_result_dict
            elif area_size > result_dict[key_name]['area_size']:
                result_dict[key_name] = room_result_dict
            pass

        return [frame_id, json.dumps(result_dict), row.city_code, 1, '']
    except Exception as e:
        return [row.frame_id, json.dumps(dict()), row.city_code, 0, str(traceback.format_exc())]


class RoomRendering(spark_util_v2.SparkLogic):
    def __init__(self):
        pass

    def logic_func(self, spark_driver, raw_df_dict, **params):
        frame_info = raw_df_dict['frame_info']
        result_rdd = frame_info.rdd.map(lambda row: find_rendering_case(row, **params['params']))
        result_df = spark_driver.rdd_2_df(result_rdd).toDF(*params['params']['final_data_cols'])

        save_dict = {
            "AI_room_rendering": result_df
        }
        return save_dict


def main(debug=False, **kwargs):
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    pt_date = kwargs['pt_data']

    # 读取业务配置文件
    f = get_file_stream(kwargs['config_file'])
    conf = yaml.load(f)
    spark_config_key = "room_rendering"
    spark_params = conf.get(spark_config_key, None)

    rendering_df = pd.read_csv('room_rendering_class.csv', sep='\t')
    spark_params['logic_params']['logic_function_params']['params']['rendering_df'] = rendering_df

    spark_params["sql_params"]["sql_vars"] = {
        "pt_date": pt_date,
        "city_code": kwargs['city_code']
    }
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_class"] = RoomRendering
    # 存储pt
    for save_name in spark_params["save_params"]:
        spark_params["save_params"][save_name]["partition_params"] = {
            "pt": "{}000000".format(pt_date)
        }
    spark_driver = spark_util_v2.SparkSqlDriver(debug=debug, **spark_params)
    spark_driver.run()
    return spark_driver


if __name__ == '__main__':
    current_pt_date = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y%m%d")

    parser = argparse.ArgumentParser(description='')
    parser.add_argument("-pt_date", default=current_pt_date, help="")
    parser.add_argument("-city_code", default='110000', help="")
    parser.add_argument("-config_file", default="frame_eval/room_rendering/room_rendering.yml", help="")
    args = parser.parse_args()

    if sys.platform not in ["win32", "darwin"]:
        params = {
            'pt_data': args.pt_date,
            'config_file': args.config_file,
            'city_code': args.city_code,
        }
        main(**params)
    else:
        params = {
            'pt_data': args.pt_date,
            'config_file': args.config_file,
            'city_code': args.city_code,
        }
        main(**params)
    pass


