# hdfs 上部署的python环境
HDFS_PYTHON_PATH2="hdfs://ns-fed/user/strategy/zhuc/python27.zip#python"
# 本地python命令, 21.21上的配置
PYTHON_CMD="/home/work/zhucheng011/python/python27/bin/python2"
source bin/utils.sh

function room_rendering() {
    pt_date=$1
    city_code=$2

    spark-submit --py-files lib.zip \
                 --executor-memory 10G \
                 --conf spark.dynamicAllocation.maxExecutors=150 \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH2} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.pyspark.driver.python=${PYTHON_CMD} \
    frame_eval/room_rendering/spark_main.py \
                 -pt_date "${pt_date}" \
                 -city_code "${city_code}" \
                 -config_file frame_eval/room_rendering/room_rendering.yml
}

function main
{
    if [[ $# -lt 1 ]] ; then
        echo "error! lack <job_name>"
        usage
    fi
    job_name=$1
    echo "TASK: ${job_name}  "

    zip -q -r ./lib.zip ./*

    case ${job_name} in
        room_rendering )
        pt_data=$2
        city_code=$3
        room_rendering "$pt_data" "$city_code"
        ;;

        * )

        echo "error! invalid <job_name>"
        usage
        ;;

    esac
}

main $*
