SELECT DISTINCT frame_id, reflect('java.net.URLDecoder', 'decode', trim(vector_value), 'UTF-8') AS frame_json, city_code
FROM (
    SELECT mapping.frame_id, vector_value, h_m.city_code
    FROM (
        SELECT id, vector_value
        FROM dw.dw_house_frame_vector_da
        WHERE pt = '{pt_date}000000'
            AND is_valid = 1
    ) vector
        JOIN (
            SELECT image_id, entity_id AS frame_id, ROW_NUMBER() OVER (
                PARTITION BY entity_id
                ORDER BY
                    update_time DESC
            ) AS rn
            FROM dw.dw_house_image_entity_mapping_da
            WHERE pt = '{pt_date}000000'
                AND image_type_code = 110028006
                AND entity_type_code = 110029002
                AND is_valid = 1
        ) mapping
        ON mapping.image_id = vector.id
        JOIN (
            SELECT DISTINCT frame_id, city_code
            FROM dw.dw_house_house_frame_mapping_da
            WHERE pt = '{pt_date}000000'
                AND is_valid = 1
                AND city_code IN ({city_code})
        ) h_m
        ON mapping.frame_id = h_m.frame_id
        where rn =1
) aaa
