WITH style_space_map AS (
		SELECT cid, album_case_id, style, style_name, space_type
			, space_name
		FROM dw.dw_plat_utopia_feed_image_feeds_da
		WHERE pt = '20220703000000'
	),
	frame_map AS (
		SELECT content_id, frame_id
		FROM dw.dw_dec_shj_album_case_da
		WHERE pt = '20220703000000'
			AND frame_id != 0
	),
	url_data AS (
		SELECT content_id, album_case_id, url, is_des_img, beauty
			, clarity, furniture_quantity
		FROM data_mining.data_mining_room_deco_renderings
		WHERE pt = '20220703000000'
			AND is_des_img = 1
			AND (beauty = 2
				OR beauty = 3)
			AND (clarity = 2
				OR clarity = 3)
			AND (furniture_quantity != '0'
				AND furniture_quantity != '1')
	),
	v_frame AS (
		SELECT frame_id
			, reflect('java.net.URLDecoder', 'decode', trim(vector_value), 'UTF-8') AS json_str
		FROM (
			SELECT mapping.frame_id, vector_value
			FROM (
				SELECT id, vector_value
				FROM dw.dw_house_frame_vector_da
				WHERE pt = '20220703000000'
					AND is_valid = 1
			) vector
				JOIN (
					SELECT image_id, entity_id AS frame_id, ROW_NUMBER() OVER (
                        PARTITION BY entity_id
                        ORDER BY
                            update_time DESC
                    ) AS rn
					FROM dw.dw_house_image_entity_mapping_da
					WHERE pt = '20220703000000'
						AND image_type_code = 110028006
						AND entity_type_code = 110029002
						AND is_valid = 1
				) mapping
				ON mapping.image_id = vector.id
				JOIN (
					SELECT DISTINCT frame_id
					FROM dw.dw_house_house_frame_mapping_da
					WHERE pt = '20220703000000'
						AND is_valid = 1
				) h_m
				ON mapping.frame_id = h_m.frame_id
				where rn =1
		) aaa
	)
SELECT url_data.content_id, frame_map.frame_id, style_space_map.space_type, style_space_map.space_name, style_space_map.style,style_space_map.style_name, url_data.beauty, url_data.clarity, url_data.url, v_frame.json_str
FROM url_data
	LEFT JOIN frame_map ON url_data.album_case_id = frame_map.content_id
	LEFT JOIN style_space_map ON url_data.content_id = style_space_map.cid
	LEFT JOIN v_frame ON frame_map.frame_id = v_frame.frame_id
WHERE frame_map.frame_id IS NOT NULL
	AND style_space_map.space_type IS NOT NULL
	AND style_space_map.style != ''
	AND v_frame.json_str is not NULL