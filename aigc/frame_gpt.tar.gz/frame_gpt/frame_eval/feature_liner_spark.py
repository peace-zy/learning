#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2018 www.ke.com, Inc. All Rights Reserved
"""
户型解析——动线、可视域特征（全量）
Authors: yudonghai@ke.com
Date:    2019/06/27
"""
from __future__ import division
import logging
import yaml
import sys
import datetime
import gc

import json

import __init__
from lib import entity
from lib import spark_util
from lib import code_enum as ce
from lib import eval_main


def frame_analysis(row, debug=False, **params):
    """
    动线、可视域分析
    :param row: str/Row/dict, 户型数据
            (str格式时各个字段用逗号分隔，且需要跟Frame类内各字段顺序一致)
    :param debug: boolean, 调试模式
    :param params: dict, 参数
    :return:
    """
    frame = entity.Frame(row)
    
    eval_main.liner_explain(frame, **params)

    head_info = [
        frame.frame_id,
        frame.image_id,
        frame.city_code,
        frame.room,
        frame.parlour,
        frame.kitchen,
        frame.toilet,
        frame.plan_cnt
    ]
    
    # print(frame.frame_id)
    visual_liner_idx = None
    for i in range(len(frame.explain_message[ce.EXPLAIN_VISUAL])):
        if frame.explain_message[ce.EXPLAIN_VISUAL][i]:
            visual_liner_idx = i

    visual_areas = []
    va_raw = {}
    if visual_liner_idx is not None:
        va_raw = frame.explain_message[ce.EXPLAIN_VISUAL][visual_liner_idx].get("pts_polygon_o", {})
    for xi, yi in va_raw:
        visual_areas.append(va_raw[(xi, yi)])

    info_dict = {
        ce.EXPLAIN_POINT_VALUE_DICT: frame.explain_message[ce.EXPLAIN_POINT_VALUE_DICT],
        ce.EXPLAIN_VARS: {"visual_areas": visual_areas, "visual_liner_idx": visual_liner_idx}
    }

    ret_dict = frame.explain_message[ce.EXPLAIN_LINER][visual_liner_idx] if visual_liner_idx is not None else {}
    edge_len = frame.explain_message[ce.EXPLAIN_VISUAL][visual_liner_idx].get("edge_len", None) if visual_liner_idx is not None else None
    area_ratio_o = frame.explain_message[ce.EXPLAIN_VISUAL][visual_liner_idx].get("area_ratio_o", None) if visual_liner_idx is not None else None

    if ret_dict is None:
        ret_dict = {}
    result = head_info + [edge_len, frame.frame_size] + [
        ret_dict.get("guest_len", 0),
        ret_dict.get("living_len", 0),
        ret_dict.get("work_len", 0),
        ret_dict.get("guest_lines", "{}"),
        ret_dict.get("living_lines", "{}"),
        ret_dict.get("work_lines", "{}"),
        ret_dict.get("living_guest_cross", ""),
        ret_dict.get("work_guest_cross", ""),
        ret_dict.get("living_work_cross", ""),
        frame.state.value,
        1 if frame.state == ce.State.valid else 0,
        datetime.date.today().strftime("%Y%m%d"),
        area_ratio_o,
        json.dumps(info_dict, encoding="utf-8")
    ]

    result = [str(x) for x in result]
    if debug:
        return frame, result
    return result


def logic_func(driver, raw_df, **params):
    """
     spark 逻辑处理
    :param driver: spark_util.SparkSqlDriver, spark 执行类
    :param raw_df: pyspark.sql.dataframe.DataFrame， sql 查询结果
    :param params: dict, 参数字典
    :return: result_df, 处理后的 DataFrame
    """
    result_rdd = raw_df.rdd.map(lambda row: frame_analysis(row, **params))
    result_df = driver.rdd_2_df(result_rdd)
    names = params["table_names"]
    result_df = result_df.toDF(*names)
    return result_df


def main():
    """ 主函数 """
    if len(sys.argv) < 4:
        logging.error("no less than 3 arguments!")
        sys.exit()

    pt_date = sys.argv[1]
    config_file = sys.argv[2]
    city_code = sys.argv[3]

    with open(config_file, "r") as config_data:
        conf = yaml.load(config_data)

    # 从配置文件读取参数
    spark_config_key = "frame_eval_line_config"
    spark_params = conf.get(spark_config_key, None)
    if spark_params is None:
        logging.error("lack {} in config file".format(spark_config_key))
        sys.exit(1)

    # ## 补充参数
    # pt
    spark_params["sql_params"]["pt_date"] = pt_date
    spark_params["sql_params"]["city_code"] = city_code
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_function"] = logic_func
    # 存储pt
    spark_params["save_params"]["partition_params"] = {"pt": "{}000000".format(pt_date)}

    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()


if __name__ == "__main__":

    logging.basicConfig(level=logging.WARN, format='%(asctime)s %(levelname)s %(message)s')

    main()
