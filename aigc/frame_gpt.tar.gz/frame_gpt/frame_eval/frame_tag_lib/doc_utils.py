# coding=utf-8
import logging

import frame_eval.frame_tag_lib.utils as utils


def doc_format(features, doc_conf, one_room_doc_func):
    """
    生成文案模块
    features: 各个功能区的特征字典
    doc_conf: 配置文案
    """
    room_type_lst = doc_conf["room_type_order"]
    exp_dict = doc_conf["explain"]

    final_doc = dict()
    for room_type in room_type_lst:
        room_feature_list = features.get(room_type)
        room_exp_dict = exp_dict.get(room_type)

        if room_feature_list is None:
            continue
        docs = get_room_doc(room_feature_list, room_exp_dict, one_room_doc_func)
        # 后处理
        doc_list = list()
        for d in docs['doc']:
            dim_dict = {"area_id": d['area_id']}
            for dim in d['dims']:
                dim_dict[dim['dim_name']] = dict()
                for k, v in dim.items():
                    if k == 'dim_name' or k == 'room_type_name':
                        continue
                    dim_dict[dim['dim_name']][k] = v
            doc_list.append(dim_dict)
        final_doc[room_type] = doc_list
    return final_doc


def get_room_doc(room_feature_list, room_exp_dict, one_room_doc_func):
    room_type_name = room_exp_dict["name"]
    room_type = room_exp_dict["type"]
    room_range = room_exp_dict["range"]
    dims_conf = room_exp_dict["dims"]

    # if not key_vars_lst:
    #     return None
    room_feature_list2 = room_feature_list
    if room_range == "max":
        room_feature_list2 = [sorted(room_feature_list, key=lambda x: x["area_size"])[-1]]

    room_doc_list = []
    for room_fea in room_feature_list2:
        room_doc = one_room_doc_func(room_fea, dims_conf)
        for d in room_doc:
            d.update({'room_type_name': room_type_name})
        room_doc_list.append({
            "dims": room_doc,
            "area_id": room_fea.get("area_id"),
        })
    return {
        "room_type_name": room_type_name,
        "room_type": room_type,
        "doc": room_doc_list,
    }


def condition_check(key_dict, conditions, condition_conn):
    cond_results = []
    for cond in conditions:
        k, comp, target = cond
        if utils.is_number(target):
            target = float(target)
        value = key_dict.get(k)
        if utils.is_number(value):
            value = float(value)
        if comp == "notnull":
            cond_results.append(value is not None)
        elif comp == "<":
            cond_results.append(value < target)
        elif comp == "<=":
            cond_results.append(value <= target)
        elif comp == ">":
            cond_results.append(value > target)
        elif comp == ">=":
            cond_results.append(value >= target)
        elif comp == "==":
            cond_results.append(value == target)
        elif comp == "!=":
            cond_results.append(value != target)
        elif comp == "true":
            cond_results.append(value is True)
        elif comp == "false":
            cond_results.append(value is False)
        elif comp == "in":
            cond_results.append(value in set(target.strip().split(",")))
        else:
            logging.error("unknown operator！")
            return None
    result = None
    if condition_conn == "all":
        result = all(cond_results)
    elif condition_conn == "any":
        result = any(cond_results)
    else:
        logging.error("unknown condition connection {}!!".format(condition_conn))
    return result


# def one_room_doc(room_fea, dims_conf):
#     one_room_doc = []
#     for dim in dims_conf:
#         dim_name = dim.get("dim_name", None)
#         dim_condition = dim.get("dim_condition", [])
#         dim_condition_conn = dim.get("dim_condition_conn", "")
#         simple_explain = unicode(dim.get("simple_explain", u""))
#         detailed_explain = unicode(dim.get("detailed_explain", u""))
#         annotation = unicode(dim.get("annotation", u""))
#         module = unicode(dim.get("module", u""))
#         enum = unicode(dim.get("enum", u""))
#         level = unicode(dim.get("level", u""))
#         display_item = unicode(dim.get("display_item", u""))
#         display_sub_item = unicode(dim.get("display_sub_item", u""))
#         doc_vars = dim.get("doc_vars", [])
#
#         # 删除None值的key
#         # for k, v in room_fea.items():
#         #     if v is None:
#         #         room_fea.pop(k)
#
#         dim_flag = condition_check(room_fea, dim_condition, dim_condition_conn)
#         if dim_flag is None:
#             return None
#         if not dim_flag:
#             continue
#
#         dim_result = doc_group_getter(doc_vars, room_fea)
#         if not dim_result:
#             continue
#         if dim_result is None:
#             return None
#         full_vars = dict(room_fea, **dim_result)
#         # 格式化str到unicode
#         for k, v in full_vars.items():
#             if isinstance(v, str):
#                 v1 = unicode(v, 'utf-8')
#                 full_vars[k] = v1
#
#         one_room_doc.append({
#             "dim_name": dim_name,
#             "simple_explain": simple_explain.format(**full_vars),
#             "detailed_explain": detailed_explain.format(**full_vars),
#             "module": module.format(**full_vars),
#             "enum": enum.format(**full_vars),
#             "level": level.format(**full_vars),
#             "display_item": display_item.format(**full_vars),
#             "display_sub_item": display_sub_item.format(**full_vars),
#             "annotation": annotation.format(**full_vars),
#         })
#     return one_room_doc


def doc_group_getter(doc_vars, room_keys):
    new_result = {}
    for doc_group in doc_vars:
        for doc_item in doc_group:
            item_cond = doc_item["cond"]
            item_cond_conn = doc_item["cond_conn"]
            new_vars = doc_item["vars"]
            item_flag = condition_check(room_keys, item_cond, item_cond_conn)
            if item_flag is None:
                return None
            if item_flag:
                new_result.update(new_vars)
                break
    return new_result
