# coding=utf-8
import sys
import os
import json
import logging
import yaml
import datetime
import pkg_resources
from lib.file_util import get_file_stream

if sys.platform in ["win32", "darwin"]:
    os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../"))
    sys.path.insert(0, os.getcwd())

from lib import spark_util
import frame_eval.frame_tag_lib.utils as utils



def get_result(frame_id, frame):
    """后处理结果"""
    result = []
    result.append(frame_id)
    if isinstance(frame, Exception):
        result.append('')  # feature
        result.append('')  # city_code
        result.append(str(frame))
    else:
        error = ''
        features = frame.explain_message['frame_tag_feature']
        result.append(json.dumps(features, cls=utils.NpEncoder))
        result.append(frame.city_code)
        result.append(error)
    return result


def update_basic2frame(row, frame):
    """其它表或者渠道更新最终结果的函数"""
    pass


def frame_feature_propressor(row, **params):
    frame, result = utils.get_whole_frame_info(
        row, params["explain_params"], get_result, update_basic2frame)
    return result


def logic_func(driver, raw_df, **params):
    """
    result_rdd = raw_df.rdd.map(lambda row: frame_feature_propressor(row, **params))
    result_df = driver.rdd_2_df(result_rdd)
    names = params["table_names"]
    result_df = result_df.toDF(*names)
    """
    # 筛选已经有特征的数据
    raw_df_done = raw_df.filter("feature NOT LIKE 'none'").persist()
    # 筛选上一天没有的增量数据并计算
    result_rdd = raw_df.filter("feature LIKE 'none'").repartition(300).rdd.map(lambda row: frame_feature_propressor(row, **params))
    names = params["table_names"]
    # 增量与存量合并
    result_df = result_rdd.toDF(names)
    raw_df_union = raw_df_done.select(names).union(result_df)
    return raw_df_union


def main():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    # if len(sys.argv) < 3:
    #     logging.error("no less than 2 arguments!")
    #     sys.exit()

    pt_date = sys.argv[2]
    config_file = sys.argv[1]
    city_code = sys.argv[3]

    f = get_file_stream(config_file)
    conf = yaml.load(f)

    # get_module_res = lambda *res: pkg_resources.resource_stream(
    #     'frame_eval.frame_tag_lib', os.path.join(*res))
    # f = get_module_res(config_file)
    # conf = yaml.load(f)

    # with open(config_file, "r") as config_data:
    #     conf = yaml.load(config_data)
    # with open("frame_eval/frame_tag_lib/doc.yml", "r") as config_data:
    #     conf.update(yaml.load(config_data))
    #     conf["explain_params"]["doc"] = conf["doc"]
    # 从配置文件读取参数
    spark_config_key = "frame_tag_config"
    spark_params = conf.get(spark_config_key, None)
    if spark_params is None:
        logging.error("lack {} in config file".format(spark_config_key))
        sys.exit(-1)
    # ## 补充参数
    # pt
    spark_params["sql_params"]["pt_date"] = pt_date

    # 计算上一天的日期
    cur_date = datetime.datetime.strptime(pt_date, "%Y%m%d")
    pre_date = cur_date - datetime.timedelta(days=1)
    last_pt_date = pre_date.strftime("%Y%m%d")
    spark_params["sql_params"]["last_pt_date"] = last_pt_date

    # 从外部传入城市代码
    spark_params["sql_params"]["city_code"] = city_code

    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_function"] = logic_func
    # 存储pt
    spark_params["save_params"]["partition_params"] = {"pt": "{}000000".format(pt_date)}

    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()


def case_study(frame):
    frame_id, line = utils.get_frame_vector(frame)
    conf = dict()
    utils.collect_conf(r"frame_eval/frame_tag_lib/conf.yml", conf)
    # utils.collect_conf(r"frame_eval/newhouse_v2/doc.yml", conf)
    # conf["explain_params"]["doc"] = conf["doc"]

    frame, result = utils.get_whole_frame_info(
        line, conf["explain_params"], get_result, update_basic2frame)

    features = result[1]
    if features != "":
        features = json.loads(result[1])

    return features, result


if __name__ == "__main__":

    if sys.platform not in ["win32", "darwin"]:
        main()
    else:
        frame_id = 11000004283443
        # frame_id = 1620052383711275 # 动线ERROR
        case_study(frame_id)