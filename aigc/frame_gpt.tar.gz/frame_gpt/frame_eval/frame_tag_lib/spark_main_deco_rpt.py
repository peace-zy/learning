# coding=utf-8
import sys
import logging
import yaml
import json
import os

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../"))
sys.path.insert(0, os.getcwd())

import frame_eval.frame_tag_lib.spark_main_feature as spark_main_feature
import frame_eval.frame_tag_lib.utils as utils
import frame_eval.frame_tag_lib.doc_utils as doc_utils
# import frame_eval.frame_tag_lib.spark_util as spark_util
from lib import spark_util
from lib.file_util import get_file_stream


def logic_func(driver, raw_df, **params):
    result_rdd = raw_df.rdd.map(lambda row: get_result(row, **params))
    result_df = driver.rdd_2_df(result_rdd)
    names = params["table_names"]
    result_df = result_df.toDF(*names)
    return result_df


def main():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    if len(sys.argv) < 3:
        logging.error("no less than 2 arguments!")
        sys.exit()

    pt_date = sys.argv[2]
    config_file = sys.argv[1]
    last_input_pt_data = pt_date
    if len(sys.argv) > 3:
        last_input_pt_data = sys.argv[3]

    f = get_file_stream(config_file)
    conf = yaml.load(f)

    # with open(config_file, "r") as config_data:
    #     conf = yaml.load(config_data)
    # 从配置文件读取参数
    spark_config_key = "frame_tag_config"
    spark_params = conf.get(spark_config_key, None)
    # spark_params["logic_params"]["logic_function_params"]["doc"] = conf["doc"]
    if spark_params is None:
        logging.error("lack {} in config file".format(spark_config_key))
        sys.exit(-1)
    # ## 补充参数
    # pt
    spark_params["sql_params"]["pt_date"] = last_input_pt_data
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_function"] = logic_func
    # 存储pt
    spark_params["save_params"]["partition_params"] = {"pt": "{}000000".format(pt_date)}

    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()


def get_result(row, **doc_conf):
    result = []
    doc_conf = doc_conf['doc']
    result.append(row['frame_id'])
    if row['error'] != '':
        result.append('')
    else:
        features = json.loads(row['feature'])
        docs = doc_utils.doc_format(features, doc_conf, one_room_doc)
        result.append(json.dumps(docs))
    result.append(row['city_code'])
    result.append(row['error'])
    return result


def one_room_doc(room_fea, dims_conf):
    one_room_doc = []
    for dim in dims_conf:
        dim_name = dim.get("dim_name", None)
        dim_condition = dim.get("dim_condition", [])
        dim_condition_conn = dim.get("dim_condition_conn", "")
        # 这里添加新字段
        enum_lev1 = unicode(dim.get("enum_lev1", u""))
        enum_lev2 = unicode(dim.get("enum_lev2", u""))
        enum_lev3 = unicode(dim.get("enum_lev3", u""))
        doc_vars = dim.get("doc_vars", [])

        # 删除None值的key
        # for k, v in room_fea.items():
        #     if v is None:
        #         room_fea.pop(k)

        dim_flag = doc_utils.condition_check(room_fea, dim_condition, dim_condition_conn)
        if dim_flag is None:
            return None
        if not dim_flag:
            continue

        dim_result = doc_utils.doc_group_getter(doc_vars, room_fea)
        if not dim_result:
            continue
        if dim_result is None:
            return None
        full_vars = dict(room_fea, **dim_result)
        # 格式化str到unicode
        for k, v in full_vars.items():
            if isinstance(v, str):
                v1 = unicode(v, 'utf-8')
                full_vars[k] = v1

        one_room_doc.append({
            "dim_name": dim_name,
            "enum_lev1": enum_lev1.format(**full_vars),
            "enum_lev2": enum_lev2.format(**full_vars),
            "enum_lev3": enum_lev3.format(**full_vars),
        })
    return one_room_doc


def case_study(frame_id):
    features, study_result = spark_main_feature.case_study(frame_id)
    conf = dict()
    utils.collect_conf(r"frame_eval/frame_tag_lib/doc.yml", conf)

    row = {
        "frame_id": study_result[0],
        "feature": study_result[1],
        "city_code": study_result[2],
        "error": study_result[3]
    }
    res = get_result(row, **conf)
    if res[1] != '':
        doc = json.loads(res[1])
        features = json.loads(study_result[1])
    else:
        doc = dict()
        features = dict()
    return doc, features


if __name__ == "__main__":
    if sys.platform not in ["win32", "darwin"]:
        main()
    else:
        # sys.argv.append("frame_eval/frame_tag_lib/doc.yml")
        # sys.argv.append("20210505")
        # main()

        # frame_id = 11000005873079
        # frame_id = 2120052369071309
        # frame_id = r'D:\frame.json'
        # case_study(frame_id)

        import pandas as pd
        df = pd.read_csv(r'D:\frameid.csv')
        frame_id_list = []
        width_list, depth_list, with_cloakroom_list = [], [], []
        with_balcony_list, with_toilet_list = [], []
        enum_lev1_list, enum_lev2_list, enum_lev3_list = [], [], []
        for idx, row in df.iterrows():
            print(idx)
            frame_id = row['frame_id']
            doc, features = case_study(frame_id)
            width, depth, with_cloakroom, with_balcony, with_toilet = 0, 0, -1, -1, -1
            if features.get('main_room') is not None:
                width = features.get('main_room')[0].get('width')
                depth = features.get('main_room')[0].get('depth')
                with_balcony = features.get('main_room')[0].get('with_balcony')
                with_cloakroom = features.get('main_room')[0].get('with_cloakroom')
                with_toilet = features.get('main_room')[0].get('with_toilet')
            enum_lev1, enum_lev2, enum_lev3 = '-1', '-1', '-1'
            if doc.get('main_room_width_depth') is not None:
                enum_lev1 = doc.get('main_room_width_depth')['enum_lev1']
                enum_lev2 = doc.get('main_room_width_depth')['enum_lev2']
                enum_lev3 = doc.get('main_room_width_depth')['enum_lev3']
            frame_id_list.append(frame_id)
            enum_lev1_list.append(enum_lev1)
            enum_lev2_list.append(enum_lev2)
            enum_lev3_list.append(enum_lev3)
            width_list.append(width)
            depth_list.append(depth)
            with_cloakroom_list.append(with_cloakroom)
            with_balcony_list.append(with_balcony)
            with_toilet_list.append(with_toilet)

        df1 = pd.DataFrame({
            "frame_id": frame_id_list,
            "enum_lev1": enum_lev1_list,
            "enum_lev2": enum_lev2_list,
            "enum_lev3": enum_lev3_list,
            "width": width_list,
            "depth": depth_list,
            "with_cloakroom": with_cloakroom_list,
            "with_balcony": with_balcony_list,
            "with_toilet": with_toilet_list,
        })
        df1.to_csv(r'D:\main_room_frame_tag.csv')
        tmp = 0
