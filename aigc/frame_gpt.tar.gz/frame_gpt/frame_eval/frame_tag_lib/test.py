# coding=utf-8
import json
import os.path

import pandas as pd
import math
from PIL import Image
from io import BytesIO
import requests

import numpy as np
import frame_eval.frame_tag_lib.utils as utils

import web_server.api_lib as api_lib

def get_sql_in_str(file_path, column):
    """输入csv, 打印、输出sql in 的语句"""
    df = pd.read_csv(file_path)
    frame_ids = df[column]
    res = '('
    for k, v in frame_ids.iteritems():
        if not utils.is_number(v):
            continue
        if math.isnan(v):
            continue
        f = str(long(v))
        res = res + f + ','
    res = res[0:-1] + ')'
    print(res)

    file_write_obj = open(r'D:\sql.csv', 'w')
    file_write_obj.writelines(res)
    return res


def get_full_eval(frame_id):
    frame_id = str(frame_id)
    FRAME_EVAL_ARTICLE_URL = 'http://i.data.api.lianjia.com/v2/meta/frame_eval_full'
    BIG_DATA_KEY = "frame_analysis"
    BIG_DATA_SECRET = "c338b06a92d4400edcbf11c03979241a"
    records = api_lib.request_bigdata_api(FRAME_EVAL_ARTICLE_URL, {"frame_id": frame_id},
                                          BIG_DATA_KEY, BIG_DATA_SECRET)
    return records


def get_wd_img(records):
    article = json.loads(records['data'][0]['article'])
    width_depth = article['space'][3]
    wd_img_url = width_depth[2][0]
    main_url = article['main_img']

    response = requests.get(wd_img_url).content
    wd_image = Image.open(BytesIO(response))
    response = requests.get(main_url).content
    main_image = Image.open(BytesIO(response))

    img = Image.blend(wd_image, main_image, 0.6)

    return img


def test0():
    df = pd.read_csv(r'D:\\a.csv')
    frame_ids = df['frame_id']
    for k, v in frame_ids.iteritems():
        print(k)
        try:
            records = get_full_eval(v)
            img = get_wd_img(records)
            path = os.path.join(r'D:\tmp\a', str(v) + '.png')
            img.save(path)
        except Exception as e:
            print(e)
            print(v)


if __name__ == '__main__':

    test0()

    # file_path = r'D:\a.csv'
    # column = 'frame_id'
    #
    # get_sql_in_str(file_path, column)