WITH vector_city AS (
		SELECT id, vector_value, city_code, ROW_NUMBER() OVER (PARTITION BY city_code ORDER BY RAND()) AS city_rn
		FROM dw.dw_house_frame_vector_da
		WHERE pt = '{pt_date}000000'
			AND is_valid = 1
			AND city_code IN ({city_code})
	), 
	vector AS (
		SELECT id, vector_value, city_code
		FROM vector_city
	), 
	mapping AS (
		SELECT image_id, entity_id, update_time
		FROM dw.dw_house_image_entity_mapping_da
		WHERE pt = '{pt_date}000000'
			AND image_type_code = 110028006
			AND entity_type_code = 110029002
			AND is_valid = 1
	), 
	tb AS (
		SELECT mapping.entity_id AS frame_id, image_id
			, reflect('java.net.URLDecoder', 'decode', trim(vector_value), 'UTF-8') AS vector_value
			, city_code, ROW_NUMBER() OVER (PARTITION BY mapping.entity_id ORDER BY update_time DESC) AS rn
		FROM vector
			JOIN mapping ON mapping.image_id = vector.id
	), 
	last_feature AS (
		SELECT frame_id, feature, city_code, error
		FROM data_mining.data_mining_frame_tag_lib_da
		WHERE pt = '{last_pt_date}000000'
	)
SELECT
    DISTINCT today_feature.frame_id AS frame_id,
             today_feature.image_id AS image_id,
             today_feature.vector_value AS vector_value,
             today_feature.city_code AS city_code,
             nvl(last_feature.feature, 'none') AS feature,
             last_feature.error AS error
FROM (
	SELECT frame_id, image_id, vector_value, city_code
	FROM tb
	WHERE tb.rn = 1
) today_feature
	LEFT JOIN last_feature ON last_feature.frame_id = today_feature.frame_id