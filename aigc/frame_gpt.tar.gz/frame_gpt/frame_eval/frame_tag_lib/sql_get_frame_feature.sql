SELECT frame_id, feature, city_code, error
FROM
    (SELECT
      frame_id
      ,feature
      ,city_code
      ,error
      ,ROW_NUMBER() OVER (PARTITION BY city_code ORDER BY RAND()) AS city_rn
    FROM data_mining.data_mining_frame_tag_lib_da
    WHERE pt='{pt_date}000000'
--     AND city_code in ('110000', '510100')
    ) feature_table
-- WHERE city_rn < 5000