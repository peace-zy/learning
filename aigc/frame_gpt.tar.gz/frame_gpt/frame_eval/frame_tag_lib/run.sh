# hdfs 上部署的python环境
HDFS_PYTHON_PATH="hdfs://ns-fed/user/strategy/yudonghai/python.tgz#python"

# 本地python命令, 21.21上的配置
PYTHON_CMD="/home/work/zhucheng011/python/python27/bin/python2"

function frame_tag_lib() {
    pt_date=$1

    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.pyspark.driver.python=${PYTHON_CMD} \
    frame_eval/frame_tag_lib/spark_main_feature.py frame_eval/frame_tag_lib/conf.yml "$pt_date"

#    spark-submit --py-files lib.zip \
#    --conf spark.dynamicAllocation.maxExecutors=200 \
#    --master yarn \
#    --deploy-mode cluster \
#    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
#    --conf spark.pyspark.python="python/bin/python" \
#    frame_eval/frame_tag_lib/spark_main_feature.py frame_eval/frame_tag_lib/conf.yml "$pt_date"
}

function get_nearst_pt() {
  # 得到离今天最近的一个pt
  table=$1
  partition="set hive.cli.print.header=flase;
    show partitions $table;"
  LAST_PT=$(hive -S -e  "$partition" | sort | tail -n 1|cut -d= -f 2)
  echo "${LAST_PT:0:8}"
  # $? 返回上一个输出结果
  return $?
}

function rpt_frame_tag_lib() {
    last_pt=$(get_nearst_pt data_mining.data_mining_frame_tag_lib_da)
    pt_date=$1

    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.pyspark.driver.python="python2.7" \
    frame_eval/frame_tag_lib/spark_main_deco_rpt.py frame_eval/frame_tag_lib/doc.yml "$pt_date" "$last_pt"
}

function usage {
    echo "usage:"
    echo "bash frame_miner.sh <job_name> [job_params...]"
    echo "  <job_name>:"
    echo "      frame_tag_lib"
    echo "  [job_params...]:"
    echo "      params for job if necessary"
    exit 1
}

function main
{

    if [[ $# -lt 1 ]] ; then
        echo "error! lack <job_name>"
        usage
    fi
    job_name=$1
    echo "TASK: ${job_name}  "

    zip -q -r ./lib.zip ./*

    case ${job_name} in
        frame_tag_lib )
        pt_data=$2
        frame_tag_lib "$pt_data"
        ;;

        rpt_frame_tag_lib )
        pt_data=$2
        rpt_frame_tag_lib "$pt_data"
        ;;

        * )
        echo "error! invalid <job_name>"
        usage
        ;;
    esac
}

main $*
