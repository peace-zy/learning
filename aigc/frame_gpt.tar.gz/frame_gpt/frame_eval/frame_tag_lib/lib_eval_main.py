# coding=utf-8
import logging
import collections
from operator import itemgetter
import numpy as np

from lib import comm_lib
import lib.eval_main as eval_main
import lib.eval_general as eval_general
import lib.eval_single as eval_single
import lib.eval_global as eval_global
from lib import code_enum as ce
from lib import room_contour_lib
from lib.eval_main import dinning_kitchen_distance, get_toilet_parlour_dis
from frame_remould.geometry.polygon import Polygon

NEW_FEATURE_FIELD = 'frame_tag_feature'
KIT_TOI_FIELD = 'cluster_features'  # 聚类库中的定制特征，暂时只有厨卫


def get_every_room_features(frame, **kwargs):
    fea_dict0 = {
        "shi": frame.room_cnt[0],
        "ting": frame.room_cnt[1],
        "chu": frame.room_cnt[2],
        "wei": frame.room_cnt[3],
        "total_area_size": frame.frame_size,
    }
    message = frame.explain_message
    frame_vector = frame.vector

    cluster_features = room_contour_lib.get_room_cluster_feature(frame.frame_id, frame_vector,
                                                                 kwargs['class_conf'])
    frame.explain_message[KIT_TOI_FIELD] = cluster_features

    frame_tag_dict = collections.defaultdict(list)
    for plan_idx, plan_vector in enumerate(frame_vector[frame.plan_key]):
        points_dict, line_items_dict, lines_dict, areas_dict = itemgetter(*ce.DICTS)(plan_vector)
        area_inf_dict, main_room_id, sub_rooms, _, _, _, _, _, _ = message[ce.EXPLAIN_WHOLE_FRAME]
        main_room_connected_id = frame.house.get_connect_areas4area_id(main_room_id)
        room_type_kwargs = {
            "area_dict": areas_dict,
            "main_room": main_room_id,
            "main_room_connected_id": main_room_connected_id,
        }
        for area_id in areas_dict:
            _, area_points, room_type_id, detail_type, area_size = itemgetter(*ce.IPTTS)(areas_dict[area_id])
            # 功能区面积
            size_without_line = areas_dict[area_id].get("sizeWithoutLine", None)
            norm_area_size = area_size if size_without_line is None else size_without_line
            norm_area_size = None if norm_area_size is None else norm_area_size / 1000000.
            # 面宽进深
            wd_info = message.get(ce.EXPLAIN_WIDTH_DEPTH, {}).get(area_id, None)
            if wd_info is None or wd_info[1] is None or wd_info[2] is None:
                width = None
                depth = None
            else:
                width = round(wd_info[1] / 1000. - 0.12, 2)
                depth = round(wd_info[2] / 1000. - 0.12, 2)
            # 朝向
            face = message.get(ce.EXPLAIN_FACE, {}).get(area_id, [None])[0]
            # face_south = False
            # if 'south' in face:
            #     face_south = True
            # 窗地比
            window_door = message.get(ce.EXPLAIN_WINDOW_DOOR, {}).get(area_id, None)
            if window_door is None:
                wdf = None
                convex = None
            else:
                wdf = window_door[1]
                convex = window_door[4]
            features = {
                "area_id": area_id,
                "area_size": round(norm_area_size, 2),
                "width": width,
                "depth": depth,
                "face": face,
                "wdf": wdf,
                "convex": convex,
            }
            features.update(fea_dict0)
            room_type_kwargs["area_id"] = area_id
            room_key = get_room_type(room_type_id, frame, **room_type_kwargs)
            feas = get_room_type_specific_features(room_key, area_id, frame, plan_idx)
            features.update(feas)
            frame_tag_dict[room_key].append(features)
    hallway_fea = get_hallway_decoration_dict(frame)
    if hallway_fea is not None:
        frame_tag_dict['hallway'] = [hallway_fea]
    frame.explain_message[NEW_FEATURE_FIELD].update(frame_tag_dict)


def get_hallway_decoration_dict(frame):
    if frame.house.res_dict.get('hallway') is not None and \
         frame.house.res_dict.get('hallway'):
        res_dict = frame.house.res_dict['hallway'][0]
    else:
        return None
    fea_dict0 = {
        "shi": frame.room_cnt[0],
        "ting": frame.room_cnt[1],
        "chu": frame.room_cnt[2],
        "wei": frame.room_cnt[3],
        "total_area_size": frame.frame_size,
    }

    area_size = res_dict['space_analysis']['width'] / 1000. * res_dict['space_analysis']['depth'] / 1000
    hallway_fea = {
        "area_size": area_size,
        "width": res_dict['space_analysis']['width'] / 1000.,
        "depth": res_dict['space_analysis']['depth'] / 1000.,
        "right_label": res_dict['space_analysis']['right_label'],
        "left_label": res_dict['space_analysis']['left_label'],
        "left_dis": res_dict['space_analysis']['left_dis'],
        "right_dis": res_dict['space_analysis']['right_dis'],
    }
    # TODO: 门厅左右距离必须加入
    hallway_fea.update(fea_dict0)
    return hallway_fea


def get_room_type_specific_features(room_key, area_id, frame, plan_idx):
    """根据不同功能区、分间得到或者升级特有特征"""
    if room_key == ce.DecorationAreaType.main_room.value:
        return get_main_room_features(area_id, frame)
    if room_key == ce.DecorationAreaType.sub_room.value:
        return get_room_features(area_id, frame)
    if room_key == ce.DecorationAreaType.kitchen.value:
        return get_kitchen_features(area_id, frame, plan_idx)
    if room_key == ce.DecorationAreaType.parlour_toilet.value:
        return get_parlour_toilet_features(area_id, frame, plan_idx)
    if room_key == ce.DecorationAreaType.main_toilet.value:
        return get_main_toilet_features(area_id, frame, plan_idx)
    if room_key == ce.DecorationAreaType.parlour.value:
        return get_parlour_features(area_id, frame, plan_idx)
    return {}


def get_parlour_features(area_id, frame, plan_idx):
    frame_label = frame.explain_message[ce.EXPLAIN_FRAME]
    with_dining = True if (frame_label & ce.FramePLabel.with_dining_room) else False

    plan_vector = frame.vector[frame.plan_key][plan_idx]
    points_dict, line_items_dict, lines_dict, areas_dict = itemgetter(*ce.DICTS)(plan_vector)
    _, area_points, room_type_id, detail_type, area_size = itemgetter(*ce.IPTTS)(areas_dict[area_id])
    living_area = 0
    for living in frame.house.res_dict['livingroom']:
        contours = living['space_analysis']['contours']
        poly = Polygon(*[p for p in contours])
        living_area = poly.area
    max_rec_ratio = np.fabs(living_area) * 1. / area_size

    message = frame.explain_message
    explain_parlour = message.get(ce.EXPLAIN_PARLOUR, {})
    with_balcony = explain_parlour.get(area_id, {}).get(ce.WITH_BALCONY, False)
    parlour_dict = {
        "with_dining": with_dining,
        "max_rec_ratio": max_rec_ratio,
        "with_balcony": with_balcony,
    }
    return parlour_dict


def get_parlour_toilet_features(area_id, frame, plan_idx):
    toilet_dict = get_toilet_features(area_id, frame, plan_idx)
    return toilet_dict


def get_main_toilet_features(area_id, frame, plan_idx):
    toilet_dict = get_toilet_features(area_id, frame, plan_idx)
    return toilet_dict


def get_toilet_features(area_id, frame, plan_idx):
    message = frame.explain_message
    explain_toilet = message.get(ce.EXPLAIN_TOILET, {})
    room_name, room_label, face_entrance_dis, face_kitchen_dis, face_room_dis = explain_toilet.get(
        area_id, ["", 0])
    if face_entrance_dis == float('inf'):
        face_entrance_dis = 999999.
    else:
        face_entrance_dis = face_entrance_dis / 1000

    if face_kitchen_dis == float('inf'):
        face_kitchen_dis = 999999.
    else:
        face_kitchen_dis = face_kitchen_dis

    if face_room_dis == float('inf'):
        face_room_dis = 999999.
    else:
        face_room_dis = face_room_dis
    parlour_dis = get_toilet_parlour_dis(frame, plan_idx, area_id)
    toilet_dict = {
        "face_entrance_dis": face_entrance_dis,
        "face_kitchen_dis": face_kitchen_dis,
        "parlour_dis": parlour_dis,
        "face_room_dis": face_room_dis,
    }

    cluster_dict = dict()
    cluster_fea = frame.explain_message[KIT_TOI_FIELD].get(ce.AreaType.toilet.value, [{}])
    for f in cluster_fea:
        if area_id == f['area_id']:
            cluster_dict['cluster_main_width_label'] = f.get('main_width_label', None)
            cluster_dict['cluster_main_deep_label'] = f.get('main_deep_label', None)
            cluster_dict['cluster_door_at_side'] = f.get('door_at_side', None)
            cluster_dict['cluster_has_side_800_cnt'] = f.get('has_side_800_cnt', None)
            cluster_dict['cluster_room_label'] = f.get('room_label', None)
    toilet_dict.update(cluster_dict)

    return toilet_dict


def get_kitchen_features(area_id, frame, plan_idx):
    message = frame.explain_message
    explain_kitchen = message.get(ce.EXPLAIN_KITCHEN, {})
    # with_entrance = explain_kitchen.get(area_id, {}).get(ce.WITH_ENTRANCE, None)
    kitchen_entrance_dis = explain_kitchen.get(area_id, {}).get(ce.WITH_ENTRANCE, float("inf"))
    if kitchen_entrance_dis == float('inf'):
        kitchen_entrance_dis = 999999.
    else:
        kitchen_entrance_dis /= 1000

    plan_vector = frame.vector[frame.plan_key][plan_idx]
    dinning_kitchen_dis = dinning_kitchen_distance(plan_vector, explain_kitchen)
    if dinning_kitchen_dis is None:
        dinning_kitchen_dis = 999999.
    else:
        dinning_kitchen_dis /= 1000.

    points_dict, line_items_dict, lines_dict, areas_dict = itemgetter(*ce.DICTS)(plan_vector)
    _, area_points, room_type, detail_type, area_size = itemgetter(*ce.IPTTS)(areas_dict[area_id])
    open_kitchen = True if detail_type == ce.OPEN_KITCHEN_TYPE else False

    with_balcony = explain_kitchen.get(area_id, {}).get(ce.WITH_BALCONY, False)
    kitchen_dict = {
        "kitchen_entrance_dis": kitchen_entrance_dis,
        "dinning_kitchen_dis": dinning_kitchen_dis,
        "open_kitchen": open_kitchen,
        "with_balcony": with_balcony,
    }

    cluster_dict = dict()
    cluster_fea = frame.explain_message[KIT_TOI_FIELD].get(ce.AreaType.kitchen.value, [{}])
    for f in cluster_fea:
        if area_id == f['area_id']:
            cluster_dict['cluster_main_width_label'] = f.get('main_width_label', None)
            cluster_dict['cluster_main_deep_label'] = f.get('main_deep_label', None)
            cluster_dict['cluster_has_side_400_cnt'] = f.get('has_side_400_cnt', None)
            cluster_dict['cluster_has_side_1300_cnt'] = f.get('has_side_1300_cnt', None)
            cluster_dict['cluster_door_balcony_pos'] = f.get('door_balcony_pos', None)
            cluster_dict['cluster_has_parallel_balcony'] = f.get('has_parallel_balcony', None)
            cluster_dict['cluster_has_vertical_balcony'] = f.get('has_vertical_balcony', None)
            cluster_dict['cluster_balcony_has_800'] = f.get('balcony_has_800', None)
            cluster_dict['cluster_area_size_label'] = f.get('area_size_label', None)
            cluster_dict['cluster_toilet_area_size_label'] = f.get('toilet_area_size_label', None)
            cluster_dict['cluster_balcony_door_cnt'] = f.get('door_cnt', None)
            cluster_dict['cluster_room_label'] = f.get('room_label', None)
    kitchen_dict.update(cluster_dict)

    return kitchen_dict


def get_main_room_features(area_id, frame):
    room_dict = get_room_features(area_id, frame)
    main_room_dict = room_dict
    # 用最大矩形的方法更新主卧的面宽进深
    # TODO ： 次卧需要更新
    house = frame.house
    if house.res_dict.get('main_room'):
        width = house.res_dict.get('main_room')[0]['space_analysis']['width']/1000
        depth = house.res_dict.get('main_room')[0]['space_analysis']['depth']/1000
        main_room_dict.update({
            'width': round(width, 2),
            'depth': round(depth, 2),
            'max_rec_area': round(width * depth, 2),
        })

    return main_room_dict


def get_room_features(area_id, frame):
    """卧室特有特征"""
    explain_room = frame.explain_message.get(ce.EXPLAIN_ROOM, {})
    room_name, room_label, face_entrance_dis, face_toilet_dis = explain_room.get(
        area_id, ["", 0, float("inf"), float("inf")])

    with_balcony = True if (room_label & ce.RoomLabel.with_balcony) else False
    with_toilet = True if (room_label & ce.RoomLabel.with_toilet) else False
    with_cloakroom = True if (room_label & ce.RoomLabel.with_cloakroom) else False
    face_room = True if (room_label & ce.RoomLabel.face_others) else False
    neighbor_kitchen = True if (room_label & ce.RoomLabel.neighbor_kitchen) else False
    if face_entrance_dis == float("inf"):
        face_entrance_dis = 999999.
    else:
        face_entrance_dis /= 1000.
    if face_toilet_dis == float("inf"):
        face_toilet_dis = 999999.
    else:
        # face_toilet_dis /= 1000.
        face_toilet_dis = face_toilet_dis
    room_dict = {
        "face_entrance_dis": face_entrance_dis,
        "face_toilet_dis": face_toilet_dis,
        "neighbor_kitchen": neighbor_kitchen,
        "with_toilet": with_toilet,
        "with_balcony": with_balcony,
        "with_cloakroom": with_cloakroom,
        "face_room": face_room,
    }
    return room_dict


def get_room_type(room_type_id, frame, **kwargs):
    """
    room_type: 户型编辑器中的room_type编号，
    """
    area_id = kwargs["area_id"]
    areas_dict = kwargs["area_dict"]
    main_room_connected_id = kwargs["main_room_connected_id"]
    # 主卧和次卧
    if room_type_id == ce.AreaType.room.value:
        main_room_id = kwargs.get("main_room")
        if area_id == main_room_id:
            return ce.DecorationAreaType.main_room.value
        else:
            return ce.DecorationAreaType.sub_room.value
    # 客厅, 餐厅
    if room_type_id == ce.AreaType.parlour.value:
        if areas_dict[area_id].get('type', None) == 2:
            return ce.DecorationAreaType.dinning_room.value
        else:
            return ce.DecorationAreaType.parlour.value
    # 厨房
    if room_type_id == ce.AreaType.kitchen.value:
        return ce.DecorationAreaType.kitchen.value
    # 主卫和客卫，其它卫生间
    if room_type_id == ce.AreaType.toilet.value:
        if area_id in main_room_connected_id:
            return ce.DecorationAreaType.main_toilet.value
        elif is_parlour_toilet(area_id, frame):
            return ce.DecorationAreaType.parlour_toilet.value
        else:
            return ce.DecorationAreaType.other_toilet.value
    return ce.DecorationAreaType.other.value


def is_parlour_toilet(area_id, frame):
    connected_id = frame.house.get_connect_areas4area_id(area_id)
    for conn in connected_id:
        for fp in frame.house.floorplans:
            if conn not in fp.id_regions:
                continue
            roomType = fp.id_regions[conn]._roomType
            if roomType == ce.AreaType.other.value or roomType == ce.AreaType.parlour.value:
                return True
    return False


def get_whole_house_features(frame):
    fea_dict0 = {
        "shi": frame.room_cnt[0],
        "ting": frame.room_cnt[1],
        "chu": frame.room_cnt[2],
        "wei": frame.room_cnt[3],
        "total_area_size": frame.frame_size,
        "area_size": frame.frame_size,
    }

    frame_label = frame.frame_label

    living_len = 0
    work_len = 0
    guest_len = 0
    if frame.explain_message.get('explain_real_liner') is None:
        pass
    elif frame.explain_message['explain_real_liner'].get('living_len') is None:
        # 动线 ERROR时保护
        pass
    else:
        living_len = frame.explain_message['explain_real_liner']['living_len'] / 1000
        work_len = frame.explain_message['explain_real_liner']['work_len'] / 1000
        guest_len = frame.explain_message['explain_real_liner']['guest_len'] / 1000
    # 可视域比例
    if frame.explain_message.get('explain_real_visual') is None:
        visual_ratio = 0
    else:
        visual_ratio = frame.explain_message['explain_real_visual']['area_ratio_o']
    # 整屋朝向
    total_face = None
    face_label = frame.explain_message[ce.EXPLAIN_WHOLE_FRAME][8]
    for label, ft in zip([1, 2, 4, 8, 16], [u"南北", u"南", u"东", u"西", u"北"]):
        if label & face_label:
            total_face = ft
            break
    # 通透性
    trance_type = None
    trans_label = frame.explain_message[ce.EXPLAIN_WHOLE_FRAME][3]
    for label, tt in zip([1, 2, 4], [u"对侧", u"邻侧", u"单侧"]):
        if label & trans_label:
            trance_type = tt
            break

    whole_dict = {
        "movement_clear": is_label_hit(frame_label, "movement_clear"),  # 是否动静分明
        "moving_line_cross_cnt": get_moving_line_cross_cnt(frame),  # 动线交叉数量
        "living_len": living_len,
        "work_len": work_len,
        "guest_len": guest_len,
        "good_active_line": is_label_hit(frame_label, "good_active_line"),  # 是否动线合理
        "visual_ratio": visual_ratio,  # 可视域比例
        "is_square": is_label_hit(frame_label, "square"),  # 是否方正
        "total_face_str": total_face,  # 总体朝向
        "face_label": face_label,  # 总体朝向编码
    }
    whole_dict.update(fea_dict0)
    frame.explain_message[NEW_FEATURE_FIELD].update({'whole': [whole_dict]})
    return None


def get_moving_line_cross_cnt(frame):
    """动线交叉点数"""
    if frame.explain_message.get('explain_real_liner') is None:
        return None
    return frame.explain_message['explain_real_liner']['cross_cnt']


def is_label_hit(label, key):
    """判断某一标签是否命中"""
    if ce.LABEL_DICT.get(key) is None:
        raise ValueError("no this tag")
    if label & ce.LABEL_DICT[key][0] == 0:
        return False
    else:
        return True


def frame_tag_feature_collect(base_func):
    """收集户型特征"""
    def item_func(frame, *args, **kwargs):
        frame.explain_message[NEW_FEATURE_FIELD] = {}
        get_every_room_features(frame, **kwargs)
        get_whole_house_features(frame)

    return item_func


@eval_main.frame_prepare
@eval_general.area_wall
@eval_general.width_depth_face
@eval_general.area_size
@eval_general.window_door
@eval_single.single_general
@eval_global.v1
# @eval_main.liner_worker
@frame_tag_feature_collect
def frame_tag_explain(frame, *args, **kwargs):
    logging.debug("newhouse_explain")


