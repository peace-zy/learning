# coding=utf-8
import json
import yaml
import boto3
import traceback
import logging

from lib import entity
from lib import label_functions
from frame_remould.floorplan import House
from lib.file_util import get_file_stream

from frame_eval.frame_tag_lib.lib_eval_main import frame_tag_explain

import numpy as np


class NpEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return json.JSONEncoder.default(self, obj)


def get_s3_client():
    S3_AK = "223HG43LGIX9W3MWTOCL"
    S3_AKS = "tqWXh8kSyxM/QfgF34dMXFJcRrIIGfIIZkVVjSMH"
    s3_client = boto3.client('s3', region_name="cn-north-1", endpoint_url="http://storage.lianjia.com",
                             aws_access_key_id=S3_AK,
                             aws_secret_access_key=S3_AKS)
    return s3_client


def get_frame_vector(frame, city='110000'):
    if is_number(frame):
        frame_id = str(frame)
        s3_client = get_s3_client()
        vector_response = s3_client.get_object(Bucket='frame-eval-image', Key=str(frame_id) + '.json')
        vector_str = vector_response['Body'].read()
        city_code = str(city)
        line = "\t".join([frame_id, 'image_id', vector_str.decode("utf-8"), city_code])
    else:
        with open(frame, 'r') as f:
            ke_json = json.load(f)
        frame_id = str(888)
        line = "\t".join([frame_id, 'image_id', json.dumps(ke_json), str(city)])

    return frame_id, line


def is_number(s):
    try:
        float(s)
        return True
    except Exception as e:
        pass
    # except ValueError:
    #     pass

    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except Exception as e:
        pass
    # except (TypeError, ValueError):
    #     pass

    return False


def collect_conf(conf_path, conf):
    with open(conf_path, 'r', encoding='UTF-8') as conf_data:
        conf0 = yaml.full_load(conf_data)
        conf.update(conf0)


def collect_conf_on_spark(conf_path, conf):
    f = get_file_stream(conf_path)
    conf0 = yaml.load(f)
    conf.update(conf0)


def get_whole_frame_info(row, conf, get_result, update_basic2frame):
    """
    get_result: 得到结果的函数
    update_basic2frame: 其它表或者渠道更新最终结果的函数
    """
    frame = entity.Frame(row)
    try:
        frame_vector = frame.vector
        house = House()
        house.set_json_str(json.dumps(frame_vector))
        house.run()

        frame.set_house(house)
        frame.add_label(label_functions.label_base, **conf["label_params"])
        frame_tag_explain(frame, **conf)
        update_basic2frame(row, frame)
        result = get_result(frame.frame_id, frame)
    except Exception as e:
        traceback.print_exc()
        result = get_result(frame.frame_id, e)
    return frame, result

