# -*- coding:utf-8 -*-
import copy
import sys
import os
import pandas as pd
import math
import yaml

if sys.platform in ["win32", "darwin"]:
    os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../../"))
    sys.path.insert(0, os.getcwd())

import frame_eval.frame_tag_lib.utils as utils

ROOM_TYPE = 'room_type'
DIM_NAME = 'dim_name'
ENUM_LEV1 = 'enum_lev1'
ENUM_LEV2 = 'enum_lev2'
ENUM_LEV3 = 'enum_lev3'
CONFIG_FILE = 'frame_eval/frame_tag_lib/doc.yml'

ROOM_DICT = {
    'whole': '整屋',
    'main_room': '主卧',
    'sub_room': '次卧',
    'parlour': '客厅',
    'kitchen': '厨房',
    'main_toilet': '主卫',
    'parlour_toilet': '客卫',
}

def get_init_conf():
    """初始化配置"""
    conf = dict()
    utils.collect_conf(r"frame_eval/frame_tag_lib/doc_temp.yml", conf)

    room_types = conf['doc']['room_type_order']

    # 复制主卧的初始化到其它功能区
    for room in room_types:
        if conf['doc']['explain'].get(room) is None:
            conf['doc']['explain'][room] = copy.deepcopy(conf['doc']['explain']['main_room'])
            if room == 'sub_room':
                conf['doc']['explain'][room]['range'] = 'all'
            conf['doc']['explain'][room]['type'] = room
            conf['doc']['explain'][room]['name'] = ROOM_DICT[room]
    return conf


def get_condition(line):
    cons = []
    features = []
    cons1 = line.split('&&')
    for c in cons1:
        cons2 = c.split('**')
        cons.append((cons2[0], cons2[1], cons2[2]))
        features.append(cons2[0])
    return cons, features


def convert_config(excel_path):
    df = pd.read_excel(excel_path)
    conf = get_init_conf()

    tag_rooms = list(df[ROOM_TYPE].unique())
    tag_rooms = [r.encode(encoding="utf-8") for r in tag_rooms]

    all_room_types = copy.deepcopy(conf['doc']['room_type_order'])
    # 删除没有的功能区
    for r in all_room_types:
        if r in tag_rooms:
            continue
        conf['doc']['room_type_order'].remove(r)
        del conf['doc']['explain'][r]

    for r in tag_rooms:
        dim_temp = conf['doc']['explain'][r]['dims'][0]
        df_r = df[df[ROOM_TYPE] == r]
        room_dim_names = [i.encode('utf8') for i in list(df_r[DIM_NAME].unique())]
        new_dim_list = []
        for d in room_dim_names:
            new_dim = copy.deepcopy(dim_temp)
            df_dim = df_r[df_r[DIM_NAME] == d]
            doc_vars_temp = copy.deepcopy(new_dim['doc_vars'][0]) # doc_vars 模板
            new_doc_vars = []
            all_features = set()
            for idx, row in df_dim.iterrows():
                doc_vars_i = copy.deepcopy(doc_vars_temp)
                enums = [row[ENUM_LEV1], row[ENUM_LEV2], row[ENUM_LEV3]]
                for idx, e in enumerate(enums):
                    if type(e) == unicode:
                        enums[idx] = e.encode('utf8').replace(' ', '')
                    if utils.is_number(e):
                        if math.isnan(e):
                            enums[idx] = ''
                        else:
                            enums[idx] = str(e)
                    if e is None:
                        enums[idx] = ''
                doc_vars_i[0]['vars']['e1'] = enums[0]
                doc_vars_i[0]['vars']['e2'] = enums[1]
                doc_vars_i[0]['vars']['e3'] = enums[2]

                condition = row['condition']
                cons, features = get_condition(condition)
                for f in features:
                    all_features.add(f)
                doc_vars_i[0]['cond'] = cons
                new_doc_vars.append(doc_vars_i)
            dim_condition = []
            for f in all_features:
                con = (f.encode('utf8'), 'notnull', '')
                dim_condition.append(con)
            # 更新dim_name
            new_dim[DIM_NAME] = d
            new_dim['doc_vars'] = new_doc_vars
            new_dim['dim_condition'] = dim_condition
            new_dim_list.append(new_dim)
        conf['doc']['explain'][r]['dims'] = new_dim_list

    with open(CONFIG_FILE, "w") as f:
        yaml.dump(conf, f, encoding='utf-8', allow_unicode=True)


if __name__ == "__main__":
    excel_path = r'D:\frame_tag_mainroom.xlsx'
    # excel_path = r'conf.xlsx'
    convert_config(excel_path)
