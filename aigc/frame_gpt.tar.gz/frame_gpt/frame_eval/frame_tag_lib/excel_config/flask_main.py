# -*- coding:utf-8 -*-
import requests
import json
import os
import sys
import yaml
import base64
import boto3

from flask import Flask
from flask import request

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../../"))
sys.path.insert(0, os.getcwd())

from frame_eval.frame_tag_lib.excel_config.format_excel2yml import convert_config
from frame_eval.frame_tag_lib import utils
import frame_eval.frame_tag_lib.spark_main_feature as spark_main_feature
from frame_eval.frame_tag_lib import spark_main_deco_rpt

EXCEL_PATH = 'conf.xlsx'

app = Flask(__name__)


def after_request(resp):
    resp.headers['Access-Control-Allow-Origin'] = '*'
    return resp


@app.route("/update_config", methods=["POST"])
def update_config():
    lxsx = request.form.get('file')
    with open(EXCEL_PATH, 'wb') as f:
        f.write(base64.b64decode(lxsx.split(u'base64,')[1]))

    convert_config(EXCEL_PATH)
    return {'code': 'OK'}


@app.route("/frame_vector", methods=["POST"])
def get_frame_vector():
    try:
        frame_id = request.form.get('frame_id')
        s3_client = get_s3_client()
        vector_response = s3_client.get_object(Bucket='frame-eval-image', Key=str(frame_id) + '.json')
        vector_str = vector_response['Body'].read()
        vector_dict = json.loads(vector_str)
        for fp in vector_dict['floorplans']:
            if fp.get('items') is not None:
                fp['items'] = []

        res = {'frame_vector': json.dumps(vector_dict)}
    except Exception as error:
        if hasattr(error, 'message'):
            res = {"error": error.message}
        else:
            res = {"error": "Unkonw error"}
    return res


@app.route("/frame_tag", methods=["POST"])
def frame_tag():
    try:
        frame_vector = request.form.get('vectorValue').encode('utf8')
        frame_id = str(request.form.get('frame_id'))
        if utils.is_number(frame_id):
            res = spark_main_deco_rpt.case_study(frame_id)
            return res
        else:
            return {'frameid': 'error'}

    except Exception as error:
        res = {"error": error.message}
    return res


def get_s3_client():
    S3_AK = "223HG43LGIX9W3MWTOCL"
    S3_AKS = "tqWXh8kSyxM/QfgF34dMXFJcRrIIGfIIZkVVjSMH"
    s3_client = boto3.client('s3', region_name="cn-north-1", endpoint_url="http://storage.lianjia.com",
                             aws_access_key_id=S3_AK,
                             aws_secret_access_key=S3_AKS)
    return s3_client


if __name__ == "__main__":
    app.after_request(after_request)
    app.run(host='0.0.0.0', port=8900)
