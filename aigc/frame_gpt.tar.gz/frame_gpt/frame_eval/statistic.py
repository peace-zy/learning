#!/bin/env python2.7
# coding=utf-8
# Copyright (c) 2019 www.ke.com, Inc. All Rights Reserved
"""
Authors: yudonghai@ke.com
Date: 2019-07-10
"""
from __future__ import division
import logging
import yaml
import sys
from operator import itemgetter

import json

import __init__
from lib import entity
from lib import spark_util
from lib import eval_main
from lib import code_enum as ce


def frame_analysis(row, **params):
    """
    为户型打标签
    :param row: str/Row/dict, 户型数据
            (str格式时各个字段用逗号分隔，且需要跟Frame类内各字段顺序一致)
    :param params: dict, 参数
    :return:
    """
    frame = entity.Frame(row)
    if frame.state != ce.State.valid:
        feas = [frame.frame_id, frame.city_code, frame.state] + [0] * 17
        feas = [str(x) for x in feas]
        return feas
    eval_main.base_explain(frame, **params)

    message = frame.explain_message

    frame_vector = frame.vector
    ting_info = [None, 0]
    chu_info = [None, 0]
    wei_info = []

    for plan_vector in frame_vector[frame.plan_key]:
        points_dict, line_items_dict, lines_dict, areas_dict = itemgetter(*ce.DICTS)(plan_vector)

        # 逐分间
        for area_id in areas_dict:
            _, area_points, room_type, detail_type, area_size = itemgetter(*ce.IPTTS)(areas_dict[area_id])

            # 有独立餐厅
            if detail_type in ce.REAL_PARLOUR:
                if area_size > ting_info[1]:
                    ting_info = [area_id, area_size]
            elif room_type == ce.AreaType.kitchen.value:
                if area_size > chu_info[1]:
                    chu_info = [area_id, area_size]
            elif room_type == ce.AreaType.toilet.value:
                wei_info.append([area_id, area_size])

    # name, width, depth, width_div_depth
    explain_width_depth = message.get(ce.EXPLAIN_WIDTH_DEPTH, {})
    # area_size, gray_size, door_size
    explain_size = message.get(ce.EXPLAIN_SIZE, {})
    # expand_points, oblique_flag, max_line, line_info_lst, entrance_vector
    explain_wall = message.get(ce.EXPLAIN_WALL, {})
    # all_window_len, w_div_floor, faces, main_face, convex_window
    explain_window_door = message.get(ce.EXPLAIN_WINDOW_DOOR, {})
    # name, ToiletLabel
    explain_toilet = message.get(ce.EXPLAIN_TOILET, {})
    # name, RoomLabel
    explain_room = message.get(ce.EXPLAIN_ROOM, {})
    # FramePLabel
    explain_frame = message.get(ce.EXPLAIN_FRAME, 0)
    # main_face, main_face_len, face_dict
    explain_face = message.get(ce.EXPLAIN_FACE, {})
    # ### explain_whole_frame
    # area_inf_dict, main_room_id, sub_rooms, trans_flag, face_flag, frame_rec, surround_sub_room_cnt, frame_size
    explain_whole_frame = message.get(ce.EXPLAIN_WHOLE_FRAME, [{}, None, [], 0, 0, True, -1, 0])

    # 分间类型 - [分间个数，分间总面积]
    area_inf_dict = explain_whole_frame[0]
    # 主卧id
    main_room_id = explain_whole_frame[1]
    # 次卧列表 <id, 次序, 名称>
    sub_rooms = explain_whole_frame[2]
    # 通透类型
    trans_flag = explain_whole_frame[3]
    # 朝向类型
    face_flag = explain_whole_frame[4]
    # 是否方正
    frame_rec = explain_whole_frame[5]
    # 主卧邻接次卧数量
    surround_sub_room_cnt = explain_whole_frame[6]
    # 户型面积
    frame_size = explain_whole_frame[7] / 1000000.

    room_cnt = area_inf_dict.get(ce.AreaType.room.value, [0, 0])[0]

    features = [frame.frame_id,
                frame.city_code,
                frame.state,
                frame_size,
                area_inf_dict.get(ce.AreaType.room.value, [0, 0])[0],
                area_inf_dict.get(ce.AreaType.parlour.value, [0, 0])[0],
                area_inf_dict.get(ce.AreaType.kitchen.value, [0, 0])[0],
                area_inf_dict.get(ce.AreaType.toilet.value, [0, 0])[0],
                area_inf_dict.get(ce.AreaType.room.value, [0, 0])[1],
                area_inf_dict.get(ce.AreaType.parlour.value, [0, 0])[1],
                area_inf_dict.get(ce.AreaType.kitchen.value, [0, 0])[1],
                explain_size.get(main_room_id, [0, 0, 0])[0],
                explain_window_door.get(main_room_id, [0, 0, [], '', False])[1],
                explain_window_door.get(ting_info[0], [0, 0, [], '', False])[1],
                explain_width_depth.get(chu_info[0], ['', 0, 0, 0])[1],
                explain_width_depth.get(chu_info[0], ['', 0, 0, 0])[2],
                sum([explain_size[x][1] for x in explain_size]),
                explain_size.get(ting_info[0], [0, 0, 0])[2],
                explain_width_depth.get(ting_info[0], ['', 0, 0, 0])[3],
                explain_window_door.get(ting_info[0], [0, 0, [], '', False])[1]
                ]

    features = [str(x) for x in features]

    return features


def logic_func(driver, raw_df, **params):
    """
     spark 逻辑处理
    :param driver: spark_util.SparkSqlDriver, spark 执行类
    :param raw_df: pyspark.sql.dataframe.DataFrame， sql 查询结果
    :param params: dict, 参数字典
    :return: result_df, 处理后的 DataFrame
    """
    result_rdd = raw_df.rdd.map(lambda row: frame_analysis(row, **params))
    result_df = driver.rdd_2_df(result_rdd)
    names = [
        "frame_id",
        "city_code",
        "state",
        "frame_size",
        "shi",
        "ting",
        "chu",
        "wei",
        "room_size",
        "parlour_size",
        "kitchen_size",
        "main_room_size",
        "main_room_wd",
        "parlour_wd",
        "kitchen_width",
        "kitchen_depth",
        "gray_size",
        "parlour_door_size",
        "parlour_wdd",
        "parlour_wd"
    ]
    result_df = result_df.toDF(*names)
    return result_df


def main():
    """ 主函数 """
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    if len(sys.argv) < 3:
        logging.error("no less than 2 arguments!")
        sys.exit()

    pt_date = sys.argv[1]
    config_file = sys.argv[2]

    with open(config_file, "r") as config_data:
        conf = yaml.load(config_data)

    # 从配置文件读取参数
    spark_config_key = "frame_eval_config"
    spark_params = conf.get(spark_config_key, None)
    if spark_params is None:
        logging.error("lack {} in config file".format(spark_config_key))
        sys.exit(1)

    # ## 补充参数
    # pt
    spark_params["sql_params"]["pt_date"] = pt_date
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_function"] = logic_func
    # 存储pt
    spark_params["save_params"]["file_or_table_name"] = "data/statistic.txt"
    spark_params["save_params"]["save_target"] = "local"

    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()


if __name__ == "__main__":

    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')

    main()
