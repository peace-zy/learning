# -*- coding: utf-8 -*-
# ===============================================================
#
#    Copyright (C) 2021 Beike, Inc. All Rights Reserved.
#
#    @Create Author : 李雨龙 (liyulong008@ke.com)
#    @Create Time   : 2021/7/15 14:41
#    @Description   : 户型改造解读实体
#
# ===============================================================
from __future__ import division
import __init__
import json
import math
import copy
from abc import ABCMeta, abstractmethod

import numpy as np
from shapely.geometry import LineString, Polygon, Point, CAP_STYLE, JOIN_STYLE
from shapely.strtree import STRtree
from shapely.affinity import affine_transform, rotate
import matplotlib.pyplot as plt

from lib import code_enum as ce, diff_util, figures


def get_color_by_room_type_and_idx(room_type, idx):
    return int(min(255, 50 + 16*int(room_type[-3:]) + min(2*(ord(idx if idx else 'A') - 65), 14)))


CMAP = plt.get_cmap('tab20')

# 分间大类 总数
MAX_ROOM_TYPE = 13
# # 分间小类 总数
# MAX_ROOM_DETAIL_TYPE = 45
# 附件大类
WALL_ITEM_TYPE_MAP = {0: 0, 1: 1, 2: 0, 3: 0, 4: 0, 16: 2,  # 门/推拉门
                      5: 3}  # 窗
MAX_WALL_ITEM_TYPE = max(list(WALL_ITEM_TYPE_MAP.values()))
# # 附件小类 总数
# MAX_ITEM_DETAIL_TYPE = 19
# 墙体大类 总数
WALL_TYPE_MAP = {0: 0, 1: 1, 2: 0, 3: 3, 6: 3}
MAX_WALL_TYPE = max(list(WALL_TYPE_MAP.values()))

ALL_COLOR = CMAP(np.linspace(0, 1, MAX_WALL_ITEM_TYPE + MAX_ROOM_TYPE + MAX_WALL_TYPE))

WALL_COLORS = ALL_COLOR[:MAX_WALL_TYPE]
ROOM_COLORS = ALL_COLOR[MAX_WALL_TYPE: MAX_ROOM_TYPE + MAX_WALL_TYPE]
WALL_ITEM_COLORS = ALL_COLOR[MAX_ROOM_TYPE + MAX_WALL_TYPE:]

ROOM_NAME = {
    '100900000012': '其他房间',
    '100900000002': '厅',  # 厅
    '100900000001': '卧室',  # 室
    '100900000004': '卫生间',  # 卫
    '100900000003': '厨房',  # 厨
    '100900000005': '阳台',  # 阳台
    '100900000008': '储物间',  # 储物间
    '100900000013': '衣帽间',  # 储物间
}


def get_color_by_type_and_idx_channel(obj_type, color_map, idx=None):
    color_type = list(color_map[min(len(color_map) - 1, obj_type)])
    if idx is not None:
        color_type[-1] = 1. - min(5, idx) / 25.0
    return color_type


class GeoObj(object):
    """
    几何物体基类
    """
    __metaclass__ = ABCMeta

    def __init__(self):
        # 几何元素类型
        self.type = 'geo_obj_base'
        # 透明度
        self.alpha = 0.4
        # 显示层级
        self.zorder = 1
        # 是否匹配上了
        self.is_matched = False
        # 匹配上的对象
        self.matched_obj = None
        # 弱匹配 墙体可能移位, 截断...
        self.is_almost_matched = False
        # 另外一个户型的几何变换的矩阵
        self.trans_matrix = None
        # skimage 几何变化对象
        self.trans_matrix_obj = None
        # 另外一个户型的几何变换的矩阵(打平成一维数组)
        self.trans_matrix_1d = None

    @abstractmethod
    def dump(self):
        """
        导出json dict
        :return:
        """
        pass


class Corner(GeoObj):
    """
    户型角点
    """

    DEFAULT_VALUE = -1000
    ANGLE_THRESHOLD = 15
    # 从x坐标轴正向逆时针0,1,2,3
    ANGLE_TYPE = np.array([0, 90, 180, 270])

    def __init__(self, x, y, line_ids, uid=None, **kwargs):
        super(Corner, self).__init__()
        self.line_ids = line_ids
        self.line_cnt = len(line_ids)
        self.connected_pts = []
        self.x = x
        self.y = y
        self.p_type = 'o'
        if uid is None:
            self.uid = diff_util.create_uuid()
        else:
            self.uid = uid
        self.walls = []
        self.walls_angle = []
        self.sorted_angle = self.DEFAULT_VALUE*np.ones(4)
        self.coord = (self.x, self.y)
        self.entrance_distance = -1
        self.centroid_distance = -1
        self.min_contour_distance = -1
        self.name = str(self.coord)
        self.obj = Point(self.coord)
        self.color = figures.COLOR_MAP[3]
        # 原始json
        self.ori_dict = kwargs['ori_dict']

    def __str__(self):
        return str(self.coord)

    def get_feature_vec(self):
        return self.relative_coords + [self.entrance_distance, self.center_distance, self.line_cnt] + list(self.sorted_angle)

    def set_matched(self, op_obj, color=None):
        self.matched_obj = op_obj
        if color:
            self.color = color
        else:
            self.color = figures.GREEN
        self.is_matched = True

    def set_mismatched(self, color=None):
        self.alpha = 0.9
        self.zorder = 3
        if color:
            self.color = color
        else:
            self.color = figures.BLACK
        self.is_matched = False

    def dump(self):
        """
        导出json dict(最终变换过的)
        :return:
        """
        self.ori_dict['x'] = self.coord[0]
        self.ori_dict['y'] = self.coord[1]
        return self.ori_dict


class Wall(GeoObj):
    """
    墙体
    """

    # 墙体的膨胀尺寸, 可以认为是墙体近邻范围可以匹配的墙体.
    DILUTED_WIDTH = 400

    def __init__(self, pts_id, line_type, items, edge_computed, uid, pts_dict, **kwargs):

        super(Wall, self).__init__()
        # 墙体id
        self.uid = -1
        # 墙体可能是一对多
        self.matched_obj = set()
        # p为Corner类型
        self.pts_id = pts_id
        self.line_type = line_type
        # 排序x, y
        _tmp_coords = sorted([(_pid, pts_dict[_pid].coord) for _pid in self.pts_id], key=lambda x: (x[-1][0], x[-1][1]))
        self.p_1 = pts_dict[_tmp_coords[0][0]]
        self.p_2 = pts_dict[_tmp_coords[1][0]]
        self.coord = [_tmp_coords[0][-1], _tmp_coords[1][-1]]
        self.items = items
        self.line_items = []
        self.edge_computed = edge_computed
        self.uid = uid
        self.curve = kwargs['curve']
        self.rooms = set()
        self.room_types = set()
        self.pts_set = {tuple(_tmp_coords[0][-1]), tuple(_tmp_coords[1][-1])}
        self.name = str(self.coord)
        self.obj = LineString(self.coord)
        # 指定默认色
        # self.color = figures.COLOR_MAP[2]
        self.length = self.obj.length
        self.angle = kwargs['angle']
        # 墙体厚度
        self.wall_thickness = kwargs['wall_thickness']
        self.diluted_wall = self.obj.buffer(self.DILUTED_WIDTH, resolution=1,
                                            cap_style=CAP_STYLE.flat, join_style=JOIN_STYLE.mitre)
        self.diluted_wall_id = id(self.diluted_wall)
        # 线宽
        self.linewidth = 1
        # 原始json
        self.ori_dict = kwargs['ori_dict']
        # 是否是断墙： Shapely: Dangles are edges which have one or both ends which are not incident on another edge endpoint.
        self.is_dangle = True
        self.type = kwargs['ori_dict']['type']
        self.color = get_color_by_type_and_idx_channel(WALL_TYPE_MAP.get(line_type, 2), WALL_COLORS)

    def __str__(self):
        return str(self.coord)

    def get_paired_wall_polygon(self):
        """
        获取最终匹配完之后的墙体膨胀多边形点集
        :return: [(x1, y1), (x2, y2),...]
        """
        return list(self.obj.buffer(self.wall_thickness, resolution=1, cap_style=CAP_STYLE.flat,
                                    join_style=JOIN_STYLE.mitre).boundary.coords)

    def set_mismatched(self, color=None):
        if not self.edge_computed:
            self.is_matched = False
            self.alpha = 0.9
            self.zorder = 2
            self.linewidth = 5
            if color:
                self.color = color
            else:
                self.color = figures.RED

    def set_missing(self, color=None):
        self.alpha = 0.7
        self.zorder = 2
        if color:
            self.color = color
        else:
            self.color = figures.RED
        self.linewidth = 8
        self.is_matched = False

    def set_matched(self, op_obj, color=None):
        self.alpha = 0.7
        self.matched_obj.add(op_obj)
        if color:
            self.color = color
        else:
            self.color = figures.GREEN
        self.linewidth = 2
        self.is_matched = True

    def set_super_wall_matched(self, op_super_walls, color=None):
        self.alpha = 0.2
        self.matched_obj = op_super_walls
        if color:
            self.color = color
        self.linewidth = 12
        self.is_almost_matched = True

    def set_almost_matched(self, op_obj, color=None):
        self.alpha = 0.2
        self.matched_obj.add(op_obj)
        if color:
            self.color = color
        self.linewidth = 12
        self.is_almost_matched = True

    def dump(self):
        """
        导出json dict
        :return:
        """
        self.ori_dict['curve'] = self.curve
        self.ori_dict['points'] = self.pts_id
        return self.ori_dict


class SuperWall(Wall):

    def __init__(self):
        """
        超墙: 相连的多段墙
            1. 同一直线.
            2. 同墙体类别.
        """
        super(SuperWall, self).__init__()
        # 是否属于同一分间
        self.is_same_room = False
        self.multi_walls = []


class WallItem(GeoObj):

    DILUTED_WIDTH = 300

    def __init__(self, line_item_type, is_type, entrance, start_point, end_point, line_id, uid, **kwargs):
        """
        墙体附件
        """
        super(WallItem, self).__init__()

        self.uid = uid
        self.line_item_type = line_item_type
        self.line_id = line_id
        self.is_type = is_type
        self.start = kwargs['start']
        self.rotate_x = kwargs['rotate_x']
        self.rotate_y = kwargs['rotate_y']
        self.wall_thickness = kwargs['wall_thickness']
        self.entrance = entrance
        self.start_point, self.end_point = [start_point['x'], start_point['y']], [end_point['x'], end_point['y']]
        self.coord = self.start_point, self.end_point
        self.center = np.mean([self.start_point, self.end_point], axis=0)
        self.name = str(self.coord)
        self.obj = LineString(self.coord)
        self.diluted_wall_item = self.obj.buffer(self.wall_thickness, resolution=1,
                                                 cap_style=CAP_STYLE.flat, join_style=JOIN_STYLE.mitre)

        # self.color = figures.COLOR_MAP[5]
        # 默认为窗2
        if entrance is not None:
            self.color = [0.1, 0.1, 0.1, 1.]
        else:
            self.color = get_color_by_type_and_idx_channel(WALL_ITEM_TYPE_MAP.get(line_item_type, 2), WALL_ITEM_COLORS)
        self.length = self.obj.length
        self.is_matched = True
        self.edge_computed = False
        # 原始json
        self.ori_dict = kwargs['ori_dict']
        self.type = kwargs['ori_dict']['type']

    def __str__(self):
        return str(self.coord)

    def get_paired_wall_polygon(self):
        """
        获取最终匹配完之后的墙体膨胀多边形点集
        :return: [(x1, y1), (x2, y2),...]
        """
        return list(self.diluted_wall_item.boundary.coords)

    def set_mismatched(self, color=None):
        self.is_matched = False
        self.alpha = 0.9
        self.zorder = 2
        self.linewidth = 3
        if color:
            self.color = color
        else:
            self.color = figures.DARKGRAY

    def dump(self):
        """
        导出json dict
        :return:
        """
        self.ori_dict['rotateY'] = self.rotate_y
        self.ori_dict['rotateX'] = self.rotate_x
        self.ori_dict['start'] = self.start
        self.ori_dict['entrance'] = self.entrance
        return self.ori_dict


class Room(GeoObj):

    def __init__(self, room_type, detail_type, uid, room_idx, **kwargs):
        """
        分间对象
        :param room_type: 房间类型(大类)
        :param detail_type: 房间类型(小类)
        :param room_pts: id索引
        :param real_pts: 真实坐标
        :param uid:
        """
        super(Room, self).__init__()
        # 房间类型(大类)
        self.room_type = room_type
        # 房间类型(小类)
        self.detail_type = detail_type
        self.room_pts = []
        self.uid = uid
        # 分间在户型中的唯一序号
        self.room_idx = room_idx + 1
        self.real_pts = []
        self.room_lines = []
        self.obj = None
        self.area_size = 0
        # 匹配上的分间
        self.matched_obj = []
        # 角点连接墙体的夹角
        self.point_angle = []
        self.name = kwargs.get('name', 'Room')
        # 原始json
        self.ori_dict = kwargs['ori_dict']
        self.name_idx = self.ori_dict['nameIndex']
        # self.color_shade = get_color_by_room_type_and_idx(room_type, self.ori_dict['nameIndex'])
        # self.color_shade_rgb = self.color_shade/255.0, self.color_shade/255.0, self.color_shade/255.0
        self.color = get_color_by_type_and_idx_channel(int(room_type[-3:]), ROOM_COLORS, room_idx)

    def __str__(self):
        return self.name + str(self.area_size)

    def set_real_pts(self, real_pts):
        self.real_pts = real_pts
        self.obj = Polygon(real_pts)
        self.area_size = self.obj.area

    def set_room_pts(self, room_pts):
        self.room_pts = room_pts

    def set_point_angle(self, point_angle):
        self.point_angle = point_angle

    def set_room_lines(self, room_lines):
        self.room_lines = room_lines

    def get_room_polygon_pts(self):
        """
        返回分间的多边形点集
        :return:
        """
        return list(self.obj.boundary.coords)

    def dump(self):
        """
        导出json dict
        :return:
        """
        return self.ori_dict
        # _label_x = self.ori_dict['labelX']
        # _label_y = self.ori_dict['labelY']
        # _label_coord = self.trans_matrix_obj([_label_x, _label_y])[0]
        # self.ori_dict['labelX'], self.ori_dict['labelY'] = _label_coord[0], _label_coord[1]
        # _sub_label_x = self.ori_dict['subLabelX']
        # _sub_label_y = self.ori_dict['subLabelY']
        # _sub_label_coord = self.trans_matrix_obj([_sub_label_x, _sub_label_y])[0]
        # self.ori_dict['subLabelX'], self.ori_dict['subLabelY'] = _sub_label_coord[0], _sub_label_coord[1]


class DiffFrame(GeoObj):
    """
    单户型类(for对比) - 基类
    """

    __metaclass__ = ABCMeta

    # 可视化缩放尺寸
    DISPLAY_SIZE = 256

    def __init__(self):

        super(DiffFrame, self).__init__()

        self.entity_frame = None
        self.entity_eval_result = None

        self._state = ce.State.valid
        self.area_size = 0

        self.corner_list = []
        self.wall_list = []
        self.diluted_wall_id_to_wall = dict()

        self.wall_item_list = []
        self.area_list = []

        self.ori_line_map = dict()
        self.ori_p_map = dict()
        self.pts_key_to_line_map = dict()
        self.ori_line_item_map = dict()
        self.ori_area_map = dict()

        self.entrance_item = None
        self.entrance_line = None

        self.corner_2_wall = dict()
        self.wall_2_item = dict()

        self.max_x, self.max_y = -1, -1
        self.min_x, self.min_y = float('inf'), float('inf')

        # 绘图几何变换的矩阵
        self.draw_matrix_dict = dict()

        # 未匹配成功的元素
        self.mismatched_corner = []
        self.mismatched_wall = []
        self.mismatched_line_item = []
        # 匹配成功的元素
        self.matched_corner = []
        self.matched_wall = []

        # 膨胀墙体的空间索引(用于提速)
        self.wall_str_tree = None

    def set_entity_frame(self, entity_frame, entity_eval_result):
        """
        单户型的解析
        :param entity_frame:
        :param entity_eval_result:
        :return:
        """
        self.entity_frame = entity_frame
        self.entity_eval_result = entity_eval_result

    # @abstractmethod
    def get_center(self):
        assert self.max_x > 0, 'max_x is empty'
        return [(self.max_x + self.min_x) // 2, (self.max_y + self.min_y) // 2]

    def get_width(self):
        return self.max_x - self.min_x

    def get_height(self):
        return self.max_y - self.min_y

    def get_trans_matrix_1d(self):
        return [self.draw_matrix_dict.get(_, 0) for _ in ['a', 'b', 'd', 'e', 'xoff', 'yoff']]

    def trans_room_a_to_b(self, tform, entrance_angle):
        """
        将 a 户型的附件变换成 b 户型
        :param tform: A->B的 skimage transform对象
        :param entrance_angle: B的户型朝向.
        :return:
        """
        self.trans_matrix = tform.params
        self.trans_matrix_obj = tform
        self.trans_matrix_1d = list(self.trans_matrix[:2, :2].flatten()) + list(self.trans_matrix[[0, 1], -1])
        # 转换户型的每个点变成B的坐标系
        for _p_key in self.ori_p_map:
            _p_obj = self.ori_p_map[_p_key]
            _p_obj.trans_matrix = self.trans_matrix
            _p_obj.trans_matrix_obj = self.trans_matrix_obj
            _p_obj.trans_matrix_1d = self.trans_matrix_1d
            _p_obj.coord = tform(_p_obj.coord)[0]
            _p_obj.obj = Point(_p_obj.coord)
        _trans_diluted_walls = []
        for _wall in self.wall_list:
            _wall.trans_matrix = self.trans_matrix
            _wall.trans_matrix_obj = self.trans_matrix_obj
            _wall.trans_matrix_1d = self.trans_matrix_1d
            _ori_coord = np.array(_wall.obj.coords)
            _wall.obj = affine_transform(_wall.obj, self.trans_matrix_1d)
            _diluted_wall = affine_transform(_wall.diluted_wall, self.trans_matrix_1d)
            _wall.diluted_wall_id = id(_diluted_wall)
            _wall.diluted_wall = _diluted_wall

            _post_coord = np.array(_wall.obj.coords)
            _prev_vec, _next_vec = _ori_coord[1] - _ori_coord[0], _post_coord[1] - _post_coord[0]
            is_reflected = np.dot(_prev_vec, _next_vec) <= 0
            if is_reflected:
                # _wall.curve = -_wall.curve
                # 从左到右 从上倒下
                sorted_pts_tuple = sorted(zip(_wall.pts_id, [self.ori_p_map[_].coord for _ in _wall.pts_id]),
                                          key=lambda x: (x[-1][0], -x[-1][1]))
                _wall.pts_id = [sorted_pts_tuple[0][0], sorted_pts_tuple[1][0]]
            _trans_diluted_walls.append(_diluted_wall)
            self.diluted_wall_id_to_wall[_wall.diluted_wall_id] = _wall
            for _item_id in _wall.items:
                _item = self.ori_line_item_map[_item_id]
                if _item.entrance is not None:
                    _item.entrance = entrance_angle
                _temp_wall_item_obj = _item.obj
                _temp_diluted_wall_item = self.ori_line_item_map[_item_id].diluted_wall_item
                _post_item_obj = affine_transform(_temp_wall_item_obj, self.trans_matrix_1d)
                _post_diluted_item_obj = affine_transform(_temp_diluted_wall_item, self.trans_matrix_1d)
                # 获取原始朝向
                rotate_angle = -45
                if _item.rotate_x == _item.rotate_y:
                    # 逆时针 90
                    rotate_angle = -rotate_angle
                # 是否存在线上的旋转
                if _item.rotate_y:
                    # 远点
                    rotate_pt = Point(sorted(list(_temp_wall_item_obj.coords), reverse=True, key=lambda x: (x[0], -x[-1]))[0])
                else:
                    # 近点
                    rotate_pt = Point(sorted(list(_temp_wall_item_obj.coords), key=lambda x: (x[0], -x[-1]))[0])
                open_center = rotate(rotate_pt, rotate_angle, _temp_wall_item_obj.centroid)
                new_open_pt = affine_transform(open_center, self.trans_matrix_1d)
                new_item_line = sorted(list(_post_item_obj.coords), key=lambda x: (x[0], -x[-1]))
                x_side_sign = diff_util.pt_at_line_side(new_item_line[0], new_item_line[1], list(new_open_pt.coords)[0])
                if x_side_sign > 0:
                    # 左边
                    _item.rotate_x = True
                else:
                    _item.rotate_x = False
                # 计算得到点离那个点更近
                dist_arr = np.argmin([Point(_).distance(new_open_pt) for _ in new_item_line])
                if dist_arr == 0:
                    # 左边
                    _item.rotate_y = False
                else:
                    _item.rotate_y = True

                if is_reflected:
                    _item.start = _wall.length - _item.length - _item.start
                self.ori_line_item_map[_item_id].obj = _post_item_obj
                self.ori_line_item_map[_item_id].diluted_wall_item = _post_diluted_item_obj
        self.wall_str_tree = STRtree(_trans_diluted_walls)
        for _area in self.area_list:
            _area.trans_matrix = self.trans_matrix
            _area.trans_matrix_obj = self.trans_matrix_obj
            _area.trans_matrix_1d = self.trans_matrix_1d
            _area.obj = affine_transform(_area.obj, self.trans_matrix_1d)

    def add_match_corner(self, _corner, _op_corner, color=None):
        _corner.set_matched(_op_corner, color)
        self.matched_corner.append(_corner)

    def add_match_wall(self, _wall, _op_wall, color=None):
        _wall.set_matched(_op_wall, color)
        self.matched_wall.append(_wall)

    def add_mismatch_corner(self, _corner, color=None):
        _corner.set_mismatched(color)
        self.mismatched_corner.append(_corner)

    def add_mismatch_line_item(self, _line_item, color=None):
        _line_item.set_mismatched(color)
        self.mismatched_line_item.append(_line_item)

    def add_mismatch_wall(self, _wall, color=None):
        _wall.set_mismatched(color)
        self.mismatched_wall.append(_wall)

    def get_matched_corners(self):
        return self.matched_corner

    def get_mismatched_corners(self):
        return self.mismatched_corner

    @abstractmethod
    def estimate_trans_matrix(self):
        """
        估计绘图的变换矩阵
        :return:
        """
        pass

    def is_all_matched(self):
        """
        如果没有任何差异墙体就认为是完全匹配.
        :return:
        """
        return len(self.mismatched_wall) == 0 & len(self.mismatched_corner) == 0


class FrameStdVecObj(DiffFrame):

    # json字段名称
    _FLOOR_PLAN_KEY = u'floorplans'
    # 默认楼层=0
    _DEFAULT_FLOOR_IDX = 0
    # 角点字段名称
    _POINT_KEY = u'points'
    # 墙体字段名称
    _LINE_KEY = u'lines'
    # 墙体厚度名称
    _LINE_THICKNESS_KEY = u'thickness'
    # 墙体自动厚度名称
    _LINE_AUTO_THICKNESS_KEY = u'thicknessComputed'
    # 分间字段名称
    _AREA_KEY = u'areas'
    # 分间字段名称
    _LINE_ITEM_KEY = u'lineItems'
    # 分间字段名称
    _ITEM_KEY = u'items'
    _EDGE_KEY = u'edgeComputed'
    _UID_KEY = u'id'
    _TYPE_KEY = u'type'
    _CURVE_KEY = u'curve'
    # 墙体字段
    _LINE_ITEM_START_PT_KEY = u'startPointAt'
    _LINE_ITEM_END_PT_KEY = u'endPointAt'
    _LINE_ITEM_IS_KEY = u'is'
    _LINE_ITEM_ENTRANCE_KEY = u'entrance'
    _LINE_ITEM_LINE_ID = u'line'
    _LINE_ITEM_START = u'start'
    _LINE_ITEM_ROTATE_Y = u'rotateY'
    _LINE_ITEM_ROTATE_X = u'rotateX'

    # 分间字段
    _ROOM_TYPE_KEY = u'roomType'

    # 户型可能存在的位置枚举: [0, 45, 90, 135, 180, 225, 270, 315]
    ROTATIONS = list(range(0, 360, 45))
    # ROTATIONS = [(_/180)*math.pi for _ in (range(0, 360, 45))]

    def __init__(self, frame_json, **kwargs):
        """
        贝壳标准图json
        """
        super(FrameStdVecObj, self).__init__()
        self.frame_id = kwargs.get('frame_id', -1)

        if type(frame_json) is not dict:
            self._load_json(frame_json)
        else:
            self._frame_json = frame_json
        self.dump_frame_json = copy.deepcopy(self._frame_json)
        # Room相对关系描述
        self.room_relation_dict = dict()
        # 所有居室类型
        self.room_type_list = list()

        self._extract_corner()
        self._extract_wall()
        self._extract_line_item()
        self._extract_room()
        # 为了可视化
        self.estimate_trans_matrix()
        # 提取边界
        self.edge_lines, self.edge_pts = self.get_edges()
        # 外围多边形对象
        self.frame_polygon_obj = Polygon([_.coord for _ in self.edge_pts])
        # 外围轮廓对象
        self.frame_polygon_contour_obj = self.frame_polygon_obj.exterior
        # 户型重心
        self.centroid = self.frame_polygon_obj.centroid
        # 角点类型
        self._cal_corner_type()

    def _load_json(self, _frame_json_str):
        try:
            vector_value = json.loads(_frame_json_str)
            if vector_value is None:
                self._state = ce.State.invalid_json_format
            else:
                self._frame_json = vector_value
        except Exception as e:
            print(e)
            self._state = ce.State.invalid_json_format

    def _extract_corner(self):
        """
        提取角点
        :return:
        """
        point_dict = self._frame_json[self._FLOOR_PLAN_KEY][self._DEFAULT_FLOOR_IDX][self._POINT_KEY]
        for _p_idx, _p_dict in enumerate(point_dict):
            _x, _y = int(_p_dict['x']), int(_p_dict['y'])
            _c = Corner(_x, _y, _p_dict[self._LINE_KEY], _p_dict[self._UID_KEY], ori_dict=_p_dict)
            self.corner_list.append(_c)
            self.ori_p_map[_p_dict[self._UID_KEY]] = _c
            self.max_x, self.max_y = max(self.max_x, _x), max(self.max_y, _y)
            self.min_x, self.min_y = min(self.min_x, _x), min(self.min_y, _y)

    def _extract_wall(self):
        """
        提取角点
        :return:
        """
        lines_dict = self._frame_json[self._FLOOR_PLAN_KEY][self._DEFAULT_FLOOR_IDX][self._LINE_KEY]
        wall_objs = []
        for _line_idx, _line_dict in enumerate(lines_dict):
            _pts = _line_dict[self._POINT_KEY]
            _pt1, _pt2 = self.ori_p_map[_pts[0]], self.ori_p_map[_pts[1]]
            # 线上的关联点, 互相加上对方
            _pt1.connected_pts.append((self.ori_p_map[_pts[1]]))
            _pt2.connected_pts.append(self.ori_p_map[_pts[0]])
            # 计算线段夹角
            _line_angle = diff_util.get_relative_angle(_pt1.coord, _pt2.coord)
            thickness = _line_dict.get(self._LINE_THICKNESS_KEY) if _line_dict.get(self._LINE_THICKNESS_KEY) else _line_dict.get(self._LINE_AUTO_THICKNESS_KEY, 240)
            _w = Wall(_pts, _line_dict[self._TYPE_KEY], _line_dict[self._ITEM_KEY],
                      _line_dict[self._EDGE_KEY], _line_dict[self._UID_KEY], self.ori_p_map,
                      angle=_line_angle, ori_dict=_line_dict, curve=_line_dict[self._CURVE_KEY],
                      wall_thickness=thickness)
            self.wall_list.append(_w)
            self.ori_line_map[_line_dict[self._UID_KEY]] = _w
            self.pts_key_to_line_map[frozenset(_pts)] = _w
            self.diluted_wall_id_to_wall[_w.diluted_wall_id] = _w
            wall_objs.append(_w.diluted_wall)
        self.wall_str_tree = STRtree(wall_objs)

    def _extract_line_item(self):
        """
        提取墙体附件
        :return:
        """
        line_items_dict = self._frame_json[self._FLOOR_PLAN_KEY][self._DEFAULT_FLOOR_IDX][self._LINE_ITEM_KEY]
        for _line_item_idx, _line_item_dict in enumerate(line_items_dict):
            # line_item_type, is_type, entrance, start_point, end_point, uid
            line_id = _line_item_dict[self._LINE_ITEM_LINE_ID]
            _w = self.ori_line_map[line_id]
            _w_item = WallItem(_line_item_dict[self._TYPE_KEY], _line_item_dict[self._LINE_ITEM_IS_KEY],
                          _line_item_dict[self._LINE_ITEM_ENTRANCE_KEY], _line_item_dict[self._LINE_ITEM_START_PT_KEY],
                          _line_item_dict[self._LINE_ITEM_END_PT_KEY], line_id, _line_item_dict[self._UID_KEY],
                          rotate_x=_line_item_dict[self._LINE_ITEM_ROTATE_X],
                          rotate_y=_line_item_dict[self._LINE_ITEM_ROTATE_Y], wall_thickness=_w.wall_thickness,
                          start=_line_item_dict[self._LINE_ITEM_START], ori_dict=_line_item_dict)
            if _line_item_dict[self._LINE_ITEM_ENTRANCE_KEY] is not None and self.ori_line_map[line_id].edge_computed:
                # 入户门可能不在外墙上
                self.entrance_item = _w_item
                self.entrance_line = line_id
            self.wall_item_list.append(_w_item)
            self.ori_line_item_map[_line_item_dict[self._UID_KEY]] = _w_item
            _w.line_items.append(_w_item)

    def _extract_room(self):
        """
        提取分间
        :return:
        """
        room_dict_arr = self._frame_json[self._FLOOR_PLAN_KEY][self._DEFAULT_FLOOR_IDX][self._AREA_KEY]
        _tmp_room_obj = []
        _room_obj_id_room = dict()
        for _r_idx, _r_dict in enumerate(room_dict_arr):
            _room_pts = _r_dict['points']
            _real_pts = []
            _pts_angle = []
            _room_lines = []
            _real_lines = []
            # 记录关联
            _r_type = _r_dict[self._ROOM_TYPE_KEY]
            _r = Room(_r_type, _r_dict[self._TYPE_KEY],
                      _r_dict[self._UID_KEY], _r_idx, name=_r_dict['roomName'], ori_dict=_r_dict)
            if _r_type in ROOM_NAME:
                self.room_type_list.append(ROOM_NAME[_r_type])
            # 求每个点的夹角
            cp_pt_arr = [_room_pts[-1]] + _room_pts + [_room_pts[0]]
            for _pt_idx in range(1, len(_room_pts)+1):
                _pt_id = cp_pt_arr[_pt_idx]
                _pt = self.ori_p_map[_pt_id]
                _pt_coord = _pt.coord
                _real_pts.append(_pt_coord)
                _prev_pt_id, _next_pt_id = cp_pt_arr[_pt_idx-1], cp_pt_arr[_pt_idx+1]
                _prev_pt, _next_pt = self.ori_p_map[_prev_pt_id], self.ori_p_map[_next_pt_id]
                _prev_pt_coord, _next_pt_coord = _prev_pt.coord, _next_pt.coord
                _prev_vec, _next_vec = np.array(_prev_pt_coord) - np.array(_pt_coord),  np.array(_next_pt_coord) - np.array(_pt_coord)
                _pt_angle = diff_util.angle_between_vec(_prev_vec, _next_vec)
                _pts_angle.append(abs(np.degrees(_pt_angle)))
                # 点对应逆时针方向的第一条边
                _room_line_pt_id = frozenset([_pt_id, _next_pt_id])
                _room_line = self.pts_key_to_line_map[_room_line_pt_id]
                _room_line.is_dangle = False
                _room_line.room_types.add(_r_dict[self._TYPE_KEY])
                _room_line.rooms.add(_r)
                _real_lines.append(_room_line)
            _r.set_room_lines(_real_lines)
            _r.set_real_pts(_real_pts)
            _r.set_point_angle(_pts_angle)
            _r.set_room_pts(_room_pts)
            _tmp_room_obj.append(_r.obj)
            _room_obj_id_room[id(_r.obj)] = _r
            self.area_size += _r.area_size
            self.area_list.append(_r)
            self.ori_area_map[_r_dict[self._UID_KEY]] = _r
        room_str_tree = STRtree(_tmp_room_obj)
        # 遍历得到断墙所属分间
        for _w in self.wall_list:
            _w_obj = _w.obj
            if _w.is_dangle:
                # 找最近分间
                adj_rooms = room_str_tree.query(_w_obj)
                _len_rooms = []
                for _adj_r in adj_rooms:
                    _w_inter = _adj_r.intersection(_w_obj)
                    _len_rooms.append((_w_inter.length, _adj_r))
                if _len_rooms:
                    _nearest_room_tuple = sorted(_len_rooms, key=lambda x: -x[0])[0]
                    _nearest_room = _room_obj_id_room[id(_nearest_room_tuple[-1])]
                    _w.room_types.add(_nearest_room.room_type)
                    _w.rooms.add(_nearest_room)
                    _nearest_room.room_lines.append(_w)
            pass
        # 计算所有Room的相对关系
        for _r in self.area_list:
            _r_id = _r.uid
            _ori_dict = _r.ori_dict
            _attached_areas = _ori_dict['attachments']['areas']
            for _area in _attached_areas:
                _attached_area_id = _area[self._UID_KEY]
                _room_pair = frozenset({_r_id, _attached_area_id})
                _shared_line_items = _area['sharedLineItems']
                if _room_pair in self.room_relation_dict or len(_shared_line_items) == 0:
                    continue
                _connected_line_items_name = []
                for _line_item_id in _shared_line_items:
                    _item_obj = self.ori_line_item_map[_line_item_id]
                    if _item_obj.is_type == 'window':
                        # 推拉门
                        _connected_line_items_name.append('窗')
                    elif _item_obj.line_item_type == 1:
                        _connected_line_items_name.append('推拉门')
                    elif _item_obj.line_item_type == 16:
                        _connected_line_items_name.append('垭口')
                    else:
                        _connected_line_items_name.append('门')
                _attached_room_obj = self.ori_area_map[_area[self._UID_KEY]]
                # 计算相对关系
                _angle = get_relative_angle(np.array(_attached_room_obj.obj.centroid.coords)[0], np.array(_r.obj.centroid.coords)[0], )
                _direction_desc = get_direction(_angle)
                _desc_text = _r.name + "通过" + "和".join(_connected_line_items_name) \
                                + "连通" + _direction_desc + "方" + _attached_room_obj.name
                self.room_relation_dict[_room_pair] = _desc_text
            pass

    def _cal_corner_type(self):
        """
        计算角点的类别, 计算点特征
        :return:
        """
        _center = self.get_center()
        _entrance_pt = self.entrance_item.center
        for _c in self.corner_list:
            _c_pt = _c.coord
            # 给角点找到对应的墙对象
            for _corner_line_id in _c.line_ids:
                _tmp_wall = self.ori_line_map[_corner_line_id]
                _c.walls.append(_tmp_wall)
                far_pt = _tmp_wall.pts_set - {_c_pt}
                # assert len(far_pt) == 1, 'wall should have only two points'
                if len(far_pt) != 1:
                    # 'wall should have only two points'
                    c_angle = 0
                else:
                    c_angle = diff_util.get_relative_angle(far_pt.pop(), _c_pt)
                _c.walls_angle.append(c_angle)
            # 判断角点类型
            # _c.sorted_angle = sorted(_c.walls_angle)
            for _a in _c.walls_angle:
                _min_idx = np.argmin(np.abs(Corner.ANGLE_TYPE - _a))
                if np.abs(Corner.ANGLE_TYPE[_min_idx] - _c.sorted_angle[_min_idx]) > np.abs(Corner.ANGLE_TYPE[_min_idx] - _a):
                    _c.sorted_angle[_min_idx] = _a
            remain_v = np.abs(_c.sorted_angle - Corner.ANGLE_TYPE)
            _c.p_type = tuple(sorted(np.where(remain_v < Corner.ANGLE_THRESHOLD)[0]))
            # 计算入户门的欧式距离
            _c.entrance_distance = diff_util.p2p_euclidean(_c_pt, _entrance_pt)
            # 计算重心的欧式距离
            _c.centroid_distance = diff_util.p2p_euclidean(_c_pt, list(self.centroid.coords)[0])
            # 计算边界的最近欧式距离
            _c.min_contour_distance = _c.obj.distance(self.frame_polygon_contour_obj)
            _c.relative_coords = [_c_pt[0] - _center[0], _c_pt[1] - _center[1]]

    def extract_common_feature(self):
        points_feature = []
        for _c in self.corner_list:
            _c_vec = _c.get_feature_vec()
            points_feature.append(_c_vec)
        return points_feature

    def estimate_trans_matrix(self):
        """
        估计绘图变换矩阵
        :return:
        """
        _max_size = max(self.max_x - self.min_x, self.max_y - self.min_y)
        _scale = self.DISPLAY_SIZE / _max_size
        self.draw_matrix_dict['a'] = _scale
        self.draw_matrix_dict['e'] = _scale
        self.draw_matrix_dict['xoff'] = -self.min_x * _scale
        self.draw_matrix_dict['yoff'] = -self.min_y * _scale

    def get_edges(self):
        """
        遍历点得到所有边
        :return:
        """
        # 入户门一定在外墙上
        _wall_id = self.entrance_line
        _wall_obj = self.ori_line_map[_wall_id]
        _wall_pt_id = _wall_obj.pts_id[0]
        _wall_pt = self.ori_p_map[_wall_pt_id]
        # 是否闭合
        is_open = True
        visted_lines = [_wall_obj]
        visted_line_ids_set = set([_wall_id])
        visted_pts = [_wall_pt]
        visted_pt_ids_set = set([_wall_pt_id])
        while is_open:
            _pt_ids = _wall_obj.pts_id
            # 遍历当前墙体所有点
            for _line_pt_id in _pt_ids:
                if _line_pt_id == _wall_pt_id and len(visted_pt_ids_set) > 1:
                    is_open = False
                    # 找到了起始点
                    break
                if _line_pt_id in visted_pt_ids_set:
                    # 如果已经访问过就跳过
                    continue
                _new_p = self.ori_p_map[_line_pt_id]
                for _new_p_line_id in _new_p.line_ids:
                    # 未方位点的墙体
                    if _new_p_line_id == _wall_id and len(visted_line_ids_set) > 1:
                        # 找到了起始墙体
                        is_open = False
                        break
                    if _new_p_line_id in visted_line_ids_set:
                        # 避免访问自己
                        continue
                    _tmp_wall_obj = self.ori_line_map[_new_p_line_id]

                    if _tmp_wall_obj.edge_computed:
                        _wall_obj = _tmp_wall_obj
                        visted_lines.append(_wall_obj)
                        for _item_id in _wall_obj.items:
                            _item = self.ori_line_item_map[_item_id]
                            _item.edge_computed = True
                        visted_line_ids_set.add(_new_p_line_id)
                        visted_pts.append(_new_p)
                        visted_pt_ids_set.add(_line_pt_id)
                        break
        return visted_lines, visted_pts

    def dump(self, polygons):
        """
        导出dict
        :param polygons: 需要
        :return:
        """
        self.dump_frame_json[self._FLOOR_PLAN_KEY][self._DEFAULT_FLOOR_IDX][self._POINT_KEY] = [_.dump() for _ in self.corner_list]
        self.dump_frame_json[self._FLOOR_PLAN_KEY][self._DEFAULT_FLOOR_IDX][self._LINE_KEY] = [_.dump() for _ in self.wall_list]
        _tmp_wall_item_dump_list = []
        for _wall_item in self.wall_item_list:
            _tmp_wall_dump = copy.deepcopy(_wall_item.dump())
            # if _wall_item.entrance is not None:
            #     _tmp_wall_dump['entrance'] = None
            _tmp_wall_item_dump_list.append(_tmp_wall_dump)
        self.dump_frame_json[self._FLOOR_PLAN_KEY][self._DEFAULT_FLOOR_IDX][self._LINE_ITEM_KEY] = _tmp_wall_item_dump_list
        self.dump_frame_json[self._FLOOR_PLAN_KEY][self._DEFAULT_FLOOR_IDX][self._AREA_KEY] = [_.dump() for _ in self.area_list]
        self.dump_frame_json[self._FLOOR_PLAN_KEY][self._DEFAULT_FLOOR_IDX]['items'] = []
        if polygons:
            self.dump_frame_json[self._FLOOR_PLAN_KEY][self._DEFAULT_FLOOR_IDX]['polygons'] = polygons
        else:
            self.dump_frame_json[self._FLOOR_PLAN_KEY][self._DEFAULT_FLOOR_IDX]['polygons'] = []
        return self.dump_frame_json

    @property
    def FLOOR_PLAN_KEY(self):
        return self._FLOOR_PLAN_KEY


def get_direction(angle):
    """
    将角度转换成方向
    :param angle:
    :return:
    """
    angle %= 360
    if angle >= 330 or angle <= 30:
        return '右'
    elif 30 < angle < 60:
        return '右上'
    elif 60 <= angle <= 120:
        return '上'
    elif 120 < angle < 150:
        return '左上'
    elif 150 <= angle <= 210:
        return '左'
    elif 210 < angle < 240:
        return '左下'
    elif 240 <= angle <= 300:
        return '下'
    elif 300 < angle < 330:
        return '右下'


def get_relative_angle(end_f_p, f_p, precision=3):
    """
    获取两个点相对于定位点和x轴正向夹角(相反的)
    :param end_f_p:
    :param f_p:
    :param precision:
    :return:
    """
    x_diff = end_f_p[0] - f_p[0]
    y_diff = end_f_p[1] - f_p[1]
    oblique_diff = math.sqrt(x_diff * x_diff + y_diff * y_diff)
    if oblique_diff == 0:
        diff_angle = 0
    else:
        if y_diff < 0:
            diff_angle = 360 - math.acos(x_diff / oblique_diff) * 180 / math.pi
        else:
            diff_angle = math.acos(x_diff / oblique_diff) * 180 / math.pi
    return round(diff_angle, precision)


class DrawJsonError(Exception):
    def __init__(self, url):
        Exception.__init__(self, url)
        self.url = url
