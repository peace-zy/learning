# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/2/17 14:26
# ===================================
from frame_mod_eval.mod_lib.mod_params import ModIndex


class ModDoc(object):
    def __init__(self, **kwargs):
        self.kwargs = kwargs


class ErshouModDoc(ModDoc):
    def __init__(self, reform_name, **kwargs):
        super(ErshouModDoc, self).__init__(**kwargs)
        self.enum_docs = kwargs['ershou_mod_doc'][reform_name]

    @property
    def value_docs(self):
        return self.enum_docs['value_docs']

    @property
    def pos_docs(self):
        return self.enum_docs['pos_docs']


if __name__ == '__main__':
    pass
