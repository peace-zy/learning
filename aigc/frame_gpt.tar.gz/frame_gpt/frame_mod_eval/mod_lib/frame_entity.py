# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/3/2 16:31
# ===================================
from __future__ import division
import copy
import math

import frame_mod_eval.mod_lib.mod_params as MP
import frame_mod_eval.mod_lib.mod_tools as MT
from frame_mod_eval.mod_lib.room_entity import RoomFactory
from frame_mod_eval.mod_lib.mod_tools import OtherTools


class FrameObj(object):
    def __init__(self, frame, **kwargs):
        """
        户型扩展类.
        :param frame: 通过frame_diff模块下frame_diff方法返回的户型对象
        :param kwargs: 参数字典，传入户型特征、标签、格局等变量
        :return:
        """
        self.__dict__.update(frame.__dict__)
        # 户型面积, 该面积被标准化为平方米为单位
        self.area_size = OtherTools.cal_std_area(frame.area_size)
        # 调用户型解读的case_study得到的户型特征字典，features_opposite为对比的户型特征字典, id_opposite为对比户型的frame_id
        self.features = kwargs['features']
        self.features_opposite = kwargs['features_opposite']
        self.id_opposite = kwargs['id_opposite']
        # 长度为4的列表，代表该户型室厅厨卫数量
        self.structure = [self.features[u'whole'][0][u'shi'], self.features[u'whole'][0][u'ting'],
                          self.features[u'whole'][0][u'chu'], self.features[u'whole'][0][u'wei']]
        # 该户型所包含的所有分间类对象
        self.room_list = []
        pass

    @property
    def extra_feature_dict(self):
        """
        该户型的特征字典.
        :param:
        :return: 返回字典，key=frame_id + area_id，value为包含面宽、进深、朝向和分间面积的字典
        """
        ef_dict = dict()
        for _, _value in self.features.items():
            for _fea_dic in _value:
                if _fea_dic.get('area_id', '') == '':
                    continue

                ef_dict[self.frame_id.decode('utf8') + _fea_dic['area_id']] = {
                    'width': _fea_dic.get('width', 0),
                    'depth': _fea_dic.get('depth', 0),
                    'face': _fea_dic.get('face', ''),
                    'area_size': _fea_dic.get('area_size', 0),
                    'cluster_room_label': _fea_dic.get('cluster_room_label', '')
                }
        for _, _value in self.features_opposite.items():
            for _fea_dic in _value:
                if _fea_dic.get('area_id', '') == '':
                    continue
                ef_dict[self.id_opposite.decode('utf8') + _fea_dic['area_id']] = {
                    'width': _fea_dic.get('width', 0),
                    'depth': _fea_dic.get('depth', 0),
                    'face': _fea_dic.get('face', ''),
                    'area_size': _fea_dic.get('area_size', 0),
                    'cluster_room_label': _fea_dic.get('cluster_room_label', '')
                }
        return ef_dict

    def cal_related_room(self, **kwargs):
        """
        计算与本分间相关的分间，包括吃掉了哪个分间的面积，被哪些分间吃掉了面积
        """
        RF = RoomFactory()
        for _room_iter in self.area_list:
            # 生成分间的扩展类RoomObj对象
            _extra_features = self.extra_feature_dict[self.frame_id.decode('utf8') + _room_iter.uid]
            # _extra_features = self.extra_feature_dict[self.frame_id + _room_iter.uid]
            _params_dict = dict()
            _params_dict['extra_features'] = _extra_features
            _params_dict['trans_matrix_1d'] = self.trans_matrix_1d
            _room = RF.get_object(_room_iter, **_params_dict)
            self.room_list.append(_room)
            # 遍历该分间匹配到的分间，搜索所有吃掉自己面积的分间对象，存入passive列表
            for _match in _room.matched_obj:
                # 相交小于阈值的则认为二者不相交
                if _match[1] <= kwargs['threshold_area_match']:
                    continue
                # 生成匹配分间的扩展类RoomObj对象
                _extra_features = self.extra_feature_dict[self.id_opposite.decode('utf8') + _match[0].uid]
                _params_dict = dict()
                _params_dict['extra_features'] = _extra_features
                _match_room = RF.get_object(_match[0], **_params_dict)
                _match_room.intersect_area = OtherTools.cal_std_area(_match[1])

                # 判断两个分间类型是否相同, 将当前分间匹配到的同类型面积最大的分间作为变换后的自己，即room_same_class
                _flag = (_room.detail_type == _match_room.detail_type) or (_room.room_type == _match_room.room_type and _room.room_type == MP.RoomClassEnum.parlor.value)
                if not _flag:
                    _room.passive.append(_match_room)
                else:
                    if _room.room_same_class is None:
                        _room.room_same_class = _match_room
                    else:
                        if _match_room.intersect_area <= _room.room_same_class.intersect_area:
                            _room.passive.append(_match_room)
                        else:
                            _room.passive.append(_room.room_same_class)
                            _room.room_same_class = _match_room

            # 如果_room.room_same_class为None，则代表该分间改造后消失
            if _room.room_same_class is None:
                continue
            # 遍历该分间匹配到的分间，搜索所有自己吃掉面积的分间对象，存入proactive列表
            for _match in _room.room_same_class.matched_obj:
                # 如果当前分间和_match是同一个分间、或者不是同一分间但相交小于阈值的则认为二者不相交
                if _room.uid == _match_room.uid or _match[1] < kwargs['threshold_area_match']:
                    continue
                _extra_features = self.extra_feature_dict[self.frame_id.decode('utf8') + _match[0].uid]
                _params_dict = dict()
                _params_dict['extra_features'] = _extra_features
                _match_room = RF.get_object(_match[0], **_params_dict)
                _match_room.intersect_area = OtherTools.cal_std_area(_match[1])
                _room.proactive.append(_match_room)

    def collect_whole_polygons(self, **kwargs):
        def point_dis(point1, point2):
            # 计算两点之间欧式距离
            return math.sqrt((point1[0] - point2[0])**2 + (point1[1] - point2[1])**2)

        def judge_almost_match_wall(line):
            matched_list = list(line.matched_obj)
            line_match = None
            p1s, p1e = tuple(), tuple()
            p2s, p2e = tuple(), tuple()
            length1 = 0
            length2 = 0
            line_item_list1 = list()
            line_item_list2 = list()
            if len(matched_list) >= 1:
                length1 = line.length
                [p1s, p1e] = sorted(line.coord)
                line_item_list1 = line.line_items
                point_list = list()
                for _match in matched_list:
                    point_list += _match.coord
                    length2 += _match.length
                    line_item_list2 += _match.line_items
                point_list = sorted(point_list)
                p2s, p2e = point_list[0], point_list[-1]

            if abs(length1 - length2) / length1 > 0.3:
                return True

            item_ratio1 = dict()
            item_ratio2 = dict()
            for _item in line_item_list1:
                item_p = ((_item.coord[0][0] + _item.coord[1][0]) / 2, (_item.coord[0][1] + _item.coord[1][1]) / 2)
                ratio = point_dis(item_p, p1s) / length1
                item_ratio1[_item.line_item_type] = ratio

            for _item in line_item_list2:
                item_p = ((_item.coord[0][0] + _item.coord[1][0]) / 2, (_item.coord[0][1] + _item.coord[1][1]) / 2)
                ratio = point_dis(item_p, p2s) / length2
                item_ratio2[_item.line_item_type] = ratio

            keys1 = set(item_ratio1.keys())
            keys2 = set(item_ratio2.keys())
            if keys1 != keys2:
                return True
            for _key, _value in item_ratio1.items():
                if abs(item_ratio2[_key] - _value) > 0.1:
                    return True
            return False

        draw_img_config = kwargs
        line_list = list()
        for _line in self.wall_list:
            if _line.edge_computed is True:
                continue
            # 如果两个墙体匹配的话，需要保证附件完全相同，否则也要标记
            if _line.is_matched is True:
                fujian1 = set()
                for _item in _line.line_items:
                    fujian1.add(_item.line_item_type)
                fujian2 = set()
                line_match = list(_line.matched_obj)[0]
                for _item in line_match.line_items:
                    fujian2.add(_item.line_item_type)
                if fujian1 != fujian2:
                    line_list.append(copy.deepcopy(_line))
                continue
            # 如果两个墙体不匹配的话，要标记
            if _line.is_matched is False and _line.is_almost_matched is False:
                line_list.append(copy.deepcopy(_line))
                continue
            # 如果两个墙体半匹配的话，需要保证附件完全相同，否则也要标记
            if _line.is_almost_matched is True is judge_almost_match_wall(_line):
                line_list.append(copy.deepcopy(_line))
                continue

        polygons_list = MT.ImgTools.get_draw_poly(line_list, obj_type='line',
                                                  color=draw_img_config['line_color_changed'], fill="transparent",
                                                  opacity=draw_img_config['line_opacity_changed'])
        return polygons_list


if __name__ == '__main__':
    pass
