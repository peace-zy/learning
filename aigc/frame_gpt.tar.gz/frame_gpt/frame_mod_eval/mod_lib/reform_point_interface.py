# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/2/17 14:30
# ===================================
from abc import ABCMeta, abstractmethod

from frame_mod_eval.mod_lib.mod_params import ModIndex
from frame_mod_eval.mod_lib.mod_doc import ModDoc
from frame_mod_eval.mod_lib.mod_image import ModPolygon


class IReformPoint(object):
    __metaclass__ = ABCMeta

    def __init__(self, **kwargs):
        # 改造点编号及名称
        self.reform_id = ModIndex.Others.value
        self.reform_name = ModIndex.Others.name

        # 改造点polygon以及文案
        self.modPolygons = ModPolygon(**kwargs)
        self.modDocs = ModDoc(**kwargs)

        # 其余参数
        self.kwargs = kwargs

    @abstractmethod
    def judge_is_valid(self):
        return False

    @abstractmethod
    def solve(self):
        pass


if __name__ == '__main__':
    pass
