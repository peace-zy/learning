# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2021/11/2 19:55
# ===================================
from enum import Enum


class ModIndex(Enum):
    Others = 0
    LivingroomChangeBedroom = 1 << 0  # 客厅改卧室
    BedroomAddBedroom = 1 << 1
    BedroomAddToilet = 1 << 2
    BedroomAddCloakroom = 1 << 3
    BedroomChangeLivingroom = 1 << 7  # 卧室改客厅
    LivingroomAddCloakroom = 1 << 8
    KitchenAddArea = 1 << 9  # 扩大厨房
    ToiletDryWet = 1 << 10  # 干湿分离

    AddBedroom = 1 << 11  # 增加居室
    SubBedroom = 1 << 12  # 减少居室
    AddToilet = 1 << 13  # 增加卫生间
    AddCloakroom = 1 << 14  # 增加衣帽间
    AddStorage = 1 << 15  # 增加储物间
    ToiletAddArea = 1 << 16  # 扩大卫生间
    BedroomAddArea = 1 << 17  # 扩大卧室
    SubToilet = 1 << 18  # 减少卫生间
    LivingroomAddLighting = 1 << 19  # 客厅增加采光
    AddDiningArea = 1 << 20  # 增加用餐区
    AddStudy = 1 << 21  # 增加书房
    KitchenChangeDoor = 1 << 22  # 改厨房门
    ToiletChangeDoor = 1 << 23  # 改卫生间门


class ModIndexSpare(Enum):
    Others = 0
    LivingroomChangeBedroom = 0  # 客厅改卧室
    BedroomAddBedroom = 0
    BedroomAddToilet = 0
    BedroomAddCloakroom = 0
    BedroomChangeLivingroom = 0  # 卧室改客厅
    LivingroomAddCloakroom = 0
    KitchenAddArea = 0  # 扩大厨房
    ToiletDryWet = 0  # 干湿分离

    AddBedroom = 0  # 增加居室
    SubBedroom = 0  # 减少居室
    AddToilet = 0  # 增加卫生间
    AddCloakroom = 0  # 增加衣帽间
    AddStorage = 0  # 增加储物间
    ToiletAddArea = 0  # 扩大卫生间
    BedroomAddArea = 0  # 扩大卧室
    SubToilet = 0  # 减少卫生间
    LivingroomAddLighting = 0  # 客厅增加采光
    AddDiningArea = 0  # 增加用餐区
    AddStudy = 0  # 增加书房
    KitchenChangeDoor = 0  # 改厨房门
    ToiletChangeDoor = 0  # 改卫生间门


class RoomNameEnum(Enum):
    others = 0  # 其他房间
    living_room = 1  # 客厅
    dining_room = 2  # 餐厅
    bedroom = 3  # 卧室
    study = 4  # 书房
    toilet = 5  # 卫生间
    kitchen = 8  # 厨房
    open_kitchen = 9  # 开放厨房
    cloakroom = 15  # 衣帽间
    hallway = 25  # 门厅
    lounge = 37  # 起居室
    mainroom = 38  # 主卧
    secondary_bedroom = 39  # 次卧


class VarName(Enum):
    AREA_ID_KEY = 'area_id'
    AREA_KEY = 'areas'
    AREA_SIZE_KEY = 'area_size'

    CURVE_KEY = 'curve'

    DEPTH_KEY = 'depth'

    EDGE_KEY = 'edgeComputed'
    EXTRA_FEATURES = 'extra_features'

    FACE_KEY = 'face'
    FEATURES_KEY = 'features'
    FEATURES_OPPOSITE_KEY = 'features_opposite'
    FLOOR_PLAN_KEY = 'floorplans'

    ITEM_KEY = 'items'

    ID_OPPOSITE_KEY = 'id_opposite'

    LINE_AUTO_THICKNESS_KEY = 'thicknessComputed'
    LINE_ITEM_START_PT_KEY = 'startPointAt'
    LINE_ITEM_END_PT_KEY = 'endPointAt'
    LINE_ITEM_IS_KEY = 'is'
    LINE_ITEM_ENTRANCE_KEY = 'entrance'
    LINE_ITEM_LINE_ID = 'line'
    LINE_ITEM_START = 'start'
    LINE_ITEM_ROTATE_Y = 'rotateY'
    LINE_ITEM_ROTATE_X = 'rotateX'
    LINE_ITEM_KEY = 'lineItems'
    LINE_KEY = 'lines'
    LINE_THICKNESS_KEY = 'thickness'

    POINT_KEY = 'points'

    ROOM_LABEL = 'cluster_room_label'
    ROOM_TYPE_KEY = 'roomType'

    THRESHOLD_AREA_MATCH_KEY = 'threshold_area_match'
    TYPE_KEY = 'type'

    UID_KEY = 'id'

    WIDTH_KEY = 'width'


class RoomClassEnum(Enum):
    bedroom = '100900000001'
    parlor = '100900000002'
    kitchen = '100900000003'
    toilet = '100900000004'
    storage = '100900000008'
    cloakroom = '100900000013'


ROOM_NAME = {
    '100900000001': '室',
    '100900000002': '厅',
    '100900000003': '厨',
    '100900000004': '卫',
    '100900000005': '阳台',
    '100900000006': '露台',
    '100900000007': '花园',
    '100900000008': '储物间',
    '100900000009': '保姆间',
    '100900000010': '车库',
    '100900000011': '阁楼',
    '100900000012': '其他',
    '100900000013': '衣帽间'
}
SUB_ROOM_NAME = {
    0:   ('其他', '100900000012', -1),
    1:   ('客厅', '100900000002', 48),
    2:   ('餐厅', '100900000002', 48),
    3:   ('卧室', '100900000001', 47),
    4:   ('书房', '100900000001', -1),
    5:   ('卫生间', '100900000004', 50),
    6:   ('淋浴间', '100900000004', -1),
    7:   ('洗手间', '100900000004', -1),
    8:   ('厨房', '100900000003', 49),
    9:   ('开放厨房', '100900000003', -1),
    10:  ('多功能间', '100900000001', -1),
    11:  ('保姆间', '100900000009', -1),
    12:  ('阳台', '100900000005', -1),
    13:  ('露台', '100900000006', -1),
    14:  ('储物间', '100900000008', -1),
    15:  ('衣帽间', '100900000013', -1),
    16:  ('阁楼', '100900000011', -1),
    17:  ('花园', '1100900000007', -1),
    18:  ('车库', '1100900000010', -1),
    19:  ('电梯', '100900000012', -1),
    20:  ('地下室', '100900000012', -1),
    21:  ('天井', '100900000012', -1),
    22:  ('阳光房', '100900000012', -1),
    23:  ('过道', '100900000012', -1),
    24:  ('楼梯间', '100900000012', -1),
    25:  ('门厅', '100900000002', 48),
    26:  ('入户花园', '100900000012', -1),
    27:  ('玄关', '100900000012', -1),
    28:  ('挑空', '100900000012', -1),
    29:  ('晾晒区', '100900000012', -1),
    30:  ('洗衣房', '100900000012', -1),
    31:  ('娱乐区', '100900000012', -1),
    32:  ('健身区', '100900000012', -1),
    33:  ('接待区', '100900000012', -1),
    34:  ('影音区', '100900000012', -1),
    35:  ('餐饮区', '100900000012', -1),
    36:  ('其他', '100900000012', -1),
    37:  ('起居室', '100900000002', 48),
    38:  ('主卧', '100900000001', 47),
    39:  ('次卧', '100900000001', -1),
    40:  ('优化间', '100900000001', -1),
    41:  ('办公室', '100900000001', -1),
    42:  ('会议室', '100900000001', -1),
    43:  ('洽谈间', '100900000001', -1),
    44:  ('共享大厅', '100900000002', 48),
    45:  ('水吧', '100900000012', -1)
}

THRESHOLD_AREA_MATCH = 1.1
THRESHOLD_ANNEX = 0.945
THRESHOLD_PARTITION = 0.52
THRESHOLD_NIBBLE = 0.4
THRESHOLD_EXPAND = 0.4


if __name__ == '__main__':
    pass
