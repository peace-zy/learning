# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2021/11/3 14:36
# ===================================

import json
import random

import requests
from PIL import Image
import time

from io import BytesIO
import frame_mod_eval.utils.room_doc_param as RDP
from frame_mod_eval.utils import upload_util
from frame_mod_eval.entity.frame_diff_entity import DrawJsonError


class OtherTools(object):
    @staticmethod
    def cal_std_area(area_size_origin):
        """
        将面积单位标准化为平方米
        :param area_size_origin: 分间面积
        :return: 单位为平方米的分间面积，保留两位小数
        """
        if area_size_origin > 1e3:
            area_size_origin = area_size_origin * 1e-6
        return round(area_size_origin, 2)

    @staticmethod
    def timer(func):
        # 传入的参数是一个函数
        def deco(*args, **kwargs):
            # 本应传入运行函数的各种参数
            print('\n函数：{_funcname_}开始运行：'.format(_funcname_=func.__name__))
            start_time = time.time()
            # 调用代运行的函数，并将各种原本的参数传入
            res = func(*args, **kwargs)
            end_time = time.time()
            print('函数:{_funcname_}运行了 {_time_}秒'.format(_funcname_=func.__name__, _time_=(end_time - start_time)))
            # 返回值为函数的运行结果
            return res

        # 返回值为函数
        return deco

    @staticmethod
    def cal_room_lines_commen(room1, room2):
        """
        计算两个分间墙体的交集
        :param room1: 第一个分间
        :param room2: 第二个分间
        :return: 两个分间相交的墙体列表
        """
        return list(set(room1.room_lines).intersection(set(room2.room_lines)))

    @staticmethod
    def judge_toilet_rational(toilet_room, line_id_dict):
        """
        判断新增卫生间的合理性，新建卫生间需要与已存在的卫生间有相邻墙体
        :param toilet_room: 卫生间分间对象
        :param line_id_dict: 墙体id字典
        :return: 布尔值，true表示合理，false表示不合理
        """
        for _line in toilet_room.room_lines:
            related_type = line_id_dict.get(_line.uid, None)
            if related_type is None:
                continue
            related_room_type1 = related_type[2]
            related_room_type2 = related_type[3]
            if related_room_type1 == related_room_type2:
                return True
        return False


class ImgTools(object):
    @staticmethod
    def get_img_url(frame_id):
        """
        获取图片的url
        :param frame_id: 户型id
        :return: 该户型图片对应的url
        """
        prefix = r'http://storage.lianjia.com/'
        import web_server.api_lib as api_lib
        appkey = 'frame_analysis'
        secret = 'c338b06a92d4400edcbf11c03979241a'
        frame_miner_url = r'http://i.data.api.lianjia.com/v2/meta/frame_miner'
        url = '888'
        if frame_id != '888':
            r = api_lib.request_bigdata_api(frame_miner_url,
                                            {'frame_ids': frame_id},
                                            key=appkey,
                                            secret=secret)
            if r['data']:
                url = r['data'][0]['image_url']
        if url[0:4] != 'http':
            url = prefix + url
        return url

    @staticmethod
    def draw_json(frameX_vector, hide_compass=True, show=True, save_path=None, url='http://10.200.40.29:8898/print-polygon'):
        frame_json_str = json.dumps(frameX_vector)
        payload = {
            'source': frame_json_str,
            "pngSize": '1440x1080',
            'hideCompass': hide_compass,
        }
        try:
            res = requests.post(url, data=payload)
            img_bytes = res.content
            img = Image.open(BytesIO(img_bytes))
        except Exception as e:
            raise DrawJsonError(url)
        if show:
            img.show()
        if save_path:
            img.save(save_path)
        else:
            data_result = upload_util.upload_s3_img('12321', img_bytes)
            return data_result
        return img

    @staticmethod
    def get_draw_poly(obj_list, obj_type='line', color="#FF0000", fill="transparent", opacity=1.0, stroke_width=2.5):
        """
        获取绘图对象对应的多边形
        :param obj_list: 需要颜色标注的对象列表
        :param obj_type:
        :return:
        """
        draw_poly = []
        for _obj in obj_list:
            if obj_type == 'line':
                tmp = _obj.get_paired_wall_polygon()
            elif obj_type == 'room':
                tmp = _obj.get_room_polygon_pts()
            elif obj_type == 'lineitem':
                tmp = _obj.get_paired_wall_polygon()
            _convert = []
            for _ele in tmp:
                _convert.append({"x": _ele[0], "y": _ele[1]})
            draw_poly.append({"points": _convert, "stroke": color, "fill": fill, "opacity": opacity, "stroke-width": stroke_width})
        return draw_poly

    @staticmethod
    def add_color_to_other_rooms(not_find_match, frame, draw_img_config):
        """
        将多幅本地图片拼接成同一幅图片
        :param not_find_match: 变化的分间列表
        :param frame: 分间所在的户型
        :param draw_img_config: 颜色参数
        :return:
        """
        for _all_room in frame.room_list:
            # 通过下面的流程将没有变化的分间筛选出来
            _this_room1 = ImgTools.get_draw_poly([_all_room], obj_type='room', color=draw_img_config['area_color_origin'], fill=draw_img_config['area_color_origin'], opacity=draw_img_config['area_opacity_origin'])
            _this_room2 = ImgTools.get_draw_poly([_all_room], obj_type='room', color=draw_img_config['area_color_add'], fill=draw_img_config['area_color_add'], opacity=draw_img_config['area_opacity_add'])
            _flag = 0
            for _room_tmp in not_find_match:
                if _this_room1[0] == _room_tmp or _this_room2[0] == _room_tmp:
                    _flag = 1
                    break
            # 当_flag为1时分间为变化的分间
            if _flag == 1:
                continue
            # 没有变化的分间
            _this_room1[0]['stroke'] = draw_img_config['area_color_others']
            _this_room1[0]['fill'] = draw_img_config['area_color_others']
            _this_room1[0]['opacity'] = draw_img_config['area_opacity_others']
            not_find_match = not_find_match + _this_room1
        return not_find_match

    @staticmethod
    def splice_image_in_oneline(img_path_list, save_path, resolution=(512, 512)):
        """
        将多幅本地图片拼接成同一幅图片
        :param img_path_list: 图片路径列表
        :param save_path: 保存路径
        :param resolution: 分辨率
        :return:
        """
        list_size = len(img_path_list)
        target = Image.new('RGB', (resolution[0] * list_size, resolution[1]))
        left_top = [0, 0]
        right_down = [resolution[0], resolution[1]]
        for _img_path in img_path_list:
            _img = Image.open(_img_path)
            target.paste(_img, tuple(left_top + right_down))
            left_top[0] = left_top[0] + resolution[0]
            right_down[0] = right_down[0] + resolution[0]
        target.save(save_path)


class NameTools(object):
    @staticmethod
    def face_engname_to_std_name(origin_face):
        """
        朝向字段英文转中文
        :param origin_face: 分间朝向英文
        :return: 分间朝向中文
        """
        if isinstance(origin_face, unicode):
            origin_face = origin_face.encode('utf8')
        if origin_face == 'south':
            return '南'
        elif origin_face == 'north':
            return '北'
        elif origin_face == 'east':
            return '东'
        elif origin_face == 'west':
            return '西'
        elif origin_face == 'north-west':
            return '西北'
        elif origin_face == 'north-east':
            return '东北'
        elif origin_face == 'south-east':
            return '东南'
        elif origin_face == 'south-west':
            return '西南'
        return origin_face

    @staticmethod
    def face_std_name_to_engname(origin_face):
        """
        朝向字段中文转英文
        :param origin_face: 分间朝向汉语
        :return: 分间朝向英文
        """
        if isinstance(origin_face, unicode):
            origin_face = origin_face.encode('utf8')
        if origin_face == '南':
            return 'south'
        elif origin_face == '北':
            return 'north'
        elif origin_face == '东':
            return 'east'
        elif origin_face == '西':
            return 'west'
        elif origin_face == '西北':
            return 'north-west'
        elif origin_face == '东北':
            return 'north-east'
        elif origin_face == '东南':
            return 'south-east'
        elif origin_face == '西南':
            return 'south-west'
        return origin_face

    @staticmethod
    def room_std_name_to_engname(origin_name):
        if isinstance(origin_name, unicode):
            origin_name = origin_name.encode('utf8')
        if '卧' in origin_name:
            return 'bedroom'
        elif '卫' in origin_name:
            return 'toilet'
        elif '阳' in origin_name:
            return 'balcony'
        elif '厨' in origin_name:
            return 'kitchen'
        elif '客厅' in origin_name:
            return 'livingroom'
        elif '起居' in origin_name:
            return 'livingroom'
        elif '储' in origin_name:
            return 'storageroom'
        elif '衣帽' in origin_name:
            return 'cloakroom'
        elif '门厅' in origin_name:
            return 'hall'
        elif '过道' in origin_name:
            return 'aisle'
        elif '餐' in origin_name:
            return 'diningroom'
        else:
            return origin_name


class DrawUrlSampling(object):
    def __init__(self, url_dict):
        """
        :param url_dict: 画图url-core字典
        """
        self.url_dict = url_dict

    @property
    def random_list(self):
        random_list = list()
        for _url, _core in self.url_dict.items():
            random_list = random_list + _core * [_url]
        return random_list

    def get_url(self):
        url = random.choice(self.random_list)
        return url

    def add_url(self, url, core):
        self.url_dict[url] = core

    def del_url(self, url):
        if url in self.url_dict:
            self.url_dict.pop(url)


def sample_valid_url(current_optional_urls):
    """
    从绘图的list中采样一个可用的
    :param current_optional_urls:
    :return:
    """
    if len(current_optional_urls) == 0:
        return None
    random_list = list()
    for _url, _core in current_optional_urls.items():
        random_list = random_list + _core * [_url]
    if len(random_list) == 0:
        return None
    url = random.choice(random_list)
    return url


if __name__ == '__main__':
    pass
