# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/2/15 11:47
# ===================================
from collections import defaultdict
from frame_mod_eval.mod_lib.mod_tools import ImgTools


class ModPolygon(object):
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.polygonsA = list()
        self.polygonsB = list()

    def set_polygons(self, line_obj_list, polygon_type='line', belong_to='B', **draw_params):
        line_polygons = ImgTools.get_draw_poly(line_obj_list,
                                               obj_type=polygon_type,
                                               fill=draw_params['fill'],
                                               color=draw_params['color'],
                                               opacity=draw_params['opacity'])
        if belong_to == 'A':
            self.polygonsA += line_polygons
        elif belong_to == 'B':
            self.polygonsB += line_polygons


class SecondHandModPolygon(ModPolygon):
    def __init__(self, **kwargs):
        super(SecondHandModPolygon, self).__init__(**kwargs)


if __name__ == '__main__':
    pass
