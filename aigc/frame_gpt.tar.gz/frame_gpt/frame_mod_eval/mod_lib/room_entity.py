# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/3/2 11:01
# ===================================
import sys
import inspect
from abc import ABCMeta, abstractmethod
from collections import defaultdict

import frame_mod_eval.mod_lib.mod_params as MP
import frame_mod_eval.entity.frame_diff_entity as FDE
from frame_mod_eval.mod_lib.mod_tools import OtherTools
from frame_mod_eval.mod_lib.mod_params import VarName


class RoomFactory(object):
    def __init__(self, **kwargs):
        self.kwargs = kwargs

    @property
    def ClassDict(self):
        class_list = inspect.getmembers(sys.modules[__name__])
        class_dict = {_name: _class for _name, _class in class_list}
        return class_dict

    @staticmethod
    def get_room_name(room_type):
        room_dict = defaultdict(lambda: 'RoomObj')
        room_dict.update({
            '100900000001': 'BedRoom',
            '100900000002': 'LivingRoom',
            '100900000003': 'Kitchen',
            '100900000004': 'Toilet'
        })
        return room_dict[room_type]

    def get_object(self, Room, **kwargs):
        ReformPointName = self.get_room_name(Room.room_type)
        # if ReformPointName not in self.ClassDict:
        #     raise NotImplementedError('class {} has not been implement'.format(ReformPointName))
        class_obj = self.ClassDict[ReformPointName](Room, **kwargs)
        return class_obj


class RoomObj(object):
    __metaclass__ = ABCMeta

    all_reform_point_name = list()

    def __init__(self, room, **kwargs):
        """
        分间扩展类.
        :param room: 通过frame_diff_entity模块下Room方法返回的分间对象
        :param kwargs: 参数字典，传入分间特征、权重
        :return:
        """
        self.__dict__.update(room.__dict__)

        extra_features = kwargs['extra_features']
        self.trans_matrix_1d = kwargs.get('trans_matrix_1d', [1, 0, 0, 1, 0, 0])
        if self.trans_matrix_1d is None:
            self.trans_matrix_1d = [1, 0, 0, 1, 0, 0]
        # 面宽、进深、朝向、面积
        self.width = extra_features.get('width', -1)
        self.depth = extra_features.get('depth', -1)
        self.area_size = OtherTools.cal_std_area(self.area_size)
        # 分间标准名称、权重
        self.std_name = MP.SUB_ROOM_NAME[self.detail_type][0]
        if isinstance(self.name, unicode):
            self.name = self.name.encode('utf8')

        # 该分间被哪些分间吃掉了面积
        self.passive = []
        # 该分间吃掉了哪些分间的面积
        self.proactive = []
        # 该分间变成了对面户型的哪个分间，如果该分间改造后消失则为None
        self.room_same_class = None
        # 该分间与对面户型某个相交分间的交叠面积
        self.intersect_area = 0

        self.reform_point_list = list()
        self.kwargs = kwargs

    def get_room_polygon_pts(self):
        return list(self.obj.boundary.coords)

    @property
    def intersect_ratio(self):
        # 该分间与对面户型某个相交分间的交叠面积/该分间的面积
        return round(self.intersect_area/self.area_size, 2)

    @property
    def intersect_abs_area(self):
        # |该分间与对面户型某个相交分间的交叠面积 - 该分间面积|
        return abs(self.intersect_area - self.area_size)

    @property
    def line_id_dict(self):
        """
        该分间所有墙体关联分间的字典.
        :return: 返回字典，key = 墙体id，value = (分间1名称，分间2名称)，如果为外墙则不存储
        """
        id_dict = dict()
        for _line in self.room_lines:
            _related = list(_line.rooms)
            if len(_related) < 2:
                continue
            id_dict[_line.uid] = (_related[0].name, _related[1].name, _related[0].detail_type, _related[1].detail_type)
        return id_dict

    @classmethod
    def get_all_reform_point(cls, **kwargs):
        # 通过传入的参数获取该分间相关的改造点
        cls.all_reform_point_name = kwargs.get(cls.__name__, list())

    def detect_reform_point(self, **kwargs):
        """
        分间检测各自的改造点
        :param kwargs: 参数列表
        """
        # 计算该分间下的所有改造点
        if kwargs.get('ReformPointFactory', None) is None:
            raise KeyError("You should transfer a variable called ReformPointFactory")
        ReformPointFactory = kwargs['ReformPointFactory']
        kwargs['self_room'] = self
        kwargs['room_same_class'] = self.room_same_class
        for _reform_point_name in self.all_reform_point_name:
            reform_point = ReformPointFactory.get_object(_reform_point_name, **kwargs)
            res = reform_point.solve(**kwargs)
            if res is None:
                continue
            self.reform_point_list.append(res)


class BedRoom(RoomObj):
    def __init__(self, room, **kwargs):
        super(BedRoom, self).__init__(room, **kwargs)


class LivingRoom(RoomObj):
    def __init__(self, room, **kwargs):
        super(LivingRoom, self).__init__(room, **kwargs)


class Kitchen(RoomObj):
    def __init__(self, room, **kwargs):
        super(Kitchen, self).__init__(room, **kwargs)


class Toilet(RoomObj):
    def __init__(self, room, **kwargs):
        super(Toilet, self).__init__(room, **kwargs)

    def judge_have_dangle_wall(self):
        for _line in self.room_lines:
            if _line.is_dangle:
                return True
        return False


if __name__ == '__main__':
    pass
