# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/3/2 15:33
# ===================================
import json

import frame_mod_eval.utils.frame_diff as FD
import frame_eval.frame_tag_lib.utils as tag_utils

from lib import diff_util
from frame_eval.frame_tag_lib import spark_main_feature
from frame_mod_eval.entity import frame_diff_entity as ent
from frame_mod_eval.mod_lib.frame_entity import FrameObj
from frame_mod_eval.mod_toB.room_diff_toB import FrameDiffEval
from frame_mod_eval.mod_toB.reform_point_interface_toB import ReformPointToBFactory


def extract_basic_features(frame, config_params):
    frame_id, line = tag_utils.get_frame_vector(frame)
    frame, result = tag_utils.get_whole_frame_info(line, config_params["explain_params"], spark_main_feature.get_result, spark_main_feature.update_basic2frame)

    features = result[1]
    if features != "":
        features = json.loads(result[1])

    return features


def generate_reform_point(frame_id1, frame_id2, **params):
    """
    :param frame_id1: 改前户型
    :param frame_id2: 改后户型
    :param params: 改造参数
    :return [改造类对象、户型旋转状态status_diff、旋转后原户型Json]
    """
    [frame_json_a] = params.get('frame_json_a', diff_util.download_frame_json([frame_id1], with_json=False))
    [frame_json_b] = params.get('frame_json_b', diff_util.download_frame_json([frame_id2], with_json=False))
    # frame_diff里面计算两户型的分间、墙体、附件的diff主流程
    frame_a = ent.FrameStdVecObj(frame_json_a, frame_id=frame_id1)
    frame_b = ent.FrameStdVecObj(frame_json_b, frame_id=frame_id2)
    frame_a_2, frame_b_2, status_diff = FD.frame_diff(frame_a, frame_b)
    if status_diff < 0:
        return [None, status_diff, json.dumps(frame_a_2.dump([]))]
    # display_frame_pairs(frame_a, frame_b, display=False)

    features_a = params.get('features_a', extract_basic_features(frame_id1, params))
    features_b = params.get('features_b', extract_basic_features(frame_id2, params))

    try:
        if features_a == '' or features_b == '':
            raise Exception("frame features is an empty string")
    except Exception as e:
        print(repr(e))

    if not isinstance(features_a, dict):
        features_a = json.loads(features_a)
    if not isinstance(features_b, dict):
        features_b = json.loads(features_b)

    # 初始化原户型和改后户型的FrameObj对象，以及FrameDiffEval对象, 调用cal_related_room()函数计算吃掉对面的谁和被对面的谁吃掉
    params_dict = {'features': features_a, 'features_opposite': features_b, 'id_opposite': frame_id2}
    frame_a = FrameObj(frame_a_2, **params_dict)
    frame_a.cal_related_room(**params['mod_eval_conf']['reform_docs'])
    params_dict = {'features': features_b, 'features_opposite': features_a, 'id_opposite': frame_id1}
    frame_b = FrameObj(frame_b_2, **params_dict)
    frame_b.cal_related_room(**params['mod_eval_conf']['reform_docs'])

    params['mod_eval_conf']['ReformPointFactory'] = ReformPointToBFactory()

    frame_diff_obj = FrameDiffEval(frame_a, frame_b, **params['mod_eval_conf'])
    frame_diff_obj.solve_reform_point()

    return [frame_diff_obj, frame_diff_obj.status, json.dumps(frame_a_2.dump([]))]


def case_study(frame_id1, frame_id2, **case_conf):
    [frame_diff_obj, status_diff, json_a_2] = generate_reform_point(frame_id1, frame_id2, **case_conf)
    return frame_diff_obj.reform_list


def run_case_study(frame_id1, frame_id2):
    conf_params1, conf_params2 = dict(), dict()
    tag_utils.collect_conf(r"frame_mod_eval/mod_toB/collect_mod_toB_params.yml", conf_params1)
    conf_params1 = conf_params1['params']
    tag_utils.collect_conf(r"frame_eval/frame_tag_lib/conf.yml", conf_params2)
    conf_params1.update(conf_params2)
    input_params = dict()
    conf_params1['input_params'] = input_params
    rl = case_study(frame_id1, frame_id2, **conf_params1)
    return rl


def main():
    reform_list = run_case_study('1120040390044333', '1120021307159958')
    pass


if __name__ == '__main__':
    main()
    pass
