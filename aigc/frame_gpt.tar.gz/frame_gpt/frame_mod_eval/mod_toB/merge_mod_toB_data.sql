WITH today_report AS (
        -- 昨天的文案内容
		SELECT distinct frame_id, after_frame_id, status, NVL(score, 0.0) as score, city_code, report, is_valid
		FROM data_mining.data_mining_mod_report_v2_deco_b_inter_da
		WHERE pt = '{pt_date}000000' and status = 2 and is_valid = 1
	),
    today_image AS (
        -- 昨天的图片内容
		SELECT distinct frame_id, after_frame_id, area_id, reform_id, reform_class, reform_spare, before_flag, url, is_valid
		FROM data_mining.data_mining_mod_image_v2_url_da
		WHERE pt = '{last_image_date}000000' and is_valid = 1 and reform_class = 1 and area_id='all'
	),
    last_final_report AS (
        -- 前一天的最终报告.
		SELECT distinct frame_id, status, report, city_code, is_valid, error_msg
		FROM data_mining.data_mining_mod_report_v2_deco_b_final_da
		WHERE pt = '{last_final_report_date}000000' and is_valid = 1
	),
	uni_feature AS (
	    -- 只计算一层户型数据
        SELECT distinct frame_id, build_area, t_shi, t_ting
        FROM data_mining.data_mining_frame_uni_feature_da
        WHERE pt = '{pt_date}000000' and plans_len = 1
	)
SELECT distinct a.frame_id
       , a.after_frame_id
       , a.score
       , nvl(c.status, a.status) as status --  如果昨天的最终报告没有状态代表是新的数据, 就用最新的.
       , nvl(c.report, a.report) as report
       , nvl(c.error_msg, '') as error_msg
       , nvl(c.city_code, a.city_code) as city_code
       , nvl(c.is_valid, a.is_valid) as is_valid
       , b.area_id
       , b.reform_id
       , b.reform_class
       , b.reform_spare
       , b.before_flag
       , b.url
       , nvl(u_b.build_area, 0) as build_area
       , nvl(u_b.t_shi, -1) as t_shi
       , nvl(u_b.t_ting, -1) as t_ting
FROM today_report a
	LEFT JOIN today_image b ON b.frame_id = a.frame_id AND b.after_frame_id = a.after_frame_id
	LEFT JOIN uni_feature u_b ON u_b.frame_id = a.after_frame_id
    LEFT JOIN last_final_report c ON c.frame_id = a.frame_id