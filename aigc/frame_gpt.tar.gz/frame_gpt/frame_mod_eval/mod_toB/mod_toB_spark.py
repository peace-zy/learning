# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/3/3 20:33
# ===================================
import json
import pandas as pd

import functools
import traceback

import frame_mod_eval.utils.frame_diff as FD
from frame_mod_eval.mod_lib.frame_entity import FrameObj
from frame_mod_eval.mod_toB.room_diff_toB import FrameDiffEval
from frame_mod_eval.entity import frame_diff_entity as ent
from frame_mod_eval.mod_toB.reform_point_interface_toB import ReformPointToBFactory


class ModNameToB(object):
    name_dict = {
        0: '客厅改卧室', 7: '卧室改客厅', 9: '扩大厨房', 10: '干湿分离', 11: '增加居室', 12: '减少居室', 13: '增加卫生间',
        14: '增加衣帽间', 15: '增加储物间', 16: '扩大卫生间', 17: '扩大卧室', 18: '减少卫生间', 19: '客厅增加采光', 20: '增加用餐区',
        21: '增加书房', 22: '改厨房门', 23: '改卫生间门'
    }


def generate_reform_json_without_http(f_1, f_2, frame_json_a, frame_json_b, features_a, features_b, **kwargs):
    # frame_diff里面计算两户型的分间、墙体、附件的diff主流程
    frame_a = ent.FrameStdVecObj(frame_json_a, frame_id=f_1)
    frame_b = ent.FrameStdVecObj(frame_json_b, frame_id=f_2)
    frame_a_2, frame_b_2, status_diff = FD.frame_diff(frame_a, frame_b)

    # 接收frame_diff的状态值，如果小于0则代表无法正常旋转，直接返回，否则就继续运行
    if status_diff < 0:
        return [None, status_diff, json.dumps(frame_a_2.dump([]))]

    try:
        if features_a == '' or features_b == '':
            raise Exception("frame features is an empty string")
    except Exception as e:
        print(repr(e))

    if not isinstance(features_a, dict):
        features_a = json.loads(features_a)
    if not isinstance(features_b, dict):
        features_b = json.loads(features_b)
    # 初始化原户型和改后户型的FrameObj对象，以及FrameDiffEval对象, 调用cal_related_room()函数计算吃掉对面的谁和被对面的谁吃掉
    params_dict = {'features': features_a, 'features_opposite': features_b, 'id_opposite': f_2}
    frame_a = FrameObj(frame_a_2, **params_dict)
    frame_a.cal_related_room(**kwargs['mod_eval_conf']['reform_docs'])
    params_dict = {'features': features_b, 'features_opposite': features_a, 'id_opposite': f_1}
    frame_b = FrameObj(frame_b_2, **params_dict)
    frame_b.cal_related_room(**kwargs['mod_eval_conf']['reform_docs'])

    # 生成改造点工厂对象用于后续生成全局改造点
    kwargs['mod_eval_conf']['ReformPointFactory'] = ReformPointToBFactory()

    frame_diff_obj = FrameDiffEval(frame_a, frame_b, **kwargs['mod_eval_conf'])
    frame_diff_obj.solve_reform_point()

    return [frame_diff_obj, frame_diff_obj.status, json.dumps(frame_a_2.dump([]))]


def mod_toB_1th_period(row, **kwargs):
    frame_id, after_frame_id = row.frame_id, row.after_frame_id
    before_frame_json, after_frame_json = row.before_frame_json, row.after_frame_json
    before_frame_featrue, after_frame_feature = row.before_frame_feature, row.after_frame_feature

    try:
        [frame_diff_obj, status, frame_json_after_a] = \
            generate_reform_json_without_http(frame_id, after_frame_id, before_frame_json, after_frame_json, before_frame_featrue, after_frame_feature, **kwargs)

        result_dict = dict()
        # 返回列表：包括改造前后id、打分、长短文案、是否有效、状态值
        result_dict['frame_id'] = frame_id
        result_dict['after_frame_id'] = after_frame_id
        result_dict['trans_frame_a_json'] = frame_json_after_a
        result_dict['status'] = status
        result_dict['report'] = json.dumps(dict())

        if status < 0:
            result_dict['is_valid'] = 0
            result_dict['detail_info'] = json.dumps(dict())
        else:
            result_dict['is_valid'] = 1

            detail_info_dict = dict()
            detail_info_dict['frame_id_A'] = frame_id
            detail_info_dict['frame_id_B'] = after_frame_id
            detail_info_dict['pngSize'] = '1440x1080'
            detail_info_dict['report'] = list()

            head_img_dict = {'area_id': 'all',
                             'reform_id': frame_diff_obj.reform_value,
                             'reform_spare': frame_diff_obj.reform_spare_value,
                             'reform_class': 1,
                             'plan_idx': 0,
                             'polygons_A': frame_diff_obj.polygons_list_A,
                             'polygons_B': frame_diff_obj.polygons_list_B}
            detail_info_dict['report'].append(head_img_dict)

            result_dict['detail_info'] = json.dumps(detail_info_dict)

        result_list = list()
        result_list.append(result_dict['frame_id'])
        result_list.append(result_dict['after_frame_id'])
        result_list.append(result_dict['status'])
        result_list.append(result_dict['trans_frame_a_json'])
        result_list.append(row.score)
        result_list.append(result_dict['detail_info'])
        result_list.append(result_dict['is_valid'])
        result_list.append(result_dict['report'])
        result_list.append(row.city_code)
    except Exception as e:
        status, trans_frame_a_json, score, detail_info, is_valid, report = -2, str(traceback.format_exc()), 0.0, '', 0, ''
        result_list = [frame_id, after_frame_id, status, trans_frame_a_json, score, detail_info, is_valid, report, row.city_code]
    return result_list


def mod_toB_2th_period(frame_id, after_frame_id, trans_frame_a_json, detail_info, **kwargs):
    detail_info_dict = json.loads(detail_info)
    detail_info_dict['trans_frame_a_json'] = trans_frame_a_json
    detail_info_res = json.dumps(detail_info_dict)
    return detail_info_res


def mod_toB_3th_period(row, **kwargs):
    def analysis_reform_id(reform_id):
        res = list()
        for i in range(24):
            if reform_id & (1 << i) != 0:
                res.append(ModNameToB.name_dict[i])
        return res

    def compare_rule(v1, v2):
        if v1['reform_num'] == v2['reform_num']:
            if v1['score'] > v2['score']:
                return -1
            else:
                return 1
        else:
            if v1['reform_num'] > v2['reform_num']:
                return -1
            else:
                return 1

    frame_id = row.frame_id
    url_info = row.url_info
    report = dict()
    try:
        report['frame_id'] = frame_id

        df = pd.DataFrame(url_info)
        df.columns = ['after_frame_id', 'score', 'reform_id', 'reform_spare', 'before_flag', 'url',
                      'area_size', 'room', 'parlar', 'city_code']
        df_after = df[df['before_flag'] == 0]
        df_before = df[df['before_flag'] == 1]
        report['url'] = json.loads(df_before.iloc[0].url)
        city_code = df_before.iloc[0].city_code

        reform_method = list()
        frame_set = set()
        for index, row in df_after.iterrows():
            if row.after_frame_id in frame_set or row.reform_id == 0:
                continue
            frame_set.add(row.after_frame_id)
            method = dict()
            method['frame_id'] = row.after_frame_id
            method['score'] = row.score
            method['area_size'] = row.area_size
            method['room'] = row.room
            method['parlar'] = row.parlar
            method['url'] = json.loads(row.url)
            method['reform_point'] = analysis_reform_id(row.reform_id)
            method['reform_num'] = len(method['reform_point'])
            reform_method.append(method)
        reform_method = sorted(reform_method, key=functools.cmp_to_key(compare_rule))
        report['reform_method'] = reform_method
        res = [frame_id, 2, json.dumps(report), city_code, 1, '']
    except Exception as e:
        res = [frame_id, -1, json.dumps(report), '000000', 0, str(traceback.format_exc())]
    return res


if __name__ == '__main__':
    pass
