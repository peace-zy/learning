# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/3/2 11:33
# ===================================
import sys
import copy
import math
from abc import ABCMeta, abstractmethod

import inspect
import numpy as np

import frame_mod_eval.mod_lib.mod_params as MP
import frame_mod_eval.mod_lib.mod_tools as MT
from frame_mod_eval.mod_lib.reform_point_interface import IReformPoint
from frame_mod_eval.mod_lib.mod_params import ModIndex, ModIndexSpare


class ReformPointToBFactory(object):
    def __init__(self, **kwargs):
        self.kwargs = kwargs

    @property
    def ClassDict(self):
        class_list = inspect.getmembers(sys.modules[__name__])
        class_dict = {_name: _class for _name, _class in class_list}
        return class_dict

    def get_object(self, ReformPointName, **kwargs):
        if ReformPointName not in self.ClassDict:
            raise NotImplementedError('class {} has not been implement'.format(ReformPointName))
        class_obj = self.ClassDict[ReformPointName](**kwargs)
        return class_obj


class IReformPointToB(IReformPoint):
    __metaclass__ = ABCMeta

    def __init__(self, **kwargs):
        super(IReformPointToB, self).__init__(**kwargs)
        self.service_name = 'DecorationToB'
        self.reform_class = 1

    @abstractmethod
    def judge_is_valid(self, **kwargs):
        return False

    @abstractmethod
    def solve(self, **kwargs):
        return None


class AddBedroom(IReformPointToB):
    def __init__(self, **kwargs):
        super(AddBedroom, self).__init__(**kwargs)
        self.reform_name = ModIndex.AddBedroom.name
        self.reform_id = ModIndex.AddBedroom.value
        self.reform_spare_id = ModIndexSpare.AddBedroom.value

    def judge_is_valid(self, **kwargs):
        flag = False
        if kwargs['frame_a'].structure[0] != 0 and \
                kwargs['frame_a'].structure[0] < kwargs['frame_b'].structure[0]:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        return self


class SubBedroom(IReformPointToB):
    def __init__(self, **kwargs):
        super(SubBedroom, self).__init__(**kwargs)
        self.reform_name = ModIndex.SubBedroom.name
        self.reform_id = ModIndex.SubBedroom.value
        self.reform_spare_id = ModIndexSpare.SubBedroom.value

    def judge_is_valid(self, **kwargs):
        flag = False
        if kwargs['frame_b'].structure[0] != 0 \
                and kwargs['frame_a'].structure[0] > kwargs['frame_b'].structure[0]:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        return self


class AddToilet(IReformPointToB):
    def __init__(self, **kwargs):
        super(AddToilet, self).__init__(**kwargs)
        self.reform_name = ModIndex.AddToilet.name
        self.reform_id = ModIndex.AddToilet.value
        self.reform_spare_id = ModIndexSpare.AddToilet.value

    def judge_is_valid(self, **kwargs):
        flag = False
        if kwargs['frame_a'].structure[3] < kwargs['frame_b'].structure[3]:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        return self


class SubToilet(IReformPointToB):
    def __init__(self, **kwargs):
        super(SubToilet, self).__init__(**kwargs)
        self.reform_name = ModIndex.SubToilet.name
        self.reform_id = ModIndex.SubToilet.value
        self.reform_spare_id = ModIndexSpare.SubToilet.value

    def judge_is_valid(self, **kwargs):
        flag = False
        if kwargs['frame_a'].structure[3] > kwargs['frame_b'].structure[3]:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        return self


class AddCloakroom(IReformPointToB):
    def __init__(self, **kwargs):
        super(AddCloakroom, self).__init__(**kwargs)
        self.reform_name = ModIndex.AddCloakroom.name
        self.reform_id = ModIndex.AddCloakroom.value
        self.reform_spare_id = ModIndexSpare.AddCloakroom.value

    def judge_is_valid(self, **kwargs):
        frame_a, frame_b = kwargs['frame_a'], kwargs['frame_b']
        cnt_a, cnt_b = 0, 0
        for _room in frame_a.room_list:
            if _room.room_type == MP.RoomClassEnum.cloakroom.value:
                cnt_a = cnt_a + 1
        for _room in frame_b.room_list:
            if _room.room_type == MP.RoomClassEnum.cloakroom.value:
                cnt_b = cnt_b + 1
        flag = False
        if cnt_a < cnt_b:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        return self


class AddStorage(IReformPointToB):
    def __init__(self, **kwargs):
        super(AddStorage, self).__init__(**kwargs)
        self.reform_name = ModIndex.AddStorage.name
        self.reform_id = ModIndex.AddStorage.value
        self.reform_spare_id = ModIndexSpare.AddStorage.value

    def judge_is_valid(self, **kwargs):
        frame_a, frame_b = kwargs['frame_a'], kwargs['frame_b']
        cnt_a, cnt_b = 0, 0
        for _room in frame_a.room_list:
            if _room.room_type == MP.RoomClassEnum.storage.value:
                cnt_a = cnt_a + 1
        for _room in frame_b.room_list:
            if _room.room_type == MP.RoomClassEnum.storage.value:
                cnt_b = cnt_b + 1
        flag = False
        if cnt_a < cnt_b:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        return self


class AddStudy(IReformPointToB):
    def __init__(self, **kwargs):
        super(AddStudy, self).__init__(**kwargs)
        self.reform_name = ModIndex.AddStudy.name
        self.reform_id = ModIndex.AddStudy.value
        self.reform_spare_id = ModIndexSpare.AddStudy.value

    def judge_is_valid(self, **kwargs):
        frame_a, frame_b = kwargs['frame_a'], kwargs['frame_b']
        cnt_a, cnt_b = 0, 0
        for _room in frame_a.room_list:
            if _room.room_type == MP.RoomClassEnum.bedroom.value and _room.detail_type == 4:
                cnt_a = cnt_a + 1
        for _room in frame_b.room_list:
            if _room.room_type == MP.RoomClassEnum.bedroom.value and _room.detail_type == 4:
                cnt_b = cnt_b + 1
        flag = False
        if cnt_a < cnt_b:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        return self


class AddDiningArea(IReformPointToB):
    def __init__(self, **kwargs):
        super(AddDiningArea, self).__init__(**kwargs)
        self.reform_name = ModIndex.AddDiningArea.name
        self.reform_id = ModIndex.AddDiningArea.value
        self.reform_spare_id = ModIndexSpare.AddDiningArea.value

    def judge_is_valid(self, **kwargs):
        frame_a, frame_b = kwargs['frame_a'], kwargs['frame_b']
        cnt_a, cnt_b = 0, 0
        for _room in frame_a.room_list:
            if _room.room_type == MP.RoomClassEnum.parlor.value and _room.detail_type == 2:
                cnt_a = cnt_a + 1
        for _room in frame_b.room_list:
            if _room.room_type == MP.RoomClassEnum.parlor.value and _room.detail_type == 2:
                cnt_b = cnt_b + 1
        flag = False
        if cnt_a < cnt_b:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        return self


class BedroomChangeLivingroom(IReformPointToB):
    def __init__(self, **kwargs):
        super(BedroomChangeLivingroom, self).__init__(**kwargs)
        self.reform_name = ModIndex.BedroomChangeLivingroom.name
        self.reform_id = ModIndex.BedroomChangeLivingroom.value
        self.reform_spare_id = ModIndexSpare.BedroomChangeLivingroom.value

    def judge_is_valid(self, **kwargs):
        flag = False
        self_room = kwargs['self_room']
        related_room = kwargs['related_room']
        if related_room.intersect_ratio > 0.70:
            flag = True
        if related_room.intersect_area / self_room.area_size > 0.9:
            flag = True
        return flag

    def solve(self, **kwargs):
        self_room = kwargs['self_room']
        room_same_class = kwargs['room_same_class']
        s2 = 0
        if room_same_class is not None:
            s2 = room_same_class.area_size
        for _related in self_room.passive:
            # 判断相关联的分间是否是客厅，检测卧室与客厅相关的改造点，改造后的户型至少要有一个卧室
            if s2 >= 0 and _related.detail_type == MP.RoomNameEnum.living_room.value and kwargs['frame_b'].structure[0] > 0:
                kwargs['related_room'] = _related
        if kwargs.get('related_room', None) is None:
            return None
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        return self


class LivingroomChangeBedroom(IReformPointToB):
    def __init__(self, **kwargs):
        super(LivingroomChangeBedroom, self).__init__(**kwargs)
        self.reform_name = ModIndex.LivingroomChangeBedroom.name
        self.reform_id = ModIndex.LivingroomChangeBedroom.value
        self.reform_spare_id = ModIndexSpare.LivingroomChangeBedroom.value

    def judge_is_valid(self, **kwargs):
        flag = False
        self_room = kwargs['self_room']
        related_room = kwargs['related_room']
        if related_room.intersect_ratio > 0.70:
            flag = True
        if related_room.intersect_area / self_room.area_size > 0.9:
            flag = True
        return flag

    def solve(self, **kwargs):
        self_room = kwargs['self_room']
        room_same_class = kwargs['room_same_class']
        s2 = 0
        if room_same_class is not None:
            s2 = room_same_class.area_size
        for _related in self_room.passive:
            # 判断相关联的分间是否是卧室，检测客厅与卧室相关的改造点
            if s2 >= 0 and (_related.detail_type == MP.RoomNameEnum.bedroom.value or _related.detail_type == MP.RoomNameEnum.mainroom.value or _related.detail_type == MP.RoomNameEnum.secondary_bedroom.value):
                kwargs['related_room'] = _related
        if kwargs.get('related_room', None) is None:
            return None
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        return self


class ToiletDryWet(IReformPointToB):
    def __init__(self, **kwargs):
        super(ToiletDryWet, self).__init__(**kwargs)
        self.reform_name = ModIndex.ToiletDryWet.name
        self.reform_id = ModIndex.ToiletDryWet.value
        self.reform_spare_id = ModIndexSpare.ToiletDryWet.value

    def judge_is_valid(self, **kwargs):
        flag = False
        self_room = kwargs['self_room']
        room_same_class = kwargs['room_same_class']
        # 如果相交的面积占关联分间的比例没达到阈值，说明关联分间不完全从本分间分离出来，因此不算做增加分间
        if room_same_class is not None and room_same_class.intersect_ratio > 0.5 and \
                not self_room.judge_have_dangle_wall() and room_same_class.judge_have_dangle_wall():
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        return self


class KitchenAddArea(IReformPointToB):
    def __init__(self, **kwargs):
        super(KitchenAddArea, self).__init__(**kwargs)
        self.reform_name = ModIndex.KitchenAddArea.name
        self.reform_id = ModIndex.KitchenAddArea.value
        self.reform_spare_id = ModIndexSpare.KitchenAddArea.value

    def judge_is_valid(self, **kwargs):
        flag = False
        self_room = kwargs['self_room']
        room_same_class = kwargs['room_same_class']
        if room_same_class is not None and \
                room_same_class.area_size / self_room.area_size > kwargs['reform_docs']['threshold_add_area_ratio'] and \
                room_same_class.area_size - self_room.area_size > 1:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        return self


class ToiletAddArea(IReformPointToB):
    def __init__(self, **kwargs):
        super(ToiletAddArea, self).__init__(**kwargs)
        self.reform_name = ModIndex.ToiletAddArea.name
        self.reform_id = ModIndex.ToiletAddArea.value
        self.reform_spare_id = ModIndexSpare.ToiletAddArea.value

    def judge_is_valid(self, **kwargs):
        flag = False
        self_room = kwargs['self_room']
        room_same_class = kwargs['room_same_class']
        if room_same_class is not None and \
                room_same_class.area_size / self_room.area_size > kwargs['reform_docs']['threshold_add_area_ratio'] and \
                room_same_class.area_size - self_room.area_size > 1:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        return self


class BedroomAddArea(IReformPointToB):
    def __init__(self, **kwargs):
        super(BedroomAddArea, self).__init__(**kwargs)
        self.reform_name = ModIndex.BedroomAddArea.name
        self.reform_id = ModIndex.BedroomAddArea.value
        self.reform_spare_id = ModIndexSpare.BedroomAddArea.value

    def judge_is_valid(self, **kwargs):
        flag = False
        self_room = kwargs['self_room']
        room_same_class = kwargs['room_same_class']
        if room_same_class is not None and \
                room_same_class.area_size / self_room.area_size > kwargs['reform_docs']['threshold_add_area_ratio'] and \
                room_same_class.area_size - self_room.area_size > 1:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        return self


class LivingroomAddLighting(IReformPointToB):
    def __init__(self, **kwargs):
        super(LivingroomAddLighting, self).__init__(**kwargs)
        self.reform_name = ModIndex.LivingroomAddLighting.name
        self.reform_id = ModIndex.LivingroomAddLighting.value
        self.reform_spare_id = ModIndexSpare.LivingroomAddLighting.value

    def judge_is_valid(self, **kwargs):
        flag = False
        self_room = kwargs['self_room']
        room_same_class = kwargs['room_same_class']
        if room_same_class is None:
            return False
        window_set_a = set()
        window_set_b = set()
        for _line in self_room.room_lines:
            for _line_item in _line.line_items:
                if _line_item.line_item_type == 5:
                    window_set_a.add(copy.deepcopy(_line_item))
        for _line in room_same_class.room_lines:
            for _line_item in _line.line_items:
                if _line_item.line_item_type == 5:
                    window_set_b.add(copy.deepcopy(_line_item))
        if window_set_a < window_set_b:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        return self


class ToiletChangeDoor(IReformPointToB):
    def __init__(self, **kwargs):
        super(ToiletChangeDoor, self).__init__(**kwargs)
        self.reform_name = ModIndex.ToiletChangeDoor.name
        self.reform_id = ModIndex.ToiletChangeDoor.value
        self.reform_spare_id = ModIndexSpare.ToiletChangeDoor.value

    def trans_point(self, point, trans_matrix):
        return np.array([trans_matrix[0] * point[0] + trans_matrix[1] * point[1] + trans_matrix[4],
                         trans_matrix[2] * point[0] + trans_matrix[3] * point[1] + trans_matrix[5]])

    def judge_is_valid(self, **kwargs):
        flag = False
        self_room = kwargs['self_room']
        room_same_class = kwargs['room_same_class']
        if room_same_class is None:
            return False
        obj_self = self_room.obj
        obj_same = room_same_class.obj
        line_dict1 = dict()
        line_dict2 = dict()
        for _line in self_room.room_lines:
            for _line_item in _line.line_items:
                if _line_item.type > 4:
                    continue
                line_id = _line.uid
                room_near = self_room.line_id_dict[line_id]
                if self_room.name != room_near[0].encode('utf-8'):
                    line_dict1[room_near[0]] = (_line, _line_item)
                elif self_room.name != room_near[1].encode('utf-8'):
                    line_dict1[room_near[1]] = (_line, _line_item)

        for _line in room_same_class.room_lines:
            for _line_item in _line.line_items:
                if _line_item.type > 4:
                    continue
                line_id = _line.uid
                room_near = room_same_class.line_id_dict[line_id]
                if self_room.name != room_near[0].encode('utf-8'):
                    line_dict2[room_near[0]] = (_line, _line_item)
                elif self_room.name != room_near[1].encode('utf-8'):
                    line_dict2[room_near[1]] = (_line, _line_item)
        for _key, (_line1, _line_item1) in line_dict1.items():
            if _key not in line_dict2:
                continue
            (_line2, _line_item2) = line_dict2[_key]

            trans1 = self_room.trans_matrix_1d
            trans2 = [1, 0, 0, 1, 0, 0]
            center1 = self.trans_point(_line_item1.center, trans1)
            center2 = self.trans_point(_line_item2.center, trans2)

            l1p1 = self.trans_point(_line_item1.start_point, trans1)
            l1p2 = self.trans_point(_line_item1.end_point, trans1)
            l2p1 = np.array(_line_item2.start_point)
            l2p2 = np.array(_line_item2.end_point)
            dir1 = (l1p2 - l1p1) / _line_item1.length
            dir2 = (l2p2 - l2p1) / _line_item2.length
            fa1 = np.array([-dir1[1], dir1[0]])
            fa2 = np.array([-dir2[1], dir2[0]])
            ok1 = 0
            ok2 = 0
            door_to_left1, right_to_left1, door_to_left2, right_to_left2 = -1, -1, -1, -1
            if abs(math.atan2(fa1[1], fa1[0]) - math.pi / 2) < 0.05 or abs(
                    math.atan2(fa1[1], fa1[0]) + math.pi / 2) < 0.05:
                door_to_left1 = center1[0] - obj_self.bounds[0]
                right_to_left1 = obj_self.bounds[2] - obj_self.bounds[0]
                ok1 = 1
            elif abs(math.atan2(fa1[1], fa1[0]) - 0) < 0.05 or abs(math.atan2(fa1[1], fa1[0]) - math.pi) < 0.05 or abs(
                    math.atan2(fa1[1], fa1[0]) + math.pi) < 0.05:
                door_to_left1 = center1[1] - obj_self.bounds[1]
                right_to_left1 = obj_self.bounds[3] - obj_self.bounds[1]
                ok1 = 1
            else:
                continue

            if abs(math.atan2(fa2[1], fa2[0]) - math.pi / 2) < 0.05 or abs(
                    math.atan2(fa2[1], fa2[0]) + math.pi / 2) < 0.05:
                door_to_left2 = center2[0] - obj_same.bounds[0]
                right_to_left2 = obj_same.bounds[2] - obj_same.bounds[0]
                ok2 = 1
            elif abs(math.atan2(fa2[1], fa2[0]) - 0) < 0.05 or abs(math.atan2(fa2[1], fa2[0]) - math.pi) < 0.05 or abs(
                    math.atan2(fa2[1], fa2[0]) + math.pi) < 0.05:
                door_to_left2 = center2[1] - obj_same.bounds[1]
                right_to_left2 = obj_same.bounds[3] - obj_same.bounds[1]
                ok2 = 1
            else:
                continue

            if ok1 == 0 or ok2 == 0:
                continue
            ratio1 = door_to_left1 / right_to_left1
            ratio2 = door_to_left2 / right_to_left2
            if abs(ratio1 - ratio2) > 0.1 and abs(door_to_left2 - door_to_left1) > 400:
                # draw_img_config = self.kwargs['draw_img']
                # self.kwargs['line'] += MT.ImgTools.get_draw_poly([_line2], obj_type='line', color=draw_img_config['line_color_changed'], fill="transparent", opacity=draw_img_config['line_opacity_changed'])
                flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        return self


class KitchenChangeDoor(IReformPointToB):
    def __init__(self, **kwargs):
        super(KitchenChangeDoor, self).__init__(**kwargs)
        self.reform_name = ModIndex.KitchenChangeDoor.name
        self.reform_id = ModIndex.KitchenChangeDoor.value
        self.reform_spare_id = ModIndexSpare.KitchenChangeDoor.value

    def trans_point(self, point, trans_matrix):
        return np.array([trans_matrix[0] * point[0] + trans_matrix[1] * point[1] + trans_matrix[4],
                         trans_matrix[2] * point[0] + trans_matrix[3] * point[1] + trans_matrix[5]])

    def judge_is_valid(self, **kwargs):
        flag = False
        self_room = kwargs['self_room']
        room_same_class = kwargs['room_same_class']
        if room_same_class is None:
            return False
        obj_self = self_room.obj
        obj_same = room_same_class.obj
        line_dict1 = dict()
        line_dict2 = dict()
        for _line in self_room.room_lines:
            for _line_item in _line.line_items:
                if _line_item.type > 4:
                    continue
                line_id = _line.uid
                room_near = self_room.line_id_dict[line_id]
                if self_room.name != room_near[0].encode('utf-8'):
                    line_dict1[room_near[0]] = (_line, _line_item)
                elif self_room.name != room_near[1].encode('utf-8'):
                    line_dict1[room_near[1]] = (_line, _line_item)

        for _line in room_same_class.room_lines:
            for _line_item in _line.line_items:
                if _line_item.type > 4:
                    continue
                line_id = _line.uid
                room_near = room_same_class.line_id_dict[line_id]
                if self_room.name != room_near[0].encode('utf-8'):
                    line_dict2[room_near[0]] = (_line, _line_item)
                elif self_room.name != room_near[1].encode('utf-8'):
                    line_dict2[room_near[1]] = (_line, _line_item)
        for _key, (_line1, _line_item1) in line_dict1.items():
            if _key not in line_dict2:
                continue
            (_line2, _line_item2) = line_dict2[_key]

            trans1 = self_room.trans_matrix_1d
            trans2 = [1, 0, 0, 1, 0, 0]
            center1 = self.trans_point(_line_item1.center, trans1)
            center2 = self.trans_point(_line_item2.center, trans2)

            l1p1 = self.trans_point(_line_item1.start_point, trans1)
            l1p2 = self.trans_point(_line_item1.end_point, trans1)
            l2p1 = np.array(_line_item2.start_point)
            l2p2 = np.array(_line_item2.end_point)
            dir1 = (l1p2 - l1p1) / _line_item1.length
            dir2 = (l2p2 - l2p1) / _line_item2.length
            fa1 = np.array([-dir1[1], dir1[0]])
            fa2 = np.array([-dir2[1], dir2[0]])
            ok1 = 0
            ok2 = 0
            door_to_left1, right_to_left1, door_to_left2, right_to_left2 = -1, -1, -1, -1
            if abs(math.atan2(fa1[1], fa1[0]) - math.pi / 2) < 0.05 or abs(
                    math.atan2(fa1[1], fa1[0]) + math.pi / 2) < 0.05:
                door_to_left1 = center1[0] - obj_self.bounds[0]
                right_to_left1 = obj_self.bounds[2] - obj_self.bounds[0]
                ok1 = 1
            elif abs(math.atan2(fa1[1], fa1[0]) - 0) < 0.05 or abs(math.atan2(fa1[1], fa1[0]) - math.pi) < 0.05 or abs(
                    math.atan2(fa1[1], fa1[0]) + math.pi) < 0.05:
                door_to_left1 = center1[1] - obj_self.bounds[1]
                right_to_left1 = obj_self.bounds[3] - obj_self.bounds[1]
                ok1 = 1
            else:
                continue

            if abs(math.atan2(fa2[1], fa2[0]) - math.pi / 2) < 0.05 or abs(
                    math.atan2(fa2[1], fa2[0]) + math.pi / 2) < 0.05:
                door_to_left2 = center2[0] - obj_same.bounds[0]
                right_to_left2 = obj_same.bounds[2] - obj_same.bounds[0]
                ok2 = 1
            elif abs(math.atan2(fa2[1], fa2[0]) - 0) < 0.05 or abs(math.atan2(fa2[1], fa2[0]) - math.pi) < 0.05 or abs(
                    math.atan2(fa2[1], fa2[0]) + math.pi) < 0.05:
                door_to_left2 = center2[1] - obj_same.bounds[1]
                right_to_left2 = obj_same.bounds[3] - obj_same.bounds[1]
                ok2 = 1
            else:
                continue

            if ok1 == 0 or ok2 == 0:
                continue
            ratio1 = door_to_left1 / right_to_left1
            ratio2 = door_to_left2 / right_to_left2
            if abs(ratio1 - ratio2) > 0.1 and abs(door_to_left2 - door_to_left1) > 400:
                # draw_img_config = self.kwargs['draw_img']
                # self.kwargs['line'] += MT.ImgTools.get_draw_poly([_line2], obj_type='line', color=draw_img_config['line_color_changed'], fill="transparent", opacity=draw_img_config['line_opacity_changed'])
                flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        return self


if __name__ == '__main__':
    pass
