# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/3/2 15:30
# ===================================

class FrameDiffEval(object):
    """
    两户型对比类
    """
    def __init__(self, frame_a, frame_b, **kwargs):
        """
        :param frame_a: 原户型 DiffFrame
        :param frame_b: 改户型 DiffFrame
        """
        # 原户型和改户型
        self.frame_a = frame_a
        self.frame_b = frame_b
        # 要进行解析的分间列表，由于目前是分析原户型的所有分间改造点，所以存储的是frame_a的所有分间通过room_factory模块生成的类
        self.room_list = frame_a.room_list
        # 改造状态，0:未改造(无diff), 1:已改造(有diff)&没检测点覆盖, 2: 已改造(有diff)&有覆盖检测点. (负值在计算diff的时候已经返回)
        self.status = 0
        # 改造点集合列表
        self.reform_list = list()
        self.reform_value = 0
        self.reform_spare_value = 0
        # 改造后墙体集合
        self.polygons_list_A = list()
        self.polygons_list_B = list()
        self.kwargs = kwargs

    def judge_diff(self):
        """
        遍历两户型的墙体和附件，判断两户型是否完全相同.
        :param:
        :return: 返回布尔值，True表示有diff不完全相同，False表示没有diff完全相同
        """
        # 遍历frame_a的墙体
        for _room in self.frame_a.room_list:
            for _line in _room.room_lines:
                if not _line.is_matched:
                    return True
                # 遍历墙体上的附件
                for _line_item in _line.line_items:
                    if not _line_item.is_matched:
                        return True
        # 遍历frame_b的墙体
        for _room in self.frame_b.room_list:
            for _line in _room.room_lines:
                if not _line.is_matched:
                    return True
                # 遍历墙体上的附件
                for _line_item in _line.line_items:
                    if not _line_item.is_matched:
                        return True
        return False

    def constrained_condition(self):
        """
        一些特殊的约束条件，户型总面积过大则不考虑
        :return: 布尔变量，代表是否满足约束条件
        """
        if self.frame_a.area_size > 180 or self.frame_a.structure[0] > 5 or self.frame_b.structure[0] > 5:
            return False
        return True

    def solve_reform_point(self):
        # 检查两户型是否完全相同
        have_diff = self.judge_diff()
        # 计算是否满足自定义的约束条件
        constrained_satisfy = self.constrained_condition()
        # 如果不满足约束条件直接返回，这里记录一下状态变量status
        if have_diff and not constrained_satisfy:
            self.status = 1
            return
        elif not have_diff and not constrained_satisfy:
            self.status = 0
            return
        # 参数设置
        _params = dict()
        _params['frame_a'] = self.frame_a
        _params['frame_b'] = self.frame_b
        _params.update(self.kwargs)
        # 检测局部改造点
        for _room in self.room_list:
            _room.get_all_reform_point(**_params['reform_point_list'])
            _room.detect_reform_point(**_params)
            for _reform_point in _room.reform_point_list:
                self.reform_value |= _reform_point.reform_id
                self.reform_spare_value |= _reform_point.reform_spare_id
            self.reform_list = self.reform_list + _room.reform_point_list
        # 检测全局改造点
        ReformPointFactory = _params['ReformPointFactory']
        for _reform_point_name in _params['reform_point_list']['whole']:
            reform_point = ReformPointFactory.get_object(_reform_point_name)
            res = reform_point.solve(**_params)
            if res is None:
                continue
            self.reform_value |= res.reform_id
            self.reform_spare_value |= res.reform_spare_id
            self.reform_list.append(res)
        self.polygons_list_B = self.polygons_list_B + self.frame_b.collect_whole_polygons(**_params['draw_img'])

        if len(self.reform_list) > 0:
            self.status = 2
        else:
            self.status = 1
        pass


if __name__ == '__main__':
    pass
