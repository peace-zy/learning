WITH today_report AS (
        -- 昨天的文案内容
		SELECT distinct frame_id, after_frame_id, status, NVL(score, 0.0) as score, report
			, short_report, detail_info, after_frame_json, is_valid
		FROM data_mining.data_mining_mod_report_inter_da
		WHERE pt = '{pt_date}000000' and status = 2 and is_valid = 1
	),
    last_image AS (
        -- 昨天的图片内容
		SELECT distinct frame_id, after_frame_id, area_id, reform_id, before_flag, url, is_valid
		FROM data_mining.data_mining_mod_image_da
		WHERE pt = '{last_image_date}000000' and is_valid = 1
	),
    last_final_report AS (
        -- 前一天的最终报告.
		SELECT distinct frame_id, after_frame_id, status, score, report, short_report, is_valid
		FROM data_mining.data_mining_frame_mod_report_da
		WHERE pt = '{last_final_report_date}000000' and is_valid = 1
	),
	uni_feature AS (
	    -- 只计算一层户型数据
        SELECT distinct frame_id
        FROM data_mining.data_mining_frame_uni_feature_da
        WHERE pt = '{pt_date}000000' and plans_len = 1
	)
SELECT distinct a.frame_id
       , a.after_frame_id
       , nvl(c.status, a.status) as status -- 如果昨天的最终报告没有状态代表是新的数据, 就用最新的.
       , nvl(c.score, a.score) as score
       , nvl(c.report, a.report) as report
       , nvl(c.short_report, a.short_report) as short_report
       , b.area_id
       , nvl(b.reform_id, -2) as reform_id
       , nvl(b.before_flag, -2) as before_flag
       , b.url
       , nvl(c.short_report, 'new') as is_new
       , nvl(a.is_valid, -2) as is_valid
FROM today_report a
	JOIN last_image b ON b.frame_id = a.frame_id AND b.after_frame_id = a.after_frame_id
	JOIN uni_feature u_a ON u_a.frame_id = a.frame_id
	JOIN uni_feature u_b ON u_b.frame_id = a.after_frame_id
    LEFT JOIN last_final_report c ON c.frame_id = a.frame_id AND c.after_frame_id = a.after_frame_id