# -*- coding: utf-8 -*-
# ===============================================================
#
#    Copyright (C) 2021 Beike, Inc. All Rights Reserved.
#
#    @Create Author : 李雨龙 (liyulong008@ke.com)
#    @Create Time   : 2021/8/11 11:24
#    @Description   : frame_miner
#
# ===============================================================
from __future__ import division

import sys
import yaml
import logging
import traceback

import pyspark.sql.functions as functions

from frame_mod_eval.utils import reform_doc
from lib import spark_util
from lib.file_util import get_file_stream
import frame_eval.frame_tag_lib.utils as tag_utils


def single_frame_runner(row, **params):
    _frame_id, after_frame_id = row.frame_id, row.after_frame_id
    da_data_cols = params['mod_eval_conf']['da_data_cols']
    try:
        var_data = row.report_data
        var_data = sorted(var_data, key=lambda x: x.score, reverse=True)
        _score = var_data[0].score
        _status = var_data[0].status
        _short_report = var_data[0].short_report
        _report = var_data[0].report
        reform_dict_without_img = {
            'frame_id': _frame_id,
            'after_frame_id': after_frame_id,
            'short_report': _short_report,
            'report': _report,
            'status': _status,
            'score': _score,
            'is_valid': 1,
        }
        # 把namedtuple换成dict
        img_url_dict_list = [{'area_id': _.area_id, 'before_flag': _.before_flag,
                              'reform_id': _.reform_id, 'url': _.url} for _ in var_data]
        logging.debug('FRAME ID {}-{} START. '.format(_frame_id, after_frame_id))
        _ret_dict = reform_doc.fill_complete_docs(reform_dict_without_img, img_url_dict_list)
        return [_ret_dict[_[0]] for _ in da_data_cols]
    except:
        error_msg = 'FRAME ID {}-{} ERROR: {}'.format(_frame_id, after_frame_id,
                                                      str(traceback.format_exc()).replace('\n', '|'))
        logging.fatal(error_msg)
        is_valid = 0
        unknown_err_code = -2
        default_score = 0.0
        return [_frame_id, after_frame_id, unknown_err_code,
                default_score, error_msg, '', is_valid]


def logic_func(driver, raw_df, **params):
    """
     spark 逻辑处理
    :param driver: spark_util.SparkSqlDriver, spark 执行类
    :param raw_df: pyspark.sql.dataframe.DataFrame， sql 查询结果
    :param params: dict, 参数字典
    :return: result_df, 处理后的 DataFrame
    """
    raw_df = raw_df.persist()
    names = [_ for _, __ in params['mod_eval_conf']['da_data_cols']]
    # 过滤不需要计算的行
    raw_df_done = raw_df.filter("is_new != 'new' and status = 2")\
        .dropDuplicates(['frame_id', 'after_frame_id']).select(names).distinct()
    # 过滤出需要计算的增量
    raw_df_undo = raw_df.filter("is_new = 'new'").groupby(["frame_id", "after_frame_id"]).agg(
        functions.collect_list(
            functions.struct("area_id", "status", "score"
                             , "report", "short_report"
                             , "area_id", "reform_id",
                             "before_flag", "url")).alias(
            "report_data")
    )
    result_rdd = raw_df_undo.rdd.map(lambda row: single_frame_runner(row, **params))
    # join回去
    result_df = result_rdd.toDF(names)
    raw_df_union = raw_df_done.union(result_df)
    return raw_df_union


def main():
    """ 主函数 """
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    if len(sys.argv) < 2:
        logging.error("no less than 1 arguments!")
        sys.exit()

    pt_date = sys.argv[1]
    config_file = sys.argv[2]
    last_final_report_date = sys.argv[3]
    last_image_date = sys.argv[4]

    f = get_file_stream(config_file)
    conf = yaml.load(f)

    # 从配置文件读取参数
    spark_config_key = "frame_mod_eval_merge"
    spark_params = conf.get(spark_config_key, None)
    if spark_params is None:
        logging.error("lack {} in config file".format(spark_config_key))
        sys.exit(1)
    # 加载文案配置
    logic_function_params = spark_params["logic_params"]['logic_function_params']
    conf_params2 = dict()
    conf_params3 = dict()
    tag_utils.collect_conf_on_spark(r"frame_eval/frame_tag_lib/conf.yml", conf_params2)
    tag_utils.collect_conf_on_spark(r"frame_mod_eval/reform_docs.yml", conf_params3)
    logic_function_params.update(conf_params2)
    logic_function_params.update(conf_params3)
    # 补充参数
    spark_params["logic_params"]['logic_function_params'] = logic_function_params
    # pt
    spark_params["sql_params"]["pt_date"] = pt_date
    spark_params["sql_params"]["last_final_report_date"] = last_final_report_date
    spark_params["sql_params"]["last_image_date"] = last_image_date
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_function"] = logic_func
    # 存储pt
    spark_params["save_params"]["partition_params"] = {"pt": "{}000000".format(pt_date)}

    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()


if __name__ == "__main__":
    main()
