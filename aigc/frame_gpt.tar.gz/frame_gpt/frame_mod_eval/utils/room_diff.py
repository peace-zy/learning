# -*- coding: utf-8 -*-
"""
户改长短文案与md生成模块
Authors: yangdongxue004@ke.com
Date:    2021/8/15
"""
import json

from frame_mod_eval.utils.markdownIO import MarkDownIO, StrIO
from frame_mod_eval.utils.reform_func_tools import DocsGenerator, ImgTools, OtherTools
import frame_mod_eval.utils.room_doc_param as RDP


class FrameDiffEval(object):
    """
    两户型对比类
    """
    def __init__(self, frame_a, frame_b):
        """
        :param frame_a: 原户型 DiffFrame
        :param frame_b: 改户型 DiffFrame
        """
        # 原户型和改户型
        self.frame_a = frame_a
        self.frame_b = frame_b
        self.frame_a_url_path = frame_a.img_url
        self.frame_b_url_dict = dict()
        # 要进行解析的分间列表，由于目前是分析原户型的所有分间改造点，所以存储的是frame_a的所有分间通过room_factory模块生成的类
        self.room_list = []
        # 短文案与长文案json
        self.short_json = ''
        self.long_json = ''
        # 改造状态，0:未改造(无diff), 1:已改造(有diff)&有检测点覆盖, 2: 已改造(有diff)&未覆盖检测点. (负值在计算diff的时候已经返回)
        self.status = 0

    def judge_diff(self):
        """
        遍历两户型的墙体和附件，判断两户型是否完全相同.
        :param:
        :return: 返回布尔值，True表示有diff不完全相同，False表示没有diff完全相同
        """
        # 遍历frame_a的墙体
        for _room in self.frame_a.room_list:
            for _line in _room.room_lines:
                if not _line.is_matched:
                    return True
                # 遍历墙体上的附件
                for _line_item in _line.line_items:
                    if not _line_item.is_matched:
                        return True
        # 遍历frame_b的墙体
        for _room in self.frame_b.room_list:
            for _line in _room.room_lines:
                if not _line.is_matched:
                    return True
                # 遍历墙体上的附件
                for _line_item in _line.line_items:
                    if not _line_item.is_matched:
                        return True
        return False

    def constrained_condition(self):
        """
        一些特殊的约束条件，户型总面积过大则不考虑
        :return: 布尔变量，代表是否满足约束条件
        """
        if self.frame_a.area_size > 180 or self.frame_a.structure[0] > 5 or self.frame_b.structure[0] > 5:
            return False
        return True

    def generate_docs(self, reform_conf):
        """
        遍历原户型所有分间，分别计算每个分间的检测点，并存储在分间对象的docs_total列表内，同时计算状态变量status
        :param reform_conf: 固定文案的字典
        :return: 不重复的检测点列表, 列表检测点按照权重从大到小排序
        """
        # 将原户型的所有分间排序
        self.room_list = sorted(self.frame_a.room_list, key=lambda x: (x.spatial_weight, x.total_weight_of_reform), reverse=True)
        reform_point = list()
        # 检查两户型是否完全相同
        have_diff = self.judge_diff()
        # 计算是否满足自定义的约束条件
        constrained_satisfy = self.constrained_condition()
        # 如果不满足约束条件直接返回，这里记录一下状态变量status
        if have_diff and not constrained_satisfy:
            self.status = 1
            return reform_point
        elif not have_diff and not constrained_satisfy:
            self.status = 0
            return reform_point
        # 遍历原分间
        draw_poly_list = list()
        draw_img_config = reform_conf['mod_eval_conf']['draw_img']
        for _room in self.room_list:
            _room.reform_conf = reform_conf['compare_docs']
            _params = dict()
            _params['counter_frame'] = self.frame_a
            _params.update(reform_conf['mod_eval_conf'])
            _params['without_http'] = False
            line_draw_list, lineitem_draw_list = _room.personalized_label(_params)
            draw_poly_list = draw_poly_list + ImgTools.get_draw_poly(line_draw_list, obj_type='line', color=draw_img_config['line_color_changed'], fill="transparent", opacity=draw_img_config['line_opacity_changed'])
            draw_poly_list = draw_poly_list + ImgTools.get_draw_poly(lineitem_draw_list, obj_type='lineitem', color=draw_img_config['line_color_changed'], fill="transparent", opacity=draw_img_config['line_opacity_changed'])

            if len(_room.docs_total) == 0:
                continue
            # 将检测点前标记分间名称
            for _docs in _room.docs_total:
                reform_point.append((_room.std_name + '-' + _docs[0], _docs[-1]))

        _json_2 = self.frame_b.dump(draw_poly_list)
        # self.frame_b_url_dict = ImgTools.draw_json(_json_2, show=False, save_path=None, url=draw_img_config['draw_json_url'])[0]
        # self.frame_a_url_path = urlparse.urlparse(self.frame_a_url_path).path
        # 获取所有不重复的改造点标签
        reform_point = list(set(reform_point))
        # 计算状态
        if have_diff:
            if len(reform_point) > 0:
                self.status = 2
            else:
                self.status = 1
        # 将不重复的改造点按照改造点权重排序
        reform_point = sorted(reform_point, key=lambda x: x[-1], reverse=True)
        self.room_list = sorted(self.frame_a.room_list, key=lambda x: (x.spatial_weight, x.total_weight_of_reform), reverse=True)
        return reform_point

    def generate_md(self, reform_conf, calculate_precision=False):
        """
        生成改造点的md文件
        :param reform_conf: 固定文案的字典
        :calculate_precision: 如果该变量设置为True，则不写入md文件，只返回改造点列表方便统计
        :return: 不重复的检测点列表, 列表检测点按照权重从大到小排序
        """
        reform_point = self.generate_docs(reform_conf)
        if calculate_precision:
            return reform_point
        f1 = self.frame_a.frame_id
        f2 = self.frame_b.frame_id
        structure_a = self.frame_a.structure
        structure_b = self.frame_b.structure
        save_path = ''
        if reform_conf.get('md_batch', 0) == 1:
            save_path = 'data/reform_doc_pic/md/100.md'
        else:
            save_path_str = reform_conf['mod_eval_conf']['reform_docs']['ret_md_file']
            save_path = save_path_str.format(f1, f2)
        # 生成并打开save_path路径下的md文件
        mdIO = MarkDownIO(save_path)
        if reform_conf.get('md_batch', 0) == 1:
            mdIO.open(type_write='a+')
        else:
            mdIO.open(type_write='w')
        # 户改报告的标题、编号、图片、骨架图、基本信息
        # mdIO.write_html_topic('邻居家户型改造报告', center=True, font_size=7)
        if reform_conf.get('md_batch', 0) == 1:
            mdIO.write_md_topic('{}.邻居家户型改造报告'.format(reform_conf['md_batch_index']), level=1, next_line=True)
        else:
            mdIO.write_md_topic('邻居家户型改造报告', level=1, next_line=True)
        mdIO.write_html_topic('改造前后户型编号:{} -- {}'.format(f1, f2), center=True, font_size=5)
        mdIO.write_img_url([self.frame_a.img_url, self.frame_b_url_dict['bwb.c_s']])
        mdIO.write_img_local('../skeleton/{}-{}.jpg'.format(f1, f2))
        mdIO.write_text('原户型: ', emphasize=2, next_line=False, font_size=4)
        mdIO.write_text('{}室{}厅{}厨{}卫-{}m<sup>2</sup>'.format(structure_a[0], structure_a[1], structure_a[2], structure_a[3], OtherTools.cal_std_area(self.frame_a.area_size)), font_size=4)
        mdIO.write_text('邻居家:', emphasize=2, next_line=False, font_size=4)
        mdIO.write_text('{}室{}厅{}厨{}卫-{}m<sup>2</sup>'.format(structure_b[0], structure_b[1], structure_b[2], structure_b[3], OtherTools.cal_std_area(self.frame_b.area_size)), font_size=4)
        # 没有改造点的情况
        if len(reform_point) == 0:
            mdIO.write_text('不在筛选条件内, 没有当前的4个改造点(客厅改卧室、卧室-增加卧室、卧室-增加衣帽间、卧室-增加卫生间)', emphasize=2, font_size=4)
            mdIO.close()
            return reform_point
        # 如果户型面积特别大或者超过5室的情况
        if self.frame_a.area_size > 180 or structure_a[0] > 5 or structure_b[0] > 5:
            mdIO.write_text('不在筛选条件内, 面积太大{}m<sup>2</sup>'.format(self.frame_a.area_size), emphasize=2, font_size=4)
            mdIO.close()
            return reform_point
        # 展示在最上面的简单改造点标签列表文案
        str_in = DocsGenerator.generate_reform_points_list([_point[0] for _point in reform_point])
        mdIO.write_text(str_in, emphasize=2, next_line=True, font_size=4)
        draw_img_config = reform_conf['mod_eval_conf']['draw_img']
        for _room in self.room_list:
            if len(_room.docs_total) == 0:
                continue
            mdIO.write_text('\n', decorate=False)
            mdIO.write_md_topic('原户型-{}（空间权重{}）: '.format(_room.name, str(_room.spatial_weight)), level=3, next_line=True)
            for _cnt, _docs in enumerate(_room.docs_total):
                # 1.改造点及其附图
                mdIO.write_md_topic('{}.{}（改造点权重{}）: '.format(_cnt + 1, _docs[0], str(_docs[-1])), level=4, next_line=True)
                not_find_match1, not_find_match2 = _docs[-2]
                not_find_match1 = ImgTools.add_color_to_other_rooms(not_find_match1, self.frame_a, draw_img_config)
                not_find_match2 = ImgTools.add_color_to_other_rooms(not_find_match2, self.frame_b, draw_img_config)
                _json_1 = self.frame_a.dump(not_find_match1)
                _json_2 = self.frame_b.dump(not_find_match2)

                # 将改造前后分间标记的两张图拼接在一起并写入md文件
                _save_path_1 = draw_img_config['draw_img_origin_path'].format(f1, f2, _room.name, _docs[0], _cnt).decode('utf8')
                _save_path_2 = draw_img_config['draw_img_after_path'].format(f1, f2, _room.name, _docs[0], _cnt).decode('utf8')
                _save_path_3 = draw_img_config['draw_img_merge_path'].format(f1, f2, _room.name, _docs[0], _cnt).decode('utf8')
                _save = '![](../diff/{}-{}-{}-{}-{}.png)'.format(f1, f2, _room.name, _docs[0], _cnt)
                ImgTools.draw_json(_json_1, show=False, save_path=_save_path_1, url=draw_img_config['draw_json_url'])
                ImgTools.draw_json(_json_2, show=False, save_path=_save_path_2, url=draw_img_config['draw_json_url'])
                ImgTools.splice_image_in_oneline([_save_path_1, _save_path_2], _save_path_3, resolution=(1440, 1080))
                mdIO.write_text(_save)

                # 2.适合人群
                if _docs[1] != '':
                    mdIO.write_text('- ', next_line=False, decorate=False)
                    mdIO.write_text('适合人群: ', emphasize=2)
                    mdIO.write_text(_docs[1])

                # 3.原空间解析文案
                if _docs[2] != '':
                    mdIO.write_text('- ', next_line=False, decorate=False)
                    mdIO.write_text('原空间解析: ', emphasize=2)
                    mdIO.write_text(_docs[2])

                # 4.改造建议文案
                if _docs[3] != '':
                    mdIO.write_text('- ', next_line=False, decorate=False)
                    mdIO.write_text('改造建议: ', emphasize=2)
                    mdIO.write_text(_docs[3])

                # 5.改造后布局建议文案
                if len(_docs[4][0]) > 0:
                    mdIO.write_text('- ', next_line=False, decorate=False)
                    mdIO.write_text('改造后布局建议: ', emphasize=2)
                    for _suggest in _docs[4][0]:
                        mdIO.write_text('\t', next_line=False, decorate=False)
                        mdIO.write_text('{}:'.format(_suggest['typeName'].encode('utf8')), emphasize=2, next_line=False, decorate=False)
                        mdIO.write_text('{}'.format(_suggest['text'].encode('utf8')))
                    for img_url in _docs[4][1]:
                        mdIO.write_img_url([img_url])

                # 6.改造影响文案
                if len(_docs[5]) > 0:
                    mdIO.write_text('- ', next_line=False, decorate=False)
                    mdIO.write_text('改造影响: ', emphasize=2)
                    for _influence in _docs[5]:
                        mdIO.write_text('\t', next_line=False, decorate=False)
                        mdIO.write_text('{}:'.format(_influence['typeName'].encode('utf8')), emphasize=2, next_line=False, decorate=False)
                        mdIO.write_text('{}'.format(_influence['text'].encode('utf8')))
                    for img_url in _docs[6]:
                        mdIO.write_img_url([img_url])

        mdIO.close()
        return reform_point

    def generate_str_doc(self, reform_conf):
        """
        生成改造点的md文件
        :param reform_conf: 固定文案的字典
        :calculate_precision: 如果该变量设置为True，则不写入md文件，只返回改造点列表方便统计
        :return: 不重复的检测点列表, 列表检测点按照权重从大到小排序
        """
        reform_point = self.generate_docs(reform_conf)
        f1 = self.frame_a.frame_id
        f2 = self.frame_b.frame_id
        structure_a = self.frame_a.structure
        structure_b = self.frame_b.structure
        # 生成并打开save_path路径下的md文件
        mdIO = StrIO()
        # 户改报告的标题、编号、图片、骨架图、基本信息
        # mdIO.write_html_topic('邻居家户型改造报告', center=True, font_size=7)
        mdIO.write_text('原始{}室{}厅{}厨{}卫'.format(structure_a[0], structure_a[1], structure_a[2], structure_a[3],next_line=False))
        mdIO.write_text('改造{}室{}厅{}厨{}卫;'.format(structure_b[0], structure_b[1], structure_b[2], structure_b[3],next_line=True))
        # 如果户型面积特别大或者超过5室的情况
        if self.frame_a.area_size > 180 or structure_a[0] > 5 or structure_b[0] > 5:
            return reform_point
        # 展示在最上面的简单改造点标签列表文案
        str_in = DocsGenerator.generate_reform_points_list([_point[0] for _point in reform_point])
        mdIO.write_text(str_in, next_line=False)
        for _room in self.room_list:
            if len(_room.docs_total) == 0:
                continue
            mdIO.write_text(';\n')
            mdIO.write_text('{}:'.format(_room.name, str(_room.spatial_weight)))
            for _cnt, _docs in enumerate(_room.docs_total):
                # 1.改造点及其附图
                mdIO.write_text('-{}'.format(_docs[0], str(_docs[-1])), next_line=True)

                # 2.适合人群
                if _docs[1] != '':
                    # mdIO.write_text('- ', next_line=False)
                    mdIO.write_text('人群:', next_line=False)
                    mdIO.write_text(_docs[1])

                # 3.原空间解析文案
                if _docs[2] != '':
                    # mdIO.write_text('- ', next_line=False)
                    mdIO.write_text('原空间:', next_line=False)
                    mdIO.write_text(_docs[2])

                # 4.改造建议文案
                if _docs[3] != '':
                    # mdIO.write_text('- ', next_line=False)
                    mdIO.write_text('建议:', next_line=False)
                    mdIO.write_text(_docs[3])
                # 5.改造后布局建议文案
                if len(_docs[4][0]) > 0:
                    mdIO.write_text('- ', next_line=False)
                    mdIO.write_text('改造后布局建议:')
                    for _suggest in _docs[4][0]:
                        mdIO.write_text('\t', next_line=False)
                        mdIO.write_text('{}:'.format(_suggest['typeName'].encode('utf8')), next_line=False,)
                        mdIO.write_text('{}'.format(_suggest['text'].encode('utf8')))
                # 6.改造影响文案
                if len(_docs[5]) > 0:
                    mdIO.write_text('影响,', next_line=False)
                    for _influence in _docs[5]:
                        mdIO.write_text('{}:'.format(_influence['typeName']), )
                        mdIO.write_text('{}'.format(_influence['text']))



        return mdIO

    def generate_docs_without_http(self, reform_conf):
        """
        遍历原户型所有分间，分别计算每个分间的检测点，并存储在分间对象的docs_total列表内，同时计算状态变量status
        :param reform_conf: 固定文案的字典
        :return: 不重复的检测点列表, 列表检测点按照权重从大到小排序
        """
        # 将原户型的所有分间排序
        self.room_list = sorted(self.frame_a.room_list, key=lambda x: (x.spatial_weight, x.total_weight_of_reform), reverse=True)
        reform_point = list()
        # 检查两户型是否完全相同
        have_diff = self.judge_diff()
        # 计算是否满足自定义的约束条件
        constrained_satisfy = self.constrained_condition()
        # 如果不满足约束条件直接返回，这里记录一下状态变量status
        if have_diff and not constrained_satisfy:
            self.status = 1
            return reform_point
        elif not have_diff and not constrained_satisfy:
            self.status = 0
            return reform_point
        # 遍历原分间
        draw_poly_list = list()
        draw_img_config = reform_conf['mod_eval_conf']['draw_img']
        for _room in self.room_list:
            _room.reform_conf = reform_conf['compare_docs']
            _params = dict()
            _params['counter_frame'] = self.frame_a
            _params.update(reform_conf['mod_eval_conf'])
            _params['without_http'] = True
            line_draw_list, lineitem_draw_list = _room.personalized_label(_params)
            draw_poly_list = draw_poly_list + ImgTools.get_draw_poly(line_draw_list, obj_type='line', color=draw_img_config['line_color_changed'], fill="transparent", opacity=draw_img_config['line_opacity_changed'])
            draw_poly_list = draw_poly_list + ImgTools.get_draw_poly(lineitem_draw_list, obj_type='lineitem', color=draw_img_config['line_color_changed'], fill="transparent", opacity=draw_img_config['line_opacity_changed'])

            if len(_room.docs_total) == 0:
                continue
            # 将检测点前标记分间名称
            for _docs in _room.docs_total:
                reform_point.append((_room.std_name + '-' + _docs[0], _docs[-1]))

        self.frame_b_url_dict = draw_poly_list
        # 获取所有不重复的改造点标签
        reform_point = list(set(reform_point))
        # 计算状态
        if have_diff:
            if len(reform_point) > 0:
                self.status = 2
            else:
                self.status = 1
        # 将不重复的改造点按照改造点权重排序
        reform_point = sorted(reform_point, key=lambda x: x[-1], reverse=True)
        self.room_list = sorted(self.frame_a.room_list, key=lambda x: (x.spatial_weight, x.total_weight_of_reform), reverse=True)
        return reform_point

    def generate_json_without_http(self, reform_conf):
        """
        生成改造点的长文案和短文案json
        :param reform_conf: 固定文案的字典
        :return: 列表，[短文案json, 长文案json, 状态值status]
        """
        # 生成分间改造点文案
        reform_point = self.generate_docs_without_http(reform_conf)
        # 短文案json，包括frame_origin、frame_aft、reform_point_all三个字典
        frame_origin = {"frame_id": self.frame_a.frame_id, "area_size": self.frame_a.area_size,
                     "bedroom": self.frame_a.structure[0], "parlor": self.frame_a.structure[1],
                     "kitchen": self.frame_a.structure[2], "toilet": self.frame_a.structure[3], "img_url": self.frame_a_url_path}
        frame_after = {"frame_id": self.frame_b.frame_id, "area_size": self.frame_b.area_size,
                     "bedroom": self.frame_b.structure[0], "parlor": self.frame_b.structure[1],
                     "kitchen": self.frame_b.structure[2], "toilet": self.frame_b.structure[3], "img_url": self.frame_b_url_dict}
        reform_point_all = []
        for _point in reform_point:
            _dict_tmp = {"reform_name": _point[0], "reform_id": RDP.REFORM_POINT_INDEX[_point[0]], "reform_weight": _point[1]}
            reform_point_all.append(_dict_tmp)
        short_dict = {"frame_origin": frame_origin, "frame_after": frame_after, "reform_point_all": reform_point_all}
        self.short_json = json.dumps(short_dict)

        # 长文案json，包括frame_origin、frame_after、reform_point_all、room_list四个字典
        long_dict = short_dict
        reform_room_list = []
        draw_img_config = reform_conf['mod_eval_conf']['draw_img']
        for _room in self.room_list:
            if len(_room.docs_total) == 0:
                continue
            room_tmp = dict()
            room_tmp['room_name'] = _room.name
            room_tmp['belong_to_ori'] = 1
            room_tmp['space_weight'] = _room.spatial_weight
            room_tmp['area_id'] = _room.uid
            _reform_point = list()
            for _cnt, _docs in enumerate(_room.docs_total):
                _docs_dict = dict()
                _docs_dict["reform_name"] = _docs[0]
                _docs_dict["reform_id"] = RDP.REFORM_POINT_INDEX['{}-{}'.format(_room.std_name, _docs[0])]
                _docs_dict["reform_weight"] = _docs[-1]

                # 生成改造前后标注图
                not_find_match1, not_find_match2 = _docs[-2]

                # 获取户改前图片标注后的url
                not_find_match1 = ImgTools.add_color_to_other_rooms(not_find_match1, self.frame_a, draw_img_config)
                _docs_dict["ori_reform_img_url"] = not_find_match1
                # 获取户改后图片标注后的url
                not_find_match2 = ImgTools.add_color_to_other_rooms(not_find_match2, self.frame_b, draw_img_config)
                _docs_dict["aft_reform_img_url"] = not_find_match2

                _docs_dict["app_crowd"] = ""
                _docs_dict["ori_analysis"] = _docs[2]
                _docs_dict["reform_suggest"] = _docs[3]
                _docs_dict["layout_suggest_param"] = _docs[4]
                _docs_dict["reform_influence"] = _docs[5]
                _docs_dict["reform_influence_img_url"] = _docs[6]
                _reform_point.append(_docs_dict)
            room_tmp["reform_point"] = _reform_point
            reform_room_list.append(room_tmp)
        long_dict["room_list"] = reform_room_list
        self.long_json = json.dumps(long_dict)
        return [self.short_json, self.long_json, self.status]