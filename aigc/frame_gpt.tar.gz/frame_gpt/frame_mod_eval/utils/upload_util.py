# -*- coding: utf-8 -*-
# ===============================================================
#
#    Copyright (C) 2019 Beike, Inc. All Rights Reserved.
#
#    @Create Author : 李雨龙 (liyulong008@ke.com)
#    @Create Time   : 2018-04-17 15:30
#    @Description   : web服务入口
#
# ===============================================================
import requests
import traceback
import hashlib
import time
import urllib
import redis

from lib import log as logger


def get_now_ms():
    """
    获取当前ms时间
    :return:
    """
    return int(1000 * time.time())


class ImageUploadConfig(object):
    """
    图片上传配置
    """
    # 超时
    time_out = 8

    # 签名过期时间
    exp = 85400

    return_result = {
        'Code': "",
        'Msg': "",
        'Data': {
            'V1': {
                "Urls": {}
            }
        },
        'Error': "",
        'XRequestId': ""
    }

    # 线上
    config_info = {
        'AccessKey': "DF010000282D",  # 此AK仅用于测试，业务使用请替换
        'SecretKey': "9C1492089A1F3BB82806D1C15D5185F2",  # 此SK仅用于测试，业务使用请替换
        'Album': "frame-mod-report",  # 测试用途 public 图库，业务使用请替换
        'EndPoint': "https://iupload.ke.com/upload/",  # 图片上传节点，上传地址需末尾拼上album
    }

    # B端扫一扫url加签
    B_config = {
        'AccessKey': "DF0100002C1F",
        'SecretKey': "320D16F7B231F2C986CF8EA92C964C8F",
    }


def upload_s3_img(request_id, image_data):
    """
    upload image to s3
    :param request_id: request_id
    :param image_data: binary image
    :return:
    """
    t1 = get_now_ms()
    logger.debug('{}\tUPLOAD_IN\t{}'.format(request_id, t1))
    time_span = 0
    try:
        upload_url = ImageUploadConfig.config_info["EndPoint"] + ImageUploadConfig.config_info["Album"]
        _data_result, success_status = upload(image_data, upload_url, ImageUploadConfig.config_info["AccessKey"],
                                              ImageUploadConfig.config_info["SecretKey"], ImageUploadConfig.exp)
        t2 = get_now_ms()
        time_span = t2 - t1
        if not success_status:
            error_msg = '{}\tUPLOAD_S3_IMG\t{}'.format(request_id, _data_result)
            logger.error(error_msg)
            raise Exception(error_msg)
        else:
            logger.debug('{}\tUPLOAD_S3_IMG_RES\t{}'.format(request_id, _data_result))
            return _data_result, time_span
    except Exception as ex:
        error_msg = "{}\tUPLOAD_S3_IMG_UNKNOWN\t{}".format(request_id, traceback.print_stack())
        logger.fatal(error_msg)
        raise Exception(error_msg)


def upload(img_data, upload_url, access_key, secret_key, exp):
    signed_upload_url, success_status = sign_url(upload_url, access_key, secret_key, exp)
    if success_status:
        return do_upload(img_data, signed_upload_url)
    else:
        return None, False


def sign_url(to_sign_url, access_key, secret_key, expire_seconds):
    if not 1 <= expire_seconds <= 86400:
        raise Exception("Invalid expire seconds, should be in 1~86400")
    if access_key == "" or secret_key == "":
        raise Exception("Invalid AccessKey or SecretKey")
    url = urlparse(to_sign_url)
    parameters = dict()
    parameters["ak"] = access_key
    parameters["ts"] = str(int(time.time()))
    parameters["exp"] = str(expire_seconds)
    string_to_sign = url.path + parameters.get("ak") + parameters.get("ts") + str(expire_seconds) + secret_key
    sign = hash_md5(string_to_sign.encode(encoding="utf8"))
    parameters["sign"] = sign
    parameters_encode = urllib.urlencode(parameters)
    return to_sign_url + '?' + parameters_encode, True


def hash_md5(src):
    md5obj = hashlib.md5()
    md5obj.update(src)
    return md5obj.hexdigest()


def do_upload(img_data, signed_upload_url):
    upload_file = {'image': img_data}
    data_result = requests.post(signed_upload_url, files=upload_file, timeout=ImageUploadConfig.time_out)
    if data_result.json()["code"] != "OK":
        return None, False
    else:
        result_json = data_result.json()
        return result_json["data"]["v1"]["urls"], True


def try_fetch():
    url = 'https://p.ke.com/v1/bk.c_s/p/frame-r2v/08f1d39df90510ccbd0118ac0220ed01280130013887ec03.jpeg'
    signed_upload_url, success_status = sign_url(url, ImageUploadConfig.config_info["AccessKey"], ImageUploadConfig.config_info["SecretKey"], ImageUploadConfig.exp)
    data_result = requests.get(signed_upload_url, timeout=ImageUploadConfig.time_out)
    print('done')


def upload2redis(reform_str, host="m13405.zeus.redis.ljnode.com",
                 port=13405, password="X3h0RYOf01MZ1qbN", queue='reform_render'):
    """上传户改对至redis，https://wiki.lianjia.com/pages/viewpage.action?pageId=900143149"""
    redis_conn = redis.StrictRedis(host=host,
                                   port=port,
                                   db=0,
                                   password=password)
    pipeline = redis_conn.pipeline()
    pipeline.lpush(queue, reform_str)
    pipeline.execute()
    pipeline.close()


if __name__ == '__main__':
    # logger.init('DEBUG', './mod_eval.log')
    #
    # _image_data = open('20210817141621.png', 'rb').read()
    # __data_result = upload_s3_img('12321', _image_data)
    # print(__data_result)

    # try_fetch()

    import json

    with open('reform.json', 'r') as f:
        reform_json = json.load(f)
    json.dumps(reform_json)
    upload2redis(reform_json)
