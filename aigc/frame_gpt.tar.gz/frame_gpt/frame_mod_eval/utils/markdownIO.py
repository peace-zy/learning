# -*- coding: utf-8 -*-
"""
markdown读写类
Authors: yangdongxue004@ke.com
Date:    2021/8/15
"""


class MarkDownIO(object):
    def __init__(self, save_path):
        self.save_path = save_path
        self.file_write_obj = None

    def open(self, type_write='w'):
        self.file_write_obj = open(self.save_path.decode('utf8'), type_write)
        print('户改文案将写入markdown文件: ' + self.save_path + '中，该文件已打开\n')

    def write_html_topic(self, text, center=False, font_size=0, next_line=True):
        if font_size > 0:
            str_in = '<font size=\'{}\'>'.format(font_size) + text + '</font>'
        if center is True:
            str_in = '<div align=\'center\'>' + str_in + '</div>'
        if next_line is True:
            str_in = str_in + '\n'
        self.file_write_obj.writelines(str_in)

    def write_md_topic(self, text, level=0, next_line=True):
        str_in = '#' * level + ' '
        str_in = str_in + text
        if next_line is True:
            str_in = str_in + '\n'
        self.file_write_obj.writelines(str_in)

    def write_text(self, text, emphasize=0, next_line=True, font_size=3, decorate=True):
        # if isinstance(text, unicode):
        #     text = text.encode('utf8')
        empha = '*' * emphasize
        str_in = ''
        str_in = str_in + empha
        str_in = str_in + text
        str_in = str_in + empha
        if decorate is True:
            str_in = '<font size={}>'.format(font_size) + str_in + '</font>'
        if next_line is True:
            str_in = str_in + '\n\n'
        self.file_write_obj.writelines(str_in)

    def write_img_url(self, img_url_list):
        str_in = ''
        for img_url in img_url_list:
            str_in = str_in + '<img src=\"' + img_url + '\" width=\"470\"/>'
        str_in = str_in + '\n'
        self.file_write_obj.writelines(str_in.encode('utf8'))

    def write_img_local(self, img_path):
        str_in = '\n![]'
        str_in = str_in + '(' + img_path + ')'
        str_in = str_in + '\n'
        self.file_write_obj.writelines(str_in.encode('utf8'))

    def close(self):
        self.file_write_obj.close()
        print('户改markdown文件：' + self.save_path + '已关闭\n')


class StrIO(object):
    def __init__(self):
        self.file_write_obj = ''
        self.img_path = ''
        self.match_diff = 0

    # def write_html_topic(self, text):
    #     self.file_write_obj += '[{}]'.format(text)

    def write_md_topic(self, text, level=0, next_line=True):
        str_in = '#' * level + ' '
        str_in = str_in + text
        if next_line is True:
            str_in = str_in + '\n'
        self.file_write_obj += str_in

    def write_text(self, text, emphasize=0, next_line=True):
        empha = '*' * emphasize
        str_in = ''
        str_in = str_in + empha
        str_in = str_in + text
        str_in = str_in + empha
        if next_line is True:
            str_in = str_in + '\n'
        self.file_write_obj += str_in
