# -*- coding: utf-8 -*-
"""
分间与户型类对象生成模块
Authors: yangdongxue004@ke.com
Date:    2021/8/15
"""
import copy

import frame_mod_eval.entity.frame_diff_entity as FDE
import frame_mod_eval.utils.room_doc_param as RDP
import lib.diff_util as DU
from frame_mod_eval.utils.reform_func_tools import DocsGenerator, ImgTools, OtherTools, NameTools


class RoomFactory(object):
    @staticmethod
    def room_obj(room, params_dict):
        # 如果是厅那么创建LivingRoom类对象
        if room.room_type == RDP.RoomClassEnum.parlor.value:
            return LivingRoom(room, params_dict)
        # 如果是卧室、主卧、次卧则创建BedRoom类对象
        if room.detail_type == RDP.RoomNameEnum.bedroom.value or room.detail_type == RDP.RoomNameEnum.mainroom or room.detail_type == RDP.RoomNameEnum.secondary_bedroom:
            return BedRoom(room, params_dict)
        # 其余情况创建父类RoomObj对象
        return RoomObj(room, params_dict)


class FrameObj(object):
    _FLOOR_PLAN_KEY = FDE.FrameStdVecObj._FLOOR_PLAN_KEY
    _DEFAULT_FLOOR_IDX = FDE.FrameStdVecObj._DEFAULT_FLOOR_IDX
    _POINT_KEY = FDE.FrameStdVecObj._POINT_KEY
    _LINE_KEY = FDE.FrameStdVecObj._LINE_KEY
    _AREA_KEY = FDE.FrameStdVecObj._AREA_KEY
    _LINE_ITEM_KEY = FDE.FrameStdVecObj._LINE_ITEM_KEY
    _FEATURES_KEY = 'features'
    _FEATURES_OPPOSITE_KEY = 'features_opposite'
    _ID_OPPOSITE_KEY = 'id_opposite'
    _FRAME_LABEL = 'frame_label'
    _AREA_ID_KEY = 'area_id'
    _WIDTH_KEY = 'width'
    _DEPTH_KEY = 'depth'
    _FACE_KEY = 'face'
    _AREA_SIZE = 'area_size'
    _EXTRA_FEATURES = 'extra_features'
    _ROOM_LABEL = 'cluster_room_label'

    def __init__(self, frame, params_dict):
        """
        户型扩展类.
        :param frame: 通过frame_diff模块下frame_diff方法返回的户型对象
        :param params_dict: 参数字典,传入户型特征、标签、格局等变量
        :return:
        """
        self.__dict__.update(frame.__dict__)
        # 户型面积, 该面积被标准化为平方米为单位
        self.area_size = OtherTools.cal_std_area(frame.area_size)
        # 调用户型解读的case_study得到的户型特征字典,features_opposite为对比的户型特征字典, id_opposite为对比户型的frame_id
        self.features = params_dict[self._FEATURES_KEY]
        self.features_opposite = params_dict[self._FEATURES_OPPOSITE_KEY]
        self.id_opposite = params_dict[self._ID_OPPOSITE_KEY]
        # 长度为4的列表,代表该户型室厅厨卫数量
        self.structure = [self.features[u'whole'][0][u'shi'], self.features[u'whole'][0][u'ting'], self.features[u'whole'][0][u'chu'], self.features[u'whole'][0][u'wei']]
        # 该户型id对应的原图片url
        self.img_url = ''
        # if not params_dict.get('without_http', False):
        #     self.img_url = ImgTools.get_img_url(self.frame_id)
        # 该户型的解读标签(动静分明、南北通透等)
        self.label = params_dict.get(self._FRAME_LABEL, 0)
        # 该户型所包含的所有分间类对象
        self.room_list = []
        pass

    @property
    def extra_feature_dict(self):
        """
        该户型的特征字典.
        :param:
        :return: 返回字典,key=frame_id + area_id,value为包含面宽、进深、朝向和分间面积的字典
        """
        ef_dict = dict()
        for _, _value in self.features.items():
            for _fea_dic in _value:
                if _fea_dic.get(self._AREA_ID_KEY, '') == '':
                    continue

                ef_dict[self.frame_id + _fea_dic[self._AREA_ID_KEY]] = {
                    self._WIDTH_KEY: _fea_dic.get(self._WIDTH_KEY, 0),
                    self._DEPTH_KEY: _fea_dic.get(self._DEPTH_KEY, 0),
                    self._FACE_KEY: _fea_dic.get(self._FACE_KEY, ''),
                    self._AREA_SIZE: _fea_dic.get(self._AREA_SIZE, 0),
                    self._ROOM_LABEL: _fea_dic.get(self._ROOM_LABEL, '')
                }
        for _, _value in self.features_opposite.items():
            for _fea_dic in _value:
                if _fea_dic.get(self._AREA_ID_KEY, '') == '':
                    continue
                ef_dict[self.id_opposite + _fea_dic[self._AREA_ID_KEY]] = {
                    self._WIDTH_KEY: _fea_dic.get(self._WIDTH_KEY, 0),
                    self._DEPTH_KEY: _fea_dic.get(self._DEPTH_KEY, 0),
                    self._FACE_KEY: _fea_dic.get(self._FACE_KEY, ''),
                    self._AREA_SIZE: _fea_dic.get(self._AREA_SIZE, 0),
                    self._ROOM_LABEL: _fea_dic.get(self._ROOM_LABEL, '')
                }
        return ef_dict

    def cal_related_room(self, config_params):
        """
        计算与本分间相关的分间,包括吃掉了哪个分间的面积,被哪些分间吃掉了面积
        """
        for _room_iter in self.area_list:
            # 生成分间的扩展类RoomObj对象
            _extra_features = self.extra_feature_dict[self.frame_id + _room_iter.uid]
            # _extra_features = self.extra_feature_dict[self.frame_id + _room_iter.uid]
            _params_dict = dict()
            _params_dict[self._EXTRA_FEATURES] = _extra_features
            _room = RoomFactory.room_obj(_room_iter, _params_dict)
            self.room_list.append(_room)
            # 遍历该分间匹配到的分间,搜索所有吃掉自己面积的分间对象,存入passive列表
            for _match in _room.matched_obj:
                # 相交小于阈值的则认为二者不相交
                if _match[1] <= config_params[RDP.THRESHOLD_AREA_MATCH_KEY]:
                    continue
                # 生成匹配分间的扩展类RoomObj对象
                _extra_features = self.extra_feature_dict[self.id_opposite + _match[0].uid]
                _params_dict = dict()
                _params_dict[self._EXTRA_FEATURES] = _extra_features
                _match_room = RoomFactory.room_obj(_match[0], _params_dict)
                _match_room.intersect_area = OtherTools.cal_std_area(_match[1])

                # 判断两个分间类型是否相同, 将当前分间匹配到的同类型面积最大的分间作为变换后的自己,即room_same_class
                _flag = (_room.detail_type == _match_room.detail_type) or (_room.room_type == _match_room.room_type and _room.room_type == RDP.RoomClassEnum.parlor.value)
                if not _flag:
                    _room.passive.append(_match_room)
                else:
                    if _room.room_same_class is None:
                        _room.room_same_class = _match_room
                    else:
                        if _match_room.intersect_area <= _room.room_same_class.intersect_area:
                            _room.passive.append(_match_room)
                        else:
                            _room.passive.append(_room.room_same_class)
                            _room.room_same_class = _match_room

            # 如果_room.room_same_class为None,则代表该分间改造后消失
            if _room.room_same_class is None:
                continue
            # 遍历该分间匹配到的分间,搜索所有自己吃掉面积的分间对象,存入proactive列表
            for _match in _room.room_same_class.matched_obj:
                # 如果当前分间和_match是同一个分间、或者不是同一分间但相交小于阈值的则认为二者不相交
                if _room.uid == _match_room.uid or _match[1] < config_params[RDP.THRESHOLD_AREA_MATCH_KEY]:
                    continue
                _extra_features = self.extra_feature_dict[self.frame_id + _match[0].uid]
                _params_dict = dict()
                _params_dict[self._EXTRA_FEATURES] = _extra_features
                _match_room = RoomFactory.room_obj(_match[0], _params_dict)
                _match_room.intersect_area = OtherTools.cal_std_area(_match[1])
                _room.proactive.append(_match_room)

    def dump(self, polygons):
        """
        导出dict(从frame_diff_entity粘过来的)
        :param polygons: 需要
        :return:
        """
        self.dump_frame_json[self._FLOOR_PLAN_KEY][self._DEFAULT_FLOOR_IDX][self._POINT_KEY] = [_.dump() for _ in self.corner_list]
        self.dump_frame_json[self._FLOOR_PLAN_KEY][self._DEFAULT_FLOOR_IDX][self._LINE_KEY] = [_.dump() for _ in self.wall_list]
        _tmp_wall_item_dump_list = []
        for _wall_item in self.wall_item_list:
            _tmp_wall_dump = copy.deepcopy(_wall_item.dump())
            # if _wall_item.entrance is not None:
            #     _tmp_wall_dump['entrance'] = None
            _tmp_wall_item_dump_list.append(_tmp_wall_dump)
        self.dump_frame_json[self._FLOOR_PLAN_KEY][self._DEFAULT_FLOOR_IDX][
            self._LINE_ITEM_KEY] = _tmp_wall_item_dump_list
        self.dump_frame_json[self._FLOOR_PLAN_KEY][self._DEFAULT_FLOOR_IDX][self._AREA_KEY] = [_.dump() for _ in self.area_list]
        self.dump_frame_json[self._FLOOR_PLAN_KEY][self._DEFAULT_FLOOR_IDX]['items'] = []
        if polygons:
            self.dump_frame_json[self._FLOOR_PLAN_KEY][self._DEFAULT_FLOOR_IDX]['polygons'] = polygons
        else:
            self.dump_frame_json[self._FLOOR_PLAN_KEY][self._DEFAULT_FLOOR_IDX]['polygons'] = []
        return self.dump_frame_json


class RoomObj(FDE.Room):
    _EXTRA_FEATURES = 'extra_features'
    _WIDTH_KEY = 'width'
    _DEPTH_KEY = 'depth'
    _FACE_KEY = 'face'
    _AREA_SIZE = 'area_size'
    _ROOM_LABEL = 'cluster_room_label'

    def __init__(self, room, params_dict):
        """
        分间扩展类.
        :param room: 通过frame_diff_entity模块下Room方法返回的分间对象
        :param params_dict: 参数字典,传入分间特征、权重
        :return:
        """
        self.__dict__.update(room.__dict__)
        extra_features = params_dict[self._EXTRA_FEATURES]
        # 面宽、进深、朝向、面积
        self.width = extra_features.get(self._WIDTH_KEY, -1)
        self.depth = extra_features.get(self._DEPTH_KEY, -1)
        self.face = NameTools.face_engname_to_std_name(extra_features.get(self._FACE_KEY, ''))
        self.room_label = extra_features.get(self._ROOM_LABEL, '')
        self.area_size = OtherTools.cal_std_area(self.area_size)
        # 分间标准名称、权重
        self.std_name = RDP.SUB_ROOM_NAME[self.detail_type][0]
        self.spatial_weight = RDP.SUB_ROOM_NAME[self.detail_type][2]
        self.total_weight_of_reform = 0
        self.name = self.name

        # 该分间被哪些分间吃掉了面积
        self.passive = []
        # 该分间吃掉了哪些分间的面积
        self.proactive = []
        # 该分间变成了对面户型的哪个分间,如果该分间改造后消失则为None
        self.room_same_class = None
        # 该分间与对面户型某个相交分间的交叠面积
        self.intersect_area = 0

        # 分间对应的文案、标签
        self.docs_total = []
        # 文案字典
        self.reform_config = dict()

    @property
    def intersect_ratio(self):
        # 该分间与对面户型某个相交分间的交叠面积/该分间的面积
        return round(self.intersect_area/self.area_size, 2)

    @property
    def intersect_abs_area(self):
        # |该分间与对面户型某个相交分间的交叠面积 - 该分间面积|
        return abs(self.intersect_area - self.area_size)

    @property
    def line_id_dict(self):
        """
        该分间所有墙体关联分间的字典.
        :return: 返回字典,key = 墙体id,value = (分间1名称,分间2名称),如果为外墙则不存储
        """
        id_dict = dict()
        for _line in self.room_lines:
            _related = list(_line.rooms)
            if len(_related) < 2:
                continue
            id_dict[_line.uid] = (_related[0].name, _related[1].name, _related[0].detail_type, _related[1].detail_type)
        return id_dict

    def find_change_origin(self, draw_img_config, room_list=[], line_list=[], lineitem_list=[]):
        """
        搜索改造前户型需要上色的分间、墙体和附件
        :param draw_img_config: 绘图参数字典
        :param room_list: 改造分间列表
        :param line_list: 改造墙体列表
        :param lineitem_list: 改造墙体附件列表
        :return: 绘图的多边形列表、未匹配到的墙体列表、未匹配到的墙体带有的所有附件序号集合、未匹配的墙体附件、未匹配到的墙体附件序号集合
        """
        draw_poly = []
        # 1.面
        draw_poly = draw_poly + ImgTools.get_draw_poly([self], obj_type='room', color=draw_img_config['area_color_origin'], fill=draw_img_config['area_color_origin'], opacity=draw_img_config['area_opacity_origin'])
        # 2.线
        lines_notmatch = []
        line_type = set()
        # 3.附件
        lineitems_notmatch = []
        lineitems_set = set()
        return draw_poly, lines_notmatch, line_type, lineitems_notmatch, lineitems_set

    def find_change_after(self, draw_img_config, room_list=[], line_list=[], lineitem_list=[]):
        """
        搜索改后户型需要上色的分间、墙体和附件
        :param draw_img_config: 绘图参数字典
        :param room_list: 改造分间列表
        :param line_list: 改造墙体列表
        :param lineitem_list: 改造墙体附件列表
        :return: 绘图的多边形列表、未匹配到的墙体列表、未匹配到的墙体带有的所有附件序号集合、未匹配的墙体附件、未匹配到的墙体附件序号集合
        """
        draw_poly = []
        # 1.面
        # 原分间多边形
        if room_list[0] is not None:
            draw_poly = draw_poly + ImgTools.get_draw_poly([room_list[0]], obj_type='room', color=draw_img_config['area_color_origin'], fill=draw_img_config['area_color_origin'], opacity=draw_img_config['area_opacity_origin'])
        # 如果有新增加的分间则返回需要涂色的多边形
        if room_list[1] is not None:
            draw_poly = draw_poly + ImgTools.get_draw_poly([room_list[1]], obj_type='room', color=draw_img_config['area_color_add'], fill=draw_img_config['area_color_add'], opacity=draw_img_config['area_opacity_add'])

        # 2.线
        lines_notmatch = []
        line_type = set()
        for _line in line_list:
            if _line.is_matched is False and _line.is_almost_matched is False and _line.length > 100 and not _line.edge_computed:
                lines_notmatch.append(_line)
                for _lineitem in _line.line_items:
                    line_type.add(_lineitem.type)
        draw_poly = draw_poly + ImgTools.get_draw_poly(lines_notmatch, obj_type='line', color=draw_img_config['line_color_changed'], fill="transparent", opacity=draw_img_config['line_opacity_changed'])

        # 3.附件
        lineitems_notmatch = []
        lineitems_set = set()
        for _line in lineitem_list:
            for _line_item in _line.line_items:
                if _line_item.is_matched is False:
                    lineitems_set.add(_line_item.type)
                    lineitems_notmatch.append(_line_item)
        draw_poly = draw_poly + ImgTools.get_draw_poly(lineitems_notmatch, obj_type='lineitem', color=draw_img_config['lineitem_color_changed'], fill="transparent", opacity=draw_img_config['lineitem_opacity_changed'])
        return draw_poly, lines_notmatch, line_type, lineitems_notmatch, lineitems_set

    def personalized_label(self, params_dict):
        line_draw_list = list()
        lineitem_draw_list = list()
        return line_draw_list, lineitem_draw_list


class BedRoom(RoomObj):
    def __init__(self, room, params_dict):
        super(BedRoom, self).__init__(room, params_dict)
        self.room_label = self.get_bedroom_label()

    def get_bedroom_label(self):
        width_flag = 0
        depth_flag = 0
        for _param in RDP.BEDROOM_STYLE_WIDTH_THRESHOLD:
            if self.width < _param[0]:
                width_flag = _param[1]
                break
        for _param in RDP.BEDROOM_STYLE_DEPTH_THRESHOLD:
            if self.depth < _param[0]:
                depth_flag = _param[1]
                break
        return '{}|{}'.format(width_flag, depth_flag)

    def judge_add_bedroom(self, related_room, params_dict):
        lines_notmatch2 = list()
        lineitems_notmatch2 = list()
        # 如果相交的面积占关联分间的比例没达到阈值,说明关联分间不完全从本分间分离出来,因此不算做增加分间
        if related_room.intersect_ratio < params_dict['reform_docs']['threshold_partition'] and related_room.intersect_abs_area > params_dict['reform_docs']['threshold_partition_abs']:
            return lines_notmatch2, lineitems_notmatch2
        _reform_doc_tmp = list()
        # 0.改造点标签
        _reform_doc_tmp.append('增加{}'.format(related_room.std_name))
        # 1.适合人群
        _reform_doc_tmp.append('')
        # 2.原空间解析
        _str_in = '{},属于{}的{};{};'.format(
            self.name + DocsGenerator.generate_bedroom_size_common_docs(self.width, self.depth, self.area_size, face=self.face),
            DocsGenerator.generate_bedroom_type_docs(self.width, self.depth, what='type'),
            self.std_name,
            DocsGenerator.generate_reform_conf_docs(self.reform_conf, ['bedroom', 'bedroom', RDP.ADD_NUM_KEY, RDP.PROBLEM_KEY])
        )
        _reform_doc_tmp.append(_str_in)
        # 3.改造建议
        _str_in = ''
        # 搜索原分间需要绘制的墙体和附件
        draw_obj1, lines_notmatch1, line_type1, lineitems_notmatch1, lineitems_set1 = self.find_change_origin(params_dict['draw_img'])
        # 搜索关联分间需要绘制的墙体和附件
        draw_obj2, lines_notmatch2, line_type2, lineitems_notmatch2, lineitems_set2 = self.find_change_after(params_dict['draw_img'], room_list=[self.room_same_class, related_room], line_list=related_room.room_lines, lineitem_list=related_room.room_lines)

        if len(lines_notmatch2) > 0:
            if len(line_type2) == 0 or (len(line_type2) == 1 and 0 in line_type2):
                _str_in = _str_in + '在{}新建墙体'.format(self.name)
            elif len(line_type2) == 1 and 5 in line_type2:
                _str_in = _str_in + '在{}新建落地窗或半窗墙体,保证采光'.format(self.name)
            elif len(line_type2) == 1 and 1 in line_type2:
                _str_in = _str_in + '在{}设置带有推拉门的墙体'.format(self.name)
            elif 0 in line_type2 and 5 in line_type2:
                _str_in = _str_in + '在{}新建带窗墙体,保证采光'.format(self.name)
            else:
                _str_in = _str_in + '在{}新建墙体'.format(self.name)
            _str_in = _str_in + ', '
        _str_in = _str_in + '隔出一个{}平米的房间和{}平米的房间;'.format(self.room_same_class.area_size, related_room.area_size)
        _str_in = _str_in + '新增的{}{},属于{}的{};'.format(
            related_room.name,
            DocsGenerator.generate_bedroom_size_common_docs(related_room.width, related_room.depth, related_room.area_size, face=related_room.face),
            DocsGenerator.generate_bedroom_type_docs(related_room.width, related_room.depth, what='type'),
            related_room.std_name
        )
        _reform_doc_tmp.append(_str_in)
        # 4.改造后布局建议
        if not params_dict['without_http']:
            suggestPoints, layoutImageUrl = DocsGenerator.generate_reform_suggest('masterBedroom', related_room.room_label)
            _reform_doc_tmp.append([suggestPoints, layoutImageUrl])
        else:
            _reform_doc_tmp.append(['masterBedroom', related_room.room_label])
        # 5.改造影响
        _str_in = ''
        _str_in = DocsGenerator.generate_origin_room_influence_docs(self, self.room_same_class) + ';'
        _str_in = _str_in + '改后{}{},属于{}的{}'.format(self.room_same_class.std_name,
                                                     DocsGenerator.generate_bedroom_size_common_docs(self.room_same_class.width, self.room_same_class.depth, self.room_same_class.area_size, face=self.room_same_class.face),
                                                     DocsGenerator.generate_bedroom_type_docs(self.room_same_class.width, self.room_same_class.depth, what='type'),
                                                     self.room_same_class.std_name)
        _reform_influence_docs = [{'typeName': u'尺寸变化', 'text': _str_in, 'type': '', 'title': None}]
        if not params_dict['without_http']:
            suggestPoints, layoutImageUrl = DocsGenerator.generate_reform_suggest('masterBedroom', self.room_same_class.room_label)
            suggestPoints = _reform_influence_docs + suggestPoints
            _reform_doc_tmp.append(suggestPoints)
        else:
            _reform_doc_tmp.append(_str_in)
        # 6.改造影响附图
        if not params_dict['without_http']:
            if self.room_same_class is not None:
                suggestPoints, layoutImageUrl = DocsGenerator.generate_reform_suggest('masterBedroom', self.room_same_class.room_label)
                _reform_doc_tmp.append(layoutImageUrl)
            else:
                _reform_doc_tmp.append(list())
        else:
            if self.room_same_class is not None:
                _reform_doc_tmp.append(['masterBedroom', self.room_same_class.room_label, _reform_influence_docs])
            else:
                _reform_doc_tmp.append(['', '', _reform_influence_docs])

        # 7.变化的分间、墙体、附件
        _reform_doc_tmp.append([draw_obj1, draw_obj2])

        # 8.改造点权重
        _reform_point_weight = DocsGenerator.generate_reform_conf_docs(self.reform_conf, ['bedroom', 'bedroom', RDP.ADD_NUM_KEY, RDP.WEIGHT_KEY])
        self.total_weight_of_reform = self.total_weight_of_reform + _reform_point_weight
        _reform_doc_tmp.append(_reform_point_weight)

        self.docs_total.append(_reform_doc_tmp)
        return lines_notmatch2, lineitems_notmatch2

    def judge_add_toilet(self, related_room, params_dict):
        lines_notmatch2 = list()
        lineitems_notmatch2 = list()
        # 如果相交的面积占关联分间的比例没达到阈值,说明关联分间不完全从本分间分离出来,因此不算做增加分间
        if related_room.intersect_ratio < params_dict['reform_docs']['threshold_partition'] and related_room.intersect_abs_area > params_dict['reform_docs']['threshold_partition_abs']:
            return lines_notmatch2, lineitems_notmatch2
        if not OtherTools.judge_toilet_rational(related_room, related_room.line_id_dict):
           return lines_notmatch2, lineitems_notmatch2
        _reform_doc_tmp = list()
        # 0.改造点标签
        _reform_doc_tmp.append('增加{}'.format(related_room.std_name))
        # 1.适合人群
        _reform_doc_tmp.append('')
        # 2.原空间解析
        _str_in = '{},属于{}的{};{};'.format(
            self.name + DocsGenerator.generate_bedroom_size_common_docs(self.width, self.depth, self.area_size, face=self.face),
            DocsGenerator.generate_bedroom_type_docs(self.width, self.depth, what='type'),
            self.std_name,
            DocsGenerator.generate_reform_conf_docs(self.reform_conf, ['bedroom', 'toilet', RDP.ADD_NUM_KEY, RDP.PROBLEM_KEY])
        )
        _reform_doc_tmp.append(_str_in)
        # 3.改造建议
        _str_in = ''
        # 搜索原分间需要绘制的墙体和附件
        draw_obj1, lines_notmatch1, line_type1, lineitems_notmatch1, lineitems_set1 = self.find_change_origin(params_dict['draw_img'])
        # 搜索关联分间需要绘制的墙体和附件
        draw_obj2, lines_notmatch2, line_type2, lineitems_notmatch2, lineitems_set2 = self.find_change_after(params_dict['draw_img'], room_list=[self.room_same_class, related_room], line_list=related_room.room_lines, lineitem_list=related_room.room_lines)

        if len(lines_notmatch2) > 0:
            if len(line_type2) == 0 or (len(line_type2) == 1 and 0 in line_type2):
                _str_in = _str_in + '在{}新建墙体'.format(self.name)
            elif len(line_type2) == 1 and 5 in line_type2:
                _str_in = _str_in + '在{}新建落地窗或半窗墙体,保证采光'.format(self.name)
            elif len(line_type2) == 1 and 1 in line_type2:
                _str_in = _str_in + '在{}设置带有推拉门的墙体'.format(self.name)
            elif 0 in line_type2 and 5 in line_type2:
                _str_in = _str_in + '在{}新建带窗墙体,保证采光'.format(self.name)
            else:
                _str_in = _str_in + '在{}新建墙体'.format(self.name)
            _str_in = _str_in + ', '
        _str_in = _str_in + '隔出一个{}平方米的{}和{}平方米的{};'.format(int(related_room.area_size), related_room.name,
                                                            int(self.room_same_class.area_size), self.room_same_class.name)
        _str_in = _str_in + '新增的{}{};'.format(
            related_room.name,
            DocsGenerator.generate_size_common_docs(related_room.width, related_room.depth, related_room.area_size)
        )
        _reform_doc_tmp.append(_str_in)
        # 4.改造后布局建议
        if not params_dict['without_http']:
            suggestPoints, layoutImageUrl = DocsGenerator.generate_reform_suggest('toilet', related_room.room_label)
            _reform_doc_tmp.append([suggestPoints, layoutImageUrl])
        else:
            _reform_doc_tmp.append(['toilet', related_room.room_label])
        # 5.改造影响
        _str_in = ''
        _str_in = DocsGenerator.generate_origin_room_influence_docs(self, self.room_same_class) + ';'
        _str_in = _str_in + '改后{}{},属于{}的{}'.format(self.room_same_class.std_name,
                                             DocsGenerator.generate_bedroom_size_common_docs(self.room_same_class.width, self.room_same_class.depth, self.room_same_class.area_size, face=self.room_same_class.face),
                                             DocsGenerator.generate_bedroom_type_docs(self.room_same_class.width, self.room_same_class.depth, what='type'),
                                             self.room_same_class.std_name)
        _reform_influence_docs = [{'typeName': u'尺寸变化', 'text': _str_in, 'type': '', 'title': None}]
        if not params_dict['without_http']:
            suggestPoints, layoutImageUrl = DocsGenerator.generate_reform_suggest('masterBedroom', self.room_same_class.room_label)
            suggestPoints = _reform_influence_docs + suggestPoints
            _reform_doc_tmp.append(suggestPoints)
        else:
            _reform_doc_tmp.append(_str_in)
        # 6.改造影响附图
        if not params_dict['without_http']:
            if self.room_same_class is not None:
                suggestPoints, layoutImageUrl = DocsGenerator.generate_reform_suggest('masterBedroom', self.room_same_class.room_label)
                _reform_doc_tmp.append(layoutImageUrl)
            else:
                _reform_doc_tmp.append(list())
        else:
            if self.room_same_class is not None:
                _reform_doc_tmp.append(['masterBedroom', self.room_same_class.room_label, _reform_influence_docs])
            else:
                _reform_doc_tmp.append(['', '', _reform_influence_docs])
        # 7.变化的分间、墙体、附件
        _reform_doc_tmp.append([draw_obj1, draw_obj2])

        # 8.改造点权重
        _reform_point_weight = DocsGenerator.generate_reform_conf_docs(self.reform_conf, ['bedroom', 'toilet', RDP.ADD_NUM_KEY, RDP.WEIGHT_KEY])
        self.total_weight_of_reform = self.total_weight_of_reform + _reform_point_weight
        _reform_doc_tmp.append(_reform_point_weight)

        self.docs_total.append(_reform_doc_tmp)
        return lines_notmatch2, lineitems_notmatch2

    def judge_add_cloakroom(self, related_room, params_dict):
        lines_notmatch2 = list()
        lineitems_notmatch2 = list()
        if DU.is_false_diff_room(related_room, params_dict['counter_frame']):
            return lines_notmatch2, lineitems_notmatch2
        # 如果相交的面积占关联分间的比例没达到阈值,说明关联分间不完全从本分间分离出来,因此不算做增加分间
        if related_room.intersect_ratio < params_dict['reform_docs']['threshold_partition'] and related_room.intersect_abs_area > params_dict['reform_docs']['threshold_partition_abs']:
            return lines_notmatch2, lineitems_notmatch2
        _reform_doc_tmp = list()
        # 0.改造点标签
        _reform_doc_tmp.append('增加{}'.format(related_room.std_name))
        # 1.适合人群
        _reform_doc_tmp.append('')
        # 2.原空间解析
        _str_in = '{},属于{}的{};{};'.format(
            self.name + DocsGenerator.generate_bedroom_size_common_docs(self.width, self.depth, self.area_size, face=self.face),
            DocsGenerator.generate_bedroom_type_docs(self.width, self.depth, what='type'),
            self.std_name,
            DocsGenerator.generate_reform_conf_docs(self.reform_conf, ['bedroom', 'cloakroom', RDP.ADD_NUM_KEY, RDP.PROBLEM_KEY])
        )
        _reform_doc_tmp.append(_str_in)
        # 3.改造建议
        _str_in = ''
        # 搜索原分间需要绘制的墙体和附件
        draw_obj1, lines_notmatch1, line_type1, lineitems_notmatch1, lineitems_set1 = self.find_change_origin(params_dict['draw_img'])
        # 搜索关联分间需要绘制的墙体和附件
        draw_obj2, lines_notmatch2, line_type2, lineitems_notmatch2, lineitems_set2 = self.find_change_after(params_dict['draw_img'], room_list=[self.room_same_class, related_room], line_list=related_room.room_lines, lineitem_list=related_room.room_lines)
        if len(lines_notmatch2) > 0:
            if len(line_type2) == 0 or (len(line_type2) == 1 and 0 in line_type2):
                _str_in = _str_in + '在{}新建墙体'.format(self.name)
            elif len(line_type2) == 1 and 5 in line_type2:
                _str_in = _str_in + '在{}新建落地窗或半窗墙体,保证采光'.format(self.name)
            elif len(line_type2) == 1 and 1 in line_type2:
                _str_in = _str_in + '在{}设置带有推拉门的墙体'.format(self.name)
            elif 0 in line_type2 and 5 in line_type2:
                _str_in = _str_in + '在{}新建带窗墙体,保证采光'.format(self.name)
            else:
                _str_in = _str_in + '在{}新建墙体'.format(self.name)
            _str_in = _str_in + ', '
        _str_in = _str_in + '隔出一个{}平方米的{}和{}平方米的{};'.format(self.room_same_class.area_size, self.room_same_class.name, related_room.area_size, related_room.name)
        _str_in = _str_in + '新增的{}{};'.format(
            related_room.name,
            DocsGenerator.generate_size_common_docs(related_room.width, related_room.depth, related_room.area_size)
        )
        _reform_doc_tmp.append(_str_in)
        # 4.改造后布局建议
        suggestPoints = list()
        layoutImageUrl = list()
        _reform_doc_tmp.append([suggestPoints, layoutImageUrl])
        # 5.改造影响
        _str_in = ''
        _str_in = DocsGenerator.generate_origin_room_influence_docs(self, self.room_same_class) + ';'
        _str_in = _str_in + '改后{}{},属于{}的{}'.format(self.room_same_class.std_name,
                                                     DocsGenerator.generate_bedroom_size_common_docs(self.room_same_class.width, self.room_same_class.depth, self.room_same_class.area_size, face=self.room_same_class.face),
                                                     DocsGenerator.generate_bedroom_type_docs(self.room_same_class.width, self.room_same_class.depth, what='type'),
                                                     self.room_same_class.std_name)
        _reform_influence_docs = [{'typeName': u'尺寸变化', 'text': _str_in, 'type': '', 'title': None}]
        if not params_dict['without_http']:
            suggestPoints, layoutImageUrl = DocsGenerator.generate_reform_suggest('masterBedroom', self.room_same_class.room_label)
            suggestPoints = _reform_influence_docs + suggestPoints
            _reform_doc_tmp.append(suggestPoints)
        else:
            _reform_doc_tmp.append(_str_in)
        # 6.改造影响附图
        if not params_dict['without_http']:
            if self.room_same_class is not None:
                suggestPoints, layoutImageUrl = DocsGenerator.generate_reform_suggest('masterBedroom', self.room_same_class.room_label)
                _reform_doc_tmp.append(layoutImageUrl)
            else:
                _reform_doc_tmp.append(list())
        else:
            if self.room_same_class is not None:
                _reform_doc_tmp.append(['masterBedroom', self.room_same_class.room_label, _reform_influence_docs])
            else:
                _reform_doc_tmp.append(['', '', _reform_influence_docs])
        # 7.变化的分间、墙体、附件
        _reform_doc_tmp.append([draw_obj1, draw_obj2])

        # 8.改造点权重
        _reform_point_weight = DocsGenerator.generate_reform_conf_docs(self.reform_conf, ['bedroom', 'cloakroom', RDP.ADD_NUM_KEY, RDP.WEIGHT_KEY])
        self.total_weight_of_reform = self.total_weight_of_reform + _reform_point_weight
        _reform_doc_tmp.append(_reform_point_weight)

        self.docs_total.append(_reform_doc_tmp)
        return lines_notmatch2, lineitems_notmatch2

    def personalized_label(self, params_dict):
        s1 = self.area_size
        s2 = 0
        if self.room_same_class is not None:
            s2 = self.room_same_class.area_size
        line_draw_list = list()
        lineitem_draw_list = list()
        for _related in self.passive:
            # 判断相关联的分间是否是卧室,检测卧室与卧室相关的改造点
            if s2 > 0 and (_related.detail_type == RDP.RoomNameEnum.bedroom.value or _related.detail_type == RDP.RoomNameEnum.mainroom.value or _related.detail_type == RDP.RoomNameEnum.secondary_bedroom.value):
                _line_list, _lineitem_list = self.judge_add_bedroom(_related, params_dict)
                line_draw_list = line_draw_list + _line_list
                lineitem_draw_list = lineitem_draw_list + _lineitem_list
            # 判断相关联的分间是否是衣帽间,检测卧室与衣帽间相关的改造点
            if s2 > 0 and _related.detail_type == RDP.RoomNameEnum.cloakroom.value:
                _line_list, _lineitem_list = self.judge_add_cloakroom(_related, params_dict)
                line_draw_list = line_draw_list + _line_list
                lineitem_draw_list = lineitem_draw_list + _lineitem_list
            # 判断相关联的分间是否是卫生间,检测卧室与卫生间相关的改造点
            if s2 > 0 and _related.detail_type == RDP.RoomNameEnum.toilet.value:
                _line_list, _lineitem_list = self.judge_add_toilet(_related, params_dict)
                line_draw_list = line_draw_list + _line_list
                lineitem_draw_list = lineitem_draw_list + _lineitem_list
            """
            # 判断相关联的分间是否是客厅,检测卧室与客厅相关的改造点
            if s2 >= 0 and _related.detail_type == RDP.RoomNameEnum.living_room.value:
                _line_list, _lineitem_list = self.judge_change_livingroom(_related, params_dict)
                line_draw_list = line_draw_list + _line_list
                lineitem_draw_list = lineitem_draw_list + _lineitem_list
            """
        # 对该分间的改造点按照改造点权重从大到小排序
        self.docs_total = sorted(self.docs_total, key=lambda x: x[-1], reverse=True)
        return line_draw_list, lineitem_draw_list


class LivingRoom(RoomObj):
    def __init__(self, room, params_dict):
        super(LivingRoom, self).__init__(room, params_dict)

    def judge_change_bedroom(self, related_room, params_dict):
        lines_notmatch2 = list()
        lineitems_notmatch2 = list()
        # 如果相交的面积占关联分间的比例没达到阈值,说明关联分间不完全从本分间分离出来,因此不算做增加分间
        if related_room.intersect_ratio < params_dict['reform_docs']['threshold_partition'] and related_room.intersect_abs_area > params_dict['reform_docs']['threshold_partition_abs']:
            return lines_notmatch2, lineitems_notmatch2
        _reform_doc_tmp = list()
        # 0.改造点标签
        _reform_doc_tmp.append('{}改{}'.format(self.std_name, related_room.std_name))
        # 1.适合人群
        _reform_doc_tmp.append('')
        # 2.原空间解析
        _str_in = '{};{};'.format(
            self.name + DocsGenerator.generate_livingroom_size_common_docs(self.area_size),
            DocsGenerator.generate_reform_conf_docs(self.reform_conf, ['livingroom', 'bedroom', RDP.ADD_NUM_KEY, RDP.PROBLEM_KEY])
        )
        _reform_doc_tmp.append(_str_in)
        # 3.改造建议
        _str_in = ''
        # 搜索原分间需要绘制的墙体和附件
        draw_obj1, lines_notmatch1, line_type1, lineitems_notmatch1, lineitems_set1 = self.find_change_origin(params_dict['draw_img'])
        # 搜索关联分间需要绘制的墙体和附件
        draw_obj2, lines_notmatch2, line_type2, lineitems_notmatch2, lineitems_set2 = self.find_change_after(params_dict['draw_img'], room_list=[self.room_same_class, related_room], line_list=related_room.room_lines, lineitem_list=related_room.room_lines)
        if len(lines_notmatch2) > 0:
            if len(line_type2) == 0 or (len(line_type2) == 1 and 0 in line_type2):
                _str_in = _str_in + '在{}新建墙体'.format(self.name)
            elif len(line_type2) == 1 and 5 in line_type2:
                _str_in = _str_in + '在{}新建落地窗或半窗墙体,保证采光'.format(self.name)
            elif len(line_type2) == 1 and 1 in line_type2:
                _str_in = _str_in + '在{}设置带有推拉门的墙体'.format(self.name)
            elif 0 in line_type2 and 5 in line_type2:
                _str_in = _str_in + '在{}新建带窗墙体,保证采光'.format(self.name)
            else:
                _str_in = _str_in + '在{}新建墙体'.format(self.name)
            _str_in = _str_in + ', '

        _str_in = _str_in + '形成{}平方米的{};'.format(int(related_room.area_size), related_room.name)
        _str_in = _str_in + '新增的{}{},属于{}的{};'.format(
            related_room.name,
            DocsGenerator.generate_bedroom_size_common_docs(related_room.width, related_room.depth, related_room.area_size, face=related_room.face),
            DocsGenerator.generate_bedroom_type_docs(related_room.width, related_room.depth, what='type'),
            related_room.std_name
        )
        _reform_doc_tmp.append(_str_in)
        # 4.改造后布局建议
        if not params_dict['without_http']:
            suggestPoints, layoutImageUrl = DocsGenerator.generate_reform_suggest('masterBedroom', related_room.room_label)
            _reform_doc_tmp.append([suggestPoints, layoutImageUrl])
        else:
            _reform_doc_tmp.append(['masterBedroom', related_room.room_label])
        # 5.改造影响
        _str_in = ''
        _str_in = DocsGenerator.generate_origin_room_influence_docs(self, self.room_same_class) + ';'
        _reform_influence_docs = [{'typeName': u'尺寸变化', 'text': _str_in, 'type': '', 'title': None}]
        if not params_dict['without_http']:
            suggestPoints, layoutImageUrl = DocsGenerator.generate_reform_suggest('', '')
            suggestPoints = _reform_influence_docs + suggestPoints
            _reform_doc_tmp.append(suggestPoints)
        else:
            _reform_doc_tmp.append(_str_in)
        # 6.改造影响附图
        if not params_dict['without_http']:
            if self.room_same_class is not None:
                suggestPoints, layoutImageUrl = DocsGenerator.generate_reform_suggest('', '')
                _reform_doc_tmp.append(layoutImageUrl)
            else:
                _reform_doc_tmp.append(list())
        else:
            if self.room_same_class is not None:
                _reform_doc_tmp.append(['', '', _reform_influence_docs])
            else:
                _reform_doc_tmp.append(['', '', _reform_influence_docs])
        # 7.变化的分间、墙体、附件
        _reform_doc_tmp.append([draw_obj1, draw_obj2])

        # 8.改造点权重
        _reform_point_weight = DocsGenerator.generate_reform_conf_docs(self.reform_conf, ['livingroom', 'bedroom', RDP.ADD_NUM_KEY, RDP.WEIGHT_KEY])
        self.total_weight_of_reform = self.total_weight_of_reform + _reform_point_weight
        _reform_doc_tmp.append(_reform_point_weight)

        self.docs_total.append(_reform_doc_tmp)
        return lines_notmatch2, lineitems_notmatch2

    def judge_add_cloakroom(self, related_room, params_dict):
        lines_notmatch2 = list()
        lineitems_notmatch2 = list()
        if DU.is_false_diff_room(related_room, params_dict['counter_frame']):
            print("衣帽间判断函数")
            return lines_notmatch2, lineitems_notmatch2
        # 如果相交的面积占关联分间的比例没达到阈值,说明关联分间不完全从本分间分离出来,因此不算做增加分间
        if related_room.intersect_ratio < params_dict['reform_docs']['threshold_partition'] and related_room.intersect_abs_area > params_dict['reform_docs']['threshold_partition_abs']:
            return lines_notmatch2, lineitems_notmatch2
        _reform_doc_tmp = list()
        # 0.改造点标签
        _reform_doc_tmp.append('增加{}'.format(related_room.std_name))
        # 1.适合人群
        _reform_doc_tmp.append('')
        # 2.原空间解析
        _str_in = '{};{};'.format(
            self.name + DocsGenerator.generate_livingroom_size_common_docs(self.area_size),
            DocsGenerator.generate_reform_conf_docs(self.reform_conf, ['livingroom', 'cloakroom', RDP.ADD_NUM_KEY, RDP.PROBLEM_KEY])
        )
        _reform_doc_tmp.append(_str_in)
        # 3.改造建议
        _str_in = ''
        # 搜索原分间需要绘制的墙体和附件
        draw_obj1, lines_notmatch1, line_type1, lineitems_notmatch1, lineitems_set1 = self.find_change_origin(params_dict['draw_img'])
        # 搜索关联分间需要绘制的墙体和附件
        draw_obj2, lines_notmatch2, line_type2, lineitems_notmatch2, lineitems_set2 = self.find_change_after(params_dict['draw_img'], room_list=[self.room_same_class, related_room], line_list=related_room.room_lines, lineitem_list=related_room.room_lines)
        if len(lines_notmatch2) > 0:
            if len(line_type2) == 0 or (len(line_type2) == 1 and 0 in line_type2):
                _str_in = _str_in + '在{}新建墙体'.format(self.name)
            elif len(line_type2) == 1 and 5 in line_type2:
                _str_in = _str_in + '在{}新建落地窗或半窗墙体,保证采光'.format(self.name)
            elif len(line_type2) == 1 and 1 in line_type2:
                _str_in = _str_in + '在{}设置带有推拉门的墙体'.format(self.name)
            elif 0 in line_type2 and 5 in line_type2:
                _str_in = _str_in + '在{}新建带窗墙体,保证采光'.format(self.name)
            else:
                _str_in = _str_in + '在{}新建墙体'.format(self.name)
            _str_in = _str_in + ', '
        _str_in = _str_in + '隔出一个{}平方米的{}和{}平方米的{};'.format(int(self.room_same_class.area_size),
                                                            self.room_same_class.name, int(related_room.area_size),
                                                            related_room.name)
        _str_in = _str_in + '新增的{}{};'.format(related_room.name, DocsGenerator.generate_size_common_docs(related_room.width, related_room.depth, related_room.area_size))
        _reform_doc_tmp.append(_str_in)
        # 4.改造后布局建议
        suggestPoints = list()
        layoutImageUrl = list()
        _reform_doc_tmp.append([suggestPoints, layoutImageUrl])
        # 5.改造影响
        _str_in = ''
        _str_in = DocsGenerator.generate_origin_room_influence_docs(self, self.room_same_class)
        _reform_doc_tmp.append(_str_in)
        # 6.改造影响附图
        _reform_doc_tmp.append([])
        # 7.变化的分间、墙体、附件
        _reform_doc_tmp.append([draw_obj1, draw_obj2])

        # 8.改造点权重
        _reform_point_weight = DocsGenerator.generate_reform_conf_docs(self.reform_conf, ['livingroom', 'cloakroom', RDP.ADD_NUM_KEY, RDP.WEIGHT_KEY])
        self.total_weight_of_reform = self.total_weight_of_reform + _reform_point_weight
        _reform_doc_tmp.append(_reform_point_weight)

        self.docs_total.append(_reform_doc_tmp)
        return lines_notmatch2, lineitems_notmatch2

    def personalized_label(self, params_dict):
        s1 = self.area_size
        s2 = 0
        if self.room_same_class is not None:
            s2 = self.room_same_class.area_size
        line_draw_list = list()
        lineitem_draw_list = list()
        for _related in self.passive:
            # 判断相关联的分间是否是卧室,检测客厅与卧室相关的改造点
            if s2 >= 0 and (_related.detail_type == RDP.RoomNameEnum.bedroom.value or _related.detail_type == RDP.RoomNameEnum.mainroom.value or _related.detail_type == RDP.RoomNameEnum.secondary_bedroom.value):
                _line_list, _lineitem_list = self.judge_change_bedroom(_related, params_dict)
                line_draw_list = line_draw_list + _line_list
                lineitem_draw_list = lineitem_draw_list + _lineitem_list
            """
            # 判断相关联的分间是否是衣帽间,检测卧室与衣帽间相关的改造点
            if s2 > 0 and _related.detail_type == RDP.RoomNameEnum.cloakroom.value:
                _line_list, _lineitem_list = self.judge_add_cloakroom(_related, params_dict)
                line_draw_list = line_draw_list + _line_list
                lineitem_draw_list = lineitem_draw_list + _lineitem_list
            """
        # 对该分间的改造点按照改造点权重从大到小排序
        self.docs_total = sorted(self.docs_total, key=lambda x: x[-1], reverse=True)
        return line_draw_list, lineitem_draw_list


class Kitchen(RoomObj):
    def __init__(self, room, params_dict):
        super(Kitchen, self).__init__(room, params_dict)

    def judge_add_area(self, related_room, params_dict):
        lines_notmatch2 = list()
        lineitems_notmatch2 = list()
        _reform_doc_tmp = list()
        if related_room.intersect_area/self.area_size < params_dict['reform_docs']['threshold_partition'] or abs(related_room.intersect_area - self.area_size) > params_dict['reform_docs']['threshold_partition_abs']:
            return lines_notmatch2, lineitems_notmatch2
        # 0.改造点标签
        _reform_doc_tmp.append('扩大面积')
        # 1.适合人群
        _reform_doc_tmp.append('')
        # 2.原空间解析
        _str_in = '{};{};'.format(
            self.name + DocsGenerator.generate_livingroom_size_common_docs(self.area_size),
            DocsGenerator.generate_reform_conf_docs(self.reform_conf, ['kitchen', 'kitchen', RDP.ADD_AREA_KEY, RDP.PROBLEM_KEY])
        )
        _reform_doc_tmp.append(_str_in)
        # 3.改造建议
        _str_in = ''
        _reform_doc_tmp.append(_str_in)
        # 4.改造后布局建议
        if not params_dict['without_http']:
            suggestPoints, layoutImageUrl = DocsGenerator.generate_reform_suggest('kitchen', related_room.room_label)
            _reform_doc_tmp.append([suggestPoints, layoutImageUrl])
        else:
            _reform_doc_tmp.append(['kitchen', related_room.room_label])
        # 5.改造影响
        _str_in = ''
        _str_in = DocsGenerator.generate_origin_room_influence_docs(self, self.room_same_class)
        _reform_doc_tmp.append(_str_in)
        # 6.变化的分间、墙体、附件
        _reform_doc_tmp.append([list(), list()])
        # 7.改造点权重
        _reform_point_weight = DocsGenerator.generate_reform_conf_docs(self.reform_conf, ['kitchen', 'kitchen', RDP.ADD_AREA_KEY, RDP.PROBLEM_KEY])
        self.total_weight_of_reform = self.total_weight_of_reform + _reform_point_weight
        _reform_doc_tmp.append(_reform_point_weight)

        self.docs_total.append(_reform_doc_tmp)
        return lines_notmatch2, lineitems_notmatch2

    def personalized_label(self, params_dict):
        s1 = self.area_size
        s2 = 0
        if self.room_same_class is not None:
            s2 = self.room_same_class.area_size
        line_draw_list = list()
        lineitem_draw_list = list()

        if s2 > s1 + params_dict['reform_docs']['threshold_add_area']:
            _line_list, _lineitem_list = self.judge_add_area(self.room_same_class, params_dict)
            line_draw_list = line_draw_list + _line_list
            lineitem_draw_list = lineitem_draw_list + _lineitem_list

        # 对该分间的改造点按照改造点权重从大到小排序
        self.docs_total = sorted(self.docs_total, key=lambda x: x[-1], reverse=True)
        return line_draw_list, lineitem_draw_list
