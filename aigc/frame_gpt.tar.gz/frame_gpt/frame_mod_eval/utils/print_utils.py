# -*- coding:utf-8 -*-
"""
参考：https://wiki.lianjia.com/pages/viewpage.action?pageId=878961703
"""
import json
import requests
from PIL import Image
from io import BytesIO


def draw_json(frameX_vector, hide_compass=True, show=True, save_path=None,
              URL='http://10.26.9.27:8898/print-polygon'):
    frame_json_str = json.dumps(frameX_vector)
    # print(frame_json_str)
    payload = {
        'source': frame_json_str,
        "pngSize": '512x512',
        'hideCompass': hide_compass,
    }
    res = requests.post(URL, data=payload)
    try:
        obj = json.loads(res.text)
    except:
        img = Image.open(BytesIO(res.content))
    if show:
        img.show()
    if save_path:
        img.save(save_path)
    return img


if __name__ == '__main__':
    with open('source.json') as f:
        frameX_vector = json.load(f)
    img = draw_json(frameX_vector, hide_compass=True, show=True, save_path='img.png',
                    URL='http://10.200.24.133:8898/print-polygon')