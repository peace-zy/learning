# -*- coding: utf-8 -*-
import random

from reform_func_tools import DrawUrlSampling, ImgTools, DrawJsonError
import frame_eval.frame_tag_lib.utils as tag_utils
import lib.diff_util as diff_util
# from entity.frame_diff_entity import DrawJsonError
import math
import cv2
import numpy as np

_entrance_degree = 90
_entrance_towards = 0


def _direction_creator(cur_toward):
    """
    attachments 属性中的元素方向（direction）字段构建，对于原始矢量中此字段缺失的进行修复
    :rtype: object
    :param cur_toward: 当前墙体附件朝向弧度（与x轴正方向逆时针方向）
    :return: direction, direction_code; string, int; 朝向， 朝向编码
    """
    cur_degree_toward = cur_toward * 180 / math.pi
    north_diff = (_entrance_degree + (_entrance_towards - cur_degree_toward)) % 360
    north_diff = (north_diff + 360) % 360
    direction_flag = int(north_diff / 22.5)
    direction = None
    direction_code = None
    if direction_flag == 0 or direction_flag == 15:
        direction = "north"
        direction_code = 100500000007
    elif direction_flag == 1 or direction_flag == 2:
        direction = "north-east"
        direction_code = 100500000008
    elif direction_flag == 3 or direction_flag == 4:
        direction = "east"
        direction_code = 100500000001
    elif direction_flag == 5 or direction_flag == 6:
        direction = "south-east"
        direction_code = 100500000002
    elif direction_flag == 7 or direction_flag == 8:
        direction = "south"
        direction_code = 100500000003
    elif direction_flag == 9 or direction_flag == 10:
        direction = "south-west"
        direction_code = 100500000004
    elif direction_flag == 11 or direction_flag == 12:
        direction = "west"
        direction_code = 100500000005
    elif direction_flag == 13 or direction_flag == 14:
        direction = "north-west"
        direction_code = 100500000006

    return direction, direction_code

import os
from PIL import Image


def splice_image_in_oneline(img_path_list, save_path, method='method1', resolution=(1000, 750), abpath=''):
    how_many_col = 4
    list_size = len(img_path_list)
    target = Image.new('RGB', (resolution[0] * how_many_col, resolution[1] * (list_size//how_many_col + 1)))
    for index, _img_path in enumerate(img_path_list):
        houzhui = _img_path.split('.')[1]
        if houzhui == 'csv':
            continue
        qianzhui = _img_path.split('_')[0]

        hang = index // how_many_col
        lie = index % how_many_col
        _img = Image.open(abpath + _img_path).resize(resolution)

        left_top = [resolution[0] * lie, resolution[1] * hang]
        right_down = [resolution[0] * (lie + 1), resolution[1] * (hang + 1)]
        target.paste(_img, tuple(left_top + right_down))

        if qianzhui == '000':
            _img.save(save_path + '/{}.jpg'.format('origin'))

    final_img = cv2.cvtColor(np.asarray(target), cv2.COLOR_RGB2BGR)
    font = cv2.FONT_HERSHEY_SIMPLEX
    text_pos = (200, 100)
    for index, _img_path in enumerate(img_path_list):
        houzhui = _img_path.split('.')[1]
        if houzhui == 'csv':
            continue
        qianzhui = _img_path.split('_')[0]

        hang = index // how_many_col
        lie = index % how_many_col
        cv2.putText(final_img, qianzhui, (text_pos[0] + resolution[0] * lie, text_pos[1] + resolution[1] * hang),
                    font, 1.2, (255, 0, 0), 2)
    cv2.imwrite(save_path + '/{}.jpg'.format(method), final_img)
    # target.save(save_path + '/{}.png'.format(method))


if __name__ == '__main__':
    # dir_list = os.listdir(r"C:/Users/54692/Desktop/similar_dataset/similar_frame/3_contour_layout/11000001832739")
    # save_path = 'C:/Users/54692/Desktop/similar_dataset/process_rplan_ceshi/'
    # splice_image_in_oneline(dir_list, save_path, resolution=(500, 325))
    read_dir = "C:/Users/54692/Desktop/similar_dataset/similar_frame_new"
    write_dir = "C:/Users/54692/Desktop/similar_dataset/similar_frame_combine"
    dir_list = os.listdir(read_dir)
    for frame_id in dir_list:
        write_frame_dir = write_dir + '/{}'.format(frame_id)
        if not os.path.exists(write_frame_dir):
            os.mkdir(write_frame_dir)
        read_frame_dir_method1 = read_dir + '/{}/method1'.format(frame_id)
        method1_list = os.listdir(read_frame_dir_method1)
        method1_list = sorted(method1_list)
        splice_image_in_oneline(method1_list, write_frame_dir, method='method1', abpath=read_frame_dir_method1 + '/')

        read_frame_dir_method2 = read_dir + '/{}/method2'.format(frame_id)
        method2_list = os.listdir(read_frame_dir_method2)
        method2_list = sorted(method2_list)
        splice_image_in_oneline(method2_list, write_frame_dir, method='method2', abpath=read_frame_dir_method2 + '/')

        read_frame_dir_method3 = read_dir + '/{}/method3'.format(frame_id)
        method3_list = os.listdir(read_frame_dir_method3)
        method3_list = sorted(method3_list)
        splice_image_in_oneline(method3_list, write_frame_dir, method='method3', abpath=read_frame_dir_method3 + '/')
    pass
