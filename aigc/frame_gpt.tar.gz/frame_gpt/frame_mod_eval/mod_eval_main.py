# -*- coding: utf-8 -*-
# ===============================================================
#
#    Copyright (C) 2021 Beike, Inc. All Rights Reserved.
#
#    @Create Author : 李雨龙 (liyulong008@ke.com)
#    @Create Time   : 2021/8/11 11:24
#    @Description   : frame_miner
#
# ===============================================================
from __future__ import division

import sys
import csv
import os
import yaml
import traceback
import logging
from multiprocessing import Pool, Manager
import copy

import pandas as pd
from utils import reform_doc
import frame_eval.frame_tag_lib.utils as tag_utils
from utils.reform_func_tools import sample_valid_url
from frame_mod_eval.entity.frame_diff_entity import DrawJsonError


pd.set_option('mode.chained_assignment', 'raise')

COL_TYPE_MAP = {
    "str": str,
    "float": float,
    "int": int,
}

# 共享队列
multi_draw_dict = Manager().dict()


def single_frame_runner(_frame_id, after_frame_id, before_frame_json, after_frame_json, detail_info, params):
    da_data_cols = params['mod_eval_conf']['da_data_cols']
    is_valid = 0
    default_reform_id = -2
    default_area_id = -2
    before_flag = -2
    try:
        params_cp = copy.deepcopy(params)
        params_cp['mod_eval_conf']['draw_img']['draw_json_url'] = sample_valid_url(multi_draw_dict)
        logging.info('FRAME ID {}-{} START. '.format(_frame_id, after_frame_id))
        # 这里的after_frame_json代表转过后的原户型, before_frame_json代表改
        _ret_dict_arr = reform_doc.draw_all_img_with_http(_frame_id, after_frame_id,
                                                          after_frame_json, before_frame_json,
                                                          detail_info, params_cp)
        return [[__[_[0]] for _ in da_data_cols] for __ in _ret_dict_arr]
    except DrawJsonError as DJE:
        error_msg = "DRAW_ERROR:访问{}发生错误".format(DJE.url)
        logging.fatal(error_msg)
        if DJE.url in multi_draw_dict:
            multi_draw_dict.pop(DJE.url)
        if len(multi_draw_dict) == 0:
            # 所有画图服务都挂了, 任务停止.
            raise Exception('ALL Draw Server Down!')
        return [[_frame_id, after_frame_id, default_area_id, default_reform_id, before_flag, error_msg, is_valid]]
    except Exception as ex:
        error_msg = 'FRAME ID {}-{} ERROR: {}, TYPE: {}'.format(_frame_id, after_frame_id,
                                                      str(traceback.format_exc()).replace('\n', '|'), type(ex))
        if type(ex) is DrawJsonError:
            DJE = ex
            error_msg = "===DRAW_ERROR:访问{}发生错误".format(DJE.url)
            logging.fatal(error_msg)
            if DJE.url in multi_draw_dict:
                multi_draw_dict.pop(DJE.url)
            if len(multi_draw_dict) == 0:
                # 所有画图服务都挂了, 任务停止.
                raise Exception('ALL Draw Server Down!')
            return [[_frame_id, after_frame_id, default_area_id, default_reform_id, before_flag, error_msg, is_valid]]
        logging.fatal(error_msg)
        return [[_frame_id, after_frame_id, default_area_id, default_reform_id, before_flag, error_msg, is_valid]]


def df_runner(df, params):
    """
    处理 户型对比
    :param df:
    :param params:
    :return:
    """
    _process_ret_arr = []
    cpu = params['mod_eval_conf'].get('cpu_cnt', 3)
    url_dict = params['mod_eval_conf']['draw_img']['draw_json_url_dict']
    multi_draw_dict.update(url_dict)
    logging.info('CPU: {}'.format(cpu))
    pool = Pool(cpu)
    for _row in df.itertuples():
        _frame_id, after_frame_id = _row.frame_id, _row.after_frame_id
        _process_ret_arr.append(pool.apply_async(single_frame_runner, (_frame_id, after_frame_id,
                                                                       _row.before_frame_json,
                                                                       _row.after_frame_json,
                                                                       _row.detail_info, params)))
    pool.close()
    pool.join()
    _ret_dfs = []
    for _ret in _process_ret_arr:
        _ret_dict = _ret.get()
        _ret_dfs.extend(_ret_dict)
    return _ret_dfs


def load_ori_dataset(file_path, names):
    """
    加载原始数据
    :param file_path: 数据文件路径
    :param names: 数据文件列名
    :return:
    """
    feature_names_lst = [_ for _, __ in names]
    feature_name2type = {_: COL_TYPE_MAP[__] for _, __ in names}
    frame_pd = pd.read_table(file_path, header=None, names=feature_names_lst,
                             dtype=feature_name2type, index_col=False)
    return frame_pd


def main(config_file, city_code, _process_cnt):
    logging.info("=" * 10)
    logging.info("[DA] FRAME MOD REPORT: city_code:{0}".format(city_code))
    # load config
    # with open(config_file, "r", encoding='UTF-8') as config_data:
    with open(config_file, "r") as config_data:
        conf = yaml.load(config_data)
    _mod_config = conf.get("mod_eval_conf", None)
    if _mod_config is None:
        logging.error("no mod_config in config file")
        sys.exit(1)
    # 加载文案配置
    all_config = {'mod_eval_conf': _mod_config}
    conf_params2 = dict()
    conf_params3 = dict()
    tag_utils.collect_conf(r"frame_eval/frame_tag_lib/conf.yml", conf_params2)
    tag_utils.collect_conf(r"frame_mod_eval/reform_docs.yml", conf_params3)
    all_config.update(conf_params2)
    all_config.update(conf_params3)
    # form file path
    src_parent_path = _mod_config['src_parent_path']
    src_path, src_file = _mod_config['src_path'], _mod_config['src_file']
    ret_path, ret_cluster_file = _mod_config['ret_path'], _mod_config['ret_mod_file']

    raw_file_path = os.path.join('.', src_parent_path, src_path,
                                 src_file.format(city_code=city_code))
    ret_file_path = os.path.join('.', src_parent_path, ret_path,
                                 ret_cluster_file.format(city_code=city_code))
    logging.info('raw_file_path: {}'.format(raw_file_path))
    logging.info('ret_file_path: {}'.format(ret_file_path))
    raw_data_cols = _mod_config['raw_data_cols']
    data_cols = _mod_config['da_data_cols']
    # load data
    frame_pd_ori = load_ori_dataset(raw_file_path, raw_data_cols)
    ret_names_lst = [_ for _, __ in data_cols]
    # 筛选已经存在报告的
    has_report_index = frame_pd_ori.area_id != 'empty'
    has_report_pd = frame_pd_ori[has_report_index]
    logging.info("has_report_pd len:{}".format(len(has_report_pd)))
    no_report_pd = frame_pd_ori[~has_report_index]
    logging.info("no_report_pd len:{}".format(len(no_report_pd)))
    # 多进程计算
    if len(no_report_pd) > 0:
        _mod_config['cpu_cnt'] = _process_cnt
        report_ret = df_runner(no_report_pd, all_config)
        final_df = pd.DataFrame(data=report_ret, columns=ret_names_lst)
        # 合并上已经存在报告的数据
        all_ret_df = pd.concat([has_report_pd[ret_names_lst], final_df], axis=0)
    else:
        all_ret_df = frame_pd_ori
    all_ret_df.to_csv(ret_file_path, sep='\t', index=None,
                      quoting=csv.QUOTE_NONE, escapechar='',
                      header=None, )
    # 写数据
    logging.info('文件落地...ALL DONE')


if __name__ == '__main__':
    """
        原改报告-画图跑批
        参数: 配置文件路径 城市代码 进程数

        任务逻辑:
            1. 数据准备: 
                a. 城市的小区户型轮廓组.
                b. 关联上最近一份Pt的原改报告数据表.
            2. 筛选增量户型.
            3. 多进程计算: 
                c. 图文匹配.
            4. 拼接上旧数据, 更新全量表.

        python ./frame_mod_eval/mod_eval_main.py ./config/mod_eval_conf.yml 110000 10
        :return:
        """
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    if len(sys.argv) < 3:
        logging.error("no less than 3 arguments!")
        sys.exit()

    _config_file = sys.argv[1]
    _city_code = sys.argv[2]
    _process_cnt = int(sys.argv[3])

    main(_config_file, _city_code, _process_cnt)
