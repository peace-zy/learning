WITH today_report AS (
		SELECT distinct frame_id, after_frame_id, status, score, report
			, short_report, detail_info, after_frame_json, is_valid
		FROM data_mining.data_mining_mod_report_inter_da
		WHERE pt = ${hiveconf:PT_DATE} and status = 2
	),
    last_image AS (
		SELECT frame_id, after_frame_id, area_id, reform_id, before_flag, regexp_replace(url, ' ', '') as url, is_valid
		FROM(
		    SELECT *, ROW_NUMBER() OVER (PARTITION BY frame_id, after_frame_id, area_id, reform_id, before_flag
		                                   ORDER BY is_valid DESC) AS img_rn
            FROM data_mining.data_mining_mod_image_da
            WHERE pt = ${hiveconf:LAST_DATE} and is_valid = 1
		) inner_img
		WHERE img_rn = 1
	),
	v_frame AS (
		SELECT frame_id
			, reflect('java.net.URLDecoder', 'decode', trim(vector_value), 'UTF-8') AS json_str
		FROM (
			SELECT mapping.frame_id, vector_value
			FROM (
				SELECT id, vector_value
				FROM dw.dw_house_frame_vector_da
				WHERE pt = ${hiveconf:PT_DATE}
					AND is_valid = 1
			) vector
				JOIN (
					SELECT image_id, entity_id AS frame_id, ROW_NUMBER() OVER (
                        PARTITION BY entity_id
                        ORDER BY
                            update_time DESC
                    ) AS rn
					FROM dw.dw_house_image_entity_mapping_da
					WHERE pt = ${hiveconf:PT_DATE}
						AND image_type_code = 110028006
						AND entity_type_code = 110029002
						AND is_valid = 1
				) mapping
				ON mapping.image_id = vector.id
				JOIN (
					SELECT DISTINCT frame_id
					FROM dw.dw_house_house_frame_mapping_da
					WHERE pt = ${hiveconf:PT_DATE}
						AND is_valid = 1
						AND city_code IN (${hiveconf:CITY_CODE})
				) h_m
				ON mapping.frame_id = h_m.frame_id
				where rn =1
		) aaa
	)
SELECT distinct a.frame_id
       , a.after_frame_id
       , nvl(area_id, 'empty') as area_id
       , nvl(reform_id, -2) as reform_id, nvl(before_flag, -1) as before_flag, url
       , a.detail_info
	   , c.json_str as before_frame_json
	   , a.after_frame_json, nvl(a.is_valid, 1) is_valid
FROM today_report a
	LEFT JOIN last_image b ON a.frame_id = b.frame_id
	        AND a.after_frame_id = b.after_frame_id
    LEFT JOIN v_frame c ON c.frame_id = a.after_frame_id
ORDER BY rand()