insert overwrite table data_mining.data_mining_frame_mod_report_da partition (pt='20210824000000')
select frame_id, after_frame_id, status, nvl(score, 0) as score, report, short_report, is_valid
from data_mining.data_mining_frame_mod_report_da b
where pt = '20210826000000'
