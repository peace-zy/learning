-- 覆盖数据
insert overwrite table data_mining.data_mining_mod_image_da partition (pt='20210825000000')
select frame_id, after_frame_id, area_id, reform_id, before_flag, url, is_valid
from data_mining.data_mining_mod_image_da b
where pt = '20210826000000'

-- 刷指定的数据
insert overwrite table data_mining.data_mining_mod_image_da partition (pt='20210825000000')
select frame_id, after_frame_id, area_id, reform_id, before_flag, url, is_valid
from data_mining.data_mining_mod_image_da b
where pt = '20210826000000' and b.frame_id not in(
    SELECT distinct a.frame_id as img_frame_id
    FROM data_mining.data_mining_mod_image_da a
    WHERE pt = '20210825000000' and reform_id = 3
)