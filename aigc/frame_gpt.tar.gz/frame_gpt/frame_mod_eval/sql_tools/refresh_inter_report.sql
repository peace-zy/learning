insert overwrite table data_mining.data_mining_mod_report_inter_da partition (pt='20210825000000')
select frame_id, after_frame_id, status, score, report, short_report, detail_info, after_frame_json, is_valid
from data_mining.data_mining_mod_report_inter_da b
where pt = '20210826000000'