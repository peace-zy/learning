CREATE EXTERNAL TABLE IF NOT EXISTS data_mining.data_mining_frame_mod_report_da ( 
    `frame_id` string,
    `after_frame_id` string,
    `status` string,
    `score` float,
    `report` string,
    `short_report` string,
    `is_valid` int
)
partitioned by (pt string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\u0001'
COLLECTION ITEMS TERMINATED BY '\u0002'
MAP KEYS TERMINATED BY '\u0003'
STORED AS INPUTFORMAT   'org.apache.hadoop.mapred.TextInputFormat' OUTPUTFORMAT   'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION 'hdfs://ns-fed/user/bigdata/data_mining/data_mining_frame_mod_report_da'