# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/3/4 16:03
# ===================================

import sys
import argparse
import logging
import datetime
import yaml

from lib import spark_util_v2
from lib.file_util import get_file_stream

from frame_mod_eval.mod_period.period_3th.mod_3th_period import ModThirdPeriodFactory


class HouseModEvalThird(spark_util_v2.SparkLogic):
    def logic_func(self, spark_driver, raw_df_dict, **kwargs):
        """
        spark逻辑函数流程
        :param spark_driver: 东海定义的SparkSqlDriver类对象，内部可以访问sql执行完的数据以及逻辑函数处理后的数据
        :param raw_df_dict: 通过执行sql文件拉到的数据字典
        :param kwargs: 参数字典，对应配置文件中的logic_function_params参数
        :return: 落表数据字典
        """
        Params = kwargs['params']
        ThirdObj = Params['ThirdObj']
        business_data = raw_df_dict['business_data']

        # 业务最终表筛选昨日计算过的数据，solved_condition代表昨日计算完成数据的筛选条件
        business_data_done = business_data.filter(ThirdObj.solved_condition).select(ThirdObj.final_data_cols).distinct()
        # 业务最终表筛选今日未计算的增量数据，increment_condition代表今日未计算数据的筛选条件
        business_data_undo = business_data.filter(ThirdObj.increment_condition).distinct()
        # 通过第三阶段函数计算业务增量数据
        ThirdPeriodDataRdd = ThirdObj.merge_reform_docs_with_url(business_data_undo, **Params)

        if ThirdPeriodDataRdd.count() == 0:
            # 如果增量为0则保护处理，因为RDD.count为0时.toDF会报错
            ThirdPeriodUnionData = business_data_done
        else:
            ThirdPeriodDataDF = ThirdPeriodDataRdd.toDF(ThirdObj.final_data_cols)
            # 第三阶段增量与全量数据合并
            ThirdPeriodUnionData = business_data_done.union(ThirdPeriodDataDF)
        # 保存计算完成的数据，并存储在save_dict字典中，字典的key值与配置文件中的save_params参数字典key值相同
        save_dict = {
            'final_report_table': ThirdPeriodUnionData
        }
        return save_dict


def main(debug=False, **kwargs):
    """
    spark 任务主函数流程
    :param debug: 老朱开发的debug模式，目的是便于在jupyter上查看spark运行的变量，设置为True后工程运行完sql后就会返回，不执行逻辑函数
    :param kwargs: 参数字典
    :return: 东海定义的SparkSqlDriver类对象，内部可以访问sql执行完的数据以及逻辑函数处理后的数据
    """
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    # 今天和昨天的pt
    pt_date = kwargs['pt_data']
    cur_date = datetime.datetime.strptime(pt_date, "%Y%m%d")
    pre_date = cur_date - datetime.timedelta(days=1)
    last_pt_date = pre_date.strftime("%Y%m%d")
    # 读取业务配置文件
    f = get_file_stream(kwargs['config_file'])
    conf = yaml.load(f)
    spark_config_key = "mod_eval_config_params"
    spark_params = conf.get(spark_config_key, None)

    # 创建业务相关的三阶段工厂对象，通过外部传入的业务标识字符串生成对应的一阶段子类对象
    ThirdFactory = ModThirdPeriodFactory()
    ThirdObj = ThirdFactory.get_object(kwargs['spark_config_key'], **spark_params["logic_params"]['logic_function_params']['params'])
    logic_function_params = spark_params["logic_params"]['logic_function_params']
    logic_function_params['params']['ThirdObj'] = ThirdObj

    # sql对应的变量字典，当sql中存在需要替换的变量时可以在该字典中定义
    spark_params["sql_params"]["sql_vars"] = {
        "pt_date": pt_date,
        "last_final_report_date": last_pt_date,
        "city_code": kwargs['city_code'],
        "last_image_date": pt_date
    }
    # 逻辑处理类
    spark_params["logic_params"]["logic_class"] = HouseModEvalThird
    # 存储pt
    for save_name in spark_params["save_params"]:
        spark_params["save_params"][save_name]["partition_params"] = {
            "pt": "{}000000".format(pt_date)
        }
    spark_driver = spark_util_v2.SparkSqlDriver(debug=debug, **spark_params)
    spark_driver.run()
    return spark_driver


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('-pt_date', type=str, default='20220306')
    parser.add_argument('-config_file', type=str, default='')
    parser.add_argument('-sql_file', type=str, default='')
    parser.add_argument('-city_code', type=str, default='110000')
    parser.add_argument('-spark_config_key', type=str, default='Undefined')
    args = parser.parse_args()

    if sys.platform not in ["win32", "darwin"]:
        params = {
            'pt_data': args.pt_date,
            'config_file': args.config_file,
            'sql_file': args.sql_file,
            'city_code': args.city_code,
            'spark_config_key': args.spark_config_key
        }
        main(**params)
    else:
        pass
    pass
