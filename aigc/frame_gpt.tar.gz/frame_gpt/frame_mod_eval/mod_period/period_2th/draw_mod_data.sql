WITH detail_info_table AS (
		SELECT distinct frame_id, after_frame_id, detail_info, is_valid, status
		FROM {inner_table}
		WHERE pt = '{pt_date}000000' and is_valid=1 and status = 2
	),
	trans_json_table AS(
        SELECT distinct frame_id, after_frame_id, trans_frame_a_json, is_valid, status
		FROM data_mining.data_mining_mod_image_v2_da
		WHERE pt = '{pt_date}000000' and is_valid=1 and status = 2
	),
    last_image AS (
		SELECT frame_id, after_frame_id, area_id, regexp_replace(url, ' ', '') as url
		FROM(
		    SELECT *, ROW_NUMBER() OVER (
		        PARTITION BY frame_id, after_frame_id, area_id, reform_id, reform_class, reform_spare, before_flag
                ORDER BY before_flag DESC) AS img_rn
            FROM data_mining.data_mining_mod_image_v2_url_da
            WHERE pt = '{last_image_date}000000' and reform_class = {reform_class}
		) inner_img
		WHERE img_rn = 1
	)
SELECT DISTINCT a.frame_id
       , a.after_frame_id
       , a.detail_info
	   , b.trans_frame_a_json
FROM detail_info_table a
    LEFT JOIN trans_json_table b ON a.frame_id = b.frame_id AND a.after_frame_id = b.after_frame_id
	LEFT JOIN last_image c ON a.frame_id = c.frame_id AND a.after_frame_id = c.after_frame_id
    WHERE c.area_id is null
limit 200000