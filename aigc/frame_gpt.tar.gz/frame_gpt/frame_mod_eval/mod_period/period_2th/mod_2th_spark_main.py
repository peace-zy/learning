# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/3/4 16:03
# ===================================
import sys
import argparse
import logging
import datetime
import yaml
import redis
import traceback
import time

from lib import spark_util_v2
from lib.file_util import get_file_stream

from frame_mod_eval.mod_period.period_2th.mod_2th_period import ModSecondPeriodFactory


def mod_second_period_runner(rows, **kwargs):
    SecondObj = kwargs['SecondObj']
    mod_eval_conf = kwargs['mod_eval_conf']
    host = mod_eval_conf['host']
    port = mod_eval_conf['port']
    password = mod_eval_conf['password']
    push_vec_queue = mod_eval_conf['push_vec_queue']
    max_queue_size = mod_eval_conf.get('max_queue_size', 100)
    sleep_times = mod_eval_conf.get('sleep_times', 100)
    redis_conn = redis.StrictRedis(host=host,
                                   port=port,
                                   db=0,
                                   password=password)
    pipeline = redis_conn.pipeline()
    write_cnt = 0
    sleep_time = sleep_times + 10
    _rows = list(rows)
    rows_size = len(_rows)
    while True:
        if redis_conn.llen(push_vec_queue) > max_queue_size:
            # 当超过指定大小开始sleep
            sleep_time -= 1
            time.sleep(5)
            if sleep_time > 0:
                print('push_vec_queue exceeded, sleep: {}'.format(sleep_time))
                continue
            else:
                print('push_vec_queue exceeded, sleep times exceeded: {}'.format(sleep_time))
                break
        if write_cnt > rows_size - 1:
            # 所有数据写完了
            print('done push vec')
            break
        row = _rows[write_cnt]
        frame_id, after_frame_id = row.frame_id, row.after_frame_id
        try:
            # 等到key可以马上写, 等了10s没等到, 还是写.
            detail_info = row.detail_info
            trans_frame_a_json = row.trans_frame_a_json
            _draw_json = SecondObj.draw_reform_url(frame_id, after_frame_id, trans_frame_a_json, detail_info, **kwargs)
            if _draw_json:
                pipeline.lpush(push_vec_queue, _draw_json)
            else:
                raise Exception("Empty _draw_json!")
            if write_cnt % 6 == 0:
                pipeline.execute()
                time.sleep(1)
            write_cnt += 1
        except:
            error_msg = 'FRAME ID {}-{} ERROR: {}'.format(frame_id, after_frame_id,
                                                          str(traceback.format_exc()).replace('\n', '|'))
            logging.fatal(error_msg)
    # 回写队列保留两个小时
    pipeline.execute()
    pipeline.close()


class HouseModEvalSecond(spark_util_v2.SparkLogic):

    def __init__(self):
        self.repartition_size = 40

    def logic_func(self, spark_driver, raw_df_dict, **kwargs):
        _params = kwargs['params']
        business_data = raw_df_dict['business_data']
        business_data.repartition(self.repartition_size).foreachPartition(lambda rows: mod_second_period_runner(rows, **_params))
        # _cnt = business_data.count()
        # print('*********************business_data.count:{}***************************'.format(_cnt))
        # driver上执行TERM信号
        mod_eval_conf = _params['mod_eval_conf']
        host = mod_eval_conf['host']
        port = mod_eval_conf['port']
        password = mod_eval_conf['password']
        push_vec_queue = mod_eval_conf['push_vec_queue']
        redis_conn = redis.StrictRedis(host=host,
                                       port=port,
                                       db=0,
                                       password=password)
        # 发送 TERM
        print('*********************START TERM***************************')
        for _ in range(self.repartition_size * 2):
            redis_conn.lpush(push_vec_queue, 'TERM')
        # 队列超时3分钟
        redis_conn.expire(push_vec_queue, 3600)
        redis_conn.close()
        print('*********************DONE TERM***************************')
        save_dict = dict()
        return save_dict


def main(debug=False, **kwargs):
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    # 今天和昨天的pt
    pt_date = kwargs['pt_date']
    last_pt_date = kwargs['last_pt_date']
    # 配置文件
    f = get_file_stream(kwargs['config_file'])
    conf = yaml.load(f)
    spark_config_key = "mod_eval_config_params"
    spark_params = conf.get(spark_config_key, None)

    # 创建工厂
    second_factory = ModSecondPeriodFactory()
    second_obj = second_factory.get_object(kwargs['spark_config_key'])
    logic_function_params = spark_params["logic_params"]['logic_function_params']
    logic_function_params['params']['SecondObj'] = second_obj

    spark_params["sql_params"]["sql_vars"] = {
        "pt_date": pt_date,
        "last_image_date": last_pt_date,
        "inner_table": second_obj.inner_table,
        "reform_class": second_obj.reform_class
    }

    spark_params["logic_params"]["logic_class"] = HouseModEvalSecond
    spark_driver = spark_util_v2.SparkSqlDriver(debug=debug, **spark_params)
    spark_driver.run()
    return spark_driver


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('-pt_date', type=str, default='20220306', help='GAT with sparse version or not.')
    parser.add_argument('-last_pt_date', type=str, default='20220306', help='GAT with sparse version or not.')
    parser.add_argument('-config_file', type=str, default='', help='Number of epochs to train.')
    parser.add_argument('-sql_file', type=str, default='', help='Number of epochs to train.')
    parser.add_argument('-spark_config_key', type=str, default='Undefined', help='Number of epochs to train.')
    args = parser.parse_args()
    if sys.platform not in ["win32", "darwin"]:
        params = {
            'pt_date': args.pt_date,
            'last_pt_date': args.last_pt_date,
            'config_file': args.config_file,
            'sql_file': args.sql_file,
            'spark_config_key': args.spark_config_key
        }
        main(**params)

