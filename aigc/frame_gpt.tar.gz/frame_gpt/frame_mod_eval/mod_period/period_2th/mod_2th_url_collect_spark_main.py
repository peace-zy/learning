# -*- coding: utf-8 -*-
# ===================================
# @Author  : 李雨龙
# @Email   : liyulong008@ke.com
# @Time    : 2022/3/4 16:03
# ===================================
import sys
import argparse
import logging
import yaml
import redis
import traceback
import time
import datetime

from pyspark.sql.types import StructField, StructType, StringType, IntegerType, LongType
from lib import spark_util_v2
from lib.file_util import get_file_stream

from frame_mod_eval.mod_period.period_2th.mod_2th_period import REDIS_KEY_LIST


def mod_second_period_runner(_, **kwargs):
    mod_eval_conf = kwargs['mod_eval_conf']
    host = mod_eval_conf['host']
    port = mod_eval_conf['port']
    password = mod_eval_conf['password']
    pull_url_queue = mod_eval_conf['pull_url_queue']
    # ds_to_hive_sync_queue = mod_eval_conf['ds_to_hive_sync_queue']
    # res = [[_.frame_id, _.after_frame_id, _.area_id,
    #         _.reform_id, _.reform_class, _.reform_spare,
    #         _.before_flag, _.url
    #         ] for _ in rows]
    redis_conn = redis.StrictRedis(host=host,
                                   port=port,
                                   db=0,
                                   password=password)
    write_cnt = 0
    _url_key = 'default'
    res = []
    # do while结构 给同步队列塞值, 触发同步环.
    # pipeline.lpush(ds_to_hive_sync_queue, 'READY')
    # pipeline.execute()
    timeout = 1800
    while True:
        try:
            logging.info('MOD_PRINT: waiting for pull url queue...')
            _recv_msg = redis_conn.brpop(pull_url_queue, timeout=timeout)
            print('MOD_PRINT: receive key: {}'.format(_recv_msg))
            if _recv_msg:
                _url_key = _recv_msg[-1]
                if _url_key == 'TERM':
                    # 手动结束信号, 等待时间减少
                    print("RECEIVE TERM SIGNAL. COLLECT EXECUTOR RETURN!")
                    time.sleep(4)
                    timeout = 120
                else:
                    timeout = 1200
            else:
                print("EXCEED MAX WAIT TIME. COLLECT EXECUTOR RETURN!")
                break
        except:
            error_msg = 'MOD_PRINT: KEY- {} - ERROR: {}'.format(_url_key, str(traceback.format_exc()).replace('\n', '|'))
            logging.fatal(error_msg)
            break
        try:
            if _url_key:
                # 获取value
                _url = redis_conn.get(_url_key)
                if _url:
                    # 第一个是URL通配符
                    split_infos = _url_key.split('|')[1:]
                    _row = []
                    for _idx, (_key, _type) in enumerate(REDIS_KEY_LIST[:7]):
                        _row.append(_type(split_infos[_idx]))
                    _row.extend([_url, 1])
                    res.append(_row)
                    print('MOD_PRINT: receive key: {} = {}'.format(_url_key, _row))
                    redis_conn.delete(_url_key)
                    write_cnt += 1
                    if write_cnt % 10 == 0:
                        time.sleep(1)
        except:
            error_msg = 'MOD_PRINT: KEY- {} - ERROR: {}'.format(_url_key, str(traceback.format_exc()).replace('\n', '|'))
            logging.fatal(error_msg)
    print('MOD_PRINT: return res: {}'.format(str(res)))
    redis_conn.close()
    return iter(res)


class HouseModEvalSecond(spark_util_v2.SparkLogic):

    def __init__(self):
        pass

    def logic_func(self, spark_driver, raw_df_dict, **kwargs):
        _params = kwargs['params']
        _partition_cnt = 20
        business_data = raw_df_dict['business_data'].cache()
        _dummy_data = spark_driver.session.createDataFrame(list(('',) for _ in range(_partition_cnt)), ['_'])
        incr_data_rdd = _dummy_data.repartition(_partition_cnt).rdd.mapPartitions(lambda _: mod_second_period_runner(_, **_params))
        # for _i in incr_data_rdd.collect():
        #     print("*"*8)
        #     print(_i)
        schema = StructType([
            StructField('frame_id', StringType(), True),
            StructField('after_frame_id', StringType(), True),
            StructField('area_id', StringType(), True),
            StructField('reform_id', IntegerType(), True),
            StructField('reform_class', LongType(), True),
            StructField('reform_spare', LongType(), True),
            StructField('before_flag', IntegerType(), True),
            StructField('url', StringType(), True),
            StructField('is_valid', IntegerType(), True)
        ])

        incr_data_df = spark_driver.session.createDataFrame(incr_data_rdd, schema)
        # .toDF([_ for _, __ in REDIS_KEY_LIST])
        print(incr_data_df.printSchema())
        # print(incr_data_df.show())
        # incr_data_df = business_data
        # print('*********************incr_data_df count: {}***************************'.format(incr_data_df.count()))
        final_df = incr_data_df.union(business_data).dropDuplicates(['frame_id', 'after_frame_id', 'area_id',
                                                                     'reform_id', 'reform_class', 'reform_spare',
                                                                     'before_flag'])
        # print('*********************final_df count: {}***************************'.format(final_df.count()))
        # final_df = incr_data_df
        save_dict = {
            "collect_url_table": final_df
        }
        return save_dict


def main(debug=False, **kwargs):
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    # 今天和昨天的pt
    pt_date = kwargs['pt_data']
    # 配置文件
    f = get_file_stream(kwargs['config_file'])
    conf = yaml.load(f)
    spark_config_key = "mod_eval_config_params"
    spark_params = conf.get(spark_config_key, None)
    spark_params["sql_params"]["sql_vars"] = {
        "pt_date": pt_date,
    }
    spark_params["logic_params"]["logic_class"] = HouseModEvalSecond

    for save_name in spark_params["save_params"]:
        spark_params["save_params"][save_name]["partition_params"] = {
            "pt": "{}000000".format(pt_date)
        }
    spark_driver = spark_util_v2.SparkSqlDriver(debug=debug, **spark_params)
    spark_driver.run()
    return spark_driver


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('-pt_date', type=str, default='20220306', help='GAT with sparse version or not.')
    parser.add_argument('-config_file', type=str, default='', help='Number of epochs to train.')
    args = parser.parse_args()
    if sys.platform not in ["win32", "darwin"]:
        params = {
            'pt_data': args.pt_date,
            'config_file': args.config_file,
        }
        main(**params)
