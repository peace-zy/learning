SELECT  frame_id, after_frame_id, area_id, reform_id, reform_class, reform_spare,
	    before_flag, regexp_replace(url, ' ', '') as url, is_valid
FROM(
    SELECT *, ROW_NUMBER() OVER (PARTITION BY frame_id, after_frame_id, area_id, reform_id, reform_class, reform_spare, before_flag ORDER BY before_flag DESC) AS img_rn
    FROM data_mining.data_mining_mod_image_v2_url_di
    WHERE pt = '{pt_date}000000' and is_valid = 1
) inner_img
WHERE img_rn = 1