# hdfs 上部署的python环境
HDFS_PYTHON_PATH="hdfs://ns-fed/user/strategy/yudonghai/python.tgz#python"
HDFS_PYTHON_PATH2="hdfs://ns-fed/user/strategy/zhuc/python27.zip#python"
# 本地python命令, 21.21上的配置
PYTHON_CMD="/home/work/zhucheng011/python/python27/bin/python2"
source bin/utils.sh

function PushRedis() {
    pt_date=$1
    last_pt_date=$2
    business_flag=$3

    spark-submit --py-files lib.zip \
                 --executor-memory 10G \
                 --conf spark.dynamicAllocation.maxExecutors=200 \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.pyspark.driver.python=${PYTHON_CMD}\
                 --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_mod_eval/mod_period/period_2th/mod_2th_spark_main.py \
                 -pt_date "${pt_date}" \
                 -last_pt_date "${last_pt_date}" \
                 -config_file frame_mod_eval/mod_period/period_2th/draw_mod_params.yml \
                 -sql_file frame_mod_eval/mod_period/period_2th/draw_mod_data.sql \
                 -spark_config_key "${business_flag}"
}

function PullRedis() {
    # 第二阶段收集画完的URL
    pt_date=$1
    spark-submit --py-files lib.zip \
                 --executor-memory 10G \
                 --conf spark.dynamicAllocation.maxExecutors=200 \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.pyspark.driver.python=${PYTHON_CMD}\
                 --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_mod_eval/mod_period/period_2th/mod_2th_url_collect_spark_main.py \
                 -pt_date "${pt_date}" \
                 -config_file frame_mod_eval/mod_period/period_2th/mod_2th_url_collect_params.yml
}

function main
{
    if [[ $# -lt 1 ]] ; then
        echo "error! lack <job_name>"
        usage
    fi
    job_name=$1
    echo "TASK: ${job_name}  "

    zip -q -r ./lib.zip ./*

    case ${job_name} in

        PushRedis )
        pt_data=$2
        last_pt_date=$3
        business_flag=$4
        PushRedis "$pt_data" "$last_pt_date" "$business_flag"
        ;;

        PullRedis )
        pt_data=$2
        PullRedis "$pt_data"
        ;;

        * )

        echo "error! invalid <job_name>"
        usage
        ;;

    esac
}

main $*