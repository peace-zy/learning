# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/3/4 15:12
# ===================================
import json
from abc import ABCMeta, abstractmethod
import sys
import inspect

from frame_mod_eval.mod_toB.mod_toB_spark import mod_toB_2th_period
from frame_mod_eval.mod_ershou.mod_ershou_spark import mod_SecondHand_2th_period


REDIS_KEY_LIST = [("frame_id", str), ("after_frame_id", str),
                  ("area_id", str), ("reform_id", long),
                  ("reform_class", long), ("reform_spare", long),
                  ("before_flag", long), ("url", str), ("is_valid", long)
                  ]


class ModSecondPeriodFactory(object):
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.name_map = dict()

    @property
    def ClassDict(self):
        class_dict = dict()
        class_list = inspect.getmembers(sys.modules[__name__])
        for _name, _class in class_list:
            if hasattr(_class, 'business_name'):
                class_dict[_name] = _class
                self.name_map[_class.business_name] = _name
        return class_dict

    def get_object(self, Name, **kwargs):
        CD = self.ClassDict
        ClassName = self.name_map.get(Name, 'Undefined')
        if ClassName not in CD:
            raise NotImplementedError('class {} has not been implement'.format(ClassName))
        class_obj = self.ClassDict[ClassName](**kwargs)
        return class_obj


class ModSecondPeriod(object):
    __metaclass__ = ABCMeta

    def __init__(self, **kwargs):
        self.kwargs = kwargs

    @abstractmethod
    def draw_reform_url(self, _frame_id, after_frame_id, trans_frame_a_json, detail_info, **kwargs):
        pass


class ModSecondPeriodToB(ModSecondPeriod):

    business_name = 'dec_toB'
    reform_class = 1
    inner_table = 'data_mining.data_mining_mod_report_v2_deco_b_inter_da'

    def __init__(self, **kwargs):
        super(ModSecondPeriodToB, self).__init__(**kwargs)
        pass

    def draw_reform_url(self, frame_id, after_frame_id, trans_frame_a_json, detail_info, **kwargs):
        result_json = mod_toB_2th_period(frame_id, after_frame_id, trans_frame_a_json, detail_info, **kwargs)
        if isinstance(result_json, dict):
            json.dumps(result_json)
        return result_json


class ModSecondSecondHandToC(ModSecondPeriod):

    business_name = 'secondhand_toC'
    reform_class = 2
    inner_table = 'data_mining.data_mining_mod_report_v2_secondhand_c_inter_da'

    def __init__(self, **kwargs):
        super(ModSecondSecondHandToC, self).__init__(**kwargs)
        pass

    def draw_reform_url(self, frame_id, after_frame_id, trans_frame_a_json, detail_info, **kwargs):
        result_json = mod_SecondHand_2th_period(frame_id, after_frame_id, trans_frame_a_json, detail_info, **kwargs)
        if isinstance(result_json, dict):
            json.dumps(result_json)
        return result_json


if __name__ == '__main__':
    pass
