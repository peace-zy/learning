# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/3/4 14:43
# ===================================
from abc import ABCMeta, abstractmethod
import sys
import inspect

from frame_mod_eval.mod_toB.mod_toB_spark import mod_toB_1th_period
from frame_mod_eval.mod_ershou.mod_ershou_spark import mod_SecondHand_1th_period


class ModFirstPeriodFactory(object):
    def __init__(self,  **kwargs):
        self.kwargs = kwargs
        # name_map 字典存储了业务标识字符串与类名的对应关系，即{business_name: class_name}
        self.name_map = dict()

    @property
    def ClassDict(self):
        """
        ClassDict属性: 遍历__main__文件(当前文件)下的所有类与对象，筛选出有business_name属性的类，
                      存储类名与类的字典, 即{class_name: class}
        """
        class_dict = dict()
        class_list = inspect.getmembers(sys.modules[__name__])
        for _name, _class in class_list:
            if hasattr(_class, 'business_name'):
                class_dict[_name] = _class
                self.name_map[_class.business_name] = _name
        return class_dict

    def get_object(self, Name, **kwargs):
        """
        根据业务标识字符串business_name获取类对象，先通过self.name_map获取类名，再通过ClassDict创建类对象
        :param Name: 业务标识字符串business_name
        :param kwargs: 参数字典
        :return: 返回business_name对应业务相应的第一阶段类对象
        """
        CD = self.ClassDict
        ClassName = self.name_map.get(Name, 'Undefined')
        if ClassName not in CD:
            raise NotImplementedError('class {} has not been implement'.format(ClassName))
        class_obj = self.ClassDict[ClassName](**kwargs)
        return class_obj


class ModFirstPeriod(object):
    __metaclass__ = ABCMeta

    def __init__(self, **kwargs):
        """
        第一阶段基类初始化函数，用于后续扩展。内部存储不同业务的yml配置文件都需要定义的变量
        :param kwargs: 参数字典
        """
        self.kwargs = kwargs
        # 第一阶段sql拉取的数据列名列表
        self.da_data_cols = kwargs['mod_eval_conf']['da_data_cols']
        # 公共渲染底图表列名
        self.trans_data_cols = kwargs['mod_eval_conf']['trans_data_cols']
        # 第一阶段业务inner表列名
        self.final_data_cols = kwargs['mod_eval_conf']['final_data_cols']

    @abstractmethod
    def generate_reform_docs_without_url(self, business_data_undo, **kwargs):
        """
        业务第一阶段增量数据处理函数
        :param business_data_undo: 在pyspark下的dataframe类型增量数据
        :param kwargs: 参数字典
        :return:
        """
        pass


class ModFirstPeriodToB(ModFirstPeriod):

    business_name = 'dec_toB'

    def __init__(self, **kwargs):
        """
        装修户改home端toB第一阶段
        :param kwargs: 参数字典
        """
        super(ModFirstPeriodToB, self).__init__(**kwargs)
        # increment_condition为今日未计算数据的筛选条件，solved_condition为昨日已计算完数据的筛选条件
        self.increment_condition = "status=3"
        self.solved_condition = "status!=3"
        pass

    def generate_reform_docs_without_url(self, business_data_undo, **kwargs):
        """
        装修户改home端toB第一阶段增量数据处理函数
        :param business_data_undo: 在pyspark下的dataframe类型增量数据
        :param kwargs: 参数字典
        :return: 增量数据处理过后的RDD变量数据
        """
        FirstPeriodDataRdd = business_data_undo.rdd.map(lambda row: mod_toB_1th_period(row, **kwargs))
        return FirstPeriodDataRdd


class ModFirstPeriodSecondHandToC(ModFirstPeriod):

    business_name = 'secondhand_toC'

    def __init__(self, **kwargs):
        """
        二手C端户改第一阶段
        :param kwargs: 参数字典
        """
        super(ModFirstPeriodSecondHandToC, self).__init__(**kwargs)
        # increment_condition为今日未计算数据的筛选条件，solved_condition为昨日已计算完数据的筛选条件
        self.increment_condition = "status=3"
        self.solved_condition = "status!=3"
        pass

    def generate_reform_docs_without_url(self, business_data_undo, **kwargs):
        """
        二手C端户改第一阶段增量数据处理函数
        :param business_data_undo: 在pyspark下的dataframe类型增量数据
        :param kwargs: 参数字典
        :return: 增量数据处理过后的RDD变量数据
        """
        FirstPeriodDataRdd = business_data_undo.rdd.map(lambda row: mod_SecondHand_1th_period(row, **kwargs))
        return FirstPeriodDataRdd


if __name__ == '__main__':
    pass
