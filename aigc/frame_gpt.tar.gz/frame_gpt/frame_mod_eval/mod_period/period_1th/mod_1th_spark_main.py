# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2022/3/4 16:03
# ===================================
import sys
import argparse
import logging
import datetime
import yaml

from lib import spark_util_v2
from lib.file_util import get_file_stream

from frame_mod_eval.mod_period.period_1th.mod_1th_period import ModFirstPeriodFactory


class HouseModEvalFirst(spark_util_v2.SparkLogic):
    def logic_func(self, spark_driver, raw_df_dict, **kwargs):
        """
        spark逻辑函数流程
        :param spark_driver: 东海定义的SparkSqlDriver类对象，内部可以访问sql执行完的数据以及逻辑函数处理后的数据
        :param raw_df_dict: 通过执行sql文件拉到的数据字典
        :param kwargs: 参数字典，对应配置文件中的logic_function_params参数
        :return: 落表数据字典
        """
        Params = kwargs['params']
        FirstObj = Params['FirstObj']
        business_data = raw_df_dict['business_data']

        # 业务inner表筛选昨日计算过的数据，solved_condition代表昨日计算完成数据的筛选条件
        business_data_done = business_data.filter(FirstObj.solved_condition).select(FirstObj.final_data_cols).distinct()
        # 业务inner表筛选今日未计算的增量数据，increment_condition代表今日未计算数据的筛选条件
        business_data_undo = business_data.filter(FirstObj.increment_condition).distinct()
        # 通过第一阶段函数计算业务增量数据
        FirstPeriodDataRdd = FirstObj.generate_reform_docs_without_url(business_data_undo, **Params)
        if FirstPeriodDataRdd.count() == 0:
            # 业务inner表增量和全量合并
            business_report_data_union = business_data_done
            # 保存计算完成的数据，并存储在save_dict字典中，字典的key值与配置文件中的save_params参数字典key值相同
            save_dict = {
                "business_report_table": business_report_data_union
            }
        else:
            FirstPeriodDataDF = FirstPeriodDataRdd.toDF(FirstObj.da_data_cols)
            # 筛选渲染底图计算后的增量数据
            trans_json_data = FirstPeriodDataDF.select(FirstObj.trans_data_cols)
            # 筛选业务inner计算后的增量数据
            business_report_data = FirstPeriodDataDF.select(FirstObj.final_data_cols)
            # 业务inner表增量和全量合并
            business_report_data_union = business_data_done.union(business_report_data)
            # 保存计算完成的数据，并存储在save_dict字典中，字典的key值与配置文件中的save_params参数字典key值相同
            save_dict = {
                "trans_json_table": trans_json_data,
                "business_report_table": business_report_data_union
            }
        return save_dict


def main(debug=False, **kwargs):
    """
    spark 任务主函数流程
    :param debug: 老朱开发的debug模式，目的是便于在jupyter上查看spark运行的变量，设置为True后工程运行完sql后就会返回，不执行逻辑函数
    :param kwargs: 参数字典
    :return: 东海定义的SparkSqlDriver类对象，内部可以访问sql执行完的数据以及逻辑函数处理后的数据
    """
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    # 今天和昨天的pt
    pt_date = kwargs['pt_data']
    cur_date = datetime.datetime.strptime(pt_date, "%Y%m%d")
    pre_date = cur_date - datetime.timedelta(days=1)
    last_pt_date = pre_date.strftime("%Y%m%d")
    # 读取业务配置文件
    f = get_file_stream(kwargs['config_file'])
    conf = yaml.load(f)
    spark_config_key = "mod_eval_config_params"
    spark_params = conf.get(spark_config_key, None)

    # 创建业务相关的一阶段工厂对象，通过外部传入的业务标识字符串生成对应的一阶段子类对象
    FirstFactory = ModFirstPeriodFactory()
    FirstObj = FirstFactory.get_object(kwargs['spark_config_key'], **spark_params["logic_params"]['logic_function_params']['params'])
    logic_function_params = spark_params["logic_params"]['logic_function_params']
    logic_function_params['params']['FirstObj'] = FirstObj

    # sql对应的变量字典，当sql中存在需要替换的变量时可以在该字典中定义
    spark_params["sql_params"]["sql_vars"] = {
        "pt_date": pt_date,
        "last_pt": last_pt_date,
        "city_code": kwargs['city_code'],
    }
    # 逻辑处理类
    spark_params["logic_params"]["logic_class"] = HouseModEvalFirst
    # 存储pt
    for save_name in spark_params["save_params"]:
        spark_params["save_params"][save_name]["partition_params"] = {
            "pt": "{}000000".format(pt_date)
        }
    spark_driver = spark_util_v2.SparkSqlDriver(debug=debug, **spark_params)
    spark_driver.run()
    return spark_driver


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('-pt_date', type=str, default='20220306')
    parser.add_argument('-config_file', type=str, default='')
    parser.add_argument('-sql_file', type=str, default='')
    parser.add_argument('-city_code', type=str, default='110000')
    parser.add_argument('-spark_config_key', type=str, default='Undefined')
    args = parser.parse_args()
    if sys.platform not in ["win32", "darwin"]:
        params = {
            'pt_data': args.pt_date,
            'config_file': args.config_file,
            'sql_file': args.sql_file,
            'city_code': args.city_code,
            'spark_config_key': args.spark_config_key
        }
        main(**params)
    else:
        pass
    pass
