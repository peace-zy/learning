#-*-coding: utf-8-*-

class DotDict(dict):
    def __init__(self, *args, **kwargs):
        super(DotDict, self).__init__(*args, **kwargs)

    def __getattr__(self, key):
        value = self[key]
        if isinstance(value, dict):
            value = DotDict(value)
        return value

class ModType:
    KitchenCloseToOpenU = DotDict({
        "en_name": "KitchenCloseToOpenU",
        "zh_name": "厨房-封闭式变开放式",
        "id": 1 << 0  # 厨房封闭改开放
    })
    BedroomAddBedroom = 1 << 1
    BedroomAddToilet = 1 << 2
    BedroomAddCloakroom = 1 << 3
    BedroomChangeLivingroom = 1 << 7  # 卧室改客厅
    LivingroomAddCloakroom = 1 << 8
    KitchenAddArea = 1 << 9  # 扩大厨房
    ToiletDryWet = 1 << 10  # 干湿分离

    AddBedroom = 1 << 11  # 增加居室
    SubBedroom = 1 << 12  # 减少居室
    AddToilet = 1 << 13  # 增加卫生间
    AddCloakroom = 1 << 14  # 增加衣帽间
    AddStorage = 1 << 15  # 增加储物间
    ToiletAddArea = 1 << 16  # 扩大卫生间
    BedroomAddArea = 1 << 17  # 扩大卧室
    SubToilet = 1 << 18  # 减少卫生间
    LivingroomAddLighting = 1 << 19  # 客厅增加采光
    AddDiningArea = 1 << 20  # 增加用餐区
    AddStudy = 1 << 21  # 增加书房
    KitchenChangeDoor = 1 << 22  # 改厨房门
    ToiletChangeDoor = 1 << 23  # 改卫生间门

class FrameVectorKey(object):
    FLOOR_PLAN_KEY = u'floorplans'
    # 默认楼层=0
    DEFAULT_FLOOR_IDX = 0
    # 角点字段名称
    POINT_KEY = u'points'
    # 墙体字段名称
    LINE_KEY = u'lines'
    # 墙体厚度名称
    LINE_THICKNESS_KEY = u'thickness'
    # 墙体自动厚度名称
    LINE_AUTO_THICKNESS_KEY = u'thicknessComputed'
    # 分间字段名称
    AREA_KEY = u'areas'
    # 分间字段名称
    LINE_ITEM_KEY = u'lineItems'
    # 分间字段名称
    ITEM_KEY = u'items'
    EDGE_KEY = u'edgeComputed'
    UID_KEY = u'id'
    TYPE_KEY = u'type'
    CURVE_KEY = u'curve'
    # 墙体字段
    LINE_ITEM_START_PT_KEY = u'startPointAt'
    LINE_ITEM_END_PT_KEY = u'endPointAt'
    LINE_ITEM_IS_KEY = u'is'
    LINE_ITEM_ENTRANCE_KEY = u'entrance'
    LINE_ITEM_LINE_ID = u'line'
    LINE_ITEM_START = u'start'
    LINE_ITEM_ROTATE_Y = u'rotateY'
    LINE_ITEM_ROTATE_X = u'rotateX'

 # 分间字段
RoomFineType = {
    0:  "其他",
    1:  "客厅",
    2:  "餐厅", 
    3:  "卧室",
    4:  "书房",
    5:  "卫生间",
    6:  "淋浴间",
    7:  "洗手间",
    8:  "厨房",
    9:  "开放厨房",
    10:  "多功能间",
    11:  "保姆间",
    12:  "阳台",
    13:  "露台",
    14:  "储物间",
    15:  "衣帽间",
    16:  "阁楼",
    17:  "花园",
    18:  "车库",
    19:  "电梯",
    20:  "地下室",
    21:  "天井",
    22:  "阳光房",
    23:  "过道",
    24:  "楼梯间",
    25:  "门厅",
    26:  "入户花园",
    27:  "玄关",
    28:  "挑空",
    29:  "晾晒区",
    30:  "洗衣房",
    31:  "娱乐区",
    32:  "健身区",
    33:  "接待区",
    34:  "影音区",
    35:  "餐饮区",
    36:  "其他 (原名“自定义”)",
    37:  "起居室", 
    38: "主卧",
    39: "次卧",
    40: "优化间",
    41: "办公室",
    42: "会议室",
    43: "洽谈间",
    44: "共享大厅",
    45: "水吧"
}
