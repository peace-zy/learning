import reform_point_detector
import inspect

ReformPointToCFactory = {m[0]: m[1] for m in inspect.getmembers(reform_point_detector, inspect.isclass)}
