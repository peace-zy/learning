# -*- coding: utf-8 -*-
from __future__ import division
import json
import copy
import boto3
import numpy as np
from scipy.optimize import linear_sum_assignment
import traceback
import logging
import sys
if sys.version_info.major == 2:
    reload(sys)
    sys.setdefaultencoding('utf-8')
    
from shapely.geometry import LineString, Polygon, Point
#from shapely.strtree import STRtree
from shapely.affinity import affine_transform, rotate

import figures
import api_lib
from mod_param import RoomFineType

__all__ = ["FrameVector"]

class FrameVector(object):
    def __init__(self, frame_id=None, frame_json=None, **kwargs):
        """
        :param frame_id:
        :param frame_json:
        :param kwargs:
        """
        self.status = 0
        try:
            self.DEBUG = kwargs.get("debug", False)
            if self.DEBUG:
                from shapely.plotting import plot_polygon, plot_points, plot_line
                import matplotlib.pyplot as plt
                self.init_plot()
            if frame_id is None and frame_json is None:
                raise KeyError('Missing parameter called frame_id or frame_json')
            if frame_id is not None and frame_json is None:
                frame_json = self.get_frame_vector(frame_id)
            self.frame_id = frame_id
            self.frame_json = frame_json
            logging.debug("frame_id=".format(frame_id))
            logging.debug("frame_json={}".format(frame_json))
            logging.info("[doing] load frame_json")
            self.frame_dict = json.loads(self.frame_json)
            if self.frame_dict is None:
                self.status = 1
                logging.warning("frame_id={} frame vector={} is None".format(self.frame_id, self.frame_dict))
                return
            logging.info("[done] load frame_json")

            self.basic_frame_info_dict = copy.deepcopy(self.frame_dict)
            self.FRAME_KEY_SHAPELY = {
                "points": [], 
                "lines": [], 
                "areas": [], 
                "lineItems": [], 
                "items": []
            }
        
            logging.info("[doing] get basic_frame_info_dict")
            for key in self.FRAME_KEY_SHAPELY:
                self.basic_frame_info_dict["floorplans"][0].pop(key)
            logging.info("[done] get basic_frame_info_dict")
            self.total_room_area = 0
            self.max_x, self.max_y = -1, -1
            self.min_x, self.min_y = float('inf'), float('inf')

            self.room_basic_tag_key = "room_basic_tag"
            logging.info("[doing] get frame_info_dict")
            self.frame_info_dict = self._get_frame_info_dict()
            logging.info("[done] get frame_info_dict")
            self.VIRTUAL_WALL_TYPE_ID = 3
            self.CENTROID_THRES = 1e-10 
            self.isolation_wall_list = set([])
                
            logging.info("[doing] post_init")
            self.post_init()
            if self.DEBUG:
                self.save_fig()
            logging.info("[done] post_init")
        except Exception as e:
            traceback.print_exc()
            logging.warning("frame_id={} {}".format(self.frame_id, e))
            self.status = 1

    def get_frame_vector(self, frame_id):
        def get_s3_client():
            S3_AK = "223HG43LGIX9W3MWTOCL"
            S3_AKS = "tqWXh8kSyxM/QfgF34dMXFJcRrIIGfIIZkVVjSMH"
            s3_client = boto3.client('s3', region_name="cn-north-1", endpoint_url="http://storage.lianjia.com",
                                    aws_access_key_id=S3_AK,
                                    aws_secret_access_key=S3_AKS)
            return s3_client

        frame_id = str(frame_id)
        s3_client = get_s3_client()
        vector_response = s3_client.get_object(Bucket='frame-eval-image', Key=str(frame_id) + '.json')
        frame_json = vector_response['Body'].read().decode('utf-8')
        return frame_json   

    def post_init(self):
        try:
            if self.frame_id is not None:
                logging.info("[doing] get frame_basic_tag")
                self.frame_basic_tag = self._get_frame_basic_tag(self.frame_id)
                logging.debug("frame_basic_tag".format(self.frame_basic_tag))
                logging.info("[done] frame_basic_tag")
                logging.info("[doing] add_basic_tag_to_room")
                if self.frame_basic_tag is not None:
                    self._add_basic_tag_to_room()
                else:
                    logging.warning("frame_id=[{}] has not basic tag".format(self.frame_id))
                logging.info("[done] add_basic_tag_to_room")
            # 为FRAME_KEY_SHAPELY添加geometry
            logging.info("[doing] add_shapely_geometry")
            self._add_shapely_geometry()
            logging.info("[done] add_shapely_geometry")
            
            logging.info("[doing] process_room")
            # 处理分间，户型是否为非旋转矩形等
            self._process_room()
            logging.info("[done] process_room")

            logging.info("[doing] process_item")
            # 家具挂接到分间，家具最近墙体计算
            self._process_item()
            logging.info("[done] process_item")
            logging.info("[doing] _get_isolation_wall")
            self.isolation_wall_list = self._get_isolation_wall()
            logging.info("[done] _get_isolation_wall")

        except Exception as e:
            traceback.print_exc()
            logging.warning("post_init frame_id={} {}".format(self.frame_id, e))

    def _get_all_area_lines(self):
        all_area_lines = set([])
        for area_id, area_info in self.area_dict.items():
            all_area_lines.update([line["id"] for line in area_info["attachments"]["lines"]])
        return all_area_lines
            
    def _get_isolation_wall(self):
        all_area_lines = self._get_all_area_lines()
        isolation_wall_list = set([]) 
        if not all_area_lines:
            logging.warning("frame_id={} has no area lines".format(self.frame_id))
            return isolation_wall_list
        for line_id in self.line_dict:
            if line_id not in all_area_lines:
                isolation_wall_list.add(line_id)

        return isolation_wall_list

    def _get_frame_info_dict(self):
        frame_info_dict = {}
        for key in self.FRAME_KEY_SHAPELY:
            frame_info_dict[key] = {}
            for ele in self.frame_dict["floorplans"][0][key]:
                frame_info_dict[key][ele["id"]] = ele
                #frame_info_dict[key][ele["id"]] = {self.room_basic_tag_key: {}}
                #frame_info_dict[key][ele["id"]].update(ele)

        return frame_info_dict

    def _get_frame_basic_tag(self, frame_id):
        FRAME_FEATURE_URL = "http://i.data.api.lianjia.com/v2/meta/frame_basic_tag"
        BIG_DATA_KEY = "frame_analysis"
        BIG_DATA_SECRET = "c338b06a92d4400edcbf11c03979241a"

        _tmp_frames_ret = api_lib.request_bigdata_api(FRAME_FEATURE_URL, {"frame_id": str(frame_id)}, BIG_DATA_KEY,
                                            BIG_DATA_SECRET)
        basic_feature = None
        try:
            if "data" in _tmp_frames_ret \
                    and len(_tmp_frames_ret["data"]) > 0 \
                    and "feature" in _tmp_frames_ret["data"][0]:
                basic_feature = json.loads(_tmp_frames_ret["data"][0]["feature"])
        except Exception as e:
            logging.warning("{} {}".format(e, _tmp_frames_ret))
        return basic_feature
    
    def _add_basic_tag_to_room(self):
        ROOM_KEYS = ["hallway", "main_room", "sub_room", "parlour", "kitchen", "parlour_toilet"]
        if self.frame_basic_tag is not None:
            for _room_key in ROOM_KEYS:
                for _room in self.frame_basic_tag.get(_room_key, []):
                    area_id = _room.get("area_id", None)
                    if area_id is None or area_id not in self.frame_info_dict["areas"]:
                        continue
                    self.frame_info_dict["areas"][area_id][self.room_basic_tag_key] = copy.deepcopy(_room)
                    #print("area_id", area_id)

    @property
    def point_dict(self):
        return self.frame_info_dict["points"]

    @property
    def line_dict(self):
        return self.frame_info_dict["lines"]

    @property
    def area_dict(self):
        return self.frame_info_dict["areas"]

    @property
    def line_item_dict(self):
        return self.frame_info_dict["lineItems"]

    @property
    def item_dict(self):
        return self.frame_info_dict["items"]

    def _process_room(self):
        def judge_room_is_normal_rect(room_info):
            room_info = copy.deepcopy(room_info)
            """
            if len(room_info["attachments"]["lines"]) != 4:
                return False
            """
            room_polygon = room_info["shapely_polygon"]
            (xmin, ymin, xmax, ymax) = room_polygon.bounds
            room_rect = Polygon([(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)])
            _rect_points = [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]
            if self.DEBUG:
                for r_p in _rect_points:
                    plot_points(Point(r_p), ax=self.ax, color=figures.RED)
            
            logging.debug(
                room_polygon.minimum_rotated_rectangle.centroid.distance(room_rect.centroid),
                room_polygon.minimum_rotated_rectangle.centroid.distance(room_polygon.centroid),
                room_polygon.minimum_rotated_rectangle.area - room_rect.area,
                room_polygon.minimum_rotated_rectangle.area - room_polygon.area
            )

            if room_polygon.minimum_rotated_rectangle.centroid.distance(room_rect.centroid) <= self.CENTROID_THRES \
                    and room_polygon.minimum_rotated_rectangle.centroid.distance(room_polygon.centroid) == 0\
                    and room_polygon.minimum_rotated_rectangle.area == room_rect.area \
                    and room_polygon.minimum_rotated_rectangle.area == room_polygon.area:
                return True
            return False

        for area_id, area_info in self.area_dict.items():
            # 处理分间，户型是否为非旋转矩形等
            room_is_normal_rect = judge_room_is_normal_rect(self.area_dict[area_id])
            self.area_dict[area_id]["is_normal_rect"] = room_is_normal_rect
            self.total_room_area += area_info["sizeWithoutLine"] if "sizeWithoutLine" in area_info else area_info["size"]
            #print(area_id, room_is_normal_rect)

    def _add_shapely_geometry(self):
        self.FRAME_KEY_SHAPELY ["points"].append("shapely_point")
        for point_id, point_info in self.point_dict.items():
            self.point_dict[point_id]["shapely_point"] = Point(
                point_info["x"],
                point_info["y"]
            )
            self.max_x, self.max_y = max(self.max_x, point_info["x"]), max(self.max_y, point_info["y"])
            self.min_x, self.min_y = min(self.min_x, point_info["x"]), min(self.min_y, point_info["y"])

        self.FRAME_KEY_SHAPELY ["lines"].append("shapely_linestring")
        for line_id, line_info in self.line_dict.items():
            coord = sorted([(self.point_dict[p_id]["x"], self.point_dict[p_id]["y"]) for p_id in line_info["points"]], key=lambda x: (x[0], x[1]))
            self.line_dict[line_id]["shapely_linestring"] = LineString(coord)

        self.FRAME_KEY_SHAPELY ["areas"].append("shapely_polygon")
        for area_id, area_info in self.area_dict.items():
            self.area_dict[area_id]["shapely_polygon"] = Polygon(
                [
                    (
                        self.point_dict[point_id]["x"],
                        self.point_dict[point_id]["y"]
                    )
                    for point_id in area_info["points"]
                ]
            )

            if self.DEBUG:
                d = self.area_dict[area_id]["shapely_polygon"]
                plot_polygon(d.minimum_rotated_rectangle, ax=self.ax, add_points=False, color=figures.BLACK)
                (xmin, ymin, xmax, ymax) = d.bounds
                #rect = Polygon([(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)])
                _rect_points = [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]
                for r_p in _rect_points:
                    plot_points(Point(r_p), ax=self.ax, color=figures.RED)
                #plot_line(LineString([(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax), (xmin, ymin)]), ax=self.ax, add_points=False, color=figures.GREEN)


        self.FRAME_KEY_SHAPELY ["lineItems"].append("shapely_linestring")
        for line_item_id, line_item_info in self.line_item_dict.items():
            start_point = line_item_info["startPointAt"]
            end_point = line_item_info["endPointAt"]
            coord = sorted([(start_point["x"], start_point["y"]), (end_point["x"], end_point["y"])], key=lambda x: (x[0], x[1]))
            self.line_item_dict[line_item_id]["shapely_linestring"] = LineString(coord)
  
        self.FRAME_KEY_SHAPELY ["items"].extend(["shapely_polygon", "shapely_linestring"])
        for item_id, item_info in self.item_dict.items():
            half_width = item_info["width"] / 2
            half_height = item_info["height"] / 2
            left_top = (item_info["x"] - half_width, item_info["y"] - half_height)
            right_top = (item_info["x"] + half_width, item_info["y"] - half_height)
            right_bottom = (item_info["x"] + half_width, item_info["y"] + half_height)
            left_bottom = (item_info["x"] - half_width, item_info["y"] + half_height)
            item_polygon = Polygon([left_top, right_top, right_bottom, left_bottom])
            points = [left_top, right_top, right_bottom, left_bottom]

            shift_points = points[1:] + [points[0]]
            lines = [[x, y] for x, y in zip(points, shift_points)]
            
            self.item_dict[item_id]["shapely_polygon"] = rotate(item_polygon, item_info["rotateZ"], origin="centroid")
            
            self.item_dict[item_id]["shapely_linestring"] = [
                rotate(
                    LineString(sorted(_line, key=lambda x: (x[0], x[1]))), 
                    item_info["rotateZ"], 
                    origin=self.item_dict[item_id]["shapely_polygon"].centroid
                ) 
                for _line in lines
            ]
           
        if self.DEBUG:
            for area_id, area_info in self.area_dict.items():
                area = area_info["shapely_polygon"]
                plot_polygon(area, ax=self.ax, add_points=False, color=figures.BLUE)
            
            for item_id, item_info in self.item_dict.items():
                item = item_info["shapely_polygon"]
                plot_polygon(item, ax=self.ax, add_points=False, color=figures.RED)
            
    def _get_item_nearest_line(self, lines, item_info, ax=None):
        _lines_linestring = [self.line_dict[_line["id"]]["shapely_linestring"] for _line in lines]
        _item_info = copy.deepcopy(item_info)

        cost_matrix = np.ones((len(_item_info["shapely_linestring"]), len(lines))) * 100
        
        for row, item_linestring in enumerate(_item_info["shapely_linestring"]):
            #plot_line(item_linestring, ax=ax, add_points=False, color=figures.GREEN)
            for col, line_linestring in enumerate(_lines_linestring):
                #plot_line(line_linestring, ax=ax, add_points=False, color=figures.YELLOW)
                cost_matrix[row][col] = item_linestring.centroid.distance(line_linestring)
       
        row_ind, col_ind = linear_sum_assignment(cost_matrix)
        tmp = [(item_idx, line_idx, cost_matrix[item_idx][line_idx]) for item_idx, line_idx in zip(row_ind, col_ind)]
        distance_info = sorted(tmp, key=lambda x: (x[2]))

        (item_idx, line_idx, cost) = distance_info[0]
        if self.DEBUG:
            plot_line(_lines_linestring[line_idx], ax=self.ax, add_points=False, color=figures.YELLOW, linewidth=2)
            plot_line(_item_info["shapely_linestring"][item_idx], ax=self.ax, add_points=False, color=figures.GREEN, linewidth=2)
            pass
        item_nearest_line_id = lines[line_idx]["id"]
        return item_nearest_line_id

    def _process_item(self):
        def _item_to_area_attachment():
            for area_id, area_info in self.area_dict.items():
                for item_id, item_info in self.item_dict.items():
                    if area_info["shapely_polygon"].contains(item_info["shapely_polygon"]):
                        if "items" not in self.area_dict[area_id]["attachments"]:
                            self.area_dict[area_id]["attachments"]["items"] = []
                        self.area_dict[area_id]["attachments"]["items"].append(
                            {
                                "id": item_id
                            }
                        )
                        item_nearest_line_id = self._get_item_nearest_line(area_info["attachments"]["lines"], item_info)
                        self.item_dict[item_id]["nearest_line"] = {"id": item_nearest_line_id}
                        if "nearest_items" not in self.line_dict[item_nearest_line_id]:
                            self.line_dict[item_nearest_line_id]["nearest_items"] = []
                        self.line_dict[item_nearest_line_id]["nearest_items"].append({"id": item_id})
        _item_to_area_attachment()

    def get_public_space_area(self, frame_vector_obj, config):
        public_space_area = 0
        for area_id, area_info in frame_vector_obj.area_dict.items():
            if "type" not in area_info:
                logging.warning("frame_id={} {} has not type".format(frame_vector_obj.frame_id, area_info))
                continue
            typeName = RoomFineType.get(area_info["type"], None)
            if typeName is None:
                typeName = area_info.get("typeName", None)

            if typeName is None:
                logging.warning("frame_id={} room_type={} is not existss".format(frame_vector_obj.frame_id, area_info["type"]))
                continue

            if typeName is not None and typeName in config["general_param"]["public_space_names"]:
                public_space_area += area_info["sizeWithoutLine"] if "sizeWithoutLine" in area_info else area_info["size"]
            elif typeName == "厨房" and "开放厨房" in config["general_param"]["public_space_names"]:
                for attachment_line in area_info["attachments"]["lines"]:
                    att_line_id = attachment_line["id"]
                    if att_line_id not in frame_vector_obj.line_dict:
                        continue
                    if frame_vector_obj.line_dict[att_line_id]["type"] == self.VIRTUAL_WALL_TYPE_ID:
                        public_space_area += area_info["sizeWithoutLine"] if "sizeWithoutLine" in area_info else area_info["size"]
            elif typeName == "阳台" and "开放阳台" in config["general_param"]["public_space_names"]:
                for attachment_line in area_info["attachments"]["lines"]:
                    att_line_id = attachment_line["id"]
                    if att_line_id not in frame_vector_obj.line_dict:
                        continue
                    if frame_vector_obj.line_dict[att_line_id]["type"] == self.VIRTUAL_WALL_TYPE_ID:
                        public_space_area += area_info["sizeWithoutLine"] if "sizeWithoutLine" in area_info else area_info["size"]
        return public_space_area
        
    def init_plot(self):
        self.fig = plt.figure()
        self.ax = self.fig.add_subplot(111)

    def save_fig(self, out_name="show_image_d.png"):
        _lim_range = (min(self.min_x, self.min_y) - 500, max(self.max_x, self.max_y) + 500)
        plt.xlim(_lim_range)
        plt.ylim(_lim_range)
        plt.savefig(out_name)

    def dump(self, use_basic_tag=False):
        out_dict = copy.deepcopy(self.basic_frame_info_dict)
        _tmp_frame_info_dict = copy.deepcopy(self.frame_info_dict)
        for key, shapely_keys in self.FRAME_KEY_SHAPELY.items():
            for ele_key, ele_info in _tmp_frame_info_dict[key].items():
                for _s_k in shapely_keys:
                    try:
                        if _s_k in ele_info:
                            _tmp_frame_info_dict[key][ele_key].pop(_s_k)
                    except Exception as e:
                        traceback.print_exc()
            out_dict["floorplans"][0][key] = [ele_info for ele_key, ele_info in _tmp_frame_info_dict[key].items()]
        if use_basic_tag:
            out_dict["basic_tag"] = self.frame_basic_tag
        
        return json.dumps(out_dict)

def main():
    frame_id = "11000020281276"
    fv = FrameVector(frame_id=frame_id, debug=True)
    #print(json.dumps(fv.dump()))
    print(fv)
if __name__ == "__main__":
    main()
