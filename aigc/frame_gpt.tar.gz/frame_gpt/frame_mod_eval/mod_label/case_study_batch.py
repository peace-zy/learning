#-*-coding: utf-8-*-
import yaml
import json
import os
import logging
from tqdm import tqdm
import time

from log import Logger
import frame_vector
from factory import ReformPointToCFactory
logger = Logger(os.path.basename(__file__)).logger

head = [
    "frame_id",
    "house_id",
    "city_code",
    "resblock_id",
    "room_cnt",
    "parlor_cnt",
    "kitchen_cnt",
    "toilet_cnt",
    "build_area",
    "used_area",
    "standard_url",
    "frame_json",
    "is_valid",
    "error_msgv",
    "frame_type",
    "pt",
]

def get_data(input_data):
    for line in input_data:
        try:
            fields = line.strip().split("\t")
            data = dict(zip(head, fields))
        except Exception as e:
            traceback.print_exc()
            yield None
        yield data

def process(data, config):
    start = time.time()
    frame_id, frame_json = data["frame_id"], data["frame_json"]
    fv_obj = frame_vector.FrameVector(frame_id=frame_id, frame_json=frame_json, debug=False)
    logging.info("-" * 10 + "[done] instantiation frame_vector status={}".format(frame_id, fv_obj.status) + "-" * 10)
    end = time.time()
    logging.info("time={} instantiation frame_vector".format((end - start) * 1000))
    start = time.time()
    if fv_obj.status != 0:
        return {}
    reform_dict = {
        "frame_id": -1 if fv_obj.frame_id is None else fv_obj.frame_id,
        "before_frame_vector": fv_obj.frame_json,
        "after_frame_vector": None,
        "reform_info": []
    }

    logging.info("-" * 10 + "[doing] frame_id={} reform point checking".format(frame_id) + "-" * 10)
    flag = False
    for reform_name, reform_kwargs in config["reform_points"].items():
        if reform_name not in ReformPointToCFactory:
            logging.warning("{} is not implement".format(reform_name))
            continue
        logging.debug(reform_name)
        reformer = ReformPointToCFactory[reform_name]()
        reform_res = reformer.detect(frame_vector=fv_obj, config=config, reform_kwargs=reform_kwargs)
        
        if reform_res:
            reform_dict["reform_info"].append(reform_res)
            reform_dict["after_frame_vector"] = fv_obj.dump()
            flag = True

    logging.info("-" * 10 + "[done] frame_id={} reform point checked".format(frame_id) + "-" * 10)
    logging.info(">" * 10 + "[done] frame_id=[{}] process".format(frame_id) + "<" * 10)
    end = time.time()
    logging.info("time={} reform point check".format((end - start) * 1000))
    return reform_dict if flag else {}

def main():
    #ori_data_file = "/mnt/aigc_cb_v2/zhangyan461/dataset/data_mining_frame_dict_vector_base_da_v2_20240304"
    ori_data_file = "debug_frame_data.txt"
    ori_data_file = "/mnt/aigc_chubao/zhangyan461/dataset/data_mining_frame_dict_vector_base_da_v2_20240306"
    ori_data_file = "/mnt/aigc_cb_v2/zhangyan461/dataset/data_mining_frame_dict_vector_base_da_v2_20240306"
    with open("config/reform_point_detect_config.yml", "r") as f:
        config = yaml.load(f, Loader=yaml.FullLoader)
        logging.info("config={}".format(config))

    split_size = 1024 * 1024 * 1024 # 1G
    #bar = tqdm(total=)
    num_line = 0
    with open(ori_data_file, "r") as f:
         with open("res_29_320.txt", "w") as wf:
             while True:
                input_data=[item.strip() for item in f.readlines(split_size)]
                if input_data:            
                    num_line += len(input_data)
                    for data in tqdm(get_data(input_data), total=len(input_data)):
                        if data is None:
                            logging.warning("data is None")
                            continue
                        
                        start = time.time()
                        reform_dict = process(data, config)
                        end = time.time()
                        logging.info("time={} process".format((end - start) * 1000))
                        if reform_dict:
                            logging.debug(reform_dict)
                            wf.write(json.dumps(reform_dict) + "\n")
                else:
                    break
    
    return

if __name__ == "__main__":
    main()

