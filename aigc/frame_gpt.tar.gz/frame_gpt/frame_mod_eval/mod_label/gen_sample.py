#-*-coding: utf-8-*-
import yaml
import json

import frame_vector
from factory import ReformPointToCFactory

def main():
    with open("config/reform_point_detect_config.yml", "r") as f:
        config = yaml.load(f, Loader=yaml.FullLoader)
        print(config)
    frame_id = "11000020281276"
    frame_id = "11000039139064"
    frame_id = "11000008637727"
    #fv_obj = frame_vector.FrameVector(frame_id=frame_id, debug=True)
    """
    test_json_file = "kitchen_close_to_openu.json"
    with open(test_json_file, "r") as f:
        frame_json = json.load(f)
    frame_json = json.dumps(frame_json)
    """
    fv_obj = frame_vector.FrameVector(frame_id=frame_id, debug=False)
    if fv_obj.status != 0:
        return {}
    
    #print(fv_obj.dump())
    reform_dict = {
        "frame_id": -1 if fv_obj.frame_id is None else fv_obj.frame_id,
        "before_frame_vector": fv_obj.frame_json,
        "after_frame_vector": None,
        "reform_info": []
    } 
    for reform_name, reform_kwargs in config["reform_points"].items():
        if reform_name not in ReformPointToCFactory:
            print(f"{reform_name} is not implement")
            continue
        print(reform_name)
        reformer = ReformPointToCFactory[reform_name]()
        reform_res = reformer.detect(frame_vector=fv_obj, config=config, reform_kwargs=reform_kwargs)
        
        if reform_res:
            reform_dict["reform_info"].append(reform_res)
            reform_dict["after_frame_vector"] = fv_obj.dump()
        #print(fv_obj.dump())
        #print(reform_res)
    print(reform_dict)
    with open("sample.json", "w") as f:
        json.dump(reform_dict, f, ensure_ascii=False, indent=4)
    return

if __name__ == "__main__":
    main()

