# 户型改造标签检测

wiki: https://wiki.lianjia.com/pages/viewpage.action?pageId=1354994722
调研wiki: https://wiki.lianjia.com/pages/resumedraft.action?draftId=1355015038&draftShareId=3a107cf5-365d-4aec-9a12-e10ee0aeaca2&
# 批量检测改造点
python case_study_batch.py

# 调试检测改造点
python case_study_debug.py

# 渲染改前改后图，方便与运营同学评估badcase及策略迭代
python show_reform_point.py 0/1 [0-批量结果, 1-调试结果输出]