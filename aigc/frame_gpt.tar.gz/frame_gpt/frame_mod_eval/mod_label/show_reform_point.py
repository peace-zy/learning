import sys
import requests
import time
import json
import traceback
from tqdm import tqdm
import os
import xml.etree.ElementTree as ET
from xml.etree.ElementTree import register_namespace
from PIL import Image
from io import BytesIO
import logging
from shapely.geometry import LineString, Polygon, Point

from log import Logger
logger = Logger(os.path.basename(__file__)).logger
from svg2pnger import Svg2Pnger 

class FrameToSvgConfig(object):
    #HTTP_URL ="https://doctorstrange-vrlab.lianjia.com/print-svg"
    # test env
    HTTP_URL = "http://huxing.ttb.test.ke.com/print-svg"
    TIMEOUT = 10
    TRY_NUM = 10

def frame_to_svg(frame_json):
    post_data = {
            "source": frame_json,
            "index": 0
    }
    #headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    start = time.time()
    TRY_NUM = FrameToSvgConfig.TRY_NUM
    svg_data = None

    #while TRY_NUM: 
    while True: 
        try:
            # {"error":true,"message":"Protocol error (Runtime.callFunctionOn): Target closed."}
            TRY_NUM -= 1
            response = requests.post(
                url=FrameToSvgConfig.HTTP_URL,
                data=post_data,
                timeout=FrameToSvgConfig.TIMEOUT
            )
            try:
                content = response.content.decode("utf-8")          
                res = json.loads(content)
            except Exception as ce:
                svg_data = content
                break
            if "code" in res and res["code"] != 0:
                break
            #elif "error" in res and res["error"]:
            
        except Exception as e:
            #traceback.print_exc()
            pass
            
    end = time.time()
    logging.info("frame_to_svg time={}s".format(end - start))
    return svg_data

class SvgConfig(object): 
    REGISTER_TAG = "http://www.w3.org/2000/svg"
    REGISTER_XLINK = "http://www.w3.org/1999/xlink"
    SVG_PREFIX_TAG = f"{{{REGISTER_TAG}}}"
    SVG_XLINK = f"{{{REGISTER_XLINK}}}"

class ProcessorConfig(object):
    EMPTY_FLOORPLAN_KEEP_KEYS = {"areaGroup", "lineGroup", "pointGroup", "lineItemGroup", "defs"}
    REMOVE_KEYS = {"ruleGroup", "gridGroup", "areaLabelGroup"}
    VIEW_BOX_DASHED_LINE_ITEM_ID = "item-defs-85"
    VALID_ATTRIB_TYPES = {"line", "item", "image", "area", "lineItem"}
    VALID_GROUP = {"areaGroup", "lineGroup", "pointGroup", "lineItemGroup", "itemGroup", "defs"}

def load_svg(in_svg, modify_image_href=False):
    # return ET.ElementTree
    if in_svg is None:
        raise ValueError("[{}] set svg_file and svg_data_str".format("SvgReader"))
    try:
        if isinstance(in_svg, str):
            if os.path.exists(in_svg):
                tree = ET.parse(in_svg)
            else:
                tree = ET.ElementTree(ET.fromstring(in_svg))
        elif isinstance(in_svg, ET.Element):
            tree = copy.deepcopy(ET.ElementTree(in_svg))
        elif isinstance(in_svg, ET.ElementTree):
            tree = copy.deepcopy(in_svg)
        else:
            raise ValueError("now support file_path, xml_str, \
                    xml.etree.ElementTree.Element, xml.etree.ElementTree.ElementTree")
        if modify_image_href:
            for elem in tree.iter():
                if SvgConfig.SVG_PREFIX_TAG + "image" == elem.tag:
                    elem.attrib[SvgConfig.SVG_XLINK + "href"] = "http:" + elem.attrib[SvgConfig.SVG_XLINK + "href"]
    except Exception as e:
        traceback.print_exc()
        return None
    
    return tree

def get_item_id_and_et_ele_dict(tree):
    item_id_and_et_ele_dict = {}
    root = tree.getroot()
    for g in root:
        #print(g.attrib, g.tag)
        for elem in g:
            for e in elem.iter():
                if "id" in e.attrib and "type" in e.attrib and e.attrib["type"] in ProcessorConfig.VALID_ATTRIB_TYPES:
                    if e.attrib["id"] not in item_id_and_et_ele_dict:
                        item_id_and_et_ele_dict[e.attrib["id"]] = {
                            "g_addr": g,
                            "g_elem": elem,
                            "id_type": e.attrib["type"],
                            "id_tag": e.tag.split(SvgConfig.SVG_PREFIX_TAG)[1],
                            "id_addr": e
                        }
                    else:
                        raise ValueError("duplicate")
                    
    return item_id_and_et_ele_dict

def write_svg(tree, out_svg_file):
    register_namespace('', SvgConfig.REGISTER_TAG)
    register_namespace('xlink', SvgConfig.REGISTER_XLINK)
    if not isinstance(tree, ET.ElementTree):
        tree = ET.ElementTree(tree)
    tree.write(out_svg_file)

def convert_frame_to_svg(data, frame_vector_key, frame_vector, out_svg_file):
    status = True
    svg = frame_to_svg(frame_vector)
    if svg is None:
        logging.info("{} frame to svg error".format(data["frame_id"]))
        status = False
        return status
    #print(svg)
    svg_tree = load_svg(svg, True)
    root = svg_tree.getroot()
    item_id_and_et_ele_dict = get_item_id_and_et_ele_dict(svg_tree)
    reform_info = data["reform_info"]
    RATIO = 25
    CANVAS_WITH, CANVAS_HEIGHT = 75000, 75000
    cooking_bench_width = 600
    for rinfo in reform_info:
        if "KitchenCloseToOpenU" in rinfo["reform_type"] \
                and len(rinfo["reform_data"]) > 0:
            for rdata in rinfo["reform_data"]:
                if "before" in frame_vector_key:
                    ele = item_id_and_et_ele_dict[rdata["id"]]
                    ele["id_addr"].attrib["fill"] = "red"
                    ele["id_addr"].attrib["opacity"] = "0.5"
                    
                if "after" in frame_vector_key:
                    cooking_bench_points = rdata["cooking_bench_points"]
                    svg_polygon = LineString(
                        [
                            (
                                point[0] / RATIO, 
                                (CANVAS_HEIGHT - point[1]) / RATIO
                            ) for point in cooking_bench_points
                        ]
                    )
                    # 原点由左下角转成左上角
                    right_hand_side = svg_polygon.buffer(cooking_bench_width / RATIO, single_sided=True)
                    cooking_bench_svg_str = right_hand_side.svg()
                    new_g = ET.SubElement(root, "g")
                    
                    cooking_bench_tag = ET.fromstring(cooking_bench_svg_str)
                    new_g.append(cooking_bench_tag)

            
    write_svg(svg_tree, out_svg_file)
    return status

def process(data, svg2pnger, keys, svg_output_path, png_output_path):
    images = []
    HEIGHT, WIDTH = 375, 500
    frame_id = data["frame_id"]
    status = True
    for k in keys:
        frame_vector_key = f"{k}_frame_vector"
        frame_vector = data[frame_vector_key]
        svg_file = os.path.join(svg_output_path, f"{frame_id}_{k}.svg")
        status = convert_frame_to_svg(data, frame_vector_key, frame_vector, svg_file)
        if not status:
            break
        png_bin = svg2pnger.svg_to_png(svg_file)
        png_img = Image.open(BytesIO(png_bin))
        images.append(png_img.resize((WIDTH, HEIGHT)))
    if status:
        new_image = Image.new('RGB', (WIDTH * 2, HEIGHT), 'white')
        for idx, img in enumerate(images):
            new_image.paste(img, (idx * WIDTH, 0))
        png_image_file = os.path.join(png_output_path, f"{frame_id}.png")
        new_image.save(png_image_file)
    return status
    
def main():
    jsonl_file = sys.argv[1]
    mode = 0
    if len(sys.argv) > 2:
        mode = int(sys.argv[2])
    DISPLAY_WINDOW_SIZE = (984, 812)
    if mode == 0:
        svg_output_path = "svg"
        png_output_path = "pngs"
    else:
        svg_output_path = "debug"
        png_output_path = "debug"
 
    os.makedirs(svg_output_path, exist_ok=True)
    os.makedirs(png_output_path, exist_ok=True)
    svg2pnger = Svg2Pnger(png_output_path, DISPLAY_WINDOW_SIZE)

    with open(jsonl_file, "r") as f:
        with open("fail_frame_id_all.txt", "w") as wf:
            for line in tqdm(f.readlines()):
                data = json.loads(line.strip())
                try:
                    status = process(
                        data,
                        svg2pnger,
                        ["before", "after"],
                        svg_output_path,
                        png_output_path
                    )
                    if not status:
                        wf.write("{}\n".format(data["frame_id"]))
                except Exception as e:
                    traceback.print_exc()
                    logging.warning("{} process error".format(data["frame_id"]))
                    continue
            
    svg2pnger.release()
 
    return

if __name__ == "__main__":

    main()
