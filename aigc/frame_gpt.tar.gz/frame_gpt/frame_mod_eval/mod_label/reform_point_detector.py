# -*- coding: utf-8 -*-
import abc
from shapely.geometry import LineString, Polygon, Point
import logging
import traceback
import copy
import sys

if sys.version_info.major == 2:
    reload(sys)
    sys.setdefaultencoding('utf-8')

from mod_param import ModType

class ReformPointDetector():
    __metaclass__ = abc.ABCMeta
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        
    @abc.abstractmethod
    def detect(self, **kwargs):
        return None

class KitchenCloseToOpenU(ReformPointDetector):
    def __init__(self, **kwargs):
        super(KitchenCloseToOpenU, self).__init__(**kwargs)
        self.reform_en_name = ModType.KitchenCloseToOpenU.en_name
        self.reform_zh_name = ModType.KitchenCloseToOpenU.zh_name
        self.reform_id = ModType.KitchenCloseToOpenU.id
        self.type_name = "厨房"
        self.DOOR_PASS_DICT = {
            0: "单开门",
            1: "推拉门",
            2: "双开门",
            3: "子母门",
            4: "电梯门",
            16: "垭口"
        }
        self.KEEP_ITEM_DISPLATY_NAMES = {"Item-StairsItem", "Item-CircularStairsItem", "Item-PillarItem"}
        self.DOOR = "door"
        self.VIRTUAL_WALL_TYPE_ID = 3
        self.DEBUG = kwargs.get("debug", False)

    def is_same_line(self, line1, line2):
        # 计算两条线段的斜率
        point1 = self.frame_vector_obj.point_dict[line1[0]]
        point2 = self.frame_vector_obj.point_dict[line1[1]]
        point3 = self.frame_vector_obj.point_dict[line2[0]]
        point4 = self.frame_vector_obj.point_dict[line2[1]]
        x1, y1 = point1["x"], point1["y"]
        x2, y2 = point2["x"], point2["y"]
        x3, y3 = point3["x"], point3["y"]
        x4, y4 = point4["x"], point4["y"]
        
        """
        slope1 = (y2 - y1) / (x2 - x1) if x2 != x1 else float('inf')
        slope2 = (y4 - y3) / (x4 - x3) if x4 != x3 else float('inf')

        # 计算两条线段的截距
        intercept1 = y1 - slope1 * x1 if x2 != x1 else float('inf')
        intercept2 = y3 - slope2 * x3 if x4 != x3 else float('inf')
        """
        EPS = 6

        slope1 = (y2 - y1) / (x2 - x1) if (abs(x2 - x1) / 10) > EPS  else float('inf')
        slope2 = (y4 - y3) / (x4 - x3) if (abs(x4 - x3) / 10) > EPS else float('inf')

        # 计算两条线段的截距
        intercept1 = y1 - slope1 * x1 if (abs(x2 - x1) / 10) > EPS else float('inf')
        intercept2 = y3 - slope2 * x3 if (abs(x4 - x3) / 10) > EPS else float('inf')

        res = False
        # 如果斜率和截距都相等，那么线段在一条直线上
        if slope1 == slope2 and intercept1 == intercept2:
            # 垂直x轴 判断x
            if slope1 == float("inf") and intercept2 == float("inf") and abs(x3 - x1) / 10 > EPS:
                res = False
            else :
                res = True     
     
        return res

    def reform_isolation_wall(self, line_id):
        #虚拟墙
        self.frame_vector_obj.line_dict[line_id]["type"] = self.VIRTUAL_WALL_TYPE_ID
        logging.debug("frame_id={} line_id={}设置成虚拟墙".format(self.frame_vector_obj.frame_id, line_id))
        for line_item_id in self.frame_vector_obj.line_dict[line_id]["items"]:
            if line_item_id in self.frame_vector_obj.line_item_dict:
                self.frame_vector_obj.line_item_dict.pop(line_item_id)
                logging.debug("frame_id={} 拆除延伸墙面/隔断/小拐角的墙体附件{}".format(self.frame_vector_obj.frame_id, line_item_id))

    def reform_func(
            self, 
            long_side_id,
            short_side_id,
            kitchen_area_id,
            public_space_area_ids,
            clear_adjacent_public_space,
            clear_kitchen,
            adjacent_line_intersection
        ):
        # 长边改成虚拟墙
        self.frame_vector_obj.line_dict[long_side_id]["type"] = self.VIRTUAL_WALL_TYPE_ID
        self.frame_vector_obj.line_dict[short_side_id]["type"] = self.VIRTUAL_WALL_TYPE_ID
        # 删除长边和短边墙体附件
        for side_id in [long_side_id, short_side_id]:
            for line_item_id in self.frame_vector_obj.line_dict[side_id]["items"]:
                logging.debug("long_side {} has been removed".format(line_item_id))
                self.frame_vector_obj.line_item_dict.pop(line_item_id)
        
        """
        # 删除短边门
        for line_item_id in self.frame_vector_obj.line_dict[short_side_id]["items"]:
            #if self.frame_vector_obj.line_item_dict[line_item_id]["type"] in self.DOOR_PASS_DICT:
                logging.debug("short_side: {} has been removed".format(line_item_id))
                self.frame_vector_obj.line_item_dict.pop(line_item_id)
        """
        # 删除厨具
        if clear_kitchen:
            kitchen_items_list = self.frame_vector_obj.area_dict[kitchen_area_id]["attachments"].get("items", [])
            for kitchen_item in kitchen_items_list:
                kitchen_item_id = kitchen_item["id"]
                displayName = self.frame_vector_obj.item_dict[kitchen_item_id].get("displayName", None)
                if displayName not in self.KEEP_ITEM_DISPLATY_NAMES:
                    self.frame_vector_obj.item_dict.pop(kitchen_item_id)

        # 相邻公共空间家具清空
        if clear_adjacent_public_space:
            for p_area_id in public_space_area_ids:
                items_list = self.frame_vector_obj.area_dict[p_area_id]["attachments"].get("items", [])
                for item in items_list:
                    item_id = item["id"]
                    displayName = self.frame_vector_obj.item_dict[item_id].get("displayName", None)
                    if displayName not in self.KEEP_ITEM_DISPLATY_NAMES:
                        self.frame_vector_obj.item_dict.pop(item_id)
        
        public_space_area_lines = set([])
        dining_room_id = None
        for p_area_id in public_space_area_ids:
            public_space_area_lines.update([line["id"] for line in self.frame_vector_obj.area_dict[p_area_id]["attachments"]["lines"]])
            if self.frame_vector_obj.area_dict[p_area_id]["typeName"] == "餐厅":
                dining_room_id = p_area_id

        # 相邻边有延伸墙面/隔断/小拐角一并拆除
        if adjacent_line_intersection:
            _point = self.frame_vector_obj.point_dict.get(adjacent_line_intersection, None)
            if _point is None:
                logging.warning("相邻边交点[{}]不存在".format(adjacent_line_intersection))
            else:
                _lines = copy.deepcopy(_point["lines"])
                if short_side_id in _lines:
                    _lines.remove(short_side_id)
                if long_side_id in _lines:
                    _lines.remove(long_side_id)
                for l_id in _lines:
                    if l_id in self.frame_vector_obj.isolation_wall_list:
                        self.reform_isolation_wall(l_id)
                        for isolation_wall_id in self.frame_vector_obj.isolation_wall_list:
                            set1 = set(self.frame_vector_obj.line_dict[isolation_wall_id]["points"])
                            set2 = set(self.frame_vector_obj.line_dict[l_id]["points"])
                            
                            if set1.intersection(set2):
                                self.reform_isolation_wall(isolation_wall_id)

                    # 交点对应相邻公共空间墙
                    elif l_id in public_space_area_lines:
                        if dining_room_id is not None:
                            # 相邻公共空间也相邻拆除与交点延长线有关的共享墙和墙体附件
                            for att_line_info in self.frame_vector_obj.area_dict[dining_room_id]["attachments"]["lines"]:
                                att_line_id = att_line_info["id"]
                                #print(att_line_id)
                                if self.is_same_line(
                                    self.frame_vector_obj.line_dict[l_id]["points"], 
                                    self.frame_vector_obj.line_dict[att_line_id]["points"]
                                ):
                                    if att_line_id in self.frame_vector_obj.line_dict:
                                        # 判断候选边是否相邻公共空间共享边
                                        for att_area_info in self.frame_vector_obj.area_dict[dining_room_id]["attachments"]["areas"]:
                                            if att_line_id in att_area_info["sharedLines"]:
                                                att_area_id = att_area_info["id"]
                                                if self.frame_vector_obj.area_dict[att_area_id]["typeName"] in self.config["general_param"]["public_space_names"]:
                                                    for line_item_id in self.frame_vector_obj.line_dict[att_line_id]["items"]:
                                                        if line_item_id in self.frame_vector_obj.line_item_dict:
                                                            self.frame_vector_obj.line_item_dict.pop(line_item_id)
                                                            logging.debug("frame_id={} 拆除餐厅与其他公共空间相邻墙体附件{}".format(self.frame_vector_obj.frame_id, line_item_id))
                                                    self.frame_vector_obj.line_dict[att_line_id]["type"] = self.VIRTUAL_WALL_TYPE_ID
                                                    logging.debug("frame_id={} 餐厅与其他公共空间相邻墙{}设置成虚拟墙".format(self.frame_vector_obj.frame_id, att_line_id))

                        self.frame_vector_obj.line_dict[l_id]["type"] = self.VIRTUAL_WALL_TYPE_ID
                        logging.debug("frame_id={} line_id={}设置成虚拟墙".format(self.frame_vector_obj.frame_id, l_id))
                
    def can_be_reformed(self, area_info, long_side_id, short_side_id, long_side_pass_length_cmp):
        flag = True
        # 与阳台相邻
        for attachment_area in area_info["attachments"]["areas"]:
            att_area_id = attachment_area["id"]
            if self.frame_vector_obj.area_dict[att_area_id]["typeName"] == "阳台":
                flag = False
                return flag
            elif self.frame_vector_obj.area_dict[att_area_id]["typeName"] not in self.config["general_param"]["public_space_names"]:
                for s_l_item_id in attachment_area["sharedLineItems"]:
                    if self.frame_vector_obj.line_item_dict[s_l_item_id]["type"] in self.DOOR_PASS_DICT:
                        flag = False
                        return flag

        # 长边有垭口
        if long_side_pass_length_cmp is not None:
            for line_item_id in self.frame_vector_obj.line_dict[long_side_id]["items"]:
                # 有垭口
                if self.frame_vector_obj.line_item_dict[line_item_id]["type"] == 16:
                    expression = "{}{}".format(self.frame_vector_obj.line_item_dict[line_item_id]["length"], long_side_pass_length_cmp)
                    if not eval(expression):
                        flag = False
                        return flag
        
        # 虚拟墙
        if self.frame_vector_obj.line_dict[long_side_id]["type"] == self.VIRTUAL_WALL_TYPE_ID \
                or self.frame_vector_obj.line_dict[short_side_id]["type"] == self.VIRTUAL_WALL_TYPE_ID:
            flag = False
            return flag
            
        return flag         
        
    def get_cooking_bench_points(
        self,
        long_side_id,
        short_side_id,
        kitchen_area_id,
        cooking_bench_width
    ):
        cooking_bench_points = []
        long_side_points = self.frame_vector_obj.line_dict[long_side_id].get("points", [])
        kitchen_points = self.frame_vector_obj.area_dict[kitchen_area_id].get("points", [])
        if len(long_side_points) != 2 or not kitchen_points:
            return cooking_bench_points
        
        l_s_p1_index = kitchen_points.index(long_side_points[0])
        l_s_p2_index = kitchen_points.index(long_side_points[1])
        max_p_index = max(l_s_p1_index, l_s_p2_index)
        min_p_index = min(l_s_p1_index, l_s_p2_index)
        # 起始点在0位
        if max_p_index == len(kitchen_points) - 1 and min_p_index == 0:
            new_kitchen_points = kitchen_points
        else:
            new_kitchen_points = kitchen_points[max_p_index:] + kitchen_points[:max_p_index]

        kitchen_shapely_linestring = LineString(
            [
                (
                    self.frame_vector_obj.point_dict[p_id]["x"], 
                    self.frame_vector_obj.point_dict[p_id]["y"]
                ) for p_id in new_kitchen_points
            ]
        )

        right_hand_side = kitchen_shapely_linestring.buffer(-cooking_bench_width, single_sided=True)
        exterior_coords = right_hand_side.exterior.coords.xy
        cooking_bench_points = list(zip(exterior_coords[0], exterior_coords[1]))
        #print(cooking_bench_points)
        if self.DEBUG:
            from shapely.plotting import plot_polygon, plot_points, plot_line
            import matplotlib.pyplot as plt
            RATIO = 25
            self.fig = plt.figure()
            self.ax = self.fig.add_subplot(111)
            plot_polygon(right_hand_side, ax=self.ax, add_points=True, color="#ff3333")
            out_name = "show_reform_point.png"
            for x, y in zip(right_hand_side.exterior.coords.xy[0], right_hand_side.exterior.coords.xy[1]):
                plt.annotate((x, y), (x, y))
            plt.savefig(out_name)
            svg_polygon = LineString(
                [
                    (
                        self.frame_vector_obj.point_dict[p_id]["x"] / RATIO, 
                        (75000 - self.frame_vector_obj.point_dict[p_id]["y"]) / RATIO
                    ) for p_id in new_kitchen_points
                ]
            )
            # 原点由左下角转成左上角
            right_hand_side_1 = svg_polygon.buffer(cooking_bench_width / RATIO, single_sided=True)
            #print(right_hand_side_1.svg())

        return cooking_bench_points
    
    def detect(self, **kwargs):
        logging.info("[doing] [{}] reform point dectct".format(self.reform_en_name))
        reform_res = {
            "reform_id": self.reform_id,
            "reform_type": self.reform_en_name,
            "reform_zh_name": self.reform_zh_name,
            "reform_data": [],
            "reform_advantage_info": [],
        }
        try:
            self.frame_vector_obj, self.config, reform_kwargs = kwargs["frame_vector"], kwargs["config"], kwargs["reform_kwargs"]
            check_normal_rect = reform_kwargs.get("is_normal_rect", False)
            need_side_num = reform_kwargs.get("need_side_num", 0)
            adjacent_side_near_publice_space_num = reform_kwargs.get("adjacent_side_near_publice_space_num", 0)
            long_side_cmp = reform_kwargs.get("long_side_cmp", None)
            short_side_cmp = reform_kwargs.get("short_side_cmp", None)
            long_side_pass_length_cmp = reform_kwargs.get("long_side_pass_length_cmp", None)
            clear_adjacent_public_space = reform_kwargs.get("clear_adjacent_public", True)
            clear_kitchen = reform_kwargs.get("clear_kitchen", True)
            cooking_bench_width = reform_kwargs.get("cooking_bench_width", 0.6) * 1000 # 转成mm
            before_public_space_area = self.frame_vector_obj.get_public_space_area(self.frame_vector_obj, self.config)
        except Exception as e:
            logging.warning(e)
            traceback.print_exc()
            return {}

        need_reform = False

        for area_id, area_info in self.frame_vector_obj.area_dict.items():
            try:
                # 规则矩形
                typeName = area_info.get("typeName", None)
                if typeName is None or typeName != self.type_name:
                    continue
                if check_normal_rect:
                    is_normal_rect = area_info.get("is_normal_rect", False)
                    if not is_normal_rect:
                        continue
                if need_side_num > 0 and len(area_info["attachments"]["lines"]) != need_side_num:
                    continue
                    
                public_space_shared_lines = []
                public_space_area_ids = []
                for attachment_area in area_info["attachments"]["areas"]:
                    att_area_id = attachment_area["id"]
                    if self.frame_vector_obj.area_dict[att_area_id]["typeName"] in self.config["general_param"]["public_space_names"]:
                        public_space_shared_lines += attachment_area["sharedLines"]
                        public_space_area_ids.append(att_area_id)
                        logging.debug(area_id, public_space_shared_lines)
                    
                    
                # 邻边且边与公共空间相邻的数量
                if len(public_space_shared_lines) != adjacent_side_near_publice_space_num:
                    continue
            
                line_id_len = sorted(
                    [
                        (line_id, self.frame_vector_obj.line_dict[line_id]["shapely_linestring"].length / 1000) for line_id in public_space_shared_lines
                    ],
                    key=lambda x: x[1]
                )
                logging.debug(line_id_len)

                short_side, long_side = line_id_len[0], line_id_len[-1]
                
                # 是否相邻
                if not self.frame_vector_obj.line_dict[short_side[0]]["shapely_linestring"].touches(
                        self.frame_vector_obj.line_dict[long_side[0]]["shapely_linestring"]):
                    continue

                # 邻边相交点
                adjacent_line_intersection = list(
                    set(self.frame_vector_obj.line_dict[long_side[0]]["points"]).intersection(
                        set(self.frame_vector_obj.line_dict[short_side[0]]["points"])
                    )
                )
                if len(adjacent_line_intersection) != 1:
                    continue

                # 长短边长度限制
                if long_side_cmp is not None:
                    expression1 = "{}{}".format(long_side[1], long_side_cmp)
                    logging.debug(expression1)
                    if not eval(expression1):
                        continue
                if short_side_cmp is not None:
                    expression2 = "{}{}".format(short_side[1], short_side_cmp)
                    logging.debug(expression2)
                    if not eval(expression2):
                        continue
                                           
                # 其他条件
                if not self.can_be_reformed(area_info, long_side[0], short_side[0], long_side_pass_length_cmp):
                    continue

                logging.debug("{} {} 可以修改{}".format(area_id, area_info["roomName"], self.__class__.__name__))
                # 改造
                self.reform_func(
                    long_side_id=long_side[0],
                    short_side_id=short_side[0],
                    kitchen_area_id=area_id,
                    public_space_area_ids=public_space_area_ids,
                    clear_adjacent_public_space=clear_adjacent_public_space,
                    clear_kitchen=clear_kitchen,
                    adjacent_line_intersection=adjacent_line_intersection[0]
                )
                cooking_bench_points = self.get_cooking_bench_points(
                    long_side_id=long_side[0],
                    short_side_id=short_side[0],
                    kitchen_area_id=area_id,
                    cooking_bench_width=cooking_bench_width
                )
                reform_res["reform_data"].append(
                    {
                        "id": area_id,
                        "cooking_bench_points": cooking_bench_points
                    }
                )
                need_reform = True
            except Exception as e:
                logging.warning("{}".format(e))
                traceback.print_exc()
                continue
        after_public_space_area = self.frame_vector_obj.get_public_space_area(self.frame_vector_obj, self.config)
 
        logging.info("[done] [{}] reform point dectct".format(self.reform_en_name))
        
        if need_reform:
            # 公共空间占比
            if "public_space_ratio" in reform_kwargs["advantage"]:
                reform_res["reform_advantage_info"].append({
                    "advantage": reform_kwargs["advantage"]["public_space_ratio"],
                    "before": round(100 * (before_public_space_area / self.frame_vector_obj.total_room_area), 2),
                    "after": round(100 * (after_public_space_area / self.frame_vector_obj.total_room_area), 2)
                })
            if "width" in reform_kwargs["advantage"]:
                reform_res["reform_advantage_info"].append({
                    "advantage": reform_kwargs["advantage"]["width"],
                    "before": 0,
                    "after": 0
                })

            return reform_res
        else:
            return {}

if __name__ == '__main__':
    frame_id = '18000012280542'
    RC = RoomCombine(frame_id=frame_id)
    for area in RC.frame_dict['floorplans'][0]['areas']:
        import pdb
        pdb.set_trace()
        room_object = RC.get_id_object(area['id'])
        print(room_object)
