#-*-coding: utf-8-*-
import yaml
import os
import json

from log import Logger
import frame_vector
from factory import ReformPointToCFactory
logger = Logger(os.path.basename(__file__)).logger

def main():
    with open("config/reform_point_detect_config.yml", "r") as f:
        config = yaml.load(f, Loader=yaml.FullLoader)
        print(config)
    frame_id = "34000001562983"
    frame_id = "87480001954823"
    frame_id = "1620044443554375"
    frame_id = "11000039139064"
    frame_id = "14000006399638"
    frame_id = "16000003571870"
    frame_id = "88280001067444"
    frame_id = "14000023979765"
    frame_id = "88280001067444"
    frame_id = "11000015648474"
    frame_id = "37000029247082"
    frame_id = "88430000656913"
    frame_id = "11000039993215"
    frame_id = "14000007262404"
    frame_id = "11000039993215"
    frame_id = "34000001562983"
    frame_id = "11000039139064"
    frame_id = "11000008637727"
    frame_id = "14000023979765"
    frame_id = "88280001067444"
    frame_id = "88430000656913"
    frame_id = "11000015648474"
    frame_id = "51000003884704"
    frame_id = "87330011478297"
    frame_id = "87480002271856"
    frame_id = "87590001241825"
    frame_id = "82000005104927"
    frame_id = "41000008328116"
    frame_id = "21000028820331"
    frame_id = "32000000533703"

    #fv_obj = frame_vector.FrameVector(frame_id=frame_id, debug=True)
    """
    test_json_file = "kitchen_close_to_openu.json"
    with open(test_json_file, "r") as f:
        frame_json = json.load(f)
    frame_json = json.dumps(frame_json)
    """
    fv_obj = frame_vector.FrameVector(frame_id=frame_id, debug=False)
    if fv_obj.status != 0:
        return {}
    #print(fv_obj.dump())
    reform_dict = {
        "frame_id": -1 if fv_obj.frame_id is None else fv_obj.frame_id,
        "before_frame_vector": fv_obj.frame_json,
        "after_frame_vector": None,
        "reform_info": []
    } 
    for reform_name, reform_kwargs in config["reform_points"].items():
        if reform_name not in ReformPointToCFactory:
            print("{} is not implement".format(reform_name))
            continue
        print(reform_name)
        reformer = ReformPointToCFactory[reform_name](debug=True)
        #reformer = ReformPointToCFactory[reform_name]()
        reform_res = reformer.detect(frame_vector=fv_obj, config=config, reform_kwargs=reform_kwargs)
        
        if reform_res:
            reform_dict["reform_info"].append(reform_res)
            reform_dict["after_frame_vector"] = fv_obj.dump()
        #print(fv_obj.dump())
        #print(reform_res)
    #print(reform_dict)
    with open("debug.json", "w") as f:
        f.write(json.dumps(reform_dict) + "\n")
    """
    print(reform_dict["before_frame_vector"])
    print("#" * 100)
    print(reform_dict["after_frame_vector"])
    """
    return

if __name__ == "__main__":
    main()

