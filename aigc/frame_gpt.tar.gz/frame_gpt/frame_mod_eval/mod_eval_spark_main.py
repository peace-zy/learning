# -*- coding: utf-8 -*-
# ===============================================================
#
#    Copyright (C) 2021 Beike, Inc. All Rights Reserved.
#
#    @Create Author : 李雨龙 (liyulong008@ke.com)
#    @Create Time   : 2021/8/11 11:24
#    @Description   : frame_miner
#
# ===============================================================
from __future__ import division

import sys
import yaml
import logging
import traceback

from frame_mod_eval.utils import reform_doc
from lib import spark_util
from lib.file_util import get_file_stream
import frame_eval.frame_tag_lib.utils as tag_utils


def single_frame_runner(row, **params):
    _frame_id, after_frame_id = row.frame_id, row.after_frame_id
    before_frame_json, after_frame_json = row.before_frame_json, row.after_frame_json
    da_data_cols = params['mod_eval_conf']['da_data_cols']
    try:
        logging.debug('FRAME ID {}-{} START. '.format(_frame_id, after_frame_id))
        _ret_dict = reform_doc.reform_docs_main_without_http(_frame_id, after_frame_id,
                                                             before_frame_json, after_frame_json,
                                                             params)
        return [_ret_dict[_[0]] for _ in da_data_cols]
    except:
        error_msg = 'FRAME ID {}-{} ERROR: {}'.format(_frame_id, after_frame_id,
                                                      str(traceback.format_exc()).replace('\n', '|'))
        logging.fatal(error_msg)
        is_valid = 0
        unknown_err_code = -2
        default_score = 0.0
        detail_info = ''
        after_frame_json = ''
        return [_frame_id, after_frame_id, unknown_err_code,
                default_score, error_msg, '', detail_info,
                after_frame_json, is_valid]


def logic_func(driver, raw_df, **params):
    """
     spark 逻辑处理
    :param driver: spark_util.SparkSqlDriver, spark 执行类
    :param raw_df: pyspark.sql.dataframe.DataFrame， sql 查询结果
    :param params: dict, 参数字典
    :return: result_df, 处理后的 DataFrame
    """
    # 过滤不需要计算的行
    raw_df_done = raw_df.filter("score > -0.9 and score is not null").persist()
    # 过滤出需要计算的增量
    result_rdd = raw_df.filter("score <= -0.9 ").repartition(300).rdd.map(lambda row: single_frame_runner(row, **params))
    # join回去
    names = [_ for _, __ in params['mod_eval_conf']['da_data_cols']]
    result_df = result_rdd.toDF(names)
    raw_df_union = raw_df_done.select(names).union(result_df)
    return raw_df_union


def main():
    """ 主函数 """
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    if len(sys.argv) < 2:
        logging.error("no less than 1 arguments!")
        sys.exit()

    pt_date = sys.argv[1]
    config_file = sys.argv[2]
    report_last_pt = sys.argv[3]
    cluster_last_pt = sys.argv[4]
    city_code = sys.argv[5]

    f = get_file_stream(config_file)
    conf = yaml.load(f)

    # 从配置文件读取参数
    spark_config_key = "frame_mod_eval"
    spark_params = conf.get(spark_config_key, None)
    if spark_params is None:
        logging.error("lack {} in config file".format(spark_config_key))
        sys.exit(1)
    # 加载文案配置
    logic_function_params = spark_params["logic_params"]['logic_function_params']
    conf_params2 = dict()
    conf_params3 = dict()
    tag_utils.collect_conf_on_spark(r"frame_eval/frame_tag_lib/conf.yml", conf_params2)
    tag_utils.collect_conf_on_spark(r"frame_mod_eval/reform_docs.yml", conf_params3)
    logic_function_params.update(conf_params2)
    logic_function_params.update(conf_params3)
    # 补充参数
    spark_params["logic_params"]['logic_function_params'] = logic_function_params
    # pt
    spark_params["sql_params"]["pt_date"] = pt_date
    spark_params["sql_params"]["last_pt"] = report_last_pt
    spark_params["sql_params"]["cluster_last_pt"] = cluster_last_pt
    spark_params["sql_params"]["city_code"] = city_code
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_function"] = logic_func
    # 存储pt
    spark_params["save_params"]["partition_params"] = {"pt": "{}000000".format(pt_date)}

    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()


if __name__ == "__main__":
    main()
