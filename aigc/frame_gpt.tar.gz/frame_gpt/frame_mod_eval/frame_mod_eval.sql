WITH group_base AS (
		SELECT *
		FROM data_mining.data_mining_frame_res_group_da
		WHERE pt = '{pt_date}000000'
			AND city_code IN ({city_code})
	),
	cluster_v3 AS (
		SELECT *
		FROM data_mining.data_mining_frame_cluster_v3_da
		WHERE pt = '{cluster_last_pt}000000'
			AND city_code IN ({city_code})
	),
	group_cluster AS (
		SELECT DISTINCT g.frame_id, rept_frame_id, res_mod_rept_id
		FROM group_base g
			JOIN cluster_v3 v ON g.frame_id = v.frame_id
	),
	last_report AS (
		SELECT frame_id, after_frame_id, status, score, report
	            , short_report, detail_info, after_frame_json, is_valid
        FROM (
            SELECT *, ROW_NUMBER() OVER (PARTITION BY frame_id, after_frame_id ORDER BY status DESC) AS report_rn
            FROM data_mining.data_mining_mod_report_inter_da
            WHERE pt = '{last_pt}000000'
        ) inner_last_report
        WHERE report_rn = 1
	),
	v_frame AS (
		SELECT frame_id
			, reflect('java.net.URLDecoder', 'decode', trim(vector_value), 'UTF-8') AS json_str
		FROM (
			SELECT mapping.frame_id, vector_value
			FROM (
				SELECT id, vector_value
				FROM dw.dw_house_frame_vector_da
				WHERE pt = '{pt_date}000000'
					AND is_valid = 1
			) vector
				JOIN (
					SELECT image_id, entity_id AS frame_id, ROW_NUMBER() OVER (
                        PARTITION BY entity_id
                        ORDER BY
                            update_time DESC
                    ) AS rn
					FROM dw.dw_house_image_entity_mapping_da
					WHERE pt = '{pt_date}000000'
						AND image_type_code = 110028006
						AND entity_type_code = 110029002
						AND is_valid = 1
				) mapping
				ON mapping.image_id = vector.id
				JOIN (
					SELECT DISTINCT frame_id
					FROM dw.dw_house_house_frame_mapping_da
					WHERE pt = '{pt_date}000000'
						AND is_valid = 1
						AND city_code IN ({city_code})
				) h_m
				ON mapping.frame_id = h_m.frame_id
				where rn =1
		) aaa
	)
SELECT
    distinct nvl(c.frame_id, a.frame_id) as frame_id
    , nvl(c.after_frame_id, b.frame_id) AS after_frame_id
    , c.status
	, nvl(c.score, -1) AS score, c.report
	, c.short_report, c.detail_info, d.json_str AS before_frame_json
	, nvl(c.after_frame_json, e.json_str) AS after_frame_json
	, nvl(c.is_valid, 1) AS is_valid
FROM group_cluster a
	FULL JOIN group_cluster b ON a.res_mod_rept_id = b.res_mod_rept_id
	LEFT JOIN last_report c
	ON a.frame_id = c.frame_id
		AND b.frame_id = c.after_frame_id
	LEFT JOIN v_frame d ON a.frame_id = d.frame_id
	LEFT JOIN v_frame e ON b.frame_id = e.frame_id
WHERE a.frame_id != b.frame_id
	AND a.rept_frame_id != b.rept_frame_id
order by rand()