WITH today_report AS (
        -- 昨天的文案内容
		SELECT distinct frame_id, after_frame_id, NVL(score, 0.0) as score, city_code, reform_theme, status
		FROM data_mining.data_mining_mod_report_v2_secondhand_c_inter_da
		WHERE pt = '{pt_date}000000' and status = 2 and is_valid = 1
	),
    today_image AS (
        -- 昨天的图片内容
		SELECT distinct frame_id, after_frame_id, area_id, reform_id, reform_class, reform_spare, before_flag, url
		FROM data_mining.data_mining_mod_image_v2_url_da
		WHERE pt = '{last_image_date}000000' and is_valid = 1 and reform_class = 2
	),
    last_final_report AS (
        -- 前一天的最终报告.
		SELECT distinct frame_id, report, city_code
		FROM data_mining.data_mining_second_hand_mod_report_docs_da
		WHERE pt = '{last_final_report_date}000000' and status = 1
	)
SELECT distinct a.frame_id
       , a.after_frame_id
       , a.score
       , a.status
       , nvl(a.reform_theme, '') as reform_theme
       , nvl(c.report, '') as report
       , nvl(c.city_code, a.city_code) as city_code
       , b.area_id
       , b.reform_id
       , b.reform_class
       , b.reform_spare
       , b.before_flag
       , b.url
FROM today_report a
	LEFT JOIN today_image b ON b.frame_id = a.frame_id AND b.after_frame_id = a.after_frame_id
    LEFT JOIN last_final_report c ON c.frame_id = a.frame_id