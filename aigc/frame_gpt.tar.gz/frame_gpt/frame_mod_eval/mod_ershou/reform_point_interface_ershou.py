# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2021/11/3 18:58
# ===================================
import sys
import copy
import math

import inspect
import numpy as np

from abc import ABCMeta, abstractmethod
from frame_mod_eval.mod_lib.mod_params import ModIndex, ModIndexSpare
import frame_mod_eval.mod_lib.mod_params as MP
import frame_mod_eval.mod_lib.mod_tools as MT
from frame_mod_eval.mod_lib.reform_point_interface import IReformPoint
from frame_mod_eval.mod_lib.mod_image import SecondHandModPolygon
from frame_mod_eval.mod_lib.mod_doc import ErshouModDoc


class ReformPointSecondHandFactory(object):
    def __init__(self, **kwargs):
        self.kwargs = kwargs

    @property
    def ClassDict(self):
        class_list = inspect.getmembers(sys.modules[__name__])
        class_dict = {_name: _class for _name, _class in class_list}
        return class_dict

    def get_object(self, ReformPointName, **kwargs):
        if ReformPointName not in self.ClassDict:
            raise NotImplementedError('class {} has not been implement'.format(ReformPointName))
        class_obj = self.ClassDict[ReformPointName](**kwargs)
        return class_obj


class IReformPointSecondHand(IReformPoint):
    __metaclass__ = ABCMeta

    def __init__(self, **kwargs):
        super(IReformPointSecondHand, self).__init__(**kwargs)
        self.service_name = 'SecondHandToC'
        self.reform_class = 2
        self.area_id = 'whole' if kwargs.get('self_room', None) is None else kwargs['self_room'].uid

    @abstractmethod
    def judge_is_valid(self, **kwargs):
        return False

    @abstractmethod
    def solve(self, **kwargs):
        return None


class BedroomAddBedroom(IReformPointSecondHand):
    def __init__(self, **kwargs):
        super(BedroomAddBedroom, self).__init__(**kwargs)
        self.reform_name = ModIndex.BedroomAddBedroom.name
        self.reform_id = ModIndex.BedroomAddBedroom.value
        self.reform_spare_id = ModIndexSpare.AddBedroom.value
        self.modDocs = ErshouModDoc(self.reform_name, **kwargs)

    def collect_polygons(self, **kwargs):
        draw_params = {'color': kwargs['draw_img']['area_color_origin'],
                       'fill': kwargs['draw_img']['area_color_origin'],
                       'opacity': kwargs['draw_img']['area_opacity_origin']}
        self.modPolygons.set_polygons([kwargs['self_room']], polygon_type='room', belong_to='A', **draw_params)

        draw_params = {'color': kwargs['draw_img']['area_color_origin'],
                       'fill': kwargs['draw_img']['area_color_origin'],
                       'opacity': kwargs['draw_img']['area_opacity_origin']}
        self.modPolygons.set_polygons([kwargs['room_same_class']], polygon_type='room', belong_to='B', **draw_params)

        draw_params = {'color': kwargs['draw_img']['area_color_add'],
                       'fill': kwargs['draw_img']['area_color_add'],
                       'opacity': kwargs['draw_img']['area_opacity_add']}
        self.modPolygons.set_polygons([kwargs['related_room']], polygon_type='room', belong_to='B', **draw_params)
        pass

    def judge_is_valid(self, **kwargs):
        flag = False
        related_room = kwargs['related_room']
        if related_room.intersect_ratio > self.kwargs['reform_docs']['threshold_partition'] or related_room.intersect_abs_area <= self.kwargs['reform_docs']['threshold_partition_abs']:
            flag = True
        return flag

    def solve(self, **kwargs):
        self_room = kwargs['self_room']
        room_same_class = kwargs['room_same_class']
        s2 = 0
        if room_same_class is not None:
            s2 = room_same_class.area_size
        for _related in self_room.passive:
            # 判断相关联的分间是否是卧室，检测卧室与卧室相关的改造点
            if s2 > 0 and (_related.detail_type == MP.RoomNameEnum.bedroom.value or _related.detail_type == MP.RoomNameEnum.mainroom.value or _related.detail_type == MP.RoomNameEnum.secondary_bedroom.value):
                kwargs['related_room'] = _related
        if kwargs.get('related_room', None) is None:
            return None
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        self.collect_polygons(**kwargs)
        return self


class AddToilet(IReformPointSecondHand):
    def __init__(self, **kwargs):
        super(AddToilet, self).__init__(**kwargs)
        self.reform_name = ModIndex.AddToilet.name
        self.reform_id = ModIndex.AddToilet.value
        self.reform_spare_id = ModIndexSpare.AddToilet.value
        self.modDocs = ErshouModDoc(self.reform_name, **kwargs)

    def collect_polygons(self, **kwargs):
        frame_a = kwargs['frame_a']
        frame_b = kwargs['frame_b']
        toilet_list = list()
        # 改后户型如果卫生间在原户型没有对应关系，+1
        for room in frame_b.room_list:
            if room.room_type != MP.RoomClassEnum.toilet.value:
                continue
            match_cnt = 0
            for match, _ in room.matched_obj:
                if match.room_type == MP.RoomClassEnum.toilet.value:
                    match_cnt += 1
            if match_cnt == 0:
                toilet_list.append(room)
        for room in frame_a.room_list:
            if room.room_type != MP.RoomClassEnum.toilet.value:
                continue
            match_cnt = 0
            match_area = 100000000
            match_obj = None
            for match, _ in room.matched_obj:
                if match.room_type == MP.RoomClassEnum.toilet.value:
                    match_cnt += 1
                    if match.area_size < match_area:
                        match_area = match.area_size
                        match_obj = match
            if match_cnt >= 2:
                toilet_list.append(match_obj)

        draw_params = {'color': kwargs['draw_img']['area_color_add'],
                       'fill': kwargs['draw_img']['area_color_add'],
                       'opacity': kwargs['draw_img']['area_opacity_add']}
        self.modPolygons.set_polygons(toilet_list, polygon_type='room', belong_to='B', **draw_params)

    def judge_is_valid(self, **kwargs):
        flag = False
        if kwargs['frame_a'].structure[3] < kwargs['frame_b'].structure[3]:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        self.collect_polygons(**kwargs)
        return self


class AddCloakroom(IReformPointSecondHand):
    def __init__(self, **kwargs):
        super(AddCloakroom, self).__init__(**kwargs)
        self.reform_name = ModIndex.AddCloakroom.name
        self.reform_id = ModIndex.AddCloakroom.value
        self.reform_spare_id = ModIndexSpare.AddCloakroom.value
        self.modDocs = ErshouModDoc(self.reform_name, **kwargs)

    def collect_polygons(self, **kwargs):
        frame_b = kwargs['frame_b']
        cloak_list = list()
        for room in frame_b.room_list:
            if room.room_type != MP.RoomClassEnum.cloakroom.value:
                continue
            match_cnt = 0
            for match, _ in room.matched_obj:
                if match.room_type == MP.RoomClassEnum.cloakroom.value:
                    match_cnt += 1
            if match_cnt == 0:
                cloak_list.append(room)
        draw_params = {'color': kwargs['draw_img']['area_color_add'],
                       'fill': kwargs['draw_img']['area_color_add'],
                       'opacity': kwargs['draw_img']['area_opacity_add']}
        self.modPolygons.set_polygons(cloak_list, polygon_type='room', belong_to='B', **draw_params)

    def judge_is_valid(self, **kwargs):
        frame_a, frame_b = kwargs['frame_a'], kwargs['frame_b']
        cnt_a, cnt_b = 0, 0
        for _room in frame_a.room_list:
            if _room.room_type == MP.RoomClassEnum.cloakroom.value:
                cnt_a = cnt_a + 1
        for _room in frame_b.room_list:
            if _room.room_type == MP.RoomClassEnum.cloakroom.value:
                cnt_b = cnt_b + 1
        flag = False
        if cnt_a < cnt_b:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        self.collect_polygons(**kwargs)
        return self


class AddStorage(IReformPointSecondHand):
    def __init__(self, **kwargs):
        super(AddStorage, self).__init__(**kwargs)
        self.reform_name = ModIndex.AddStorage.name
        self.reform_id = ModIndex.AddStorage.value
        self.reform_spare_id = ModIndexSpare.AddStorage.value
        self.modDocs = ErshouModDoc(self.reform_name, **kwargs)

    def collect_polygons(self, **kwargs):
        frame_b = kwargs['frame_b']
        storage_list = list()
        for room in frame_b.room_list:
            if room.room_type != MP.RoomClassEnum.storage.value:
                continue
            match_cnt = 0
            for match, _ in room.matched_obj:
                if match.room_type == MP.RoomClassEnum.storage.value:
                    match_cnt += 1
            if match_cnt == 0:
                storage_list.append(room)
        draw_params = {'color': kwargs['draw_img']['area_color_add'],
                       'fill': kwargs['draw_img']['area_color_add'],
                       'opacity': kwargs['draw_img']['area_opacity_add']}
        self.modPolygons.set_polygons(storage_list, polygon_type='room', belong_to='B', **draw_params)

    def judge_is_valid(self, **kwargs):
        frame_a, frame_b = kwargs['frame_a'], kwargs['frame_b']
        cnt_a, cnt_b = 0, 0
        for _room in frame_a.room_list:
            if _room.room_type == MP.RoomClassEnum.storage.value:
                cnt_a = cnt_a + 1
        for _room in frame_b.room_list:
            if _room.room_type == MP.RoomClassEnum.storage.value:
                cnt_b = cnt_b + 1
        flag = False
        if cnt_a < cnt_b:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        self.collect_polygons(**kwargs)
        return self


class AddStudy(IReformPointSecondHand):
    def __init__(self, **kwargs):
        super(AddStudy, self).__init__(**kwargs)
        self.reform_name = ModIndex.AddStudy.name
        self.reform_id = ModIndex.AddStudy.value
        self.reform_spare_id = ModIndexSpare.AddStudy.value
        self.modDocs = ErshouModDoc(self.reform_name, **kwargs)

    def collect_polygons(self, **kwargs):
        frame_b = kwargs['frame_b']
        study_list = list()
        for room in frame_b.room_list:
            if room.room_type != MP.RoomClassEnum.bedroom.value or room.detail_type != 4:
                continue
            match_cnt = 0
            for match, _ in room.matched_obj:
                if match.room_type != MP.RoomClassEnum.bedroom.value or match.detail_type != 4:
                    match_cnt += 1
            if match_cnt == 0:
                study_list.append(room)
        draw_params = {'color': kwargs['draw_img']['area_color_add'],
                       'fill': kwargs['draw_img']['area_color_add'],
                       'opacity': kwargs['draw_img']['area_opacity_add']}
        self.modPolygons.set_polygons(study_list, polygon_type='room', belong_to='B', **draw_params)

    def judge_is_valid(self, **kwargs):
        frame_a, frame_b = kwargs['frame_a'], kwargs['frame_b']
        cnt_a, cnt_b = 0, 0
        for _room in frame_a.room_list:
            if _room.room_type == MP.RoomClassEnum.bedroom.value and _room.detail_type == 4:
                cnt_a = cnt_a + 1
        for _room in frame_b.room_list:
            if _room.room_type == MP.RoomClassEnum.bedroom.value and _room.detail_type == 4:
                cnt_b = cnt_b + 1
        flag = False
        if cnt_a < cnt_b:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        self.collect_polygons(**kwargs)
        return self


class AddDiningArea(IReformPointSecondHand):
    def __init__(self, **kwargs):
        super(AddDiningArea, self).__init__(**kwargs)
        self.reform_name = ModIndex.AddDiningArea.name
        self.reform_id = ModIndex.AddDiningArea.value
        self.reform_spare_id = ModIndexSpare.AddDiningArea.value
        self.modDocs = ErshouModDoc(self.reform_name, **kwargs)

    def collect_polygons(self, **kwargs):
        frame_b = kwargs['frame_b']
        Dining_list = list()
        for room in frame_b.room_list:
            if room.room_type != MP.RoomClassEnum.parlor.value or room.detail_type != 2:
                continue
            match_cnt = 0
            for match, _ in room.matched_obj:
                if match.room_type != MP.RoomClassEnum.parlor.value or match.detail_type != 2:
                    match_cnt += 1
            if match_cnt == 0:
                Dining_list.append(room)
        draw_params = {'color': kwargs['draw_img']['area_color_add'],
                       'fill': kwargs['draw_img']['area_color_add'],
                       'opacity': kwargs['draw_img']['area_opacity_add']}
        self.modPolygons.set_polygons(Dining_list, polygon_type='room', belong_to='B', **draw_params)

    def judge_is_valid(self, **kwargs):
        frame_a, frame_b = kwargs['frame_a'], kwargs['frame_b']
        cnt_a, cnt_b = 0, 0
        for _room in frame_a.room_list:
            if _room.room_type == MP.RoomClassEnum.parlor.value and _room.detail_type == 2:
                cnt_a = cnt_a + 1
        for _room in frame_b.room_list:
            if _room.room_type == MP.RoomClassEnum.parlor.value and _room.detail_type == 2:
                cnt_b = cnt_b + 1
        flag = False
        if cnt_a < cnt_b:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        self.collect_polygons(**kwargs)
        return self


class BedroomChangeLivingroom(IReformPointSecondHand):
    def __init__(self, **kwargs):
        super(BedroomChangeLivingroom, self).__init__(**kwargs)
        self.reform_name = ModIndex.BedroomChangeLivingroom.name
        self.reform_id = ModIndex.BedroomChangeLivingroom.value
        self.reform_spare_id = ModIndexSpare.BedroomChangeLivingroom.value
        self.modDocs = ErshouModDoc(self.reform_name, **kwargs)

    def collect_polygons(self, **kwargs):
        line_list = kwargs['related_room'].room_lines
        bcl_list = list()
        for _line in line_list:
            if _line.is_matched is False and _line.is_almost_matched is False and _line.length > 100 and not _line.edge_computed:
                bcl_list.append(_line)
        draw_params = {'color': kwargs['draw_img']['area_color_origin'],
                       'fill': kwargs['draw_img']['area_color_origin'],
                       'opacity': kwargs['draw_img']['area_opacity_origin']}
        self.modPolygons.set_polygons([kwargs['self_room']], polygon_type='room', belong_to='A', **draw_params)

        draw_params = {'color': kwargs['draw_img']['area_color_add'],
                       'fill': kwargs['draw_img']['area_color_add'],
                       'opacity': kwargs['draw_img']['area_opacity_add']}
        self.modPolygons.set_polygons([kwargs['related_room']], polygon_type='room', belong_to='B', **draw_params)

        draw_params = {'color': kwargs['draw_img']['line_color_changed'],
                       'fill': 'transparent',
                       'opacity': kwargs['draw_img']['line_opacity_changed']}
        self.modPolygons.set_polygons(bcl_list, polygon_type='line', belong_to='B', **draw_params)

    def judge_is_valid(self, **kwargs):
        flag = False
        self_room = kwargs['self_room']
        related_room = kwargs['related_room']
        if related_room.intersect_ratio > 0.70 or related_room.intersect_area / self_room.area_size > 0.9:
            flag = True
        return flag

    def solve(self, **kwargs):
        self_room = kwargs['self_room']
        room_same_class = kwargs['room_same_class']
        s2 = 0
        if room_same_class is not None:
            s2 = room_same_class.area_size
        for _related in self_room.passive:
            # 判断相关联的分间是否是客厅，检测卧室与客厅相关的改造点，改造后的户型至少要有一个卧室
            if s2 >= 0 and _related.detail_type == MP.RoomNameEnum.living_room.value and kwargs['frame_b'].structure[0] > 0:
                kwargs['related_room'] = _related
        if kwargs.get('related_room', None) is None:
            return None
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        self.collect_polygons(**kwargs)
        return self


class LivingroomChangeBedroom(IReformPointSecondHand):
    def __init__(self, **kwargs):
        super(LivingroomChangeBedroom, self).__init__(**kwargs)
        self.reform_name = ModIndex.LivingroomChangeBedroom.name
        self.reform_id = ModIndex.LivingroomChangeBedroom.value
        self.reform_spare_id = ModIndexSpare.LivingroomChangeBedroom.value
        self.modDocs = ErshouModDoc(self.reform_name, **kwargs)

    def collect_polygons(self, **kwargs):
        line_list = kwargs['related_room'].room_lines
        bcl_list = list()
        for _line in line_list:
            if _line.is_matched is False and _line.is_almost_matched is False and _line.length > 100 and not _line.edge_computed:
                bcl_list.append(_line)
        draw_params = {'color': kwargs['draw_img']['area_color_origin'],
                       'fill': kwargs['draw_img']['area_color_origin'],
                       'opacity': kwargs['draw_img']['area_opacity_origin']}
        self.modPolygons.set_polygons([kwargs['self_room']], polygon_type='room', belong_to='A', **draw_params)

        draw_params = {'color': kwargs['draw_img']['area_color_add'],
                       'fill': kwargs['draw_img']['area_color_add'],
                       'opacity': kwargs['draw_img']['area_opacity_add']}
        self.modPolygons.set_polygons([kwargs['related_room']], polygon_type='room', belong_to='B', **draw_params)

        draw_params = {'color': kwargs['draw_img']['line_color_changed'],
                       'fill': 'transparent',
                       'opacity': kwargs['draw_img']['line_opacity_changed']}
        self.modPolygons.set_polygons(bcl_list, polygon_type='line', belong_to='B', **draw_params)

    def judge_is_valid(self, **kwargs):
        flag = False
        self_room = kwargs['self_room']
        related_room = kwargs['related_room']
        if related_room.intersect_ratio > 0.70:
            flag = True
        if related_room.intersect_area / self_room.area_size > 0.9:
            flag = True
        return flag

    def solve(self, **kwargs):
        self_room = kwargs['self_room']
        room_same_class = kwargs['room_same_class']
        s2 = 0
        if room_same_class is not None:
            s2 = room_same_class.area_size
        for _related in self_room.passive:
            # 判断相关联的分间是否是卧室，检测客厅与卧室相关的改造点
            if s2 >= 0 and (
                    _related.detail_type == MP.RoomNameEnum.bedroom.value or _related.detail_type == MP.RoomNameEnum.mainroom.value or _related.detail_type == MP.RoomNameEnum.secondary_bedroom.value):
                kwargs['related_room'] = _related
        if kwargs.get('related_room', None) is None:
            return None
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        self.collect_polygons(**kwargs)
        return self


class ToiletDryWet(IReformPointSecondHand):
    def __init__(self, **kwargs):
        super(ToiletDryWet, self).__init__(**kwargs)
        self.reform_name = ModIndex.ToiletDryWet.name
        self.reform_id = ModIndex.ToiletDryWet.value
        self.reform_spare_id = ModIndexSpare.ToiletDryWet.value
        self.modDocs = ErshouModDoc(self.reform_name, **kwargs)

    def collect_polygons(self, **kwargs):
        line_list = kwargs['room_same_class'].room_lines
        drywet_list = list()
        for _line in line_list:
            if _line.is_matched is False and _line.is_almost_matched is False and _line.length > 100 and not _line.edge_computed:
                if _line.is_dangle:
                    drywet_list.append(_line)
        draw_params = {'color': kwargs['draw_img']['line_color_changed'],
                       'fill': 'transparent',
                       'opacity': kwargs['draw_img']['line_opacity_changed']}
        self.modPolygons.set_polygons(drywet_list, polygon_type='line', belong_to='B', **draw_params)

    def judge_is_valid(self, **kwargs):
        flag = False
        self_room = kwargs['self_room']
        room_same_class = kwargs['room_same_class']
        # 如果相交的面积占关联分间的比例没达到阈值，说明关联分间不完全从本分间分离出来，因此不算做增加分间
        if room_same_class is not None and room_same_class.intersect_ratio > 0.5 and \
                not self_room.judge_have_dangle_wall() and room_same_class.judge_have_dangle_wall():
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        self.collect_polygons(**kwargs)
        return self


class KitchenAddArea(IReformPointSecondHand):
    def __init__(self, **kwargs):
        super(KitchenAddArea, self).__init__(**kwargs)
        self.reform_name = ModIndex.KitchenAddArea.name
        self.reform_id = ModIndex.KitchenAddArea.value
        self.reform_spare_id = ModIndexSpare.KitchenAddArea.value
        self.modDocs = ErshouModDoc(self.reform_name, **kwargs)

    def collect_polygons(self, **kwargs):
        draw_params = {'color': kwargs['draw_img']['area_color_origin'],
                       'fill': kwargs['draw_img']['area_color_origin'],
                       'opacity': kwargs['draw_img']['area_opacity_origin']}
        self.modPolygons.set_polygons([kwargs['self_room']], polygon_type='room', belong_to='A', **draw_params)

        draw_params = {'color': kwargs['draw_img']['area_color_origin'],
                       'fill': kwargs['draw_img']['area_color_origin'],
                       'opacity': kwargs['draw_img']['area_opacity_origin']}
        self.modPolygons.set_polygons([kwargs['room_same_class']], polygon_type='room', belong_to='B', **draw_params)

    def judge_is_valid(self, **kwargs):
        flag = False
        self_room = kwargs['self_room']
        room_same_class = kwargs['room_same_class']
        if room_same_class is not None and \
                room_same_class.area_size / self_room.area_size > kwargs['reform_docs']['threshold_add_area_ratio'] and \
                room_same_class.area_size - self_room.area_size > 1:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        self.collect_polygons(**kwargs)
        return self


class ToiletAddArea(IReformPointSecondHand):
    def __init__(self, **kwargs):
        super(ToiletAddArea, self).__init__(**kwargs)
        self.reform_name = ModIndex.ToiletAddArea.name
        self.reform_id = ModIndex.ToiletAddArea.value
        self.reform_spare_id = ModIndexSpare.ToiletAddArea.value
        self.modDocs = ErshouModDoc(self.reform_name, **kwargs)

    def collect_polygons(self, **kwargs):
        draw_params = {'color': kwargs['draw_img']['area_color_origin'],
                       'fill': kwargs['draw_img']['area_color_origin'],
                       'opacity': kwargs['draw_img']['area_opacity_origin']}
        self.modPolygons.set_polygons([kwargs['self_room']], polygon_type='room', belong_to='A', **draw_params)

        draw_params = {'color': kwargs['draw_img']['area_color_origin'],
                       'fill': kwargs['draw_img']['area_color_origin'],
                       'opacity': kwargs['draw_img']['area_opacity_origin']}
        self.modPolygons.set_polygons([kwargs['room_same_class']], polygon_type='room', belong_to='B', **draw_params)

    def judge_is_valid(self, **kwargs):
        flag = False
        self_room = kwargs['self_room']
        room_same_class = kwargs['room_same_class']
        if room_same_class is not None and \
                room_same_class.area_size / self_room.area_size > kwargs['reform_docs']['threshold_add_area_ratio'] and \
                room_same_class.area_size - self_room.area_size > 1:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        self.collect_polygons(**kwargs)
        return self


class BedroomAddArea(IReformPointSecondHand):
    def __init__(self, **kwargs):
        super(BedroomAddArea, self).__init__(**kwargs)
        self.reform_name = ModIndex.BedroomAddArea.name
        self.reform_id = ModIndex.BedroomAddArea.value
        self.reform_spare_id = ModIndexSpare.BedroomAddArea.value
        self.modDocs = ErshouModDoc(self.reform_name, **kwargs)

    def collect_polygons(self, **kwargs):
        draw_params = {'color': kwargs['draw_img']['area_color_origin'],
                       'fill': kwargs['draw_img']['area_color_origin'],
                       'opacity': kwargs['draw_img']['area_opacity_origin']}
        self.modPolygons.set_polygons([kwargs['self_room']], polygon_type='room', belong_to='A', **draw_params)

        draw_params = {'color': kwargs['draw_img']['area_color_origin'],
                       'fill': kwargs['draw_img']['area_color_origin'],
                       'opacity': kwargs['draw_img']['area_opacity_origin']}
        self.modPolygons.set_polygons([kwargs['room_same_class']], polygon_type='room', belong_to='B', **draw_params)

    def judge_is_valid(self, **kwargs):
        flag = False
        self_room = kwargs['self_room']
        room_same_class = kwargs['room_same_class']
        if room_same_class is not None and \
                room_same_class.area_size / self_room.area_size > kwargs['reform_docs']['threshold_add_area_ratio'] and \
                room_same_class.area_size - self_room.area_size > 1:
            flag = True
        return flag

    def solve(self, **kwargs):
        flag = self.judge_is_valid(**kwargs)
        if flag is False:
            return None
        self.collect_polygons(**kwargs)
        return self


if __name__ == '__main__':
    pass
