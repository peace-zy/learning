# -*- coding:utf-8 -*-
# second hand modify eval
import copy
import json
import traceback
import pandas as pd
from collections import defaultdict

import frame_eval.frame_tag_lib.utils as tag_utils
import frame_mod_eval.utils.frame_diff as FD
from frame_mod_eval.entity import frame_diff_entity as ent
from frame_mod_eval.mod_lib.frame_entity import FrameObj
from frame_mod_eval.mod_ershou.room_diff_ershou import FrameDiffEval
from frame_mod_eval.mod_ershou.reform_point_interface_ershou import ReformPointSecondHandFactory


class ModNameSecondHand(object):
    name_dict = {
        0: '客厅改卧室', 1: '卧室拆分', 7: '卧室改客厅', 9: '扩大厨房',
        10: '干湿分离', 13: '增加卫生间', 14: '增加衣帽间', 15: '增加储物间', 16: '扩大卫生间', 17: '扩大卧室',
        20: '增加用餐区', 21: '增加书房'
    }


def generate_reform_json_without_http(frame_id1, frame_id2, frame_json_a, frame_json_b, features_a, features_b, **kwargs):
    # frame_diff里面计算两户型的分间、墙体、附件的diff主流程
    frame_a = ent.FrameStdVecObj(frame_json_a, frame_id=frame_id1)
    frame_b = ent.FrameStdVecObj(frame_json_b, frame_id=frame_id2)
    frame_a_2, frame_b_2, status_diff = FD.frame_diff(frame_a, frame_b)

    # 接收frame_diff的状态值，如果小于0则代表无法正常旋转，直接返回，否则就继续运行
    if status_diff < 0:
        return [None, status_diff, json.dumps(frame_a_2.dump([]))]

    try:
        if features_a == '' or features_b == '':
            raise Exception("frame features is an empty string")
    except Exception as e:
        print(repr(e))

    if not isinstance(features_a, dict):
        features_a = json.loads(features_a)
    if not isinstance(features_b, dict):
        features_b = json.loads(features_b)
    # 初始化原户型和改后户型的FrameObj对象，以及FrameDiffEval对象, 调用cal_related_room()函数计算吃掉对面的谁和被对面的谁吃掉
    params_dict = {'features': features_a, 'features_opposite': features_b, 'id_opposite': frame_id2}
    frame_a = FrameObj(frame_a_2, **params_dict)
    frame_a.cal_related_room(**kwargs['mod_eval_conf']['reform_docs'])
    params_dict = {'features': features_b, 'features_opposite': features_a, 'id_opposite': frame_id1}
    frame_b = FrameObj(frame_b_2, **params_dict)
    frame_b.cal_related_room(**kwargs['mod_eval_conf']['reform_docs'])

    kwargs['mod_eval_conf']['ReformPointFactory'] = ReformPointSecondHandFactory()

    frame_diff_obj = FrameDiffEval(frame_a, frame_b, **kwargs['mod_eval_conf'])
    frame_diff_obj.solve_reform_point()

    return [frame_diff_obj, frame_diff_obj.status, json.dumps(frame_a_2.dump([]))]


def mod_SecondHand_1th_period(row, **kwargs):
    frame_id, after_frame_id = str(row.frame_id), str(row.after_frame_id)
    before_frame_json, after_frame_json = row.before_frame_json, row.after_frame_json
    before_frame_featrue, after_frame_feature = row.before_frame_feature, row.after_frame_feature

    try:
        [frame_diff_obj, status, frame_json_after_a] = \
            generate_reform_json_without_http(frame_id, after_frame_id, before_frame_json, after_frame_json, before_frame_featrue, after_frame_feature, **kwargs)

        result_dict = dict()
        # 返回列表：包括改造前后id、打分、长短文案、是否有效、状态值
        result_dict['frame_id'] = frame_id
        result_dict['after_frame_id'] = after_frame_id
        result_dict['trans_frame_a_json'] = frame_json_after_a
        result_dict['status'] = status

        if status < 0:
            result_dict['is_valid'] = 0
            result_dict['detail_info'] = json.dumps(dict())
            result_dict['reform_theme'] = json.dumps(list())
        else:
            result_dict['is_valid'] = 1

            detail_info_dict = dict()
            detail_info_dict['frame_id_A'] = frame_id
            detail_info_dict['frame_id_B'] = after_frame_id
            detail_info_dict['pngSize'] = '1440x1080'
            detail_info_dict['report'] = list()

            head_img_dict = {'area_id': 'all',
                             'reform_id': frame_diff_obj.reform_value,
                             'reform_spare': frame_diff_obj.reform_spare_value,
                             'reform_class': 2,
                             'plan_idx': 0,
                             'polygons_A': frame_diff_obj.polygons_list_A,
                             'polygons_B': frame_diff_obj.polygons_list_B}
            detail_info_dict['report'].append(head_img_dict)

            for _reform_point in frame_diff_obj.reform_list:
                img_draw_dict = {'area_id': 'single',
                                 'reform_id': _reform_point.reform_id,
                                 'reform_spare': _reform_point.reform_spare_id,
                                 'reform_class': 2,
                                 'plan_idx': 0,
                                 'polygons_A': _reform_point.modPolygons.polygonsA,
                                 'polygons_B': _reform_point.modPolygons.polygonsB}
                detail_info_dict['report'].append(img_draw_dict)

            result_dict['detail_info'] = json.dumps(detail_info_dict)

            reform_theme = list()
            for _reform_point in frame_diff_obj.reform_list:
                _legend = [{"color": "#3072F6", "text": "改造空间"},
                           {"color": "#3AA000", "text": "新增空间"},
                           {"color": "#BA2727", "text": "改造墙体"}]
                theme = {'area_id': 'single',
                         'reform_id': _reform_point.reform_id,
                         'reform_spare': _reform_point.reform_spare_id,
                         'reform_class': 2,
                         'legend': _legend,
                         'value_docs': _reform_point.modDocs.value_docs,
                         'pos_docs': _reform_point.modDocs.pos_docs}
                reform_theme.append(theme)

            result_dict['reform_theme'] = json.dumps(reform_theme)

        result_list = list()
        result_list.append(result_dict['frame_id'])
        result_list.append(result_dict['after_frame_id'])
        result_list.append(result_dict['status'])
        result_list.append(result_dict['trans_frame_a_json'])
        result_list.append(row.score)
        result_dict['error_msg'] = ''
        result_list.append(result_dict['error_msg'])
        result_list.append(result_dict['reform_theme'])
        result_list.append(result_dict['detail_info'])
        result_list.append(result_dict['is_valid'])
        result_list.append(row.city_code)
    except Exception as e:
        status, trans_frame_a_json, score, error_msg, reform_theme, detail_info, is_valid = -2, '', 0.0, str(traceback.format_exc()), '', '', 0
        result_list = [frame_id, after_frame_id, status, trans_frame_a_json, score, error_msg, reform_theme, detail_info, is_valid, row.city_code]
    return result_list


def mod_SecondHand_2th_period(frame_id, after_frame_id, trans_frame_a_json, detail_info, **kwargs):
    detail_info_dict = json.loads(detail_info)
    detail_info_dict['trans_frame_a_json'] = trans_frame_a_json
    detail_info_res = json.dumps(detail_info_dict)
    return detail_info_res


def mod_SecondHand_3th_period(row, **kwargs):
    def collect_solve(frame_id, frame_group_df, city_code):
        # 二手户改优先级序列，列表内数字为改造点对应的二进制位数，后续二手改造点排序首先按照列表中的改造点顺序进行处理
        PRIORITY_LIST = [1, 0, 7, 13, 14, 15, 20, 21, 10, 17, 9, 16]
        result_json_dict = dict()
        reform_point_all = list()
        reform_theme_info = list()
        result_json_dict['origin_frame_id'] = frame_id
        result_json_dict['origin_img_url'] = dict()

        frame_info = defaultdict(dict)
        for index, row in frame_group_df.iterrows():
            frame_info[row['after_frame_id']]['score'] = row['score']
            frame_info[row['after_frame_id']]['reform_theme'] = row['reform_theme']
            frame_info[row['after_frame_id']]['city_code'] = row['city_code']
            if row['area_id'] == 'all' and row['before_flag'] == 1:
                result_json_dict['origin_img_url'] = json.loads(row['url'])
            if row['area_id'] == 'all':
                continue
            url_key = '|'.join(
                [row['area_id'], str(row['reform_id']), str(row['reform_class']), str(row['reform_spare']),
                 str(row['before_flag'])])
            url_key_list = frame_info[row['after_frame_id']].get('url_key_list', list())
            url_key_list.append(url_key)
            frame_info[row['after_frame_id']]['url_key_list'] = url_key_list
            frame_info[row['after_frame_id']][url_key] = json.loads(row['url'])

        frame_info_list = list()
        for _key, _value in frame_info.items():
            frame_info_list.append((_key, _value))

        mod_set = defaultdict(list)
        for after_frame_id, info_dict in frame_info_list:
            reform_theme = json.loads(info_dict['reform_theme'])
            for _theme in reform_theme:
                info_dict['after_frame_id'] = after_frame_id
                mod_set[_theme['reform_id']].append(
                    tuple([info_dict['score'], copy.deepcopy(info_dict), after_frame_id]))

        for key, value in mod_set.items():
            mod_set[key] = sorted(value, key=lambda x: x[0], reverse=True)

        reform_cnt = 0
        for _priority in PRIORITY_LIST:
            if (1 << _priority) not in mod_set:
                continue
            reform_cnt += 1
            if reform_cnt > 8:
                break
            _reform_point = mod_set[1 << _priority][0][1]
            theme_dict = json.loads(_reform_point['reform_theme'])
            theme = None
            for _tmp in theme_dict:
                if _tmp['reform_id'] == (1 << _priority):
                    theme = copy.deepcopy(_tmp)
            if theme is None:
                continue
            _reform_theme = dict()
            _reform_theme['theme_name'] = ModNameSecondHand.name_dict[_priority]
            _reform_theme['frame_id'] = _reform_point['after_frame_id']
            _reform_theme['area_id'] = theme['area_id']
            _reform_theme['reform_id'] = theme['reform_id']
            _reform_theme['score'] = _reform_point['score']
            _reform_theme['pos_docs'] = theme['pos_docs']
            _reform_theme['value_docs'] = theme['value_docs']
            _reform_theme['legend'] = theme['legend']

            url_key = '|'.join(
                [theme['area_id'], str(theme['reform_id']), str(theme['reform_class']), str(theme['reform_spare']),
                 '1'])
            _reform_theme['origin_img_url'] = _reform_point[url_key]
            url_key = '|'.join(
                [theme['area_id'], str(theme['reform_id']), str(theme['reform_class']), str(theme['reform_spare']),
                 '0'])
            _reform_theme['after_img_url'] = _reform_point[url_key]

            reform_theme_info.append(_reform_theme)

            reform_point_all.append(_reform_theme['theme_name'])

        result_json_dict['reform_point_all'] = reform_point_all
        result_json_dict['reform_theme_info'] = reform_theme_info
        return [frame_id, json.dumps(result_json_dict), city_code]

    frame_id = row.frame_id
    url_info = row.url_info
    report = dict()
    city_code = ''
    try:
        report['frame_id'] = frame_id
        df = pd.DataFrame(url_info)
        df.columns = ["after_frame_id", "score", "reform_theme", "city_code", "url", "area_id", "reform_id", "reform_class", "reform_spare", "before_flag"]
        city_code = df.iloc[0].city_code
        [frame_id, report, city_code] = collect_solve(frame_id, df, city_code)
        res = [frame_id, report, city_code, 1]
    except Exception as e:
        res = [frame_id, '', city_code, 0]
    return res


def collect_solve(frame_id, frame_group_df, city_code):
    PRIORITY_LIST = [1, 0, 7, 13, 14, 15, 20, 21, 10, 17, 9, 16]
    result_json_dict = dict()
    reform_point_all = list()
    reform_theme_info = list()
    result_json_dict['origin_frame_id'] = frame_id
    result_json_dict['origin_img_url'] = dict()

    frame_info = defaultdict(dict)
    for index, row in frame_group_df.iterrows():
        frame_info[row['after_frame_id']]['score'] = row['score']
        frame_info[row['after_frame_id']]['reform_theme'] = row['reform_theme']
        frame_info[row['after_frame_id']]['city_code'] = row['city_code']
        if row['area_id'] == 'all' and row['before_flag'] == 1:
            result_json_dict['origin_img_url'] = json.loads(row['url'])
        if row['area_id'] == 'all':
            continue
        url_key = '|'.join(
            [row['area_id'], str(row['reform_id']), str(row['reform_class']), str(row['reform_spare']),
             str(row['before_flag'])])
        url_key_list = frame_info[row['after_frame_id']].get('url_key_list', list())
        url_key_list.append(url_key)
        frame_info[row['after_frame_id']]['url_key_list'] = url_key_list
        frame_info[row['after_frame_id']][url_key] = json.loads(row['url'])

    frame_info_list = list()
    for _key, _value in frame_info.items():
        frame_info_list.append((_key, _value))

    mod_set = defaultdict(list)
    for after_frame_id, info_dict in frame_info_list:
        reform_theme = json.loads(info_dict['reform_theme'])
        for _theme in reform_theme:
            info_dict['after_frame_id'] = after_frame_id
            mod_set[_theme['reform_id']].append(
                tuple([info_dict['score'], copy.deepcopy(info_dict), after_frame_id]))

    for key, value in mod_set.items():
        mod_set[key] = sorted(value, key=lambda x: x[0], reverse=True)

    reform_cnt = 0
    for _priority in PRIORITY_LIST:
        if (1 << _priority) not in mod_set:
            continue
        reform_cnt += 1
        if reform_cnt > 8:
            break
        _reform_point = mod_set[1 << _priority][0][1]
        theme_dict = json.loads(_reform_point['reform_theme'])
        theme = None
        for _tmp in theme_dict:
            if _tmp['reform_id'] == (1 << _priority):
                theme = copy.deepcopy(_tmp)
        if theme is None:
            continue
        _reform_theme = dict()
        _reform_theme['theme_name'] = ModNameSecondHand.name_dict[_priority]
        _reform_theme['frame_id'] = _reform_point['after_frame_id']
        _reform_theme['area_id'] = theme['area_id']
        _reform_theme['reform_id'] = theme['reform_id']
        _reform_theme['score'] = _reform_point['score']
        _reform_theme['pos_docs'] = theme['pos_docs']
        _reform_theme['value_docs'] = theme['value_docs']
        _reform_theme['legend'] = theme['legend']

        url_key = '|'.join(
            [theme['area_id'], str(theme['reform_id']), str(theme['reform_class']), str(theme['reform_spare']),
             '1'])
        _reform_theme['origin_img_url'] = _reform_point[url_key]
        url_key = '|'.join(
            [theme['area_id'], str(theme['reform_id']), str(theme['reform_class']), str(theme['reform_spare']),
             '0'])
        _reform_theme['after_img_url'] = _reform_point[url_key]

        reform_theme_info.append(_reform_theme)

        reform_point_all.append(_reform_theme['theme_name'])

    result_json_dict['reform_point_all'] = reform_point_all
    result_json_dict['reform_theme_info'] = reform_theme_info
    return [frame_id, json.dumps(result_json_dict), city_code]


def test():
    import pandas as pd
    df = pd.read_csv('C:/Users/54692/Desktop/ershou_debug.csv', sep='\t')
    res = collect_solve('21410', df, '110000')
    result_dict = json.loads(res[1])
    pass


if __name__ == "__main__":
    test()
    pass
