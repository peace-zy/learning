# hdfs 上部署的python环境
HDFS_PYTHON_PATH="hdfs://ns-fed/user/strategy/yudonghai/python.tgz#python"
HDFS_PYTHON_PATH2="hdfs://ns-fed/user/strategy/zhuc/python27.zip#python"
# 本地python命令, 21.21上的配置
PYTHON_CMD="/home/work/zhucheng011/python/python27/bin/python2"
source bin/utils.sh

function sh_demo_content(){
    # 二手户型新demo页内容
    pt_date=$1

    spark-submit --py-files lib.zip \
    --conf spark.yarn.executor.memoryOverhead=7G \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    --conf spark.pyspark.driver.python=${PYTHON_CMD} \
    frame_mod_eval/secondhand_mod/demo_spark_main.py -pt_date  "$pt_date" \
    -config_file frame_mod_eval/secondhand_mod/demo_conf.yml
}


function RunFirstPeriod() {
    pt_date=$1
    city_code=$2

    spark-submit --py-files lib.zip \
                 --executor-memory 10G \
                 --master yarn \
                 --deploy-mode cluster \
                 --driver-memory 10G \
                 --conf spark.dynamicAllocation.maxExecutors=800 \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH2} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.sql.storeAssignmentPolicy="LEGACY" \
                 --conf spark.sql.hive.convertMetastoreOrc=false \
    frame_mod_eval/mod_period/period_1th/mod_1th_spark_main.py \
                 -pt_date "${pt_date}" \
                 -city_code "${city_code}" \
                 -config_file frame_mod_eval/mod_ershou/collect_mod_ershou_params.yml \
                 -sql_file frame_mod_eval/mod_ershou/collect_mod_ershou_data.sql \
                 -spark_config_key "secondhand_toC"
}


function RunThirdPeriod() {
    pt_date=$1
    city_code=$2

    spark-submit --py-files lib.zip \
                 --executor-memory 10G \
                 --conf spark.dynamicAllocation.maxExecutors=800 \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.pyspark.driver.python=${PYTHON_CMD}\
    frame_mod_eval/mod_period/period_3th/mod_3th_spark_main.py \
                 -pt_date "${pt_date}" \
                 -city_code "${city_code}" \
                 -config_file frame_mod_eval/mod_ershou/merge_mod_ershou_params.yml \
                 -sql_file frame_mod_eval/mod_ershou/merge_mod_ershou_data.sql \
                 -spark_config_key "secondhand_toC"
}


function main
{
    if [[ $# -lt 1 ]] ; then
        echo "error! lack <job_name>"
        usage
    fi
    job_name=$1
    echo "TASK: ${job_name}  "

    zip -q -r ./lib.zip ./*

    case ${job_name} in
        sh_demo_content )
        pt_data=$2
        sh_demo_content "$pt_data"
        ;;

        RunFirstPeriod )
        pt_data=$2
        city_code=$3
        RunFirstPeriod "$pt_data" "$city_code"
        ;;

        RunThirdPeriod )
        pt_data=$2
        city_code=$3
        RunThirdPeriod "$pt_data" "$city_code"
        ;;

        * )

        echo "error! invalid <job_name>"
        usage
        ;;

    esac
}

main $*