# -*- coding: utf-8 -*-
# ===================================
# @Author  : 杨东学
# @Email   : yangdongxue004@ke.com
# @Time    : 2021/11/2 18:21
# ===================================
import copy
import os
import sys
import json
import requests
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont
import cv2
import numpy as np
import pandas as pd
from collections import defaultdict

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../"))
sys.path.insert(0, os.getcwd())

import matplotlib.pyplot as plt
from lib import figures
from shapely.affinity import affine_transform

from lib import diff_util
from frame_mod_eval.entity import frame_diff_entity as ent
from frame_eval.frame_tag_lib import spark_main_feature
from frame_mod_eval.mod_lib.frame_entity import FrameObj
from frame_mod_eval.mod_ershou.room_diff_ershou import FrameDiffEval
import frame_mod_eval.mod_lib.mod_tools as MT
import frame_mod_eval.mod_lib.mod_params as MP
import frame_mod_eval.utils.frame_diff as FD
import frame_eval.frame_tag_lib.utils as tag_utils
from frame_mod_eval.mod_ershou.reform_point_interface_ershou import ReformPointSecondHandFactory
from multiprocessing import Process, Pool

name_dict = {
    'BedroomAddBedroom': '卧室拆分',
    'LivingroomChangeBedroom': '客厅改卧室',
    'BedroomChangeLivingroom': '卧室改客厅',
    'KitchenAddArea': '扩大厨房',
    'ToiletDryWet': '干湿分离',
    'AddBedroom': '增加居室',
    'SubBedroom': '减少居室',
    'AddToilet': '增加卫生间',
    'AddCloakroom': '增加衣帽间',
    'AddStorage': '增加储物间',
    'ToiletAddArea': '扩大卫生间',
    'BedroomAddArea': '扩大卧室',
    'SubToilet': '减少卫生间',
    'LivingroomAddLighting': '客厅增加采光',
    'AddDiningArea': '增加用餐区',
    'AddStudy': '增加书房',
    'KitchenChangeDoor': '改厨房门',
    'ToiletChangeDoor': '改卫生间门'
}


def display_frame_pairs(frame_a, frame_b, corner_desc=False, wall_desc=False, display=True, use_b_axis=False):
    """
    绘出户型对比图
    :param frame_a:
    :param frame_b:
    :param corner_desc: 是否显示点坐标
    :param wall_desc: 是否显示墙的长度
    :param display: True, 直接调试中显示; False, 保存到指定目录
    :param use_b_axis: 将frame_a的坐标系换算到b.
    :return:
    """
    size = ent.DiffFrame.DISPLAY_SIZE
    _margin = int(size * 0.01)
    fig = plt.figure(1, figsize=(12, 6), dpi=90)
    ax_a = fig.add_subplot(121)
    ax_a.axis('off')
    ax_b = fig.add_subplot(122)
    ax_b.axis('off')
    for _ax, _frame in zip([ax_a, ax_b], [frame_a, frame_b]):
        if use_b_axis:
            _matrix_1d = frame_b.get_trans_matrix_1d()
        else:
            _matrix_1d = _frame.get_trans_matrix_1d()
        # 绘制角点
        for _p in _frame.corner_list:
            _scale_p = affine_transform(_p.obj, _matrix_1d)
            figures.plot_coords(_ax, _scale_p, color=_p.color, zorder=_p.zorder, alpha=_p.alpha)
            if corner_desc:
                figures.add_origin(_ax, _scale_p, 'center', _p.name)
        # 绘制墙体
        for _w in _frame.wall_list:
            _scale_w = affine_transform(_w.obj, _matrix_1d)
            figures.plot_line(_ax, _scale_w, color=figures.BLUE, zorder=_w.zorder, linewidth=1, alpha=_w.alpha)
            figures.plot_line(_ax, _scale_w, color=_w.color, zorder=_w.zorder, linewidth=_w.linewidth, alpha=_w.alpha)
            if wall_desc:
                figures.add_origin(_ax, _scale_w, 'center', str(_w.length))
        # 绘制墙体附件
        for _w_i in _frame.wall_item_list:
            if not _w_i.is_matched:
                _scale_w_i = affine_transform(_w_i.obj, _matrix_1d)
                figures.plot_line(_ax, _scale_w_i, color=figures.BLUE, zorder=_w_i.zorder, linewidth=1, alpha=_w_i.alpha)
                figures.plot_line(_ax, _scale_w_i, color=_w_i.color, zorder=_w_i.zorder, linewidth=_w_i.linewidth, alpha=_w_i.alpha)
                if wall_desc:
                    figures.add_origin(_ax, _scale_w_i, 'center', str(_scale_w_i.length))
        figures.set_limits(_ax, -_margin, size + _margin, -_margin, size + _margin)
    if display:
        plt.show()
    else:
        # plt.savefig('data/mod_diff_res/img/{}-{}.jpg'.format(frame_a.frame_id, frame_b.frame_id), bbox_inches='tight', pad_inches=0)
        plt.savefig('data/reform_doc_pic/skeleton/{}-{}.jpg'.format(frame_a.frame_id, frame_b.frame_id), bbox_inches='tight', pad_inches=0)
        plt.close()


def cv2ImgAddText(img, text, left, top, textColor=(0, 255, 0), textSize=20):
    if (isinstance(img, np.ndarray)): #判断是否OpenCV图片类型
        img = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(img)
    fontText = ImageFont.truetype("D:/simsun.ttc", textSize, encoding="utf-8") #cp936
    draw.text((left, top), text, textColor, font=fontText)
    return cv2.cvtColor(np.asarray(img), cv2.COLOR_RGB2BGR)


def split_img(frame_id1, frame_id2, origin_img_dict, mod_img_dict, reform_list, **params):
    res = requests.get(origin_img_dict['bk.c_s'])
    img_bytes = res.content
    img_origin = Image.open(BytesIO(img_bytes))

    res = requests.get(mod_img_dict['bk.c_s'])
    img_bytes = res.content
    img_mod = Image.open(BytesIO(img_bytes))

    width = img_origin.size[0]
    height = img_origin.size[1]

    target = Image.new('RGB', (width * 2, height))
    target.paste(img_origin, (0, 0, width, height))
    target.paste(img_mod, (width, 0, 2*width, height))

    img = cv2.cvtColor(np.asarray(target), cv2.COLOR_RGB2BGR)
    pos = 30
    if len(reform_list) == 0:
        return
    for _reform_point in reform_list:
        title = '全局'
        if hasattr(_reform_point, 'room'):
            title = '{}'.format(_reform_point.room.name)
        sentence = '{}: {}'.format(title, name_dict[_reform_point.reform_name]).decode('utf-8')
        img = cv2ImgAddText(img, sentence, 600, pos, (0, 0, 0), 20)
        pos = pos + 40
    if 'second_score' not in params:
        print('saved {}'.format(params['save_path']))
        cv2.imwrite('{}/{}_{}.png'.format(params['save_path'], str(frame_id1), str(frame_id2)), img)
        return

    score_tuple1 = params['second_score'].get(frame_id1, tuple([-1, -1, -1, -1, -1]))
    score_tuple2 = params['second_score'].get(frame_id2, tuple([-1, -1, -1, -1, -1]))
    sentence = '总得分: {} : {}'.format(round(score_tuple1[0], 2), round(score_tuple2[0], 2)).decode('utf-8')
    pos = pos + 40
    img = cv2ImgAddText(img, sentence, 600, pos, (0, 0, 0), 20)

    sentence = '实用性得分: {} : {}'.format(round(score_tuple1[1], 2), round(score_tuple2[1], 2)).decode('utf-8')
    pos = pos + 40
    img = cv2ImgAddText(img, sentence, 600, pos, (0, 0, 0), 20)

    sentence = '便捷性得分: {} : {}'.format(round(score_tuple1[2], 2), round(score_tuple2[2], 2)).decode('utf-8')
    pos = pos + 40
    img = cv2ImgAddText(img, sentence, 600, pos, (0, 0, 0), 20)

    sentence = '空间利用得分: {} : {}'.format(round(score_tuple1[3], 2), round(score_tuple2[3], 2)).decode('utf-8')
    pos = pos + 40
    img = cv2ImgAddText(img, sentence, 600, pos, (0, 0, 0), 20)

    sentence = '舒适性得分: {} : {}'.format(round(score_tuple1[4], 2), round(score_tuple2[4], 2)).decode('utf-8')
    pos = pos + 40
    img = cv2ImgAddText(img, sentence, 600, pos, (0, 0, 0), 20)

    sentence = '私密性得分: {} : {}'.format(round(score_tuple1[5], 2), round(score_tuple2[5], 2)).decode('utf-8')
    pos = pos + 40
    img = cv2ImgAddText(img, sentence, 600, pos, (0, 0, 0), 20)
    cv2.imwrite('{}/{}_{}.png'.format(params['save_path'], str(frame_id1), str(frame_id2)), img)
    pass


def extract_basic_features(frame, config_params):
    frame_id, line = tag_utils.get_frame_vector(frame)
    frame, result = tag_utils.get_whole_frame_info(line, config_params["explain_params"], spark_main_feature.get_result, spark_main_feature.update_basic2frame)

    features = result[1]
    if features != "":
        features = json.loads(result[1])

    return features


def generate_reform_point(frame_id1, frame_id2, **kwargs):
    """
    :param frame_id1: 改前户型
    :param frame_id2: 改后户型
    :param params: 改造参数
    :return: [改造类对象、户型旋转状态status_diff、旋转后原户型Json]
    """
    [frame_json_a] = kwargs.get('frame_json_a', diff_util.download_frame_json([frame_id1], with_json=False))
    [frame_json_b] = kwargs.get('frame_json_b', diff_util.download_frame_json([frame_id2], with_json=False))
    features_a = kwargs.get('features_a', extract_basic_features(frame_id1, kwargs))
    features_b = kwargs.get('features_b', extract_basic_features(frame_id2, kwargs))

    # frame_diff里面计算两户型的分间、墙体、附件的diff主流程
    frame_a = ent.FrameStdVecObj(frame_json_a, frame_id=frame_id1)
    frame_b = ent.FrameStdVecObj(frame_json_b, frame_id=frame_id2)
    frame_a_2, frame_b_2, status_diff = FD.frame_diff(frame_a, frame_b)

    # 接收frame_diff的状态值，如果小于0则代表无法正常旋转，直接返回，否则就继续运行
    if status_diff < 0:
        return [None, status_diff, json.dumps(frame_a_2.dump([]))]

    try:
        if features_a == '' or features_b == '':
            raise Exception("frame features is an empty string")
    except Exception as e:
        print(repr(e))

    if not isinstance(features_a, dict):
        features_a = json.loads(features_a)
    if not isinstance(features_b, dict):
        features_b = json.loads(features_b)
    # 初始化原户型和改后户型的FrameObj对象，以及FrameDiffEval对象, 调用cal_related_room()函数计算吃掉对面的谁和被对面的谁吃掉
    params_dict = {'features': features_a, 'features_opposite': features_b, 'id_opposite': frame_id2}
    frame_a = FrameObj(frame_a_2, **params_dict)
    frame_a.cal_related_room(**kwargs['mod_eval_conf']['reform_docs'])
    params_dict = {'features': features_b, 'features_opposite': features_a, 'id_opposite': frame_id1}
    frame_b = FrameObj(frame_b_2, **params_dict)
    frame_b.cal_related_room(**kwargs['mod_eval_conf']['reform_docs'])

    kwargs['mod_eval_conf']['ReformPointFactory'] = ReformPointSecondHandFactory()

    frame_diff_obj = FrameDiffEval(frame_a, frame_b, **kwargs['mod_eval_conf'])
    frame_diff_obj.solve_reform_point()

    return [frame_diff_obj, frame_diff_obj.status, json.dumps(frame_a_2.dump([]))]


def case_study_batch():
    conf_params1, conf_params2 = dict(), dict()
    tag_utils.collect_conf(r"frame_mod_eval/mod_ershou/conf.yml", conf_params1)
    conf_params1 = conf_params1['params']
    tag_utils.collect_conf(r"frame_eval/frame_tag_lib/conf.yml", conf_params2)
    conf_params1['mod_eval_conf'].update(conf_params2)
    conf_params3 = dict()
    tag_utils.collect_conf(r"frame_mod_eval/mod_ershou/ershou_mod_doc.yml", conf_params3)
    conf_params1.update(conf_params3)

    df = pd.read_csv('C:/Users/54692/Desktop/reform_file/zhaozhao_online_frames_all_mod.tsv', sep='\t')
    for index, row in df.iterrows():
        try:
            conf_params1['yuangai'] = copy.deepcopy(row)
            [frame_diff_obj, status_diff, json_a_2] = generate_reform_point(str(int(row['frame_id'])), str(int(row['after_frame_id'])), **conf_params1)
            print(index, str(int(row['frame_id'])), str(int(row['after_frame_id'])))
            # 绘图
            frame_id1 = str(int(row['frame_id']))
            frame_id2 = str(int(row['after_frame_id']))
            [frame_json_b] = conf_params1.get('frame_json_b', diff_util.download_frame_json([frame_id2], with_json=False))

            frame_dict_a = json.loads(json_a_2)
            frame_dict_a['floorplans'][0]['polygons'] = frame_diff_obj.polygons_list_before

            frame_dict_b = json.loads(frame_json_b)
            frame_dict_b['floorplans'][0]['polygons'] = frame_diff_obj.polygons_list_after

            img_origin = MT.ImgTools.draw_json(frame_dict_a, show=False)
            data_result = MT.ImgTools.draw_json(frame_dict_b, show=False)
            save_path = "data/mod_ershou"
            conf_params1['save_path'] = save_path
            split_img(frame_id1, frame_id2, img_origin[0], data_result[0], frame_diff_obj.reform_list, **conf_params1)
        except Exception as e:
            print(index, e)


def case_study(frame_id1, frame_id2, show=False, **case_conf):

    [frame_diff_obj, status_diff, json_a_2] = generate_reform_point(frame_id1, frame_id2, **case_conf)
    # 绘图
    [frame_json_b] = case_conf.get('frame_json_b', diff_util.download_frame_json([frame_id2], with_json=False))

    frame_dict_a = json.loads(json_a_2)
    frame_dict_a['floorplans'][0]['polygons'] = frame_diff_obj.polygons_list_A

    frame_dict_b = json.loads(frame_json_b)
    frame_dict_b['floorplans'][0]['polygons'] = frame_diff_obj.polygons_list_B

    img_origin = MT.ImgTools.draw_json(frame_dict_a, show=show)
    data_result = MT.ImgTools.draw_json(frame_dict_b, show=show)
    save_path = "data/mod_ershou"
    case_conf['save_path'] = save_path
    split_img(frame_id1, frame_id2, img_origin[0], data_result[0], frame_diff_obj.reform_list, **case_conf)
    return frame_diff_obj.reform_list


def run_case_study(frame_id1, frame_id2):
    conf_params1, conf_params2 = dict(), dict()
    tag_utils.collect_conf(r"frame_mod_eval/mod_ershou/conf.yml", conf_params1)
    conf_params1 = conf_params1['params']
    tag_utils.collect_conf(r"frame_eval/frame_tag_lib/conf.yml", conf_params2)
    conf_params1.update(conf_params2)
    conf_params3 = dict()
    tag_utils.collect_conf(r"frame_mod_eval/mod_ershou/ershou_mod_doc.yml", conf_params3)
    conf_params1['mod_eval_conf'].update(conf_params3)
    rl = case_study(frame_id1, frame_id2, show=True, **conf_params1)
    return rl


def get_second_phase_score(row, **params):
    from lib import code_enum as ce
    from lib import eval_score

    score_config = params.get("score_config", None)

    base_point_value = "{}" if (row.eval_base_text is None or row.eval_base_text == '') else row.eval_base_text
    liner_info = "{}" if (row.eval_liner_text is None or row.eval_liner_text == '') else row.eval_liner_text
    base_vars = "{}" if (row.message_text is None or row.message_text == '') else row.message_text

    base_point_value_dict = json.loads(base_point_value, encoding="utf-8")
    liner_info_dict = json.loads(liner_info, encoding="utf-8")
    liner_point_value_dict = liner_info_dict.get(ce.EXPLAIN_POINT_VALUE_DICT, {})

    point_value_dict = base_point_value_dict
    for d in liner_point_value_dict:
        if d in point_value_dict:
            point_value_dict[d].update(liner_point_value_dict[d])
        else:
            point_value_dict[d] = liner_point_value_dict[d]

    # 打分
    score_result, add_vars_dict = eval_score.score_collect(row, point_value_dict, **score_config)
    return score_result


def multi_process():
    conf_params1, conf_params2 = dict(), dict()
    tag_utils.collect_conf(r"frame_mod_eval/mod_ershou/conf.yml", conf_params1)
    conf_params1 = conf_params1['params']
    tag_utils.collect_conf(r"frame_eval/frame_tag_lib/conf.yml", conf_params2)
    conf_params1.update(conf_params2)
    input_params = dict()
    conf_params1['input_params'] = input_params
    hu_work = 5
    pool = Pool(hu_work)
    async_res = list()

    df = pd.read_csv('C:/Users/54692/Desktop/reform_file/zhaozhao_online_frames_all_mod.tsv', sep='\t')
    for index, row in df.iterrows():
        frame_id1 = str(row.frame_id)
        frame_id2 = str(row.after_frame_id)
        reform = None
        try:
            reform = pool.apply_async(case_study, args=(frame_id1, frame_id2), kwds=conf_params1)
            print('第{}个运行完成，frame_id1={}，frame_id2={}'.format(index, frame_id1, frame_id2))
        except Exception as ex:
            print(frame_id1, frame_id2, list())
            continue
        async_res.append([frame_id1, frame_id2, reform])
    async_res2 = list()
    for _async in async_res:
        try:
            _reform_list = _async[2].get()
            async_res2.append([_async[0], _async[1], _reform_list])
        except Exception as ex:
            continue

    return async_res2


def main():
    reform_list = run_case_study('11000000684932', '1120033698109424')
    pass


if __name__ == '__main__':
    # 跑批量
    # case_study_batch()
    main()
    """
    fp = open(r"C:/Users/54692/Desktop/reform_file/15_reform_sta_zhaozhao.txt", "w+")
    fp.close()
    """
    pass
