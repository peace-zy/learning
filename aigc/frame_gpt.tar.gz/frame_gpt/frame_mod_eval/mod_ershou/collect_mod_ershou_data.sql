WITH group_base AS (
		SELECT *
		FROM data_mining.data_mining_frame_res_group_da
		WHERE pt = '{pt_date}000000'
			AND city_code IN ({city_code})
	),
	house_house AS (
	    SELECT *
		FROM dw.dw_house_house_frame_mapping_da
		WHERE pt = '{pt_date}000000'
			AND city_code IN ({city_code}) AND is_valid = 1
	),
	frame_housedel AS (
	    SELECT *
		FROM dw.dw_hdel_housedel_da
		WHERE pt = '{pt_date}000000' AND ke_show_status_code='120005001'
			AND city_code IN ({city_code})
	),
	tag_lib AS (
		SELECT *
		FROM data_mining.data_mining_frame_tag_lib_da
		WHERE pt = '{pt_date}000000'
			AND city_code IN ({city_code})
	),
	frame_score AS (
		SELECT *
		FROM data_mining.data_mining_frame_score
        WHERE pt = '{pt_date}000000'
			AND city_code IN ({city_code})
	),
	last_report AS (
		SELECT inn.frame_id, inn.after_frame_id, inn.status, inn.score, inn.reform_theme
	            , inn.detail_info, tra.trans_frame_a_json, inn.is_valid, inn.error_msg, inn.city_code
        FROM (
            SELECT *, ROW_NUMBER() OVER (PARTITION BY frame_id, after_frame_id ORDER BY status DESC) AS report_rn
            FROM data_mining.data_mining_mod_report_v2_secondhand_c_inter_da
            WHERE pt = '{last_pt}000000' and is_valid = 1
        ) inn
        LEFT JOIN data_mining.data_mining_mod_image_v2_da tra
            ON inn.frame_id = tra.frame_id and inn.after_frame_id = tra.after_frame_id
        WHERE report_rn = 1
	),
	v_frame AS (
		SELECT frame_id
			, reflect('java.net.URLDecoder', 'decode', trim(vector_value), 'UTF-8') AS json_str
		FROM (
			SELECT mapping.frame_id, vector_value
			FROM (
				SELECT id, vector_value
				FROM dw.dw_house_frame_vector_da
				WHERE pt = '{pt_date}000000'
					AND is_valid = 1
			) vector
				JOIN (
					SELECT image_id, entity_id AS frame_id, ROW_NUMBER() OVER (
                        PARTITION BY entity_id
                        ORDER BY
                            update_time DESC
                    ) AS rn
					FROM dw.dw_house_image_entity_mapping_da
					WHERE pt = '{pt_date}000000'
						AND image_type_code = 110028006
						AND entity_type_code = 110029002
						AND is_valid = 1
				) mapping
				ON mapping.image_id = vector.id
				JOIN (
					SELECT DISTINCT frame_id
					FROM dw.dw_house_house_frame_mapping_da
					WHERE pt = '{pt_date}000000'
						AND is_valid = 1
						AND city_code IN ({city_code})
				) h_m
				ON mapping.frame_id = h_m.frame_id
				where rn =1
		) aaa
	)
SELECT
    DISTINCT nvl(c.frame_id, a.frame_id) AS frame_id
    , nvl(c.after_frame_id, b.frame_id) AS after_frame_id
    , nvl(c.status, 3) AS status
    , nvl(c.reform_theme, '') AS reform_theme
	, nvl(c.detail_info, '') AS detail_info
	, nvl(c.trans_frame_a_json, '') AS trans_frame_a_json
	, nvl(c.is_valid, 1) AS is_valid
	, nvl(c.city_code, a.city_code) AS city_code
	, nvl(c.score, h.score) AS score
	, nvl(c.error_msg, '') AS error_msg
    , f.feature AS before_frame_feature
    , g.feature AS after_frame_feature
	, d.json_str AS before_frame_json
	, e.json_str AS after_frame_json
FROM group_base a
    JOIN house_house hh ON hh.frame_id=a.frame_id
    JOIN frame_housedel fh ON fh.house_id=hh.house_id
	FULL JOIN group_base b ON a.res_mod_rept_id = b.res_mod_rept_id
	LEFT JOIN last_report c ON a.frame_id = c.frame_id AND b.frame_id = c.after_frame_id
	LEFT JOIN v_frame d ON a.frame_id = d.frame_id
	LEFT JOIN v_frame e ON b.frame_id = e.frame_id
    JOIN tag_lib f ON a.frame_id = f.frame_id
	JOIN tag_lib g ON b.frame_id = g.frame_id
    LEFT JOIN frame_score h ON b.frame_id = h.frame_id
WHERE a.frame_id != b.frame_id