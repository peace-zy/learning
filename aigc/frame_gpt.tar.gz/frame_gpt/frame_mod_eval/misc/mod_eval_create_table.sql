CREATE TABLE IF NOT EXISTS `mod_image_v2_url_di`(
    `uid` VARCHAR(150) NOT NULL COMMENT 'frame_id+after_frame_id+area_id+reform_id+reform_class+reform_spare+before_flag',
    `frame_id` bigint NOT NULL COMMENT '原户型id',
    `after_frame_id` bigint NOT NULL COMMENT '改后户型id',
    `area_id` VARCHAR(100) NOT NULL COMMENT '分间id',
    `reform_id` int NOT NULL COMMENT '改造点编号',
    `reform_class` bigint NOT NULL DEFAULT '0' COMMENT '改造点对应类别',
    `reform_spare` bigint NOT NULL DEFAULT '0' COMMENT '改造点对应类别(备用)',
    `before_flag` int NOT NULL COMMENT '1:改造前,0:不是改造前',
    `url` VARCHAR(3000) NOT NULL COMMENT '改造图片URL',
    `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
    PRIMARY KEY (`uid`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

CREATE EXTERNAL TABLE `data_mining.data_mining_mod_image_v2_da`(
    `frame_id` string COMMENT '原户型代码',
    `after_frame_id` string COMMENT '改户型代码',
    `trans_frame_a_json` string COMMENT '原户型的变换户型json',
    `status` string COMMENT '状态',
    `is_valid` int COMMENT '是否有效'
) PARTITIONED BY (`pt` string) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\u0001' COLLECTION ITEMS TERMINATED BY '\u0002' MAP KEYS TERMINATED BY '\u0003' STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcInputFormat' OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat' LOCATION 'hdfs://ns-fed/user/bigdata/data_mining/data_mining_mod_image_v2_da' TBLPROPERTIES ('transient_lastDdlTime' = '1646460107');

CREATE EXTERNAL TABLE IF NOT EXISTS data_mining.data_mining_mod_report_v2_secondhand_c_inter_da (
    `frame_id` string COMMENT '原户型代码',
    `after_frame_id` string COMMENT '改户型代码',
    `status` string COMMENT '状态',
    `score` float COMMENT '改造打分',
    `short_report` string COMMENT '报告摘要',
    `report` string COMMENT '户型报告',
    `detail_info` string COMMENT '户型图示数据',
    `is_valid` int COMMENT '是否有效'
) partitioned by (pt string) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\u0001' COLLECTION ITEMS TERMINATED BY '\u0002' MAP KEYS TERMINATED BY '\u0003' STORED AS orc LOCATION 'hdfs://ns-fed/user/bigdata/data_mining/data_mining_mod_report_v2_secondhand_c_inter_da';

CREATE EXTERNAL TABLE IF NOT EXISTS data_mining.data_mining_mod_report_v2_deco_b_inter_da (
    `frame_id` string COMMENT '原户型代码',
    `after_frame_id` string COMMENT '改户型代码',
    `status` string COMMENT '状态',
    `score` float COMMENT '改造打分',
    `detail_info` string COMMENT '户型图示数据',
    `is_valid` int COMMENT '是否有效'
) partitioned by (pt string) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\u0001' COLLECTION ITEMS TERMINATED BY '\u0002' MAP KEYS TERMINATED BY '\u0003' STORED AS orc LOCATION 'hdfs://ns-fed/user/bigdata/data_mining/data_mining_mod_report_v2_deco_b_inter_da';

CREATE EXTERNAL TABLE IF NOT EXISTS data_mining.data_mining_mod_image_v2_url_di (
    `uid` string COMMENT '唯一编码',
    `frame_id` string COMMENT '原户型代码',
    `after_frame_id` string COMMENT '改户型代码',
    `area_id` string COMMENT '分间id',
    `reform_id` int COMMENT '改造点编号',
    `reform_class` BIGINT COMMENT '改造点对应类别',
    `reform_spare` BIGINT COMMENT '改造点对应类别(备用)',
    `before_flag` int COMMENT '改造点是否改造前(是: 1)',
    `url` string COMMENT '改造图片URL',
    `is_valid` int COMMENT '是否有效'
) partitioned by (pt string) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\u0001' COLLECTION ITEMS TERMINATED BY '\u0002' MAP KEYS TERMINATED BY '\u0003' STORED AS orc LOCATION 'hdfs://ns-fed/user/bigdata/data_mining/data_mining_mod_image_v2_url_di'