# -*- coding:utf-8 -*-
import copy
import json
import yaml
import logging
import sys
import os
import pandas as pd
import numpy as np
import argparse
import datetime
import math

reload(sys)
sys.setdefaultencoding("utf8")

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../"))
sys.path.insert(0, os.getcwd())

current_pt_date = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y%m%d")

parser = argparse.ArgumentParser(description='')
parser.add_argument("-env", default="online", help=" online or debug")
parser.add_argument("-pt_date", default=current_pt_date, help="")
parser.add_argument("-config_file", default="frame_mod_eval/secondhand_mod/demo_conf.yml", help="")

args = parser.parse_args()
if args.env == "debug":
    # spark 路径必须在import spark之前配置
    with open(r'./config/spark_debug.yml') as f:
        conf = yaml.load(f)
    spark_name = conf['local_spark_path']  # 注意spark路径
    sys.path.insert(0, os.path.join(spark_name, 'python'))
    sys.path.insert(0, os.path.join(spark_name, 'python/lib/py4j-0.10.4-src.zip'))

from lib import  spark_util_v2
from lib.file_util import get_file_stream
from lib import code_enum
from frame_eval.frame_tag_lib.utils import is_number


def label2tag(label_value):
    label_dict = code_enum.LABEL_DICT
    tags = []
    for k, v in label_dict.items():
        if v[0] & label_value != 0:
            tags.append(k)
    return tags


def get_eval_demo(row, **params):
    """得到解读demo页内容"""
    label_tags = label2tag(row.label_value)
    label_order = params['params']['label_order']
    all_space = [l[0] for l in label_order['space']]
    all_trans = [l[0] for l in label_order['trans']]
    all_usage = [l[0] for l in label_order['usage']]

    # 得到标签字典
    space_dict = {}
    for i in label_order['space']:
        space_dict[i[0]] = i[1]
    trans_dict = {}
    for i in label_order['trans']:
        trans_dict[i[0]] = i[1]
    usage_dict = {}
    for i in label_order['usage']:
        usage_dict[i[0]] = i[1]

    # 得到指定的户型标签
    space_label = list(set(label_tags).intersection(set(all_space)))
    trans_label = list(set(label_tags).intersection(set(all_trans)))
    usage_label = list(set(label_tags).intersection(set(all_usage)))

    # 标签排序
    space_idxs = sorted([all_space.index(l) for l in space_label])
    trans_idxs = sorted([all_trans.index(l) for l in trans_label])
    usage_idxs = sorted([all_usage.index(l) for l in usage_label])
    space_label = [all_space[i] for i in space_idxs]
    trans_label = [all_trans[i] for i in trans_idxs]
    usage_label = [all_usage[i] for i in usage_idxs]

    # 特殊处理采光通风，全南标签
    if 'all_south' in trans_label:
        new_trans_label = []
        for l in trans_label:
            if l == 'south_parlour': continue
            if l == 'south_bedroom': continue
            new_trans_label.append(l)
        trans_label = new_trans_label
    # 标签显示最多n个
    n = params['params']['max_label_num']
    space_label = space_label[0: n]
    trans_label = trans_label[0: n]
    usage_label = usage_label[0: n]

    eval_data = {
        "space_label": [space_dict[l] for l in space_label],
        "trans_label": [trans_dict[l] for l in trans_label],
        "usage_label": [usage_dict[l] for l in usage_label],
    }

    return eval_data


def get_mod_demo(row, **params):
    """得到户改demo内容，如果没有返回空"""
    if row.mod_report == '' or row.mod_report is None:
        return ''
    if is_number(row.mod_report):
        if math.isnan(row.mod_report):
            return ''

    mod_report = json.loads(row.mod_report)
    if len(mod_report['reform_point_all']) == 0:
        return ''
    head_info = {
        "reform_point_all": mod_report['reform_point_all'],
        "first_point_origin_img": mod_report['reform_theme_info'][0]['origin_img_url'],
        "first_point_after_img": mod_report['reform_theme_info'][0]['after_img_url'],
    }
    return head_info

def get_head_data(row, **params):
    """得到demo页头内容，例如头图、建筑面积等"""
    face_dict = params['params']['face_code']
    face_code = row.face_code
    if is_number(face_code):
        if math.isnan(float(face_code)):
            face_code = ''
    if face_code is None:
        face_code = ''
    face_code = face_code.split(',')
    face_str = u''
    if face_code != '':
        for idx, f in enumerate(face_code):
            if idx > 0:
                face_str += u'，'
            if f == '':
                continue
            face_str += face_dict[int(f)]
    try:
        message = json.loads(row.message)
        main_url = ''
        if message.get('main_img') is not None:
            main_url = message.get('main_img')
    except:
        main_url = ''
    room_str = '{shi}室{ting}厅{wei}卫'.format(**{
        "shi": row.shi, "ting": row.ting, "wei": row.wei})
    if row.floor_area is None:
        floor_area = ''
    else:
        floor_area = float(row.floor_area)
    head_info = {
        "floor_area": floor_area,
        "main_url": main_url,
        "face_code": face_str,
        "score": row.score,
        "resblock_name": row.resblock_name,
        "room": room_str,
    }
    return head_info


def get_new_short_row(row, **params):
    result = [
        row.frame_id,
        row.city_code,
        row.state,
        row.shi,
        row.ting,
        row.chu,
        row.wei,
        row.label_value,
        row.score,
        row.space_score,
        row.trans_score,
        row.usage_score,
        row.abstract,
    ]
    head = get_head_data(row, **params)
    eval_demo = get_eval_demo(row, **params)
    mod_demo = get_mod_demo(row, **params)
    new_info = {
        "head": head,
        "eval": eval_demo,
        "reform": mod_demo,
    }
    result.append(json.dumps(new_info))
    return result


class DemoContent(spark_util_v2.SparkLogic):
    def logic_func(self, spark_driver, raw_df_dict, **params):
        frame_demo_df = raw_df_dict["demo_info"]
        result_rdd = frame_demo_df.rdd.map(lambda row: get_new_short_row(row, **params))
        result_df = spark_driver.rdd_2_df(result_rdd)
        save_dict = {
            "api_frame_eval_short_da": result_df
        }

        return save_dict


def main(pt_date, config_file, debug=False):
    f = get_file_stream(config_file)
    conf = yaml.load(f)

    spark_config_key = "demo_content"
    spark_params = conf.get(spark_config_key, None)

    spark_params["sql_params"]["sql_vars"] = {
        "pt_date": pt_date,
    }
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_class"] = DemoContent
    # 存储pt
    for save_name in spark_params["save_params"]:
        spark_params["save_params"][save_name]["partition_params"] = {
            "pt": "{}000000".format(pt_date)
        }

    spark_driver = spark_util_v2.SparkSqlDriver(debug=debug, **spark_params)
    spark_driver.run()
    return spark_driver


def test():
    df = pd.read_csv(r'D:\demo_info.tsv', sep='\t')
    f = get_file_stream("frame_mod_eval/secondhand_mod/demo_conf.yml")
    conf = yaml.load(f)

    spark_config_key = "demo_content"
    spark_params = conf.get(spark_config_key, None)

    for idx, row in df.iterrows():
        print(idx)
        res = get_new_short_row(row, **spark_params['logic_params']['logic_function_params'])
        tmp = 0

if __name__ == "__main__":
    # test()

    if args.env == "debug":
        spark_driver = main(args.pt_date, args.config_file, debug=True)
    else:
        main(args.pt_date, args.config_file)