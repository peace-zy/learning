WITH demo_basic AS (
		SELECT *
		FROM api.api_frame_eval_short_da
		WHERE pt = '{pt_date}000000'
	),
    frame_eval AS (
        SELECT *
        FROM data_mining.data_mining_frame_eval_da
        WHERE pt = '{pt_date}000000' AND message != ''
    ),
	frame_housedel_id AS (
		SELECT a.frame_id, a.house_id, b.face_code, b.floor_area, b.typing_time, b.resblock_name
		FROM (
			SELECT frame_id, house_id
			FROM dw.dw_house_house_frame_mapping_da
			WHERE pt = '{pt_date}000000'
		) a
			JOIN (
				SELECT house_id, face_code, floor_area, resblock_name, typing_time
				FROM dw.dw_allinfo_housedel_da
				WHERE pt = '{pt_date}000000'
			) b
			ON a.house_id = b.house_id
	),
	frame_housedel_id2 AS (
		SELECT frame_id, house_id, face_code, floor_area, resblock_name
        FROM (
            SELECT frame_id, house_id, face_code, floor_area, resblock_name
                , ROW_NUMBER() OVER (PARTITION BY frame_housedel_id.frame_id ORDER BY typing_time desc) AS rn
            FROM frame_housedel_id
            ) a
        WHERE a.rn = 1
    ),
    frame_moe_eval AS (
        SELECT frame_id, report
        FROM data_mining.data_mining_second_hand_mod_report_docs_da
        WHERE pt = '{pt_date}000000'
    )
SELECT DISTINCT a.frame_id, a.city_code, a.state, a.shi, a.ting
	, a.chu, a.wei, a.label_value, a.score, a.space_score
	, a.trans_score, a.usage_score, a.abstract
    , b.face_code, b.floor_area, b.resblock_name
    , c.message
    , NVL(d.report, '') AS mod_report
FROM demo_basic a
	LEFT JOIN frame_housedel_id2 b ON a.frame_id = b.frame_id
    LEFT JOIN frame_eval c ON a.frame_id = c.frame_id
    LEFT JOIN frame_moe_eval d ON a.frame_id = d.frame_id