SELECT *
FROM data_mining.data_mining_second_hand_mod_report_docs_da
WHERE pt = '{last_pt_date}000000'
