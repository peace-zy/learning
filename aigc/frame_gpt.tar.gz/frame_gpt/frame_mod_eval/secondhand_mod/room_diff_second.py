# -*- coding: utf-8 -*-
"""
二手户改长短文案与md生成模块
Authors: yangdongxue004@ke.com
Date:    2021/9/22
"""
import json
import urlparse

from frame_mod_eval.utils.markdownIO import MarkDownIO
from frame_mod_eval.utils.reform_func_tools import DocsGenerator, ImgTools, OtherTools
import frame_mod_eval.utils.room_doc_param as RDP

REFORM_NAME_MAP = {
    '客厅改卧室': '客厅-客厅改卧室',
    '卧室拆分': '卧室-增加卧室',
    '卧室增加卫生间': '卧室-增加卫生间',
    '卧室增加衣帽间': '卧室-增加衣帽间',
    '卧室改客厅': '卧室-卧室改客厅',
    '客厅增加储物间': '客厅-增加衣帽间',
    '扩大厨房': '厨房-扩大面积',
    '干湿分离': '卫生间-干湿分离'
}


class FrameDiffEval(object):
    """
    两户型对比类
    """
    def __init__(self, frame_a, frame_b):
        """
        :param frame_a: 原户型 DiffFrame
        :param frame_b: 改户型 DiffFrame
        """
        # 原户型和改户型
        self.frame_a = frame_a
        self.frame_b = frame_b
        self.reform_polygons_origin_lines_total = list()
        self.reform_polygons_after_lines_total = list()
        # 要进行解析的分间列表，由于目前是分析原户型的所有分间改造点，所以存储的是frame_a的所有分间通过room_factory模块生成的类
        self.room_list = []
        # 短文案与长文案json
        self.short_json = ''
        self.long_json = ''
        # 改造状态，0:未改造(无diff), 1:已改造(有diff)&有检测点覆盖, 2: 已改造(有diff)&未覆盖检测点. (负值在计算diff的时候已经返回)
        self.status = 0

    def judge_diff(self):
        """
        遍历两户型的墙体和附件，判断两户型是否完全相同.
        :param:
        :return: 返回布尔值，True表示有diff不完全相同，False表示没有diff完全相同
        """
        # 遍历frame_a的墙体
        for _room in self.frame_a.room_list:
            for _line in _room.room_lines:
                if not _line.is_matched:
                    return True
                # 遍历墙体上的附件
                for _line_item in _line.line_items:
                    if not _line_item.is_matched:
                        return True
        # 遍历frame_b的墙体
        for _room in self.frame_b.room_list:
            for _line in _room.room_lines:
                if not _line.is_matched:
                    return True
                # 遍历墙体上的附件
                for _line_item in _line.line_items:
                    if not _line_item.is_matched:
                        return True
        return False

    def constrained_condition(self):
        """
        一些特殊的约束条件，户型总面积过大则不考虑
        :return: 布尔变量，代表是否满足约束条件
        """
        if self.frame_a.area_size > 180 or self.frame_a.structure[0] > 5 or self.frame_b.structure[0] > 5:
            return False
        return True

    def generate_docs_without_http(self, reform_conf):
        """
        遍历原户型所有分间，分别计算每个分间的检测点，并存储在分间对象的reform_point_list列表内，同时计算状态变量status
        :param reform_conf: 固定文案的字典
        :return: 不重复的检测点列表, 列表检测点按照权重从大到小排序
        """
        # 将原户型的所有分间排序
        self.room_list = sorted(self.frame_a.room_list, key=lambda x: (x.spatial_weight, x.total_weight_of_reform), reverse=True)
        reform_point = list()
        # 检查两户型是否完全相同
        have_diff = self.judge_diff()
        # 计算是否满足自定义的约束条件
        constrained_satisfy = self.constrained_condition()
        # 如果不满足约束条件直接返回，这里记录一下状态变量status
        if have_diff and not constrained_satisfy:
            self.status = 1
            return reform_point
        elif not have_diff and not constrained_satisfy:
            self.status = 0
            return reform_point
        # 遍历原分间
        for _room in self.room_list:
            _room.reform_conf = reform_conf['compare_docs']
            _params = dict()
            _params['counter_frame'] = self.frame_a
            _params.update(reform_conf['mod_eval_conf'])
            _room.personalized_label(_params)

            if len(_room.reform_point_list) == 0:
                continue
            self.reform_polygons_origin_lines_total = self.reform_polygons_origin_lines_total + _room.reform_polygons_origin_lines
            self.reform_polygons_after_lines_total = self.reform_polygons_after_lines_total + _room.reform_polygons_after_lines
            # 将检测点前标记分间名称
            for _docs in _room.reform_point_list:
                if len(_docs.reform_doc_tmp) == 0:
                    continue
                reform_point.append((_docs.reform_doc_tmp['reform_name'], _docs.reform_point_weight))

        self.frame_b_url_dict = self.reform_polygons_after_lines_total
        # 获取所有不重复的改造点标签
        reform_point = list(set(reform_point))
        # 计算状态
        if have_diff:
            if len(reform_point) > 0:
                self.status = 2
            else:
                self.status = 1
        # 将不重复的改造点按照改造点权重排序
        reform_point = sorted(reform_point, key=lambda x: x[-1], reverse=True)
        self.room_list = sorted(self.frame_a.room_list, key=lambda x: (x.spatial_weight, x.total_weight_of_reform), reverse=True)
        return reform_point

    def generate_json_without_http(self, reform_conf):
        """
        生成改造点的长文案和短文案json
        :param reform_conf: 固定文案的字典
        :return: 列表，[短文案json, 长文案json, 状态值status]
        """
        # 生成分间改造点文案
        reform_point = self.generate_docs_without_http(reform_conf)
        # 短文案json，包括frame_origin、frame_aft、reform_point_all三个字典
        frame_origin = {"frame_id": self.frame_a.frame_id, "area_size": self.frame_a.area_size,
                        "bedroom": self.frame_a.structure[0], "parlor": self.frame_a.structure[1],
                        "kitchen": self.frame_a.structure[2], "toilet": self.frame_a.structure[3],
                        "img_url": self.reform_polygons_origin_lines_total}
        frame_after = {"frame_id": self.frame_b.frame_id, "area_size": self.frame_b.area_size,
                       "bedroom": self.frame_b.structure[0], "parlor": self.frame_b.structure[1],
                       "kitchen": self.frame_b.structure[2], "toilet": self.frame_b.structure[3],
                       "img_url": self.reform_polygons_after_lines_total}
        reform_point_all = []
        for _point in reform_point:
            _dict_tmp = {"reform_name": _point[0], "reform_id": RDP.REFORM_POINT_INDEX[REFORM_NAME_MAP[_point[0]]], "reform_weight": _point[1]}
            reform_point_all.append(_dict_tmp)
        short_dict = {"frame_origin": frame_origin, "frame_after": frame_after, "reform_point_all": reform_point_all}
        self.short_json = json.dumps(short_dict)

        # 长文案json，包括frame_origin、frame_after、reform_point_all、room_list四个字典
        long_dict = short_dict
        reform_room_list = list()
        for _room in self.room_list:
            if len(_room.reform_point_list) == 0:
                continue
            room_tmp = dict()
            room_tmp['room_name'] = _room.name
            room_tmp['belong_to_ori'] = 1
            room_tmp['space_weight'] = _room.spatial_weight
            room_tmp['area_id'] = _room.uid
            _reform_point = list()
            for _cnt, _docs in enumerate(_room.reform_point_list):
                _docs_dict = dict()
                _docs_dict["reform_name"] = _docs.reform_doc_tmp['reform_name']
                _docs_dict["reform_id"] = RDP.REFORM_POINT_INDEX[REFORM_NAME_MAP[_docs.reform_doc_tmp['reform_name']]]
                _docs_dict["reform_weight"] = _docs.reform_doc_tmp['reform_point_weight']
                _docs_dict["pos_docs"] = _docs.reform_doc_tmp['pos_docs']
                _docs_dict["value_docs"] = _docs.reform_doc_tmp['value_docs']

                _legend = list()
                _polygons_total = _docs.reform_polygons_origin + _docs.reform_polygons_after
                color_conf = reform_conf['mod_eval_conf']['draw_img']
                flag1 = 0
                flag2 = 0
                flag3 = 0
                for _polygon in _polygons_total:
                    _fill = _polygon['fill']
                    _stroke = _polygon['stroke']
                    if _fill == color_conf['area_color_origin'] and flag1 == 0:
                        _l = {'text': "改造空间", 'color': _fill}
                        _legend.append(_l)
                        flag1 = 1
                    if _fill == color_conf['area_color_add'] and flag2 == 0:
                        _l = {'text': "新增空间", 'color': _fill}
                        _legend.append(_l)
                        flag2 = 1
                    if _stroke == color_conf['line_color_changed'] and flag3 == 0:
                        _l = {'text': "改造墙体", 'color': _stroke}
                        _legend.append(_l)
                        flag3 = 1
                _docs_dict["legend"] = _legend

                _reform_point.append(_docs_dict)
            room_tmp["reform_point"] = _reform_point
            reform_room_list.append(room_tmp)
        long_dict["room_list"] = reform_room_list
        self.long_json = json.dumps(long_dict)
        return [self.short_json, self.long_json, self.status]

