# -*- coding:utf-8 -*-
# second hand modify eval
import copy
import json
import yaml
import logging
import sys
import os
import pandas as pd
import numpy as np
import argparse
import datetime
import traceback
from collections import defaultdict
import math
import time

reload(sys)
sys.setdefaultencoding("utf8")

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../"))
sys.path.insert(0, os.getcwd())

current_pt_date = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y%m%d")

parser = argparse.ArgumentParser(description='')
parser.add_argument("-env", default="online", help=" online or debug")
parser.add_argument("-pt_date", default=current_pt_date, help="")
parser.add_argument("-cluster_last_pt", default="20210911")
parser.add_argument("-config_file", default="frame_mod_eval/secondhand_mod/conf.yml", help="")

args = parser.parse_args()
if args.env == "debug":
    # spark 路径必须在import spark之前配置
    with open(r'./config/spark_debug.yml') as f:
        conf = yaml.load(f)
    spark_name = conf['local_spark_path']  # 注意spark路径
    sys.path.insert(0, os.path.join(spark_name, 'python'))
    sys.path.insert(0, os.path.join(spark_name, 'python/lib/py4j-0.10.4-src.zip'))

import pyspark.sql.functions as functions
from lib import spark_util_v2
from lib.file_util import get_file_stream
import frame_eval.frame_tag_lib.utils as tag_utils
# from frame_mod_eval.utils import reform_doc
from frame_mod_eval.secondhand_mod import reform_doc_second


def single_frame_runner(row, **params):
    """
    处理行数据，返回一阶段的表数据，report的格式类似装修户改
    :param row: 行数据
    :param params: 字典参数
    :return: [frame_id, after_frame_id, report, error_msg, is_valid, score, status]
    """
    _frame_id, after_frame_id = str(row.frame_id), str(row.after_frame_id)
    before_frame_json, after_frame_json = row.before_frame_json, row.after_frame_json
    before_frame_featrue, after_frame_feature = row.before_frame_feature, row.after_frame_feature
    score = row.score
    try:
        logging.debug('FRAME ID {}-{} START. '.format(_frame_id, after_frame_id))
        _ret_dict = reform_doc_second.reform_docs_main_without_http(_frame_id, after_frame_id,
                                                                 before_frame_json, after_frame_json,
                                                                 before_frame_featrue, after_frame_feature,
                                                                 score, params['params'])
        result = [_ret_dict['frame_id'], _ret_dict['after_frame_id'], _ret_dict['report'],
                  '', _ret_dict['is_valid'], _ret_dict['score'], _ret_dict['status'], row.city_code]
        return result
    except:
        error_msg = 'FRAME ID {}-{} ERROR: {}'.format(_frame_id, after_frame_id, str(traceback.format_exc()).replace('\n', '|'))
        logging.fatal(error_msg)
        is_valid = 0
        status = -2
        default_score = 0.0

        return [_frame_id, after_frame_id, '', str(traceback.format_exc()), is_valid,
                default_score, status, row.city_code]


def collect_solve(frame_id, frame_group_df, city_code):
    result_json_dict = dict()
    reform_point_all = list()
    reform_theme_info = list()
    result_json_dict['origin_frame_id'] = frame_id
    result_json_dict['origin_img_url'] = dict()
    mod_set = defaultdict(list)
    for index, row in frame_group_df.iterrows():
        if row['error_msg'] != '' or row['status'] < 2:
            continue
        # debug 模式下，'' 为nan
        # if math.isnan(row['error_msg']) is False:
        #    continue
        report_dict = json.loads(row['report'])
        for _room in report_dict['room_list']:
            for _reform_point in _room['reform_point']:
                mod_set[_reform_point['reform_id']].append(tuple([row['score'], _reform_point, row['after_frame_id'], _room['area_id']]))
    for key, value in mod_set.items():
        mod_set[key] = sorted(value, key=lambda x: x[0], reverse=True)
    reform_cnt = 0
    for _priority in reform_doc_second.REFORM_PRIORITY:
        if _priority not in mod_set:
            continue
        reform_cnt += 1
        if reform_cnt > 8:
            break
        _reform_point = mod_set[_priority][0][1]
        _reform_theme = dict()
        _reform_theme['theme_name'] = _reform_point['reform_name']
        _reform_theme['frame_id'] = mod_set[_priority][0][2]
        _reform_theme['area_id'] = mod_set[_priority][0][3]
        _reform_theme['reform_id'] = _reform_point['reform_id']
        _reform_theme['score'] = mod_set[_priority][0][0]
        _reform_theme['pos_docs'] = _reform_point['pos_docs']
        _reform_theme['value_docs'] = _reform_point['value_docs']
        _reform_theme['legend'] = _reform_point['legend']
        _reform_theme['origin_img_url'] = dict()
        _reform_theme['after_img_url'] = dict()

        reform_theme_info.append(_reform_theme)

        reform_point_all.append(_reform_point['reform_name'])
    result_json_dict['reform_point_all'] = reform_point_all
    result_json_dict['reform_theme_info'] = reform_theme_info
    return [[frame_id, json.dumps(result_json_dict), city_code]]


def collect_information(frame_id, frame_group, column_names):
    """
    :param frame_id: 原户型id
    :param frame_group: frame_id对应的多个改造户型
    :param column_names: group列名
    :return:
    """
    df = spark_util_v2.spark_group2pandas_df(frame_group, column_names)
    res = list()
    city_code = ''
    try:
        city_code = df.iloc[0]['city_code']
        res = collect_solve(frame_id, df, city_code)
    except Exception as e:
        res = [[frame_id, str(traceback.format_exc()), city_code]]

    return res


def doc_url_match(row, **params):
    frame_id = row['frame_id']
    report = row['report']
    column_names = ['after_frame_id', 'area_id', 'before_flag', 'reform_id', 'url']
    url_info_df = spark_util_v2.spark_group2pandas_df(row['url_info'], column_names)

    report_dict = json.loads(report)
    search_dict = dict()
    for idx, _Row in url_info_df.iterrows():
        url = json.loads(_Row['url'])[0]
        if url["code"] != "OK":
            continue
        img_url = url["data"]["v1"]["urls"]
        after_frame_id = str(_Row['after_frame_id'])
        area_id = _Row['area_id']
        reform_id = str(_Row['reform_id'])
        before_flag = str(_Row['before_flag'])
        search_dict[(after_frame_id, area_id, reform_id, before_flag)] = img_url

    id_tmp = 0
    reform_have_img = list()
    reform_point_have_img = list()
    for _reform_theme_info in report_dict["reform_theme_info"]:
        key_before = (_reform_theme_info['frame_id'], _reform_theme_info['area_id'], str(_reform_theme_info['reform_id']), str(1))
        key_after = (_reform_theme_info['frame_id'], _reform_theme_info['area_id'], str(_reform_theme_info['reform_id']), str(0))
        if key_before in search_dict:
            _reform_theme_info['origin_img_url'] = search_dict[key_before]
        if key_after in search_dict:
            _reform_theme_info['after_img_url'] = search_dict[key_after]
        if key_before in search_dict and key_after in search_dict:
            reform_have_img.append(copy.deepcopy(_reform_theme_info))
            reform_point_have_img.append(copy.deepcopy(_reform_theme_info['theme_name']))
            id_tmp = str(_reform_theme_info['frame_id'])

    report_dict["reform_theme_info"] = reform_have_img
    report_dict["reform_point_all"] = reform_point_have_img

    key_before = (id_tmp, "all", '-1', '1')
    url_flag = False
    if key_before in search_dict:
        report_dict['origin_img_url'] = search_dict[key_before]
        url_flag = True
    report_complete = json.dumps(report_dict)
    if url_flag:
        return [[frame_id, report_complete, row['city_code'], 1]]
    else:
        return [[frame_id, report_complete, row['city_code'], 0]]


class SecondHouseModEval(spark_util_v2.SparkLogic):
    def logic_func(self, spark_driver, raw_df_dict, **params):
        # 运行完第一阶段sql后得到的frame_pair_info数据
        frame_pair_info = raw_df_dict['frame_pair_info'].cache()
        # 获取增量
        frame_pair_info_delta = frame_pair_info.filter("report='none'")
        # 获取存量
        frame_pair_info_last = frame_pair_info.filter("report!='none'").\
            select(["frame_id", "after_frame_id", "report", "error_msg", "is_valid",
                    "score", "status", "city_code"])
        delta_cnt = frame_pair_info_delta.count()
        # logging.info("increasment data size: " + str(frame_pair_info_delta.count()))
        # logging.info("stock data size: " + str(frame_pair_info_last.count()))

        if delta_cnt == 0:
            last_report_df = raw_df_dict['frame_pair_info']
            save_dict = {
                "second_hand_mod_report_inter": frame_pair_info,
                "second_hand_mod_report_docs": last_report_df,
            }
            return save_dict

        first_period_rdd = frame_pair_info_delta.repartition(800).rdd.map(lambda row: single_frame_runner(row, **params))
        first_period_df = spark_driver.rdd_2_df(first_period_rdd)

        names0 = ['frame_id', 'after_frame_id', 'report', 'error_msg', 'is_valid',
                  'score', 'status', "city_code"]
        first_period_df_with_name = first_period_df.toDF(*names0)
        column_names = first_period_df_with_name.schema.names

        # 合并一阶段的存量和增量
        frame_pair_info_union = frame_pair_info_last.select(names0).union(first_period_df)

        # 将第一阶段数据按照frame_id聚合成一组
        frame_group = frame_pair_info_union.rdd.groupBy(lambda row: row['frame_id'])
        doc_final_without_url_rdd = frame_group.flatMap(lambda row: collect_information(row[0], row[1], column_names))
        doc_final_without_url_df = spark_driver.rdd_2_df(doc_final_without_url_rdd)
        names = ['frame_id', 'report', 'city_code']

        doc_final_without_url_df_with_name = doc_final_without_url_df.toDF(*names)

        url_data = raw_df_dict['doc_find_url']
        solve_url_table = url_data.groupby(['frame_id']).agg(functions.collect_list(
            functions.struct('after_frame_id', 'area_id', 'before_flag', 'reform_id', 'url')).alias('url_info'))

        doc_final_with_url = doc_final_without_url_df_with_name.join(solve_url_table, solve_url_table.frame_id == doc_final_without_url_df_with_name.frame_id). \
            select(doc_final_without_url_df_with_name.frame_id, doc_final_without_url_df_with_name.report, solve_url_table.url_info, doc_final_without_url_df_with_name.city_code)
        doc_final_rdd = doc_final_with_url.rdd.flatMap(lambda row: doc_url_match(row, **params))

        doc_final_df = spark_driver.rdd_2_df(doc_final_rdd)

        save_dict = {
            "second_hand_mod_report_inter": frame_pair_info_union,
            "second_hand_mod_report_docs": doc_final_df,
        }
        return save_dict


def main(pt_date, cluster_last_pt, config_file, debug=False):
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')

    f = get_file_stream(config_file)
    conf = yaml.load(f)

    spark_config_key = "second_hand_mod_eval"
    spark_params = conf.get(spark_config_key, None)

    cur_date = datetime.datetime.strptime(pt_date, "%Y%m%d")
    pre_date = cur_date - datetime.timedelta(days=1)
    last_pt_date = pre_date.strftime("%Y%m%d")

    city_code = conf["params"]["city_code"]
    spark_params["sql_params"]["sql_vars"] = {
        "pt_date": pt_date,
        "last_pt_date": last_pt_date,
        "city_code": city_code,
        "cluster_last_pt": cluster_last_pt,
    }
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_class"] = SecondHouseModEval
    logic_function_params = spark_params["logic_params"]['logic_function_params']
    conf_params2 = dict()
    conf_params3 = dict()
    tag_utils.collect_conf_on_spark(r"frame_eval/frame_tag_lib/conf.yml", conf_params2)
    tag_utils.collect_conf_on_spark(r"frame_mod_eval/reform_docs.yml", conf_params3)
    logic_function_params['params'].update(conf_params2)
    logic_function_params['params'].update(conf_params3)
    spark_params["logic_params"]['logic_function_params'] = logic_function_params
    # 存储pt
    for save_name in spark_params["save_params"]:
        spark_params["save_params"][save_name]["partition_params"] = {
            "pt": "{}000000".format(pt_date)
        }
    spark_driver = spark_util_v2.SparkSqlDriver(debug=debug, **spark_params)
    spark_driver.run()
    return spark_driver


def test():
    """
    frame_pair_info_df = pd.read_csv(r'D:/frame_pair_info.tsv', sep='\t')
    config_file = "frame_mod_eval/secondhand_mod/conf.yml"
    f = get_file_stream(config_file)
    conf = yaml.load(f)

    spark_config_key = "second_hand_mod_eval"
    spark_params = conf.get(spark_config_key, None)

    spark_params["sql_params"]["sql_vars"] = {
        "pt_date": 000000,
        "city_code": 110000,
        "cluster_last_pt": 100009,
    }
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_class"] = SecondHouseModEval
    logic_function_params = spark_params["logic_params"]['logic_function_params']
    conf_params2 = dict()
    conf_params3 = dict()
    tag_utils.collect_conf_on_spark(r"frame_eval/frame_tag_lib/conf.yml", conf_params2)
    tag_utils.collect_conf_on_spark(r"frame_mod_eval/reform_docs.yml", conf_params3)
    logic_function_params['params'].update(conf_params2)
    logic_function_params['params'].update(conf_params3)
    spark_params["logic_params"]['logic_function_params'] = logic_function_params


    result = single_frame_runner(frame_pair_info_df.iloc[5], **logic_function_params)
    """
    hang_data = pd.read_csv(r'D:/debug.tsv', sep='\t')
    names0 = ['frame_id', 'after_frame_id', 'report', 'error_msg', 'is_valid',
              'score', 'status', "city_code"]
    res = collect_information('11000000522561', hang_data, names0)
    # url_info_df = pd.read_csv(r'D:/url_info_df.tsv', sep='\t')
    # names = ['frame_id', 'after_frame_id', 'report', 'error_msg', 'is_valid', 'score', 'status']
    # select_frame(url_info_df, names)
    # row = hang_data.iloc[0]
    # result = doc_url_match(row)

    # frame_group_df = pd.read_csv(r'D:\frame_group.tsv', sep='\t')
    # frame_id = 16000003334747
    # names = ['frame_id', 'after_frame_id', 'report',
    #          'error_msg', 'is_valid', 'score', 'status', 'city_code']
    # "second_hand_mod_report_docs": doc_final_df,
    # df_select = select_frame(frame_group_df, names)
    # res = collect_solve(frame_id, df_select)
    return None


if __name__ == "__main__":
    # test(); exit()
    if args.env == "debug":
        spark_driver = main(args.pt_date, args.cluster_last_pt, args.config_file, debug=True)
    else:
        main(args.pt_date, args.cluster_last_pt, args.config_file)
