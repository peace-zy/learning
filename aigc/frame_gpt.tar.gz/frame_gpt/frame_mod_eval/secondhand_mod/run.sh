# hdfs 上部署的python环境
HDFS_PYTHON_PATH="hdfs://ns-fed/user/strategy/yudonghai/python.tgz#python"
# 本地python命令, 21.21上的配置
PYTHON_CMD="/home/work/zhucheng011/python/python27/bin/python2"
source bin/utils.sh

function second_hand_mod_eval() {
    pt_date=$1
    cluster_last_pt=$(get_nearst_pt data_mining.data_mining_frame_cluster_v3_da)

    spark-submit --py-files lib.zip \
    --executor-memory 10G \
    --conf spark.dynamicAllocation.maxExecutors=800 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.pyspark.driver.python=${PYTHON_CMD}\
    frame_mod_eval/secondhand_mod/sh_mod_eval_spark.py \
    -cluster_last_pt ${cluster_last_pt} \
    -pt_date ${pt_date}
}

function sh_demo_content(){
    # 二手户型新demo页内容
    pt_date=$1

    spark-submit --py-files lib.zip \
    --conf spark.yarn.executor.memoryOverhead=7G \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    --conf spark.pyspark.driver.python=${PYTHON_CMD} \
    frame_mod_eval/secondhand_mod/demo_spark_main.py -pt_date  "$pt_date" \
    -config_file frame_mod_eval/secondhand_mod/demo_conf.yml
}

function main
{
    if [[ $# -lt 1 ]] ; then
        echo "error! lack <job_name>"
        usage
    fi
    job_name=$1
    echo "TASK: ${job_name}  "

    zip -q -r ./lib.zip ./*

    case ${job_name} in
        sh_demo_content )
        pt_data=$2
        sh_demo_content "$pt_data"
        ;;

        second_hand_mod_eval )
        pt_date=$2
        second_hand_mod_eval "$pt_date"
        ;;

        * )

        echo "error! invalid <job_name>"
        usage
        ;;

    esac
}

main $*