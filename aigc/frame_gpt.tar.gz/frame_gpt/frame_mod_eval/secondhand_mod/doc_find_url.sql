SELECT * FROM dw.dw_plat_frame_miner_reform_url_da
WHERE pt='{pt_date}000000'
-- AND frame_id in (16000003334747)
-- AND frame_id in (11000018535755, 1120038923770662, 1114916480675921)
