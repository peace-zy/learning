# -*- coding: utf-8 -*-
"""
二手改造点检测接口模块
Authors: yangdongxue004@ke.com
Date:    2021/9/22
"""
from abc import ABCMeta, abstractmethod

import frame_mod_eval.utils.room_doc_param as RDP
import lib.diff_util as DU
from frame_mod_eval.utils.reform_func_tools import DocsGenerator, ImgTools, OtherTools, NameTools


class IReformPointCheck(object):
    __metaclass__ = ABCMeta

    def __init__(self, room, **kwargs):
        self.room = room
        self.reform_doc_tmp = dict()
        self.reform_polygons_origin = list()
        self.reform_polygons_after = list()
        self.reform_polygons_origin_lines = list()
        self.reform_polygons_after_lines = list()
        self.params_dict = kwargs
        self.reform_point_weight = 0

    def check(self, related_room, room_same_class):
        flag = self.judge_is_valid(related_room, room_same_class)
        if not flag:
            return False
        self.reform_doc_tmp['reform_name'] = self.reform_point_label()
        # 搜索原分间需要绘制的墙体和附件
        self.find_change_origin(self.params_dict['draw_img'], room_list=[self.room])
        # 搜索关联分间需要绘制的墙体和附件
        self.find_change_after(self.params_dict['draw_img'], room_list=[room_same_class, related_room], line_list=related_room.room_lines, lineitem_list=related_room.room_lines)
        self.reform_doc_tmp['reform_point_weight'] = self.get_reform_point_weight(related_room)
        self.reform_point_weight = self.reform_doc_tmp['reform_point_weight']
        self.reform_doc_tmp['pos_docs'] = self.get_pos_docs()
        self.reform_doc_tmp['value_docs'] = self.get_value_docs()
        return True

    def judge_is_valid(self, related_room, room_same_class):
        return True

    @abstractmethod
    def reform_point_label(self):
        pass

    def find_change_origin(self, draw_img_config, room_list=[], line_list=[], lineitem_list=[]):
        """
        搜索改造前户型需要上色的分间、墙体和附件
        :param draw_img_config: 绘图参数字典
        :param room_list: 改造分间列表
        :param line_list: 改造墙体列表
        :param lineitem_list: 改造墙体附件列表
        :return: 绘图的多边形列表、未匹配到的墙体列表、未匹配到的墙体带有的所有附件序号集合、未匹配的墙体附件、未匹配到的墙体附件序号集合
        """
        # 1.面
        poly_tmp = ImgTools.get_draw_poly([room_list[0]], obj_type='room', color=draw_img_config['area_color_origin'], fill=draw_img_config['area_color_origin'], opacity=draw_img_config['area_opacity_origin'])
        self.reform_polygons_origin = self.reform_polygons_origin + poly_tmp
        # 2.线
        lines_notmatch = []
        line_type = set()
        # 3.附件
        lineitems_notmatch = []
        return lines_notmatch, line_type

    def find_change_after(self, draw_img_config, room_list=[], line_list=[], lineitem_list=[]):
        """
        搜索改后户型需要上色的分间、墙体和附件
        :param draw_img_config: 绘图参数字典
        :param room_list: 改造分间列表
        :param line_list: 改造墙体列表
        :param lineitem_list: 改造墙体附件列表
        :return: 绘图的多边形列表、未匹配到的墙体列表、未匹配到的墙体带有的所有附件序号集合、未匹配的墙体附件、未匹配到的墙体附件序号集合
        """
        # 1.面
        # 原分间多边形
        if room_list[0] is not None:
            poly_tmp = ImgTools.get_draw_poly([room_list[0]], obj_type='room', color=draw_img_config['area_color_origin'], fill=draw_img_config['area_color_origin'], opacity=draw_img_config['area_opacity_origin'])
            self.reform_polygons_after = self.reform_polygons_after + poly_tmp
        # 如果有新增加的分间则返回需要涂色的多边形
        if room_list[1] is not None:
            poly_tmp = ImgTools.get_draw_poly([room_list[1]], obj_type='room', color=draw_img_config['area_color_add'], fill=draw_img_config['area_color_add'], opacity=draw_img_config['area_opacity_add'])
            self.reform_polygons_after = self.reform_polygons_after + poly_tmp

        # 2.线
        lines_notmatch = []
        line_type = set()
        for _line in line_list:
            if _line.is_matched is False and _line.is_almost_matched is False and _line.length > 100 and not _line.edge_computed:
                lines_notmatch.append(_line)
                for _lineitem in _line.line_items:
                    line_type.add(_lineitem.type)
        poly_tmp = ImgTools.get_draw_poly(lines_notmatch, obj_type='line', color=draw_img_config['line_color_changed'], fill="transparent", opacity=draw_img_config['line_opacity_changed'])
        self.reform_polygons_after = self.reform_polygons_after + poly_tmp
        self.reform_polygons_after_lines = self.reform_polygons_after_lines + poly_tmp

        # 3.附件
        lineitems_notmatch = []
        for _line in lineitem_list:
            for _line_item in _line.line_items:
                if _line_item.is_matched is False:
                    lineitems_notmatch.append(_line_item)
        poly_tmp = ImgTools.get_draw_poly(lineitems_notmatch, obj_type='lineitem', color=draw_img_config['lineitem_color_changed'], fill="transparent", opacity=draw_img_config['lineitem_opacity_changed'])
        self.reform_polygons_after = self.reform_polygons_after + poly_tmp
        self.reform_polygons_after_lines = self.reform_polygons_after_lines + poly_tmp
        return lines_notmatch, line_type

    @abstractmethod
    def get_reform_point_weight(self, related_room):
        return 0

    @abstractmethod
    def get_pos_docs(self):
        pass

    @abstractmethod
    def get_value_docs(self):
        pass


class BedroomAddBedroom(IReformPointCheck):
    def __init__(self, room, **kwargs):
        super(BedroomAddBedroom, self).__init__(room, **kwargs)

    def judge_is_valid(self, related_room, room_same_class):
        if related_room.intersect_ratio < self.params_dict['reform_docs']['threshold_partition'] and related_room.intersect_abs_area > self.params_dict['reform_docs']['threshold_partition_abs']:
            return False
        return True

    def reform_point_label(self):
        return '卧室拆分'

    def get_reform_point_weight(self, related_room):
        return DocsGenerator.generate_reform_conf_docs(self.room.reform_conf, [self.room.english_name, related_room.english_name, RDP.ADD_NUM_KEY, RDP.WEIGHT_KEY])

    def get_pos_docs(self):
        _str_in = "{}增加墙体,增加居室个数;".format(self.room.name)
        return _str_in

    def get_value_docs(self):
        _str_in = "增加卧室数量满足更多的家人一起生活;"
        return _str_in


class BedroomAddToilet(IReformPointCheck):
    def __init__(self, room, **kwargs):
        super(BedroomAddToilet, self).__init__(room, **kwargs)

    def judge_is_valid(self, related_room, room_same_class):
        # 如果相交的面积占关联分间的比例没达到阈值,说明关联分间不完全从本分间分离出来,因此不算做增加分间
        if related_room.intersect_ratio < self.params_dict['reform_docs']['threshold_partition'] and related_room.intersect_abs_area > self.params_dict['reform_docs']['threshold_partition_abs']:
            return False
        if not OtherTools.judge_toilet_rational(related_room, related_room.line_id_dict):
            return False
        return True

    def reform_point_label(self):
        return '卧室增加卫生间'

    def get_reform_point_weight(self, related_room):
        return DocsGenerator.generate_reform_conf_docs(self.room.reform_conf, [self.room.english_name, related_room.english_name, RDP.ADD_NUM_KEY, RDP.WEIGHT_KEY])

    def get_pos_docs(self):
        _str_in = "{}增加卫生间;".format(self.room.name)
        return _str_in

    def get_value_docs(self):
        _str_in = "增加了个人私密性,减少了使用卫生间冲突的情况;"
        return _str_in


class BedroomAddCloakroom(IReformPointCheck):
    def __init__(self, room, **kwargs):
        super(BedroomAddCloakroom, self).__init__(room, **kwargs)

    def judge_is_valid(self, related_room, room_same_class):
        if DU.is_false_diff_room(related_room, self.params_dict['counter_frame']):
            return False
        # 如果相交的面积占关联分间的比例没达到阈值,说明关联分间不完全从本分间分离出来,因此不算做增加分间
        if related_room.intersect_ratio < self.params_dict['reform_docs']['threshold_partition'] and related_room.intersect_abs_area > self.params_dict['reform_docs']['threshold_partition_abs']:
            return False
        return True

    def reform_point_label(self):
        return '卧室增加衣帽间'

    def get_reform_point_weight(self, related_room):
        return DocsGenerator.generate_reform_conf_docs(self.room.reform_conf, [self.room.english_name, related_room.english_name, RDP.ADD_NUM_KEY, RDP.WEIGHT_KEY])

    def get_pos_docs(self):
        _str_in = "{}增加衣帽间;".format(self.room.name)
        return _str_in

    def get_value_docs(self):
        _str_in = "衣帽间为卧室增加了存储空间,让衣物收纳清晰有条理;"
        return _str_in


class BedroomChangeLivingroom(IReformPointCheck):
    def __init__(self, room, **kwargs):
        super(BedroomChangeLivingroom, self).__init__(room, **kwargs)

    def judge_is_valid(self, related_room, room_same_class):
        # 如果相交的面积占关联分间的比例没达到阈值,说明关联分间不完全从本分间分离出来,因此不算做增加分间
        if related_room.intersect_ratio < self.params_dict['reform_docs']['threshold_partition'] and related_room.intersect_abs_area > self.params_dict['reform_docs']['threshold_partition_abs']:
            return False
        return True

    def reform_point_label(self):
        return '卧室改客厅'

    def get_reform_point_weight(self, related_room):
        return DocsGenerator.generate_reform_conf_docs(self.room.reform_conf, [self.room.english_name, related_room.english_name, RDP.CHANGE_KEY, RDP.WEIGHT_KEY])

    def get_pos_docs(self):
        _str_in = "{}墙体改动,扩大客厅面积".format(self.room.name)
        return _str_in

    def get_value_docs(self):
        _str_in = "增加客厅面积,生活空间更加宽敞;"
        return _str_in


class LivingroomAddBedroom(IReformPointCheck):
    def __init__(self, room, **kwargs):
        super(LivingroomAddBedroom, self).__init__(room, **kwargs)

    def judge_is_valid(self, related_room, room_same_class):
        # 如果相交的面积占关联分间的比例没达到阈值,说明关联分间不完全从本分间分离出来,因此不算做增加分间
        if related_room.intersect_ratio < self.params_dict['reform_docs']['threshold_partition'] and related_room.intersect_abs_area > self.params_dict['reform_docs']['threshold_partition_abs']:
            return False
        return True

    def reform_point_label(self):
        return '客厅改卧室'

    def get_reform_point_weight(self, related_room):
        return DocsGenerator.generate_reform_conf_docs(self.room.reform_conf, [self.room.english_name, related_room.english_name, RDP.ADD_NUM_KEY, RDP.WEIGHT_KEY])

    def get_pos_docs(self):
        _str_in = "客厅改动墙体,改造为{}向卧室;".format(self.room.name)
        return _str_in

    def get_value_docs(self):
        _str_in = "增加卧室数量满足更多的人一起生活;"
        return _str_in


class LivingroomAddCloakroom(IReformPointCheck):
    def __init__(self, room, **kwargs):
        super(LivingroomAddCloakroom, self).__init__(room, **kwargs)

    def judge_is_valid(self, related_room, room_same_class):
        if DU.is_false_diff_room(related_room, self.params_dict['counter_frame']):
            return False
            # 如果相交的面积占关联分间的比例没达到阈值,说明关联分间不完全从本分间分离出来,因此不算做增加分间
        if related_room.intersect_ratio < self.params_dict['reform_docs']['threshold_partition'] and related_room.intersect_abs_area > self.params_dict['reform_docs']['threshold_partition_abs']:
            return False
        return True

    def reform_point_label(self):
        return '客厅增加储物间'

    def get_reform_point_weight(self, related_room):
        return DocsGenerator.generate_reform_conf_docs(self.room.reform_conf, [self.room.english_name, related_room.english_name, RDP.ADD_NUM_KEY, RDP.WEIGHT_KEY])

    def get_pos_docs(self):
        _str_in = "客厅增加储物间"
        return _str_in

    def get_value_docs(self):
        _str_in = "客厅的储物空间增加,有助于保持生活环境整洁;"
        return _str_in


class KitchenAddArea(IReformPointCheck):
    def __init__(self, room, **kwargs):
        super(KitchenAddArea, self).__init__(room, **kwargs)

    def judge_is_valid(self, related_room, room_same_class):
        if room_same_class.intersect_area / self.room.area_size < self.params_dict['reform_docs']['threshold_partition'] or abs(room_same_class.intersect_area - self.room.area_size) > self.params_dict['reform_docs']['threshold_partition_abs']:
            return False
        return True

    def reform_point_label(self):
        return '扩大厨房'

    def get_reform_point_weight(self, related_room):
        return DocsGenerator.generate_reform_conf_docs(self.room.reform_conf, [self.room.english_name, related_room.english_name, RDP.ADD_AREA_KEY, RDP.WEIGHT_KEY])

    def get_pos_docs(self):
        _str_in = "{}的墙体移动,增加厨房面积;".format(self.room.name)
        return _str_in

    def get_value_docs(self):
        _str_in = "厨房空间增加,可以容纳多人共同家务;"
        return _str_in


class ToiletDryWet(IReformPointCheck):
    def __init__(self, room, **kwargs):
        super(ToiletDryWet, self).__init__(room, **kwargs)

    def judge_is_valid(self, related_room, room_same_class):
        if room_same_class.intersect_ratio < 0.5:
            return False
        return True

    def reform_point_label(self):
        return '干湿分离'

    def get_reform_point_weight(self, related_room):
        return DocsGenerator.generate_reform_conf_docs(self.room.reform_conf, [self.room.english_name, related_room.english_name, RDP.DRY_WET_KEY, RDP.WEIGHT_KEY])

    def get_pos_docs(self):
        _str_in = "卫生间{}设置干区和湿区".format(self.room.name)
        return _str_in

    def get_value_docs(self):
        _str_in = "卫生间干区不受湿区影响,可保持场地干燥卫生,干区湿区可同时使用提高使用效率;"
        return _str_in


if __name__ == '__main__':
    pass
