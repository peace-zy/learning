# -*- coding: utf-8 -*-
"""
二手分间与户型类对象生成模块
Authors: yangdongxue004@ke.com
Date:    2021/8/15
"""
import copy

import frame_mod_eval.entity.frame_diff_entity as FDE
import frame_mod_eval.utils.room_doc_param as RDP
import lib.diff_util as DU
from frame_mod_eval.utils.reform_func_tools import DocsGenerator, ImgTools, OtherTools, NameTools
import reform_point_interface_second as RPI


class RoomFactory(object):
    @staticmethod
    def room_obj(room, params_dict):
        # 如果是卧室、主卧、次卧则创建BedRoom类对象
        if room.detail_type == RDP.RoomNameEnum.bedroom.value or room.detail_type == RDP.RoomNameEnum.mainroom or room.detail_type == RDP.RoomNameEnum.secondary_bedroom:
            return BedRoom(room, params_dict)
        # 如果是厨房则创建Kitchen类对象
        if room.detail_type == RDP.RoomNameEnum.kitchen.value:
            return Kitchen(room, params_dict)
        if room.detail_type == RDP.RoomNameEnum.toilet.value:
            return Toilet(room, params_dict)
        # 如果是厅那么创建LivingRoom类对象
        if room.room_type == RDP.RoomClassEnum.parlor.value:
            return LivingRoom(room, params_dict)
        # 其余情况创建父类RoomObj对象
        return RoomObj(room, params_dict)


class FrameObj(FDE.FrameStdVecObj):
    _FEATURES_KEY = 'features'
    _FEATURES_OPPOSITE_KEY = 'features_opposite'
    _ID_OPPOSITE_KEY = 'id_opposite'
    _AREA_ID_KEY = 'area_id'
    _WIDTH_KEY = 'width'
    _DEPTH_KEY = 'depth'
    _FACE_KEY = 'face'
    _AREA_SIZE = 'area_size'
    _EXTRA_FEATURES = 'extra_features'
    _ROOM_LABEL = 'cluster_room_label'

    def __init__(self, frame, params_dict):
        """
        户型扩展类.
        :param frame: 通过frame_diff模块下frame_diff方法返回的户型对象
        :param params_dict: 参数字典，传入户型特征、标签、格局等变量
        :return:
        """
        self.__dict__.update(frame.__dict__)
        # 户型面积, 该面积被标准化为平方米为单位
        self.area_size = OtherTools.cal_std_area(frame.area_size)
        # 调用户型解读的case_study得到的户型特征字典，features_opposite为对比的户型特征字典, id_opposite为对比户型的frame_id
        self.features = params_dict[self._FEATURES_KEY]
        self.features_opposite = params_dict[self._FEATURES_OPPOSITE_KEY]
        self.id_opposite = params_dict[self._ID_OPPOSITE_KEY]
        # 长度为4的列表，代表该户型室厅厨卫数量
        self.structure = [self.features[u'whole'][0][u'shi'], self.features[u'whole'][0][u'ting'], self.features[u'whole'][0][u'chu'], self.features[u'whole'][0][u'wei']]
        # 该户型id对应的原图片url
        self.img_url = ''
        # 该户型所包含的所有分间类对象
        self.room_list = []
        pass

    @property
    def extra_feature_dict(self):
        """
        该户型的特征字典.
        :param:
        :return: 返回字典，key=frame_id + area_id，value为包含面宽、进深、朝向和分间面积的字典
        """
        ef_dict = dict()
        for _, _value in self.features.items():
            for _fea_dic in _value:
                if _fea_dic.get(self._AREA_ID_KEY, '') == '':
                    continue

                ef_dict[self.frame_id.decode('utf8') + _fea_dic[self._AREA_ID_KEY]] = {
                    self._WIDTH_KEY: _fea_dic.get(self._WIDTH_KEY, 0),
                    self._DEPTH_KEY: _fea_dic.get(self._DEPTH_KEY, 0),
                    self._FACE_KEY: _fea_dic.get(self._FACE_KEY, ''),
                    self._AREA_SIZE: _fea_dic.get(self._AREA_SIZE, 0),
                    self._ROOM_LABEL: _fea_dic.get(self._ROOM_LABEL, '')
                }
        for _, _value in self.features_opposite.items():
            for _fea_dic in _value:
                if _fea_dic.get(self._AREA_ID_KEY, '') == '':
                    continue
                ef_dict[self.id_opposite.decode('utf8') + _fea_dic[self._AREA_ID_KEY]] = {
                    self._WIDTH_KEY: _fea_dic.get(self._WIDTH_KEY, 0),
                    self._DEPTH_KEY: _fea_dic.get(self._DEPTH_KEY, 0),
                    self._FACE_KEY: _fea_dic.get(self._FACE_KEY, ''),
                    self._AREA_SIZE: _fea_dic.get(self._AREA_SIZE, 0),
                    self._ROOM_LABEL: _fea_dic.get(self._ROOM_LABEL, '')
                }
        return ef_dict

    def cal_related_room(self, config_params):
        """
        计算与本分间相关的分间，包括吃掉了哪个分间的面积，被哪些分间吃掉了面积
        """
        for _room_iter in self.area_list:
            # 生成分间的扩展类RoomObj对象
            _extra_features = self.extra_feature_dict[self.frame_id.decode('utf8') + _room_iter.uid]
            # _extra_features = self.extra_feature_dict[self.frame_id + _room_iter.uid]
            _params_dict = dict()
            _params_dict[self._EXTRA_FEATURES] = _extra_features
            _room = RoomFactory.room_obj(_room_iter, _params_dict)
            self.room_list.append(_room)
            # 遍历该分间匹配到的分间，搜索所有吃掉自己面积的分间对象，存入passive列表
            for _match in _room.matched_obj:
                # 相交小于阈值的则认为二者不相交
                if _match[1] <= config_params[RDP.THRESHOLD_AREA_MATCH_KEY]:
                    continue
                # 生成匹配分间的扩展类RoomObj对象
                _extra_features = self.extra_feature_dict[self.id_opposite.decode('utf8') + _match[0].uid]
                _params_dict = dict()
                _params_dict[self._EXTRA_FEATURES] = _extra_features
                _match_room = RoomFactory.room_obj(_match[0], _params_dict)
                _match_room.intersect_area = OtherTools.cal_std_area(_match[1])

                # 判断两个分间类型是否相同, 将当前分间匹配到的同类型面积最大的分间作为变换后的自己，即room_same_class
                _flag = (_room.detail_type == _match_room.detail_type) or (_room.room_type == _match_room.room_type and _room.room_type == RDP.RoomClassEnum.parlor.value)
                if not _flag:
                    _room.passive.append(_match_room)
                else:
                    if _room.room_same_class is None:
                        _room.room_same_class = _match_room
                    else:
                        if _match_room.intersect_area <= _room.room_same_class.intersect_area:
                            _room.passive.append(_match_room)
                        else:
                            _room.passive.append(_room.room_same_class)
                            _room.room_same_class = _match_room

            # 如果_room.room_same_class为None，则代表该分间改造后消失
            if _room.room_same_class is None:
                continue
            # 遍历该分间匹配到的分间，搜索所有自己吃掉面积的分间对象，存入proactive列表
            for _match in _room.room_same_class.matched_obj:
                # 如果当前分间和_match是同一个分间、或者不是同一分间但相交小于阈值的则认为二者不相交
                if _room.uid == _match_room.uid or _match[1] < config_params[RDP.THRESHOLD_AREA_MATCH_KEY]:
                    continue
                _extra_features = self.extra_feature_dict[self.frame_id.decode('utf8') + _match[0].uid]
                _params_dict = dict()
                _params_dict[self._EXTRA_FEATURES] = _extra_features
                _match_room = RoomFactory.room_obj(_match[0], _params_dict)
                _match_room.intersect_area = OtherTools.cal_std_area(_match[1])
                _room.proactive.append(_match_room)


class RoomObj(FDE.Room):
    _EXTRA_FEATURES = 'extra_features'
    _WIDTH_KEY = 'width'
    _DEPTH_KEY = 'depth'
    _FACE_KEY = 'face'
    _AREA_SIZE = 'area_size'
    _ROOM_LABEL = 'cluster_room_label'

    def __init__(self, room, params_dict):
        """
        分间扩展类.
        :param room: 通过frame_diff_entity模块下Room方法返回的分间对象
        :param params_dict: 参数字典，传入分间特征、权重
        :return:
        """
        self.__dict__.update(room.__dict__)
        extra_features = params_dict[self._EXTRA_FEATURES]
        # 面宽、进深、朝向、面积
        self.width = extra_features.get(self._WIDTH_KEY, -1)
        self.depth = extra_features.get(self._DEPTH_KEY, -1)
        self.face = NameTools.face_engname_to_std_name(extra_features.get(self._FACE_KEY, ''))
        self.room_label = extra_features.get(self._ROOM_LABEL, '')
        self.area_size = OtherTools.cal_std_area(self.area_size)
        # 分间标准名称、权重
        self.std_name = RDP.SUB_ROOM_NAME[self.detail_type][0]
        self.english_name = NameTools.room_std_name_to_engname(self.std_name)
        self.spatial_weight = RDP.SUB_ROOM_NAME[self.detail_type][2]
        self.total_weight_of_reform = 0
        if isinstance(self.name, unicode):
            self.name = self.name.encode('utf8')

        # 该分间被哪些分间吃掉了面积
        self.passive = []
        # 该分间吃掉了哪些分间的面积
        self.proactive = []
        # 该分间变成了对面户型的哪个分间，如果该分间改造后消失则为None
        self.room_same_class = None
        # 该分间与对面户型某个相交分间的交叠面积
        self.intersect_area = 0

        self.reform_point_list = list()
        self.reform_polygons_origin_lines = list()
        self.reform_polygons_after_lines = list()
        # 文案字典
        self.reform_config = dict()

    @property
    def intersect_ratio(self):
        # 该分间与对面户型某个相交分间的交叠面积/该分间的面积
        return round(self.intersect_area/self.area_size, 2)

    @property
    def intersect_abs_area(self):
        # |该分间与对面户型某个相交分间的交叠面积 - 该分间面积|
        return abs(self.intersect_area - self.area_size)

    @property
    def line_id_dict(self):
        """
        该分间所有墙体关联分间的字典.
        :return: 返回字典，key = 墙体id，value = (分间1名称，分间2名称)，如果为外墙则不存储
        """
        id_dict = dict()
        for _line in self.room_lines:
            _related = list(_line.rooms)
            if len(_related) < 2:
                continue
            id_dict[_line.uid] = (_related[0].name, _related[1].name, _related[0].detail_type, _related[1].detail_type)
        return id_dict

    def personalized_label(self, params_dict):
        pass


class BedRoom(RoomObj):
    def __init__(self, room, params_dict):
        super(BedRoom, self).__init__(room, params_dict)
        self.room_label = self.get_bedroom_label()

    def get_bedroom_label(self):
        width_flag = 0
        depth_flag = 0
        for _param in RDP.BEDROOM_STYLE_WIDTH_THRESHOLD:
            if self.width < _param[0]:
                width_flag = _param[1]
                break
        for _param in RDP.BEDROOM_STYLE_DEPTH_THRESHOLD:
            if self.depth < _param[0]:
                depth_flag = _param[1]
                break
        return '{}|{}'.format(width_flag, depth_flag)

    def personalized_label(self, params_dict):
        s1 = self.area_size
        s2 = 0
        if self.room_same_class is not None:
            s2 = self.room_same_class.area_size
        for _related in self.passive:
            # 判断相关联的分间是否是卧室，检测卧室与卧室相关的改造点
            if s2 > 0 and (_related.detail_type == RDP.RoomNameEnum.bedroom.value or _related.detail_type == RDP.RoomNameEnum.mainroom.value or _related.detail_type == RDP.RoomNameEnum.secondary_bedroom.value):
                BAB = RPI.BedroomAddBedroom(self, **params_dict)
                _flag = BAB.check(_related, self.room_same_class)
                if _flag:
                    self.reform_point_list.append(BAB)
            # 判断相关联的分间是否是卫生间，检测卧室与卫生间相关的改造点
            if s2 > 0 and _related.detail_type == RDP.RoomNameEnum.toilet.value:
                BAT = RPI.BedroomAddToilet(self, **params_dict)
                _flag = BAT.check(_related, self.room_same_class)
                if _flag:
                    self.reform_point_list.append(BAT)
            # 判断相关联的分间是否是卫生间，检测卧室与卫生间相关的改造点
            if s2 > 0 and _related.detail_type == RDP.RoomNameEnum.cloakroom.value:
                BAC = RPI.BedroomAddCloakroom(self, **params_dict)
                _flag = BAC.check(_related, self.room_same_class)
                if _flag:
                    self.reform_point_list.append(BAC)
            # 判断相关联的分间是否是客厅，检测卧室与客厅相关的改造点
            if s2 >= 0 and _related.detail_type == RDP.RoomNameEnum.living_room.value:
                BCL = RPI.BedroomChangeLivingroom(self, **params_dict)
                _flag = BCL.check(_related, self.room_same_class)
                if _flag:
                    self.reform_point_list.append(BCL)

        # 对该分间的改造点按照改造点权重从大到小排序
        self.reform_point_list = sorted(self.reform_point_list, key=lambda x: x.reform_point_weight, reverse=True)
        for _point in self.reform_point_list:
            self.reform_polygons_origin_lines = self.reform_polygons_origin_lines + _point.reform_polygons_origin_lines
            self.reform_polygons_after_lines = self.reform_polygons_after_lines + _point.reform_polygons_after_lines


class LivingRoom(RoomObj):
    def __init__(self, room, params_dict):
        super(LivingRoom, self).__init__(room, params_dict)

    def personalized_label(self, params_dict):
        s1 = self.area_size
        s2 = 0
        if self.room_same_class is not None:
            s2 = self.room_same_class.area_size
        for _related in self.passive:
            # 判断相关联的分间是否是卧室，检测客厅与卧室相关的改造点
            if s2 >= 0 and (_related.detail_type == RDP.RoomNameEnum.bedroom.value or _related.detail_type == RDP.RoomNameEnum.mainroom.value or _related.detail_type == RDP.RoomNameEnum.secondary_bedroom.value):
                LAB = RPI.LivingroomAddBedroom(self, **params_dict)
                _flag = LAB.check(_related, self.room_same_class)
                if _flag:
                    self.reform_point_list.append(LAB)

            # 判断相关联的分间是否是衣帽间，检测卧室与衣帽间相关的改造点
            if s2 > 0 and _related.detail_type == RDP.RoomNameEnum.cloakroom.value:
                LAC = RPI.LivingroomAddCloakroom(self, **params_dict)
                _flag = LAC.check(_related, self.room_same_class)
                if _flag:
                    self.reform_point_list.append(LAC)

        # 对该分间的改造点按照改造点权重从大到小排序
        self.reform_point_list = sorted(self.reform_point_list, key=lambda x: x.reform_point_weight, reverse=True)
        for _point in self.reform_point_list:
            self.reform_polygons_origin_lines = self.reform_polygons_origin_lines + _point.reform_polygons_origin_lines
            self.reform_polygons_after_lines = self.reform_polygons_after_lines + _point.reform_polygons_after_lines


class Kitchen(RoomObj):
    def __init__(self, room, params_dict):
        super(Kitchen, self).__init__(room, params_dict)

    def personalized_label(self, params_dict):
        s1 = self.area_size
        s2 = 0
        if self.room_same_class is not None:
            s2 = self.room_same_class.area_size
        if s2 > s1 + params_dict['reform_docs']['threshold_add_area']:
            KAA = RPI.KitchenAddArea(self, **params_dict)
            _flag = KAA.check(self.room_same_class, self.room_same_class)
            if _flag:
                self.reform_point_list.append(KAA)

        # 对该分间的改造点按照改造点权重从大到小排序
        self.reform_point_list = sorted(self.reform_point_list, key=lambda x: x.reform_point_weight, reverse=True)
        for _point in self.reform_point_list:
            self.reform_polygons_origin_lines = self.reform_polygons_origin_lines + _point.reform_polygons_origin_lines
            self.reform_polygons_after_lines = self.reform_polygons_after_lines + _point.reform_polygons_after_lines


class Toilet(RoomObj):
    def __init__(self, room, params_dict):
        super(Toilet, self).__init__(room, params_dict)

    def judge_have_dangle_wall(self):
        for _line in self.room_lines:
            if _line.is_dangle:
                return True
        return False

    def personalized_label(self, params_dict):
        s1 = self.area_size
        s2 = 0
        if self.room_same_class is not None:
            s2 = self.room_same_class.area_size
        if self.room_same_class is not None and not self.judge_have_dangle_wall() and self.room_same_class.judge_have_dangle_wall():
            TDW = RPI.ToiletDryWet(self, **params_dict)
            _flag = TDW.check(self.room_same_class, self.room_same_class)
            if _flag:
                self.reform_point_list.append(TDW)

        # 对该分间的改造点按照改造点权重从大到小排序
        self.reform_point_list = sorted(self.reform_point_list, key=lambda x: x.reform_point_weight, reverse=True)
        for _point in self.reform_point_list:
            self.reform_polygons_origin_lines = self.reform_polygons_origin_lines + _point.reform_polygons_origin_lines
            self.reform_polygons_after_lines = self.reform_polygons_after_lines + _point.reform_polygons_after_lines
