# -*- coding: utf-8 -*-
"""
二手户改报告生成主函数模块
Authors: yangdongxue004@ke.com
Date:    2021/9/22
"""
from __future__ import division
import json
import copy
import os
import random

import pandas as pd
from shapely.affinity import affine_transform

import frame_mod_eval.utils.frame_diff as FD
import frame_eval.frame_tag_lib.utils as tag_utils
from frame_mod_eval.secondhand_mod import room_diff_second, room_factory_second
from frame_mod_eval.entity import frame_diff_entity as ent
from frame_eval.frame_tag_lib import spark_main_feature
from lib import diff_util, figures
from frame_mod_eval.utils.reform_func_tools import ImgTools, DocsGenerator, OtherTools

REFORM_PRIORITY = {1, 0, 7, 10, 2, 3, 8, 9}

def extract_basic_features(frame, config_params):
    frame_id, line = tag_utils.get_frame_vector(frame)
    frame, result = tag_utils.get_whole_frame_info(line, config_params["explain_params"], spark_main_feature.get_result, spark_main_feature.update_basic2frame)

    features = result[1]
    if features != "":
        features = json.loads(result[1])

    return features, result


def generate_reform_json_without_http(f_1, f_2, frame_json_a, frame_json_b, features_a, features_b, config_params, generate_md=False):
    # frame_diff里面计算两户型的分间、墙体、附件的diff主流程
    frame_a = ent.FrameStdVecObj(frame_json_a, frame_id=f_1)
    frame_b = ent.FrameStdVecObj(frame_json_b, frame_id=f_2)
    frame_a_2, frame_b_2, status_diff = FD.frame_diff(frame_a, frame_b)

    # 接收frame_diff的状态值，如果小于0则代表无法正常旋转，直接返回，否则就继续运行
    if status_diff < 0:
        return ['', '', status_diff, json.dumps(frame_a_2.dump([]))]

    try:
        if features_a == '' or features_b == '':
            raise Exception("frame features is an empty string")
    except Exception as e:
        print(repr(e))

    if not isinstance(features_a, dict):
        features_a = json.loads(features_a)
    if not isinstance(features_b, dict):
        features_b = json.loads(features_b)
    # 初始化原户型和改后户型的FrameObj对象，以及FrameDiffEval对象, 调用cal_related_room()函数计算吃掉对面的谁和被对面的谁吃掉
    params_dict = {'features': features_a, 'features_opposite': features_b, 'id_opposite': f_2}
    frame_a = room_factory_second.FrameObj(frame_a_2, params_dict)
    frame_a.cal_related_room(config_params['mod_eval_conf']['reform_docs'])
    params_dict = {'features': features_b, 'features_opposite': features_a, 'id_opposite': f_1}
    frame_b = room_factory_second.FrameObj(frame_b_2, params_dict)
    frame_b.cal_related_room(config_params['mod_eval_conf']['reform_docs'])
    frame_diff_obj = room_diff_second.FrameDiffEval(frame_a, frame_b)

    result = frame_diff_obj.generate_json_without_http(config_params)

    return result


def reform_docs_main_without_http(f_1, f_2, json_1, json_2, features_a, features_b, frame_score, config_params):
    """
    第一阶段
    :param f_1: 改造前户型id
    :param f_2: 改造后户型id
    :param json_1: 改造前户型json
    :param json_2: 改造后户型json
    :param features_a: 改造前户型特征字典
    :param features_b: 改造后户型特征字典
    :param config_params: 外部调控参数字典
    :return: 户改报告(中间过程)全量表data_mining_frame_mod_report_inter_da对应的参数字典(共9个key，frame_id、after_frame_id、
    status、score、report、short_report、detail_info、after_frame_json、is_valid(设置成了固定值1))
    """
    result_dict = dict()
    # 返回列表：包括改造前后id、打分、长短文案、是否有效、状态值
    result_dict['frame_id'] = f_1
    result_dict['after_frame_id'] = f_2
    result_dict['is_valid'] = 0
    result_dict['score'] = frame_score
    docs_json = generate_reform_json_without_http(f_1, f_2, json_1, json_2, features_a, features_b, config_params)
    result_dict['status'] = docs_json[2]
    if docs_json[2] < 0:
        return result_dict
    result_dict['is_valid'] = 1
    # 清空无用的report坐标
    report_dict = json.loads(docs_json[1])
    short_report_dict = json.loads(docs_json[0])
    report_dict['frame_after']['img_url'] = list()
    short_report_dict['frame_after']['img_url'] = list()
    result_dict['short_report'] = json.dumps(short_report_dict)

    for _room in report_dict['room_list']:
        for _reform_point in _room['reform_point']:
            _reform_point['aft_reform_img_url'] = list()
            _reform_point['ori_reform_img_url'] = list()

    result_dict['report'] = json.dumps(report_dict)

    return result_dict


def case_study_first_second_period(frameid_1='1116895714014035', frameid_2='1120040115173614'):
    json_a, json_b = diff_util.download_frame_json([frameid_1, frameid_2], with_json=False)

    # 提取户型f_1和f_2的面宽、进深等特征, case_study使用的是frame_diff里的
    features_a, result_1 = extract_basic_features(frameid_1, conf_params1)
    features_b, result_2 = extract_basic_features(frameid_2, conf_params1)

    # 第一阶段，通过两户型id、两户型json和调控参数获取户改报告(中间过程)全量表参数字典result1
    result1 = reform_docs_main_without_http(frameid_1, frameid_2, json_a, json_b, features_a, features_b, 0, conf_params1)
    pass


if __name__ == '__main__':
    import matplotlib.pyplot as plt
    conf_params1 = dict()
    conf_params2 = dict()
    conf_params3 = dict()
    tag_utils.collect_conf(r"config/mod_eval_conf.yml", conf_params1)
    tag_utils.collect_conf(r"frame_eval/frame_tag_lib/conf.yml", conf_params2)
    tag_utils.collect_conf(r"frame_mod_eval/reform_docs.yml", conf_params3)
    conf_params1.update(conf_params2)
    conf_params1.update(conf_params3)
    case_study_first_second_period(frameid_1='1120043942275332', frameid_2='11000015816606')
    pass
