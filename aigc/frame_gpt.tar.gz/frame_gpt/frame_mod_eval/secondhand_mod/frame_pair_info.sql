-- 获得改前和改后户型id及信息
WITH group_base AS (
		SELECT *
		FROM data_mining.data_mining_frame_res_group_da
		WHERE pt = '{pt_date}000000'
			AND city_code IN ({city_code})
	),
	cluster_v3 AS (
		SELECT *
		FROM data_mining.data_mining_frame_cluster_v3_da
		WHERE pt = '{cluster_last_pt}000000'
			AND city_code IN ({city_code})
	),
    group_cluster AS (
		SELECT DISTINCT g.frame_id, rept_frame_id, res_mod_rept_id, g.city_code
		FROM group_base g
			JOIN cluster_v3 v ON g.frame_id = v.frame_id
	),
    frame_score AS (
		SELECT *
		FROM data_mining.data_mining_frame_score
        WHERE pt = '{pt_date}000000'
		    AND city_code IN ({city_code})
	),
    tag_lib AS (
		SELECT *
		FROM data_mining.data_mining_frame_tag_lib_da
		WHERE pt = '{pt_date}000000'
			AND city_code IN ({city_code})
	),
    v_frame AS (
		SELECT frame_id
			, reflect('java.net.URLDecoder', 'decode', trim(vector_value), 'UTF-8') AS json_str
		FROM (
			SELECT mapping.frame_id, vector_value
			FROM (
				SELECT id, vector_value
				FROM dw.dw_house_frame_vector_da
				WHERE pt = '{pt_date}000000'
					AND is_valid = 1
			) vector
				JOIN (
					SELECT image_id, entity_id AS frame_id, ROW_NUMBER() OVER (
                        PARTITION BY entity_id
                        ORDER BY
                            update_time DESC
                    ) AS rn
					FROM dw.dw_house_image_entity_mapping_da
					WHERE pt = '{pt_date}000000'
						AND image_type_code = 110028006
						AND entity_type_code = 110029002
						AND is_valid = 1
				) mapping
				ON mapping.image_id = vector.id
				JOIN (
					SELECT DISTINCT frame_id
					FROM dw.dw_house_house_frame_mapping_da
					WHERE pt = '{pt_date}000000'
						AND is_valid = 1
						AND city_code IN ({city_code})
				) h_m
				ON mapping.frame_id = h_m.frame_id
				where rn =1
		) aaa
	),
    last_inter_pt_data AS (
        SELECT frame_id, after_frame_id, report, error_msg, is_valid, score, status
        FROM data_mining.data_mining_second_hand_mod_report_inter_da
        WHERE pt = '{last_pt_date}000000'
    )


SELECT DISTINCT
    NVL(c.frame_id, a.frame_id) AS frame_id
    , b.frame_id AS after_frame_id
    , d.json_str AS before_frame_json
    , e.json_str AS after_frame_json
    , f.feature as before_frame_feature
    , g.feature as after_frame_feature
    , NVL(h.score, 0) AS score
    , NVL(c.report, 'none') AS report
    , c.error_msg
    , c.is_valid
    , c.status
    , a.city_code
FROM group_cluster a
    FULL JOIN group_cluster b
        ON a.res_mod_rept_id = b.res_mod_rept_id
    LEFT JOIN v_frame d ON a.frame_id = d.frame_id
    LEFT JOIN v_frame e ON b.frame_id = e.frame_id
    LEFT JOIN tag_lib f ON a.frame_id = f.frame_id
    LEFT JOIN tag_lib g ON b.frame_id = g.frame_id
    LEFT JOIN frame_score h ON a.frame_id = h.frame_id
    LEFT JOIN last_inter_pt_data c ON a.frame_id = c.frame_id
                                          AND b.frame_id = c.after_frame_id
WHERE a.frame_id != b.frame_id AND a.rept_frame_id != b.rept_frame_id

