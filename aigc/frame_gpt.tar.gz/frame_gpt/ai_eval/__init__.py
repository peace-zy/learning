import sys
import os.path as pa

sys.path.append(pa.dirname(pa.dirname(pa.abspath(__file__))))