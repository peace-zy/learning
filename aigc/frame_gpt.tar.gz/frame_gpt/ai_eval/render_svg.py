#!/usr/bin/env python
# coding: utf-8
import json
# import drawSvg as draw
import numpy as np
import matplotlib as mpl
import os
import pandas as pd
import xml.etree.ElementTree as ET

import torch.multiprocessing as mp

import pydiffvg
import ttools.modules
import torch
import skimage.io
from pydiffvg.optimize_svg import OptimizableSvg
from pydiffvg.parse_svg import parse_scene
from matplotlib import pyplot as plt

from collections import namedtuple

import svgwrite
from svgwrite import shapes as svg_sp
from svgwrite.container import Group
import multiprocessing
from multiprocessing import Pool


def convert_dict_to_svg(frame_dict_str, frame_id, random_translate=True, save_path=None):
    frame_dict = json.loads(frame_dict_str)
    d = svgwrite.Drawing(f'{frame_id}.svg', size=(WIDTH, WIDTH), profile='tiny')
    g = Group(id=str(frame_id))
    all_pts = []
    # 水平翻转
    max_y = -1
    for _ in frame_dict:
        _obj_list = frame_dict[_]
        for _obj_idx, _obj in enumerate(_obj_list):
            _pts = np.array(_obj['pts'])
            max_y = max(max_y, _pts.max(0)[-1])
    for _ in frame_dict:
        _obj_list = frame_dict[_]
        for _obj_idx, _obj in enumerate(_obj_list):
            _pts = np.array(_obj['pts'])
            _pts = np.abs(_pts - np.array([0, max_y]))
            all_pts.extend(_pts)
            _color = _obj['color']
            _color_hex = mpl.colors.rgb2hex(_color)
            if len(_pts) > 2:
                _d_str = f"M {_pts[0][0]} {_pts[0][1]}"
                for _pt in _pts[1:]:
                    _d_str += f"L {_pt[0]} {_pt[1]}"
                g.add(svgwrite.path.Path(d=_d_str + ' Z', fill=_color_hex, fill_opacity=_color[-1], id=f"{_}{_obj_idx}"))
            elif len(_pts) == 2:
                # 墙体变成白色
                if 'item' not in _:
                    _color_hex = '#FFFFFF'
                _p = svgwrite.path.Path(d=f"M {_pts[0][0]} {_pts[0][1]} L {_pts[1][0]} {_pts[1][1]}",
                                        stroke=_color_hex, stroke_width=3, id=f"{_}{_obj_idx}")
                g.add(_p)
    if random_translate:
        _all_pts = (WIDTH - (np.array(all_pts)).max(0))*(0.1 + 0.8*np.random.rand())
        g.translate(tx=_all_pts[0], ty=_all_pts[1])
    d.add(g)
    if save_path is not None:
        d.save()
    return d.tostring()

def parse_svg_from_string(svg_str):
    tree = ET.ElementTree(ET.fromstring(svg_str))
    root = tree.getroot()
    ret = parse_scene(root)
    return ret


def svg_render(canvas_width, canvas_height, shapes, shape_groups):
    _render = pydiffvg.RenderFunction.apply
    scene_args = pydiffvg.RenderFunction.serialize_scene(canvas_width, canvas_height, shapes, shape_groups)
    img = _render(canvas_width, # width
                 canvas_height, # height
                 2,   # num_samples_x
                 2,   # num_samples_y
                 0,   # seed
                 None,
                 *scene_args)
    return img


def render_func(_frame_id, frame_dict_str, count):
    svg_str = convert_dict_to_svg(frame_dict_str, _frame_id)
    canvas_width, canvas_height, shapes, shape_groups = parse_svg_from_string(svg_str)
    ref = svg_render(canvas_width, canvas_height, shapes, shape_groups)
    pydiffvg.imwrite(ref.cpu(), f'{svg_render_png}/{_frame_id}.png', gamma=1.0)
    if count % 100 == 0:
        print(f'count:{count}')
    return [_frame_id, count]


def single_render_func(curser_start, curser_end):
    count = 0
    with open(frame_df_path, 'r') as fp:
        line = fp.readline()
        print(f'head:{line}')
        while True:
            count += 1
            line = fp.readline()
            if not line:
                break
            if not curser_start < count < curser_end:
                continue
            _line_rows = line.strip().split('\t')
            _frame_id, frame_dict_str = _line_rows[0], _line_rows[-1]
            # Load SVG
            svg_str = convert_dict_to_svg(frame_dict_str, _frame_id)
            canvas_width, canvas_height, shapes, shape_groups = parse_svg_from_string(svg_str)
            ref = svg_render(canvas_width, canvas_height, shapes, shape_groups)
            pydiffvg.imwrite(ref.cpu(), f'{svg_render_png}/{_frame_id}.png', gamma=1.0)
            if count % 100 == 0:
                print(f'count:{count}')

frame_df_path = "all_dataset_1M_svg_bj_all.tsv"
svg_render_png = 'img_single_svg_2'
WIDTH = 224
pydiffvg.set_device(torch.device('cuda:1'))


if __name__ == '__main__':
    torch.multiprocessing.set_start_method('spawn')
    data_size = 1e6
    num_processes = 7
    chunk_size = data_size // num_processes
    print(f"data_size:{data_size}, num_processes:{num_processes}, chunk_size:{chunk_size}")
    processes = []
    for rank in range(num_processes):
        p = mp.Process(target=single_render_func, args=(rank*chunk_size, (rank+1)*chunk_size))
        p.start()
        processes.append(p)
    for p in processes:
        p.join()
    
#     torch.multiprocessing.set_start_method('spawn')
#     multiprocessing.set_start_method('spawn')
#     pydiffvg.set_device(torch.device('cuda:0'))
#     WIDTH = 320

#     frame_df_path = "all_dataset_1M_svg.tsv"
#     svg_render_png = 'img_single_svg'
#     res_list = []
#     p = Pool(3)
#     count = 0
#     with open(frame_df_path, 'r') as fp:
#         line = fp.readline()
#         print(f'head:{line}')
#         while True:
#             count += 1
#             line = fp.readline()
#             if not line:
#                 break
#             _line_rows = line.strip().split('\t')
#             _frame_id, frame_dict_str = _line_rows[0], _line_rows[-1]
#             result = p.apply_async(render_func, args=(_frame_id, frame_dict_str, count))
#             res_list.append(result)
#             break
#     p.close()
#     p.join()
#     ret_result = []
#     for res in res_list:
#         result = res.get()
#         if result:
#             ret_result.append(result)
    print(f"ALL DONE")






