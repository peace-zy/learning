# -*- coding: utf-8 -*-
"""
户改报告生成主函数模块
Authors: yangdongxue004@ke.com
Date:    2021/8/15
"""
from __future__ import division
import sys
import os.path as pa
sys.path.append('/Users/liyulong/Documents/work/project/frame_gpt')
import json, csv
import copy
import os
import traceback
from collections import Counter

import numpy as np
import pandas as pd
from shapely.affinity import affine_transform
from descartes.patch import PolygonPatch
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
# /aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt/frame_mod_eval
sys.path.append('/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt')
import frame_mod_eval.utils.frame_diff as FD
import matplotlib.pyplot as plt
import frame_eval.frame_tag_lib.utils as tag_utils
from frame_mod_eval.utils import room_diff, room_factory
from frame_mod_eval.entity import frame_diff_entity as ent
from frame_eval.frame_tag_lib import spark_main_feature
from lib import diff_util, figures, entity
from frame_mod_eval.utils.reform_func_tools import ImgTools, DocsGenerator, OtherTools
import cv2
from multiprocessing import Pool


def cal_precision():
    sample_df = pd.read_excel('frame_mod_eval/label.xls')
    tot = 0
    cnt = 0
    yingshe = {'客厅-客厅改卧室': 1, '卧室-增加卧室': 2, '卧室-增加卫生间': 3, '卧室-增加衣帽间': 4, '无检测点': 5}
    hang = 0
    for _row in sample_df.itertuples():
        data = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
        tot = tot + 1
        frame_1 = str(_row.frame_id1)
        frame_2 = str(_row.frame_id2)
        cnt = cnt + 1
        try:
            reform_point = generate_reform_json(frame_1, frame_2, cal_precision=True)
            print('当前第{}个打样md处理完毕'.format(cnt))

            for reform_point_name in reform_point:
                print(reform_point_name[0])
                data[yingshe[reform_point_name[0]]] = 1
            if len(reform_point) == 0:
                data[5] = 1
        except Exception as ex:
            print("ERROR: ", ex)

        fIO = open("frame_mod_eval/precision.txt", "a+")
        fIO.writelines('{},{},{},{},{},{},{}\n'.format(frame_1, frame_2,data[1],data[2],data[3],data[4],data[5]))
        fIO.close()

        print(data[1], data[2], data[3], data[4], data[5])

    pass


def calprecision_100_sampling():
    sample_df = pd.read_excel('frame_mod_eval/100frame_id_sampling.xls')
    tot = 0
    cnt = 0
    yingshe = {'客厅-客厅改卧室': 1, '卧室-增加卧室': 2, '卧室-增加卫生间': 3, '卧室-增加衣帽间': 4}
    hang = 0
    for _row in sample_df.itertuples():
        tot = tot + 1
        frame_1 = str(_row.res_contour_rept_id)
        _frame_ids = _row.all_group_frame.split(',')
        for _frame_id in _frame_ids:
            data = {1: 0, 2: 0, 3: 0, 4: 0}
            frame_2 = str(_frame_id)
            if frame_1 == frame_2:
                continue
            cnt = cnt + 1
            str_name = ''
            try:
                reform_point = generate_reform_json(frame_1, frame_2)
                print('当前第{}个打样md处理完毕{}-{}'.format(cnt, frame_1,frame_2))

                for _, reform_point_name in enumerate(reform_point):
                    print(reform_point_name[0])
                    data[yingshe[reform_point_name[0]]] = 1
                    str_name = str_name + reform_point_name[0]
                    if _ < len(reform_point) - 1:
                        str_name = str_name + ','
            except Exception as ex:
                print("ERROR: ", ex)

            fIO = open("frame_mod_eval/reform_point_100_sampling.txt", "a+")
            fIO.writelines('{},{},{}\n'.format(frame_1, frame_2, str_name))
            fIO.close()

            print(data[1], data[2], data[3], data[4])

    pass

# def display_frame_pairs(frame_a, frame_b, corner_desc=False, wall_desc=False, display=True, use_b_axis=False):
#     """
#     绘出户型对比图
#     :param frame_a:
#     :param frame_b:
#     :param corner_desc: 是否显示点坐标
#     :param wall_desc: 是否显示墙的长度
#     :param display: True, 直接调试中显示; False, 保存到指定目录
#     :param use_b_axis: 将frame_a的坐标系换算到b.
#     :return:
#     """
#     size = ent.DiffFrame.DISPLAY_SIZE
#     _margin = int(size * 0.01)
#     fig = plt.figure(1, figsize=(12, 6), dpi=90)
#     ax_a = fig.add_subplot(121)
#     ax_a.axis('off')
#     ax_b = fig.add_subplot(122)
#     ax_b.axis('off')
#     for _ax, _frame in zip([ax_a, ax_b], [frame_a, frame_b]):
#         if use_b_axis:
#             _matrix_1d = frame_b.get_trans_matrix_1d()
#         else:
#             _matrix_1d = _frame.get_trans_matrix_1d()
#         # 绘制角点
#         for _p in _frame.corner_list:
#             _scale_p = affine_transform(_p.obj, _matrix_1d)
#             figures.plot_coords(_ax, _scale_p, color=_p.color, zorder=_p.zorder, alpha=_p.alpha)
#             if corner_desc:
#                 figures.add_origin(_ax, _scale_p, 'center', _p.name)
#         # 绘制墙体
#         for _w in _frame.wall_list:
#             _scale_w = affine_transform(_w.obj, _matrix_1d)
#             figures.plot_line(_ax, _scale_w, color=figures.BLUE, zorder=_w.zorder, linewidth=1, alpha=_w.alpha)
#             figures.plot_line(_ax, _scale_w, color=_w.color, zorder=_w.zorder, linewidth=_w.linewidth, alpha=_w.alpha)
#             if wall_desc:
#                 figures.add_origin(_ax, _scale_w, 'center', str(_w.length))
#         # 绘制墙体附件
#         for _w_i in _frame.wall_item_list:
#             if not _w_i.is_matched:
#                 _scale_w_i = affine_transform(_w_i.obj, _matrix_1d)
#                 figures.plot_line(_ax, _scale_w_i, color=figures.BLUE, zorder=_w_i.zorder, linewidth=1, alpha=_w_i.alpha)
#                 figures.plot_line(_ax, _scale_w_i, color=_w_i.color, zorder=_w_i.zorder, linewidth=_w_i.linewidth, alpha=_w_i.alpha)
#                 if wall_desc:
#                     figures.add_origin(_ax, _scale_w_i, 'center', str(_scale_w_i.length))
#         figures.set_limits(_ax, -_margin, size + _margin, -_margin, size + _margin)
#     if display:
#         plt.show()
#     else:
#         # plt.savefig('data/mod_diff_res/img/{}-{}.jpg'.format(frame_a.frame_id, frame_b.frame_id), bbox_inches='tight', pad_inches=0)
#         plt.savefig('data/reform_doc_pic/skeleton/{}-{}.jpg'.format(frame_a.frame_id, frame_b.frame_id), bbox_inches='tight', pad_inches=0)
#         plt.close()


def save_frame_as_svg():
    pass


WALL_COLOR = (0.01, 0.01, 0.01)

WALL_ITEM_COLOR = (0.8, 0.1, 0.1)


def display_frame_single(_frame):
    size = ent.DiffFrame.DISPLAY_SIZE
    _margin = int(size * 0.01)
    _imgs = []
    _diff_line_objs = []
    fig = plt.figure(1, figsize=(6, 6), dpi=90)
    # fig.patch.set_facecolor('black')
    # plt.rcParams['axes.facecolor'] = 'black'
    _ax = fig.add_subplot(111)
    _ax.axis('off')
    _matrix_1d = _frame.get_trans_matrix_1d()
    # 绘制角点
    # 绘制墙体
    frame_dict = {'area': [], 'wall': [], 'wall_item': []}
    for _a_i in _frame.area_list:
        _scale_a_i = affine_transform(_a_i.obj, _matrix_1d)
        patch = PolygonPatch(_scale_a_i, facecolor=_a_i.color, zorder=1, linewidth=0)
        frame_dict['area'].append({'pts': np.array(_scale_a_i.boundary.coords, dtype=int).tolist(),
                                   'color': [round(_, 4) for _ in _a_i.color]})
        _ax.add_patch(patch)
    for _w in _frame.wall_list:
        _scale_w = affine_transform(_w.obj, _matrix_1d)
        figures.plot_line(_ax, _scale_w, color=_w.color, zorder=2, solid_capstyle='projecting', linewidth=int(size * 0.02))
        frame_dict['wall'].append({'pts': np.array(_scale_w.coords, dtype=np.int).tolist(),
                                   'color': [round(_, 4) for _ in _w.color]})
    # 绘制墙体附件
    for _w_i in _frame.wall_item_list:
        _scale_w_i = affine_transform(_w_i.obj, _matrix_1d)
        figures.plot_line(_ax, _scale_w_i, color=_w_i.color, zorder=3, solid_capstyle='butt', linewidth=int(size * 0.03))
        frame_dict['wall_item'].append({'pts': np.array(_scale_w_i.coords, dtype=np.int).tolist(),
                                        'color': [round(_, 4) for _ in _w_i.color]})
    figures.set_limits(_ax, -_margin, size + _margin, -_margin, size + _margin)
    canvas = FigureCanvas(fig)
    canvas.draw()
    image = np.frombuffer(canvas.tostring_rgb(), dtype='uint8').reshape(fig.canvas.get_width_height()[::-1] + (3,))
    _img_path = f'/aistudio/workspace/aigc_ssd/liyulong/project/frame_gpt/data/img_single/{_frame.frame_id}.jpg'
    cv2.imwrite(_img_path, image[..., ::-1])
    plt.clf()
    return _img_path, frame_dict


def display_frame_pairs(frame_a, frame_b, corner_desc=False, wall_desc=False, display=True, use_b_axis=False):
    """
    绘出户型对比图
    :param frame_a:
    :param frame_b:
    :param corner_desc: 是否显示点坐标
    :param wall_desc: 是否显示墙的长度
    :param display: True, 直接调试中显示; False, 保存到指定目录
    :param use_b_axis: 将frame_a的坐标系换算到b.
    :return:
    """
    size = ent.DiffFrame.DISPLAY_SIZE
    _margin = int(size * 0.05)
    _imgs = []
    _diff_line_objs = []
    for _idx, _frame in enumerate([frame_a, frame_b]):
        fig = plt.figure(1, figsize=(6, 6), dpi=90)
        _ax = fig.add_subplot(111)
        _ax.axis('off')
        if use_b_axis:
            _matrix_1d = frame_b.get_trans_matrix_1d()
        else:
            _matrix_1d = _frame.get_trans_matrix_1d()
        # 绘制角点
        # 绘制墙体
        for _w in _frame.wall_list:
            _scale_w = affine_transform(_w.obj, _matrix_1d)
            figures.plot_line(_ax, _scale_w, color=WALL_COLOR, zorder=2, linewidth=2, alpha=1)
            if not _w.is_matched and not _w.edge_computed:
                # 不包含外墙
                _diff_line_objs.append((_scale_w, WALL_COLOR, 2))
        # 绘制墙体附件
        for _w_i in _frame.wall_item_list:
            _scale_w_i = affine_transform(_w_i.obj, _matrix_1d)
            figures.plot_line(_ax, _scale_w_i, color=WALL_ITEM_COLOR, zorder=3, linewidth=3, alpha=1)
            if not _w_i.is_matched:
                _diff_line_objs.append((_scale_w_i, WALL_ITEM_COLOR, 4))
        for _a_i in _frame.area_list:
            _scale_a_i = affine_transform(_a_i.obj, _matrix_1d)
            patch = PolygonPatch(_scale_a_i, facecolor=_a_i.color_shade_rgb, linewidth=2, alpha=1, zorder=1)
            _ax.add_patch(patch)
        figures.set_limits(_ax, -_margin, size + _margin, -_margin, size + _margin)
        canvas = FigureCanvas(fig)
        canvas.draw()
        image = np.frombuffer(canvas.tostring_rgb(), dtype='uint8').reshape(fig.canvas.get_width_height()[::-1] + (3,))
        cv2.imwrite(f'data/aigc/img/{frame_a.frame_id}-{frame_b.frame_id}_{_idx}.jpg', image)
        _imgs.append(image.mean(2))
        plt.clf()
    # 绘制diff墙体
    fig = plt.figure(1, figsize=(6, 6), dpi=90)
    _ax = fig.add_subplot(111)
    _ax.axis('off')
    figures.set_limits(_ax, -_margin, size + _margin, -_margin, size + _margin)
    diff_canvas = FigureCanvas(fig)
    for _o, _c, _l in _diff_line_objs:
        figures.plot_line(_ax, _o, color=_c, zorder=_l, linewidth=_l, alpha=1)
    diff_canvas.draw()
    image = np.frombuffer(diff_canvas.tostring_rgb(), dtype='uint8').reshape(fig.canvas.get_width_height()[::-1] + (3,))
    cv2.imwrite(f'data/aigc/img/{frame_a.frame_id}-{frame_b.frame_id}_diff.jpg', image)
    _imgs.append(image.mean(2))
    _imgs = cv2.merge(_imgs)
    _imgs_flag = (np.abs(_imgs - 255.) < 0.00001).astype(np.int)
    _match_diff = np.sum(np.abs(_imgs_flag[..., 0] - _imgs_flag[..., 1]) > 0) / np.sum((_imgs_flag[..., 0] + _imgs_flag[..., 1]) > 0)
    _all_pic_path = f'data/aigc/img/{frame_a.frame_id}-{frame_b.frame_id}_all.jpg'
    cv2.imwrite(_all_pic_path, _imgs)
    plt.clf()
    return _all_pic_path, _match_diff


def extract_basic_features(frame, config_params):
    frame_id, line = tag_utils.get_frame_vector(frame)
    frame, result = tag_utils.get_whole_frame_info(line, config_params["explain_params"], spark_main_feature.get_result, spark_main_feature.update_basic2frame)

    features = result[1]
    if features != "":
        features = json.loads(result[1])

    return features, result


def generate_reform_json(f_1, f_2, config_params, generate_md=True, cal_precision=False):
    """
    生成改造点json
    :param f_1: 原户型frame_id
    :param f_2: 改户型frame_id
    :param config_params: 外部传入的参数字典
    :param generate_md: 布尔值,True表示生成本地md文件,False表示生成长短文案的json
    :param cal_precision: 布尔值, 当generate_md为True时,cal_precision为True会让函数返回不重复的改造点而不生成md文件
    :return: result list<> 根据generate_md的值决定返回文案的json还是生成本地md文件,如果生成md的话返回不重复的改造点
    """
    # frame_diff里面计算两户型的分间、墙体、附件的diff主流程
    frame_json_a, frame_json_b = diff_util.download_frame_json([f_1, f_2], with_json=False)
    frame_a = ent.FrameStdVecObj(frame_json_a, frame_id=f_1)
    frame_b = ent.FrameStdVecObj(frame_json_b, frame_id=f_2)
    frame_a_2, frame_b_2, status_diff = FD.frame_diff(frame_a, frame_b)

    # 接收frame_diff的状态值,如果小于0则代表无法正常旋转,直接返回,否则就继续运行
    if status_diff < 0:
        return ['', '', status_diff]
    # 调用frame_diff模块里面的画图函数,画出的图片会存储在本地,如果要生成md文件的话需要把这句话的注释去掉
    if generate_md:
        import matplotlib.pyplot as plt
        # FD.display_frame_pairs(frame_a, frame_b, display=False)
        display_frame_pairs(frame_a, frame_b, display=False)
    # 提取户型f_1和f_2的面宽、进深等特征, case_study使用的是frame_diff里的
    features_a, result_1 = extract_basic_features(f_1, config_params)
    features_b, result_2 = extract_basic_features(f_2, config_params)

    entity_frame_a, eval_result_a = FD.extract_single_frame_feature(f_1, frame_json_a, conf=config_params)
    entity_frame_b, eval_result_b = FD.extract_single_frame_feature(f_2, frame_json_b, conf=config_params)

    # 初始化原户型和改后户型的FrameObj对象,以及FrameDiffEval对象, 调用cal_related_room()函数计算吃掉对面的谁和被对面的谁吃掉
    params_dict = {'features': features_a, 'features_opposite': features_b, 'id_opposite': f_2, 'frame_label': entity_frame_a.frame_label, 'without_http': False}
    frame_a = room_factory.FrameObj(frame_a_2, params_dict)
    frame_a.cal_related_room(config_params['mod_eval_conf']['reform_docs'])
    params_dict = {'features': features_b, 'features_opposite': features_a, 'id_opposite': f_1, 'frame_label': entity_frame_b.frame_label, 'without_http': False}
    frame_b = room_factory.FrameObj(frame_b_2, params_dict)
    frame_b.cal_related_room(config_params['mod_eval_conf']['reform_docs'])
    frame_diff_obj = room_diff.FrameDiffEval(frame_a, frame_b)

    result = frame_diff_obj.generate_md(config_params, calculate_precision=cal_precision)
    return result


def generate_reform_text_img_pair(f_1, f_2, config_params, generate_md=True, cal_precision=False):
    """
    生成改造点json
    :param f_1: 原户型frame_id
    :param f_2: 改户型frame_id
    :param config_params: 外部传入的参数字典
    :param generate_md: 布尔值,True表示生成本地md文件,False表示生成长短文案的json
    :param cal_precision: 布尔值, 当generate_md为True时,cal_precision为True会让函数返回不重复的改造点而不生成md文件
    :return: result list<> 根据generate_md的值决定返回文案的json还是生成本地md文件,如果生成md的话返回不重复的改造点
    """
    # frame_diff里面计算两户型的分间、墙体、附件的diff主流程
    frame_json_a, frame_json_b = diff_util.download_frame_json([f_1, f_2], with_json=False)
    frame_a = ent.FrameStdVecObj(frame_json_a, frame_id=f_1)
    frame_b = ent.FrameStdVecObj(frame_json_b, frame_id=f_2)
    frame_a_2, frame_b_2, status_diff = FD.frame_diff(frame_a, frame_b)

    # 接收frame_diff的状态值,如果小于0则代表无法正常旋转,直接返回,否则就继续运行
    if status_diff < 0:
        return ['', '', status_diff]
    # 调用frame_diff模块里面的画图函数,画出的图片会存储在本地,如果要生成md文件的话需要把这句话的注释去掉
        # FD.display_frame_pairs(frame_a, frame_b, display=False)
    _all_pic_path, _match_diff = display_frame_pairs(frame_a, frame_b, display=False)
    # 提取户型f_1和f_2的面宽、进深等特征, case_study使用的是frame_diff里的
    features_a, result_1 = extract_basic_features(f_1, config_params)
    features_b, result_2 = extract_basic_features(f_2, config_params)

    entity_frame_a, eval_result_a = FD.extract_single_frame_feature(f_1, frame_json_a, conf=config_params)
    entity_frame_b, eval_result_b = FD.extract_single_frame_feature(f_2, frame_json_b, conf=config_params)

    # 初始化原户型和改后户型的FrameObj对象,以及FrameDiffEval对象, 调用cal_related_room()函数计算吃掉对面的谁和被对面的谁吃掉
    params_dict = {'features': features_a, 'features_opposite': features_b, 'id_opposite': f_2, 'frame_label': entity_frame_a.frame_label, 'without_http': False}
    frame_a = room_factory.FrameObj(frame_a_2, params_dict)
    frame_a.cal_related_room(config_params['mod_eval_conf']['reform_docs'])
    params_dict = {'features': features_b, 'features_opposite': features_a, 'id_opposite': f_1, 'frame_label': entity_frame_b.frame_label, 'without_http': False}
    frame_b = room_factory.FrameObj(frame_b_2, params_dict)
    frame_b.cal_related_room(config_params['mod_eval_conf']['reform_docs'])
    frame_diff_obj = room_diff.FrameDiffEval(frame_a, frame_b)

    result = frame_diff_obj.generate_str_doc(config_params)
    result.img_path = _all_pic_path
    result.match_diff = _match_diff
    return result


def case_study(f_1, f_2, config_params, generate_md=False):
    generate_reform_json(f_1, f_2, config_params, generate_md)


def md_batch(config_params):
    config_params['md_batch'] = 1
    if os.path.exists('data/reform_doc_pic/md/100.md'):
        os.remove('data/reform_doc_pic/md/100.md')

    batch_file = 'data/reform_doc_pic/batch_file/try2.txt'
    f = open(batch_file, 'r')
    frame_list = f.readlines()
    for _index, _str in enumerate(frame_list):
        f_1, f_2 = _str.split('\n')[0].split(' ')
        config_params['md_batch_index'] = _index + 1
        case_study(f_1, f_2, config_params, generate_md=True)
        print(f_1, f_2)
    f.close()
    pass


def generate_reform_json_without_http(f_1, f_2, frame_json_a, frame_json_b, config_params):
    # frame_diff里面计算两户型的分间、墙体、附件的diff主流程
    frame_a = ent.FrameStdVecObj(frame_json_a, frame_id=f_1)
    frame_b = ent.FrameStdVecObj(frame_json_b, frame_id=f_2)
    frame_a_2, frame_b_2, status_diff = FD.frame_diff(frame_a, frame_b)

    # 接收frame_diff的状态值,如果小于0则代表无法正常旋转,直接返回,否则就继续运行
    if status_diff < 0:
        return ['', '', status_diff, json.dumps(frame_a_2.dump([]))]

    # 提取户型f_1和f_2的面宽、进深等特征, case_study使用的是frame_diff里的
    features_a, result_1 = extract_basic_features(f_1, config_params)
    features_b, result_2 = extract_basic_features(f_2, config_params)
    try:
        if features_a == '' or features_b == '':
            raise Exception("frame features is an empty string")
    except Exception as e:
        print(repr(e))
    entity_frame_a, eval_result_a = FD.extract_single_frame_feature(f_1, frame_json_a, conf=config_params)
    entity_frame_b, eval_result_b = FD.extract_single_frame_feature(f_2, frame_json_b, conf=config_params)

    # 初始化原户型和改后户型的FrameObj对象,以及FrameDiffEval对象, 调用cal_related_room()函数计算吃掉对面的谁和被对面的谁吃掉
    params_dict = {'features': features_a, 'features_opposite': features_b, 'id_opposite': f_2,
                   'frame_label': entity_frame_a.frame_label, 'without_http': True}
    frame_a = room_factory.FrameObj(frame_a_2, params_dict)
    frame_a.cal_related_room(config_params['mod_eval_conf']['reform_docs'])
    params_dict = {'features': features_b, 'features_opposite': features_a, 'id_opposite': f_1,
                   'frame_label': entity_frame_b.frame_label, 'without_http': True}
    frame_b = room_factory.FrameObj(frame_b_2, params_dict)
    frame_b.cal_related_room(config_params['mod_eval_conf']['reform_docs'])
    frame_diff_obj = room_diff.FrameDiffEval(frame_a, frame_b)

    result = frame_diff_obj.generate_json_without_http(config_params)
    result.append(json.dumps(frame_a.dump([])))
    return result


def reform_docs_main_without_http(f_1, f_2, json_1, json_2, config_params):
    """
    第一阶段
    :param f_1: 改造前户型id
    :param f_2: 改造后户型id
    :param json_1: 改造前户型json
    :param json_2: 改造后户型json
    :param config_params: 外部调控参数字典
    :return: 户改报告(中间过程)全量表data_mining_frame_mod_report_inter_da对应的参数字典(共9个key,frame_id、after_frame_id、
    status、score、report、short_report、detail_info、after_frame_json、is_valid(设置成了固定值1))
    """
    docs_json = generate_reform_json_without_http(f_1, f_2, json_1, json_2, config_params)
    result_dict = dict()
    # 返回列表：包括改造前后id、打分、长短文案、是否有效、状态值
    result_dict['frame_id'] = f_1
    result_dict['after_frame_id'] = f_2
    result_dict['score'] = 0
    result_dict['is_valid'] = 1
    result_dict['status'] = docs_json[2]
    result_dict['after_frame_json'] = docs_json[3]
    if docs_json[2] < 0:
        result_dict['detail_info'] = json.dumps(dict())
        result_dict['is_valid'] = 0
        return result_dict

    http_params = dict()
    docs_dict = json.loads(docs_json[1])
    for _room in docs_dict['room_list']:
        _room_dict_tmp = dict()
        for _reform_point in _room['reform_point']:
            _room_dict_tmp[_reform_point['reform_id']] = {"polygons_a": _reform_point['ori_reform_img_url'],
                                                     "polygons_b": _reform_point['aft_reform_img_url'],
                                                     "celltype": _reform_point['layout_suggest_param'][0],
                                                     "label": _reform_point['layout_suggest_param'][1]}
        http_params[_room['area_id']] = _room_dict_tmp
    _room_dict_tmp = dict()
    _room_dict_tmp[-1] = {"polygons_a": list(), "polygons_b": docs_dict["frame_after"]["img_url"], "celltype": '', "label": ''}
    http_params['all'] = _room_dict_tmp
    result_dict['detail_info'] = json.dumps(http_params)
    # 清空无用的report坐标
    report_dict = json.loads(docs_json[1])
    short_report_dict = json.loads(docs_json[0])
    report_dict['frame_after']['img_url'] = list()
    short_report_dict['frame_after']['img_url'] = list()
    result_dict['short_report'] = json.dumps(short_report_dict)

    for _room in report_dict['room_list']:
        for _reform_point in _room['reform_point']:
            _reform_point['aft_reform_img_url'] = list()
            _reform_point['ori_reform_img_url'] = list()

    result_dict['report'] = json.dumps(report_dict)
    return result_dict


def draw_all_img_with_http(f_1, f_2, json_1, json_2, detail_info_json, config_params):
    """
    第二阶段
    :param f_1: 改造前户型id
    :param f_2: 改造后户型id
    :param json_1: 改造前户型旋转后的json
    :param json_2: 改造后户型json
    :param detail_info_json: 第一阶段户改报告(中间过程)全量表的detail_info键值对应的json字符串
    :param config_params: 外部调控参数字典
    :return: 户改报告图示表data_mining.data_mining_frame_mod_image_da对应的参数字典(共7个key值,frame_id、after_frame_id、
    area_id、reform_id、before_flag、url、is_valid)
    """
    detail_info = json.loads(detail_info_json)
    frame_1_dict = json.loads(json_1)
    frame_2_dict = json.loads(json_2)
    result = list()
    draw_img_config = config_params['mod_eval_conf']['draw_img']
    for _key, _value in detail_info.items():
        for _reform_id, _polygon_dict in _value.items():
            _dict_tmp = dict()
            _dict_tmp['frame_id'] = f_1
            _dict_tmp['after_frame_id'] = f_2
            _dict_tmp['area_id'] = _key
            _dict_tmp['reform_id'] = _reform_id
            _dict_tmp['is_valid'] = 1
            _dict_tmp['before_flag'] = 0
            frame_2_dict['floorplans'][0]['polygons'] = detail_info[_key][_reform_id]["polygons_b"]
            data_result = ImgTools.draw_json(frame_2_dict, show=False, url=draw_img_config['draw_json_url'])
            _dict_tmp['url'] = json.dumps(data_result[0])
            result.append(copy.deepcopy(_dict_tmp))

            _dict_tmp['before_flag'] = 1
            frame_1_dict['floorplans'][0]['polygons'] = detail_info[_key][_reform_id]["polygons_a"]
            data_result = ImgTools.draw_json(frame_1_dict, show=False, url=draw_img_config['draw_json_url'])
            _dict_tmp['url'] = json.dumps(data_result[0])
            result.append(copy.deepcopy(_dict_tmp))

    return result


def fill_complete_docs(reform_dict_without_img, img_url_dict_list):
    """
    :param reform_dict_without_img: 第一阶段的字典结果,对应到数据表一中的某一行,表示针对某一对原改户型生成的无图文案和一些附属信息
    :param img_url_dict_list: 第二阶段的列表结果,对应到数据表二中的若干行,表示某一对原改户型对应的若干图片url字典组成的列表
    :return: 户改报告全量表data_mining.data_mining_frame_mod_report_da,对应的参数字典(共7个key值,frame_id、after_frame_id、
    status、score、report、short_report、is_valid)
    """
    f_1 = reform_dict_without_img['frame_id']
    f_2 = reform_dict_without_img['after_frame_id']
    short_report_dict = json.loads(reform_dict_without_img['short_report'])
    report_dict = json.loads(reform_dict_without_img['report'])
    # 添加原户型url的key、改户型和改造点url、布局建议和图片
    _dict_total = dict()
    for _image_data in img_url_dict_list:
        _str_tmp = '{}_{}_{}_{}_{}'.format(f_1, f_2, _image_data['area_id'],
                                           str(_image_data['before_flag']), str(_image_data['reform_id']))
        _dict_total[_str_tmp] = json.loads(_image_data['url'])
    _is_valid = 1
    # 原户型url
    _str_tmp = '{}_{}_{}_{}_{}'.format(f_1, f_2, 'all', str(1), str(-1))
    if _str_tmp not in _dict_total:
        _is_valid = 0
    short_report_dict['frame_origin']['img_url'] = _dict_total.get(_str_tmp, dict())
    report_dict['frame_origin']['img_url'] = _dict_total.get(_str_tmp, dict())
    # 改户型url
    _str_tmp = '{}_{}_{}_{}_{}'.format(f_1, f_2, 'all', str(0), str(-1))
    if _str_tmp not in _dict_total:
        _is_valid = 0
    short_report_dict['frame_after']['img_url'] = _dict_total.get(_str_tmp, '')
    report_dict['frame_after']['img_url'] = _dict_total.get(_str_tmp, dict())
    # 长报文改造点图文匹配
    for _room in report_dict['room_list']:
        for _reform_point in _room['reform_point']:
            _str_tmp = '{}_{}_{}_{}_{}'.format(f_1, f_2, _room['area_id'], str(1), str(_reform_point['reform_id']))
            _reform_point['ori_reform_img_url'] = _dict_total.get(_str_tmp, dict())
            if _str_tmp not in _dict_total:
                _is_valid = 0
            _str_tmp = '{}_{}_{}_{}_{}'.format(f_1, f_2, _room['area_id'], str(0), str(_reform_point['reform_id']))
            _reform_point['aft_reform_img_url'] = _dict_total.get(_str_tmp, dict())
            if _str_tmp not in _dict_total:
                _is_valid = 0

            suggestPoints, layoutImageUrl = DocsGenerator.generate_reform_suggest(_reform_point['layout_suggest_param'][0], _reform_point['layout_suggest_param'][1])
            _reform_point['layout_suggest'] = suggestPoints
            _reform_point['layout_suggest_img_url'] = layoutImageUrl
            _reform_point.pop('layout_suggest_param')

            suggestPoints, layoutImageUrl = DocsGenerator.generate_reform_suggest(_reform_point['reform_influence_img_url'][0], _reform_point['reform_influence_img_url'][1])
            suggestPoints = _reform_point['reform_influence_img_url'][2] + suggestPoints
            _reform_point['reform_influence'] = suggestPoints
            _reform_point['reform_influence_img_url'] = layoutImageUrl

    # 结果填充
    result_dict = dict()
    result_dict['report'] = json.dumps(report_dict)
    result_dict['short_report'] = json.dumps(short_report_dict)
    result_dict['frame_id'] = f_1
    result_dict['after_frame_id'] = f_2
    result_dict['status'] = reform_dict_without_img['status']
    result_dict['score'] = reform_dict_without_img['score']
    result_dict['is_valid'] = _is_valid
    if _is_valid == 0:
        raise Exception("原改户型{} - {}图片没有都画出来".format(f_1, f_2))
    return result_dict


def case_study_first_second_period(frameid_1='1116895714014035', frameid_2='1120040115173614'):
    json_a, json_b = diff_util.download_frame_json([frameid_1, frameid_2], with_json=False)

    # 第一阶段,通过两户型id、两户型json和调控参数获取户改报告(中间过程)全量表参数字典result1
    result1 = reform_docs_main_without_http(frameid_1, frameid_2, json_a, json_b, conf_params1)

    # 第二阶段,通过两户型id、旋转后的原户型json、改户型json、第一阶段表的detial_info信息、外部调控参数来获取户改报告图示表的参数字典列表result2
    result2 = draw_all_img_with_http(frameid_1, frameid_2, result1['after_frame_json'], json_b, result1['detail_info'], conf_params1)

    # 第三阶段,通过一阶段的无图文案和第二阶段查表得到的图片url字典列表,生成户改报告全量表参数字典
    complete_reform_data = fill_complete_docs(result1, result2)
    pass


def generate_pair():
    frame_pairs_df = pd.read_table('data/aigc/frame_pairs_1130.tsv')
    res_list = []
    # generate_reform_text_img_pair('11000003313871', '1115737174658236',  conf_params1, generate_md=True)
    for _row in frame_pairs_df.itertuples():
        try:
            tmp_result = generate_reform_text_img_pair(str(_row.frame_id), str(_row.after_frame_id), conf_params1,
                                                       generate_md=True)
            _ret_row = [_row.frame_id, _row.after_frame_id, tmp_result.match_diff,
                        tmp_result.file_write_obj.replace('\n', ''), tmp_result.img_path]
            print(_ret_row)
            res_list.append(_ret_row)
            # break
        except:
            print(traceback.print_stack())
        # break
    res_df = pd.DataFrame(data=res_list, columns=['frame_id', 'after_frame_id', 'match_diff', 'docs', 'img_path'])
    res_df.to_csv('data/aigc/all_dataset_1130.tsv', sep='\t', index=False, encoding='utf-8', )
    # quoting=csv.QUOTE_NONE, ) # 去除多余的引号


DIM5 = {"A": "实用性", "B": "便捷性", "C": "空间利用", "D": "舒适性", "E": "私密性"}
VALUE_POINT = {
    'A': {
        '6': ('主卧面积合理',),  # 主卧窗地比
        # '7': ('主卧窗地比合理',),  # 主卧窗地比
        '8': ('次卧面积合理',),  # 主卧窗地比
        # '9': ('次卧窗地比合理',),  # 主卧窗地比
        # '11': ('客厅窗地比合理',),  # 客厅窗地比
        # '13': ('厨房面宽', ':'),  # 厨房面宽
        # '14': ('厨房进深', ':'),  # 厨房进深
        # '19': ('厨房窗地比', ':'),  # 厨房窗地比
    },
    'B': {
        # '0': ('动线无交叉', ':'),  # 厨房窗地比
        '2': ('餐客相连', ),  # 餐客相连
        '3': ('厨近入户门', ),  # 厨近入户门
        '4': ('餐厨相连', ),  # 餐厨相连
        '6': ('厨带阳台', ),  # 厨带阳台
        '7': ('两卧相连', ),  # 两卧相连
    },
    'C': {
        # '0': ('方正系数', ':'),  # 方正 0~2
        '1': ('厅有阳台', ),
        '2': ('卧有阳台', ),
        # '3': ('卧室灰区', ),
        '7': ('卧有凸窗', ),
        '8': ('厅有凸窗', ),
    },
    'D': {
        '0': {'1': '对侧通透', '2': '临侧通透', '4': '单侧通透'},
        '2': ('厨卫不对门', ),
        '3': ('干湿分离', ),
        '4': ('卧室有独卫', ),
        '5': ('卧带衣帽间/储物间',),
        '6': ('厅面宽进深合理',),
        '7': ('卧面宽进深合理',),
        '15': ('明卫',),
    },
    'E': {
        '1': ('门厅', ),
        '2': ('卫不对入户门', ),
        '3': ('卧室不对视', ),
        '5': ('可视域', ":"),
    },
}


def generate_single_frame_row(_row):
    # try:
    score_dict = json.loads(_row['check_point'])
    _frame_json = json.loads(_row['frame_json'])

    _row_str_list = []
    for d in DIM5:
        pre_d_json = score_dict.get("check_point", {}).get(d, {})
        _dim_name = DIM5[d]
        _row_kv_list = []
        _k_v_params = VALUE_POINT[d]
        for _dim_k in _k_v_params:
            _row_kv_str = ''
            if _dim_k not in pre_d_json:
                continue
            _v_template = _k_v_params[_dim_k]
            _all_value = pre_d_json[_dim_k]
            if type(_v_template) == dict:
                # 需要翻译的key
                _row_kv_str = _v_template[str(int(_all_value[0][0]))]
            elif type(_v_template) == tuple:
                # 不需要翻译的key
                _temp_len = len(_v_template)
                if _temp_len == 1 and _all_value[0] is not None:
                    _real_value = _all_value[0]
                    _target_v = _all_value[1]
                    if type(_real_value) == list:
                        _real_value = _all_value[0][0]
                    if int(_target_v) == int(_real_value):
                        _row_kv_str = _v_template[0]
                elif _temp_len == 2:
                    _row_kv_str = _v_template[0] + _v_template[1] + str(round(_all_value[-2], 2))
            if _row_kv_str:
                _row_kv_list.append(_row_kv_str)
        if _row_kv_list:
            _row_str_list.append(_dim_name + ':' + ','.join(_row_kv_list))
    _label_str = ';'.join(_row_str_list)

    frame_a = ent.FrameStdVecObj(_frame_json, frame_id=_row.frame_id)
    room_counter = Counter(frame_a.room_type_list).most_common()
    room_desc_str = ''
    for _room_type, _cnt in room_counter:
        room_desc_str += f"{_cnt}个{_room_type}"
    layout_desc = ','.join(frame_a.room_relation_dict.values())
    _img_path, _img_dict = display_frame_single(frame_a)
    _union_str = f'这是一张平面户型图,它有{room_desc_str}.布局是{layout_desc}.特点是:{_label_str}'
    print(f'frame_id:{_row.frame_id}', _union_str)
    # res_list.append([_row.frame_id, _row.res_contour_rept_id, _union_str, _img_path])
    return [_row['frame_id'], _row['res_contour_rept_id'], _union_str, _img_path, json.dumps(_img_dict)]
    # except Exception as ex:
    #     traceback.print_stack()
    #     print(_row['frame_id'], ex)
    #     return []


# 监测点翻译
def generate_single():
    frame_pairs_df = pd.read_table('data/aigc/all_frame_raw_1204.tsv')
    # frame_pairs_df = pd.read_table('data/aigc/single_aigc_frame_data.tsv').sample(frac=0.01)
    frame_pairs_df['frame_id'] = frame_pairs_df['frame_id'].map(str)

    res_list = []
    # generate_single_frame_row(frame_pairs_df.head(1).to_dict())
    # p = Pool(1)
    # generate_reform_text_img_pair('11000003313871', '1115737174658236',  conf_params1, generate_md=True)
    for _idx, _row in frame_pairs_df.iterrows():
        if _row.frame_id not in {'11000000362681'}:
            continue
        result = generate_single_frame_row(_row, )
        # result = p.apply_async(generate_single_frame_row, args=(_row, ))
        res_list.append(result)
    # p.close()
    # p.join()

    ret_result = []
    for res in res_list:
        # result = res.get()
        if result:
            ret_result.append(result)
    res_df = pd.DataFrame(data=ret_result, columns=['frame_id', 'contour_rept_id', 'docs', 'img_path', 'frame_dict'])
    res_df.to_csv('data/aigc/all_dataset_1203.tsv', sep='\t', index=False, quoting=csv.QUOTE_NONE,  # 去除多余的引号
                  encoding='utf-8', )


if __name__ == '__main__':
    conf_params1 = dict()
    conf_params2 = dict()
    conf_params3 = dict()
    conf_params4 = dict()
    tag_utils.collect_conf(r"config/mod_eval_conf.yml", conf_params1)
    tag_utils.collect_conf(r"frame_eval/frame_tag_lib/conf.yml", conf_params2)
    tag_utils.collect_conf(r"frame_mod_eval/reform_docs.yml", conf_params3)
    # 户型标签/ config / show_conf.yml
    tag_utils.collect_conf(r"config/show_conf.yml", conf_params4)
    conf_params1.update(conf_params2)
    conf_params1.update(conf_params3)
    conf_params1.update(conf_params4)
    generate_single()

    # frame_pairs_df = pd.read_table('data/aigc/raw_frame_pairs_1130.tsv')
    # frame_pairs_df = pd.read_table('data/aigc/frame_pairs_1130.tsv').sample(frac=0.001)

    # case_study_first_second_period(frameid_1='11000003313871', frameid_2='1115737174658236')
    # md_batch(conf_params1)
    """
    conf_params1['md_batch'] = 1
    f = open('data/reform_doc_pic/batch_file/try2.txt', 'r')
    frame_list = f.readlines()
    for _index, _str in enumerate(frame_list):
        f_1, f_2 = _str.split('\n')[0].split(' ')
        conf_params1['md_batch_index'] = _index + 1
        case_study_first_second_period(frameid_1=f_1, frameid_2=f_2)
        print(f_1, f_2)
    f.close()
    """
    pass
