# coding=utf-8

from __future__ import division
from __future__ import print_function

import os
import sys
import yaml

PLOT = False
USE_SYMPY = True

setting_path = os.path.realpath(__file__)
setting_path = os.path.dirname(setting_path)

import pkg_resources

get_module_res = lambda *res: pkg_resources.resource_stream(__name__, os.path.join(*res))

f = get_module_res("config/frame_json.yaml")
FRAME_KEY = yaml.full_load(f)

f = get_module_res("config/rule_para.yml")
RULE_PARAM = yaml.full_load(f)

f = get_module_res("config/label_key.yml")
LABEL_KEY = yaml.full_load(f)

f = get_module_res("config/doc.yml")
DOC = yaml.full_load(f)

# frame_config = os.path.join(setting_path, "config/frame_json.yaml")
# with open(frame_config, "r") as f:
#     # with open("config/frame_json.yaml", "r") as f:
#     FRAME_KEY = yaml.load(f, Loader=yaml.FullLoader)

# para_config = os.path.join(setting_path, "config/rule_para.yml")
# with open(para_config, "r") as f:
#     RULE_PARAM = yaml.load(f, Loader=yaml.FullLoader)
#
# para_config = os.path.join(setting_path, "config/label_key.yml")
# with open(para_config, "r") as f:
#     LABEL_KEY = yaml.load(f, Loader=yaml.FullLoader)
#
# para_config = os.path.join(setting_path, "config/doc.yml")
# with open(para_config, "r") as f:
#     DOC = yaml.load(f, Loader=yaml.FullLoader)

# para_config = os.path.join(setting_path, "config/rule_para.json")
# RULE_PARAM = common.Params(para_config)

if not USE_SYMPY:
    from geometry.point import Point2D
    from geometry.line import Line2D, Segment2D
    from geometry.polygon import Polygon
    from geometry.settings import pi
    from geometry.line import Ray2D
else:
    from sympy.geometry.point import Point2D
    from sympy.geometry.line import Line2D, Segment2D
    from sympy.geometry.polygon import Polygon
    from sympy.core import pi
    from sympy.geometry.line import Ray2D

HALLWAY_RES_CONTOURS = "contours"
HALLWAY_RES_CAB_LAY = "lay"
HALLWAY_RES_RIGHT_SIDE_LAY = "right_side_lay"
HALLWAY_RES_LEFT_SIDE_LAY = "left_side_lay"
HALLWAY_RES_RIGHT_VERT_LAY = "right_vertical_lay"
HALLWAY_RES_LEFT_VERT_LAY = "left_vertical_lay"
HALLWAY_RES_FACE_LAY = "face_lay"
HALLWAY_RES_CABINETS = "cabinets"
HALLWAY_RES_SPACE = "space_analysis"
HALLWAY_RES_LAYOUT_DOC = "layout_doc"
HALLWAY_RES_REMOULD = "remould"

FURNITURE_CONTOURS = "contours"
FURNITURE_BASELINE = "baseline"

RES_ERROR = "error_code"
RES_FLOOR = "floor"
RES_AREA_ID = "area_id"
RES_REMOULD = "remould"
RES_SPACE = "space_analysis"
RES_DECORATION = "decoration"
RES_CONTOURS = "contours"
RES_WIDTH = "width"
RES_DEPTH = "depth"
RES_WIDTH_PTS = "width_ps"
RES_DEPTH_PTS = "depth_ps"
RES_FURNITURE = "furniture"

ROOMTYPE_HALLWAY = "hallway"
ROOMTYPE_MASTER_BEDROOM = "main_room"
ROOMTYPE_LIVINGROOM = "livingroom"


debug_var = None
