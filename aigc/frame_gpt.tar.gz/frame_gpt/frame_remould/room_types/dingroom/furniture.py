# coding=utf-8

import matplotlib.path as mpath
import matplotlib.patches as mpatches

from frame_remould.room_types.furniture import Furniture
import frame_remould.settings as settings


class DiningChair(Furniture):
    name = settings.LABEL_KEY["furniture"]["dingroom"]["dining_chair"]["name"]
    type = settings.LABEL_KEY["furniture"]["dingroom"]["dining_chair"]["type_id"]

    def __init__(self, baseline, depth):
        super(DiningChair, self).__init__(baseline, depth)


class SquareDiningTable(Furniture):
    name = settings.LABEL_KEY["furniture"]["dingroom"]["square_dining_table"]["name"]
    type = settings.LABEL_KEY["furniture"]["dingroom"]["square_dining_table"]["type_id"]

    def __init__(self, baseline, depth):
        super(SquareDiningTable, self).__init__(baseline, depth)


class RoundDiningTable(Furniture):
    name = settings.LABEL_KEY["furniture"]["dingroom"]["round_dining_table"]["name"]
    type = settings.LABEL_KEY["furniture"]["dingroom"]["round_dining_table"]["type_id"]

    def __init__(self, baseline, depth):
        super(RoundDiningTable, self).__init__(baseline, depth)


class SideCabinet(Furniture):
    name = settings.LABEL_KEY["furniture"]["dingroom"]["side_cabinet"]["name"]
    type = settings.LABEL_KEY["furniture"]["dingroom"]["side_cabinet"]["type_id"]

    def __init__(self, baseline, depth):
        super(SideCabinet, self).__init__(baseline, depth)

