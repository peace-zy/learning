# coding=utf-8


class DingRoom(object):
    def __init__(self):
        self.furniture_list = []
