# coding=utf-8

import frame_remould.settings as settings
from frame_remould.utils import geo_utils

from frame_remould.settings import FRAME_KEY
from frame_remould.settings import RULE_PARAM


def get_door_connect_region(door, floorplan):
    regions = []
    for rid, r in floorplan.id_regions.items():
        items_ids = list(r.id_wall_items.keys())
        if door.id in items_ids:
            regions.append(r)
    return regions


def get_entrance_door(floorplan, region):
    """
    配置进入功能区的门
    1. 被指定了入户门的门
    2. 相邻门最多的空间
    """
    doors = region.get_doors()
    if len(doors) == 0:
        return None

    for d in doors:
        if d.entrance is not None:
            entrance_door = d
            return entrance_door

    most_doors_reg = None
    most_doors = []
    max_doors = 0
    for adj_reg_id in region.adjacent_region_id:
        reg = floorplan.id_regions[adj_reg_id]
        reg_doors = reg.get_doors()
        if len(set(reg_doors).intersection(set(doors))) == 0:
            continue
        if len(reg_doors) > max_doors:
            most_doors = reg_doors
            # most_doors_reg = reg
            max_doors = len(reg_doors)

    entrance_door = list(set(doors).intersection(set(most_doors)))[0]
    return entrance_door


def get_main_window_wall_in_one_door_room(max_rec, entrance_door, region):
    """
    假设功能区只有一个进入的门，没有窗户，得到主窗所在的墙ID
    用内含最大矩形中点，和短边平行的线切割区域
    和门相反一边的最长墙是主窗墙
    """
    main_window_wall_id = None
    center = max_rec.centroid
    dr_pt = entrance_door.segment2d.midpoint
    # 通常窗户都是在矩形较短的一边
    short_side = sorted(max_rec.sides, key=lambda s: s.length)[0]
    short_side_xy = geo_utils.get_line_x_y_dir(short_side)

    center_p2 = center + short_side.direction.unit * 20
    center_line = settings.Line2D(center, center_p2)

    dr_pro = center_line.projection(dr_pt)
    dr_cen_dir = settings.Line2D(dr_pro, dr_pt).direction.unit

    win_walls = []
    for wid, w in region.id_walls.items():
        wpt = w.segment2d.midpoint
        wproj = center_line.projection(wpt)
        w_xy = geo_utils.get_line_x_y_dir(w.segment2d)
        if geo_utils.is_perpendicular(w_xy, short_side_xy):
            continue
        wdir = settings.Line2D(wproj, wpt).direction.unit
        if wdir == dr_cen_dir:
            continue
        win_walls.append(w)
    win_wall = sorted(
        win_walls,
        key=lambda w: w.segment2d.length,
        reverse=True
    )[0]
    return win_wall.id


def get_width_depth_line(rectangle, width_line):
    """
    面宽进深的两条线
    """
    center = rectangle.centroid
    xaxis, yaxis = geo_utils.get_axis4rectangle(rectangle)
    center_lines = [
        settings.Line2D(center, center + xaxis.direction.unit * 100),
        settings.Line2D(center, center + yaxis.direction.unit * 100)
    ]
    width_wall_xy = geo_utils.get_line_x_y_dir(width_line, xaxis=xaxis)

    width_pts, depth_pts = None, None
    for cline in center_lines:
        inter = rectangle.intersection(cline)
        if len(inter) != 2:
            raise RuntimeError("master bedroomm width and depth failed !!!")
        if geo_utils.is_parallel(cline, width_wall_xy):
            width_pts = inter
        else:
            depth_pts = inter
    return width_pts, depth_pts


def get_baseline(start_pt, length, line, ccw=False):
    """
    根据起始点，家具宽度， 靠墙的线， 方向
    返回baseline，并更新起始点
    """
    p1 = start_pt
    fur_dir = line.direction.unit if ccw == False else line.direction.unit * (-1)
    p2 = p1 + fur_dir * length

    if ccw is False:
        baseline = settings.Line2D(p1, p2)
    else:
        baseline = settings.Line2D(p2, p1)
    start_pt = p2
    return baseline, start_pt


def get_baseline_p12(p1, p2, line):
    lp12 = settings.Line2D(p1, p2)
    if geo_utils.is_same_direction(line, lp12):
        return lp12
    else:
        return settings.Line2D(p2, p1)


def get_furniture_depth(furnitures, width):
    depths = []
    for f in furnitures:
        if f[0] == width:
            depths.append(f[1])
    return depths


def get_ccw_line_start_p12(line, p12):
    if p12 == line.p1:
        return False
    else:
        return True


def get_baseline_along_line(line, width, start_pt, ccw):
    """
    返回baseline
    """
    baseline_dir = line.direction.unit * (-1) if ccw else line.direction.unit
    end_pt = start_pt + baseline_dir * width
    if ccw:
        baseline = settings.Line2D(end_pt, start_pt)
    else:
        baseline = settings.Line2D(start_pt, end_pt)
    return baseline


def get_length_along_line(line, width, start_pt, ccw, inner_region):
    """
    沿着内墙找到最近的距离
    line: 内墙之一
    返回baseline
    """
    length_dir = line.direction.unit * (-1) if ccw else line.direction.unit
    norm_dir = geo_utils.get_normal_dir(line)
    end_pt = start_pt + length_dir * 10
    spt2 = start_pt + norm_dir * width
    ept2 = spt2 + length_dir * 10
    length_ray1 = settings.Ray2D(start_pt, end_pt)
    length_ray2 = settings.Ray2D(spt2, ept2)

    def get_length(length_ray1, length_ray2, item, length):
        line_2ray = settings.Line2D(length_ray1.p1, length_ray2.p2)
        item_pro_seg = settings.Segment2D(
            line_2ray.projection(item.segment2d.p1),
            line_2ray.projection(item.segment2d.p2)
        )
        ray_seg = settings.Segment2D(
            length_ray1.p1,
            length_ray2.p2
        )

        if type(item_pro_seg) == settings.Segment2D and len(ray_seg) > RULE_PARAM["projection_length"]:
            inters = item_pro_seg.intersection(ray_seg)
            if len(inters) == 0:
                return 999999
            else:
                leng = length - RULE_PARAM["master"]["draw_back"]
                return leng
        elif type(item_pro_seg) == settings.Point2D:
            inters1 = length_ray1.intersection(item.segment2d)
            leng = inters1[0].distance(length_ray1.p1) - 50
            return leng
        elif len(ray_seg) < RULE_PARAM["projection_length"]:
            inters1 = length_ray1.intersection(item.segment2d)
            if len(inters1) == 0:
                return 9999999
            leng = inters1[0].distance(length_ray1.p1) - 50
            return leng

        # inters1 = length_ray1.intersection(item.segment2d)
        # inters2 = length_ray2.intersection(item.segment2d)
        #
        # if len(inters1) == 0 and len(inters2) == 0
        #     return 999999
        # if len(inters2) != 0:
        #     leng = length - RULE_PARAM["master"]["draw_back"]
        #     return leng
        # if len(inters1) != 0:
        #     leng = inters1[0].distance(length_ray1.p1) - 50
        #     return leng

    length = geo_utils.get_nearest_pt_ray2inner(
        length_ray1, inner_region
    )
    length0 = length
    for k, it in inner_region.id_items.items():
        leng = get_length(length_ray1, length_ray2, it, length)
        if leng < length0:
            length0 = leng

    # 距离不能大于所在墙长度，碰到内角会出现这种情况
    dis = line.p1.distance(line.p2)
    if length0 > dis:
        length0 = dis
    end_pt = start_pt + length_dir * length0
    if ccw:
        baseline = settings.Line2D(end_pt, start_pt)
    else:
        baseline = settings.Line2D(start_pt, end_pt)
    return baseline


def is_lineitem_furniture_intersection(item_seg, fur):
    """
    判断家具和门窗的线是否有相交
    """
    poly = fur.get_polygon()
    inters = poly.intersection(item_seg)

    if len(inters) == 0:
        return False
    else:
        return True

