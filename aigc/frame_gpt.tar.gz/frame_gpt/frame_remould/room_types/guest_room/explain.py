# coding=utf-8
import numpy as np
import pandas as pd

from frame_remould.settings import FRAME_KEY
from frame_remould.settings import RULE_PARAM
from frame_remould.settings import LABEL_KEY

from frame_remould.utils import extract_rect
import frame_remould.room_types.master_bedroom as master_bedroom


class Guestroom(object):
    def __init__(self):
        self._region = None
        self._floorplan = None
        self._max_rectangle = None
        self._inner_region = None

        self.width_pts = None
        self.width = None
        self.depth_pts = None
        self.depth = None

        self.furniture_df = None

    def initial(self):
        self.set_max_rectangle()
        self.furniture_df = self.get_furniture_table()

    @property
    def region(self):
        return self._region

    def set_region(self, region):
        self._region = region

    def set_max_rectangle(self):
        recs = extract_rect.extract_all_max_rec(
            self.region.inner_region.polygon
        )
        self._max_rectangle = recs[0]

    def get_furniture_table(self):
        furniture_sizes = RULE_PARAM["guest"]["furniture"]
        furniture_types = LABEL_KEY["furniture"]["guest"]
        data = dict()
        cnt = 0
        for fur_type, v in furniture_types.items():
            for size in furniture_sizes[fur_type]:
                width = size[0]
                depth = size[1]
                data[cnt] = [width, depth, fur_type, v["type_id"], v["name"]]
                cnt += 1
        df = pd.DataFrame(
            data=data,
            index=["width", "depth", "type", "type_id", "name"]
        )
        df = df.stack().unstack(0)
        return df


def get_guest_rooms(floorplan):
    master = master_bedroom.explain.get_master_bedroom(floorplan)
    bedroom_types = [
        FRAME_KEY["regions"]["type_id"]["bedroom"],
        FRAME_KEY["regions"]["type_id"]["master_bedroom"],
        FRAME_KEY["regions"]["type_id"]["guest_bedroom"]
    ]
    guestrooms = []
    for k, reg in floorplan.id_regions.items():
        room_type = reg.room_type
        if room_type not in bedroom_types:
            continue
        g = Guestroom()
        g.set_region(reg)
        guestrooms.append(g)

    if len(guestrooms) == 0:
        return []

    for g in guestrooms:
        if master.region == g.region:
            guestrooms.remove(g)

    return guestrooms

