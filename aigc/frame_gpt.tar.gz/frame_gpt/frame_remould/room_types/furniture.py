# coding=utf-8
import matplotlib.patches as mpatches
from matplotlib.collections import PatchCollection
import numpy as np

import frame_remould.utils.geo_utils as geo_utils
import frame_remould.settings as settings
from frame_remould.settings import RULE_PARAM
from frame_remould.settings import DOC
from frame_remould.settings import LABEL_KEY


class Furniture(object):
    type = -1
    name = ""
    def __init__(self, baseline, depth):
        self._width = None
        self._normal = None
        self._depth = depth
        self._baseline = None
        self._wall_id = None

        self._plt_anchor = None
        self._plt_angle = 0

        self.set_baseline(baseline)

    @property
    def wall_id(self):
        return self._wall_id

    @property
    def baseline(self):
        return self._baseline

    @property
    def line2d(self):
        return self._baseline

    @property
    def width(self):
        return self._width

    @property
    def depth(self):
        return self._depth

    @property
    def normal(self):
        return self._normal

    def set_normal_line(self, ref_line):
        """
        慎用，有时候会出现柜体和相邻墙不垂直情况，夹角较大（2.X度），无法找到重合线段时候用
        """
        line_normal = settings.Line2D(settings.Point2D(0, 0), self._normal)
        angle = np.rad2deg(float(line_normal.smallest_angle_between(ref_line)))
        assert angle < RULE_PARAM["parallel_angle_max"], "与原始法线角度差异大于{}度".format(RULE_PARAM["parallel_angle_max"])
        if geo_utils.is_same_direction(line_normal, ref_line):
            self._normal = ref_line.direction.unit
        else:
            self._normal = ref_line.direction.unit * (-1)

    def set_baseline(self, baseline):
        """
        baseline: Ling2d
        """
        self._width = float(baseline.p1.distance(baseline.p2))
        self._normal = geo_utils.get_normal_dir(baseline)
        self._baseline = baseline
        self._plt_anchor = (baseline.p2.x, baseline.p2.y)
        # TODO: ptl_angle 角度计算需要检验正确性
        normal_ray = settings.Ray2D(baseline.p1, baseline.p1 + self._normal)
        y_dir = settings.Ray2D(settings.Point2D(0, 0), settings.Point2D(0, 1))
        self._plt_angle = np.rad2deg(float(normal_ray.closing_angle(y_dir)))

    def set_depth(self, depth):
        self._depth = depth

    def set_width(self, width, fixed_pt):
        """
        改变家具面宽，必须在设置baseline之后；同时指定固定点是哪一个
        """
        if fixed_pt == self._baseline.p1:
            dir = self._baseline.direction.unit
            pt1 = self._baseline.p1
            pt2 = pt1 + dir * width
            self.set_baseline(settings.Line2D(pt1, pt2))
        elif fixed_pt == self._baseline.p2:
            dir = self._baseline.direction.unit * (-1)
            pt2 = self._baseline.p2
            pt1 = pt2 + dir * width
            self.set_baseline(settings.Line2D(pt1, pt2))
        else:
            assert False, "fixed point MUST be one of the baseline point"

    def set_wall_id(self, wall_id):
        self._wall_id = wall_id

    def get_patches(self):
        patches = []
        rec = mpatches.Rectangle(
            self._plt_anchor,
            self._width,
            self._depth,
            self._plt_angle,
        )
        patches.append(rec)
        return patches

    def get_side_line(self, ref_wall=None):
        # TODO: 有时候柜子边和墙有误差
        normal = self._normal
        if ref_wall is not None:
            pass

        seg1p1 = self._baseline.p1
        seg1p2 = self._baseline.p1 + normal * self._depth
        line1 = settings.Line2D(seg1p1, seg1p2)
        seg2p1 = self._baseline.p2
        seg2p2 = self._baseline.p2 + normal * self._depth
        line2 = settings.Line2D(seg2p1, seg2p2)
        return line1, line2

    def get_polygon(self):
        p1 = self._baseline.p1
        p2 = self._baseline.p2
        p3 = self._baseline.p2 + self._normal * self._depth
        p4 = self._baseline.p1 + self._normal * self._depth
        poly = settings.Polygon(*[p1, p2, p3, p4])
        return poly

    def get_contours(self):
        poly = self.get_polygon().vertices
        poly = [p.args for p in poly]
        return poly

    def get_centroid(self):
        poly = self.get_polygon()
        return poly.centroid

    def get_json_dict(self):
        res = {
            "contours": self.get_contours(),
            "baseline": [p.args for p in self.baseline.points]
        }
        return res


class HallwayCabinet(Furniture):
    name = settings.LABEL_KEY["furniture"]["hallway"]["cabinet"]["name"]
    type = settings.LABEL_KEY["furniture"]["hallway"]["cabinet"]["type_id"]

    def __init__(self, backline, depth):
        super(HallwayCabinet, self).__init__(backline, depth)
        self._lay_kind = None
        self._tag = 1

    @property
    def tag(self):
        return self._tag

    @property
    def lay_kind(self):
        return self._lay_kind

    def set_lay_kind(self, kind):
        # 配置门厅柜摆放类别，共5种
        self._lay_kind = kind

    def set_tag(self, tag):
        # 配置门厅柜类别，定制：0；成品：1
        self._tag = tag

    def get_doc(self, pos_label):
        ana_dict = dict()
        width_d = 20
        depth_d = 20
        width1 = int(self.width / width_d) * width_d
        depth1 = int(self.depth / depth_d) * depth_d
        ana_dict[DOC["hallway"]["cab_width"]] = str(width1)
        ana_dict[DOC["hallway"]["cab_depth"]] = str(depth1)
        # ana_dict[DOC["hallway"]["cab_width"]] = str(width1) + "-" + str(width1 + width_d)
        # ana_dict[DOC["hallway"]["cab_depth"]] = str(depth1) + "-" + str(depth1 + depth_d)
        # ana_dict[DOC["hallway"]["cab_tag"]] = DOC["hallway"]["cab_tag_doc"][self.tag]
        ana_dict[DOC["hallway"]["cab_pos"]] = DOC["hallway"]["cab_pos_doc"][self.lay_kind]
        ana_dict["cab_lay_doc"] = DOC["hallway"]["cab_lay_doc"][self.lay_kind]

        cons = self.get_contours()
        ana_dict[settings.HALLWAY_RES_CONTOURS] = cons
        # ana_dict["custom_volume"] = self.width * self.depth * RULE_PARAM["hallway"]["cab_custom_hight"] / 1000 / 1000
        # ana_dict["custom_volume"] = int(ana_dict["custom_volume"]) / 100 * 100
        # ana_dict["custom_shoes"] = int(ana_dict["custom_volume"] / RULE_PARAM["hallway"]["shoe_volume"]) / 10 * 10
        # ana_dict["manu_volume"] = self.width * self.depth * RULE_PARAM["hallway"]["cab_manufacture_hight"] / 1000 / 1000
        # ana_dict["manu_volume"] = int(ana_dict["manu_volume"]) / 100 * 100
        # ana_dict["munu_shoes"] = int(ana_dict["manu_volume"] / RULE_PARAM["hallway"]["shoe_volume"]) / 10 * 10
        #
        # if self.depth < 250:
        #     doc = DOC["hallway"]["cab_doc_200_250"].format(**ana_dict)
        # else:
        #     doc = DOC["hallway"]["cab_doc"].format(**ana_dict)

        width_thre = 1000
        depth_thre = 300
        doc = DOC["hallway"]["cab_doc"].format(**ana_dict)
        man_shoes = int(width1 * 2 / 260)
        woman_shoes = int(width1 * 2 / 200)
        boots = int(width1 / 200)
        if self.width >= width_thre and self.depth >= depth_thre:
            doc += DOC["hallway"]["cab_doc_g1000_g300"].format(**{
                "man_shoes": man_shoes,
                "woman_shoes": woman_shoes,
                "boots": boots
            })
        elif self.width >= width_thre and self.depth < depth_thre:
            doc += DOC["hallway"]["cab_doc_g1000_l300"]
        elif self.width < width_thre and self.depth >= depth_thre:
            doc += DOC["hallway"]["cab_doc_l1000_g300"]
        else:
            doc += DOC["hallway"]["cab_doc_l1000_g300"]

        ana_dict["cab_doc"] = doc
        ana_dict[settings.FURNITURE_BASELINE] = [p.args for p in self.baseline.points]

        return ana_dict

    def get_json_dict(self):
        fur_dict = dict()
        # poly = self.get_polygon()
        # fur_dict[settings.FURNITURE_CONTOURS] = [p.args for p in poly.vertices]
        # fur_dict[settings.FURNITURE_BASELINE] = [p.args for p in self.baseline.points]

        cab_lay_table = dict(zip(
            LABEL_KEY["hallway"]["cab_lay_kind"].values(),
            LABEL_KEY["hallway"]["cab_lay_kind"].keys()))
        fur_dict[settings.HALLWAY_RES_CAB_LAY] = cab_lay_table[self.lay_kind]
        return fur_dict

