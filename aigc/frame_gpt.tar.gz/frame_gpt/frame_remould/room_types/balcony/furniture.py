# coding=utf-8

import matplotlib.path as mpath
import matplotlib.patches as mpatches

from frame_remould.room_types.furniture import Furniture
import frame_remould.settings as settings


# class SideTable(Furniture):
#     name = settings.LABEL_KEY["furniture"]["balcony"]["sidetable"]["name"]
#     type = settings.LABEL_KEY["furniture"]["balcony"]["sidetable"]["type_id"]
#
#     def __init__(self, baseline, depth):
#         super(SideTable, self).__init__(baseline, depth)


class Chair(Furniture):
    name = settings.LABEL_KEY["furniture"]["balcony"]["chair"]["name"]
    type = settings.LABEL_KEY["furniture"]["balcony"]["chair"]["type_id"]

    def __init__(self, baseline, depth):
        super(Chair, self).__init__(baseline, depth)


class Plants(Furniture):
    name = settings.LABEL_KEY["furniture"]["balcony"]["plants"]["name"]
    type = settings.LABEL_KEY["furniture"]["balcony"]["plants"]["type_id"]

    def __init__(self, baseline, depth):
        super(Plants, self).__init__(baseline, depth)


# class Drawers(Furniture):
#     name = settings.LABEL_KEY["furniture"]["balcony"]["drawers"]["name"]
#     type = settings.LABEL_KEY["furniture"]["balcony"]["drawers"]["type_id"]
#
#     def __init__(self, baseline, depth):
#         super(Drawers, self).__init__(baseline, depth)


