# coding=utf-8


class Balcony(object):
    def __init__(self):
        self.furniture_list = []
