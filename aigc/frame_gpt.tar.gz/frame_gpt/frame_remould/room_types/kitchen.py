
import frame_remould.settings as settings


def get_adjacent_living_wall(kitchen_region, id_region):
    areas_key = settings.FRAME_KEY["regions"]
    living_id = areas_key["type_id"]["living"]
    dining_id = areas_key["type_id"]["dining"]
    corridor_id = areas_key["type_id"]["corridor"]
    hallway1_id = areas_key["type_id"]["hallway1"]
    hallway2_id = areas_key["type_id"]["hallway2"]
    adj_walls = []
    for shared_areas in kitchen_region.ke_data[areas_key["attachments"]["name"]]["areas"]:
        room_type = shared_areas[areas_key["type"]]
        if room_type == living_id or room_type == dining_id or \
                room_type == corridor_id or room_type == hallway1_id or \
                room_type == hallway2_id:
            shared_lines = shared_areas[areas_key["attachments"]["shared_lines"]]
            adj_walls.extend(shared_lines)

    return adj_walls


