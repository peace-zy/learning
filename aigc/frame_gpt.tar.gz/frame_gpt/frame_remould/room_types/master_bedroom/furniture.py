# coding=utf-8

import matplotlib.path as mpath
import matplotlib.patches as mpatches

from frame_remould.room_types.furniture import Furniture
import frame_remould.settings as settings
from frame_remould.utils import geo_utils


class Bed(Furniture):
    name = settings.LABEL_KEY["furniture"]["master"]["bed"]["name"]
    type = settings.LABEL_KEY["furniture"]["master"]["bed"]["type_id"]
    bed_wall_idx = 0

    def __init__(self, baseline, depth):
        super(Bed, self).__init__(baseline, depth)


class Bedside(Furniture):
    name = settings.LABEL_KEY["furniture"]["master"]["bedside"]["name"]
    type = settings.LABEL_KEY["furniture"]["master"]["bedside"]["type_id"]
    bed_wall_idx = 0

    def __init__(self, baseline, depth):
        super(Bedside, self).__init__(baseline, depth)


class Wardrobe(Furniture):
    name = settings.LABEL_KEY["furniture"]["master"]["wardrobe"]["name"]
    type = settings.LABEL_KEY["furniture"]["master"]["wardrobe"]["type_id"]
    bed_wall_idx = 1

    def __init__(self, baseline, depth):
        super(Wardrobe, self).__init__(baseline, depth)


class Desk(Furniture):
    name = settings.LABEL_KEY["furniture"]["master"]["desk"]["name"]
    type = settings.LABEL_KEY["furniture"]["master"]["desk"]["type_id"]
    bed_wall_idx = 0

    def __init__(self, baseline, depth):
        super(Desk, self).__init__(baseline, depth)


class CloakroomA(Furniture):
    name = settings.LABEL_KEY["furniture"]["master"]["cloakroom_A"]["name"]
    type = settings.LABEL_KEY["furniture"]["master"]["cloakroom_A"]["type_id"]
    bed_wall_idx = 1

    def __init__(self, baseline, depth):
        super(CloakroomA, self).__init__(baseline, depth)

    def get_polygon(self):
        norm = geo_utils.get_normal_dir(self.baseline)
        base_dir = self.baseline.direction.unit

        p1 = self.baseline.p1
        contours = [p1]
        contours.append(p1 + norm * self.depth)

        p = contours[-1]
        contours.append(p + base_dir * 600)
        p = contours[-1]
        contours.append(p - norm * (self.depth - 400))
        p = contours[-1]
        contours.append(p + base_dir * (self.width - 600 - 400))
        p = contours[-1]
        contours.append(p + norm * (self.depth - 400))
        p = contours[-1]
        contours.append(p + base_dir * 400)
        p = contours[-1]
        contours.append(p - norm * self.depth)
        poly = settings.Polygon(*contours)
        return poly

    def get_patches(self):
        poly = self.get_polygon()
        contours = poly.vertices
        contours.append(contours[0])
        Path = mpath.Path
        path_data = []
        for idx, p in enumerate(contours):
            if idx == 0:
                path_data.append((Path.MOVETO, p))
            elif idx == len(contours) - 1:
                path_data.append((Path.CLOSEPOLY, p))
            else:
                path_data.append((Path.LINETO, p))
        codes, verts = zip(*path_data)
        path = mpath.Path(verts, codes, closed=True, readonly=True)
        path_patch = mpatches.PathPatch(path)
        return [path_patch]


class CloakroomB(Furniture):
    name = settings.LABEL_KEY["furniture"]["master"]["cloakroom_B"]["name"]
    type = settings.LABEL_KEY["furniture"]["master"]["cloakroom_B"]["type_id"]
    bed_wall_idx = 0

    def __init__(self, baseline, depth):
        super(CloakroomB, self).__init__(baseline, depth)

    def get_polygon(self):
        norm = geo_utils.get_normal_dir(self.baseline)
        base_dir = self.baseline.direction.unit

        p1 = self.baseline.p1
        contours = [p1]
        contours.append(p1 + norm * self.depth)

        p = contours[-1]
        contours.append(p + base_dir * 600)
        p = contours[-1]
        contours.append(p - norm * (self.depth - 600))
        p = contours[-1]
        contours.append(p + base_dir * (self.width - 600 * 2))
        p = contours[-1]
        contours.append(p + norm * (self.depth - 600))
        p = contours[-1]
        contours.append(p + base_dir * 600)
        p = contours[-1]
        contours.append(p - norm * self.depth)
        poly = settings.Polygon(*contours)
        return poly

    def get_patches(self):
        poly = self.get_polygon()
        contours = poly.vertices
        contours.append(contours[0])
        Path = mpath.Path
        path_data = []
        for idx, p in enumerate(contours):
            if idx == 0:
                path_data.append((Path.MOVETO, p))
            elif idx == len(contours) - 1:
                path_data.append((Path.CLOSEPOLY, p))
            else:
                path_data.append((Path.LINETO, p))
        codes, verts = zip(*path_data)
        path = mpath.Path(verts, codes, closed=True, readonly=True)
        path_patch = mpatches.PathPatch(path)
        return [path_patch]


