# coding=utf-8
"""
主卧解读
"""
import numpy as np
import pandas as pd
import copy
import json

from frame_remould.settings import FRAME_KEY
from frame_remould.utils import extract_rect
from frame_remould.utils import geo_utils
from frame_remould.room_types import room_utils
import frame_remould.settings as settings

from frame_remould.settings import RULE_PARAM
from frame_remould.settings import LABEL_KEY

from frame_remould.room_types.master_bedroom.furniture import Bedside, Bed, Desk
from frame_remould.room_types.master_bedroom.furniture import Wardrobe, CloakroomA, CloakroomB


class Master(object):
    def __init__(self):
        self._region = None
        self._floorplan = None
        self._max_rectangle = None
        self._inner_region = None
        self.entrance_door = None
        self.main_window_wall_id = None
        self.furniture_df = None
        self.bed_wall_df = None

        self.bed_wall_inner = None  # line2D
        self.desk_wall_inner = None
        self.desk_wall_start_pt = None
        self.bed_wall_start_pt = None

        self.width_pts = None
        self.width = None
        self.depth_pts = None
        self.depth = None

        self.furniture_list = []

    def initial(self):
        self.furniture_df = get_furniture_table()
        self.bed_wall_df = get_bed_wall_table()
        self.set_max_rectangle()
        self.entrance_door = room_utils.get_entrance_door(
            self._floorplan, self.region
        )
        self.set_main_window_wall()

        self.set_width_depth()
        # TODO: 摆放暂时不做
        # self.set_bed_wall()
        # self.set_desk_wall()

    @property
    def floorplan(self):
        return self._floorplan

    @property
    def region(self):
        return self._region

    @property
    def max_rectangle(self):
        return self._max_rectangle

    def set_region(self, region):
        self._region = region

    def set_inner_region(self):
        self._inner_region = self._region.set_inner_region()

    def set_floorplan(self, floorplan):
        self._floorplan = floorplan

    def set_max_rectangle(self):
        recs = extract_rect.extract_all_max_rec(
            self.region.inner_region.polygon
        )
        self._max_rectangle = recs[0]

    def set_main_window_wall(self):
        """
        计算主卧中主窗的墙，无论是否封闭，或者连接阳台
        """
        windows = self.region.get_windows()
        doors = self.region.get_doors()
        if len(windows) != 0:
            # 最大长度的窗户当作主窗
            self.main_window = sorted(
                windows,
                key=lambda w: w.segment2d.length,
                reverse=True)[0]
            self.main_window_wall_id = self.main_window.wall_id

            # 连接阳台的门优先
            for adj_reg_id in self.region.adjacent_region_id:
                adj_reg = self._floorplan.id_regions.get(adj_reg_id)
                # TODO: 功能区相通
                if adj_reg.room_type == FRAME_KEY["regions"]["type_id"]["balcony"]:
                    adj_doors = adj_reg.get_doors()
                    connect_door = list(set(doors).intersection(set(adj_doors)))
                    if len(connect_door) != 0:
                        self.main_window_wall_id = connect_door[0].wall_id
            return self
        else:
            if len(doors) != 1:
                for adj_reg_id in self.region.adjacent_region_id:
                    adj_reg = self._floorplan.id_regions.get(adj_reg_id)
                    adj_doors = adj_reg.get_doors()
                    connect_doors = list(set(doors).intersection(set(adj_doors)))
                    # 相邻空间没有和主卧连接的门，不算
                    if len(connect_doors) == 0:
                        continue
                    # 连接阳台的门当作main_window_wall
                    if adj_reg.room_type == FRAME_KEY["regions"]["type_id"]["balcony"]:
                        # adj_doors = adj_reg.get_doors()
                        # connect_doors = list(set(doors).intersection(set(adj_doors)))
                        # if len(connect_doors) == 0:
                        #     continue
                        self.main_window_wall_id = connect_doors[0].wall_id
                        return self
                    # # 或者只和主卧相连, 且有窗
                    # if len(adj_reg.adjacent_region_id) != 1:
                    #     continue
                    # adj_wins = adj_reg.get_windows()
                    # if len(adj_wins) != 0:
                    #     adj_doors = adj_reg.get_doors()
                    #     connect_door = list(set(doors).union(set(adj_doors)))[0]
                    #     self.main_window_wall_id = connect_door.wall_id
                    #     return self
                self.main_window_wall_id = room_utils.get_main_window_wall_in_one_door_room(
                    self.max_rectangle, self.entrance_door, self.region
                )
                return self
            else:
                # 主卧没有门窗模型(入户主卧的门除外，主卧内卫生间门之类不算)
                self.main_window_wall_id = room_utils.get_main_window_wall_in_one_door_room(
                    self.max_rectangle, self.entrance_door, self.region
                )
                return self

    def set_bed_wall(self):
        """
        配置床所在的墙，和起始位置
        """
        # center = self.max_rectangle.centroid
        # center_lines = [
        #     settings.Line2D(center, center + settings.Point2D(100, 0)),
        #     settings.Line2D(center, center + settings.Point2D(0, 100))
        # ]
        #
        # # 无论墙是否是斜线, 只计算墙的相对垂直方向
        # bed_walls = []
        # win_seg = self.region.id_walls.get(self.main_window_wall_id).segment2d
        # win_line = settings.Line2D(win_seg.p1, win_seg.p2)
        # win_wall_xy = geo_utils.get_line_x_y_dir(win_line)
        #
        # center_line = None
        # for cline in center_lines:
        #     if geo_utils.is_perpendicular(cline, win_wall_xy):
        #         center_line = cline
        # assert center_line is not None, "center line None"
        #
        # dr_pt = self.entrance_door.segment2d.midpoint
        # dr_pro = center_line.projection(dr_pt)
        # dr_cen_dir = settings.Line2D(dr_pro, dr_pt).direction.unit

        dr_pt = self.entrance_door.segment2d.midpoint
        center_line, dr_cen_dir, win_wall_xy = self.get_door_center_line2()
        xaxis, yaxis = geo_utils.get_axis4rectangle(self.max_rectangle)
        bed_walls = []
        # 以中心线切分区域，内边和门再连个方向上
        for s in self._inner_region.inner_lines:
            seg = settings.Segment2D(s.p1, s.p2)
            s_xy = geo_utils.get_line_x_y_dir(s, xaxis=xaxis)
            if geo_utils.is_parallel(s_xy, win_wall_xy):
                continue
            if s.length < 500:
                continue
            s_proj = center_line.projection(seg.midpoint)
            if s_proj == seg.midpoint:
                continue
            s_dir = settings.Line2D(s_proj, seg.midpoint).direction.unit
            delta = s_dir - dr_cen_dir

            if (np.fabs(delta.x) + np.fabs(delta.y)) < 1e-5:
                continue
            bed_walls.append(s)
        bed_wall = sorted(
            bed_walls,
            key=lambda s: settings.Segment2D(s.p1, s.p2).length,
            reverse=True)[0]
        self.bed_wall_inner = bed_wall

        self.bed_wall_start_pt = sorted(
            bed_wall.points,
            key=lambda p: p.distance(dr_pt),
            reverse=True
        )[0]

    def get_door_center_line(self):
        """
        返回切分主卧的中心直线，和入主卧门的方向, 主窗相对方向
        """
        center = self.max_rectangle.centroid
        center_lines = [
            settings.Line2D(center, center + settings.Point2D(100, 0)),
            settings.Line2D(center, center + settings.Point2D(0, 100))
        ]

        # 无论墙是否是斜线, 只计算墙的相对垂直方向
        win_seg = self.region.id_walls.get(self.main_window_wall_id).segment2d
        win_line = settings.Line2D(win_seg.p1, win_seg.p2)
        win_wall_xy = geo_utils.get_line_x_y_dir(win_line)

        center_line = None
        for cline in center_lines:
            if geo_utils.is_perpendicular(cline, win_wall_xy):
                center_line = cline
        assert center_line is not None, "center line None"

        dr_pt = self.entrance_door.segment2d.midpoint
        dr_pro = center_line.projection(dr_pt)
        dr_cen_dir = settings.Line2D(dr_pro, dr_pt).direction.unit

        return center_line, dr_cen_dir, win_wall_xy

    def get_door_center_line2(self):
        center = self.max_rectangle.centroid
        xaxis, yaxis = geo_utils.get_axis4rectangle(self.max_rectangle)
        # xaxis = settings.Line2D(self.max_rectangle.vertices[0], self.max_rectangle.vertices[1])
        # yaxis = settings.Line2D(self.max_rectangle.vertices[1], self.max_rectangle.vertices[2])
        center_lines = [
            settings.Line2D(center, center + xaxis.direction.unit * 100),
            settings.Line2D(center, center + yaxis.direction.unit * 100)
        ]
        # 无论墙是否是斜线, 只计算墙的相对垂直方向
        win_seg = self.region.id_walls.get(self.main_window_wall_id).segment2d
        win_line = settings.Line2D(win_seg.p1, win_seg.p2)
        # win_wall_xy = geo_utils.get_line_x_y_dir(win_line)
        win_wall_xy = geo_utils.get_line_x_y_dir(win_line, xaxis=xaxis)

        center_line = None
        for cline in center_lines:
            if geo_utils.is_perpendicular(cline, win_wall_xy):
                center_line = cline
        assert center_line is not None, "center line None"

        dr_pt = self.entrance_door.segment2d.midpoint
        dr_pro = center_line.projection(dr_pt)
        dr_cen_dir = settings.Line2D(dr_pro, dr_pt).direction.unit

        return center_line, dr_cen_dir, win_wall_xy

    def set_desk_wall(self):
        dr_pt = self.entrance_door.segment2d.midpoint
        center_line, dr_cen_dir, win_wall_xy = self.get_door_center_line()
        desk_walls = []

        for s in self._inner_region.inner_lines:
            seg = settings.Segment2D(s.p1, s.p2)
            s_xy = geo_utils.get_line_x_y_dir(s)
            if geo_utils.is_parallel(s_xy, win_wall_xy):
                continue
            if s.length < 500:
                continue
            s_proj = center_line.projection(seg.midpoint)
            s_dir = settings.Line2D(s_proj, seg.midpoint).direction.unit

            if s_dir != dr_cen_dir:
                continue
            desk_walls.append(s)
        desk_wall = sorted(
            desk_walls,
            key=lambda s: settings.Segment2D(s.p1, s.p2).length,
            reverse=True)[0]
        self.desk_wall_inner = desk_wall
        self.desk_wall_start_pt = sorted(
            desk_wall.points,
            key=lambda p: p.distance(dr_pt),
            reverse=True
        )[0]

    def set_width_depth(self):
        win_seg = self.region.id_walls.get(self.main_window_wall_id).segment2d
        win_line = settings.Line2D(win_seg.p1, win_seg.p2)
        self.width_pts, self.depth_pts = room_utils.get_width_depth_line(self.max_rectangle, win_line)
        self.width = settings.Segment2D(self.width_pts[0], self.width_pts[1]).length
        self.depth = settings.Segment2D(self.depth_pts[0], self.depth_pts[1]).length

        # center = self.max_rectangle.centroid
        # xaxis, yaxis = geo_utils.get_axis4rectangle(self.max_rectangle)
        # center_lines = [
        #     settings.Line2D(center, center + xaxis.direction.unit * 100),
        #     settings.Line2D(center, center + yaxis.direction.unit * 100)
        # ]
        # win_seg = self.region.id_walls.get(self.main_window_wall_id).segment2d
        # win_line = settings.Line2D(win_seg.p1, win_seg.p2)
        # win_wall_xy = geo_utils.get_line_x_y_dir(win_line, xaxis=xaxis)
        # for cline in center_lines:
        #     inter = self.max_rectangle.intersection(cline)
        #     if len(inter) != 2:
        #         raise RuntimeError("master bedroomm width and depth failed !!!")
        #     if geo_utils.is_parallel(cline, win_wall_xy):
        #         self.width_pts = inter
        #         self.width = settings.Segment2D(inter[0], inter[1]).length
        #     else:
        #         self.depth_pts = inter
        #         self.depth = settings.Segment2D(inter[0], inter[1]).length

    def layout_bed(self, df, bed_wall_end_pt):
        # 摆放床头柜和床
        df = df.iloc[-1, :]
        # 判断布置床的方向在区域内是否是沿着顺时针的
        self.bed_layout_dir_ccw = False
        bed_layout_line = settings.Line2D(self.bed_wall_start_pt, bed_wall_end_pt)
        if bed_layout_line.direction.unit == self.bed_wall_inner.direction.unit:
            self.bed_layout_dir_ccw = False
        else:
            self.bed_layout_dir_ccw = True
        # bed_layout_dir = bed_layout_line.direction.unit
        # 第一个床头柜
        start_pt = self.bed_wall_start_pt
        baseline, start_pt = room_utils.get_baseline(
            start_pt,
            df["Bedside"],
            self.bed_wall_inner,
            ccw=self.bed_layout_dir_ccw)
        depths = room_utils.get_furniture_depth(
            RULE_PARAM["master"]["furniture"]["bedside"],
            df["Bedside"]
        )
        bedside0 = Bedside(baseline, depths[0])
        self.furniture_list.append(bedside0)
        # 床
        baseline, start_pt = room_utils.get_baseline(
            start_pt,
            df["Bed"],
            self.bed_wall_inner,
            ccw=self.bed_layout_dir_ccw)
        depths = room_utils.get_furniture_depth(
            RULE_PARAM["master"]["furniture"]["bed"],
            df["Bed"]
        )
        bed = Bed(baseline, depths[0])
        self.furniture_list.append(bed)
        # 第二个床头柜
        if df["Bedside_num"] == 2:
            baseline, start_pt = room_utils.get_baseline(
                start_pt,
                df["Bedside"],
                self.bed_wall_inner,
                ccw=self.bed_layout_dir_ccw)
            depths = room_utils.get_furniture_depth(
                RULE_PARAM["master"]["furniture"]["bedside"],
                df["Bedside"]
            )
            bedside1 = Bedside(baseline, depths[0])
            self.furniture_list.append(bedside1)

    def layout_wardrobe(self, df, wardrobe_line, war_start_pt):
        if_wardrobe_on_bed_wall = True  # 床墙是否有衣柜

        df = df.iloc[-1, :]
        wardrobe_classes = {
            "wardrobe": Wardrobe,
            "cloakroom_A": CloakroomA,
            "cloakroom_B": CloakroomB
        }

        w_len = 0
        wardrobe_k = None
        for k, v in wardrobe_classes.items():
            # for wlen in [df["Wardrobe"], df["CloakroomA"], df["CloakroomB"]]:
            if df[v.__name__] > 0:
                w_len = df[v.__name__]
                wardrobe_cls = v
                wardrobe_k = k
                break
        w_type = v
        wardrobe_wall_len = wardrobe_line.p1.distance(wardrobe_line.p2)
        war_bedwall_idx = w_type.bed_wall_idx
        war_layout_idx = 0 if war_bedwall_idx == 1 else 1

        def get_wardrobe_w_d(w_type, w_len):
            wardrobe_k = dict(zip(wardrobe_classes.values(), wardrobe_classes.keys()))[w_type]
            war_bedwall_idx = w_type.bed_wall_idx
            war_layout_idx = 0 if war_bedwall_idx == 1 else 1
            war_w_d = None
            for w in RULE_PARAM["master"]["furniture"][wardrobe_k]:
                if w[war_bedwall_idx] != w_len:
                    continue
                war_w_d = w
            return war_w_d, war_layout_idx

        war_w_d, war_layout_idx = get_wardrobe_w_d(w_type, w_len)
        # war_w_d = None
        #
        # for w in RULE_PARAM["master"]["furniture"][wardrobe_k]:
        #     if w[war_bedwall_idx] != w_len:
        #         continue
        #     war_w_d = w

        # 衣帽间如果距离不足，则改成衣柜
        if wardrobe_wall_len < war_w_d[war_layout_idx] and w_type != Wardrobe:
            w_type = Wardrobe
            w_len = RULE_PARAM["master"]["furniture"]['wardrobe'][0][1]
            war_w_d, war_layout_idx = get_wardrobe_w_d(w_type, w_len)
        if wardrobe_wall_len < war_w_d[war_layout_idx]:
            if_wardrobe_on_bed_wall = False
            return if_wardrobe_on_bed_wall

        if v == CloakroomB:
            baseline_dir = geo_utils.get_normal_dir(wardrobe_line)
            base_p2 = war_start_pt + baseline_dir * war_w_d[0]
            if self.bed_layout_dir_ccw:
                p1, p2 = war_start_pt, base_p2
            else:
                p1, p2 = base_p2, war_start_pt
            baseline = settings.Line2D(p1, p2)
            wardrobe = w_type(baseline, depth=war_w_d[1])
        else:
            baseline = room_utils.get_length_along_line(
                wardrobe_line,
                war_w_d[war_bedwall_idx],
                war_start_pt,
                self.bed_layout_dir_ccw,
                self.region.inner_region
            )
            wardrobe = w_type(baseline, depth=war_w_d[war_bedwall_idx])
        # 衣帽间如果有档门窗, 则改成衣帽间
        if v != Wardrobe:
            for k, item in self.region.inner_region.id_items.items():
                if room_utils.is_lineitem_furniture_intersection(item.segment2d, wardrobe):
                    w_type = Wardrobe
                    w_len = RULE_PARAM["master"]["furniture"]['wardrobe'][0][1]
                    war_bedwall_idx = w_type.bed_wall_idx
                    war_w_d, war_layout_idx = get_wardrobe_w_d(w_type, w_len)
                    baseline = room_utils.get_baseline_along_line(
                        wardrobe_line, war_w_d[war_layout_idx],
                        war_start_pt, self.bed_layout_dir_ccw
                    )
                    wardrobe = w_type(baseline, depth=war_w_d[war_bedwall_idx])

        for k, item in self.region.inner_region.id_items.items():
            if room_utils.is_lineitem_furniture_intersection(item.segment2d, wardrobe):
                if_wardrobe_on_bed_wall = False
        # basline 不能太短
        if wardrobe.baseline.p1.distance(wardrobe.baseline.p2) < RULE_PARAM["master"]["furniture"]["wardrobe"][0][0]:
            if_wardrobe_on_bed_wall = False

        if if_wardrobe_on_bed_wall is True:
            self.furniture_list.append(wardrobe)

        return if_wardrobe_on_bed_wall

    def layout_wardrobe_on_desk_wall(self):
        ccw = room_utils.get_ccw_line_start_p12(self.desk_wall_inner, self.desk_wall_start_pt)
        ward_width = RULE_PARAM["master"]['wardrobe_on_desk']
        if self.desk_wall_inner.p1.distance(self.desk_wall_inner.p2) < RULE_PARAM["master"]['wardrobe_on_desk']:
            ward_width = RULE_PARAM["master"]["furniture"]['wardrobe'][0][0]
        baseline = room_utils.get_baseline_along_line(
            self.desk_wall_inner,
            ward_width,
            self.desk_wall_start_pt,
            ccw
        )
        depth = RULE_PARAM["master"]["furniture"]['wardrobe'][0][1]
        wardrobe = Wardrobe(baseline, depth)
        w_poly = wardrobe.get_polygon()
        intersect_flag = False
        for f in self.furniture_list:
            if type(f) != Bed:
                continue
            bed_poly = f.get_polygon()
            inter = bed_poly.intersection(w_poly)
            if len(inter) != 0:
                intersect_flag = True
        # 衣柜和床相交，不摆放
        if intersect_flag is True:
            return self
        self.furniture_list.append(wardrobe)

    def layout_desk_wall(self):
        # 床的中心先射线交点
        bed = None
        for f in self.furniture_list:
            if type(f) == Bed:
                bed = f
        bed_mid = settings.Segment2D(bed.baseline.p1, bed.baseline.p2).midpoint
        bed_dir = geo_utils.get_normal_dir(bed.baseline)
        bed_p1 = bed_mid + bed_dir * 10
        bed_p2 = bed_p1 + bed_dir * 10
        bed_ray = settings.Ray2D(bed_p1, bed_p2)
        poly = self._inner_region.polygon
        inters = poly.intersection(bed_ray)
        dis = inters[0].distance(bed_mid)

        thre = RULE_PARAM["aisle_width"] + bed.depth + RULE_PARAM["master"]["furniture"]["desk"][0][1]
        if dis < thre:
            return None

        # 计算desk_wall
        self.desk_wall_inner = None
        for l in self.region.inner_region.inner_lines:
            l_xy_dir = geo_utils.get_line_x_y_dir(l, xaxis=bed.baseline)
            if geo_utils.is_parallel(l_xy_dir, bed.baseline):
                inters = settings.Segment2D(l.p1, l.p2).intersection(bed_ray)
                if len(inters) > 0 and type(inters[0]) == settings.Point2D:
                    self.desk_wall_inner = l
                    break
        if self.desk_wall_inner is None:
            return None

        mid_desk = inters[0]
        width_2 = RULE_PARAM["master"]["furniture"]['desk'][0][0] / 2
        desk_p1 = mid_desk + self.desk_wall_inner.direction.unit * width_2
        desk_p2 = mid_desk - self.desk_wall_inner.direction.unit * width_2
        desk_baseline = room_utils.get_baseline_p12(desk_p1, desk_p2, self.desk_wall_inner)
        depth = RULE_PARAM["master"]["furniture"]['desk'][0][1]
        desk = Desk(desk_baseline, depth)
        self.furniture_list.append(desk)

        # ccw = room_utils.get_ccw_line_start_p12(self.desk_wall_inner, self.desk_wall_start_pt)
        # bed = None
        # for f in self.furniture_list:
        #     if type(f) != Bed:
        #         continue
        #     bed = f
        # bed_mid_pt = settings.Segment2D(
        #     bed.baseline.p1, bed.baseline.p2
        # ).midpoint
        # proj_mid = self.desk_wall_inner.projection(bed_mid_pt)
        # width_2 = RULE_PARAM["master"]["furniture"]['desk'][0][0] / 2
        #
        # # 得到书桌的起点
        # if ccw:
        #     direc = self.desk_wall_inner.direction.unit
        # else:
        #     direc = self.desk_wall_inner.direction.unit * (-1)
        # desk_start_pt = proj_mid + direc * width_2
        # baseline = room_utils.get_baseline_along_line(
        #     self.desk_wall_inner,
        #     RULE_PARAM["master"]["furniture"]['desk'][0][0],
        #     desk_start_pt,
        #     ccw
        # )
        # depth = RULE_PARAM["master"]["furniture"]['desk'][0][1]
        # desk = Desk(baseline, depth)
        # self.furniture_list.append(desk)

    def layout_second_bedside(self):
        bedside_list = []
        bed_list = []
        for f in self.furniture_list:
            if type(f) == Bedside:
                bedside_list.append(f)
            if type(f) == Bed:
                bed_list.append(f)
        if len(bedside_list) == 2:
            return self

        bedside_poly = bedside_list[0].get_polygon()
        for idx, p in enumerate(bed_list[0].baseline.points):
            intersect = bedside_poly.intersection(p)
            if len(intersect) == 0:
                bed_only_pt = p  # 不和第一个床头柜相邻的点
            # else:
            #     bed_inter_pt = p

        bed_dirct = bed_list[0].baseline.direction.unit
        bedside_width = bedside_list[0].width
        if self.bed_layout_dir_ccw:
            baseline = settings.Line2D(
                bed_only_pt - bed_dirct * bedside_width,
                bed_only_pt)
        else:
            baseline = settings.Line2D(
                bed_only_pt,
                bed_only_pt + bed_dirct * bedside_width)

        bedside2 = Bedside(baseline, bedside_list[0].depth)
        self.furniture_list.append(bedside2)

    def run(self):
        bed_wall_end_pt = geo_utils.get_another_pt(self.bed_wall_inner, self.bed_wall_start_pt)
        bed_wall_len = settings.Segment2D(self.bed_wall_start_pt, bed_wall_end_pt).length
        bed_wall_df0 = self.bed_wall_df.loc[self.bed_wall_df.sum_len <= bed_wall_len]

        # 定制榻榻米
        if bed_wall_df0.empty:
            raise RuntimeError("master TOO small")

        self.layout_bed(bed_wall_df0, bed_wall_end_pt)

        # 找到连接另一点的墙
        wardrobe_line = None
        war_start_pt = bed_wall_end_pt
        for l in self.region.inner_region.inner_lines:
            if bed_wall_end_pt not in l.points:
                continue
            if l == self.bed_wall_inner:
                continue
            wardrobe_line = l

        if_wardrobe_on_bed_wall = self.layout_wardrobe(bed_wall_df0, wardrobe_line, war_start_pt)

        if if_wardrobe_on_bed_wall:
            # desk_wall 上放书桌
            self.layout_desk_wall()
        else:
            # 检测床头柜数量，如果只有一个，可以试着放两个
            self.layout_second_bedside()
            # desk_wall 上放衣柜
            self.layout_wardrobe_on_desk_wall()


def get_master_bedroom(floorplan):
    bedroom_types = [
        FRAME_KEY["regions"]["type_id"]["bedroom"],
        FRAME_KEY["regions"]["type_id"]["master_bedroom"],
        FRAME_KEY["regions"]["type_id"]["guest_bedroom"]
    ]
    mbedrooms = []
    for k, reg in floorplan.id_regions.items():
        room_type = reg.room_type
        if room_type not in bedroom_types:
            continue
        m = Master()
        m.set_region(reg)
        mbedrooms.append(m)

    if len(mbedrooms) == 0:
        return None

    mbedrooms_area = []
    for idx, m in enumerate(mbedrooms):
        area = m.region.size
        doors = m.region.get_doors()
        # 只有只和主卧有相连接的门的功能区才算主卧内
        for adj_id in m.region.adjacent_region_id:
            adj = floorplan.id_regions.get(adj_id)
            adj_doors = adj.get_doors()
            if len(adj_doors) != 1:
                continue
            connect_door = list(set(doors).intersection(set(adj_doors)))
            if len(connect_door) != 1:
                continue
            area += adj.size
        area /= 1000 * 1000
        mbedrooms_area.append(area)
    max_idx = np.argmax(mbedrooms_area)
    master_bedroom = mbedrooms[max_idx]
    master_bedroom.set_inner_region()

    return master_bedroom


def get_furniture_table():
    furniture_sizes = RULE_PARAM["master"]["furniture"]
    furniture_types = LABEL_KEY["furniture"]["master"]
    data = dict()
    cnt = 0
    for fur_type, v in furniture_types.items():
        for size in furniture_sizes[fur_type]:
            width = size[0]
            depth = size[1]
            data[cnt] = [width, depth, fur_type, v["type_id"], v["name"]]
            cnt += 1
    df = pd.DataFrame(
        data=data,
        index=["width", "depth", "type", "type_id", "name"]
    )
    df = df.stack().unstack(0)
    return df


def get_bed_wall_table():
    bedside_nums = [1, 2]

    df = pd.DataFrame(
        columns=["Bed", "Bedside", "Bedside_num", "Wardrobe", "CloakroomA", "CloakroomB", "wall", "sum_len"]
    )
    # 加载床头柜数据
    for bedside_num in bedside_nums:
        # 暂时不加载一个床头柜
        if bedside_num < 2:
            continue
        for bedside in RULE_PARAM["master"]["furniture"]["bedside"]:
            df = df.append({
                "Bedside": bedside[Bedside.bed_wall_idx],
                "Bedside_num": bedside_num},
                ignore_index=True)
    # 加载床数据
    df_list = [copy.deepcopy(df) for bed in RULE_PARAM["master"]["furniture"]["bed"]]
    for idx, bed in enumerate(RULE_PARAM["master"]["furniture"]["bed"]):
        for index, row in df_list[idx].iterrows():
            row["Bed"] = bed[Bed.bed_wall_idx]
    df = pd.concat(df_list, axis=0)
    # 加载衣柜
    wardrobe_classes = {
        "wardrobe": Wardrobe,
        "cloakroom_A": CloakroomA,
        "cloakroom_B": CloakroomB
    }
    cnt = 0
    for k, v in wardrobe_classes.items():
        cnt += len(RULE_PARAM["master"]["furniture"][k])
    df_list = [copy.deepcopy(df) for c in range(cnt)]
    cnt = 0
    for k, v in wardrobe_classes.items():
        for idx, wardrobe in enumerate(RULE_PARAM["master"]["furniture"][k]):
            for index, row in df_list[cnt].iterrows():
                row[v.__name__] = wardrobe[v.bed_wall_idx]
        cnt += 1
    df = pd.concat(df_list, axis=0)
    df[pd.isnull(df)] = 0
    # df[pd.isna(df)] = 0
    # 衣帽间B需要有一个墙
    df.loc[df["CloakroomB"] != 0, "wall"] = 120

    # 一个床头柜只能配普通衣柜
    df_bedside_1 = df.loc[df["Wardrobe"] != 0].copy()
    # df_bedside_1["Bedside_num"] = 1
    df_bedside_1.loc[:, "Bedside_num"] = 1
    df = pd.concat([df_bedside_1, df])
    # 计算总距离
    for idx, row in df.iterrows():
        fsum = lambda r: (r["Bed"] + r["Bedside"] * r["Bedside_num"]
                          + r["Wardrobe"] + r["CloakroomA"]
                          + r["CloakroomB"] + r["wall"])
        sum_len = fsum(row)
        row["sum_len"] = sum_len
    df = df.sort_values(by='sum_len')
    return df


def show(house, res_dict, img_path=None):
    frame_id = house.frame_id
    for idx, res in enumerate(res_dict[settings.ROOMTYPE_MASTER_BEDROOM]):
        cont = res[settings.RES_SPACE]["contours"]
        cont.append(res[settings.RES_SPACE]["contours"][0])
        walking_pts = [cont]
        # walking_pts = [res[settings.RES_SPACE]["contours"]]
        # furniture = []
        furniture = res[settings.RES_DECORATION]["furniture"]
        if len(res_dict) == 0:
            title = frame_id
        else:
            title = frame_id + "_" + str(idx)
        floor_name = res["floor"]
        house_idx = idx
        for fp_idx, fp in enumerate(house.floorplans):
            if floor_name == fp._name:
                house_idx = fp_idx
                break

        house.floorplans[house_idx].show(
            # walking_pts=walking_pts,
            title=title,
            frame_id=frame_id,
            fp_idx=idx,
            furniture=furniture,
            img_path=img_path
        )


def frameXitems_print(house, area_id):
    show_area = [area_id]
    frameXitems = house.get_frameXitems()
    new_frame = copy.deepcopy(house.frame_json)
    for index, floorplan in enumerate(house.frame_json["floorplans"]):
        # 标准json中元素list转成dict形式
        temp_lines = {lines["id"]: lines for lines in floorplan["lines"]}
        temp_points = {points["id"]: points for points in floorplan["points"]}
        temp_lineitems = {lineItems["id"]: lineItems for lineItems in floorplan["lineItems"]}
        temp_area = {areas["id"]: areas for areas in floorplan["areas"]}

        # 新json数据置空
        for keys in ["areas", "points", "lines", "lineItems", "items", "frameXitems"]:
            new_frame["floorplans"][index][keys] = list()
        # 多层结构可能没有此分间
        if area_id not in temp_area:
            continue
        # 获取与主卧联通的功能间id，阳台、卫生间、储物间、衣帽间
        # for att_area in temp_area[area_id]["attachments"]["areas"]:
        #     if att_area['type'] in [5, 6, 7, 12, 13, 14, 15] and att_area['sharedLineItems']:
        #         for lineitem_id in att_area['sharedLineItems']:
        #             if temp_lineitems[lineitem_id]['is'] == 'door':
        #                 show_area.append(att_area["id"])
        all_pts = []
        all_lines = []
        all_item = []
        for id in show_area:
            area = temp_area[id]
            area['attachments']['areas'] = [area_it for area_it in area['attachments']['areas'] if
                                            area_it['id'] in show_area]
            new_frame["floorplans"][index]["areas"].append(area)
            all_pts.extend(area['points'])
            all_lines.extend([line['id'] for line in area['attachments']['lines']])
            all_item.extend([lineItems['id'] for lineItems in area['attachments']['lineItems']])

        # 多功能间考虑点线去重
        for id in set(all_pts):
            new_pt = copy.deepcopy(temp_points[id])
            new_pt['lines'] = [lid for lid in new_pt['lines'] if lid in all_lines]
            new_frame["floorplans"][index]["points"].append(new_pt)

        new_frame["floorplans"][index]["lines"] = [temp_lines[id] for id in set(all_lines)]
        new_frame["floorplans"][index]["lineItems"] = [temp_lineitems[id] for id in set(all_item)]
        new_frame["floorplans"][index]["items"] = list()
        # 配置家具
        new_frame["floorplans"][index]['frameXitems'] = frameXitems['floorplans'][index]
    return new_frame

    # new_frame_str = json.dumps(new_frame)
    # new_house.set_json_str(new_frame_str)
    # new_house.floorplans[index].fur_list = house.floorplans[index].fur_list


def res2json(res):
    res_json = {
        settings.RES_AREA_ID: res[settings.RES_AREA_ID],
        settings.RES_FLOOR: res[settings.RES_FLOOR],
        settings.RES_ERROR: None
    }
    # space analysis 字段
    res_space = res[settings.RES_SPACE]
    space_ana = {
        settings.RES_CONTOURS: [p.args for p in res_space[settings.RES_CONTOURS]],
        settings.RES_WIDTH: res_space[settings.RES_WIDTH],
        settings.RES_DEPTH: res_space[settings.RES_DEPTH],
        settings.RES_WIDTH_PTS: [p.args for p in res_space[settings.RES_WIDTH_PTS]],
        settings.RES_DEPTH_PTS: [p.args for p in res_space[settings.RES_DEPTH_PTS]],
    }
    res_json[settings.RES_SPACE] = space_ana
    # decoration 字段
    res_deco = res[settings.RES_DECORATION]
    decration = {
        "index": res_deco["index"],
        settings.RES_FURNITURE: []
    }
    for f in res_deco[settings.RES_FURNITURE]:
        f_dict = f.get_json_dict()
        f_dict["name"] = f.name
        f_dict["type"] = f.type
        decration[settings.RES_FURNITURE].append(f_dict)
    res_json[settings.RES_DECORATION] = decration
    return res_json
