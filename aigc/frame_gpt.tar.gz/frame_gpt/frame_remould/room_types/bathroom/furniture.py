# coding=utf-8

import matplotlib.path as mpath
import matplotlib.patches as mpatches

from frame_remould.room_types.furniture import Furniture
import frame_remould.settings as settings


class Closestool(Furniture):
    name = settings.LABEL_KEY["furniture"]["bathroom"]["closestool"]["name"]
    type = settings.LABEL_KEY["furniture"]["bathroom"]["closestool"]["type_id"]

    def __init__(self, baseline, depth):
        super(Closestool, self).__init__(baseline, depth)


class Washer(Furniture):
    name = settings.LABEL_KEY["furniture"]["bathroom"]["washer"]["name"]
    type = settings.LABEL_KEY["furniture"]["bathroom"]["washer"]["type_id"]

    def __init__(self, baseline, depth):
        super(Washer, self).__init__(baseline, depth)


class Sprinkler(Furniture):
    name = settings.LABEL_KEY["furniture"]["bathroom"]["sprinkler"]["name"]
    type = settings.LABEL_KEY["furniture"]["bathroom"]["sprinkler"]["type_id"]

    def __init__(self, baseline, depth):
        super(Sprinkler, self).__init__(baseline, depth)


class BathroomCabinet(Furniture):
    name = settings.LABEL_KEY["furniture"]["bathroom"]["bathroomcabinet"]["name"]
    type = settings.LABEL_KEY["furniture"]["bathroom"]["bathroomcabinet"]["type_id"]

    def __init__(self, baseline, depth):
        super(BathroomCabinet, self).__init__(baseline, depth)


class BasinWithPedestal(Furniture):
    name = settings.LABEL_KEY["furniture"]["bathroom"]["basinWithPedestal"]["name"]
    type = settings.LABEL_KEY["furniture"]["bathroom"]["basinWithPedestal"]["type_id"]

    def __init__(self, baseline, depth):
        super(BasinWithPedestal, self).__init__(baseline, depth)


class Shower(Furniture):
    name = settings.LABEL_KEY["furniture"]["bathroom"]["shower"]["name"]
    type = settings.LABEL_KEY["furniture"]["bathroom"]["shower"]["type_id"]

    def __init__(self, baseline, depth):
        super(Shower, self).__init__(baseline, depth)


class Flue(Furniture):
    name = settings.LABEL_KEY["furniture"]["bathroom"]["flue"]["name"]
    type = settings.LABEL_KEY["furniture"]["bathroom"]["flue"]["type_id"]

    def __init__(self, baseline, depth):
        super(Flue, self).__init__(baseline, depth)


class Sewer(Furniture):
    name = settings.LABEL_KEY["furniture"]["bathroom"]["sewer"]["name"]
    type = settings.LABEL_KEY["furniture"]["bathroom"]["sewer"]["type_id"]

    def __init__(self, baseline, depth):
        super(Sewer, self).__init__(baseline, depth)

