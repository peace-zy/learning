# coding=utf-8


class Bathroom(object):
    def __init__(self):
        self.furniture_list = []
