# coding=utf-8

import frame_remould.settings as settings
from frame_remould.utils import extract_rect
from frame_remould.settings import FRAME_KEY

class Livingroom(object):
    def __init__(self):
        self.furniture_list = []
        self._region = None
        self._max_rectangle = None

    @property
    def max_rectangle(self):
        return self._max_rectangle

    @property
    def region(self):
        return self._region

    def set_inner_region(self):
        self._inner_region = self._region.set_inner_region()

    def set_floorplan(self, floorplan):
        self._floorplan = floorplan

    def set_region(self, region):
        self._region = region

    def initial(self):
        self.set_max_rectangle()

    def set_max_rectangle(self):
        recs = extract_rect.extract_all_max_rec(
            self.region.inner_region.polygon
        )
        self._max_rectangle = recs[0]

    def run(self):
        pass

def get_livingrooms(floorplan):
    livingroom_types = [FRAME_KEY["regions"]["type_id"]["living"]]
    livings = []
    for k, reg in floorplan.id_regions.items():
        room_type = reg.room_type
        if room_type not in livingroom_types:
            continue
        l = Livingroom()
        l.set_region(reg)
        livings.append(l)

    if len(livings) == 0:
        return []
    return livings


def show(house, res_dict, img_path=None):
    frame_id = house.frame_id
    for idx, res in enumerate(res_dict[settings.ROOMTYPE_LIVINGROOM]):
        cont = res[settings.RES_SPACE]["contours"]
        cont.append(res[settings.RES_SPACE]["contours"][0])
        walking_pts = [cont]
        # walking_pts = [res[settings.RES_SPACE]["contours"]]
        # furniture = res[settings.RES_DECORATION]["furniture"]
        furniture = []
        if len(res_dict) == 0:
            title = frame_id
        else:
            title = frame_id + "_" + str(idx)
        floor_name = res["floor"]
        house_idx = idx
        for fp_idx, fp in enumerate(house.floorplans):
            if floor_name == fp._name:
                house_idx = fp_idx
                break

        house.floorplans[house_idx].show(
            walking_pts=walking_pts,
            title=title,
            frame_id=frame_id,
            fp_idx=idx,
            furniture=furniture,
            img_path=img_path
        )


def res2json(res):
    res_json = {
        settings.RES_AREA_ID: res[settings.RES_AREA_ID],
        settings.RES_FLOOR: res[settings.RES_FLOOR],
        settings.RES_ERROR: None
    }
    res_space = res[settings.RES_SPACE]
    space_ana = {
        settings.RES_CONTOURS: [p.args for p in res_space[settings.RES_CONTOURS]],
        # settings.RES_WIDTH: res_space[settings.RES_WIDTH],
        # settings.RES_DEPTH: res_space[settings.RES_DEPTH],
        # settings.RES_WIDTH_PTS: [p.args for p in res_space[settings.RES_WIDTH_PTS]],
        # settings.RES_DEPTH_PTS: [p.args for p in res_space[settings.RES_DEPTH_PTS]],
    }
    res_json[settings.RES_SPACE] = space_ana
    return res_json