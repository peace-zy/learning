# coding=utf-8

from frame_remould.room_types.livingroom import explain