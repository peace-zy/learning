# coding=utf-8

import matplotlib.path as mpath
import matplotlib.patches as mpatches

from frame_remould.room_types.furniture import Furniture
import frame_remould.settings as settings


class Stool(Furniture):
    name = settings.LABEL_KEY["furniture"]["livingroom"]["stool"]["name"]
    type = settings.LABEL_KEY["furniture"]["livingroom"]["stool"]["type_id"]

    def __init__(self, baseline, depth):
        super(Stool, self).__init__(baseline, depth)


class TVbench(Furniture):
    name = settings.LABEL_KEY["furniture"]["livingroom"]["tvbench"]["name"]
    type = settings.LABEL_KEY["furniture"]["livingroom"]["tvbench"]["type_id"]

    def __init__(self, baseline, depth):
        super(TVbench, self).__init__(baseline, depth)


class Sofa_1(Furniture):
    name = settings.LABEL_KEY["furniture"]["livingroom"]["sofa_1"]["name"]
    type = settings.LABEL_KEY["furniture"]["livingroom"]["sofa_1"]["type_id"]

    def __init__(self, baseline, depth):
        super(Sofa_1, self).__init__(baseline, depth)


class RightSofa_L(Furniture):
    name = settings.LABEL_KEY["furniture"]["livingroom"]["rightsofa_l"]["name"]
    type = settings.LABEL_KEY["furniture"]["livingroom"]["rightsofa_l"]["type_id"]

    def __init__(self, baseline, depth):
        super(RightSofa_L, self).__init__(baseline, depth)


class LeftSofa_L(Furniture):
    name = settings.LABEL_KEY["furniture"]["livingroom"]["leftsofa_l"]["name"]
    type = settings.LABEL_KEY["furniture"]["livingroom"]["leftsofa_l"]["type_id"]

    def __init__(self, baseline, depth):
        super(LeftSofa_L, self).__init__(baseline, depth)


class RectangleTeaTable(Furniture):
    name = settings.LABEL_KEY["furniture"]["livingroom"]["rectangle_table"]["name"]
    type = settings.LABEL_KEY["furniture"]["livingroom"]["rectangle_table"]["type_id"]

    def __init__(self, baseline, depth):
        super(RectangleTeaTable, self).__init__(baseline, depth)


class SquareTeaTable(Furniture):
    name = settings.LABEL_KEY["furniture"]["livingroom"]["square_table"]["name"]
    type = settings.LABEL_KEY["furniture"]["livingroom"]["square_table"]["type_id"]

    def __init__(self, baseline, depth):
        super(SquareTeaTable, self).__init__(baseline, depth)


class CircleTeaTable(Furniture):
    name = settings.LABEL_KEY["furniture"]["livingroom"]["circle_table"]["name"]
    type = settings.LABEL_KEY["furniture"]["livingroom"]["circle_table"]["type_id"]

    def __init__(self, baseline, depth):
        super(CircleTeaTable, self).__init__(baseline, depth)


class SideTable(Furniture):
    name = settings.LABEL_KEY["furniture"]["livingroom"]["side_table"]["name"]
    type = settings.LABEL_KEY["furniture"]["livingroom"]["side_table"]["type_id"]

    def __init__(self, baseline, depth):
        super(SideTable, self).__init__(baseline, depth)
