# coding=utf-8

class Kitchen(object):
    def __init__(self):
        self.furniture_list = []
