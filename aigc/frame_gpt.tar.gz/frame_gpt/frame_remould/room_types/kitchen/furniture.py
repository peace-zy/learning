# coding=utf-8

import matplotlib.path as mpath
import matplotlib.patches as mpatches

from frame_remould.room_types.furniture import Furniture
import frame_remould.settings as settings
from frame_remould.utils import geo_utils


class Hearth(Furniture):
    name = settings.LABEL_KEY["furniture"]["kitchen"]["hearth"]["name"]
    type = settings.LABEL_KEY["furniture"]["kitchen"]["hearth"]["type_id"]

    def __init__(self, baseline, depth):
        super(Hearth, self).__init__(baseline, depth)


class Basin(Furniture):
    name = settings.LABEL_KEY["furniture"]["kitchen"]["basin"]["name"]
    type = settings.LABEL_KEY["furniture"]["kitchen"]["basin"]["type_id"]

    def __init__(self, baseline, depth):
        super(Basin, self).__init__(baseline, depth)


class Refigerator(Furniture):
    name = settings.LABEL_KEY["furniture"]["kitchen"]["refigerator"]["name"]
    type = settings.LABEL_KEY["furniture"]["kitchen"]["refigerator"]["type_id"]

    def __init__(self, baseline, depth):
        super(Refigerator, self).__init__(baseline, depth)


class Cabinet1(Furniture):
    name = settings.LABEL_KEY["furniture"]["kitchen"]["cabinet1"]["name"]
    type = settings.LABEL_KEY["furniture"]["kitchen"]["cabinet1"]["type_id"]

    def __init__(self, baseline, depth):
        super(Cabinet1, self).__init__(baseline, depth)


class CabinetL(Furniture):
    """面对橱柜，转角总是在左手边"""
    name = settings.LABEL_KEY["furniture"]["kitchen"]["cabinetL"]["name"]
    type = settings.LABEL_KEY["furniture"]["kitchen"]["cabinetL"]["type_id"]

    def __init__(self, baseline, depth):
        super(CabinetL, self).__init__(baseline, depth)

    def get_polygon(self):
        norm = geo_utils.get_normal_dir(self.baseline)
        base_dir = self.baseline.direction.unit

        p1 = self.baseline.p1
        contours = [p1, p1 + norm * self.depth]

        p = contours[-1]
        contours.append(p + base_dir * 600)
        p = contours[-1]
        contours.append(p - norm * (self.depth - 600))
        p = contours[-1]
        contours.append(p + base_dir * (self.width - 600))
        p = contours[-1]
        contours.append(p - norm * 600)
        poly = settings.Polygon(*contours)
        return poly

    def get_patches(self):
        poly = self.get_polygon()
        contours = poly.vertices
        contours.append(contours[0])
        Path = mpath.Path
        path_data = []
        for idx, p in enumerate(contours):
            if idx == 0:
                path_data.append((Path.MOVETO, p))
            elif idx == len(contours) - 1:
                path_data.append((Path.CLOSEPOLY, p))
            else:
                path_data.append((Path.LINETO, p))
        codes, verts = zip(*path_data)
        path = mpath.Path(verts, codes, closed=True, readonly=True)
        path_patch = mpatches.PathPatch(path)
        return [path_patch]


class CabinetU(Furniture):
    """
    U型橱柜的baseline就是中间那条直线，两边可以不一样长，即depth1和depth2不同
    """
    name = settings.LABEL_KEY["furniture"]["kitchen"]["cabinetU"]["name"]
    type = settings.LABEL_KEY["furniture"]["kitchen"]["cabinetU"]["type_id"]

    def __init__(self, baseline, depth):
        super(CabinetU, self).__init__(baseline, depth)
        self.depth1 = depth
        self.depth2 = depth

    def set_depth12(self, depth1, depth2):
        self.depth1 = depth1
        self.depth2 = depth2

    def get_polygon(self):
        norm = geo_utils.get_normal_dir(self.baseline)
        base_dir = self.baseline.direction.unit

        p1 = self.baseline.p1
        contours = [p1, p1 + norm * self.depth1]

        p = contours[-1]
        contours.append(p + base_dir * 600)
        p = contours[-1]
        contours.append(p - norm * (self.depth1 - 600))
        p = contours[-1]
        contours.append(p + base_dir * (self.width - 600 * 2))
        p = contours[-1]
        contours.append(p + norm * (self.depth2 - 600))
        p = contours[-1]
        contours.append(p + base_dir * 600)
        p = contours[-1]
        contours.append(p - norm * self.depth2)
        poly = settings.Polygon(*contours)
        return poly

    def get_patches(self):
        poly = self.get_polygon()
        contours = poly.vertices
        contours.append(contours[0])
        Path = mpath.Path
        path_data = []
        for idx, p in enumerate(contours):
            if idx == 0:
                path_data.append((Path.MOVETO, p))
            elif idx == len(contours) - 1:
                path_data.append((Path.CLOSEPOLY, p))
            else:
                path_data.append((Path.LINETO, p))
        codes, verts = zip(*path_data)
        path = mpath.Path(verts, codes, closed=True, readonly=True)
        path_patch = mpatches.PathPatch(path)
        return [path_patch]
