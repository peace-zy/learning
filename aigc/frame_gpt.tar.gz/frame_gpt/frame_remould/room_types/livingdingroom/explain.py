# coding=utf-8


class LivingDingRoom(object):
    def __init__(self):
        self.furniture_list = []
