# coding=utf-8

from frame_remould.room_types.furniture import Furniture
import frame_remould.settings as settings
from frame_remould.utils import geo_utils


class Bed(Furniture):
    name = settings.LABEL_KEY["furniture"]["bedroom"]["bed"]["name"]
    type = settings.LABEL_KEY["furniture"]["bedroom"]["bed"]["type_id"]
    bed_wall_idx = 0

    def __init__(self, baseline, depth):
        super(Bed, self).__init__(baseline, depth)


class Bedside(Furniture):
    name = settings.LABEL_KEY["furniture"]["bedroom"]["bedside"]["name"]
    type = settings.LABEL_KEY["furniture"]["bedroom"]["bedside"]["type_id"]
    bed_wall_idx = 0

    def __init__(self, baseline, depth):
        super(Bedside, self).__init__(baseline, depth)


class Wardrobe(Furniture):
    name = settings.LABEL_KEY["furniture"]["bedroom"]["wardrobe"]["name"]
    type = settings.LABEL_KEY["furniture"]["bedroom"]["wardrobe"]["type_id"]
    bed_wall_idx = 1

    def __init__(self, baseline, depth):
        super(Wardrobe, self).__init__(baseline, depth)


class Drawers(Furniture):
    name = settings.LABEL_KEY["furniture"]["bedroom"]["drawers"]["name"]
    type = settings.LABEL_KEY["furniture"]["bedroom"]["drawers"]["type_id"]
    bed_wall_idx = 0

    def __init__(self, baseline, depth):
        super(Drawers, self).__init__(baseline, depth)
