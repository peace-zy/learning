# coding=utf-8
from shapely.geometry import LineString, MultiLineString, Polygon
import numpy as np
import copy
import json

import frame_remould.utils.basic as basic
import frame_remould.settings as settings
import frame_remould.utils.geo_utils as geo_utils
import frame_remould.room_types.furniture as furniture
from frame_remould.settings import RULE_PARAM
from frame_remould.settings import LABEL_KEY
from frame_remould.settings import DOC


def get_hallway_contours(entrance, region):
    """
    获取玄关区域多边形
    """
    entrance_wall = region.id_walls.get(entrance.wall_id)
    if entrance_wall.segment2d.length < RULE_PARAM["hallway"]["entrance_wall_max"]:
        pts0 = geo_utils.get_max_rectangle_along_wall(entrance.wall_id, region)
        if pts0[0].distance(pts0[1]) < RULE_PARAM["hallway"]["little_face_dis"]:
            return pts0

    # 先沿着入户门的两个方向，寻迹一段距离
    # 第一个点在方向的后面，需要逆时针寻迹
    dis = RULE_PARAM["hallway"]["walking_dis"]
    pt_list1, ptid_list1, wallid_list1 = get_entrance_walking_path(entrance, region, dis, ccw=True)
    pt_list2, ptid_list2, wallid_list2 = get_entrance_walking_path(entrance, region, dis, ccw=False)

    # # 两个路径中最长线段的末端
    # longest_idx1 = get_longest_end_pt_idx(pt_list1)
    # longest_idx2 = get_longest_end_pt_idx(pt_list2)
    # 入户门对面组成玄关的直线
    delta_pt = geo_utils.get_normal_dir(entrance.line2d) * RULE_PARAM["hallway"]["little_face_dis"]
    face_line_p1 = entrance.line2d.p1 + delta_pt
    face_line_p2 = entrance.line2d.p2 + delta_pt
    face_line = settings.Line2D(face_line_p1, face_line_p2)
    # TODO: zhuc: 1114447528914116 门厅有问题，
    # 两个端点的投影点
    proj_p1 = face_line.projection(pt_list1[-1])
    proj_p2 = face_line.projection(pt_list2[-1])

    pts = copy.deepcopy(pt_list1)
    pts.extend([proj_p1, proj_p2])
    pt_list2_tmp = copy.deepcopy(pt_list2)
    pt_list2_tmp.reverse()
    pts.extend(pt_list2_tmp)

    hallway_poly = settings.Polygon(*pts)
    # 找到在门厅区域内的凸角点
    inner_convex = []
    for pid, pt in region.id_contours.items():
        if pt.is_convex is not True:
            continue
        inner_convex.extend(hallway_poly.intersection(pt.point2d))
        if hallway_poly.encloses_point(pt.point2d):
            inner_convex.append(pt.point2d)
    # 离门最远的凸
    dis = 0
    max_dis_pt = None
    for pt in inner_convex:
        dis_entran = entrance.line2d.distance(pt)
        if dis_entran > dis:
            max_dis_pt = pt
            dis = dis_entran
    # 凸点到入户门的距离设为上一个最短距离的1.5倍
    if max_dis_pt is not None and dis > RULE_PARAM["hallway"]["last_path_min"] * 1.5:
        # pts.clear()
        pts = []
        delta_pt = geo_utils.get_normal_dir(entrance.line2d) * dis
        face_line_p1 = entrance.line2d.p1 + delta_pt
        face_line_p2 = entrance.line2d.p2 + delta_pt
        face_line = settings.Line2D(face_line_p1, face_line_p2)

        # 两个路径上的线段可能与face line相交
        def get_new_pt_list(pt_list, faceline):
            new_pt_list = []
            for pt1_idx in range(len(pt_list) - 1):
                pt1 = pt_list[pt1_idx]
                pt2 = pt_list[pt1_idx + 1]
                seg = settings.Segment2D(pt1, pt2)
                inter = seg.intersection(faceline)
                new_pt_list.append(pt1)
                if len(inter) > 0:
                    new_pt_list.append(inter[0])
                    break
                # 倒数第一个点时，加上最后一个点
                if pt1_idx == len(pt_list) - 2:
                    new_pt_list.append(pt2)
            return new_pt_list

        pt_list1_a = get_new_pt_list(pt_list1, face_line)
        pt_list2_a = get_new_pt_list(pt_list2, face_line)

        # 两个端点的投影点
        proj_p1 = face_line.projection(pt_list1_a[-1])
        proj_p2 = face_line.projection(pt_list2_a[-1])

        pts = copy.deepcopy(pt_list1_a)
        pts.extend([proj_p1, proj_p2])
        pt_list2_a.reverse()
        pts.extend(pt_list2_a)
        # 利用多边形自动排除相同的多余点
        hallway_poly = settings.Polygon(*pts)
    return hallway_poly.vertices


def get_hallway_area(entrance, region):
    """
    获取玄关区域多边形
    """
    entrance_wall = region.id_walls.get(entrance.wall_id)
    if entrance_wall.segment2d.length < settings.RULE_PARAM.hallway_entrance_wall_max:
        pts0 = geo_utils.get_max_rectangle_along_wall(entrance.wall_id, region)
        if pts0[0].distance(pts0[1]) < settings.RULE_PARAM.hallway_face_dis:
            return pts0

    # 先沿着入户门的两个方向，寻迹一段距离
    # 第一个点在方向的后面，需要逆时针寻迹
    dis = settings.RULE_PARAM.hallway_walking_dis
    pt_list1, ptid_list1, wallid_list1 = get_walking_path(entrance, region, dis, ccw=True)
    pt_list2, ptid_list2, wallid_list2 = get_walking_path(entrance, region, dis, ccw=False)

    # 两个路径中最长线段的末端
    longest_idx1 = get_longest_end_pt_idx(pt_list1)
    longest_idx2 = get_longest_end_pt_idx(pt_list2)
    # 入户门对面组成玄关的直线
    delta_pt = geo_utils.get_normal_dir(entrance.line2d) * settings.RULE_PARAM.hallway_face_dis
    face_line_p1 = entrance.line2d.p1 + delta_pt
    face_line_p2 = entrance.line2d.p2 + delta_pt
    face_line = settings.Line2D(face_line_p1, face_line_p2)
    # 两个端点的投影点
    proj_p1 = face_line.projection(pt_list1[longest_idx1])
    proj_p2 = face_line.projection(pt_list2[longest_idx2])

    pts = []
    pts.extend(pt_list1[0: longest_idx1 + 1])
    pts.append(proj_p1)
    pts.append(proj_p2)
    pt_list2_tmp = pt_list2[0: longest_idx2 + 1]
    pt_list2_tmp.reverse()
    pts.extend(pt_list2_tmp)

    # 如果初始玄关多边形, 跨越功能区，需要求差, 保持在本区域内
    poly_in = Polygon([(p.x, p.y) for p in pts])
    poly_out = Polygon([(p.point2d.x, p.point2d.y) for p in region.id_contours.values()])
    diff = poly_in.difference(poly_out)
    poly_in = poly_in.difference(diff)
    x, y = poly_in.exterior.coords.xy
    pts = [settings.Point2D(x, y) for x, y in zip(x, y)]

    return pts

    # mlines, mlines_id_lst = geo_utils.get_MultiLineString(region.id_walls)
    # x0, y0, x1, y1 = mlines.bounds
    # cross_line = LineString([(x0, y0), (x1, y1)])
    # max_len = cross_line.length

    # ls = [l for l in mlines]
    # ls.append(cross_line)
    # mlines = MultiLineString(ls)
    # vis.show_MultiLineString(mlines)


def get_longest_end_pt_idx(points):
    """
    points: Point2D list
    return: points组成最长line的末端点
    """
    len_list = []
    for i in range(len(points) - 1):
        len_list.append(points[i].distance(points[i + 1]))
    idx = np.argmax(np.array(len_list)) + 1
    return idx


def get_direction(wall, ccw):
    p1 = get_start_pt(wall, ccw)
    p2 = get_end_pt(wall, ccw)

    # if ccw is True:
    #     p1 = get_start_pt(wall, ccw)
    #     p2 = get_end_pt(wall, ccw)
    # else:
    #     p1 = get_start_pt(wall, ccw)
    #     p2 = get_end_pt(wall, ccw)
    line = settings.Line2D(p1, p2)
    return line.direction.unit


def get_start_pt(wall, ccw, last_wall=None):
    """
    start pt定义为根据ccw方向的第一个点
    """
    if last_wall is not None and wall.region_inner is True:
        # 处理内墙方案, 如果是外轮廓，会出错
        pt = last_wall.line2d.p1 if ccw else last_wall.line2d.p2
        id_pts = {wall.p1_idx: wall.p1, wall.p2_idx: wall.p2}

        start = wall.p1 if wall.p1 == pt else wall.p2
        pt_idx = wall.p1_idx if wall.p1 == pt else wall.p2_idx
        other_idx = wall.p2_idx if wall.p1 == pt else wall.p1_idx
        wall.set_line(pt_idx, other_idx, id_pts)
        return start

    if ccw is True:
        start = wall.line2d.p2
    else:
        start = wall.line2d.p1
    return start


def get_end_pt(wall, ccw):
    if ccw is True:
        end = wall.line2d.p1
    else:
        end = wall.line2d.p2
    return end


def get_walking_path(line_item, region, dis, ccw=True):
    """
    以point为起点，沿着功能区墙体顺时针（或逆时针）移动一定距离
    返回以轮廓上某一个点为起点，沿着一个方向走，路径刚好大于一定距离的和合集
    pt_list: 点坐标集合
    ptid_list: 点ID合集，注意数量要比坐标合集少一个, 起始点
    wallid_list: 所在墙的ID合集
    """

    id_walls = region.id_walls
    start_line = id_walls[line_item.wall_id]

    pt_list = []
    wallid_list = []
    ptid_list = []
    total_len = 0

    # p1, p1_id = get_end_pt(line_item, ccw)
    p1 = line_item.segment2d.midpoint
    p2, p2_id = geo_utils.get_end_pt_and_id(start_line, ccw)

    total_len += float(p1.distance(p2))
    res_len = dis - total_len

    # 如果第一个墙就大于阈值，则直接返回
    if res_len <= 0:
        res_dir = (p2 - p1).unit
        p2 = p1 + res_dir * dis
        pt_list.extend([p1, p2])
        wallid_list.append(line_item.wall_id)
        return pt_list, ptid_list, wallid_list
    else:
        pt_list.extend([p1, p2])
        wallid_list.append(line_item.wall_id)
        ptid_list.append(p2_id)

    while True:
        next_lines = region.id_pts[ptid_list[-1]].lines
        # 去除不在本区域的墙
        next_lines = [l for l in next_lines if l in list(region.id_walls.keys())]
        # 去除来源所在墙体
        next_lines = [l for l in next_lines if l != wallid_list[-1]]

        if len(next_lines) == 1:
            next_line_id = next_lines[0]
        else:
            # 功能区内有墙的情况，不能沿着外轮廓寻迹
            next_lines = [l for l in next_lines if id_walls[l].line2d is None]
            # 不在轮廓上的点，有时候路径会比较短
            # 条件1：房间的内墙，游走到终点
            if len(next_lines) == 0:
                break
            next_line_id = next_lines[0]

        next_line = region.id_walls.get(next_line_id)

        if next_line.line2d is not None:
            pt, pt_id = geo_utils.get_end_pt_and_id(next_line, ccw)
            last_pt = get_start_pt(next_line, ccw)
        else:
            # 处理不在轮廓上的点
            last_pt = pt_list[-1]
            if last_pt.distance(next_line.p1) < last_pt.distance(next_line.p2):
                pt = next_line.p2
                pt_id = next_line.p2_id
            else:
                pt = next_line.p1
                pt_id = next_line.p1_id
            # 对于不在轮廓上的墙，也需要设置法线方向，以便后续计算门厅柜摆放
            # next_line.set_line(ptid_list[-1], pt_id, region.id_pts)

        res_dir = (pt - last_pt).unit
        res_pt = last_pt + res_dir * res_len
        total_len += pt_list[-1].distance(pt)

        # 如果转弯过大，则停止寻迹
        # 判断入户方向
        entrance_dir = settings.Ray2D(settings.Point2D(0, 0),
                                      geo_utils.get_normal_dir(line_item.line2d))
        entr_mid = line_item.segment2d.midpoint
        res_entr_ray = settings.Ray2D(entr_mid, res_pt)
        thre_degree = np.rad2deg(float(settings.pi / 2)) + settings.RULE_PARAM.hallway_turn_degree
        # 入户方向与入户门和沿墙寻迹末端点连线方向的夹角
        angle = np.rad2deg(float(res_entr_ray.angle_between(entrance_dir)))
        # 条件2：不能是和入户方向相反的折现
        if angle > thre_degree:
            break

        ptid_list.append(pt_id)
        wallid_list.append(next_line_id)

        if total_len > dis:
            # 寻迹的最后一个点通常不是墙的顶点
            # 条件3：距离
            pt_list.append(res_pt)
            break
        else:
            pt_list.append(pt)
            res_len = dis - total_len
    return pt_list, ptid_list, wallid_list


def get_entrance_walking_path(entrance, region, dis, ccw):
    id_walls = region.id_walls
    start_wall = id_walls[entrance.wall_id]

    pt_list = []
    wallid_list = []
    ptid_list = []
    total_len = 0

    p1 = entrance.segment2d.midpoint
    p2, p2_id = geo_utils.get_end_pt_and_id(start_wall, ccw)

    total_len += float(p1.distance(p2))
    res_len = dis - total_len

    # 如果第一个墙就大于阈值，则直接返回
    if res_len <= 0:
        res_dir = (p2 - p1).unit
        p2 = p1 + res_dir * dis
        pt_list.extend([p1, p2])
        wallid_list.append(entrance.wall_id)
        return pt_list, ptid_list, wallid_list
    else:
        pt_list.extend([p1, p2])
        wallid_list.append(entrance.wall_id)
        ptid_list.append(p2_id)

    while True:
        next_wall_id = geo_utils.get_next_walking_wall_id(wallid_list[-1], region, ccw)
        # 终止条件1：功能区的不在轮廓的内墙可能较短，提前到达终点
        if next_wall_id is None:
            break
        next_wall = id_walls.get(next_wall_id)
        # 对于不在轮廓上的内墙，也需要设置法线方向，以便后续计算门厅柜摆放
        # 方向要沿着连接的外墙方向
        # TODO: 可能会被复用
        if next_wall.line2d is None:
            if ccw:
                if next_wall.p1_id == ptid_list[-1]:
                    ptid1 = next_wall.p2_id
                else:
                    ptid1 = next_wall.p1_id
            else:
                ptid1 = ptid_list[-1]
            next_wall.set_line_pt1(ptid1, region.id_pts)

        # 下一个点
        last_pt = pt_list[-1]
        if last_pt.distance(next_wall.p1) < last_pt.distance(next_wall.p2):
            pt = next_wall.p2
            pt_id = next_wall.p2_id
        else:
            pt = next_wall.p1
            pt_id = next_wall.p1_id

        # 终止条件2： 如果点位凸点切前一个墙长度大于500则终止
        # is_convex = geo_utils.is_convex_pt(ptid_list[-1], region)
        con_pt = region.id_contours.get(ptid_list[-1])
        if con_pt is not None:
            # 处理内墙拐弯情况
            is_convex = region.id_contours[ptid_list[-1]].is_convex
        else:
            is_convex = False
        last_len = pt_list[-1].distance(pt_list[-2])
        if is_convex and last_len > RULE_PARAM["hallway"]["last_path_min"]:
            break

        res_dir = (pt - last_pt).unit
        res_pt = last_pt + res_dir * res_len
        total_len += pt_list[-1].distance(pt)

        ptid_list.append(pt_id)
        wallid_list.append(next_wall_id)

        if total_len > dis:
            # 寻迹的最后一个点通常不是墙的顶点
            # 条件3：距离阈值
            pt_list.append(res_pt)
            break
        else:
            pt_list.append(pt)
            res_len = dis - total_len
    return pt_list, ptid_list, wallid_list


def get_max_dis_along_wall(pt, wall, wall_items, id_wall_items, ccw):
    """
    pt点保证在墙上，沿着pt点游走的最大距离, 直到遇到门窗等附件
    """
    # 对region内墙配置line2d
    if wall.region_inner:
        pt_is_p1 = False
        if wall.p1.distance(pt) < wall.p2.distance(pt):
            pt_is_p1 = True
        if pt_is_p1 and ccw:
            wall.set_line_p1p2(inverse=True)
        elif pt_is_p1 is False and ccw is False:
            wall.set_line_p1p2(inverse=True)
        elif pt_is_p1 is True and ccw is False:
            wall.set_line_p1p2(inverse=False)
        elif pt_is_p1 is False and ccw is True:
            wall.set_line_p1p2(inverse=False)

    end_pt = get_end_pt(wall, ccw)

    min_dis = pt.distance(end_pt)
    for item in wall_items:
        dis = id_wall_items[item].segment2d.distance(pt)
        if dis < min_dis:
            min_dis = dis
    return min_dis


def get_side_lay(floorplan, right=True):
    """
    沿着入户门，尝试侧放门厅柜
    """
    # 右侧总是逆时针路径
    ccw = True if right is True else False
    region, entrance = floorplan.get_entrance_region()
    dis = RULE_PARAM["hallway"]["walking_dis"]
    pt_list, ptid_list, wallid_list = get_entrance_walking_path(entrance, region, dis, ccw=ccw)

    entrance_norm = geo_utils.get_normal_dir(entrance.line2d)

    fn_list = []
    # TODO: 没有考虑同一个直线的墙
    for idx, w_id in enumerate(wallid_list):
        wall = region.id_walls.get(w_id)
        # angle = np.rad2deg(wall.segment2d.smallest_angle_between(entrance.line2d))
        is_parallel = geo_utils.is_parallel_wall(wall, entrance)
        # if_perp = wall.segment2d.is_perpendicular(entrance.line2d)
        if not is_parallel:
            # 侧放的墙一定和入户门墙平行
            continue
        if wall.line2d is None:
            # 侧放必须在外轮廓墙上
            continue
        pt0 = get_start_pt(wall, ccw)
        wall_items = geo_utils.get_wall_items_along_wall(w_id, region.id_wall_items)
        if idx == 0:
            pt0 = get_end_pt(entrance, ccw)
            wall_items.remove(entrance.id)

        walking_dir = get_direction(wall, ccw)
        # 如果沿着墙走，碰到门窗则停下来, 得到门厅柜的基线两点
        max_width = get_max_dis_along_wall(
            pt0, wall, wall_items, region.id_wall_items, ccw)
        if max_width == 0:
            continue
        pt1 = pt0 + walking_dir * max_width

        # 左放右放有区别
        if right is True:
            baseline = settings.Line2D(pt1, pt0)
        else:
            baseline = settings.Line2D(pt0, pt1)

        depth = RULE_PARAM["hallway"]["cab_custom_depth_max"]
        cab = furniture.HallwayCabinet(baseline, depth)
        cab.set_wall_id(w_id)
        # 侧放必放成品柜
        cab.set_tag(RULE_PARAM["hallway"]["cab_manufacture_tag"])
        if right:
            cab.set_lay_kind(LABEL_KEY["hallway"]["cab_lay_kind"]["right_side_lay"])
        else:
            cab.set_lay_kind(LABEL_KEY["hallway"]["cab_lay_kind"]["left_side_lay"])

        # if cab_depth_correction(cab, region) is False:
        #     continue
        depth_cor_flag = cab_depth_correction(cab, region)
        if depth_cor_flag is False:
            # 门厅柜深度校正不通过时，尝试修正width, 以远离门
            width_cor_flag = cab_width_correction_side(cab, ccw)
            if width_cor_flag is False:
                continue

        # 左右放有区别
        if right is True:
            fixed_pt = cab.baseline.p2
        else:
            fixed_pt = cab.baseline.p1
        if cabinet_width_check(cab, fixed_pt) is False:
            continue

        lay_kind = LABEL_KEY["hallway"]["cab_lay_kind"]["right_side_lay"]
        if right is False:
            lay_kind = LABEL_KEY["hallway"]["cab_lay_kind"]["left_side_lay"]
        if cabinet_entrance_dis_check(cab, entrance, lay_kind) is False:
            continue

        fn_list.append(cab)
        break

    for f in fn_list:
        geo_utils.furniture_correction(f, region)
        if not cabinet_width_check(f, f.baseline.p1):
            fn_list.remove(f)

    return fn_list


def cabinet_depth_correction_old(cab, region, ccw):
    side1, side2 = cab.get_side_line()
    if ccw:
        side_line = side1
    else:
        side_line = side2
    # cab_wall = region.id_walls[cab.wall_id]
    next_wall_id = geo_utils.get_next_walking_wall_id(cab.wall_id, region, ccw)
    if next_wall_id is None:
        # 内墙到达终点
        return cab
    next_wall = region.id_walls[next_wall_id]
    if len(next_wall.segment2d.intersection(side_line.p1)) > 0:
        # 门厅柜边缘在下一个墙上，有交点，需要计算交点到门窗的距离
        wall_items = geo_utils.get_wall_items_along_wall(next_wall_id, region.id_wall_items)
        max_path = get_max_dis_along_wall(
            side_line.p1, next_wall, wall_items,
            region.id_wall_items,
            ccw
        )
        min_dep = RULE_PARAM["hallway"]["cab_custom_depth_min"]
        max_dep = RULE_PARAM["hallway"]["cab_custom_depth_max"]
        if max_path < min_dep:
            # 侧边挡一些门窗也可以
            cab.set_depth(min_dep)
        elif max_dep > max_path > min_dep:
            cab.set_depth(max_path)
        elif max_path > max_dep:
            cab.set_depth(max_dep)
    return cab


def cab_depth_correction(cab, region):
    def get_sidesegs_sidelines(cab, ref_line=None):
        if ref_line is not None:
            cab.set_normal_line(ref_line)

        side1, side2 = cab.get_side_line()
        sideseg1 = settings.Segment2D(side1.p1, side1.p2)
        sideseg2 = settings.Segment2D(side2.p1, side2.p2)
        sidesegs = [sideseg1, sideseg2]
        sidelines = [side1, side2]
        return sidesegs, sidelines

    sidesegs, sidelines = get_sidesegs_sidelines(cab)
    # side1, side2 = cab.get_side_line()
    # sideseg1 = settings.Segment2D(side1.p1, side1.p2)
    # sideseg2 = settings.Segment2D(side2.p1, side2.p2)
    # sidesegs = [sideseg1, sideseg2]
    # sidelines = [side1, side2]
    inter_walls = [None, None]
    # 门厅柜边线线段有重合的墙作为相交的墙
    for wid, w in region.id_walls.items():
        wseg = w.segment2d
        # TODO: 更新sidesegs,减少误差，frame_ID: 11000000764363
        if geo_utils.is_parallel(sidesegs[0], wseg):
            inter1 = sidesegs[0].intersection(wseg)
            inter2 = sidesegs[1].intersection(wseg)
            if len(inter1) > 0 or len(inter2) > 0:
                sidesegs, sidelines = get_sidesegs_sidelines(cab, wseg)

        if geo_utils.is_parallel(wseg, sidesegs[0]):
            side1, side2 = cab.get_side_line()
            sideseg1 = settings.Segment2D(side1.p1, side1.p2)
            sideseg2 = settings.Segment2D(side2.p1, side2.p2)
            sidesegs = [sideseg1, sideseg2]

        for idx, sideseg in enumerate(sidesegs):
            inters = wseg.intersection(sideseg)
            if len(inters) != 1:
                continue
            if isinstance(inters[0], settings.Segment2D):
                inter_walls[idx] = wid

    depth = cab.depth
    # thickness = region.id_walls[cab.wall_id].thickness
    for idx, wid in enumerate(inter_walls):
        if wid is None:
            continue
        ccw = True if idx == 0 else False
        wall_items = geo_utils.get_wall_items_along_wall(wid, region.id_wall_items)
        max_path = get_max_dis_along_wall(
            sidelines[idx].p1, region.id_walls[wid],
            wall_items,
            region.id_wall_items,
            ccw
        )
        # max_path -= thickness
        if max_path < 0:
            depth = 10
        elif max_path < depth:
            depth = max_path

    if depth < RULE_PARAM["hallway"]["cab_custom_depth_min"]:
        cab.set_tag(RULE_PARAM["hallway"]["cab_manufacture_tag"])
    if depth < RULE_PARAM["hallway"]["cab_manufacture_depth_min"]:
        return False
    cab.set_depth(depth)
    return True


def cabinet_width_check(cab, fixed_pt):
    """
    检查门厅柜宽度是否合理
    """
    if cab.width < RULE_PARAM["hallway"]["cab_length_min"]:
        return False
    elif cab.width > RULE_PARAM["hallway"]["cab_length_max"]:
        side_list = [
            LABEL_KEY["hallway"]["cab_lay_kind"]["right_side_lay"],
            LABEL_KEY["hallway"]["cab_lay_kind"]["left_side_lay"]
        ]
        if cab.lay_kind in side_list:
            # 侧放直接控制宽度
            cab.set_width(RULE_PARAM["hallway"]["cab_length_max"], fixed_pt)
        else:
            # 立放和对放判断剩余距离
            res_dis = cab.width - RULE_PARAM["hallway"]["cab_length_max"]
            if res_dis > RULE_PARAM["hallway"]["residual_dis"]:
                # 剩余距离太大，则按着最大宽度配置
                cab.set_width(RULE_PARAM["hallway"]["cab_length_max"], fixed_pt)
        return True
    else:
        return True


def cabinet_entrance_dis_check(cab, entrance, lay_kind):
    """
    判断门厅柜和入户门的最短距离是否合适
    暂时只有侧放才适用
    """
    # dis1 = cab.get_polygon().distance(entrance.segment2d.p1)
    # dis2 = cab.get_polygon().distance(entrance.segment2d.p2)
    # dis = np.min([dis1, dis2])
    dis1 = cab.get_polygon().distance(entrance.segment2d.p1)
    dis2 = cab.get_polygon().distance(entrance.segment2d.p2)
    dis = np.min((dis1, dis2))
    threshold = 0
    side_list = [
        LABEL_KEY["hallway"]["cab_lay_kind"]["right_side_lay"],
        LABEL_KEY["hallway"]["cab_lay_kind"]["left_side_lay"]
    ]
    vertical_list = [
        LABEL_KEY["hallway"]["cab_lay_kind"]["right_vertical_lay"],
        LABEL_KEY["hallway"]["cab_lay_kind"]["left_vertical_lay"]
    ]
    if lay_kind in side_list:
        threshold = RULE_PARAM["hallway"]["entrance_cab_sidelay_dis_max"]
    elif lay_kind in vertical_list:
        threshold = RULE_PARAM["hallway"]["entrance_cab_vertlay_dis_max"]

    if dis > threshold:
        return False
    else:
        return True


def cabinet_vertical_entrance_angle_check(cab, entrance, ccw):
    side1, side2 = cab.get_side_line()
    side = side2 if ccw else side1
    cab_pt = side.p1
    entra_p1 = entrance.line2d.p2 if ccw else entrance.line2d.p1
    entra_p2 = entrance.line2d.p1 if ccw else entrance.line2d.p2
    ray_entr = settings.Ray2D(entra_p1, entra_p2)
    ray_cab = settings.Ray2D(entra_p1, cab_pt)
    ang = np.rad2deg(float(ray_entr.smallest_angle_between(ray_cab)))

    if ang > RULE_PARAM["hallway"]["entrance_cab_angle_max"]:
        return False
    else:
        return True


def get_vertical_lay(floorplan, right=True):
    # 右侧总是逆时针路径
    ccw = True if right is True else False
    region, entrance = floorplan.get_entrance_region()
    dis = RULE_PARAM["hallway"]["walking_dis"]
    pt_list, ptid_list, wallid_list = get_entrance_walking_path(entrance, region, dis, ccw=ccw)
    id_walls = region.id_walls

    fn_list, co_walls0 = [], []
    for idx, w_id in enumerate(wallid_list):
        wall = region.id_walls.get(w_id)
        is_perpendicular = geo_utils.is_perpendicular_wall(wall, entrance)
        if not is_perpendicular:
            # 立放一定和入户门垂直
            continue
        if w_id in co_walls0:
            # 已经计算过的共线墙，不再做计算
            continue

        co_walls = geo_utils.get_collineation_connected_wall(w_id, region, ccw)
        co_walls0.extend(co_walls)

        first_id, last_id = co_walls[0], co_walls[-1]
        pt0 = get_start_pt(id_walls[first_id], ccw)
        walking_dir = get_direction(wall, ccw)

        wall_dis = 0
        for idx, co_w_id in enumerate(co_walls):
            last_wall = None
            if idx > 0:
                last_wall = id_walls[co_walls[idx - 1]]
            co_pt0 = get_start_pt(id_walls[co_w_id], ccw, last_wall=last_wall)
            co_wall = id_walls[co_w_id]
            wall_items = geo_utils.get_wall_items_along_wall(co_w_id, region.id_wall_items)
            max_width = get_max_dis_along_wall(
                co_pt0, co_wall, wall_items, region.id_wall_items, ccw)
            wall_dis += max_width
            if len(wall_items) > 0:
                break

        if wall_dis == 0:
            continue
        pt1 = pt0 + walking_dir * wall_dis
        # 左放右放有区别
        if right is True:
            baseline = settings.Line2D(pt1, pt0)
        else:
            baseline = settings.Line2D(pt0, pt1)
        depth = RULE_PARAM["hallway"]["cab_custom_depth_max"]
        cab = furniture.HallwayCabinet(baseline, depth)
        cab.set_wall_id(w_id)
        if right:
            cab.set_lay_kind(LABEL_KEY["hallway"]["cab_lay_kind"]["right_vertical_lay"])
        else:
            cab.set_lay_kind(LABEL_KEY["hallway"]["cab_lay_kind"]["left_vertical_lay"])
        # 立放优先定制柜
        cab.set_tag(RULE_PARAM["hallway"]["cab_custom_tag"])

        depth_cor_flag = cab_depth_correction(cab, region)
        if depth_cor_flag is False:
            # 门厅柜深度校正不通过时，尝试修正width, 以远离入户门的端点为锚点
            width_cor_flag = cab_width_correction_vertical(cab, region)
            if width_cor_flag is False:
                continue
        # if cab.depth < RULE_PARAM["hallway"]["cab_custom_depth_min"]:
        #     cab.set_tag(RULE_PARAM["hallway"]["cab_manufacture_tag"])

        if right is True:
            fixed_pt = cab.baseline.p2
        else:
            fixed_pt = cab.baseline.p1
        if cabinet_width_check(cab, fixed_pt) is False:
            continue

        lay_kind = LABEL_KEY["hallway"]["cab_lay_kind"]["right_vertical_lay"]
        if right is False:
            lay_kind = LABEL_KEY["hallway"]["cab_lay_kind"]["left_vertical_lay"]

        # 末端和入户门的夹角
        if cabinet_vertical_entrance_angle_check(cab, entrance, ccw) is False:
            continue

        if cabinet_entrance_dis_check(cab, entrance, lay_kind) is False:
            continue

        fn_list.append(cab)
        break

    for f in fn_list:
        geo_utils.furniture_correction(f, region)
        if not cabinet_width_check(f, f.baseline.p1):
            fn_list.remove(f)

    return fn_list


def cab_width_correction_vertical(cab, region):
    # 立放两边都要校正
    if cab.width <= RULE_PARAM["hallway"]["width_correction_len"]:
        return False

    side1, side2 = cab.get_side_line()
    sideseg1 = settings.Segment2D(side1.p1, side1.p2)
    sideseg2 = settings.Segment2D(side2.p1, side2.p2)
    sidesegs = [sideseg1, sideseg2]
    sidelines = [side1, side2]
    inter_walls = [None, None]
    # 门厅柜边线线段有重合的墙作为相交的墙
    for wid, w in region.id_walls.items():
        wseg = w.segment2d
        for idx, sideseg in enumerate(sidesegs):
            inters = wseg.intersection(sideseg)
            if len(inters) != 1:
                continue
            if isinstance(inters[0], settings.Segment2D):
                inter_walls[idx] = wid

    fixed_dict = {0: 1, 1: 0}
    for idx, wid in enumerate(inter_walls):
        if wid is None:
            continue
        wall_items = geo_utils.get_wall_items_along_wall(wid, region.id_wall_items)
        for item_id in wall_items:
            item = region.id_wall_items.get(item_id)
            # 垭口排除
            if item.type == settings.FRAME_KEY["line_items"]["types"]["opening_door"]:
                continue
            inters = item.segment2d.intersection(sidesegs[idx])
            if len(inters) != 1:
                continue
            if not isinstance(inters[0], settings.Segment2D):
                continue
            width = cab.width - RULE_PARAM["hallway"]["width_correction_len"]
            if width <= 0:
                return False
            fixpt = sidelines[fixed_dict[idx]].p1
            cab.set_width(width, fixpt)
            side1, side2 = cab.get_side_line()
            sidelines = [side1, side2]

    if cab.width < RULE_PARAM["hallway"]["cab_length_min"]:
        return False
    return True

    # if cab.width <= entrance.segment2d.length:
    #     return False
    # p1, p2 = cab.baseline.p1, cab.baseline.p2
    # dis1 = entrance.segment2d.distance(cab.baseline.p1)
    # dis2 = entrance.segment2d.distance(cab.baseline.p2)
    # anchor = p1 if dis1 > dis2 else p2
    # non_anchor = p2 if dis1 > dis2 else p1
    # dir0 = settings.Line2D(non_anchor, anchor).unit
    # non_anchor2 = non_anchor + dir0 * RULE_PARAM["hallway"]["width_correction_len"]
    #
    # new_width = non_anchor2.distance(anchor)
    # if new_width < RULE_PARAM["hallway"]["cab_length_min"]:
    #     return False
    # else:
    #     if anchor == p1:
    #         baseline = settings.Line2D(anchor, non_anchor2)
    #     else:
    #         baseline = settings.Line2D(non_anchor2, anchor)
    #     cab.set_baseline(baseline)
    #     return True


def cab_width_correction_side(cab, ccw):
    if cab.width <= RULE_PARAM["hallway"]["width_correction_len"]:
        return False
    p1, p2 = cab.baseline.p1, cab.baseline.p2
    anchor = p2 if ccw else p1
    non_anchor = p1 if ccw else p2

    # next_wall = geo_utils.get_next_walking_wall_id(cab.wall_id, region, ccw)
    # wall_items = geo_utils.get_wall_items_along_wall(next_wall, region.id_wall_items)
    dir0 = settings.Line2D(non_anchor, anchor).unit
    non_anchor2 = non_anchor + dir0 * RULE_PARAM["hallway"]["width_correction_len"]

    new_width = non_anchor2.distance(anchor)
    if new_width < RULE_PARAM["hallway"]["cab_length_min"]:
        return False
    else:
        if anchor == p1:
            baseline = settings.Line2D(anchor, non_anchor2)
        else:
            baseline = settings.Line2D(non_anchor2, anchor)
        cab.set_baseline(baseline)
        return True


def get_face_lay(floorplan):
    region, entrance = floorplan.get_entrance_region()
    entrance_wall = region.id_walls.get(entrance.wall_id)
    # face_wall = None
    # dis = np.infty
    fn_list = []
    for wid, wall in region.id_walls.items():
        if not basic.Wall.check(wall):
            continue
        if geo_utils.is_perpendicular_wall(wall, entrance_wall):
            continue
        if wid == entrance.wall_id:
            continue

        angle = np.rad2deg(float(wall.segment2d.smallest_angle_between(entrance.segment2d)))
        if angle > RULE_PARAM["hallway"]["face_entrance_wall_angle"]:
            continue
        p1_pro = entrance.segment2d.projection(wall.p1)
        p2_pro = entrance.segment2d.projection(wall.p2)
        seg_pro = settings.Segment2D(p1_pro, p2_pro)
        inters = seg_pro.intersection(entrance.segment2d)
        # 对面的墙在入户门的投影必须有一定程度的重合
        if len(inters) != 1:
            continue
        if not isinstance(inters[0], settings.Segment2D):
            continue
        length_thre = entrance.segment2d.length * RULE_PARAM["hallway"]["face_coin_ratio"]
        if inters[0].length < length_thre:
            continue
        face_dis = entrance.line2d.distance(wall.p1)
        face_thre = RULE_PARAM["hallway"]["little_face_dis"]
        if floorplan.get_total_area_in_m2() > RULE_PARAM["hallway"]["area_thre"]:
            face_thre = RULE_PARAM["hallway"]["big_face_dis"]
        if face_dis > face_thre:
            continue
        # 区分门厅柜的p1,p2
        entr_mid = entrance.segment2d.midpoint
        if (p1_pro - entr_mid).unit == entrance.line2d.unit:
            cab_wall_p1 = wall.p1
            cab_wall_p2 = wall.p2
        else:
            cab_wall_p1 = wall.p2
            cab_wall_p2 = wall.p1
        # 确认门厅柜的长度
        l = settings.Line2D(wall.p1, wall.p2)
        cab_mid = l.projection(entr_mid)
        half_cab_max = 0.5 * RULE_PARAM["hallway"]["cab_length_max"]
        if cab_wall_p1.distance(cab_mid) > half_cab_max:
            dire = (cab_mid - cab_wall_p1).unit
            cab_wall_p1 = cab_mid - dire * half_cab_max
        if cab_wall_p2.distance(cab_mid) > half_cab_max:
            dire = (cab_mid - cab_wall_p2).unit
            cab_wall_p2 = cab_mid - dire * half_cab_max

        baseline = settings.Line2D(cab_wall_p1, cab_wall_p2)
        depth = RULE_PARAM["hallway"]["cab_custom_depth_max"]
        cab = furniture.HallwayCabinet(baseline, depth)
        cab.set_tag(RULE_PARAM["hallway"]["cab_custom_tag"])
        cab.set_lay_kind(LABEL_KEY["hallway"]["cab_lay_kind"]["face_lay"])
        cab.set_wall_id(wid)
        # 不能挡住门窗
        cab_seg = settings.Segment2D(cab_wall_p1, cab_wall_p2)
        items = geo_utils.get_wall_items_along_wall(wid, region.id_wall_items)
        coin_item_flag = False
        # baseline 有遮挡
        for item_id in items:
            item = region.id_wall_items.get(item_id)
            inters = item.segment2d.intersection(cab_seg)
            if len(inters) > 1:
                coin_item_flag = True
                break
            if len(inters) == 1 and isinstance(inters[0], settings.Segment2D):
                coin_item_flag = True
                break
        # TODO: sideline 有遮挡

        if coin_item_flag:
            continue

        fn_list.append(cab)
        break

    for f in fn_list:
        geo_utils.furniture_correction(f, region)
        if not cabinet_width_check(f, f.baseline.p1):
            fn_list.remove(f)

    return fn_list


def get_space(contours, entrance):
    """
    得到门厅左边，右边，前方的空间距离
    """
    hallway_poly = settings.Polygon(*contours)
    l_entr_max_dis = [0, 0, 0]  # 0: 右边， 1： 左边, 2: 对面
    l_entr_max_dis_idx = [-1, -1, -1]
    idx_dict = {0: 1, 1: 0}  # line2d的顺序和max_dis数组顺序不同
    entr_mid = entrance.segment2d.midpoint
    for idxs, s in enumerate(hallway_poly.sides):
        if geo_utils.is_parallel(s, entrance.line2d):
            # 进深
            dis = entrance.line2d.distance(s.p1)
            if dis > l_entr_max_dis[2]:
                l_entr_max_dis[2] = dis
                l_entr_max_dis_idx[2] = idxs

        for idx, entr_pt in enumerate(entrance.line2d.points):
            if not geo_utils.is_perpendicular(s, entrance.line2d):
                continue
            l = settings.Line2D(s.p1, s.p2)
            entr_proj = entrance.line2d.projection(s.p1)
            proj_dir = settings.Ray2D(entr_mid, entr_proj)

            dir_func = geo_utils.is_same_direction
            if idx == 1:
                dir_func = geo_utils.is_opposite_direction

            if dir_func(proj_dir, entrance.line2d):
                # 门厅轮廓对入户墙的投影直线要根据左右两端方向区分
                continue
            if entrance.segment2d.contains(entr_proj):
                continue

            dis = l.distance(entr_pt)
            if dis > l_entr_max_dis[idx_dict[idx]]:
                l_entr_max_dis[idx_dict[idx]] = dis
                l_entr_max_dis_idx[idx_dict[idx]] = idxs

    return l_entr_max_dis


def get_left_right_label(dis):
    ratio = RULE_PARAM["hallway"]["label_open_ratio"]
    open_threshold = RULE_PARAM["hallway"]["walking_dis"] * ratio
    narrow_threshold = RULE_PARAM["hallway"]["cab_manufacture_depth_min"]
    if dis >= open_threshold:
        return LABEL_KEY["hallway"]["space"]["open"]
    if narrow_threshold < dis < open_threshold:
        return LABEL_KEY["hallway"]["space"]["appropriate"]
    if narrow_threshold >= dis:
        return LABEL_KEY["hallway"]["space"]["narrow"]


def get_hallway_dict():
    hallway_dict = dict()
    return hallway_dict


def get_space_doc(contours, entrance, region):
    ana_dict = dict()

    space = get_space(contours, entrance)
    depth = int(space[2] / 10) * 10
    width = space[0] + space[1] + entrance.segment2d.length
    width = int(width / 10) * 10
    l_label = get_left_right_label(space[0])
    r_label = get_left_right_label(space[1])

    label_key = str(l_label) + str(r_label)
    label_doc = DOC["hallway"]["space_label_doc"][label_key]
    ana_dict[DOC["hallway"]["right_label_name"]] = r_label
    ana_dict[DOC["hallway"]["left_label_name"]] = l_label
    ana_dict["space_label_doc"] = label_doc

    ana_dict[DOC["hallway"]["width"]] = width
    ana_dict[DOC["hallway"]["depth"]] = depth

    space_ana_doc = DOC["hallway"]["space_doc"].format(**(ana_dict))
    ana_dict["space_doc"] = space_ana_doc

    # 门厅左右的距离
    ana_dict['left_dis'] = space[0]
    ana_dict['right_dis'] = space[1]

    return ana_dict


def get_ordered_cabinet(layout_res):
    cab_list = []

    def get_cabinet_order_width(cab_list):
        if cab_list[0].width > cab_list[1].width:
            return 1
        else:
            return -1

    def get_cabinet_order_depth(cab_list):
        dep1 = RULE_PARAM["hallway"]["cab_custom_depth_common"]
        dep2 = RULE_PARAM["hallway"]["cab_custom_depth_min"]
        cof = 1
        if cab_list[0].depth < dep1 and cab_list[1].depth > dep1:
            return -1
        if cab_list[0].depth < dep2 and cab_list[1].depth > dep2:
            return -1
        return cof

    # 对放优先
    if len(layout_res[settings.HALLWAY_RES_FACE_LAY]) != 0:
        cab = layout_res[settings.HALLWAY_RES_FACE_LAY]
        cab_list.append({LABEL_KEY["hallway"]["cab_lay_kind"]["face_lay"]: cab[0]})

    # 两种立放都可以时比较
    if len(layout_res[settings.HALLWAY_RES_RIGHT_VERT_LAY]) != 0 and \
            len(layout_res[settings.HALLWAY_RES_LEFT_VERT_LAY]) != 0:
        rcab = layout_res[settings.HALLWAY_RES_RIGHT_VERT_LAY][0]
        lcab = layout_res[settings.HALLWAY_RES_LEFT_VERT_LAY][0]
        cabs = [lcab, rcab]
        cof_w = get_cabinet_order_width(cabs)
        if cof_w == -1:
            cabs.reverse()
        cof_d = get_cabinet_order_depth(cabs)
        if cof_d == -1:
            cabs.reverse()
        if lcab == cabs[0]:
            cab_list.append({LABEL_KEY["hallway"]["cab_lay_kind"]["left_vertical_lay"]: lcab})
            cab_list.append({LABEL_KEY["hallway"]["cab_lay_kind"]["right_vertical_lay"]: rcab})
        else:
            cab_list.append({LABEL_KEY["hallway"]["cab_lay_kind"]["right_vertical_lay"]: rcab})
            cab_list.append({LABEL_KEY["hallway"]["cab_lay_kind"]["left_vertical_lay"]: lcab})

    # 只能一种立放时候，直接插入门厅柜
    if len(layout_res[settings.HALLWAY_RES_RIGHT_VERT_LAY]) == 0 and \
            len(layout_res[settings.HALLWAY_RES_LEFT_VERT_LAY]) != 0:
        cab = layout_res[settings.HALLWAY_RES_LEFT_VERT_LAY]
        cab_list.append({LABEL_KEY["hallway"]["cab_lay_kind"]["left_vertical_lay"]: cab[0]})

    if len(layout_res[settings.HALLWAY_RES_RIGHT_VERT_LAY]) != 0 and \
            len(layout_res[settings.HALLWAY_RES_LEFT_VERT_LAY]) == 0:
        cab = layout_res[settings.HALLWAY_RES_RIGHT_VERT_LAY]
        cab_list.append({LABEL_KEY["hallway"]["cab_lay_kind"]["right_vertical_lay"]: cab[0]})
    # 两种侧放比较
    if len(layout_res[settings.HALLWAY_RES_RIGHT_SIDE_LAY]) != 0 and \
            len(layout_res[settings.HALLWAY_RES_LEFT_SIDE_LAY]) != 0:
        rcab = layout_res[settings.HALLWAY_RES_RIGHT_SIDE_LAY][0]
        lcab = layout_res[settings.HALLWAY_RES_LEFT_SIDE_LAY][0]
        cabs = [lcab, rcab]
        cof_w = get_cabinet_order_width(cabs)
        if cof_w == -1:
            cabs.reverse()
        cof_d = get_cabinet_order_depth(cabs)
        if cof_d == -1:
            cabs.reverse()
        if lcab == cabs[0]:
            cab_list.append({LABEL_KEY["hallway"]["cab_lay_kind"]["right_side_lay"]: lcab})
            cab_list.append({LABEL_KEY["hallway"]["cab_lay_kind"]["left_side_lay"]: rcab})
        else:
            cab_list.append({LABEL_KEY["hallway"]["cab_lay_kind"]["right_side_lay"]: rcab})
            cab_list.append({LABEL_KEY["hallway"]["cab_lay_kind"]["left_side_lay"]: lcab})

    if len(layout_res[settings.HALLWAY_RES_RIGHT_SIDE_LAY]) == 0 and \
            len(layout_res[settings.HALLWAY_RES_LEFT_SIDE_LAY]) != 0:
        cab = layout_res[settings.HALLWAY_RES_LEFT_SIDE_LAY]
        cab_list.append({LABEL_KEY["hallway"]["cab_lay_kind"]["right_side_lay"]: cab[0]})
    if len(layout_res[settings.HALLWAY_RES_RIGHT_SIDE_LAY]) != 0 and \
            len(layout_res[settings.HALLWAY_RES_LEFT_SIDE_LAY]) == 0:
        cab = layout_res[settings.HALLWAY_RES_RIGHT_SIDE_LAY]
        cab_list.append({LABEL_KEY["hallway"]["cab_lay_kind"]["left_side_lay"]: cab[0]})

    return cab_list


def get_layout_doc(layout_res):
    ana_dict = dict()
    layout_keys = [settings.HALLWAY_RES_RIGHT_SIDE_LAY,
                   settings.HALLWAY_RES_LEFT_SIDE_LAY,
                   settings.HALLWAY_RES_RIGHT_VERT_LAY,
                   settings.HALLWAY_RES_LEFT_VERT_LAY,
                   settings.HALLWAY_RES_FACE_LAY]
    for k in layout_keys:
        if len(layout_res[k]) == 0:
            ana_dict[k] = ""
            continue
        layout_kind = layout_res[k][0].lay_kind
        doc = layout_res[k][0].get_doc(layout_kind)
        ana_dict[k] = doc

    return ana_dict


def get_remould_res(floorplan, layout_res):
    ana_dict = dict()
    region, entrance = floorplan.get_entrance_region()

    layout_keys = [settings.HALLWAY_RES_RIGHT_VERT_LAY,
                   settings.HALLWAY_RES_LEFT_VERT_LAY,
                   settings.HALLWAY_RES_FACE_LAY]

    def get_longest_wall(wall_id_list, entrance, region):
        length = 0
        longest_wid = None
        for w_id in wall_id_list:
            wall = region.id_walls[w_id]
            if geo_utils.is_parallel(wall.line2d, entrance.line2d):
                continue
            if wall.segment2d.length > length:
                longest_wid = w_id

        return longest_wid

    remould_flag = True
    for k in layout_keys:
        if len(layout_res[k]) != 0:
            remould_flag = False
            # if layout_res[k][0].tag == 0:
            #     remould_flag = False
    if remould_flag == False:
        ana_dict["remould_doc"] = DOC["hallway"]["remould_doc_none"]
        return ana_dict
    # 入户门向前一定距离的点作为起始点，往左右两个方向投影
    start_pt = entrance.segment2d.midpoint + geo_utils.get_normal_dir(entrance.line2d) * 700
    entr_dir = entrance.line2d.direction.unit
    lray = settings.Ray2D(start_pt, start_pt + entr_dir * 10)
    rray = settings.Ray2D(start_pt, start_pt - entr_dir * 10)

    # 判断是否增加立放隔断
    rays = [lray, rray]
    pos_dict = {0: DOC["hallway"]["cab_pos_doc"][3], 1: DOC["hallway"]["cab_pos_doc"][1]}
    min_dis = [np.inf, np.inf] # 左右两边的距离, [左, 右]
    for wid, w in region.id_walls.items():
        for idx, ray in enumerate(rays):
            intersects = w.segment2d.intersection(ray)
            if len(intersects) > 0:
                dis = intersects[0].distance(start_pt)
                if min_dis[idx] > dis:
                    min_dis[idx] = dis

    direc_idx = np.argmax(min_dis)
    if min_dis[direc_idx] > RULE_PARAM["hallway"]["remould_vertical_dis"]:
        # 计算增量墙位置
        add_wall_p1 = entrance.segment2d.midpoint
        increment_len = RULE_PARAM["hallway"]["remould_increment_wall_length"] + 50
        add_wall_p2 = geo_utils.get_normal_dir(entrance.line2d) * increment_len
        flag = 1 if direc_idx == 0 else -1
        add_wall_dir = entrance.line2d.direction.unit * flag
        move_len = entrance.segment2d.length / 2 + RULE_PARAM["hallway"]["remould_wall_length"]
        add_wall_p2 = add_wall_p1 + add_wall_p2
        add_wall_p1 = add_wall_p1 + add_wall_dir * move_len
        add_wall_p2 = add_wall_p2 + add_wall_dir * move_len
        add_wall = settings.Segment2D(add_wall_p1, add_wall_p2)

        # 新增墙和入户门对面墙的距离
        entr_norm = geo_utils.get_normal_dir(entrance.line2d)
        add_ray = settings.Ray2D(add_wall_p1 + entr_norm * 10,
                                 add_wall_p1 + entr_norm * 20)
        min_dis = np.inf
        for wid, w in region.id_walls.items():
            intersects = w.segment2d.intersection(add_ray)
            if len(intersects) > 0:
                dis = add_wall_p1.distance(intersects[0])
                if min_dis > dis:
                    min_dis = dis

        vertical_flag = False
        # 新增门厅柜
        if min_dis > RULE_PARAM["hallway"]["remould_increment_wall_length"] + \
            RULE_PARAM["hallway"]["remould_increment_wall_dis"]:
            cab_p1 = add_wall_p1 + add_wall_dir * (-1) * (120 / 2)
            cab_p2 = add_wall_p2 + add_wall_dir * (-1) * (120 / 2)
            if direc_idx == 0:
                baseline = settings.Line2D(cab_p1, cab_p2)
            else:
                baseline = settings.Line2D(cab_p2, cab_p1)
            cab = furniture.HallwayCabinet(baseline, RULE_PARAM["hallway"]["cab_custom_depth_max"])
            cab.set_tag(0)
            lay_dict = {0:4, 1:3}
            cab.set_lay_kind(lay_dict[direc_idx])
            geo_utils.furniture_correction(cab, region)

            increment_wall = {
                "line": [(p.x, p.y) for p in add_wall.points],
                "thickness": 120,
                "cab": cab

            }
            entrance_wall = region.id_walls[entrance.wall_id]

            # 新增墙和入户门所在的墙必须有交点
            if len(entrance_wall.segment2d.intersection(add_wall)):
                ana_dict["increment_walls"] = [increment_wall]
                ana_dict["remould_doc"] = DOC["hallway"]["remould_doc_vertical"].format(**{
                    DOC["hallway"]["cab_pos"]: pos_dict[direc_idx]
                })
                ana_dict["remould_doc"] = ana_dict["remould_doc"] + cab.get_doc(0)["cab_doc"]
                vertical_flag = True
        # 考虑对面放
        area = floorplan.get_total_area_in_m2()
        if area > RULE_PARAM["hallway"]["remould_face_area"]:
            entr_norm = geo_utils.get_normal_dir(entrance.line2d)
            face_ray = settings.Ray2D(start_pt, start_pt + entr_norm * 20)
            min_dis = np.inf
            for wid, w in region.id_walls.items():
                intersects = w.segment2d.intersection(face_ray)
                if len(intersects) > 0:
                    dis = start_pt.distance(intersects[0])
                    if min_dis > dis:
                        min_dis = dis

            if min_dis > RULE_PARAM["hallway"]["remould_face_wall_dis"]:
                # ana_dict["remould_doc"] += "或者" if vertical_flag is True else ""
                ana_dict["remould_doc"] += DOC["hallway"]["remould_doc_face"]

                return ana_dict
        if vertical_flag:
            return ana_dict

    # 判断是否移动墙体
    dis = RULE_PARAM["hallway"]["walking_dis"]
    pt_list1, ptid_list1, wallid_list1 = get_entrance_walking_path(entrance, region, dis, ccw=False)
    pt_list2, ptid_list2, wallid_list2 = get_entrance_walking_path(entrance, region, dis, ccw=True)

    def get_remould_wall(wall_id_list, entrance, region):
        for w_id in wall_id_list:
            wall = region.id_walls[w_id]
            if geo_utils.is_parallel(wall.line2d, entrance.line2d):
                continue
            if wall.segment2d.length > 700:
                return w_id
            # dis = wall.segment2d.midpoint.distance(entrance.segment2d.midpoint)
            # print(wall.segment2d.length)

    longest_wid1 = get_remould_wall(wallid_list1, entrance, region)
    longest_wid2 = get_remould_wall(wallid_list2, entrance, region)

    longest_wall = [region.id_walls.get(longest_wid1), region.id_walls.get(longest_wid2)]

    neighbors = [None, None]
    areas = [0, 0]
    neighbors_wall_id = [None, None]
    room_types = [None, None]

    for idx, wall in enumerate(longest_wall):
        if wall is None:
            continue
        # 改造墙到门的中点不能太大
        entrance_dis = wall.line2d.distance(entrance.segment2d.midpoint) - entrance.segment2d.length / 2
        if entrance_dis > RULE_PARAM["hallway"]["remould_wall_length"]:
            continue
        # 改造墙厚度不能太大
        if wall.thickness > RULE_PARAM["hallway"]["remould_wall_thickness"]:
            continue
        wall_id = wall.id
        if wall.outer:
            continue
        regions = floorplan.get_regions_along_wall_id(wall_id)
        for r in regions:
            if region == r:
                regions.remove(r)
        if len(regions) == 1:
            room_types[idx] = regions[0].room_type
            neighbors[idx] = regions[0].room_type_name
            areas[idx] = regions[0].size / 1000 / 1000
            neighbors_wall_id[idx] = wall_id
    neighbor_idx = np.argmax(areas)

    if areas[neighbor_idx] > RULE_PARAM["hallway"]["remould_nerghbor_area"]:
        ana_dict["remould_doc"] = DOC["hallway"]["remould_doc_neighbor"].format(**{
            DOC["hallway"]["cab_pos"]: pos_dict[neighbor_idx],
            DOC["hallway"]["room_type"]: neighbors[neighbor_idx]
        })
        ana_dict["demolished_wall_id"] = [neighbors_wall_id[neighbor_idx]]
        return ana_dict

    remould_wall_flag = False
    for type_area in RULE_PARAM["hallway"]["remould_nerghbor_room_type_area"]:
        if room_types[neighbor_idx] == type_area[0]:
            if areas[neighbor_idx] < type_area[1]:
                ana_dict["remould_doc"] = DOC["hallway"]["remould_doc_neighbor_small"].format(**{
                    DOC["hallway"]["cab_pos"]: pos_dict[neighbor_idx],
                    DOC["hallway"]["room_type"]: neighbors[neighbor_idx],
                    "neighbor_area":  type_area[1]
                })
                return ana_dict
            else:
                remould_wall_flag = True

    if room_types[neighbor_idx] in RULE_PARAM["hallway"]["remould_nerghbor_storge"]:
        ana_dict["remould_doc"] = DOC["hallway"]["remould_doc_neighbor_storge"].format(**{
            DOC["hallway"]["cab_pos"]: pos_dict[neighbor_idx],
            DOC["hallway"]["room_type"]: neighbors[neighbor_idx],
        })
        return ana_dict

    if remould_wall_flag == True:
        ana_dict["remould_doc"] = DOC["hallway"]["remould_doc_neighbor"].format(**{
            DOC["hallway"]["cab_pos"]: pos_dict[neighbor_idx],
            DOC["hallway"]["room_type"]: neighbors[neighbor_idx]
        })
        ana_dict["demolished_wall_id"] = [neighbors_wall_id[neighbor_idx]]
        return ana_dict

    area = floorplan.get_total_area_in_m2()
    if area > RULE_PARAM["hallway"]["remould_face_area"]:
        entr_norm = geo_utils.get_normal_dir(entrance.line2d)
        face_ray = settings.Ray2D(start_pt, start_pt + entr_norm * 20)
        min_dis = np.inf
        for wid, w in region.id_walls.items():
            intersects = w.segment2d.intersection(face_ray)
            if len(intersects) > 0:
                dis = start_pt.distance(intersects[0])
                if min_dis > dis:
                    min_dis = dis

        if min_dis > RULE_PARAM["hallway"]["remould_face_wall_dis"]:
            ana_dict["remould_doc"] = DOC["hallway"]["remould_doc_face"]
            return ana_dict

    ana_dict["remould_doc"] = DOC["hallway"]["remould_doc_hard"]
    return ana_dict


def res2json(res):
    res_json = dict()
    space_ana = {
        settings.HALLWAY_RES_CONTOURS: [p.args for p in res[settings.HALLWAY_RES_CONTOURS]],
        "width": res["space_analysis"]["width"],
        "depth": res["space_analysis"]["depth"],
        "doc": res["space_analysis"]["space_doc"],
    }
    res_json["space_analysis"] = space_ana

    decoration = []
    for idx, cab_d in enumerate(res[settings.HALLWAY_RES_CABINETS]):
        deco = dict()
        deco["furniture"] = []

        cab_lay = list(cab_d.keys())[0]
        cab = cab_d[cab_lay]
        cab_dict = {
            "countours": cab.get_contours(),
            "baseline": [p.args for p in cab.baseline.points],
            "name": cab.name,
            "type": cab.type
        }
        deco["furniture"].append(cab_dict)

        cab_key = cab.get_json_dict()
        deco["doc"] = res["layout_doc"][cab_key["lay"]]["cab_doc"]
        deco["index"] = idx
        decoration.append(deco)
    res_json["decoration"] = decoration

    remould_dict = {
        "doc": res["remould"]["remould_doc"]
    }
    if res["remould"].get("demolished_wall_id") is not None:
        remould_dict["demolished_wall_id"] = res["remould"]["demolished_wall_id"]
    if res["remould"].get("increment_walls") is not None:
        increment_walls = [{
            "line": res["remould"]["increment_walls"][0]["line"],
            "thickness": res["remould"]["increment_walls"][0]["thickness"]
        }]
        cab = res["remould"]["increment_walls"][0]["cab"]
        remould_dict["furniture"] = [{
            "countours": cab.get_contours(),
            "baseline": [p.args for p in cab.baseline.points],
            "name": cab.name,
            "type": cab.type
        }]
        remould_dict["increment_walls"] = increment_walls
    res_json["remould"] = [remould_dict]

    doc_list = []
    for idx, deco in enumerate(res_json["decoration"]):
        # if idx != 0:
        #     doc += "\n"
        # doc += u"第{cnt}种摆放方式如图{cnt}，".format(**{"cnt": idx + 1})
        # doc += deco["doc"]
        # doc += deco["doc"].encode("utf8")
        doc = u"第{cnt}种摆放方式，".format(**{"cnt": idx + 1})
        doc += deco["doc"]
        doc_list.append(doc)
    cnt = 0
    for idx, remould in enumerate(res_json["remould"]):
        if remould["doc"] == "":
            continue
        idx = len(doc_list) + cnt
        doc = u"第{cnt}种摆放方式，".format(**{"cnt": idx + 1})
        doc += remould["doc"]
        doc_list.append(doc)
        cnt += 1

    res_json["doc"] = doc_list
    res_json[settings.RES_ERROR] = None
    return res_json


def show(house, res_dict, img_path=None):
    if len(res_dict[settings.ROOMTYPE_HALLWAY]) == 0:
        return None

    res = res_dict[settings.ROOMTYPE_HALLWAY][0]

    frame_id = house.frame_id
    furns = [list(f.values())[0] for f in res["cabinets"]]

    text = "#" + res["space_analysis"]["space_doc"]
    for k, v in res["layout_doc"].items():
        if v != "":
            text += "\n#" + v["cab_doc"]
    text += "\n#" + res["remould"]["remould_doc"]
    demolished_walls = None
    if res["remould"].get("demolished_wall_id") is not None:
        demolished_walls = res["remould"].get("demolished_wall_id")
    increment_walls = None
    if res["remould"].get("increment_walls") is not None:
        increment_walls = res["remould"].get("increment_walls")
        furns.append(res["remould"].get("increment_walls")[0]["cab"])

    # zhuc debug:
    # if demolished_walls is None:
    #     return None
    # if increment_walls is None:
    #     return None

    if img_path is None:
        house.show(walking_pts=[res["contours"]],
                   furniture=furns,
                   title=frame_id,
                   text=text,
                   demolished_walls=demolished_walls,
                   increment_walls=increment_walls)
    else:
        house.saveimg(img_path, frame_id,
                      walking_pts=[res["contours"]],
                      furniture=furns,
                      title=frame_id,
                      text=text,
                      demolished_walls=demolished_walls,
                      increment_walls=increment_walls)
