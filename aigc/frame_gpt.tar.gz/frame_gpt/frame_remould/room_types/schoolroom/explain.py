# coding=utf-8


class Schoolroom(object):
    def __init__(self):
        self.furniture_list = []
