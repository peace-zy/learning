# coding=utf-8

from frame_remould.room_types.furniture import Furniture
import frame_remould.settings as settings
from frame_remould.utils import geo_utils


class BookCase(Furniture):
    name = settings.LABEL_KEY["furniture"]["schoolroom"]["bookcase"]["name"]
    type = settings.LABEL_KEY["furniture"]["schoolroom"]["bookcase"]["type_id"]
    bed_wall_idx = 0

    def __init__(self, baseline, depth):
        super(BookCase, self).__init__(baseline, depth)


class Desk(Furniture):
    name = settings.LABEL_KEY["furniture"]["schoolroom"]["desk"]["name"]
    type = settings.LABEL_KEY["furniture"]["schoolroom"]["desk"]["type_id"]
    bed_wall_idx = 0

    def __init__(self, baseline, depth):
        super(Desk, self).__init__(baseline, depth)


class Chair(Furniture):
    name = settings.LABEL_KEY["furniture"]["schoolroom"]["chair"]["name"]
    type = settings.LABEL_KEY["furniture"]["schoolroom"]["chair"]["type_id"]
    bed_wall_idx = 1

    def __init__(self, baseline, depth):
        super(Chair, self).__init__(baseline, depth)

class Recliner(Furniture):
    name = settings.LABEL_KEY["furniture"]["schoolroom"]["recliner"]["name"]
    type = settings.LABEL_KEY["furniture"]["schoolroom"]["recliner"]["type_id"]
    bed_wall_idx = 1

    def __init__(self, baseline, depth):
        super(Recliner, self).__init__(baseline, depth)

