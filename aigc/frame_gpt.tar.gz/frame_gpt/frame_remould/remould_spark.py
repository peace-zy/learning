# coding=utf-8
import os
import sys
os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, os.getcwd())
import logging
import sys
import yaml
import datetime

from frame_remould.utils import spark_util

def logic_func(driver, raw_df, **params):
    print("hello world")


def main():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    if len(sys.argv) < 3:
        logging.error("no less than 2 arguments!")
        sys.exit()
    pt_date = sys.argv[1]
    config_file = sys.argv[2]

    with open(config_file, "r", encoding="utf-8") as f:
        conf = yaml.load(f, Loader=yaml.FullLoader)

    # 从配置文件读取参数
    spark_config_key = "remould_eval_config"
    spark_params = conf.get(spark_config_key, None)
    if spark_params is None:
        logging.error("lack {} in config file".format(spark_config_key))
        sys.exit(1)

    # ## 补充参数
    # pt
    spark_params["sql_params"]["pt_date"] = pt_date
    current_date = datetime.datetime.strptime(pt_date, "%Y%m%d")
    bc_pt_date = (current_date - datetime.timedelta(days=1)).strftime("%Y%m%d")
    spark_params["sql_params"]["bc_pt_date"] = bc_pt_date

    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_function"] = logic_func
    # 存储pt
    spark_params["save_params"]["partition_params"] = {"pt": "{}000000".format(pt_date)}

    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()


if __name__ == "__main__":
    # pt_date = "20201028"
    # setting_path = os.path.realpath(__file__)
    # setting_path = os.path.dirname(setting_path)
    # config_file = os.path.join(setting_path, "config/remould_spark_conf.yml")
    # with open(config_file, "r", encoding="utf-8") as f:
    #     conf = yaml.load(f, Loader=yaml.FullLoader)
    #
    # # 从配置文件读取参数
    # spark_config_key = "remould_eval_config"
    # spark_params = conf.get(spark_config_key, None)
    #
    # spark_params["sql_params"]["pt_date"] = pt_date
    # current_date = datetime.datetime.strptime(pt_date, "%Y%m%d")
    # bc_pt_date = (current_date - datetime.timedelta(days=1)).strftime("%Y%m%d")
    # spark_params["sql_params"]["bc_pt_date"] = bc_pt_date
    # # 自定义逻辑处理方法
    # spark_params["logic_params"]["logic_function"] = logic_func
    # # 存储pt
    # spark_params["save_params"]["partition_params"] = {"pt": "{}000000".format(pt_date)}

    logging.basicConfig(level=logging.WARN, format='%(asctime)s %(levelname)s %(message)s')

    main()