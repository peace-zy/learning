# class Line():
#     def distance(self):
#         print('value of A')
#
#
# class LinearEntity(Line):
#     pass
#
#
# class Segment(Line):
#     def distance(self):
#         print('value of C')
#
#
# class Segment2D(Segment, LinearEntity):
#     pass
#
#
# test = Segment2D()
# test.distance()
#
# int(0.5)

# for i in range(-3,0):
#     print(i)

# d = {}
# d['a'] = 1
# print(d)

# print(True == True)
# print(True ^ False)

l = [1, 3, 4, 2, 3, 1]
s = set(l)
print(s)

