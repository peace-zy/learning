# The functions in point.py need to complete in the future
- Are points coplanar?
    - function in point.py : is_coplanar()

- Are points on the same circumference
    - function in point.py : is_concyclic()


# Useless function in sympy point.py
- intersection()  : get the intersect point of two points



