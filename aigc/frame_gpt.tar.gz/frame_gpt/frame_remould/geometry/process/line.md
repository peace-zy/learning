# The functions in line.py need to complete in the future

- Are lines concurrent?
    - function in line.py :  are_concurrent()

- Project a line/segment/ray onto self line
    - function in line.py : projection()

- intersection of two 3D line
    - function in line.py : intersection()


