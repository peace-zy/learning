# coding=utf-8
import math
import logging
from functools import reduce

from .settings import pi, Epsilon
from .point import Point
from .line import Line, Ray, Segment
from .basic import GeometryEntity


class Polygon(GeometryEntity):

    def __new__(cls, *args, **kwargs):
        vertices = [Point._convert(a) for a in args]

        # remove same points
        nsp = []
        for p in vertices:
            if nsp and p == nsp[-1]:
                continue
            nsp.append(p)

        if len(nsp) > 1 and nsp[0] == nsp[-1]:
            nsp.pop()

        # remove collinear points
        i = -3
        while i < len(nsp) - 3 and len(nsp) > 2:
            a, b, c = nsp[i], nsp[i + 1], nsp[i + 2]
            if a.is_collinear(b, c):
                nsp[i] = a
                nsp[i + 1] = None
                nsp.pop(i + 1)
            i += 1

        vertices = list(nsp)

        if len(vertices) > 3:
            return GeometryEntity.__new__(cls, *vertices, **kwargs)
        elif len(vertices) == 3:
            return Triangle(*vertices, **kwargs)
        elif len(vertices) == 2:
            return Segment(*vertices, **kwargs)
        else:
            return Point(*vertices, **kwargs)

    def __hash__(self):
        return super(Polygon, self).__hash__()

    def __eq__(self, other):
        if not isinstance(other, Polygon) or len(self.args) != len(other.args):
            return False

        args = self.args
        oargs = other.args
        n = len(args)
        o0 = oargs[0]
        for i0 in range(n):
            if args[i0] == o0:
                if all(args[(i0 + i) % n] == oargs[i] for i in range(1, n)):
                    return True
                if all(args[(i0 - i) % n] == oargs[i] for i in range(1, n)):
                    return True
        return False

    def __contains__(self, o):
        """
        Return True if o is contained within the boundary lines of self.altitudes

        Para:
        other : GeometryEntity
        """

        if isinstance(o, Polygon):
            return self == o
        elif isinstance(o, Segment):
            return any(o in s for s in self.sides)
        elif isinstance(o, Point):
            if o in self.vertices:
                return True
            for side in self.sides:
                if o in side:
                    return True

        return False

    @staticmethod
    def _isright(a, b, c):
        """Return True/False for cw/ccw orientation."""
        ab = b - a
        ac = c - a
        t_cross = ab.cross(ac)
        return t_cross < 0

    @property
    def vertices(self):
        return list(self.args)

    @property
    def bounds(self):
        verts = self.args
        xs = [p.x for p in verts]
        ys = [p.y for p in verts]
        return (min(xs), min(ys), max(xs), max(ys))

    @property
    def ambient_dimension(self):
        """Return dimention of polygon"""
        return len(self.vertices[0])

    @property
    def angles(self):
        """The internal angle at each vertex.
            For concave polygon, angle may > pi !"""

        angle = {}
        args = self.args
        # 这里不严谨，如果初始 cw_sign 就取到了多边形的 > 180° 的顶点
        # 那接下来可能会导致其他本身 < 180°的内角变为 >180°
        # 这也是我认为 sympy 不严谨的一个函数，以后可修改
        cw_sign = self._isright(args[-1], args[0], args[1])

        for i in range(len(args)):
            a, b, c = args[i - 2], args[i - 1], args[i]
            agn = Line(b, a).angle_between(Line(b, c))

            # if Point doesn't have __hash__(), it will appear an error
            if cw_sign ^ self._isright(a, b, c):
                angle[b] = (360-agn/pi * 180)
            else:
                angle[b] = agn / pi * 180
        return angle

    @property
    def perimeter(self):
        """The perimeter of polygon"""
        p = 0
        args = self.args
        for i in range(len(args)):
            p += args[i - 1].distance(args[i])
        return p

    @property
    def area(self):
        """The area of polygon"""
        a = 0
        args = self.args
        for i in range(len(args)):
            x1, y1 = args[i-1].args
            x2, y2 = args[i].args
            a += x1*y2 - x2*y1
        return a/2

    @property
    def sides(self):
        """The directed line segments that form the sides of the polygon."""
        s = []
        args = self.args
        for i in range(-len(args), 0):
            s.append(Segment(args[i], args[i + 1]))
        return s

    def is_convex(self):
        """Return whether the polygon is convex"""
        args = self.vertices
        cw_sign = self._isright(args[-2], args[-1], args[0])
        for i in range(1, len(args)):
            if cw_sign ^ self._isright(args[i - 2], args[i - 1], args[i]):
                return False
        # sides intersecting check
        sides = self.sides
        for i, si in enumerate(sides):
            pts = si.args
            # exclude the sides connected to si
            for j in range(1 if i == len(sides) - 1 else 0, i - 1):
                sj = sides[j]
                if sj.p1 not in pts and sj.p2 not in pts:
                    hit = si.intersection(sj)
                    if hit:
                        return False

        return True

    def encloses_point(self, p):
        """Return True if p is enclosed by (is inside of) self."""
        # p = Point._convert(p)
        # if any(p in s for s in self.sides):
        #     return False
        # # Still need to complement !!!

        p = Point(p, dim=2)
        if p in self.vertices or any(p in s for s in self.sides):
            return False

        # move to p, checking that the result is numeric
        lit = []
        for v in self.vertices:
            lit.append(v - p)  # the difference is simplified
            # if lit[-1].free_symbols:
            #     return None

        poly = Polygon(*lit)

        # polygon closure is assumed in the following test but Polygon removes duplicate pts so
        # the last point has to be added so all sides are computed. Using Polygon.sides is
        # not good since Segments are unordered.
        args = poly.args
        indices = list(range(-len(args), 1))

        if poly.is_convex():
            orientation = None
            for i in indices:
                a = args[i]
                b = args[i + 1]
                test = ((-a.y)*(b.x - a.x) - (-a.x)*(b.y - a.y)) < 0
                if orientation is None:
                    orientation = test
                elif test is not orientation:
                    return False
            return True

        hit_odd = False
        p1x, p1y = args[0].args
        for i in indices[1:]:
            p2x, p2y = args[i].args
            if 0 > min(p1y, p2y):
                if 0 <= max(p1y, p2y):
                    if 0 <= max(p1x, p2x):
                        if p1y != p2y:
                            xinters = (-p1y)*(p2x - p1x)/(p2y - p1y) + p1x
                            if p1x == p2x or 0 <= xinters:
                                hit_odd = not hit_odd
            p1x, p1y = p2x, p2y
        return hit_odd

        # return True

    def distance(self, o):
        """
        Returns the shortest distance between self and o.
        """
        if isinstance(o, Point):
            dist = 999999999
            for side in self.sides:
                current = side.distance(o)
                if current == 0:
                    return 0
                elif current < dist:
                    dist = current
            return dist
        elif isinstance(o, Polygon) and self.is_convex() and o.is_convex():
            return self._do_poly_distance(o)
        raise NotImplementedError()

    def _do_poly_distance(self, e2):
        """
        Calculates the least distance between the exteriors of two
        convex polygons e1 and e2. Does not check for the convexity
        of the polygons as this is checked by Polygon.distance.

        Notes
        =====

            - Prints a warning if the two polygons possibly intersect as the return
              value will not be valid in such a case. For a more through test of
              intersection use intersection().

        See Also
        ========

        sympy.geometry.point.Point.distance

        Examples
        ========

        # >>> from sympy.geometry import Point, Polygon
        # >>> square = Polygon(Point(0, 0), Point(0, 1), Point(1, 1), Point(1, 0))
        # >>> triangle = Polygon(Point(1, 2), Point(2, 2), Point(2, 1))
        # >>> square._do_poly_distance(triangle)
        sqrt(2)/2

        Description of method used
        ==========================

        Method:
        [1] http://cgm.cs.mcgill.ca/~orm/mind2p.html
        Uses rotating calipers:
        [2] https://en.wikipedia.org/wiki/Rotating_calipers
        and antipodal points:
        [3] https://en.wikipedia.org/wiki/Antipodal_point
        """
        e1 = self

        '''Tests for a possible intersection between the polygons and outputs a warning'''
        e1_center = e1.centroid
        e2_center = e2.centroid
        e1_max_radius = 0
        e2_max_radius = 0
        for vertex in e1.vertices:
            r = Point.distance(e1_center, vertex)
            if e1_max_radius < r:
                e1_max_radius = r
        for vertex in e2.vertices:
            r = Point.distance(e2_center, vertex)
            if e2_max_radius < r:
                e2_max_radius = r
        center_dist = Point.distance(e1_center, e2_center)
        if center_dist <= e1_max_radius + e2_max_radius:
            logging.warning("Polygons may intersect producing erroneous output")
            # Warnings.warn("Polygons may intersect producing erroneous output")

        '''
        Find the upper rightmost vertex of e1 and the lowest leftmost vertex of e2
        '''
        e1_ymax = Point(0, -999999999)
        e2_ymin = Point(0, 999999999)

        for vertex in e1.vertices:
            if vertex.y > e1_ymax.y or (vertex.y == e1_ymax.y and vertex.x > e1_ymax.x):
                e1_ymax = vertex
        for vertex in e2.vertices:
            if vertex.y < e2_ymin.y or (vertex.y == e2_ymin.y and vertex.x < e2_ymin.x):
                e2_ymin = vertex
        min_dist = Point.distance(e1_ymax, e2_ymin)

        '''
        Produce a dictionary with vertices of e1 as the keys and, for each vertex, the points
        to which the vertex is connected as its value. The same is then done for e2.
        '''
        e1_connections = {}
        e2_connections = {}

        for side in e1.sides:
            if side.p1 in e1_connections:
                e1_connections[side.p1].append(side.p2)
            else:
                e1_connections[side.p1] = [side.p2]

            if side.p2 in e1_connections:
                e1_connections[side.p2].append(side.p1)
            else:
                e1_connections[side.p2] = [side.p1]

        for side in e2.sides:
            if side.p1 in e2_connections:
                e2_connections[side.p1].append(side.p2)
            else:
                e2_connections[side.p1] = [side.p2]

            if side.p2 in e2_connections:
                e2_connections[side.p2].append(side.p1)
            else:
                e2_connections[side.p2] = [side.p1]

        e1_current = e1_ymax
        e2_current = e2_ymin
        support_line = Line(Point(0, 0), Point(1, 1))

        '''
        Determine which point in e1 and e2 will be selected after e2_ymin and e1_ymax,
        this information combined with the above produced dictionaries determines the
        path that will be taken around the polygons
        '''
        point1 = e1_connections[e1_ymax][0]
        point2 = e1_connections[e1_ymax][1]
        angle1 = support_line.angle_between(Line(e1_ymax, point1))
        angle2 = support_line.angle_between(Line(e1_ymax, point2))
        if angle1 < angle2:
            e1_next = point1
        elif angle2 < angle1:
            e1_next = point2
        elif Point.distance(e1_ymax, point1) > Point.distance(e1_ymax, point2):
            e1_next = point2
        else:
            e1_next = point1

        point1 = e2_connections[e2_ymin][0]
        point2 = e2_connections[e2_ymin][1]
        angle1 = support_line.angle_between(Line(e2_ymin, point1))
        angle2 = support_line.angle_between(Line(e2_ymin, point2))
        if angle1 > angle2:
            e2_next = point1
        elif angle2 > angle1:
            e2_next = point2
        elif Point.distance(e2_ymin, point1) > Point.distance(e2_ymin, point2):
            e2_next = point2
        else:
            e2_next = point1

        '''
        Loop which determines the distance between anti-podal pairs and updates the
        minimum distance accordingly. It repeats until it reaches the starting position.
        '''
        while True:
            e1_angle = support_line.angle_between(Line(e1_current, e1_next))
            e2_angle = pi - support_line.angle_between(Line(
                e2_current, e2_next))

            if (e1_angle < e2_angle) is True:
                support_line = Line(e1_current, e1_next)
                e1_segment = Segment(e1_current, e1_next)
                min_dist_current = e1_segment.distance(e2_current)

                if min_dist_current.evalf() < min_dist.evalf():
                    min_dist = min_dist_current

                if e1_connections[e1_next][0] != e1_current:
                    e1_current = e1_next
                    e1_next = e1_connections[e1_next][0]
                else:
                    e1_current = e1_next
                    e1_next = e1_connections[e1_next][1]
            elif (e1_angle > e2_angle) is True:
                support_line = Line(e2_next, e2_current)
                e2_segment = Segment(e2_current, e2_next)
                min_dist_current = e2_segment.distance(e1_current)

                if min_dist_current.evalf() < min_dist.evalf():
                    min_dist = min_dist_current

                if e2_connections[e2_next][0] != e2_current:
                    e2_current = e2_next
                    e2_next = e2_connections[e2_next][0]
                else:
                    e2_current = e2_next
                    e2_next = e2_connections[e2_next][1]
            else:
                support_line = Line(e1_current, e1_next)
                e1_segment = Segment(e1_current, e1_next)
                e2_segment = Segment(e2_current, e2_next)
                min1 = e1_segment.distance(e2_next)
                min2 = e2_segment.distance(e1_next)

                min_dist_current = min(min1, min2)
                if min_dist_current.evalf() < min_dist.evalf():
                    min_dist = min_dist_current

                if e1_connections[e1_next][0] != e1_current:
                    e1_current = e1_next
                    e1_next = e1_connections[e1_next][0]
                else:
                    e1_current = e1_next
                    e1_next = e1_connections[e1_next][1]

                if e2_connections[e2_next][0] != e2_current:
                    e2_current = e2_next
                    e2_next = e2_connections[e2_next][0]
                else:
                    e2_current = e2_next
                    e2_next = e2_connections[e2_next][1]
            if e1_current == e1_ymax and e2_current == e2_ymin:
                break
        return min_dist

    def intersection(self, other):
        """the intersection of polygon and other geometry entity"""
        intersection_result = []
        k = other.sides if isinstance(other, Polygon) else [other]
        for side in self.sides:
            for side1 in k:
                intersection_result.extend(side.intersection(side1))

        intersection_result = list(set(intersection_result))
        points = [entity for entity in intersection_result if isinstance(entity, Point)]
        segments = [entity for entity in intersection_result if isinstance(entity, Segment)]

        if points and segments:
            points_in_segments = list(set([point for point in points for segment in segments if point in segment]))
            if points_in_segments:
                for i in points_in_segments:
                    points.remove(i)
            return list(segments + points)
        else:
            return list(intersection_result)

    @property
    def centroid(self):
        """Return the centroid of th polygon"""
        v = self.vertices
        d = reduce(lambda x, y: x+y, ((a.x * a.y) for a in v))
        dx = reduce(lambda x, y: x+y, ((a.x) for a in v))
        dy = reduce(lambda x, y: x+y, ((a.y) for a in v))
        return Point(d/(dy+Epsilon), d/(dx+Epsilon))

    def second_moment_of_area(self, point=None):
        """Returns the second moment and product moment of area of a two dimensional polygon."""
        raise NotImplementedError()


class RegularPolygon(Polygon):


    @property
    def area(self):
        raise NotImplementedError()

    @property
    def length(self):
        raise NotImplementedError()

    @property
    def center(self):
        raise NotImplementedError()

    @property
    def radius(self):
        """Radius of the RegularPolygon"""
        raise NotImplementedError()

    @property
    def circumcircle(self):
        """The circumcircle of the RegularPolygon."""
        raise NotImplementedError()

    @property
    def incircle(self):
        """The incircle of the RegularPolygon."""
        raise NotImplementedError()

    @property
    def vertices(self):
        raise NotImplementedError()


class Triangle(Polygon):
    def __new__(cls, *args, **kwargs):
        vertices = [Point._convert(a) for a in args]

        # remove same points
        nsp = []
        for p in vertices:
            if nsp and p == nsp[-1]:
                continue
            nsp.append(p)

        if len(nsp) > 1 and nsp[0] == nsp[-1]:
            nsp.pop()

        # remove collinear points
        i = -3
        while i < len(nsp) - 3 and len(nsp) > 2:
            a, b, c = nsp[i], nsp[i + 1], nsp[i + 2]
            if a.is_collinear(b, c):
                nsp[i] = a
                nsp[i + 1] = None
                nsp.pop(i + 1)
            i += 1

        vertices = list(filter(lambda x: x is not None, nsp))

        if len(vertices) == 3:
            return GeometryEntity.__new__(cls, *vertices, **kwargs)
        elif len(vertices) == 2:
            return Segment(*vertices, **kwargs)
        else:
            return Point(*vertices, **kwargs)