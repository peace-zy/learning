# coding=utf-8
"""
A geometry model which contains simple geometric operation.
This model contains point operation, line operation, polygon operation
"""

import sys
import os.path as pa

sys.path.append(pa.dirname(pa.dirname(pa.abspath(__file__))))

from geometry.point import Point, Point2D, Point3D
from geometry.line import Line, Segment, Line2D, Segment2D, Ray
from geometry.polygon import Polygon, RegularPolygon
from geometry.settings import pi
