# coding=utf-8
import os
import sys

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, os.getcwd())

import json
import yaml

import frame_remould.settings as settings
settings.PLOT = True

import frame_remould.utils.common as common
from frame_remould.floorplan import House
from frame_remould.room_types import hallway
from frame_remould.room_types import master_bedroom
from frame_remould.room_types import livingroom

from frame_remould import decoration_spark
from lib import entity
from lib import label_functions
from lib import eval_main

from ke_auto import utils as ke_utils

def main(frame_json):
    hs = House()
    hs.set_json_file(frame_json)

    # res_dict, js_dict = hs.run()
    res_dict, js_dict = hs.run_debug()

    # hallway.show(hs, res_dict)
    # master_bedroom.explain.show(hs, res_dict)
    # livingroom.explain.show(hs, res_dict)

    area_id = res_dict["main_room"][0]['area_id']
    new_frame = master_bedroom.explain.frameXitems_print(hs, area_id)
    ke_utils.draw_json(new_frame, show=True, save_path="./i.png")

    # ke_utils.get_img(new_house, show=True, save_path="./i.png")

    # hallway.show(hs, res_dict, img_path=r"D:\\")
    # common.save_json_file(js_dict, r"D:\\a.json")

    # hs.show()

def main_deco(frame_json):
    # 装修解读
    frame_id = os.path.basename(frame_json).split(".")[0]
    with open(frame_json, 'r') as f:
        frame_json = json.load(f)
    vector_str = json.dumps(frame_json)
    line = "\t".join([frame_id, 'image_id', vector_str, 'city_code'])

    file_path = os.path.realpath(__file__)
    file_path = os.path.dirname(file_path)
    config_path = os.path.join(file_path, "../../config/decoration_conf.yml")
    with open(config_path, "r") as f:
        # eval_base_conf = yaml.load(conf_data)
        # total_conf.update(eval_base_conf)
        conf = yaml.load(f, Loader=yaml.FullLoader)

    _, deco_frame = decoration_spark.frame_decoration_feature(line, debug=True, **conf)

    frame = entity.Frame(line)
    frame_vector = frame.vector

    # 标签
    frame.add_label(label_functions.label_base, **conf["label_params"])
    # 检测点
    eval_main.decoration_explain(frame, **conf)
    decoration_dict = frame.explain_message.get("decoration_dict", {})
    decoration_sug_dict = frame.explain_message.get("decoration_sug_dict", {})

    house = House()
    house.set_json_str(json.dumps(frame_vector))
    res_dict, js_dict = house.run()

    decoration_sug_dict.update(js_dict)

    hallway.show(house, res_dict)

def multi_run(frame_str, SAVE_PATH):
    hs = House()
    hs.set_json_str(frame_str)
    res_dict, js_dict = hs.run_debug()
    new_house = House()

    area_id = res_dict["main_room"][0]['area_id']
    width = res_dict["main_room"][0]['space_analysis']['width']/1000
    depth = res_dict["main_room"][0]['space_analysis']['depth'] / 1000
    if width * depth < 15:
        new_frame = master_bedroom.explain.frameXitems_print(hs, area_id)

        save_path = os.path.join(SAVE_PATH, str(width)+'-'+str(depth)+'-'+str(frame_id) + ".png")
        ke_utils.draw_json(new_frame, show=False, save_path=save_path)

if __name__ == "__main__":
    import glob
    import pandas as pd
    import boto3

    S3_AK = "223HG43LGIX9W3MWTOCL"
    S3_AKS = "tqWXh8kSyxM/QfgF34dMXFJcRrIIGfIIZkVVjSMH"
    s3_client = boto3.client('s3', region_name="cn-north-1", endpoint_url="http://storage.lianjia.com",
                             aws_access_key_id=S3_AK,
                             aws_secret_access_key=S3_AKS)
    # frame_json = r"D:\bed1.json"
    # 11000001711089
    # 11000000428853 多层
    # 11000001711089 有斜墙

    # 门厅问题
    # 11000008234983 改造墙, 旁边有储物间，检查
    # 11000016369474 主卧bug

    # 11000002525257 两个连续的内墙有问题
    # 11000002797131 内墙问题
    # 53000002330573 主卧短墙校正有问题
    # frame_json = r"D:\ke\data\more_frame_json\11000002209183.json"
    # main(frame_json)
    # '88570000257502' 客厅问题
    frame_json = r"D:\ke\data\more_frame_json\24000005075035.json"
    main(frame_json)
    # files = glob.glob("/Users/lxin/Desktop/摆放测试/*.json")
    # for frame_json in files:
    #     main(frame_json)
    # main_deco(frame_json)
    FRAMEID_FILE = "/Users/lxin/Downloads/一卫frame.tsv"
    SAVE_PATH = '/Users/lxin/Desktop/15平以下卧室摆放/'
    df = pd.read_csv(FRAMEID_FILE, sep="\t", encoding='cp1252')
    frame_id_list = list(df['frame_id'])
    import random
    random.shuffle(frame_id_list)
    for idx, frame_id in enumerate(frame_id_list[:100]):
        try:
            vector_response = s3_client.get_object(Bucket='frame-eval-image', Key=str(frame_id) + '.json')
            vector_str = vector_response['Body'].read()
            multi_run(vector_str, SAVE_PATH)
        except Exception as ex:
            print ex
            continue

