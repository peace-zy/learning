# coding=utf-8
import os
import json
import pandas as pd
import numpy as np
import shutil

import frame_remould.utils.vis as vis
import frame_remould.settings as settings
import frame_remould.utils.geo_utils as geo_utils

def split_dwg_file():
    cad_path = r'D:\tmp\cad'
    interval = 300

    files = os.listdir(os.path.join(cad_path, 'all'))

    dirs = int(np.floor(len(files) / interval))
    for i in range(dirs + 1):
        dir_name = str((i + 1) * interval)
        if os.path.exists(os.path.join(cad_path, dir_name)):
            shutil.rmtree(os.path.join(cad_path, dir_name))
        os.mkdir(os.path.join(cad_path, dir_name))
        for j in range(interval):
            file_idx = i * interval + j
            source = os.path.join(os.path.join(cad_path, 'all'), files[file_idx])
            target = os.path.join(os.path.join(cad_path, dir_name), files[file_idx])
            shutil.copy(source, target)


def extract_svg():
    cad_path = r'D:\tmp\cad'
    svg_dir_path = os.path.join(cad_path, 'svg_dir')
    dirs = os.listdir(svg_dir_path)

    if os.path.exists(os.path.join(cad_path, 'svg')):
        shutil.rmtree(os.path.join(cad_path, 'svg'))
    if os.path.exists(os.path.join(cad_path, 'png')):
        shutil.rmtree(os.path.join(cad_path, 'png'))
    os.mkdir(os.path.join(cad_path, 'svg'))
    os.mkdir(os.path.join(cad_path, 'png'))
    svg_path = os.path.join(cad_path, 'svg')
    png_path = os.path.join(cad_path, 'png')
    for d in dirs:
        source = os.path.join(svg_dir_path, d)
        source = os.path.join(source, '1.svg')
        with open(source, 'r') as f:
            content = f.read()
            svg_content = content.replace('"6"', '"800"')

        svg_name = d + '.svg'
        target = os.path.join(svg_path, svg_name)
        with open(target, 'w') as f:
            f.write(svg_content)


if __name__ == "__main__":
    # split_dwg_file()
    # extract_svg()

    import pandas as pd
    import matplotlib.pylab as plt

    df = pd.read_csv(r'D:\error.csv')
    e = list(df['error'])
    plt.hist(e, bins=30)
    plt.show()

    tmp = 0