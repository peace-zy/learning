from multiprocessing import Pool
import multiprocessing

import os
import time
import matplotlib
import gc
import pandas as pd
import json
import numpy as np

import frame_remould.settings as settings
settings.PLOT = True

import frame_remould.utils.common as common
from frame_remould.floorplan import House
from frame_remould.room_types import hallway
from frame_remould.room_types import master_bedroom
from frame_remould.room_types import livingroom

# matplotlib.use("agg")

THREADS = 8

SAVE_PATH = r"D:\ke\data\img"
# INPUT_PATH = r"D:\ke\data\layout_data"
INPUT_PATH = r"D:\ke\data\more_frame_json"
FAILED_JSON = {}
FAILED_ERROR = {}
FAILED_INITIAL = []


def decoration(json_file):
    house = House()
    j_file = os.path.join(INPUT_PATH, json_file)
    f_id = json_file.split(".")[0]

    try:
        house.set_json_file(j_file)
        res_dict, json_dict = house.run()

        # hallway.show(house, res_dict, img_path=SAVE_PATH)
        # master_bedroom.explain.show(house, res_dict, img_path=SAVE_PATH)
        livingroom.explain.show(house, res_dict, img_path=SAVE_PATH)
        # common.save_json_file(json_dict, os.path.join(SAVE_PATH, json_file))
    except Exception as error:
        print(f_id)
        return f_id, {}

    return f_id, json_dict
    # json_str = json.dumps(json_dict)
    # df.loc[df["frame_id"] == f_id, "decorate_info"] = json_str


def decoration_debug(json_file):
    failed_json = []
    f_id = json_file.split(".")[0]
    j_file = os.path.join(INPUT_PATH, json_file)
    suc_num = 0

    try:
        house = House()
        house.set_json_file(j_file)

        res_dict, _ = house.run_debug()
        # hallway.show(house, res_dict, img_path=SAVE_PATH)
        master_bedroom.explain.show(house, res_dict, img_path=SAVE_PATH)
        suc_num += 1
    except Exception as e:
        failed_json.append(j_file)
    finally:
        pass

    gc.collect()
    return failed_json, suc_num


def initial_df(json_files):
    # df = pd.DataFrame(columns=("frame_id", "decorate_info"))
    # for json_file in json_files:
    #     f_id = json_file.split(".")[0]
    #     df.append({"frame_id": f_id}, ignore_index=True)

    fid_list, deco_list = [], []
    for json_file in json_files:
        f_id = json_file.split(".")[0]
        fid_list.append(f_id)
        deco_list.append(None)
    df = pd.DataFrame({
        "frame_id": fid_list,
        "decorate_info": deco_list
    })

    return df


def ana_json_dict(f_id, json_dict):
    f_file = os.path.join(INPUT_PATH, f_id + ".json")
    for k, v in json_dict.items():
        if FAILED_JSON.get(k) is None:
            FAILED_JSON[k] = []
            FAILED_ERROR[k] = []
        for room_type_dict in v:
            if room_type_dict["error_code"] == None:
                continue
            FAILED_JSON[k].append(f_file)
            FAILED_ERROR[k].append(room_type_dict["error_code"])


def main():
    t0 = time.time()

    p = Pool(THREADS)

    jfile = os.listdir(INPUT_PATH)
    jfile = list(np.random.choice(jfile, 100, replace=False))
    # jfile = [os.path.join(json_dir, f) for f in jfile]
    # jfile = jfile[0:100]

    # res = p.starmap(decoration, zip(jfile))
    # p.close()
    # p.join()

    jfile = ['D:\\ke\\data\\more_frame_json\\35000003774143.json', 'D:\\ke\\data\\more_frame_json\\24000005075035.json', 'D:\\ke\\data\\more_frame_json\\4520031782639084.json', 'D:\\ke\\data\\more_frame_json\\37000006512401.json', 'D:\\ke\\data\\more_frame_json\\1120040439185348.json']

    # df = initial_df(jfile)

    res_list = []
    for i, f in enumerate(jfile):
        result = p.apply_async(decoration, args=(f, ))
        # result = p.apply_async(decoration, args=(f,))
        res_list.append(result)
    p.close()
    p.join()

    for idx, res in enumerate(res_list):
        # print(idx)
        f_id = res.get()[0]
        json_dict = res.get()[1]
        ana_json_dict(f_id, json_dict)
        if json_dict == {}:
            for k, v in FAILED_JSON.items():
                v.append(f_id)

    for k, v in FAILED_JSON.items():
        print(k, FAILED_JSON[k])
        print("failed number: ", len(FAILED_JSON[k]))
        print("cover ratio: ", 1 - len(FAILED_JSON[k]) / float(len(jfile)))
        print("===================================================")
    print(FAILED_INITIAL)
    print("time: ", time.time() - t0)


if __name__ == "__main__":
    main()
