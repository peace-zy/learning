spark-submit --conf spark.yarn.dist.archives="hdfs://ns-fed/user/strategy/zhuc/python2713.zip#python" \
             --conf spark.pyspark.python="python/bin/python2.7" \
             --conf spark.pyspark.driver.python="/home/work/zhuc/python/python2713/bin/python2.7" \
              --py-files lib.zip \
             frame_remould/decoration_spark.py 20210117 config/decoration_conf.yml
