import os
import shutil
from multiprocessing import Pool

from frame_remould.floorplan import Floorplan

THREADS = 8
NUM_REGIONS_MAX = 6
NUM_REGIONS_MIN = 6
INPUT_PATH = r"D:\ke\data\frame_json"
SAVE_PATH = r"D:\ke\data\select_frame"


def select_frame(json_file):
    f_id = json_file.split(".")[0]
    j_file = os.path.join(INPUT_PATH, json_file)

    fp = Floorplan()
    fp.set_json_file(j_file)
    id_regions = fp.id_regions

    if len(id_regions) > NUM_REGIONS_MAX or len(id_regions) < NUM_REGIONS_MIN:
        return None
    print(len(id_regions))
    j_file_dst = os.path.join(SAVE_PATH, json_file)
    shutil.copy(j_file, j_file_dst)
    fp.save_standard_img(SAVE_PATH, f_id)


def main():
    p = Pool(THREADS)
    jfiles = os.listdir(INPUT_PATH)
    p.starmap(select_frame, zip(jfiles))
    p.close()
    p.join()


if __name__ == "__main__":
    main()
