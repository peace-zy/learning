# coding=utf-8
# Copyright (c) 2018 www.ke.com, Inc. All Rights Reserved
"""
户型改造户型图类
Authors: zhucheng011@ke.com
Date:    2020/11/20
"""
import os
import sys

# os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
# sys.path.insert(0, os.getcwd())

import json
import logging
import collections
import copy
import numpy as np
import traceback
# from shapely.geometry import Point, LineString

import frame_remould.settings as settings
from frame_remould.utils.basic import Junction
from frame_remould.utils.basic import Wall, WallItem
from frame_remould.utils.basic import Region

import frame_remould.utils.detection_point as detection_point
from frame_remould.room_types import hallway
from frame_remould.room_types import kitchen
import frame_remould.room_types.master_bedroom as master_bedroom
import frame_remould.room_types.guest_room as guest_room
import frame_remould.room_types.livingroom as livingroom


if settings.PLOT is True:
    import frame_remould.utils.vis as vis


def straighten_lines(lines, max_gap=300, max_slope=30, len_scale_factor=0.02):
    """
    矫正线段, 并且保持连接关系
    :param lines:
    :param max_gap: pixel
    :param max_slope: (度)角度
    :param len_scale_factor: max_slope/[1 + (line_len/max_gap)*len_scale_factor],
                             线段长度每增加一倍max_gap, 合并最大角度阈值增加0.1*max_slope
    :return:
    """
    from collections import defaultdict, Counter
    from sklearn.cluster import DBSCAN
    import math

    def square_distance(point_1, point_2):
        """
        计算两点平方距离
        :param point_1:
        :param point_2:
        :return:
        """
        return (point_1[0] - point_2[0]) ** 2 + (point_1[1] - point_2[1]) ** 2

    # 投影到x, y轴
    if len(lines) < 1:
        return lines

    jids, junc = {}, []
    lnid, lpos = [], []

    def jid(jun):
        jun = tuple(jun[:2])
        if jun in jids:
            return jids[jun]
        jids[jun] = len(junc)
        junc.append(np.array(jun))
        return len(junc) - 1

    pt_to_line = defaultdict(set)
    for v0, v1 in lines:
        i_1, i_2 = jid(v0), jid(v1)
        lnid.append((i_1, i_2))
        pt_to_line[i_1].add(frozenset((i_1, i_2)))
        pt_to_line[i_2].add(frozenset((i_1, i_2)))
        lpos.append([junc[jid(v0)], junc[jid(v1)]])

    # N, 2
    lines_np = np.array(junc)
    lines_x = lines_np[:, 0].reshape(-1, 1)
    lines_y = lines_np[:, 1].reshape(-1, 1)
    merge_group_arr = [[], []]
    for _axis, line_pts in enumerate([lines_x, lines_y]):
        db_cluster = DBSCAN(eps=max_gap, min_samples=2).fit(line_pts)
        labels = db_cluster.labels_
        label_v = Counter(labels).most_common()
        for _v, _c in label_v:
            if _v < 0 or _c <= 1:
                continue
            group_sets_arr = []
            selected_pt_idx = np.where(labels == _v)[0]
            # 二次聚合动态加入
            # 从小到大
            sorted_pt_idx = selected_pt_idx[np.argsort(lines_np[selected_pt_idx, [1 - _axis]], axis=0).flatten()]
            pts_set = set(sorted_pt_idx)
            for pt_idx in sorted_pt_idx:
                current_connected_pts = pt_to_line[pt_idx]
                for _con_set in current_connected_pts:
                    connected_pt_in_group = _con_set.intersection(pts_set)
                    if len(connected_pt_in_group) > 1:
                        # 找到了一条待加入的线
                        # 和另外一轴的夹角小于alpha.
                        curr_line = lines_np[list(connected_pt_in_group)]
                        curr_line_len = np.sqrt(square_distance(curr_line[0], curr_line[1]))
                        delta_angle = abs(
                            math.atan2(*tuple(reversed(abs(curr_line[1] - curr_line[0])))) / math.pi * 180)
                        angle_alpha = max_slope / (1 + (curr_line_len / max_gap) * len_scale_factor)
                        if abs(delta_angle - (1 - _axis) * 90) > angle_alpha:
                            continue
                        if group_sets_arr:
                            is_find_inter_in_exist_group = False
                            for curr_idx, curr_group_set in enumerate(group_sets_arr):
                                inter_with_group = curr_group_set.intersection(connected_pt_in_group)
                                if inter_with_group:
                                    # 和当前组的第一条线的夹角小于1.5倍alpha.
                                    first_line = lines_np[list(curr_group_set)]
                                    f_vec = first_line[1] - first_line[0]
                                    c_vec = curr_line[1] - curr_line[0]
                                    cos_angle = f_vec.dot(c_vec) / (
                                            np.sqrt(f_vec.dot(f_vec)) * np.sqrt(c_vec.dot(c_vec)))
                                    # delta_first_angle = np.arccos(cos_angle)*180/math.pi
                                    if abs(abs(cos_angle) - 1) * 180 / math.pi > angle_alpha:
                                        continue
                                    group_sets_arr[curr_idx] = curr_group_set.union(connected_pt_in_group)
                                    is_find_inter_in_exist_group = True
                                    break
                            if not is_find_inter_in_exist_group:
                                group_sets_arr.append(connected_pt_in_group)
                        else:
                            # 当前合并列表为空, 直接加入.
                            group_sets_arr.append(connected_pt_in_group)
            if group_sets_arr:
                merge_group_arr[_axis].extend(group_sets_arr)
    lines_np_cp = copy.deepcopy(lines_np)
    for _axis, _group_sets in enumerate(merge_group_arr):
        for _group_set in _group_sets:
            select_idxs = list(_group_set)
            lines_np[select_idxs, _axis] = lines_np[select_idxs][:, _axis].mean().astype(np.int)
    return [[lines_np[_], lines_np[__]] for _, __ in lnid]


def straighten(fp_json):
    for fp in fp_json["floorplans"]:
        line_xy = list()
        pt_idx = list()
        pt_dict = dict()
        for line in fp['lines']:
            pt_idx.append([line['points'][0], line['points'][1]])
        for point in fp['points']:
            pt_dict[point['id']] = [point['x'], point['y']]
        for pt_id in pt_idx:
            line_xy.append([pt_dict[pt_id[0]], pt_dict[pt_id[1]]])
        str_line = straighten_lines(line_xy)
        for index, pt_id in enumerate(pt_idx):
            pt_dict[pt_id[0]] = str_line[index][0]
            pt_dict[pt_id[1]] = str_line[index][1]
        for point in fp['points']:
            point['x'] = pt_dict[point['id']][0]
            point['y'] = pt_dict[point['id']][1]
    return fp_json


class House(object):
    def __init__(self):
        self.floorplans = []
        self.frame_json = None
        self.frame_id = "8888"

    def set_frame_id(self, frame_id):
        self.frame_id = frame_id

    def set_json_str(self, json_str):
        frame_json = json.loads(json_str)

        # 规整点坐标
        fp_json = straighten(frame_json)
        self.frame_json = fp_json

        for fp_dict in fp_json["floorplans"]:
            fp = Floorplan()
            fp.set_ke_data(fp_dict)
            self.floorplans.append(fp)

    def set_json_file(self, json_file):
        self.set_frame_id(os.path.basename(json_file).split(".")[0])
        with open(json_file, 'r') as f:
            frame_json = json.load(f)
            # frame_json = json.load(f, encoding='gbk')
        # 规整点坐标
        fp_json = straighten(frame_json)
        self.frame_json = fp_json

        for fp_dict in fp_json["floorplans"]:
            fp = Floorplan()
            fp.set_ke_data(fp_dict)
            self.floorplans.append(fp)

    def show(self,
             demolished_walls=None,
             increment_walls=None,
             walking_pts=None,
             furniture=None,
             title=None,
             text=None,
             img_path=None):
        if settings.PLOT is True:
            fp_vis = vis.FloorPlanVis()
            for idx, fp in enumerate(self.floorplans):
                if idx == 0:
                    fp_vis.set_floorplan(fp)
                else:
                    fp_vis.add_floorplan(fp)
                if demolished_walls is not None:
                    fp_vis.add_demolished_walls(
                        demolished_walls,
                        fp.id_walls)
                if increment_walls is not None:
                    fp_vis.add_increment_walls(increment_walls)

            if walking_pts is not None:
                fp_vis.add_walking_path(walking_pts)
            if furniture is not None:
                fp_vis.add_furniture(furniture)
            if title is not None:
                fp_vis.add_title(title)
            if text is not None:
                fp_vis.add_text(text)

            fp_vis.show()
        else:
            pass

    def saveimg(self, img_path, frame_id,
                demolished_walls=None,
                walking_pts=None,
                furniture=None,
                title=None,
                text=None,
                increment_walls=None):
        if settings.PLOT is True:
            fp_vis = vis.FloorPlanVis()
            for idx, fp in enumerate(self.floorplans):
                if idx == 0:
                    fp_vis.set_floorplan(fp)
                else:
                    fp_vis.add_floorplan(fp)
                if demolished_walls is not None:
                    fp_vis.add_demolished_walls(
                        demolished_walls,
                        fp.id_walls)
                if increment_walls is not None:
                    fp_vis.add_increment_walls(increment_walls)

            if walking_pts is not None:
                fp_vis.add_walking_path(walking_pts)
            if furniture is not None:
                fp_vis.add_furniture(furniture)
            if title is not None:
                fp_vis.add_title(title)
            if text is not None:
                fp_vis.add_text(text)

            fp_vis.save_img_floorplan(img_path, frame_id)
            fp_vis.clear(if_close=True)
        else:
            pass

    def run_debug(self):
        json_dict = {
            settings.ROOMTYPE_HALLWAY: [],
            settings.ROOMTYPE_MASTER_BEDROOM: [],
            settings.ROOMTYPE_LIVINGROOM: [],
        }
        res_dict = copy.deepcopy(json_dict)
        for fp in self.floorplans:
            hallway_res, hallway_dict = fp.ana_hallway()
            if hallway_dict is not None:
                res_dict[settings.ROOMTYPE_HALLWAY].append(hallway_res)
                json_dict[settings.ROOMTYPE_HALLWAY].append(hallway_dict)

            for master in fp.get_master_bedrooms():
                if master is None:
                    continue
                master_res, master_dict = fp.ana_master_bedroom(master)
                res_dict[settings.ROOMTYPE_MASTER_BEDROOM].append(master_res)
                json_dict[settings.ROOMTYPE_MASTER_BEDROOM].append(master_dict)

            for guest in fp.get_guest_room():
                tmp = 0

            for living in fp.get_living_rooms():
                if living is None:
                    continue
                living_res, living_dict = fp.ana_livingroom(living)
                res_dict[settings.ROOMTYPE_LIVINGROOM].append(living_res)
                json_dict[settings.ROOMTYPE_LIVINGROOM].append(living_dict)

        return res_dict, json_dict

    def run(self):
        json_dict = {
            settings.ROOMTYPE_HALLWAY: [],
            settings.ROOMTYPE_MASTER_BEDROOM: [],
            settings.ROOMTYPE_LIVINGROOM: [],
        }
        res_dict = copy.deepcopy(json_dict)
        for fp in self.floorplans:
            try:
                hallway_res, hallway_dict = fp.ana_hallway()
                if hallway_dict is not None:
                    res_dict[settings.ROOMTYPE_HALLWAY].append(hallway_res)
                    json_dict[settings.ROOMTYPE_HALLWAY].append(hallway_dict)
            except Exception as error:
                traceback.print_exc()
                fp.set_exception(
                    json_dict,
                    settings.ROOMTYPE_HALLWAY,
                    error,
                    region_id="0"
                )
            # 主卧
            for master in fp.get_master_bedrooms():
                if master is None:
                    continue
                try:
                    master_res, master_dict = fp.ana_master_bedroom(master)
                    res_dict[settings.ROOMTYPE_MASTER_BEDROOM].append(master_res)
                    json_dict[settings.ROOMTYPE_MASTER_BEDROOM].append(master_dict)
                except Exception as error:
                    print(error)
                    # traceback.print_exc()
                    fp.set_exception(
                        json_dict,
                        settings.ROOMTYPE_MASTER_BEDROOM,
                        error,
                        master.region.id
                    )
            for living in fp.get_living_rooms():
                if living is None:
                    continue
                try:
                    living_res, living_dict = fp.ana_livingroom(living)
                    res_dict[settings.ROOMTYPE_LIVINGROOM].append(living_res)
                    json_dict[settings.ROOMTYPE_LIVINGROOM].append(living_dict)
                except Exception as error:
                    # traceback.print_exc()
                    print(error)

        self.res_dict, self.json_dict = res_dict, json_dict

        return res_dict, json_dict

    def get_frameXitems(self):
        frameXitems = {"floorplans": []}
        for fp in self.floorplans:
            items = []
            if hasattr(fp, "fur_list") is False:
                frameXitems["floorplans"].append(items)
                continue
            for fur in fp.fur_list:
                item = {
                    # "areaId": rid,
                    "name": fur.name,
                    "typeIdx": fur.type,
                    "typeName": fur.__class__.__name__,
                    "baseline": [p.args for p in fur.baseline.points],
                    "boundary": fur.get_contours(),
                    # "depth": fur.depth,
                    # "width": fur.width,
                }
                items.append(item)
            frameXitems["floorplans"].append(items)
        return frameXitems

    def get_frameX_json(self):
        frameXitems = self.get_frameXitems()
        res = self.frame_json
        for idx, fp in enumerate(res['floorplans']):
            fp['frameXitems'] = frameXitems['floorplans'][idx]
        return res

    def get_connect_areas4area_id(self, area_id):
        """
        获取当前功能区，连通（有门相连）的分间
        :param area_id:
        :return:
        """
        for fp in self.floorplans:
            reg = fp.id_regions.get(area_id, None)
            if reg is not None:
                break
        if reg is None:
            return []
        else:
            return reg.connect_region_id

    def get_window_cnt(self, area_id):
        windows = []
        for fp in self.floorplans:
            reg = fp.id_regions.get(area_id, None)
            windows = reg.get_windows()
        return len(windows)

    def get_room_type(self, area_id):
        for fp in self.floorplans:
            reg = fp.id_regions.get(area_id, None)
            if reg is not None:
                return reg.roomType
        return None


class Floorplan(object):
    """
    表示单层户型图类
    """

    def __init__(self):
        self._idx_pts = collections.OrderedDict()
        self._id_pts = collections.OrderedDict()
        self._idx_walls = collections.OrderedDict()
        self._id_walls = collections.OrderedDict()
        self._idx_wall_items = collections.OrderedDict()
        self._id_wall_items = collections.OrderedDict()
        self._idx_regions = collections.OrderedDict()
        self._id_regions = collections.OrderedDict()
        self._json = None
        self._name = u"一层"

        self.fur_list = []

    @property
    def id_regions(self):
        return self._id_regions

    @property
    def id_walls(self):
        return self._id_walls

    def set_json_file(self, json_file):
        with open(json_file, 'r') as f:
            ke_json = json.load(f)
        fp_json = ke_json[settings.FRAME_KEY["floorplans"]]

        # 规整，修改点坐标
        fp_json = straighten(fp_json)
        self._json = fp_json

        if len(fp_json) != 1:
            logging.warning("do not support muti-floors")
            raise RuntimeError("do not support muti-floors")
            # logging.error("do not support muti-floors ")
        self.set_ke_data(fp_json[0])

    def set_ke_data(self, ke_data):
        pts_key = settings.FRAME_KEY["points"]
        lines_key = settings.FRAME_KEY["lines"]
        region_key = settings.FRAME_KEY["regions"]
        l_i_key = settings.FRAME_KEY["line_items"]
        self._name = ke_data["name"]

        for idx, pt in enumerate(ke_data[pts_key["name"]]):
            junc = Junction()
            junc.init(pt, idx)
            self._idx_pts[idx] = junc
            self._id_pts[pt[pts_key["id"]]] = junc

        for idx, line in enumerate(ke_data[lines_key["name"]]):
            wall = Wall()
            wall.init(line, self._id_pts, idx)
            # 有时候会出现一个墙两个端点坐标完全相同
            if isinstance(wall.segment2d, settings.Point2D):
                continue
            self._idx_walls[idx] = wall
            self._id_walls[line[lines_key["id"]]] = wall
            # if wall.type > 2:
            #     logging.warning("find wall type = {}".format(wall.type))

        for wid, wall in self._id_walls.items():
            wall.set_neighbor_walls(self._id_walls)

        # 配置门窗等
        for idx, line_item in enumerate(ke_data[l_i_key["name"]]):
            wall_item = WallItem()
            wall_item.init(line_item, self._id_walls, self._id_pts, idx)
            self._idx_wall_items[idx] = wall_item
            self._id_wall_items[line_item[l_i_key["id"]]] = wall_item
            # if wall_item.type == 1:
            #     logging.warning("line item {}".format(wall_item.type))
        # 配置功能区
        for idx, reg in enumerate(ke_data[region_key["name"]]):
            region = Region()
            region.init(reg, self._id_pts, self._id_walls, self._id_wall_items, idx)
            self._idx_regions[idx] = region
            self._id_regions[region.id] = region
        for reg_id, reg in self._id_regions.items():
            reg.set_relations(self._id_regions)

    def get_id_items(self):
        # id_items = collections.OrderedDict({
        #     settings.FRAME_KEY["points"]["name"]: self._idx_pts,
        #     settings.FRAME_KEY["lines"]["name"]: self._idx_walls,
        #     settings.FRAME_KEY["line_items"]["name"]: self._idx_wall_items
        # })

        id_items = collections.OrderedDict()
        id_items[settings.FRAME_KEY["points"]["name"]] = self._idx_pts
        id_items[settings.FRAME_KEY["lines"]["name"]] = self._idx_walls
        id_items[settings.FRAME_KEY["line_items"]["name"]] = self._idx_wall_items

        return id_items

    def get_bounding_box(self):
        max_x = np.max([p.point2d.x for p in self._id_pts.values()])
        min_x = np.min([p.point2d.x for p in self._id_pts.values()])
        max_y = np.max([p.point2d.y for p in self._id_pts.values()])
        min_y = np.min([p.point2d.y for p in self._id_pts.values()])
        return min_x, max_x, min_y, max_y

    def get_regions_along_wall_id(self, wall_id):
        regions = []
        for k, v in self._idx_regions.items():
            if wall_id in v.id_walls.keys():
                regions.append(v)
        return regions

    def show(self,
             demolished_walls=None,
             increment_walls=None,
             walking_pts=None,
             furniture=None,
             title=None,
             text=None,
             frame_id=None,
             fp_idx=None,
             img_path=None):
        """
        demolished_walls: 拆除的墙
        walking_pathes: 多个点组成的路径，可以是多组[[Point2D]]
        furniture: 家具列表
        """
        if settings.PLOT is True:
            fp_vis = vis.FloorPlanVis()
            fp_vis.set_floorplan(self)

            # fp_vis.add_normal_direction()
            fp_vis.set_json(self._json)
            # fp_vis.set_standard_img()

            if demolished_walls is not None:
                fp_vis.add_demolished_walls(demolished_walls, self._id_walls)
            if increment_walls is not None:
                fp_vis.add_increment_walls(increment_walls)
            if walking_pts is not None:
                fp_vis.add_walking_path(walking_pts)
            if furniture is not None:
                fp_vis.add_furniture(furniture)
            if title is not None:
                fp_vis.add_title(title)
            if text is not None:
                fp_vis.add_text(text)
            if frame_id is not None:
                fp_vis.frame_id = frame_id
            if fp_idx is not None:
                fp_vis.fp_idx = fp_idx

            fp_vis.show(img_path=img_path)
        else:
            pass

    def saveimg(self, img_path, frame_id,
                demolished_walls=None,
                walking_pts=None,
                furniture=None,
                title=None,
                text=None):
        """
        分别保存doctorstrange渲染出的户型图，和本系统户型图
        """
        if settings.PLOT is True:
            fp_vis = vis.FloorPlanVis()
            fp_vis.set_floorplan(self)

            fp_vis.set_json(self._json)
            # fp_vis.set_standard_img()

            if demolished_walls is not None:
                fp_vis.add_demolished_walls(demolished_walls, self._id_walls)
            if walking_pts is not None:
                fp_vis.add_walking_path(walking_pts)
            if furniture is not None:
                fp_vis.add_furniture(furniture)
            if title is not None:
                fp_vis.add_title(title)
            if text is not None:
                fp_vis.add_text(text)

            fp_vis.save_img_floorplan(img_path, frame_id)
            fp_vis.clear(if_close=True)
        else:
            pass

    def save_standard_img(self, path, frame_id):
        if settings.PLOT is True:
            fp_vis = vis.FloorPlanVis()
            fp_vis.set_floorplan(self)
            fp_vis.set_json(self._json)
            fp_vis.set_standard_img()
            fp_vis.save_standard_img(path, frame_id)
        else:
            pass

    def set_exception(self, json_dict, room_type, error, region_id):
        if json_dict.get(room_type) is None:
            json_dict[room_type] = []
        error_dict = {}
        error_dict[settings.RES_FLOOR] = self._name
        error_dict[settings.RES_ERROR] = error[0]
        error_dict[settings.RES_AREA_ID] = region_id
        json_dict[room_type].append(error_dict)

    def get_total_area_in_m2(self):
        """总套内面积"""
        area = 0
        for k, v in self.id_regions.items():
            area += v.size / 1000 / 1000
        return area

    def get_entrance_region(self):
        # TODO: 多个入户门情况没有考虑
        # TODO: 入户门有时候会被标注错误
        entrance_list = []
        for k, v in self._id_wall_items.items():
            if v.entrance is not None:
                entrance_list.append(v)
        if len(entrance_list) == 0:
            return None, None
        entrance = entrance_list[0]

        region = None
        for k, v in self._id_regions.items():
            if entrance.id in [i for i in v.id_wall_items]:
                region = v

        return region, entrance

    def get_decoration2frameXitems(self, res_dict):
        # 把res_json中decoration[fur]更新后放进fru_list
        # TODO: 0326
        self.fur_list.extend(res_dict["decoration"]["furniture"])

    def get_master_bedrooms(self):
        master = master_bedroom.explain.get_master_bedroom(self)
        return [master]

    def get_guest_room(self):
        guest_rooms = guest_room.explain.get_guest_rooms(self)
        return guest_rooms

    def get_living_rooms(self):
        livingrooms = livingroom.explain.get_livingrooms(self)
        return livingrooms

    def ana_guest_room(self, guest):
        guest.set_floorplan(self)
        guest.region.prepare()
        guest.initial()
        guest.run()

    def ana_master_bedroom(self, master):
        master.set_floorplan(self)
        master.region.prepare()
        master.initial()
        # master.run()

        res = {
            settings.RES_FLOOR: self._name,
            settings.RES_AREA_ID: master.region.id,
        }

        # import frame_remould.utils.geo_utils as geo_utils
        # end_pt = geo_utils.get_another_pt(master.bed_wall_inner, master.bed_wall_start_pt)

        space_dict = {
            settings.RES_WIDTH: master.width,
            settings.RES_DEPTH: master.depth,
            settings.RES_DEPTH_PTS: master.width_pts,
            settings.RES_WIDTH_PTS: master.depth_pts,
            settings.RES_CONTOURS: master._inner_region.polygon.vertices,
            # settings.RES_CONTOURS: [master.bed_wall_start_pt, end_pt],
            # settings.RES_CONTOURS: master.max_rectangle.vertices,
        }
        res[settings.RES_SPACE] = space_dict

        deco_dict = {
            "index": 0,
            "furniture": master.furniture_list,
        }
        res[settings.RES_DECORATION] = deco_dict
        # self.show(walking_pts=[res["contours"]])
        res_json = master_bedroom.explain.res2json(res)

        self.get_decoration2frameXitems(res)
        return res, res_json

    def ana_livingroom(self, living):
        living.set_floorplan(self)
        living.region.prepare()
        living.set_inner_region()
        living.initial()
        living.run()

        res = {
            settings.RES_FLOOR: self._name,
            settings.RES_AREA_ID: living.region.id,
        }


        space_dict = {
            # settings.RES_WIDTH: living.width,
            # settings.RES_DEPTH: living.depth,
            # settings.RES_DEPTH_PTS: living.width_pts,
            # settings.RES_WIDTH_PTS: living.depth_pts,
            # settings.RES_CONTOURS: living._inner_region.polygon.vertices,
            # settings.RES_CONTOURS: [master.bed_wall_start_pt, end_pt],
            settings.RES_CONTOURS: living.max_rectangle.vertices,
        }
        res[settings.RES_SPACE] = space_dict
        res_json = livingroom.explain.res2json(res)
        return res, res_json

    def ana_hallway(self):
        # TODO: region None保护
        region, entrance = self.get_entrance_region()

        if entrance is None:
            return None, None
            # raise RuntimeError("no entrance tag")
        region.prepare()  # 务必每次提前准备每个功能区
        # 计算玄关轮廓区域
        con_list = hallway.get_hallway_contours(entrance, region)

        space_dict = hallway.get_space_doc(con_list, entrance, region)

        rsl = hallway.get_side_lay(self, right=True)
        lsl = hallway.get_side_lay(self, right=False)
        rvl = hallway.get_vertical_lay(self, right=True)
        lvl = hallway.get_vertical_lay(self, right=False)
        fl = hallway.get_face_lay(self)

        # # zhuc debug
        # self.show(walking_pts=[con_list])
        # region.show(walking_pts=[con_list])
        # inner_reg = region.set_inner_region()
        # region.show(walking_pts=[inner_reg.polygon.vertices])
        # settings.debug = region
        # recs = extract_rect.extract_all_max_rec(inner_reg.polygon)
        # con_list = recs[0].vertices + [recs[0].vertices[0]]

        layout_res = {
            settings.HALLWAY_RES_CONTOURS: con_list,
            settings.HALLWAY_RES_RIGHT_SIDE_LAY: rsl,
            settings.HALLWAY_RES_LEFT_SIDE_LAY: lsl,
            settings.HALLWAY_RES_RIGHT_VERT_LAY: rvl,
            settings.HALLWAY_RES_LEFT_VERT_LAY: lvl,
            settings.HALLWAY_RES_FACE_LAY: fl,
        }
        layout_dict = hallway.get_layout_doc(layout_res)

        cab_order = hallway.get_ordered_cabinet(layout_res)

        remould_dict = hallway.get_remould_res(self, layout_res)

        region.clear()

        res = copy.deepcopy(layout_res)
        res[settings.HALLWAY_RES_CABINETS] = cab_order
        res[settings.HALLWAY_RES_SPACE] = space_dict
        res[settings.HALLWAY_RES_LAYOUT_DOC] = layout_dict
        res[settings.HALLWAY_RES_REMOULD] = remould_dict

        res_json = hallway.res2json(res)
        return res, res_json

    def ana_kichen(self):
        demolished_walls = []
        for k, v in self._id_regions.items():
            if v.room_type != 8 and v.room_type != 9:
                continue
            demolished_walls.extend(kitchen.get_adjacent_living_wall(v, self._id_regions))

        return demolished_walls

    def get_connected_parlour_door(self, area_id):
        door = detection_point.get_connected_parlour_door(self, area_id)
        if door is None:
            return None
        else:
            return door


def main(frame_json):
    frame_id = os.path.basename(frame_json).split(".")[0]
    hs = House()
    hs.set_json_file(frame_json)
    res_dict, js_dict = hs.run()

    hallway.show(hs, res_dict)
    # hallway.show(hs, res_dict, img_path=r"D:\\")

    exit(1)

    fp = Floorplan()
    fp.set_json_file(frame_json)

    # res, _ = fp.ana_master_bedroom()
    # fp.show(walking_pts=[res["contours"]])

    res, _ = fp.ana_hallway()
    # demolished_walls = fp.ana_kichen()

    furns = [list(f.values())[0] for f in res["cabinets"]]
    # furns.extend(res[settings.HALLWAY_RES_RIGHT_SIDE_LAY])
    # furns.extend(res[settings.HALLWAY_RES_LEFT_SIDE_LAY])
    # furns.extend(res[settings.HALLWAY_RES_RIGHT_VERT_LAY])
    # furns.extend(res[settings.HALLWAY_RES_LEFT_VERT_LAY])
    # furns.extend(res[settings.HALLWAY_RES_FACE_LAY])

    text = "#" + res["space_analysis"]["space_doc"]
    for k, v in res["layout_doc"].items():
        if v != "":
            text += "\n#" + v["cab_doc"]
    text += "\n#" + res["remould"]["remould_doc"]
    demolished_walls = None
    if res["remould"].get("demolished_wall_id") is not None:
        demolished_walls = res["remould"].get("demolished_wall_id")
    fp.show(walking_pts=[res["contours"]],
            furniture=furns,
            title=frame_id,
            text=text,
            demolished_walls=demolished_walls)

    exit(1)


if __name__ == "__main__":
    # 12000000591910 三层frame_id
    # 1220040011360439 入户门配置错误
    # 1220024370201218 有门厅字段
    # 1220040771779630 有不在轮廓上的玄关墙
    # 1220025076185173 玄关左折线
    # 1220040514674830 玄关测试多线
    # 1220024222317571 两个矩形
    # 11000001185700 斜墙门厅
    # 11000011411349 逆时针错误
    #
    # 12.08
    # 1220042147667998 深凹槽
    # 1220039795259230 立放比较远
    # 1220040514674830 折线
    # more 11000001711089  斜线
    #
    # frame_json = r"D:\ke\data\test.json"
    # frame_json = r"D:\ke\data\frame_json\1220040514674830.json"
    # try:
    #     # frame_json = r"D:\ke\data\frame_json\12000000591910.json"
    #     frame_json = r"D:\ke\data\more_frame_json\11000001458404.json"
    #     main(frame_json)
    # except RuntimeError as e:
    #     print("RUNTIMEERROR: ", e)
    json_file = '/Users/lxin/Desktop/摆放测试/43000001519555.json'
    with open(json_file, 'r') as f:
        ke_json = json.load(f)
    fp_json_0 = ke_json[settings.FRAME_KEY["floorplans"]]
    fp_json = straighten(fp_json_0)
    print(fp_json)
