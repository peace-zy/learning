1. 单独测试脚本frame_remould/test/single_test.py

2. 本地批测脚本frame_remould/test/multithread_test.py

3. spark集群测试：
```
zip -r -q lib.zip frame_remould/ lib/
sh frame_remould/test/spark_submit_test.sh
```