# coding=utf-8

def arrayItemPrev(item, array, fn=None):
    idx = array.index(item)
    result = array[-1] if idx == 0 else array[idx - 1]
    # TODO:
    if fn:
        r = fn(result)
    return result


def arrayItemNext(item, array, fn=None):
    if len(array) <= 1:
        return None

    index = array.index(item)
    result = array[index + 1] if index != len(array) - 1 else array[0]
    # TODO:
    if fn:
        r = fn(result)
    return result
