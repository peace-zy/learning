# coding=utf-8
import numpy as np

import frame_remould.settings as settings


def linesWithDistanceOfLine(distanceOfLine, line):
    """
    line: geometry line
    """
    k = line.slope
    if line.is_vertical:
        dy = 0
        dx = distanceOfLine
    else:
        dis2 = distanceOfLine * distanceOfLine
        dy = np.sqrt(dis2 / (k * k + 1))
        dx = dy * (-k)
    p1 = settings.Point2D(line.p1.x - dx, line.p1.y - dy)
    p2 = settings.Point2D(line.p2.x - dx, line.p2.y - dy)
    p3 = settings.Point2D(line.p1.x + dx, line.p1.y + dy)
    p4 = settings.Point2D(line.p2.x + dx, line.p2.y + dy)
    result = [settings.Line2D(p1, p2), settings.Line2D(p3, p4)]

    if (line.p2.x - line.p1.x) < 0:
        pass
    elif (line.p2.x - line.p1.x) > 0:
        result.reverse()
    else:
        if (line.p2.y - line.p1.y) < 0:
            result.reverse()
        else:
            pass

    return result


def getK(pt1, pt2):
    if pt1.x == pt2.x:
        return 0
    result = (pt2.y - pt1.y) / (pt2.x - pt1.x)
    return result


if __name__ == "__main__":
    p1 = settings.Point2D(36625, 42563)
    p2 = settings.Point2D(38150, 42563)
    l = settings.Line2D(p1, p2)

    r = linesWithDistanceOfLine(60, l)
    tmp = 0




