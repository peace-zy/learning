# coding=utf-8
from frame_remould.doctorstrange.utils.math import linesWithDistanceOfLine


def edgeLine(line, thickness, offset):
    thick2 = thickness / 2
    rect1 = linesWithDistanceOfLine(thick2 + offset, line)
    rect2 = linesWithDistanceOfLine(thick2 - offset, line)
    return [rect1[0], rect2[1]]


def edgePoints(wall, region):
    pass


if __name__ == "__main__":
    import frame_remould.settings as settings
    from frame_remould.floorplan import House

    frame_json = r"D:\test.json"
    hs = House()
    hs.set_json_file(frame_json)
    region = hs.floorplans[0].id_regions.get(hs.floorplans[0].id_regions.keys()[0])


    # edge_pts = edgePoints()
    tmp = 0

