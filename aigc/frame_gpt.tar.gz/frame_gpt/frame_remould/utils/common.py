# coding=utf-8
import json
import os

import sys
default_encoding = 'utf-8'
if sys.getdefaultencoding() != default_encoding:
    reload(sys)
    sys.setdefaultencoding(default_encoding)


class Params(object):
    def __init__(self, json_path):
        with open(json_path, encoding="utf8") as f:
            params = json.load(f)
            self.__dict__.update(params)

    def save(self, json_path):
        with open(json_path, 'w') as f:
            json.dump(self.__dict__, f, indent=4)

    def update(self, json_path):
        with open(json_path) as f:
            params = json.load(f)
            self.__dict__.update(params)

    @property
    def dict(self):
        return self.__dict__


def maybe_mkdir_p(path):
    if not os.path.exists(path):
        os.makedirs(path)
    # else:
    #     shutil.rmtree(path)
    #     os.mkdir(path)


def save_json_file(json_dict, path):
    with open(path, 'w') as f:
        json.dump(json_dict, f, encoding="utf-8", indent=4, ensure_ascii=False)
    # import codecs
    # with codecs.open(path, 'w', encoding='utf-8') as f:
    #     json.dump(json_dict, f, ensure_ascii=False, indent=4, encoding='utf-8')
