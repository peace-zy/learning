# coding=utf-8
# Copyright (c) 2018 www.ke.com, Inc. All Rights Reserved
"""
spark 相关操作基础工具 v2
update log:
    1. 增加 hive 存储方式
    2. 面向配置，重新规范配置参数格式
Authors: yudonghai@ke.com
Date:    2018/11/23
"""
from __future__ import division
import os
import logging
import sys
import traceback
import random
import time

import json
from pyspark.sql import session
from pyspark.sql import dataframe
from pyspark import rdd


def check_path(file_path):
    """ 检查本地路径是否存在
    :param file_path, string, 本地文件路径
    检查结果本地存储路径参数是否合法
    :return: None
    """
    path = os.path.dirname(file_path)
    if not os.path.exists(path):
        os.makedirs(path)
    file = open(file_path, 'w')
    file.write("")
    file.close()

    if not os.path.isdir(path):
        raise IOError("The file path '%s' does not exist!" % path)


class SparkSqlDriver(object):
    """
    spark sql 执行的基础类， 封装了执行sql到文件存储的过程；
    抽象了逻辑处理阶段
    """

    def __init__(self, **kwargs):
        """
        :param kwargs:
            必需参数：
            job_name: string, 任务名称，需要 ** 与sql文件同名 **
            save_params: (其中标为 ** 必需 ** 的为必需参数, 其他为可选参数)
                file_or_table_name: string, 结果保存的文件路径或hive表名 ** 必需 **
                write_mode: string, 写入方式，默认 overwrite
                save_target: string, 保存位置，"hdfs", "local", "hive" 可选，默认 "local"
                file_format: string, save_target 为 hive 时，hive存储时文件类型
                coalesce_num: int, save_target 为 hdfs 时，存储分区个数，默认 1
                save_header: bool, save_target 为 local 时， 存储是否保存表头
                partition_param: dict<pt_name: value>, save_target 为 hive 时 **必需**, 指定要存储的分区
                save_columns: list<string>, save_target 为 hive 时, 指定要存储的字段，默认为全部

            可选参数：
            job_subname: string, 任务次级名称，只参与标识任务名
            run_mode: string, 运行模式，默认 ignore
                "ignore": 失败时以正常结束状态退出
                "strict": 失败时以非0状态退出
            sql_params:
                sql_path, string, sql 文件所在目录，默认 ../sql
                其他 key-value, 用于生成sql 的参数
            logic_params:
                logic_function: function(df, logic_function_params), 逻辑处理方法，参数需要是样式中方法
                logic_function_params: dict, 逻辑方法参数
            """
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
        params_str = json.dumps(kwargs, indent=4, default=lambda o: str(o))
        # logging.info("spark job params: \n{}".format(params_str))
        job_name = kwargs.get("job_name", None)
        self.sql_param = kwargs.get("sql_params", {})
        self.logic_param = kwargs.get("logic_params", {})
        self.save_param = kwargs.get("save_params", {})
        
        if job_name is None:
            logging.error("lack job_name ")
            exit(1)
        self.job_name = job_name
        self.job_subname = kwargs.get("job_subname", "")
        run_mode = kwargs.get("run_mode", "ignore")
        if run_mode not in {"ignore", "strict"}:
            logging.warn("invalid run_mode value: {}, change to default(ignore)".format(run_mode))
            self.run_mode = "ignore"
        else:
            self.run_mode = run_mode

        # 存储参数检查
        self.file_or_table_name = self.save_param.get("file_or_table_name", None)
        if self.file_or_table_name is None:
            logging.error("lack file_or_table_name param in save_params")
            exit(1)

        # 本地存储路径检查
        if self.save_param["save_target"] == "local":
            try:
                check_path(self.file_or_table_name)
            except IOError:
                logging.error("local file path not exist: {}".format(self.file_or_table_name))
                exit(1)

        self.session = session.SparkSession \
            .builder \
            .appName(job_name) \
            .enableHiveSupport() \
            .getOrCreate()

        # SparkSql查询得到的DataFrame
        self.raw_df = None
        # 经过逻辑处理后的DataFrame
        self.result_df = None

        self.sql_str = self.load_sql()

    def load_sql(self):
        """
        加载sql文件
        :return: string, sql string
        """
        sql_path = self.sql_param.get("sql_path", "../sql")
        sql_file = sql_path + "/" + self.job_name + ".hql"
        if os.path.exists(sql_file):
            with open(sql_file, "r") as sql_data:
                sql_str = "".join(sql_data.readlines()).format(**self.sql_param)
        else:
            sql_file = sql_path + "/" + self.job_name + ".sql"
            with open(sql_file, "r") as sql_data:
                sql_str = "".join(sql_data.readlines()).format(**self.sql_param)

        logging.info("\n" + sql_str)
        return sql_str

    def run_sql(self, sql):
        # 执行sql
        spark_result = self.session.sql(sql)
        self.raw_df = spark_result
        return spark_result

    def logic_process(self):
        """
            可选参数：
                "logic_function", function, 自定义逻辑处理方法.
                    此类方法至少需要两个参数，第一个为SparkSqlDriver， 第二个为 sql 查询得到的DataFrame
                    其他参数通过字典传入
                "logic_function_params", dict, 逻辑处理方法需要的参数
        """
        
        func = self.logic_param.get("logic_function", None)
        if func is None:
            self.result_df = self.raw_df
        else:
            func_params = self.logic_param.get("logic_function_params", {})

            self.result_df = func(self, self.raw_df, **func_params)

    def run(self):
        """
        封装spark任务执行过程
        :return:
        """
        full_job_name = self.job_name + self.job_subname
        logging.info("job %s start" % full_job_name)
        if self.sql_str is None:
            logging.error("sql string is None!")
            sys.exit(1)
        self.run_sql(self.sql_str)

        self.logic_process()

        job_success = self.save_spark_result(self.file_or_table_name)

        if job_success:
            logging.info("job %s success" % full_job_name)
        else:
            logging.error("job %s failed" % full_job_name)
            if self.run_mode == "strict":
                exit(1)

    def save_spark_result(self, file_path):
        """
        将 spark DataFrame 进行存储
        :param file_path:  string, 存储的文件名或表名
        :return:
        """
        # 写入方式， 默认 "overwrite"
        write_mode = self.save_param.get("write_mode", "overwrite")
        # 存储位置，hdfs 或 local, 默认 local
        save_target = self.save_param.get("save_target", "local")
        # hdfs 存储时文件切分个数; 默认 1
        coalesce_num = self.save_param.get("coalesce_num", None)
        # hdfs 存储时文件格式
        file_format = self.save_param.get("file_format", "csv")
        # 本地存储时是否存储文件头, 默认True
        save_header = self.save_param.get("save_header", True)

        if self.result_df is None:
            if self.raw_df is None:
                logging.error("empty ")
            else:
                self.result_df = self.raw_df
                logging.warn("there is no result data, save raw data instead")

        spark_result = self.result_df
        if isinstance(spark_result, rdd.RDD):
            spark_result = self.session.createDataFrame(spark_result)

        if not isinstance(spark_result, dataframe.DataFrame):
            logging.error("data type '{}' not supported! only DataFrame and RDD are supported"
                          .format(str(type(spark_result))))
            return False

        # 存储 hdfs
        if save_target == 'hdfs':
            # 结果写入hdfs.
            # 注意：此种存储方式对列名要求严格，
            # 类似"SUM(CASE tb.follow_type WHEN 0 THEN 1 ELSE 0 END)" 列名包含空格、括号等特殊字符，需要重命名
            try:
                if coalesce_num is not None:
                    spark_result.coalesce(coalesce_num).write.mode(write_mode).save(file_path, format=file_format)
                else:
                    spark_result.write.mode(write_mode).save(file_path, format=file_format)
            except Exception:
                logging.error("save DataFrame failed! \n" + traceback.format_exc())
                return False
            return True

        # 存储本地
        elif save_target == 'local':

            # 结果转为pandas.DataFrame
            result = spark_result.toPandas()
            # 本地存储
            result.to_csv(file_path, index=False, sep='\t', encoding='utf-8', header=save_header)

        # 存储 hive
        elif save_target == 'hive':
            try:
                view_salt = "{}_{}".format(int(time.time()), random.randint(0, 10000)) 
                spark_result.createOrReplaceTempView("{}_{}_tmp".format(self.job_name, view_salt))

                pt_params = self.save_param.get("partition_params", None)
                if pt_params is None:
                    logging.error("lack partition setting for saving hive")
                    return False
                else:
                    pt_param_lst = ["{}={}".format(pt, pt_params[pt]) for pt in pt_params]
                pt_params_str = ",".join(pt_param_lst)
                insert_str = "insert {} table {} partition ({})".format(write_mode, file_path, pt_params_str)
                select_str = " select {} from {}".format(",".join(self.save_param.get("save_columns", ["*"])), "{}_{}_tmp".format(self.job_name, view_salt))
                logging.info(insert_str + select_str)
                self.session.sql(insert_str + select_str)
            except Exception:
                logging.error("save DataFrame failed! \n" + traceback.format_exc())
                return False
            return True
        else:
            logging.error("unknown save target!")
            return False
        return True

    def rdd_2_df(self, rdd_data):
        """ rdd 转为 DataFrame 格式 """
        if not isinstance(rdd_data, rdd.RDD):
            logging.error("data type is not RDD!")
            return None
        else:
            df_data = self.session.createDataFrame(rdd_data)
            return df_data

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.session.stop()


if __name__ == '__main__':
    print("spark_util")
