# coding=utf-8
import os
import math
import json
import requests
from PIL import Image
from io import BytesIO

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.path as mpath
import matplotlib.lines as mlines
import matplotlib.patches as mpatches
from matplotlib.collections import PatchCollection

import frame_remould.settings as settings
import frame_remould.utils.geo_utils as geo_utils
import frame_remould.utils.shapely_figures as shapely_figures

# plt.rcParams['font.family'] = ['sans-serif']
# plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['font.sans-serif'] = ['Arial Unicode MS']  # mac plot显示中文

def plot_floorplan(floorplan):
    """
    户型矢量
    :param floorplan:
    :return:
    """
    # floorplan in json format
    print('=============plot_floorplan=============')
    if type(floorplan) is dict:
        floorplan = json.dumps(floorplan)
    r = requests.post('http://10.200.24.133:3737/easy_print',
                      data={'source': floorplan, "imgSize": '512x512', 'drawType': 'main'}, timeout=10)
    # 如视API
    # r = requests.post('http://doctorstrange-vrlab.lianjia.com/print',
    #                   data={'floorplan': floorplan}, timeout=10)
    img = Image.open(BytesIO(r.content))
    return img


class LineShape(object):
    def __init__(self, p1, p2, thickness, offset=0):
        self.offset = offset # 用于多层分离的offset
        self.p1 = settings.Point2D(*p1)
        self.p2 = settings.Point2D(*p2)
        self.seg = settings.Segment2D(self.p1, self.p2)
        self.thickness = thickness
        self.path_config = {"facecolor": "red", "linewidth": 1, "zorder": 1}

    def get_config(self):
        return self.path_config

    def set_alpha(self, alpha):
        self.path_config.update({"alpha": alpha})

    def set_path_config(self, config):
        self.path_config.update(config)

    @property
    def box_points(self):
        n = self.seg.direction.unit.rotate(settings.pi / 2)
        # n = self.seg.normal_direction.unit
        offset_p = settings.Point2D(self.offset, 0)
        box_points = {}
        box_points["p_lt"] = self.p1 + (n * (self.thickness / 2)) + offset_p
        box_points["p_rt"] = self.p2 + (n * (self.thickness / 2)) + offset_p
        box_points["p_rb"] = self.p2 - (n * (self.thickness / 2)) + offset_p
        box_points["p_lb"] = self.p1 - (n * (self.thickness / 2)) + offset_p
        return box_points

    @property
    def path_data(self):
        Path = mpath.Path
        box_points = self.box_points
        path_data = [
            (Path.MOVETO, box_points["p_lt"]),
            (Path.LINETO, box_points["p_rt"]),
            (Path.LINETO, box_points["p_rb"]),
            (Path.LINETO, box_points["p_lb"]),
            (Path.CLOSEPOLY, box_points["p_lt"])
        ]
        return path_data

    @property
    def path_patch(self):
        codes, verts = zip(*self.path_data)
        # https://matplotlib.org/api/path_api.html#matplotlib.path.Path
        path = mpath.Path(verts, codes, closed=True, readonly=True)
        # https://matplotlib.org/api/_as_gen/matplotlib.patches.PathPatch.html#matplotlib.patches.PathPatch
        path_patch = mpatches.PathPatch(path)
        return path_patch


class WallShape(LineShape):
    def __init__(self, p1, p2, thickness, offset=0):
        super(WallShape, self).__init__(p1, p2, thickness, offset)
        self.path_config.update({"facecolor": "black", "alpha": 1.})


class DemolishedWallShape(LineShape):
    def __init__(self, p1, p2, thickness, offset=0):
        super(DemolishedWallShape, self).__init__(p1, p2, thickness, offset)
        self.path_config.update({"facecolor": "white", "edgecolor": "red"})


class IncrementWallShape(LineShape):
    def __init__(self, p1, p2, thickness, offset=0):
        super(IncrementWallShape, self).__init__(p1, p2, thickness, offset)
        self.path_config.update({"facecolor": "white", "edgecolor": "blue"})


class DoorShape(LineShape):
    def __init__(self, p1, p2, thickness, offset=0):
        super(DoorShape, self).__init__(p1, p2, thickness, offset)
        self.path_config.update({"facecolor": "white", "edgecolor": "green"})


class SingleDoorShape(DoorShape):
    def __init__(self, p1, p2, thickness, offset=0):
        super(SingleDoorShape, self).__init__(p1, p2, thickness, offset)
        self.path_config.update({"facecolor": "white", "edgecolor": "green"})


class DoubleDoorShape(DoorShape):
    def __init__(self, p1, p2, thickness, offset=0):
        super(DoubleDoorShape, self).__init__(p1, p2, thickness, offset)

    @property
    def box_points(self):
        # n = self.seg.direction.unit.rotate(settings.pi / 2)
        box_points = super(DoubleDoorShape, self).box_points
        box_points["p_ml"] = box_points["p_lt"].midpoint(box_points["p_rt"])
        box_points["p_mr"] = box_points["p_lb"].midpoint(box_points["p_rb"])\

        return box_points

    @property
    def path_data(self):
        Path = mpath.Path
        box_points = self.box_points
        path_data = [
            (Path.MOVETO, box_points["p_lt"]),
            (Path.LINETO, box_points["p_rt"]),
            (Path.LINETO, box_points["p_rb"]),
            (Path.LINETO, box_points["p_lb"]),
            (Path.CLOSEPOLY, box_points["p_lt"]),
            (Path.MOVETO, box_points["p_mr"]),
            (Path.LINETO, box_points["p_ml"])
        ]
        return path_data


class OpeningDoorShape(DoorShape):
    def __init__(self, p1, p2, thickness, offset=0):
        super(OpeningDoorShape, self).__init__(p1, p2, thickness, offset)

    @property
    def box_points(self):
        # n = self.seg.direction.unit.rotate(settings.pi / 2)
        box_points = super(OpeningDoorShape, self).box_points
        box_points["p_ml"] = box_points["p_lt"].midpoint(box_points["p_lb"])
        box_points["p_mr"] = box_points["p_rt"].midpoint(box_points["p_rb"])

        return box_points

    @property
    def path_data(self):
        Path = mpath.Path
        box_points = self.box_points
        path_data = [
            (Path.MOVETO, box_points["p_lt"]),
            (Path.LINETO, box_points["p_rt"]),
            (Path.LINETO, box_points["p_rb"]),
            (Path.LINETO, box_points["p_lb"]),
            (Path.CLOSEPOLY, box_points["p_lt"]),
            (Path.MOVETO, box_points["p_mr"]),
            (Path.LINETO, box_points["p_ml"])
        ]
        return path_data


class SlidingDoorShape(DoorShape):
    def __init__(self, p1, p2, thickness, offset=0):
        super(SlidingDoorShape, self).__init__(p1, p2, thickness, offset)

    @property
    def box_points(self):
        box_points = super(SlidingDoorShape, self).box_points
        offset_p = settings.Point2D(self.offset, 0)
        p1 = self.p1 + offset_p
        p2 = self.p2 + offset_p
        box_points["p_mt"] = (
            box_points["p_lt"].midpoint(box_points["p_rt"]).midpoint(box_points["p_rt"])
        )
        box_points["p_mb"] = (
            box_points["p_rb"].midpoint(box_points["p_lb"]).midpoint(box_points["p_lb"])
        )
        box_points["p_ml"] = p2.midpoint(p1).midpoint(p1)
        box_points["p_mr"] = p1.midpoint(p2).midpoint(p2)
        return box_points

    @property
    def path_data(self):
        Path = mpath.Path
        box_points = self.box_points
        offset_p = settings.Point2D(self.offset, 0)
        p1 = self.p1 + offset_p
        p2 = self.p2 + offset_p
        path_data = [
            (Path.MOVETO, box_points["p_lt"]),
            (Path.LINETO, box_points["p_mt"]),
            (Path.LINETO, box_points["p_mr"]),
            (Path.LINETO, box_points["p_ml"]),
            (Path.LINETO, box_points["p_mb"]),
            (Path.LINETO, box_points["p_rb"]),
            (Path.LINETO, p2),
            (Path.LINETO, p1),
            (Path.CLOSEPOLY, box_points["p_lt"]),
        ]
        return path_data


class WindowShape(LineShape):
    def __init__(self, p1, p2, thickness, offset=0):
        super(WindowShape, self).__init__(p1, p2, thickness, offset)
        self.path_config.update({"facecolor": "white", "edgecolor": "blue"})

    @property
    def path_data(self):
        Path = mpath.Path
        box_points = self.box_points
        offset_p = settings.Point2D(self.offset, 0)
        p1 = self.p1 + offset_p
        p2 = self.p2 + offset_p
        path_data = [
            (Path.MOVETO, box_points["p_lt"]),
            (Path.LINETO, box_points["p_rt"]),
            (Path.LINETO, box_points["p_rb"]),
            (Path.LINETO, box_points["p_lb"]),
            (Path.LINETO, box_points["p_lt"]),
            (Path.MOVETO, p1),
            (Path.LINETO, p2),
            (Path.CLOSEPOLY, box_points["p_lt"]),
        ]
        return path_data


class FloorPlanVis(object):
    """
    户型图可视化
    """

    def __init__(self, width=0, height=0, dpi=100):
        config = {
            "dpi": dpi,
            # 同样可以控制坐标轴显示
            # "gridspec_kw": {"left": 0, "right": 1, "bottom": 0, "top": 1},
        }
        fig, ax = plt.subplots(**config)

        self.fig = fig
        self.ax = ax

        self.collection = []
        self.floorplans = []
        self.scale = 1
        self.width = width
        self.height = height
        self._json = None
        self._img = None
        self.frame_id = 888
        self.fp_idx = 0

    def set_style(self):
        """
        配置图像风格
        """
        if self.width and self.height:
            # 设置画布 Figure 尺寸
            self.fig.set_size_inches(
                self.width / self.fig.dpi, self.height / self.fig.dpi
            )
            # 设置画布 Axes 坐标轴范围
            self.ax.set_xlim(0, math.ceil(self.width * self.scale))
            self.ax.set_ylim(0, math.ceil(self.height * self.scale))
        else:
            # 设置画布 Axes 坐标轴采用等长刻度
            self.ax.axis("equal")
            # 设置画布 Figure 自动调整尺寸
            # self.fig.tight_layout()

        # 设置画布 Axes 坐标系原点为左上角, X 轴沿着水平方向向右延伸，Y 轴沿垂直方向向下延伸
        self.ax.xaxis.set_ticks_position("top")
        # self.ax.invert_yaxis()
        # 设置画布 Axes 坐标轴关闭
        self.ax.axis("on")
        # self.ax.axis("off")

        return self

    def show(self, img_path=None):
        """
        调试时展示
        """

        if img_path is None:
            self.fig.show()
            plt.show()

        if img_path is not None:
            idx_str = ("_" + str(self.fp_idx)) if self.fp_idx != 0 else ""
            img_name = str(self.frame_id) + idx_str + ".png"
            plt.savefig(os.path.join(img_path, img_name))
        self.clear(True)


    def show_img_floorplan(self):
        fig, ax = plt.subplots(1, 2)
        # TODO: 把image 和 floorplan画在一起

    def save_img_floorplan(self, img_path, frame_id):
        # matplotlib.use("agg")
        img_name = frame_id + "_fp.png"
        # self.fig.show()
        plt.savefig(os.path.join(img_path, img_name))

        img_name = frame_id + "_std.png"
        if self._img is not None:
            self._img.save(os.path.join(img_path, img_name))
        self.clear()

    def save_standard_img(self, path, frame_id):
        if self._img is None:
            assert False, "STANDARD IMG is None"
        img_name = frame_id + ".png"
        self._img.save(os.path.join(path, img_name))

    def clear(self, if_close=False):
        self.ax.clear()

        if if_close:
            plt.close(self.fig)
        return self

    def set_json(self, fp_json):
        self._json = fp_json

    def set_standard_img(self):
        # 需要vpn, 获取标准栅格图
        self._img = plot_floorplan(self._json)

    def set_floorplan(self, floorplan):
        self.clear()
        self.floorplans.append(floorplan)

        for k, v in floorplan.get_id_items().items():
            if k == settings.FRAME_KEY["points"]["name"]:
                pass
            if k == settings.FRAME_KEY["lines"]["name"]:
                self.set_lines(v)
            if k == settings.FRAME_KEY["line_items"]["name"]:
                self.set_line_items(v)
        self.set_style()

    def add_floorplan(self, fp):
        min_x0, max_x0, min_y0, max_y0 = self.floorplans[0].get_bounding_box()
        multiple = len(self.floorplans)
        offset = (max_x0 - min_x0 + 1000) * multiple
        self.floorplans.append(fp)

        for k, v in fp.get_id_items().items():
            if k == settings.FRAME_KEY["points"]["name"]:
                pass
            if k == settings.FRAME_KEY["lines"]["name"]:
                self.set_lines(v, offset=offset)
            if k == settings.FRAME_KEY["line_items"]["name"]:
                self.set_line_items(v, offset=offset)
        self.set_style()

    def set_lines(self, lines, offset=0):
        line_keys = settings.FRAME_KEY["lines"]
        for idx, line in lines.items():
            p1, p2 = line.get_offset_p1p2()
            # p1 = (float(line.segment2d.p1.x), float(line.segment2d.p1.y))
            # p2 = (float(line.segment2d.p2.x), float(line.segment2d.p2.y))
            wall_shape = WallShape(p1, p2, line.thickness, offset)
            if line.type == line_keys["types"]["virtual_wall"]:
                wall_shape.set_alpha(0.2)
            self.set_patch_collection(wall_shape)

    def set_line_items(self, line_items, offset=0):
        li_keys = settings.FRAME_KEY["line_items"]
        for idx, line_item in line_items.items():
            p1, p2 = line_item.get_offset_p1p2()
            # p1 = (float(line_item.segment2d.p1.x), float(line_item.segment2d.p1.y))
            # p2 = (float(line_item.segment2d.p2.x), float(line_item.segment2d.p2.y))
            shape = None
            if line_item.type == li_keys["types"]["single_door"]:
                shape = SingleDoorShape(p1, p2, line_item.thickness, offset)
            elif line_item.type in li_keys["types"]["double_door"]:
                shape = DoubleDoorShape(p1, p2, line_item.thickness, offset)
            elif line_item.type == li_keys["types"]["sliding_door"]:
                shape = SlidingDoorShape(p1, p2, line_item.thickness, offset)
            elif line_item.type == li_keys["types"]["opening_door"]:
                shape = OpeningDoorShape(p1, p2, line_item.thickness, offset)
            elif line_item.type in li_keys["types"]["window"]:
                shape = WindowShape(p1, p2, line_item.thickness, offset)
            # TODO: 其它门窗类暂时没有绘制
            if shape is not None:
                self.set_patch_collection(shape)

    def add_normal_direction(self, lines=True, lineitems=False):
        def add_normal(lines):
            patches = []
            for idx, line in lines.items():
                if line.line2d is None:
                    continue
                n = geo_utils.get_normal_dir(line.line2d) * 500
                mid = line.segment2d.midpoint
                dx, dy = n.x, n.y
                arrow = mpatches.Arrow(float(mid.x), float(mid.y),
                                       dx, dy, 300, facecolor="red")
                patches.append(arrow)
            patch_collection = PatchCollection(patches, **{"facecolor": "red"})
            self.ax.add_collection(patch_collection)

        for k, v in self.floorplan.get_id_items().items():
            if k == settings.FRAME_KEY["points"]["name"]:
                pass
            if k == settings.FRAME_KEY["lines"]["name"]:
                if lines is True:
                    add_normal(v)
            if k == settings.FRAME_KEY["line_items"]["name"]:
                if lineitems is True:
                    add_normal(v)

    def add_demolished_walls(self, demolished_walls, id_walls):
        for k, line in id_walls.items():
            if k in demolished_walls:
                p1 = (float(line.segment2d.p1.x), float(line.segment2d.p1.y))
                p2 = (float(line.segment2d.p2.x), float(line.segment2d.p2.y))
                wall_shape = DemolishedWallShape(p1, p2, line.thickness)

                self.set_patch_collection(wall_shape)
    def add_increment_walls(self, increment_walls):
        for w in increment_walls:
            p1 = (float(w["line"][0][0]), float(w["line"][0][1]))
            p2 = (float(w["line"][1][0]), float(w["line"][1][1]))
            wall_shape = IncrementWallShape(p1, p2, w["thickness"])
            self.set_patch_collection(wall_shape)

    def add_walking_path(self, points):
        """
        points: point list of list [[], []]
        """
        patches = []
        for idx in range(0, len(points)):
            for idx1 in range(1, len(points[idx])):
                # pt1, pt2 = points[idx - 1], points[idx]
                pt1, pt2 = points[idx][idx1 - 1], points[idx][idx1]
                line = settings.Line2D(pt1, pt2)
                dx, dy = line.direction.unit * pt1.distance(pt2)
                dx, dy = float(dx), float(dy)
                arrow = mpatches.Arrow(float(pt1.x), float(pt1.y),
                                       dx, dy, 200)
                patches.append(arrow)
        patch_collection = PatchCollection(patches, **{"facecolor": "red", "alpha": 1.})
        self.ax.add_collection(patch_collection)

    def add_furniture(self, furnitures):
        patches = []
        def label(xy, text):
            y = xy[1] - 0.15  # shift y-value for label so that it's below the artist
            self.ax.text(xy[0], y, text, ha="center", family='sans-serif', size=6, color="black")
            # plt.text(xy[0], y, text, ha="center", family='sans-serif', size=14, color="red")

        for idx, f in enumerate(furnitures):
            f_patches = f.get_patches()
            patches.extend(f_patches)
            label(f.get_centroid(), f.name)
            # label(f_patches[0].xy, str(idx + 1))
        patch_collection = PatchCollection(patches, **{"facecolor": "red", "edgecolor": "black", "alpha": 0.5})
        self.ax.add_collection(patch_collection)

    def add_title(self, title):
        title = str(title)
        # self.ax.set_title(title)
        self.ax.set_xlabel(title)

    def add_text(self, text):
        xmin, xmax, ymin, ymax = self.ax.axis()
        self.ax.text(xmin, ymin, text, wrap=True, color="red")

    def set_patch_collection(self, shape):
        patch_collection = PatchCollection(
            [shape.path_patch],
            **shape.get_config())
        self.ax.add_collection(patch_collection)


def show_MultiLineString(mlines):
    SIZE = shapely_figures.SIZE
    fig = plt.figure(1, figsize=SIZE, dpi=90)
    ax = fig.add_subplot()
    # ax = fig.add_subplot(121)
    for line in mlines:
        shapely_figures.plot_coords(ax, line, zorder=1)
        color = shapely_figures.color_issimple(line)
        shapely_figures.plot_line(ax, line, color=color, alpha=0.7, zorder=2)
    shapely_figures.plot_bounds(ax, mlines)
    plt.show()


if __name__ == "__main__":
    frame_json = r"D:\ke\data\frame_json\11000011411349.json"
    with open(frame_json, 'r') as f:
        ke_json = json.load(f)

    tmp = 0
