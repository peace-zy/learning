
import frame_remould.settings as settings
import frame_remould.utils.geo_utils as geo_utils


def extract_all_max_rec(polygon):
    rec_boundary_list = []
    if polygon.vertices.__len__() == 4:
        rec_boundary_list.append(polygon)
    else:
        concave_list, convex_list = concave_or_convex(polygon)
        a_list = []
        line_list = get_poly_line_list(polygon)
        horizontal_line = [l for l in line_list if geo_utils.get_normal_dir(l).y < 0]
        new_horizontal_line = [l for l in line_list if geo_utils.get_normal_dir(l).y > 0]
        if len(horizontal_line) < len(new_horizontal_line):
            horizontal_line = new_horizontal_line

        for l in horizontal_line:
            vex = l.p1
            s, p_list = largest_trangle_final(l, polygon, line_list, concave_list)
            a_list.append((s, p_list))

        tmp = 0
    return rec_boundary_list


def get_poly_line_list(polygon):
    line_list = []
    for idx, v in enumerate(polygon.vertices):
        if idx == len(polygon.vertices) - 1:
            p1, p2 = v, polygon.vertices[0]
        else:
            p1, p2 = v, polygon.vertices[idx + 1]
        line_list.append(settings.Line2D(p1, p2))
    return line_list


def concave_or_convex(polygon):
    """concave表示凹点，convex表示凸点
    返回两个列表"""
    concave_list = []
    convex_list = []
    line_list = []
    for idx, v in enumerate(polygon.vertices):
        if idx == len(polygon.vertices) - 1:
            p1, p2 = v, polygon.vertices[0]
        else:
            p1, p2 = v, polygon.vertices[idx + 1]
        line_list.append(settings.Line2D(p1, p2))

    for v in polygon.vertices:
        v_list = get_adj_seg(v, line_list)
        a = another_p(v_list[0], v)
        if a == v_list[0].p1:
            la = v_list[0]
            lb = v_list[1]
        else:
            la = v_list[1]
            lb = v_list[0]
        tag = concave_or_convex_point(la, lb)
        if tag == 1:
            # 凹点
            concave_list.append(v)
        else:  # tag==-1:
            # 凸出点
            convex_list.append(v)

    return concave_list, convex_list


def get_adj_seg(ver, line_list):
    """返回同一点的相邻边"""
    tp_adj_seg_list = []
    for line in line_list:
        seg = settings.Segment2D(line.p1, line.p2)
        if seg.contains(ver):
            tp_adj_seg_list.append(line)
    return tp_adj_seg_list


def another_p(line, point):
    """返回一条边的另一个顶点"""
    if line.p1 == point:
        return line.p2
    else:
        return line.p1


def concave_or_convex_point(la, lb):
    a = ((la.p2.x - la.p1.x), (la.p2.y - la.p1.y))
    b = ((lb.p2.x - lb.p1.x), (lb.p2.y - lb.p1.y))
    direc = (a[0] * b[1] - b[0] * a[1])
    if direc != 0:
        return direc / abs(direc)
    else:
        return 0


def largest_trangle_final(ho_line, polygon, line_list, concave_list=[]):
    horizontal_line_list = [x for x in line_list if geo_utils.get_normal_dir(x).y != 0]
    vertical_list = [x for x in line_list if geo_utils.get_normal_dir(x).x != 0]
    an_list = []
    f_ip = []
    ip = [ho_line.p1, ho_line.p2]

    for p in range(2):
        a, b = ip[p], ip[1 - p]
        ab = settings.Line2D(a, b)
        while b in concave_list:
            b_l = ray_ext(ab, vertical_list)
            b = b_l[1][1]
            t_dir_l = settings.Line2D(b, another_p(b_l[1][2], b))

            if t_dir_l.direction == geo_utils.get_normal_dir(ho_line):
                ab = settings.Line2D(a, b)
                break
            ab = settings.Line2D(a, b)
        f_ip.append(b)
    a, b = f_ip[0], f_ip[1]
    p1, p2 = geo_utils.get_p1_p2_from_normal(geo_utils.get_normal_dir(ho_line), a, b)
    l = settings.Line2D(p1, p2)
    s, p_list = line_ext_max_final(l, horizontal_line_list, polygon, concave_list)
    an_list.append((s, p_list))
    an_list.sort(key=lambda x: x[0], reverse=True)
    return an_list[0][0], an_list[0][1]


def ray_ext(a, line_list):
    vecter = a.direction
    a2 = a.p2
    ray_line = settings.Ray2D(a2, a2 + vecter * 100000000)
    ext_list = []
    for i in line_list:
        seg = settings.Segment2D(i.p1, i.p2)
        if ray_line.intersection(seg) != []:
            ext_list.append(
                (i.distance(a2), ray_line.intersection(seg)[0], i))
            # 返回元组有三项，距离，交点，交点线
    if ext_list == []:
        raise Exception('传入射线和列表有问题', a.p1, a.p2, vecter)
    else:
        ext_list.sort(key=lambda x: x[0])
    if ext_list[0][0] != 0:
        raise Exception('射线起始点不在凹凸点上，这个图形有问题', a.p1, a.p2)
    return ext_list


def line_ext_max_final(l, praline, boundary, concave_list):
    inside_list = []
    a_dict = {}
    global vector, np_poi
    """同侧化praline里面的规避边"""
    # 水平线
    vector = geo_utils.get_normal_dir(l)[1]
    np_poi = l.p1.y
    x_rang = cover_range(l)
    for pl in praline:
        ai = pl.p1.y - l.p1.y
        aai = abs(ai)
        if aai == 0:
            continue
        if ai / aai == geo_utils.get_normal_dir(l)[1] and is_staggerd(pl, x_rang):
            if a_dict.get(aai) == None:
                a_dict[aai] = []
            a_dict[aai].append(pl)

    inside_list = [(x1, a_dict[x1]) for x1 in a_dict.keys()]
    inside_list.sort(key=lambda x: x[0])

    # d_list全局答案存放
    global d_list
    d_list = []


    def max_rec(tl, inside_list):
        in_list = inside_list.copy()
        try:
            il = in_list[0]
        except:
            return
            # raise Exception('矩形曼延处，曼延线没有平行且坐标区域重合的线，区域不闭合', tl.p1, tl.p2)
        tl_range = cover_range(tl)
        true_p = np_poi + vector * il[0]
        in_list.__delitem__(0)
        af, ap = avoid_func(tl, il[1])
        if af[1] or af[2] or af[3] or af[4]:
            s = il[0] * tl.p1.distance(tl.p2)
            d_list.append((s, cover_range(tl), np_poi, true_p))
        else:
            max_rec(tl, in_list)
        """更新下波数据,tl要更新，如果要进入递归，则要转换相应参数并且结束这个for循环"""
        if not af[1]:
            # m的情况
            cp = [tl_range[0], tl_range[1]]
            m_range = ap[2]
            for mr in m_range:
                cp.append(mr[0])
                cp.append(mr[1])
            if af[2]:
                cp.append(ap[0])
                cp.sort()
                cp.__delitem__(0)
            if af[3]:
                cp.append(ap[1])
                cp.sort()
                cp.__delitem__(-1)
            cp.sort()
            l = len(cp)
            if l % 2 == 1:
                raise Exception('位于矩形曼延处代码，检查是否有凹陷的单点线，\
                                凹陷处应该为墙而不是单线段', a.p1, a.p2)

            l = int(l / 2)
            for i in range(l):
                tl = cut_line(cp[2 * i], cp[2 * i + 1], tl)
                max_rec(tl, in_list)

    max_rec(l, inside_list)

    d_list.sort(key=lambda x: x[0], reverse=True)
    max_s = d_list[0][0]
    x_rang = d_list[0][1]
    y_rang = (d_list[0][2], d_list[0][3])
    a = settings.Point2D(x_rang[0], y_rang[0])
    c = settings.Point2D(x_rang[1], y_rang[1])

    p_list = [a, c]

    return max_s, p_list


def cover_range(seg):
    if seg.p1.x == seg.p2.x:
        if seg.p1.y > seg.p2.y:
            return (seg.p2.y, seg.p1.y)
        else:
            return (seg.p1.y, seg.p2.y)
    else:
        if seg.p1.x > seg.p2.x:
            return (seg.p2.x, seg.p1.x)
        else:
            return (seg.p1.x, seg.p2.x)


def is_staggerd(seg, area_range, need_tag=0):
    """  测试边， 测试范围,测试范围自己先提前调用cover——range得到
    暂时返回值只用到0,1，但是用标记表明了各种相交情况，当需要时就可以更改返回值使用
    需要标记时第三个参数设置1，返回标志"""
    p_l = cover_range(seg)
    ar = [area_range[0], area_range[1]]
    ar.sort()
    if p_l[1] <= ar[0] or p_l[0] >= ar[1]:
        # waimian
        tag = 'n'
        re = 0
    elif p_l[0] <= ar[0] and p_l[1] > ar[0] and p_l[1] < ar[1]:
        tag = 'l'
        re = 1
    elif p_l[0] > ar[0] and p_l[1] < ar[1]:
        tag = 'm'
        re = 1
    elif p_l[0] > ar[0] and p_l[0] < ar[1] and p_l[1] > ar[1]:
        tag = 'r'
        re = 1
    else:
        tag = 'a'  # all
        re = 1
    if need_tag:
        return tag
    else:
        return re


def avoid_func(seg, avo_list):
    """ 一条边与列表中所有边，在某个坐标方向上，坐标区域的重合关系"""
    n, a, l, r, m = 0, 0, 0, 0, 0
    s_range = cover_range(seg)
    lp, rp = None, None
    m_range = []

    for i in avo_list:
        ran = cover_range(i)
        if ran[0] <= s_range[0] and s_range[0] < ran[1] and ran[1] < s_range[1]:
            l += 1
            lp = ran[1]
        elif ran[0] > s_range[0] and ran[0] < s_range[1] and ran[1] >= s_range[
            1]:
            r += 1
            rp = ran[0]
        elif s_range[0] < ran[0] and s_range[1] > ran[1]:
            m += 1
            m_range.append(ran)
        elif s_range[0] >= ran[0] and s_range[1] <= ran[1]:
            a += 1
        else:
            n += 1
    return [n, a, l, r, m], [lp, rp, m_range]


def cut_line(a, b, l):
    """ 一条线，沿线方向上两个位置顶点切割"""
    if l.p1.y == l.p2.y:
        # 水平线
        y = l.p1.y
        return settings.Line2D(settings.Point2D(a, y), settings.Point2D(b, y))

    else:
        x = l.p1.x
        return settings.Line2D(settings.Point2D(x, a), settings.Point2D(x, b))