# coding=utf-8
import numpy as np
import copy

import frame_remould.settings as settings
import frame_remould.utils.geo_utils as geo_utils
from frame_remould.settings import RULE_PARAM


def extract_all_max_rec(polygon):
    """
    region for debug
    """
    rectangles = []

    lines = get_poly_line_list(polygon)

    for idx, l1 in enumerate(lines):
        if idx == len(lines) - 1:
            l2 = lines[0]
        else:
            l2 = lines[idx + 1]

        # 如果不垂直，更新l2使其和l1垂直
        if not geo_utils.is_perpendicular(l1, l2):
            p1 = l1.p2
            p2 = p1 + geo_utils.get_normal_dir(l1) * 100
            l2 = settings.Line2D(p1, p2)

        rec = get_max_rec_from_two_lines(l1, l2, polygon, lines=lines)
        rectangles.append(rec)

    rectangles = [rec for rec in rectangles if rec is not None]
    rectangles.sort(key=lambda x: np.fabs(float(x.area)), reverse=True)
    new_rects = []
    for rec in rectangles:
        if rec not in new_rects:
            new_rects.append(rec)
    if len(new_rects) == 0:
        raise RuntimeError("NO max rectangle in region")
    return new_rects


def get_poly_line_list(polygon):
    line_list = []
    for idx, v in enumerate(polygon.vertices):
        if idx == len(polygon.vertices) - 1:
            p1, p2 = v, polygon.vertices[0]
        else:
            p1, p2 = v, polygon.vertices[idx + 1]
        line_list.append(settings.Line2D(p1, p2))
    return line_list


def get_max_rec_from_two_lines(l1, l2, polygon, lines=None):
    if not if_inner_corner(l1, l2):
        return None
    if l1.p1.distance(l1.p2) < RULE_PARAM["inner_wall_len_min"]:
        return None
    if l2.p1.distance(l2.p2) < RULE_PARAM["inner_wall_len_min"]:
        return None
    l12 = [l1, l2]
    # l1和l2会组成两个矩形，分别以l1不变和l2不变
    recs = [None, None]
    rec_areas = [0, 0]
    for idx, l in enumerate(l12):
        l = extend_line(l, lines)
        nearest_l = get_nearst_l_opposite_line(l, lines)
        # settings.debug.save_img(r'D:\\', "0", walking_pts=[[nearest_l.p1, nearest_l.p2]])
        if nearest_l is None:
            continue
        dis = np.min([l.distance(nearest_l.p1),
                     l.distance(nearest_l.p2)])
        if dis == 0:
            continue

        p3 = l.p2 + geo_utils.get_normal_dir(l) * dis
        p4 = l.p1 + geo_utils.get_normal_dir(l) * dis
        recs[idx] = settings.Polygon(l.p1, l.p2, p3, p4)
        rec_areas[idx] = np.fabs(float(recs[idx].area))
    max_area_idx = np.argmax(rec_areas)
    if rec_areas[max_area_idx] == 0:
        return None
    else:
        return recs[max_area_idx]


def get_nearst_l_opposite_line(line, lines):
    # TODO: 斜线会出现bug
    min_dis = np.inf
    nearst_id = None
    # 先求出l所在的线段，不一定是p1->p2
    for idx, line1 in enumerate(lines):
        # 不和line相连接或相同
        if line1.p1 == line.p1:
            continue
        if line1.p1 == line.p2:
            continue
        if line1.p2 == line.p1:
            continue
        if line1.p2 == line.p2:
            continue

        # 必须在line的法线方向侧
        if not if_point_on_line_cw(line1.p1, line):
            continue
        # 两个直线投影必须相交
        if not if_projection_intersection(line, line1):
            continue

        # dis = line1.distance(line.p1)
        dis = np.min([line.distance(line1.p1), line.distance(line1.p2)])

        if dis < min_dis:
            min_dis = dis
            nearst_id = idx
    if nearst_id is not None:
        return lines[nearst_id]
    else:
        return None


def if_point_on_line_cw(point, line):
    # 判断点是否在直线的顺时针侧
    poly = settings.Polygon(line.p1, line.p2, point)
    if isinstance(poly, settings.Segment2D):
        return False
    if poly.area < 0:
        return True
    else:
        return False


def if_projection_intersection(line1, line2):
    seg1 = settings.Segment2D(line1.p1, line1.p2)
    p1 = line1.projection(line2.p1)
    p2 = line1.projection(line2.p2)
    seg2 = settings.Segment2D(p1, p2)

    intersect = seg1.intersection(seg2)
    if len(intersect) == 0:
        return False
    if isinstance(intersect[0], settings.Segment2D):
        return True
    else:
        return False


def extend_line(line, lines):
    ray = settings.Ray2D(line.p1, line.p2)
    for idx, line1 in enumerate(lines):
        # 不和line相连接或相同
        if line1.p1 == line.p1:
            continue
        if line1.p1 == line.p2:
            continue
        if line1.p2 == line.p1:
            continue
        if line1.p2 == line.p2:
            continue
        seg = settings.Segment2D(line1.p1, line1.p2)
        intersect = ray.intersection(seg)
        if len(intersect) == 0:
            continue
        if isinstance(intersect[0], settings.Segment2D):
            continue
        if intersect[0] == seg.p1 or intersect[0] == seg.p2:
            continue
        if isinstance(intersect[0], settings.Point2D):
            p2 = intersect[0]
            return settings.Line2D(line.p1, p2)

    return line


def if_inner_corner(l1, l2):
    if l1.p2 != l2.p1:
        assert False, "直线不相连"
    poly = settings.Polygon(l1.p1, l1.p2, l2.p2)
    if isinstance(poly, settings.Segment2D):
        assert False, "两个直线共线"
    if poly.area < 0:
        return True
    else:
        return False
