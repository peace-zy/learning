# coding=utf-8

def get_connect_area4area_id(house, area_id):
    tmp = 0

