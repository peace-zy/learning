# coding=utf-8
from shapely.geometry import MultiLineString
import numpy as np
import copy

import frame_remould.settings as settings
from frame_remould.settings import RULE_PARAM

INNER_POLY_MIN_LEN = 100


def get_normal_dir(line2d):
    """
    得到线段的法线方向，即功能区内部方向
    由于frime功能区外轮廓是顺时针的，因此线段方向顺时针转90度，为法线方向。
    """
    return line2d.direction.unit.rotate(settings.pi / 2 * 3)


def get_p1_p2_from_normal(normal, p1, p2):
    l = settings.Line2D(p1, p2)
    a = get_normal_dir(l)
    b = normal
    o = settings.Point2D(0, 0)
    if is_same_direction(settings.Line2D(o, a), settings.Line2D(o, b)):
        return p1, p2
    elif is_opposite_direction(settings.Line2D(o, a), settings.Line2D(o, b)):
        return p2, p1
    else:
        assert True, "法线设置有误"


def get_MultiLineString(id_walls):
    """
    id_walls: id-wall 的字典
    return: MultiLineString集合; 对应wall id列表
    """
    coords, wall_id_list = [], []
    for k, v in id_walls.items():
        p1 = (v.p1.x, v.p1.y)
        p2 = (v.p2.x, v.p2.y)
        coords.append((p1, p2))
        wall_id_list.append(k)
    mlines = MultiLineString(coords)
    return mlines, wall_id_list


def get_points4sympy_intersections(intersections):
    intsct_pts = [p for p in intersections if isinstance(p, settings.Point2D)]
    return intsct_pts


def get_max_rectangle_along_wall(wall_id, region):
    """
    以一个墙为边，得到其向房间内的最大矩形投影
    返回长方形的四个点
    """
    wall = region.id_walls.get(wall_id)
    wall_norm = get_normal_dir(wall.line2d)
    wall_dir = wall.line2d.direction.unit
    # 收缩line 防止和墙搭边
    p1 = wall.line2d.p1 + wall_dir * 19
    p2 = wall.line2d.p2 - wall_dir * 19
    ray1 = settings.Ray2D(p1, p1 + wall_norm * 9)
    ray2 = settings.Ray2D(p2, p2 + wall_norm * 9)

    inter_pts = []
    for wid, line in region.id_walls.items():
        if wid == wall_id:
            continue
        if is_parallel(ray1, line.segment2d):
            continue
        intersections1 = line.segment2d.intersection(ray1)
        intersections2 = line.segment2d.intersection(ray2)
        intersections1 = get_points4sympy_intersections(intersections1)
        intersections2 = get_points4sympy_intersections(intersections2)
        for inter in intersections1:
            inter_pts.append((inter, p1))
        for inter in intersections2:
            inter_pts.append((inter, p2))
    # 找到wall_id距离最小的点
    dis = 9999999
    for inter, p in inter_pts:
        dis0 = inter.distance(p)
        if dis0 < dis:
            dis = dis0
            inter_pt12 = inter
            p12 = p
    pts = []
    if p12 == p1:
        inter_pt12p = p2 + wall_norm * dis
        pts.extend([p12, inter_pt12, inter_pt12p, p2])
    else:
        inter_pt12p = p1 + wall_norm * dis
        pts.extend([p12, inter_pt12, inter_pt12p, p1])
    return pts


def get_end_pt_and_id(wall, ccw):
    if wall.line2d is None:
        return None, None
    if ccw is True:
        pt = wall.line2d.p1
    else:
        pt = wall.line2d.p2
    if pt.distance(wall.p1) < pt.distance(wall.p2):
        pt_id = wall.p1_id
    else:
        pt_id = wall.p2_id
    return pt, pt_id


def get_next_walking_wall_id(wall_id, region, ccw):
    """
    沿着墙走，得到下一个墙
    """

    def get_nearst_angle_wall(wall_id, next_walls, region, ccw):
        id_walls = region.id_walls
        start_wall = id_walls[wall_id]
        pend, pend_id = get_end_pt_and_id(start_wall, ccw)
        p12_ids = [start_wall.p1_id, start_wall.p2_id]
        ray_p2id = [pid for pid in p12_ids if pend_id != pid][0]

        start_ray = settings.Ray2D(region.id_pts[pend_id].point2d, region.id_pts[ray_p2id].point2d)
        next_rays = []
        for wid in next_walls:
            w = region.id_walls[wid]
            p12_ids = [w.p1_id, w.p2_id]
            ray_p2id = [pid for pid in p12_ids if pend_id != pid][0]
            ray = settings.Ray2D(region.id_pts[pend_id].point2d, region.id_pts[ray_p2id].point2d)
            next_rays.append(ray)
        min_ray_idx = -1
        min_ray_ang = 360
        for idx, ray in enumerate(next_rays):
            ang = ray.angle_between(start_ray)
            if ang < min_ray_ang:
                min_ray_ang = ang
                min_ray_idx = idx
        return next_walls[min_ray_idx]

    id_walls = region.id_walls
    start_wall = id_walls[wall_id]
    pend, pend_id = get_end_pt_and_id(start_wall, ccw)
    if pend is None:
        return None
    next_walls = region.id_pts[pend_id].lines

    # 去除不在本区域的墙
    next_walls = [l for l in next_walls if l in list(region.id_walls.keys())]
    # 去除来源所在墙体
    next_walls = [l for l in next_walls if l != wall_id]

    next_wall_id = None
    if len(next_walls) == 1:
        next_wall_id = next_walls[0]
    else:
        next_walls = [l for l in next_walls if id_walls[l].region_inner]
        # next_walls = [l for l in next_walls if id_walls[l].line2d is None]
        if len(next_walls) == 0:
            return next_wall_id
        elif len(next_walls) == 1:
            next_wall_id = next_walls[0]
        else:
            next_wall_id = get_nearst_angle_wall(wall_id, next_walls, region, ccw)

    return next_wall_id


def get_collineation_connected_wall(wall_id, region, ccw):
    id_walls = region.id_walls
    start_wall = id_walls[wall_id]
    pend, pend_id = get_end_pt_and_id(start_wall, ccw)
    if pend is None:
        assert False, "区域内墙先配置line2d"

    end_list = [pend_id]
    wallids = [wall_id]

    while True:
        next_wall_id = get_next_walking_wall_id(wallids[-1], region, ccw)
        if next_wall_id is None:
            break

        next_wall = id_walls.get(next_wall_id)
        pre_wall = id_walls.get(wallids[-1])
        if is_parallel_wall(pre_wall, next_wall):
            wallids.append(next_wall_id)
        else:
            break
    return wallids


def get_wall_items_along_wall(wall_id, id_wall_items):
    """
    得到在一个墙上所有门窗
    """
    wall_items = []
    for item_id, wall_item in id_wall_items.items():
        if wall_item.wall_id == wall_id:
            wall_items.append(item_id)
    return wall_items


def is_convex_pt(pt_id, region):
    """
    判断点是否为凸点（相对室内）
    """
    wall_ids = region.id_pts[pt_id].lines
    # 去除不在本区域的墙
    wall_ids = [l for l in wall_ids if l in list(region.id_contour_walls.keys())]

    # assert len(wall_ids) == 2

    # 判断第一个和第二个墙
    for w in wall_ids:
        wall = region.id_walls[w]
        pend, pend_id = get_end_pt_and_id(wall, ccw=False)
        if pend_id == pt_id:
            w_id1 = w
            w_id2 = [wid for wid in wall_ids if wid != w][0]
            continue
    # 判断w0旋转到w1的角度
    wray1 = settings.Ray2D(region.id_walls[w_id1].line2d.p1, region.id_walls[w_id1].line2d.p2)
    wray2 = settings.Ray2D(region.id_walls[w_id2].line2d.p1, region.id_walls[w_id2].line2d.p2)

    angle = wray1.closing_angle(wray2)
    if angle < 0:
        return True
    else:
        return False


def is_parallel_wall(fp_wall1, fp_wall2):
    """
    判断两个墙（或者门窗）是否平行
    wall 肯定有segment2d属性
    """
    angle = np.rad2deg(float(fp_wall1.segment2d.smallest_angle_between(fp_wall2.segment2d)))
    # TODO: 验证是否需要fabs
    if angle < RULE_PARAM["parallel_angle_max"]:
        return True
    else:
        return False


def is_parallel(l1, l2):
    line1 = settings.Line2D(l1.p1, l1.p2)
    line2 = settings.Line2D(l2.p1, l2.p2)
    angle = np.rad2deg(float(line1.angle_between(line2)))
    if angle >= 180:
        angle = angle - 180
    # TODO: 验证是否需要fabs
    if angle < RULE_PARAM["parallel_angle_max"]:
        return True
    else:
        return False


def is_perpendicular_wall(wall1, wall2):
    angle = np.rad2deg(float(wall1.segment2d.smallest_angle_between(wall2.segment2d)))
    if np.fabs(angle - 90) < RULE_PARAM["parallel_angle_max"]:
        return True
    else:
        return False


def is_perpendicular(l1, l2):
    angle = np.rad2deg(float(l1.smallest_angle_between(l2)))
    if np.fabs(angle - 90) < RULE_PARAM["parallel_angle_max"]:
        return True
    else:
        return False


def is_same_direction(l1, l2):
    """
    判断两个射线方向是否相同
    可以是Line2D, 但是按着p1 -> p2 顺序
    """
    r1 = settings.Ray2D(l1.p1, l1.p2)
    r2 = settings.Ray2D(l2.p1, l2.p2)

    ang = np.rad2deg(float(r1.closing_angle(r2)))

    if np.fabs(ang) < RULE_PARAM["parallel_angle_max"]:
        return True
    else:
        return False


def is_opposite_direction(l1, l2):
    """
    判断两个射线方向是否相同
    可以是Line2D, 但是按着p1 -> p2 顺序
    """
    r1 = settings.Ray2D(l1.p1, l1.p2)
    r2 = settings.Ray2D(l2.p1, l2.p2)

    ang = np.rad2deg(float(r1.closing_angle(r2))) - 180

    if np.fabs(ang) >= 360:
        ang = np.fabs(ang) - 360

    if np.fabs(ang) < RULE_PARAM["parallel_angle_max"]:
        return True
    else:
        return False


def furniture_correction(fur, region):
    # side1, side2 = fur.get_side_line()
    # sideseg1 = settings.Segment2D(side1.p1, side1.p2)
    # sideseg2 = settings.Segment2D(side2.p1, side2.p2)

    # TODO: 考虑offset
    for wid, w in region.id_walls.items():
        side1, side2 = fur.get_side_line()
        sideseg1 = settings.Segment2D(side1.p1, side1.p2)
        sideseg2 = settings.Segment2D(side2.p1, side2.p2)
        if wid == fur.wall_id:
            p1, p2 = fur.baseline.p1, fur.baseline.p2
            # TODO: offset 方法需要验证
            p1 = p1 + fur.normal * (0.5 * w.thickness - np.fabs(w._offset))
            p2 = p2 + fur.normal * (0.5 * w.thickness - np.fabs(w._offset))
            new_base = settings.Line2D(p1, p2)
            fur.set_baseline(new_base)
        # 如果不和家具边线平行，不会继续
        if not is_parallel(w.segment2d, side1):
            continue

        if len(w.segment2d.intersection(sideseg1)) > 0:
            mid = settings.Segment2D(fur.baseline.p1, fur.baseline.p2).midpoint
            dir = settings.Line2D(side1.p1, mid).direction.unit
            p1, p2 = fur.baseline.p1, fur.baseline.p2
            p1 = p1 + dir * (0.5 * w.thickness - np.fabs(w._offset))
            new_base = settings.Line2D(p1, p2)
            fur.set_baseline(new_base)

        if len(w.segment2d.intersection(sideseg2)) > 0:
            mid = settings.Segment2D(fur.baseline.p1, fur.baseline.p2).midpoint
            dir = settings.Line2D(side2.p1, mid).direction.unit
            p1, p2 = fur.baseline.p1, fur.baseline.p2
            p2 = p2 + dir * (0.5 * w.thickness - np.fabs(w._offset))
            new_base = settings.Line2D(p1, p2)
            fur.set_baseline(new_base)


def get_line_x_y_dir(
        line,
        xaxis=settings.Line2D(settings.Point2D(0, 0), settings.Point2D(1, 0))):
    """
    给定x轴坐标系，求直线是偏向x还是y轴
    """
    yaxis = settings.Line2D(
        settings.Point2D(0, 0),
        get_normal_dir(xaxis) * (-1)
    )
    p1x, p2x = xaxis.projection(line.p1), xaxis.projection(line.p2)
    p1y, p2y = yaxis.projection(line.p1), yaxis.projection(line.p2)
    seg_x = settings.Segment2D(p1x, p2x)
    seg_y = settings.Segment2D(p1y, p2y)

    len_x = 0 if isinstance(seg_x, settings.Point2D) else seg_x.length
    len_y = 0 if isinstance(seg_y, settings.Point2D) else seg_y.length

    if len_x > len_y:
        return xaxis
    else:
        return yaxis


def get_axis4rectangle(rectangle):
    xaxis = settings.Line2D(rectangle.vertices[0], rectangle.vertices[1])
    yaxis = settings.Line2D(rectangle.vertices[1], rectangle.vertices[2])
    return xaxis, yaxis


def get_another_pt(line, pt):
    for pt0 in line.points:
        if pt0 != pt:
            return pt0


def correct_inner_polygon(inner_polygon):
    """
    校正功能区内边: 1. 一个极短边； 2. 连续两个极短边
    """
    start_idx = 0
    # sides的方向不固定，需要转换lines
    lines = []
    for idx, v in enumerate(inner_polygon.vertices):
        p1 = v
        if idx != len(inner_polygon.vertices) - 1:
            p2 = inner_polygon.vertices[idx + 1]
        else:
            p2 = inner_polygon.vertices[0]
        line = settings.Line2D(p1, p2)
        lines.append(line)

    # 保证第一个边长度足够
    for idx, s in enumerate(inner_polygon.sides):
        if s.length > INNER_POLY_MIN_LEN:
            start_idx = idx
            break
    idx_list = []

    for idx in range(len(inner_polygon.sides)):
        idx2 = start_idx + idx
        if idx2 < len(inner_polygon.sides):
            idx_list.append(idx2)
        else:
            idx_list.append(idx2 - len(inner_polygon.sides))

    # 得到所有长度不足的墙组，连续的算一组
    sides = inner_polygon.sides
    short_wall_list = []
    all_short_wall = []
    for idxidx, idx in enumerate(idx_list):
        # 如果短轮廓的两侧内轮廓方向相反，且两侧长度足够，则是内墙,不需要校正
        if idxidx == 0:
            previous_idxidx = len(idx_list) - 1
        else:
            previous_idxidx = idxidx - 1
        if idxidx == len(idx_list) - 1:
            next_idxidx = 0
        else:
            next_idxidx = idxidx + 1
        previous_idx = idx_list[previous_idxidx]
        next_idx = idx_list[next_idxidx]
        if sides[previous_idx].length > INNER_POLY_MIN_LEN and \
            sides[next_idx].length > INNER_POLY_MIN_LEN and \
            is_opposite_direction(lines[previous_idx], lines[next_idx]):
            continue

        if sides[idx].length > INNER_POLY_MIN_LEN:
            if len(short_wall_list) != 0:
                sw_list = copy.deepcopy(short_wall_list)
                all_short_wall.append(sw_list)
                short_wall_list = []
        else:
            short_wall_list.append(idx)

    if len(short_wall_list) != 0:
        sw_list = copy.deepcopy(short_wall_list)
        all_short_wall.append(sw_list)
        short_wall_list = []

    # 校正多边形
    for short_walls in all_short_wall:
        short_wall_list.extend(short_walls)

    normal_w_list = []
    for idx in idx_list:
        if idx in short_wall_list:
            continue
        normal_w_list.append(idx)

    def correct_parallel_sides(s1, s2):
        l1 = settings.Line2D(s1.p1, s1.p2)
        s2p1 = l1.projection(s2.p1)
        s2p2 = l1.projection(s2.p2)
        seg1 = settings.Segment2D(s1.p1, s1.p2)
        if seg1.distance(s2p1) < seg1.distance(s2p2):
            farthest = s2p2
        else:
            farthest = s2p1

        if farthest.distance(s1.p1) < farthest.distance(s1.p2):
            nearst = s1.p1
        else:
            nearst = s1.p2
        return settings.Line2D(nearst, farthest)

    def correct_non_paralled_sides(s1, s2):
        l1 = settings.Line2D(s1.p1, s1.p2)
        l2 = settings.Line2D(s2.p1, s2.p2)
        inter = l1.intersection(l2)[0]
        if inter.distance(s1.p1) < inter.distance(s1.p2):
            farthest = s1.p2
        else:
            farthest = s1.p1
        l1p = settings.Line2D(farthest, inter)
        if inter.distance(s2.p1) < inter.distance(s2.p2):
            farthest = s2.p2
        else:
            farthest = s2.p1
        l2p = settings.Line2D(inter, farthest)
        return l1p, l2p

    for idx0, idx in enumerate(normal_w_list):
        if idx0 == len(normal_w_list) - 1:
            next_w_idx = normal_w_list[0]
        else:
            next_w_idx = normal_w_list[idx0 + 1]

        if is_parallel(sides[idx], sides[next_w_idx]):
            sides[next_w_idx] = correct_parallel_sides(
                sides[idx],
                sides[next_w_idx]
            )
        else:
            sides[idx], sides[next_w_idx] = correct_non_paralled_sides(
                sides[idx],
                sides[next_w_idx]
            )
    pts = []
    for idx0, idx in enumerate(normal_w_list):
        pts.append(sides[idx].p2)
    inner_polygon = settings.Polygon(*pts)
    return inner_polygon


def get_nearest_pt_ray2inner(ray, inner_region):
    inter_pt = None
    for l in inner_region.inner_lines:
        seg = settings.Segment2D(l.p1, l.p2)
        intersc = seg.intersection(ray)
        if len(intersc) == 0:
            continue
        if type(intersc[0]) != settings.Point2D:
            continue
        if intersc[0] == ray.p1:
            continue
        inter_pt = intersc[0]
    if inter_pt is None:
        return None
    return ray.p1.distance(inter_pt)
