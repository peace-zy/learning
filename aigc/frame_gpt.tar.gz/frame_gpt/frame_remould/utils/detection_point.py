# coding=utf-8

from frame_remould.settings import FRAME_KEY


def get_sub_room_id(floorplan):
    masters = floorplan.get_master_bedrooms()
    tmp = 0

def get_common_door(floorplan, region_id0, region_id1):
    doors0 = floorplan.id_regions[region_id0].get_doors()
    doors1 = floorplan.id_regions[region_id1].get_doors()
    common_door = list(set(doors0).intersection(set(doors1)))[0]
    return common_door


def get_connected_parlour_door(floorplan, area_id):
    if area_id not in floorplan.id_regions:
        return None
    region_ids = floorplan.id_regions[area_id].connect_region_id
    for reg_id in region_ids:
        if floorplan.id_regions[reg_id].roomType == FRAME_KEY['regions']['roomType']['other']:
            return get_common_door(floorplan, area_id, reg_id)
        if floorplan.id_regions[reg_id].roomType == FRAME_KEY['regions']['roomType']['parlour']:
            return get_common_door(floorplan, area_id, reg_id)
    return None
