import logging
import os
import pandas as pd
import json
import boto3
import frame_remould.utils.common as common

S3_AK = "223HG43LGIX9W3MWTOCL"
S3_AKS = "tqWXh8kSyxM/QfgF34dMXFJcRrIIGfIIZkVVjSMH"

OUTPUT = "more_frame_json0"
INPUT_TABLE = r"D:\cd_frame.tsv"


def save_frame_table2jsons_v2(table_path):
    table_dir = os.path.dirname(table_path)
    frame_json_dir = os.path.join(table_dir, OUTPUT)
    maybe_mkdir_p(frame_json_dir)

    df = pd.read_csv(table_path, sep="\t", encoding='cp1252')
    for index, row in df.iterrows():
        json_str = row[2]
        frame_id = row[0]
        try:
            frame_id = long(frame_id)
            ke_fp_jsons = json.loads(json_str)
            frame_name = str(frame_id) + ".json"
            frame_json_file = os.path.join(frame_json_dir, frame_name)
            with open(frame_json_file, "w") as f:
                json.dump(ke_fp_jsons, f, indent=4, ensure_ascii=False)
        except:
            print(frame_id)
            print(json_str)


def save_frame_table2jsons(table_path):
    table_dir = os.path.dirname(table_path)
    frame_json_dir = os.path.join(table_dir, OUTPUT)
    maybe_mkdir_p(frame_json_dir)

    df = pd.read_csv(table_path, sep="\t", encoding='cp1252')
    for index, row in df.iterrows():
        json_str = row["json_str"]
        frame_id = row["frame_id"]
        try:
            ke_fp_jsons = json.loads(json_str)
            frame_name = str(frame_id) + ".json"
            frame_json_file = os.path.join(frame_json_dir, frame_name)
            with open(frame_json_file, "w", encoding="utf-8") as f:
                json.dump(ke_fp_jsons, f, indent=4, ensure_ascii=False)
        except:
            print(frame_id)
            print(json_str)


def save_frameid2json(frame_id, path):
    s3_client = boto3.client('s3', region_name="cn-north-1", endpoint_url="http://storage.lianjia.com",
                             aws_access_key_id=S3_AK,
                             aws_secret_access_key=S3_AKS)
    vector_response = s3_client.get_object(Bucket='frame-eval-image', Key=str(frame_id) + '.json')
    vector_str = vector_response['Body'].read()

    frame_json_file = os.path.join(path, str(frame_id) + '.json')
    common.save_json_file(json.loads(vector_str), frame_json_file)
    # with open(frame_json_file, "w", encoding="utf-8") as f:
    # with open(frame_json_file, "w") as f:
    #         json.dump(json.loads(vector_str), f, indent=4, ensure_ascii=False)

def maybe_mkdir_p(path):
    if not os.path.exists(path):
        os.makedirs(path)
    # else:
    #     shutil.rmtree(path)
    #     os.mkdir(path)


def main():
    save_frame_table2jsons_v2(INPUT_TABLE)
    # save_frameid2json(12000003367827, "D:/")
    # save_frame_table2jsons(INPUT_TABLE)


if __name__ == "__main__":
    main()
