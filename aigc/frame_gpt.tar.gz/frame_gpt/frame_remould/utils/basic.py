# coding=utf-8
import collections
import copy
from shapely.geometry import Polygon, Point, MultiPolygon
import numpy as np

import frame_remould.settings as settings
import frame_remould.utils.geo_utils as geo_utils

from frame_remould.settings import RULE_PARAM
from frame_remould.settings import FRAME_KEY
if settings.PLOT is True:
    import frame_remould.utils.vis as vis


class Junction(object):
    def __init__(self):
        self._idx = None
        self._id = None
        self._x = None
        self._y = None
        self._lines = None
        self._point2d = None
        self._is_convex = None

    @property
    def idx(self):
        return self._idx

    @property
    def id(self):
        return self._id

    @property
    def point2d(self):
        return self._point2d

    @property
    def lines(self):
        return self._lines

    @property
    def is_convex(self):
        return self._is_convex

    def init(self, ke_point, idx):
        self._idx = idx
        f_key = settings.FRAME_KEY["points"]  # frame key
        self._x, self._y = ke_point[f_key["x"]], ke_point[f_key["y"]]
        self._id = ke_point[f_key["id"]]
        self._lines = ke_point[f_key["lines"]]
        self._point2d = settings.Point2D(self._x, self._y)

    def set_convex(self, region):
        self._is_convex = geo_utils.is_convex_pt(self._id, region)

    def clear(self):
        self._is_convex = None


class Line(object):
    def __init__(self):
        self._idx = None
        self._id = None
        self._p1 = None
        self._p2 = None
        self._p1_id = None
        self._p2_id = None
        self._p1_idx = None
        self._p2_idx = None
        self._type = None
        self._thickness = None
        # sympy 中segment会根据点排序自动调整方向，不能用作法向计算
        self._line2d = None
        self._segment2d = None

    @property
    def p1_id(self):
        return self._p1_id

    @property
    def p2_id(self):
        return self._p2_id

    @property
    def p1_idx(self):
        return self._p1_idx

    @property
    def p2_idx(self):
        return self._p2_idx

    @property
    def idx(self):
        return self._idx

    @property
    def id(self):
        return self._id

    @property
    def line2d(self):
        return self._line2d

    @property
    def segment2d(self):
        return self._segment2d

    @property
    def type(self):
        return self._type

    @property
    def thickness(self):
        return self._thickness

    @property
    def p1(self):
        return self._p1

    @property
    def p2(self):
        return self._p2

    def reset_points(self, points):
        """
        points: list [p1, p2]
        """
        self._p1 = points[0]
        self._p2 = points[1]
        self._segment2d = settings.Segment2D(self._p1, self._p2)

    def set_line_p1p2(self, inverse=False):
        if not inverse:
            self._line2d = settings.Line2D(self._p1, self._p2)
        else:
            self._line2d = settings.Line2D(self._p2, self._p1)

    def clear_line2d(self):
        self._line2d = None


class Wall(Line):
    def __init__(self):
        super(Wall, self).__init__()
        self._outer = False
        self._offset = 0
        self._region_inner = None
        self.p1_neighbor_walls = []
        self.p2_neighbor_walls = []

    def init(self, ke_line, id_pt_dict, idx):
        self._idx = idx
        f_key = settings.FRAME_KEY["lines"]
        self._id = ke_line[f_key["id"]]
        self._outer = ke_line[f_key["outer"]]
        self._thickness = ke_line.get(f_key["thicknessComputed"])
        if ke_line.get(f_key["offsetComputed"]) is not None:
            self._offset = ke_line.get(f_key["offsetComputed"])
        if self._thickness is None and self._outer:
            self._thickness = 240
        elif self._thickness is None and not self._outer:
            self._thickness = 120

        if ke_line.get(f_key["thickness"]) is not None:
            self._thickness = ke_line[f_key["thickness"]]
        self._type = ke_line[f_key["type"]]
        self._p1_id = ke_line[f_key["points"]][0]
        self._p2_id = ke_line[f_key["points"]][1]
        self._p1 = id_pt_dict[self._p1_id].point2d
        self._p2 = id_pt_dict[self._p2_id].point2d

        self.set_point_idx(id_pt_dict)

    @staticmethod
    def check(wall):
        res = True
        if wall.segment2d.length < 50:
            res = False
        return res

    @property
    def region_inner(self):
        return self._region_inner

    @property
    def outer(self):
        return self._outer

    def set_point_idx(self, id_pt_dict):
        """
        配置节点，实例直线
        """
        self._p1_idx = id_pt_dict[self._p1_id].idx
        self._p2_idx = id_pt_dict[self._p2_id].idx
        pt1 = id_pt_dict[self._p1_id].point2d
        pt2 = id_pt_dict[self._p2_id].point2d
        self._segment2d = settings.Segment2D(pt1, pt2)

    def set_line(self, pt1_idx, pt2_idx, id_pt_dict):
        """
        配置有方向、法线的线段。不改变wall，输入idx必须和原始两个idx相同，顺序可变
        """
        # TODO: 加点是否改变的保护
        # self._p1_idx,  self._p2_idx = pt1_idx, pt2_idx
        # self._p1_id, self._p2_id = id_pt_dict[pt1_idx].id, id_pt_dict[pt2_idx].id
        if hasattr(id_pt_dict[pt1_idx], "point2d"):
            pt1 = id_pt_dict[pt1_idx].point2d
            pt2 = id_pt_dict[pt2_idx].point2d
        else:
            pt1 = id_pt_dict[pt1_idx]
            pt2 = id_pt_dict[pt2_idx]

        self._line2d = settings.Line2D(pt1, pt2)

    def set_line_pt1(self, pt1_idx, id_pt_dict):
        pt1 = id_pt_dict[pt1_idx].point2d
        if pt1_idx == self._p1_id:
            pt2 = id_pt_dict[self._p2_id].point2d
        elif pt1_idx == self._p2_id:
            pt2 = id_pt_dict[self._p1_id].point2d
        else:
            assert False, "CAN NOT FIND pt1_idx"
        self._line2d = settings.Line2D(pt1, pt2)

    def set_region_inner(self):
        """
        设置不是功能区轮廓上的墙
        """
        self._region_inner = True

    def set_neighbor_walls(self, id_walls):
        for wid, wall in id_walls.items():
            if wid == self.id:
                continue
            if self.p1 in wall.segment2d.points:
                self.p1_neighbor_walls.append(wall)
            if self.p2 in wall.segment2d.points:
                self.p2_neighbor_walls.append(wall)

    def get_offset_p1p2(self):
        wp1, wp2 = self.p1, self.p2

        w_xy = geo_utils.get_line_x_y_dir(self.segment2d)
        if w_xy.p2.x != 0:
            wp1 = settings.Point2D(wp1.x, wp1.y + self._offset)
            wp2 = settings.Point2D(wp2.x, wp2.y + self._offset)
        else:
            wp1 = settings.Point2D(wp1.x + self._offset, wp1.y)
            wp2 = settings.Point2D(wp2.x + self._offset, wp2.y)
        return wp1, wp2

    def get_polygon(self):
        # TODO: 后续需要参考dorctorstarange 更准确
        # 现在版本在两个墙相交时候会有问题
        n = self.segment2d.direction.unit.rotate(settings.pi / 2)
        # wp1, wp2 = self.p1, self.p2
        wp1, wp2 = self.get_offset_p1p2()

        p1 = wp1 + (n * (self.thickness / 2))
        p2 = wp2 + (n * (self.thickness / 2))
        p3 = wp2 - (n * (self.thickness / 2))
        p4 = wp1 - (n * (self.thickness / 2))
        poly = settings.Polygon(p1, p2, p3, p4)
        return poly


class WallItem(Line):
    def __init__(self):
        super(WallItem, self).__init__()
        self._wall_id = None
        self._wall_idx = None
        # self._start_pt = None
        # self._end_pt = None
        self._entrance = None
        self._start_idx = None
        self._start_len = None
        self._length = None
        self._offset = 0

    def init(self, ke_lineitem, id_wall_dict, id_pts_dict, idx):
        self._idx = idx
        fm_key = settings.FRAME_KEY["line_items"]
        self._id = ke_lineitem[fm_key["id"]]
        self._wall_id = ke_lineitem[fm_key["line"]]
        self._wall_idx = id_wall_dict[self._wall_id].idx
        self._thickness = id_wall_dict[self._wall_id].thickness
        self._offset = id_wall_dict[self._wall_id]._offset
        self._type = ke_lineitem[fm_key["type"]]
        self._entrance = ke_lineitem[fm_key["entrance"]]

        # TODO: 旧版frame数据不支持
        # TODO: lineitem 有时候会不在line上
        # x = ke_lineitem[fm_key["start_point_at"]]["x"]
        # y = ke_lineitem[fm_key["start_point_at"]]["y"]
        # self._start_pt = settings.Point2D(x, y)
        # x = ke_lineitem[fm_key["end_point_at"]]["x"]
        # y = ke_lineitem[fm_key["end_point_at"]]["y"]
        # self._end_pt = settings.Point2D(x, y)

        self._start_idx = ke_lineitem[fm_key["start_index"]]
        self._start_len = ke_lineitem[fm_key["start_length"]]
        self._length = ke_lineitem[fm_key["length"]]

        # self._start_idx is 0 or 1
        p1_id = eval("id_wall_dict[self._wall_id].p{}_id".format(self._start_idx + 1))
        end_idx = 1 if self._start_idx == 1 else 2
        p2_id = eval("id_wall_dict[self._wall_id].p{}_id".format(end_idx))
        line2d = settings.Line2D(id_pts_dict[p1_id].point2d, id_pts_dict[p2_id].point2d)

        self._p1 = id_pts_dict[p1_id].point2d + line2d.direction.unit * self._start_len
        self._p2 = self._p1 + line2d.direction.unit * self._length
        self._segment2d = settings.Segment2D(self._p1, self._p2)

    @property
    def entrance(self):
        return self._entrance

    @property
    def wall_id(self):
        return self._wall_id

    def set_line(self, start2end=True):
        if start2end is True:
            self._line2d = settings.Line2D(self._p1, self._p2)
        else:
            self._line2d = settings.Line2D(self._p2, self._p1)

    def get_offset_p1p2(self):
        wp1, wp2 = self.p1, self.p2

        w_xy = geo_utils.get_line_x_y_dir(self.segment2d)
        if w_xy.p2.x != 0:
            wp1 = settings.Point2D(wp1.x, wp1.y + self._offset)
            wp2 = settings.Point2D(wp2.x, wp2.y + self._offset)
        else:
            wp1 = settings.Point2D(wp1.x + self._offset, wp1.y)
            wp2 = settings.Point2D(wp2.x + self._offset, wp2.y)

        return wp1, wp2


class Region(object):
    def __init__(self):
        self._idx = None
        self._id = None
        self._size = None
        self._size_without_line = None
        self._type_name = None
        self._roomType = None
        self._room_type = None
        self._room_type_name = None
        self._ke_data = None
        self._id_pts = collections.OrderedDict()
        self._idx_pts = collections.OrderedDict()
        self._id_contours = collections.OrderedDict()
        self._idx_contours = collections.OrderedDict()
        self._id_contour_walls = collections.OrderedDict()
        self._id_walls = collections.OrderedDict()
        self._idx_walls = collections.OrderedDict()
        self._id_wall_items = collections.OrderedDict()
        self._idx_wall_items = collections.OrderedDict()
        self._adjacent_region_id = []
        self._connect_region_id = []
        self._is_prepared = False

        self._inner_region = None

    def init(self, ke_region, id_points, id_walls, id_wall_items, idx):
        self._idx = idx
        frm_key = settings.FRAME_KEY["regions"]
        self._ke_data = ke_region
        self._id = ke_region[frm_key["id"]]
        self._size = ke_region[frm_key["size"]]
        self._size_without_line = ke_region.get(frm_key["size_wihtout_line"])
        self._roomType = ke_region[frm_key["room_type"]]
        self._room_type = ke_region[frm_key["type"]]
        self._room_type_name = ke_region[frm_key["room_string"]]
        shl_polygon_pts = []
        # frame数据中外轮廓事顺时针的
        for pt_id in ke_region[frm_key["points"]]:
            self._id_contours[pt_id] = id_points[pt_id]
            self._idx_contours[id_points[pt_id].idx] = id_points[pt_id]
            shl_polygon_pts.append((id_points[pt_id].point2d.x, id_points[pt_id].point2d.y))
        self._id_pts = copy.deepcopy(self._id_contours)
        self._idx_pts = copy.deepcopy(self._idx_contours)

        # 有些在空间内的墙, 但不是轮廓的墙，需要加入wall list
        shl_polygon = Polygon(shl_polygon_pts)  # 区域多边形
        for id, w in id_walls.items():
            p1 = Point(w.segment2d.p1.x, w.segment2d.p1.y)
            p2 = Point(w.segment2d.p2.x, w.segment2d.p2.y)
            if shl_polygon.contains(p1) or shl_polygon.contains(p2):
                id_walls[id].set_region_inner()
                self._id_walls[id] = id_walls[id]
                self._idx_walls[id_walls[id].idx] = id_walls[id]
                self._id_pts[w.p1_id] = id_points[w.p1_id]
                self._id_pts[w.p2_id] = id_points[w.p2_id]
                self._idx_pts[w.p1_id] = id_points[w.p1_id]
                self._idx_pts[w.p2_id] = id_points[w.p2_id]

        for w in ke_region[frm_key["attachments"]["name"]][frm_key["attachments"]["lines"]]:
            if id_walls.get(w["id"]) is None:
                continue
            self._id_walls[w["id"]] = id_walls[w["id"]]
            self._id_contour_walls[w["id"]] = id_walls[w["id"]]
            self._idx_walls[id_walls[w["id"]].idx] = id_walls[w["id"]]
        for line_item in ke_region[frm_key["attachments"]["name"]][frm_key["attachments"]["line_items"]]:
            self._id_wall_items[line_item["id"]] = id_wall_items[line_item["id"]]
            self._idx_wall_items[id_wall_items[line_item["id"]].idx] = id_wall_items[line_item["id"]]
        # 只要有公用的墙就算相邻
        for adj in ke_region[frm_key["attachments"]["name"]][frm_key["attachments"]["areas"]]:
            # self._adjacent_region_id = adj[frm_key["type"]]
            self._adjacent_region_id.append(adj[frm_key["id"]])

    def set_relations(self, id_regions):
        doors = self.get_doors()
        for adj in self._adjacent_region_id:
            adj_reg = id_regions[adj]
            adj_doors = adj_reg.get_doors()
            connect_door = list(set(doors).intersection(set(adj_doors)))
            if len(connect_door) != 0:
                self._connect_region_id.append(adj)

    @property
    def connect_region_id(self):
        return self._connect_region_id

    @property
    def adjacent_region_id(self):
        return self._adjacent_region_id

    @property
    def is_prepared(self):
        return self._is_prepared

    @property
    def id(self):
        return self._id

    @property
    def id_wall_items(self):
        return self._id_wall_items

    @property
    def room_type(self):
        return self._room_type

    @property
    def id_walls(self):
        return self._id_walls

    @property
    def id_contour_walls(self):
        return self._id_contour_walls

    @property
    def id_pts(self):
        return self._id_pts

    @property
    def ke_data(self):
        return self._ke_data

    @property
    def id_contours(self):
        return self._id_contours

    @property
    def size_without_line(self):
        return self._size_without_line

    @property
    def size(self):
        return self._size

    @property
    def room_type_name(self):
        return self._room_type_name

    @property
    def roomType(self):
        return self._roomType

    @property
    def inner_region(self):
        return self._inner_region

    def get_id_items(self):
        id_items = {
            settings.FRAME_KEY["points"]["name"]: self._idx_contours,
            settings.FRAME_KEY["lines"]["name"]: self._idx_walls,
            settings.FRAME_KEY["line_items"]["name"]: self._idx_wall_items
        }
        return id_items

    def show(self, show_wall_normal=False, show_item_normal=False,
             walking_pts=None):
        if settings.PLOT is True:
            fp_vis = vis.FloorPlanVis()
            fp_vis.set_floorplan(self)
            if show_wall_normal:
                fp_vis.add_normal_direction(lines=True, lineitems=False)
            if show_item_normal:
                fp_vis.add_normal_direction(lines=False, lineitems=True)
            if walking_pts is not None:
                fp_vis.add_walking_path(walking_pts)
            fp_vis.show()
        else:
            pass

    def save_img(self, img_path, frame_id,
             show_wall_normal=False, show_item_normal=False,
             walking_pts=None):
        if settings.PLOT is True:
            fp_vis = vis.FloorPlanVis()
            fp_vis.set_floorplan(self)
            if show_wall_normal:
                fp_vis.add_normal_direction(lines=True, lineitems=False)
            if show_item_normal:
                fp_vis.add_normal_direction(lines=False, lineitems=True)
            if walking_pts is not None:
                fp_vis.add_walking_path(walking_pts)
            fp_vis.save_img_floorplan(img_path, frame_id)
            fp_vis.clear()
        else:
            pass

    def prepare(self):
        """
        计算每个功能区之前，需要提前准备数据结构:
            - 把外轮廓的墙法线方向置于功能区内
            - 把门窗法线方向置于功能区内
        """
        contour_keys = list(self._idx_contours.keys())

        poly_pts = [self._idx_contours.get(idx).point2d for idx in contour_keys]
        poly = settings.Polygon(*poly_pts)
        if poly.area > 0:
            # 功能区轮廓必须是顺时针的
            raise RuntimeError("contours is ccw")

        for idx1, pt_idx1 in enumerate(contour_keys):
            idx2 = idx1 + 1
            if idx1 == len(contour_keys) - 1:
                idx2 = 0
            pt1 = self._idx_contours.get(pt_idx1)
            pt_idx2 = contour_keys[idx2]
            pt2 = self._idx_contours.get(pt_idx2)


            wall_ids = list(set(pt1.lines).intersection(set(pt2.lines)))
            # if self._id_walls.get(wall_id) is None:
            #     continue
            if len(wall_ids) > 0:
                wall_id = wall_ids[0]
                self._id_walls[wall_id].set_line(pt_idx1, pt_idx2, self._idx_contours)

        for idx, wall_item in self._idx_wall_items.items():
            wall_id = wall_item.wall_id
            wall_dir = self._id_walls[wall_id].line2d.direction.unit
            item_line = settings.Line2D(wall_item.p1, wall_item.p2)

            # 方向有一定数值误差
            if item_line.direction.unit.dot(wall_dir) > 0.97:
                wall_item.set_line(start2end=True)
            else:
                wall_item.set_line(start2end=False)

        for idx, pt in self._idx_contours.items():
            pt.set_convex(self)

        # TODO: 配置内墙的方向 ?
        self._is_prepared = True

    def clear(self):
        for k, line in self._id_walls.items():
            line.clear_line2d()
        for k, line in self._idx_wall_items.items():
            line.clear_line2d()
        for k, pt in self._idx_contours.items():
            pt.clear()

    def get_windows(self):
        windows = []
        for k, item in self.id_wall_items.items():
            if item.type in FRAME_KEY["line_items"]["types"]["window"]:
                windows.append(item)
        return windows

    def get_doors(self):
        doors = []
        for k, item in self.id_wall_items.items():
            if item.type in FRAME_KEY["line_items"]["types"]["door"]:
                doors.append(item)
        return doors

    def get_inner_polygon(self):
        # TODO: 相交的内墙，内角会有差异
        contours = list(self.id_contours.values())
        contours = [j.point2d.args for j in contours]
        poly0 = Polygon(contours)
        for wid, wall in self.id_walls.items():
            wpoly = wall.get_polygon()
            wpoly = Polygon(wpoly.vertices)
            poly0 = poly0.difference(wpoly)
        # TODO: 多边形求差出现多个多边形, 需要特殊处理
        if isinstance(poly0, MultiPolygon):
            muti_polys = sorted(poly0, key=lambda p: p.area, reverse=True)
            poly0 = muti_polys[0]
        x, y = poly0.exterior.coords.xy
        pts = [settings.Point2D(x, y) for x, y in zip(x, y)]

        # self.show(walking_pts=[pts])
        inner_polygon = settings.Polygon(*pts)
        # inner_polygon = geo_utils.correct_inner_polygon(inner_polygon)
        try:
            inner_polygon = geo_utils.correct_inner_polygon(inner_polygon)
        except:
            print("correct inner polygon failed! ")
        # self.show(walking_pts=[inner_polygon.vertices])
        return inner_polygon

    def set_inner_region(self):
        inner_polygon = self.get_inner_polygon()
        inner_region = InnerRegion(inner_polygon)
        for k, v in self.id_wall_items.items():
            inner_region.set_line_item(v)
        if inner_polygon.area > 0:
            assert False, "内轮廓也应该是顺时针的"
        self._inner_region = inner_region
        return inner_region


class InnerRegion(object):
    def __init__(self, polygon):
        self._polygon = polygon
        self._id_items = collections.OrderedDict()
        self._idx_items = collections.OrderedDict()
        self.inner_lines = []

        self.polygon_correction()
        self.set_inner_lines()

    @property
    def id_items(self):
        return self._id_items

    @property
    def polygon(self):
        return self._polygon

    def polygon_correction(self):
        # 与水平(竖直)方向夹角非常小的线段更新为横平竖直的
        polygon = self._polygon
        horizantal = settings.Line2D(settings.Point2D(0, 0), settings.Point2D(1, 0))
        vertical = settings.Line2D(settings.Point2D(0, 0), settings.Point2D(0, 1))

        new_vertices = [polygon.vertices[0]]
        for idx, v in enumerate(polygon.vertices):
            if idx == len(polygon.vertices) - 1:
                p1, p2 = v, polygon.vertices[0]
            else:
                p1, p2 = v, polygon.vertices[idx + 1]

            line0 = settings.Line2D(p1, p2)

            ver_angle = np.rad2deg(float(line0.angle_between(vertical)))
            ver_angle = ver_angle if ver_angle < 180 else ver_angle - 180
            if 0 < ver_angle < RULE_PARAM["parallel_angle_max"]:
                p2 = settings.Point2D(p1.x, p2.y)

            hor_angle = np.rad2deg(float(line0.angle_between(horizantal)))
            hor_angle = hor_angle if hor_angle < 180 else hor_angle - 180
            if 0 < hor_angle < RULE_PARAM["parallel_angle_max"]:
                p2 = settings.Point2D(p2.x, p1.y)
            new_vertices.append(p2)

        new_poly = settings.Polygon(*new_vertices)
        self._polygon = new_poly

    def set_line_item(self, item):
        for idx, l in enumerate(self.inner_lines):
            adsorb_flag = [False, False]
            for idx, p in enumerate(item.segment2d.points):
                if l.distance(p) < RULE_PARAM["item_adsorb"]:
                    adsorb_flag[idx] = True
            if adsorb_flag[0] and adsorb_flag[1]:
                inner_item = copy.deepcopy(item)
                p1 = l.projection(item.p1)
                p2 = l.projection(item.p2)
                inner_item.reset_points([p1, p2])
                self._id_items[inner_item.id] = inner_item
                self._idx_items[idx] = inner_item

        # for side in self._polygon.sides:
        #     adsorb_flag = [False, False]
        #     for idx, p in enumerate(item.segment2d.points):
        #         if side.distance(p) < RULE_PARAM["item_adsorb"]:
        #             adsorb_flag[idx] = True
        #     if adsorb_flag[0] and adsorb_flag[1]:
        #         inner_item = copy.deepcopy(item)
        #         p1 = side.projection(item.p1)
        #         p2 = side.projection(item.p2)
        #         inner_item.reset_points([p1, p2])
        #         self._id_items[inner_item.id] = inner_item

    def set_inner_lines(self):
        for idx, v in enumerate(self.polygon.vertices):
            p1 = v
            if idx != len(self.polygon.vertices) - 1:
                p2 = self.polygon.vertices[idx + 1]
            else:
                p2 = self.polygon.vertices[0]
            line = settings.Line2D(p1, p2)
            self.inner_lines.append(line)

