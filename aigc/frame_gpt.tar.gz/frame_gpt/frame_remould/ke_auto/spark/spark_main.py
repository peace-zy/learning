# coding=utf-8
import os
import sys
os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../../"))
sys.path.insert(0, os.getcwd())
import logging
import sys
import yaml
import datetime
import json

from lib import entity
from frame_remould.utils import spark_util
from frame_remould.floorplan import House
import frame_remould.ke_auto.utils as ke_utils


def convert_ke_auto(row, **params):
    frame = entity.Frame(row)
    try:
        frame_vector = frame.vector
        house = House()
        house.set_json_str(json.dumps(frame_vector))
        ke_auto_list = []
        for fp in house.floorplans:
            ke_utils.update_floorplan(fp)
            ke_auto_dict = ke_utils.get_auto_json(fp)
            ke_auto_list.append(ke_auto_dict)
    except Exception as e:
        return [frame.frame_id, "error"]

    return [frame.frame_id, json.dumps(ke_auto_list)]


def test():
    import frame_eval.test.local_deco_test as local_deco_test
    frameid, row = local_deco_test.get_frame_vector(11000013003179)
    frame = entity.Frame(row)
    frame_vector = frame.vector
    house = House()
    house.set_json_str(json.dumps(frame_vector))
    ke_auto_list = []
    for fp in house.floorplans:
        ke_utils.update_floorplan(fp)
        ke_auto_dict = ke_utils.get_auto_json(fp)
        ke_auto_list.append(ke_auto_dict)

    return [frame.frame_id, ke_auto_list]


def logic_func(driver, raw_df, **params):
    result_rdd = raw_df.rdd.map(lambda row: convert_ke_auto(row, **params))
    result_df = driver.rdd_2_df(result_rdd)
    names = params["table_names"]
    result_df = result_df.toDF(*names)
    return result_df


def main():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    if len(sys.argv) < 3:
        logging.error("no less than 2 arguments!")
        sys.exit()
    pt_date = sys.argv[1]
    config_file = sys.argv[2]

    with open(config_file, "r") as config_data:
        conf = yaml.load(config_data)

    # 从配置文件读取参数
    spark_config_key = "convert_ke_auto_config"
    spark_params = conf.get(spark_config_key, None)
    if spark_params is None:
        logging.error("lack {} in config file".format(spark_config_key))
        sys.exit(-1)

    # ## 补充参数
    # pt
    spark_params["sql_params"]["pt_date"] = pt_date
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_function"] = logic_func
    # 存储pt
    spark_params["save_params"]["partition_params"] = {"pt": "{}000000".format(pt_date)}
    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()

if __name__ == "__main__":
    main()
    # test()