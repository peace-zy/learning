
# hdfs 上部署的python环境
HDFS_PYTHON_PATH="hdfs://ns-fed/user/strategy/yudonghai/python.tgz#python"

function convert_ke_auto() {
    pt_date=$1

    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=80 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.pyspark.driver.python="python2.7" \
    frame_remould/ke_auto/spark/spark_main.py "$pt_date" frame_remould/ke_auto/spark/convert_ke_auto.yml
}

function usage {
    echo "usage:"
    echo "bash frame_miner.sh <job_name> [job_params...]"
    echo "  <job_name>:"
    echo "      convert_ke_auto"
    echo "  [job_params...]:"
    echo "      params for job if necessary"
    exit 1
}

function main
{
    if [[ $# -lt 1 ]] ; then
        echo "error! lack <job_name>"
        usage
    fi
    job_name=$1
    echo "TASK: ${job_name}  "

    zip -q -r ./lib.zip ./lib ./frame_remould

    case ${job_name} in
        convert_ke_auto )
        pt_data=$2
        convert_ke_auto "$pt_data"
        ;;
        * )
        echo "error! invalid <job_name>"
        usage
        ;;
    esac
}

main $*