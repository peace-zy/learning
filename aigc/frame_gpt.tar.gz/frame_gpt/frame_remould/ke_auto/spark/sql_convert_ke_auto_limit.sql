SELECT
    frame_id
     ,image_id
     ,vector_value
     ,city_code
FROM
    (SELECT
         mapping.entity_id as frame_id
          ,image_id
          ,reflect("java.net.URLDecoder", "decode", trim(vector_value), "UTF-8") AS vector_value
          ,city_code
          ,ROW_NUMBER() OVER(PARTITION BY mapping.entity_id ORDER BY update_time desc) AS rn
     FROM
         (SELECT
              id
               ,vector_value
               ,city_code
          FROM dw.dw_house_frame_vector_da
          WHERE pt='{pt_date}000000'
            AND is_valid=1
            AND city_code='110000'
          LIMIT 10000
         ) vector
             JOIN
         (SELECT
              image_id
               ,entity_id
               ,update_time
          FROM dw.dw_house_image_entity_mapping_da
          WHERE pt='{pt_date}000000'
            AND image_type_code = 110028006
            AND entity_type_code = 110029002
            AND is_valid = 1
          LIMIT 10000
         ) mapping
         ON mapping.image_id=vector.id
    ) tb
WHERE tb.rn=1

LIMIT 100
