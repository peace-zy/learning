# coding=utf-8
import requests
import json
import time

import sys
reload(sys)
sys.setdefaultencoding('utf8')

API_URL = r"http://localhost:7777/auto_design/whole_design/"

def test_local_ke_auto_data():
    start = time.clock()

    jpath = "0a414cd1-97f6-11e9-8e0d-e0d55e49e470.json"
    f = open(jpath, 'rb')
    j = json.load(f)
    f.close()

    payload = {'floorplan': json.dumps(j)}

    res = requests.post(API_URL, data=payload)
    obj = json.loads(res.text)

    string = json.dumps(obj, ensure_ascii=False)
    with open('res.json', 'w') as f:
        f.write(string)

    end = time.clock()

    if res.status_code == 200:
        print(end - start)
    else:
        print('failed!')


if __name__ == "__main__":
    test_local_ke_auto_data()