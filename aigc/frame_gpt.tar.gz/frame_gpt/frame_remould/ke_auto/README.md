## 修改配置文件
修改settings文件中的AUTO_DESIGN_URL

## 运行
```
python main.py
```

## 启动flask
```
python frame_remould\ke_auto\flask_main.py
```