# coding=utf-8
import json
import requests
from PIL import Image
from io import BytesIO
import matplotlib

from frame_remould.settings import FRAME_KEY
import frame_remould.utils.geo_utils as geo_utils
import frame_remould.ke_auto.settings as ke_auto_settings
from frame_remould.geometry.point import Point2D
from settings import REGION_TYPE
from frame_remould.geometry.line import Line2D, Segment2D
import frame_remould.room_types.kitchen.furniture as kitchen_fur

def draw_json(frameX_json, show=True, save_path=None):
    payload = {
        'source': json.dumps(frameX_json),
        "imgSize": '1024x1024',
        "hideFloor": True,
        "hideItems": True,
        "hideAreaLabelSize": True,
    }
    res = requests.post(ke_auto_settings.DOCTOR_URL, data=payload)
    try:
        obj = json.loads(res.text)
        print("Error: ", res.text)
    except ValueError, e:
        img = Image.open(BytesIO(res.content))

    if show:
        img.show()
    if save_path:
        img.save(save_path)
    return img


def get_img(house, show=True, save_path=None):
    frameX_json = house.get_frameX_json()

    payload = {
        'source': json.dumps(frameX_json),
        "imgSize": '1024x1024',
        "hideFloor": True,
        "hideItems": True,
        "hideAreaLabelSize": True,
    }
    res = requests.post(ke_auto_settings.DOCTOR_URL, data=payload)
    try:
        obj = json.loads(res.text)
        print("Error: ", res.text)
    except ValueError, e:
        img = Image.open(BytesIO(res.content))

    if show:
        img.show()
    if save_path:
        img.save(save_path)
    return img


def get_ke_auto_data(house):
    house.fur_list = []
    for fp in house.floorplans:
        update_floorplan(fp)
        json_dict = get_auto_json(fp)
        payload = {'floorplan': json.dumps(json_dict),
                   'frameID': house.frame_id}

        if ke_auto_settings.DEBUG:
            string = json.dumps(json_dict, ensure_ascii=False, indent=4)
            with open('./test/'+ str(house.frame_id) + 'res.json', 'w') as f:
                f.write(string)

        res = requests.post(ke_auto_settings.AUTO_DESIGN_URL, data=payload)
        fp.auto_res = json.loads(res.text)
        update_furnitures(fp)
        house.fur_list.extend(fp.fur_list)


def update_floorplan(fp):
    update_wall_door_win(fp)
    update_room_type(fp)


def update_wall_door_win(fp):
    wall_list = []
    double_doors_list = []
    single_doors_list = []
    door_openings_list = []
    sliding_doors_list = []
    windows_list = []

    wall_dict = {}
    double_doors_dict = {}
    single_doors_dict = {}
    door_openings_dict = {}
    sliding_doors_dict = {}
    windows_dict = {}

    for i in range(len(fp._idx_walls)):
        wall = fp._idx_walls[i]
        p1, p2 = wall.p1, wall.p2
        w = {
            "point_start": {
                "x": int(p1.x),
                "y": int(p2.y)
            },
            "point_end": {
                "x": int(p2.x),
                "y": int(p2.y)
            },
            "thickness": wall.thickness
        }
        wall_dict[wall.id] = i
        wall_list.append(w)

    for idx, w_item in fp._idx_wall_items.items():
        pstart, pend = w_item.p1, w_item.p2
        attached_wall_idx = wall_dict[w_item.wall_id]
        if w_item.type in FRAME_KEY['line_items']['types']['window']:
            name = "普通窗"
            window = get_line_item_data(name, pstart, pend, attached_wall_idx)
            windows_dict[w_item.id] = len(windows_list)
            windows_list.append(window)
            continue

        normal2d = geo_utils.get_normal_dir(w_item.segment2d)
        normal = {
            "x": int(normal2d.x),
            "y": int(normal2d.y)
        }  # TODO: P2 norml 计算方式不对
        connect = get_lineitem_connect(fp, w_item.id)

        if w_item.type in FRAME_KEY['line_items']['types']['double_door']:
            name = "双开门"
            door = get_line_item_data(name, pstart, pend, attached_wall_idx,
                                      connect=connect, normal=normal)
            double_doors_dict[w_item.id] = len(double_doors_list)
            double_doors_list.append(door)

        if w_item.type == FRAME_KEY['line_items']['types']['single_door']:
            name = "单开门"
            door = get_line_item_data(name, pstart, pend, attached_wall_idx,
                                      connect=connect, normal=normal)
            single_doors_dict[w_item.id] = len(single_doors_list)
            single_doors_list.append(door)

        if w_item.type == FRAME_KEY['line_items']['types']['sliding_door']:
            name = "推拉门"
            door = get_line_item_data(name, pstart, pend, attached_wall_idx,
                                      connect=connect, normal=normal)
            sliding_doors_dict[w_item.id] = len(sliding_doors_list)
            sliding_doors_list.append(door)

        if w_item.type == FRAME_KEY['line_items']['types']['opening_door']:
            name = "门洞"
            door = get_line_item_data(name, pstart, pend, attached_wall_idx,
                                      connect=connect, normal=normal)
            door_openings_dict[w_item.id] = len(door_openings_list)
            door_openings_list.append(door)

    fp.wall_list = wall_list
    fp.wall_dict = wall_dict

    fp.double_doors_list = double_doors_list
    fp.single_doors_list = single_doors_list
    fp.door_openings_list = door_openings_list
    fp.sliding_doors_list = sliding_doors_list
    fp.windows_list = windows_list

    fp.double_doors_dict = double_doors_dict
    fp.single_doors_dict = single_doors_dict
    fp.door_openings_dict = door_openings_dict
    fp.sliding_doors_dict = sliding_doors_dict
    fp.windows_dict = windows_dict


def update_room_type(fp):
    for r_id, region in fp.id_regions.items():
        auto_room_type = {"ID": region.id}
        region.prepare()
        region.set_inner_region()
        walls_index = []
        windows_index = []
        single_doors_index = []
        double_doors_index = []
        door_openings_index = []
        sliding_doors_index = []
        for wid, w in region.id_walls.items():
            widx = fp.wall_dict[wid]
            walls_index.append(widx)

        for li_id, li in region.id_wall_items.items():
            if li_id in fp.windows_dict.keys():
                li_idx = fp.windows_dict[li_id]
                windows_index.append(li_idx)
            if li_id in fp.single_doors_dict.keys():
                li_idx = fp.single_doors_dict[li_id]
                single_doors_index.append(li_idx)
            if li_id in fp.double_doors_dict.keys():
                li_idx = fp.double_doors_dict[li_id]
                double_doors_index.append(li_idx)
            if li_id in fp.sliding_doors_dict.keys():
                li_idx = fp.sliding_doors_dict[li_id]
                sliding_doors_index.append(li_idx)
            if li_id in fp.door_openings_dict.keys():
                li_idx = fp.door_openings_dict[li_id]
                door_openings_index.append(li_idx)
        auto_room_type["walls_index"] = walls_index
        auto_room_type["single_doors_index"] = single_doors_index
        auto_room_type["double_doors_index"] = double_doors_index
        auto_room_type["door_openings_index"] = door_openings_index
        auto_room_type["sliding_doors_index"] = sliding_doors_index
        auto_room_type["windows_index"] = windows_index

        type = ke_auto_settings.REGION_TYPE.get(region.room_type)
        if type is not None:
            auto_room_type["name"] = ke_auto_settings.REGION_NAME.get(region.room_type)
            auto_room_type['type'] = type
        else:
            auto_room_type['name'] = '其它'
            auto_room_type['type'] = 'UnKnown'

        ## 增加是否自动设计参数
        if ke_auto_settings.DESIGN_ROOM.get(type):
            auto_room_type['is_design'] = True
        else:
            auto_room_type['is_design'] = False

        boundary = []
        for p in region.inner_region.polygon.vertices:
            boundary.append({
                "x": int(p.x),
                "y": int(p.y)
            })
        auto_room_type["boundary"] = boundary
        region.auto_room_type = auto_room_type


def get_line_item_data(name, pstart, pend, attached_wall_idx,
                       connect=None,  # list
                       normal=None):
    line_item = {
        "name": name,
        "point_start": {
            "x": int(pstart.x),
            "y": int(pstart.y)
        },
        "point_end": {
            "x": int(pend.x),
            "y": int(pend.y)
        },
        "attached_wall": attached_wall_idx
    }
    if connect != None:
        line_item["connect"] = connect
    if normal != None:
        line_item['normal'] = normal
    return line_item


def get_auto_json(floorplan):
    json_dict = {
        "wall_list": floorplan.wall_list,
        "wall_num": len(floorplan.wall_list),
        "double_doors_list": floorplan.double_doors_list,
        "double_doors_num": len(floorplan.double_doors_list),
        "single_doors_list": floorplan.single_doors_list,
        "single_doors_num": len(floorplan.single_doors_list),
        "door_openings_list": floorplan.door_openings_list,
        "door_openings_num": len(floorplan.door_openings_list),
        "sliding_doors_list": floorplan.sliding_doors_list,
        "sliding_doors_num": len(floorplan.sliding_doors_list),
        "windows_list": floorplan.windows_list,
        "windows_num": len(floorplan.windows_list),
    }

    room_type = []
    for r_id, region in floorplan.id_regions.items():
        room_type.append(region.auto_room_type)
    json_dict['room_type'] = room_type

    return json_dict


def update_furnitures(floorplan):
    fur_list = []
    for room in floorplan.auto_res['room_type']:
        room_class = ke_auto_settings.ROOM_CLASS.get(room['type'])
        if room_class is None:
            continue
        kitchen_cabinets = []
        if room.get("Furnishing") is None:
            floorplan.fur_list = fur_list
            continue
        for fur_dict in room["Furnishing"]:
            fur = fur_dict[fur_dict.keys()[0]]
            base_p1 = Point2D(fur['backline'][0]['x'], fur['backline'][0]['y'])
            base_p2 = Point2D(fur['backline'][1]['x'], fur['backline'][1]['y'])
            baseline = Line2D(base_p1, base_p2)

            fur_cls = ke_auto_settings.FURNISHING[fur_dict.keys()[0]](
                baseline, fur['depth']
            )
            if fur_dict.keys()[0] == "Cabinet":
                kitchen_cabinets.append(fur_cls)
            else:
                fur_list.append(fur_cls)
            # fur_list.append(fur_cls)

        if len(kitchen_cabinets) != 0:
            cabinets = update_kitchen_cabinets(kitchen_cabinets)
            fur_list.extend(cabinets)

    floorplan.fur_list = fur_list


def update_kitchen_cabinets(cabinets):
    def get_U_base(cabinets):
        u_base_cab = None
        for c0 in cabinets:
            base_flag = True
            for c1 in cabinets:
                if c0 == c1:
                    continue
                inter = set(c0.baseline.points).intersection(set(c1.baseline.points))
                if len(inter) == 0:
                    base_flag = False
            if base_flag:
                u_base_cab = c0
                break
        return u_base_cab

    def get_U_cab12(cabinets, base_cab):
        c1, c2 = None, None
        for c in cabinets:
            if c == base_cab:
                continue
            if base_cab.baseline.p1 in c.baseline.points:
                c1 = c
            if base_cab.baseline.p2 in c.baseline.points:
                c2 = c
        return c1, c2

    def get_cab_U(cabinets):
        base_cab = get_U_base(cabinets)
        cab1, cab2 = get_U_cab12(cabinets, base_cab)
        cab = kitchen_fur.CabinetU(base_cab.baseline, 1)
        depth1 = cab1.baseline.p1.distance(cab1.baseline.p2)
        depth2 = cab2.baseline.p1.distance(cab2.baseline.p2)
        cab.set_depth12(depth1, depth2)
        return cab

    def get_cab_L(cabinets):
        base_p1 = None
        for p in cabinets[0].baseline.points:
            base1 = cabinets[1].baseline
            if p in base1.points:
                base_p1 = p
        base_cab, depth_cab = None, None
        for idx, c in enumerate(cabinets):
            if base_p1 == c.baseline.p1:
                base_cab = c
                depth_cab = cabinets[int(not idx)]

        depth = depth_cab.baseline.p1.distance(depth_cab.baseline.p2)
        cab = kitchen_fur.CabinetL(base_cab.baseline, depth)
        return cab

    def if_L_cab(cabinets):
        seg1 = Segment2D(cabinets[0].baseline.p1, cabinets[0].baseline.p2)
        seg2 = Segment2D(cabinets[1].baseline.p1, cabinets[1].baseline.p2)
        if len(seg1.intersection(seg2)) == 0:
            return False
        else:
            return True

    if len(cabinets) == 3:
        cab = get_cab_U(cabinets)
        return [cab]
    elif len(cabinets) == 2:
        if if_L_cab(cabinets):
            cab = get_cab_L(cabinets)
            return [cab]
        else:
            return cabinets
    elif len(cabinets) == 1:
        return cabinets


def get_lineitem_connect(fp, lineitem_id):
    res = []
    for region_id, region in fp._id_regions.items():
        if region._id_wall_items.get(lineitem_id):
            res.append(ke_auto_settings.REGION_TYPE.get(region.room_type, "Unknown"))
    if len(res) == 1:
        res.append("Outside")
    return res

