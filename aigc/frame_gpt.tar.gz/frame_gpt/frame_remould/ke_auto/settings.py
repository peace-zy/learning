# coding=utf-8
import sys


reload(sys)
sys.setdefaultencoding('utf8')

import frame_remould.room_types.bathroom.explain as bathroom
import frame_remould.room_types.bathroom.furniture as bathroom_fur
import frame_remould.room_types.bedroom.explain as bedroom
import frame_remould.room_types.bedroom.furniture as bedroom_fur
import frame_remould.room_types.kitchen.explain as kitchen
import frame_remould.room_types.kitchen.furniture as kitchen_fur
import frame_remould.room_types.balcony.explain as balcony
import frame_remould.room_types.balcony.furniture as balcony_fur
import frame_remould.room_types.livingroom.explain as livingroom
import frame_remould.room_types.livingroom.furniture as livingroom_fur
import frame_remould.room_types.dingroom.explain as dingroom
import frame_remould.room_types.dingroom.furniture as dingroom_fur
import frame_remould.room_types.livingdingroom.explain as livingdingroom
import frame_remould.room_types.schoolroom.explain as schoolroom
import frame_remould.room_types.schoolroom.furniture as schoolroom_fur

DEBUG = True

AUTO_DESIGN_URL = r"http://10.26.9.9:5001/auto_design/whole_design/"
DOCTOR_URL = r"http://10.26.9.27:3737/print"

if DEBUG:
    AUTO_DESIGN_URL = r"http://localhost:7777/auto_design/whole_design/"
    DOCTOR_URL = r"http://127.0.0.1:3737/print"

## 需要进行自动设计的分间类型
DESIGN_ROOM = {
    "Unknown": False,
    "Livingroom": False,  # "LivingDiningRoom",  ## 暂时用客餐厅代替客厅
    "DiningRoom": False,
    "Bedroom": True,
    "Schoolroom": False,
    "Bathroom": False,
    "Kitchen": True,
    "Balcony": False,
    "Hallway": False,
}

REGION_TYPE = {
    0: "Unknown",
    1: "Livingroom",  # "LivingDiningRoom",  ## 暂时用客餐厅代替客厅
    2: "DiningRoom",
    3: "Bedroom",
    4: "Schoolroom",
    5: "Bathroom",
    8: "Kitchen",
    12: "Balcony",
    23: "Hallway",
}

REGION_NAME = {
    0: "其他",
    1: "客厅",
    2: "餐厅",
    3: "卧室",
    4: "书房",
    5: "卫生间",
    8: "厨房",
    12: "阳台",
    23: "过道",
}

ROOM_CLASS = {
    "Bedroom": bedroom.Bedroom,
    "Bathroom": bathroom.Bathroom,
    "Kitchen": kitchen.Kitchen,
    "Balcony": balcony.Balcony,
    "LivingDiningRoom": livingdingroom.LivingDingRoom,
    "Livingroom": livingroom.Livingroom,
    "DiningRoom": dingroom.DingRoom,
    "Schoolroom": schoolroom.Schoolroom,
}

FURNISHING = {
    "AirFlue": bathroom_fur.Flue,
    "Sewer": bathroom_fur.Sewer,
    "Closestool": bathroom_fur.Closestool,
    "Sprinkler": bathroom_fur.Sprinkler,
    "BathroomCabinet": bathroom_fur.BathroomCabinet,
    "BasinWithPedestal": bathroom_fur.BasinWithPedestal,
    "Washer": bathroom_fur.Washer,
    "Shower": bathroom_fur.Shower,
    "Flue": bathroom_fur.Flue,
    "GasCabinet": kitchen_fur.Hearth,
    "AngleGasCabinet": kitchen_fur.Hearth,
    "SinkCabinet": kitchen_fur.Basin,
    "AngleSinkCabinet": kitchen_fur.Basin,
    "Cabinet": kitchen_fur.Cabinet1,
    "Refrigerator": kitchen_fur.Refigerator,
    "Bed": bedroom_fur.Bed,
    "NightTable": bedroom_fur.Bedside,
    "Closet": bedroom_fur.Wardrobe,
    "Drawers": bedroom_fur.Drawers,

    "Plants": balcony_fur.Plants,

    "Stool": livingroom_fur.Stool,
    "TVbench": livingroom_fur.TVbench,
    "Sofa_1": livingroom_fur.Sofa_1,
    "RightSofa_L": livingroom_fur.RightSofa_L,
    "LeftSofa_L": livingroom_fur.LeftSofa_L,
    "RectangleTeaTable": livingroom_fur.RectangleTeaTable,
    "SquareTeaTable": livingroom_fur.SquareTeaTable,
    "CircleTeaTable": livingroom_fur.CircleTeaTable,
    "SideTable": livingroom_fur.SideTable,

    "DiningChair": dingroom_fur.DiningChair,
    "SquareDiningTable": dingroom_fur.SquareDiningTable,
    "RoundDiningTable": dingroom_fur.RoundDiningTable,
    "SideCabinet": dingroom_fur.SideCabinet,

    "BookCase": schoolroom_fur.BookCase,
    "Desk": schoolroom_fur.Desk,
    "Chair": schoolroom_fur.Chair,
    "Recliner": schoolroom_fur.Recliner,
}
