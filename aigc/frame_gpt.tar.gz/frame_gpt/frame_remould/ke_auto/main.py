# coding=utf-8
import json
import requests
from PIL import Image
from io import BytesIO
from multiprocessing import Pool
import pandas as pd
import time
import boto3
import os
import sys

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../"))
sys.path.insert(0, os.getcwd())

import frame_remould.ke_auto.utils as ke_utils
import frame_remould.ke_auto.settings as ke_settings
import frame_remould.settings as settings


settings.PLOT = True
ke_settings.DEBUG = True

from frame_remould.floorplan import House
import glob

S3_AK = "223HG43LGIX9W3MWTOCL"
S3_AKS = "tqWXh8kSyxM/QfgF34dMXFJcRrIIGfIIZkVVjSMH"
THREADS = 8
FRAMEID_FILE = r"D:\ke\data\frame_id_sub.tsv"
# SAVE_PATH = r"D:\ke\data\ke_auto"
SAVE_PATH = './test_png/'
MAX_FRAME = 500
s3_client = boto3.client('s3', region_name="cn-north-1", endpoint_url="http://storage.lianjia.com",
                         aws_access_key_id=S3_AK,
                         aws_secret_access_key=S3_AKS)

DATA_PATH = r"D:\ke\data\more_frame_json\11000001063653.json"


def convert_frame_vec2ke_auto(frame_id, ke_auto_file=r'D:\\ka_auto_intpu.json'):
    vector_response = s3_client.get_object(Bucket='frame-eval-image', Key=str(frame_id) + '.json')
    vector_str = vector_response['Body'].read()

    save_path = os.path.join(SAVE_PATH, str(frame_id) + ".png")

    hs = House()
    hs.set_json_str(vector_str)
    ke_utils.update_floorplan(hs.floorplans[0])
    json_dict = ke_utils.get_auto_json(hs.floorplans[0])

    string = json.dumps(json_dict, ensure_ascii=False, indent=4)
    with open(ke_auto_file, 'w') as f:
        f.write(string)


def convert_json_file2ke_auto(json_file, ke_auto_file=r'D:\\ka_auto_intpu.json'):
    hs = House()
    hs.set_json_file(json_file)
    ke_utils.update_floorplan(hs.floorplans[0])
    json_dict = ke_utils.get_auto_json(hs.floorplans[0])

    string = json.dumps(json_dict, ensure_ascii=False, indent=4)
    with open(ke_auto_file, 'w') as f:
        f.write(string)

def single_main(data_path):
    hs = House()
    hs.set_json_file(data_path)
    ke_utils.get_ke_auto_data(hs)
    frameXitems = hs.get_frameXitems()
    frameXjson = hs.get_frameX_json()

    string = json.dumps(frameXjson, ensure_ascii=False)
    with open('./i.json', 'w') as f:
        f.write(string)

    ke_utils.get_img(hs, show=ke_settings.DEBUG, save_path="./i.png")

    # show(hs)
    # hs.saveimg(
    #     img_path='./test/',
    #     frame_id=hs.frame_id,
    #     furniture=hs.fur_list,
    #     title=hs.frame_id
    # )


def show(house, img_path=None):
    frame_id = house.frame_id
    house.show(
        furniture=house.fur_list,
        img_path=img_path,
        title=frame_id
    )


def doctor_draw(data_path):
    url = r'http://127.0.0.1:3737/print'
    f = open(data_path, 'rb')
    j = json.load(f)
    f.close()

    payload = {
        'source': json.dumps(j),
        "imgSize": '256x256',
        "hideFloor": True,
    }

    res = requests.post(url, data=payload)
    # res = requests.post(url, data=payload)
    try:
        obj = json.loads(res.text)
        print("Error: ", res.text)
    except ValueError, e:
        img = Image.open(BytesIO(res.content))
        img.save(r'D:\\img.png')


# def get_img_from_s3(frame_id, s3_client, save_path=None):
def get_img_from_s3(frame_id):
    print(frame_id)
    vector_response = s3_client.get_object(Bucket='frame-eval-image', Key=str(frame_id) + '.json')
    vector_str = vector_response['Body'].read()

    save_path = os.path.join(SAVE_PATH, str(frame_id) + ".png")
    hs = House()
    hs.set_frame_id(frame_id)
    hs.set_json_str(vector_str)
    ke_utils.get_ke_auto_data(hs)
    img = ke_utils.get_img(hs, show=False, save_path=save_path)
    return img


def mutil_main(frame_id_txt):
    settings.PLOT = False
    ke_settings.DEBUG = False
    df = pd.read_csv(frame_id_txt, sep="\t", encoding='cp1252')
    frame_id_list = list(df['frame_id'])
    frame_id_list = frame_id_list[:int(MAX_FRAME)]

    p = Pool(THREADS)

    t0 = time.time()
    res_list = []
    for idx, frame_id in enumerate(frame_id_list):
        # result = get_img_from_s3(frame_id, s3_client, SAVE_PATH)
        result = p.apply_async(get_img_from_s3, args=(frame_id, ))
        res_list.append(result)
    p.close()
    p.join()

    print("total time: ", time.time() - t0)


def diff_frameID():
    df = pd.read_csv(r"D:\ke\data\frame_id.tsv", sep="\t", encoding='cp1252')
    png = pd.read_csv(r"D:\ke\data\png_list.txt", sep="\t", encoding='cp1252')

    frame_all = set(list(df['frame_id']))
    frame_png = set(list(png['frame_id']))
    sub = list(frame_all.difference(frame_png))
    df = pd.DataFrame({ "frame_id": sub })
    df.to_csv(r"D:\sub.csv", index=False)


if __name__ == "__main__":
    files = glob.glob("/Users/lxin/Desktop/摆放测试/*.json")
    for data_path in files:
        # data_path = '/Users/lxin/Desktop/摆放测试/43000001519555.json'
        single_main(data_path)


    # files = glob.glob("/Users/lxin/Desktop/摆放测试/*.json")
    # for data_path in files:
        # data_path = '/Users/lxin/Desktop/摆放测试/43000001519555.json'
        # single_main(data_path)


    # files = glob.glob("/Users/lxin/Desktop/摆放测试/*.json")
    # for data_path in files:
    #     try:
    #         # data_path = '/Users/lxin/Desktop/摆放测试/43000001519555.json'
    #         single_main(data_path)
    #     except Exception as ex:
    #         print data_path,  ex
    #         continue
    #
    # data_path = r"D:\38000006339689.json"
    # single_main(data_path)
    # FRAMEID_FILE = '/Users/lxin/Downloads/baifang-id.tsv'

    # mutil_main(FRAMEID_FILE)
    #
    frame_id = 63000000455682
    # convert_frame_vec2ke_auto(frame_id)

    get_img_from_s3(63000000455682)

    ### demo
    # 11000003499090
    # 11000004005816
    # 11000005438640
    # 11000005799484
    # 11000005926301
    ## 11000006494553
    ## 11000000600497

