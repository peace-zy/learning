# coding=utf-8
import os
import sys
import json

from flask import Flask
from flask import request

os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../"))
sys.path.insert(0, os.getcwd())

import frame_remould.ke_auto.settings as ke_auto_settings
from frame_remould.floorplan import House
import frame_remould.ke_auto.utils as ke_utils

app = Flask(__name__)


def after_request(resp):
    resp.headers['Access-Control-Allow-Origin'] = '*'
    return resp


app.after_request(after_request)


@app.route("/")
def hello():
    return "Hello World!"


@app.route("/ke_auto", methods=['GET', 'POST'])
def ke_auto():
    try:
        fp_vector = request.form.get('vectorValue')
        hs = House()
        hs.set_json_str(fp_vector)
        ke_utils.get_ke_auto_data(hs)
        res = hs.get_frameXitems()
        # res = json.dumps(res)
        res = json.dumps(res, ensure_ascii=False)
        # if ke_auto_settings.DEBUG is True:
        #     frame_vector = json.dumps(hs.get_frameX_json(), ensure_ascii=False)
        #     with open('D:\\frameXjson.json', 'w') as f:
        #         f.write(frame_vector)
    except Exception as error:
        res = {"error: ": error}

    return res


if __name__ == "__main__":
    # app.run(debug=True, host='0.0.0.0', port=7000)
    app.run(host='0.0.0.0', port=7000)