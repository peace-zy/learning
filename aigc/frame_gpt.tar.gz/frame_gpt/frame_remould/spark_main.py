# coding=utf-8
import os
import sys
os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, os.getcwd())
import logging
import sys
import yaml
import datetime
import json

from lib import entity
from frame_remould.utils import spark_util
from frame_remould.floorplan import House


def test_fun(row, **params):
    frame = entity.Frame(row)
    frame_vector = frame.vector
    house = House()
    house.set_json_str(json.dumps(frame_vector))
    res_dict, js_dict = house.run()

    return [frame.frame_id, json.dumps(js_dict)]


def logic_func(driver, raw_df, **params):
    result_rdd = raw_df.rdd.map(lambda row: test_fun(row, **params))
    result_df = driver.rdd_2_df(result_rdd)
    names = params["table_names"]
    result_df = result_df.toDF(*names)
    return result_df


def main():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    if len(sys.argv) < 3:
        logging.error("no less than 2 arguments!")
        sys.exit()
    pt_date = sys.argv[1]
    config_file = sys.argv[2]

    setting_path = os.path.realpath(__file__)
    setting_path = os.path.dirname(setting_path)
    config_file = os.path.join(setting_path, config_file)
    with open(config_file, "r") as f:
        conf = yaml.load(f, Loader=yaml.FullLoader)
    # 从配置文件读取参数
    spark_config_key = "remould_eval_config"
    spark_params = conf.get(spark_config_key, None)
    if spark_params is None:
        logging.error("lack {} in config file".format(spark_config_key))
        sys.exit(1)
    # ## 补充参数
    # pt
    spark_params["sql_params"]["pt_date"] = pt_date
    current_date = datetime.datetime.strptime(pt_date, "%Y%m%d")
    bc_pt_date = (current_date - datetime.timedelta(days=1)).strftime("%Y%m%d")
    spark_params["sql_params"]["bc_pt_date"] = bc_pt_date
    # 自定义逻辑处理方法
    spark_params["logic_params"]["logic_function"] = logic_func
    # 存储pt
    spark_params["save_params"]["partition_params"] = {"pt": "{}000000".format(pt_date)}
    spark_driver = spark_util.SparkSqlDriver(**spark_params)
    spark_driver.run()

if __name__ == "__main__":
    main()