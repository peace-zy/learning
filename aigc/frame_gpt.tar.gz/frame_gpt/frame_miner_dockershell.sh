#!/bin/bash

set -eu

# hdfs 上部署的python环境
HDFS_PYTHON_PATH="hdfs://ns-fed/user/kecv/yudonghai/python.tgz#python"
HDFS_PYTHON_PATH2="hdfs://ns-fed/user/kecv/zhuc/python27.zip#python"
#python"
# 本地python命令
PYTHON_CMD="/home/work/zhucheng011/python/python27/bin/python2"

# 启动日照计算
LIGHTING_SHELL='bin/dockershell/run_lighting.sh'

# 户型聚类脚本
CLUSTERING='bin/dockershell/run_clustering.sh'

# 小区原改脚本
RES_GROUP='bin/dockershell/run_res_group.sh'

# 原改报告脚本
MOD_EVAL='bin/dockershell/run_mod_eval.sh'

# 原改报告脚本(spark)
MOD_EVAL_SPARK='bin/dockershell/run_mod_eval_spark.sh'

# 原改报告脚本(spark)
MOD_EVAL_MERGE_SPARK='bin/dockershell/run_mod_eval_merge_spark.sh'

# 原改报告脚本(spark)
MOD_EVAL_DRAW_SPARK='bin/dockershell/run_mod_eval_draw_spark.sh'

# 计算特征提取脚本
FEATURE_EXTRACT='bin/dockershell/run_feature_extract.sh'

# 户改2.0-第二阶段-发送矢量
PERIOD_2TH_PUSH_VEC_PY_PATH='frame_mod_eval/mod_period/period_2th/mod_2th_spark_main.py'

# 户改2.0-第二阶段-发送矢量-配置
PERIOD_2TH_PUSH_VEC_CONFIG_PATH='frame_mod_eval/mod_period/period_2th/draw_mod_params.yml'

# 户改2.0-第二阶段-收集url
PERIOD_2TH_PULL_URL_PY_PATH='frame_mod_eval/mod_period/period_2th/mod_2th_url_collect_spark_main.py'

# 户改2.0-第二阶段-收集url-配置
PERIOD_2TH_PULL_URL_PY_CONFIG='frame_mod_eval/mod_period/period_2th/mod_2th_url_collect_params.yml'


source bin/utils.sh
# cd frame_miner &&  bash frame_miner_dockershell.sh frame_decoration ${-1d_yyyyMMdd}

######################## frame evaluation #######################
function label_all(){
    # 户型标签一期全量日更
    pt_date=$1

    # shell提交方法
#    spark-submit --py-files lib.zip \
#    --conf spark.dynamicAllocation.maxExecutors=100 \
#    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
#    --conf spark.pyspark.python="python/bin/python" \
#    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
#    --conf spark.pyspark.driver.python=${PYTHON_CMD} \
#    frame_label/spark_main.py "$pt_date" config/frame_label_conf.yml

    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=150 \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_label/spark_main.py "$pt_date" config/frame_label_conf.yml
}

function label_all_v2(){
    # 户型标签一期全量日更
    pt_date=$1
    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_label/label_v2/spark_main_v2.py "$pt_date" frame_label/label_v2/frame_label_conf.yml
}

function frame_clustering(){
    # $1 任务当天PT
    bash ${CLUSTERING} "$1"
}

function frame_mod_eval(){
    # $1 任务当天PT
    bash ${MOD_EVAL} "$1" "$2" "$3"
}

function frame_mod_eval_spark(){
    # $1 任务当天PT
    bash ${MOD_EVAL_SPARK} "$1" "$2" "$3"
}

function frame_mod_eval_merge_spark(){
    # $1 任务当天PT
    bash ${MOD_EVAL_MERGE_SPARK} "$1" "$2" "$3"
}

function frame_mod_eval_draw_spark(){
    # $1 任务当天PT
    bash ${MOD_EVAL_DRAW_SPARK} "$1" "$2"
}

function frame_score(){
    # 户型打分一期全量日更
    pt_date=$1
    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=100 \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_score/frame_score.py "$pt_date" config/frame_score_conf.yml
}

function frame_score_v2(){
    # 二期打分
    pt_date=$1
    spark-submit --py-files lib.zip \
    --master yarn \
    --deploy-mode cluster \
    --executor-memory 5G \
    --conf spark.dynamicAllocation.maxExecutors=300 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH2} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    --conf spark.sql.hive.convertMetastoreOrc=false \
    frame_score/score_v2/spark_main.py -pt_date  "$pt_date" -config_file frame_score/score_v2/score_v2_conf.yml
}

function frame_score_short(){
    # 户型打分一期全量日更(短文案)
    pt_date=$1
    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=100 \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_score/frame_score_short.py "$pt_date" config/frame_score_short_conf.yml
}

function frame_eval_base(){
    # 户型解读基础特征全量日更
    pt_date=$1

    spark-submit --py-files lib.zip \
    --executor-memory 8G \
    --driver-memory 8G \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_eval/feature_base_spark.py "$pt_date" config/eval_base_conf.yml
}

function frame_decoration(){
    # 户型解读基础特征全量日更
    pt_date=$1

    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=120 \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_eval/decoration_spark.py "$pt_date" config/decoration_conf.yml
}

function upload_vector() {
  # 上传矢量值到s3(增量日更子任务)
#  if [ ! -f "./lib/hadoop-aws-2.7.0.jar" ];then
#    wget https://repo1.maven.org/maven2/org/apache/hadoop/hadoop-aws/2.7.0/hadoop-aws-2.7.0.jar -P ./lib
#  fi
#
#  if [ ! -f "./lib/aws-java-sdk-1.7.4.jar" ];then
#    wget https://repo1.maven.org/maven2/com/amazonaws/aws-java-sdk/1.7.4/aws-java-sdk-1.7.4.jar -P ./lib
#  fi

  hadoop fs -get hdfs://ns-fed/user/kecv/zhuc/dockershell/aws-java-sdk-1.7.4.jar  ./lib/.
  hadoop fs -get hdfs://ns-fed/user/kecv/zhuc/dockershell/hadoop-aws-2.7.0.jar  ./lib/.

  pt_date=$1
  spark-submit --py-files lib.zip \
    --master yarn \
    --executor-memory 8G \
    --driver-memory 8G \
    --deploy-mode cluster \
    --conf spark.dynamicAllocation.maxExecutors=300 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --jars lib/hadoop-aws-2.7.0.jar,lib/aws-java-sdk-1.7.4.jar \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_upload/upload_vector.py "$pt_date" config/upload.yml

  rm ./lib/aws-java-sdk-1.7.4.jar
  rm ./lib/hadoop-aws-2.7.0.jar
}

function frame_eval_line_di(){
    # 户型解读动线和可视域特征增量日更
    pt_date=$1
    # 上传矢量数据到S2(增量)
    upload_vector "$pt_date"

    echo "---------- finish upload_vector."

    spark-submit --py-files lib.zip \
    --executor-memory 8G \
    --driver-memory 8G \
    --conf spark.dynamicAllocation.maxExecutors=300 \
    --conf spark.executor.extraJavaOptions="-Xmn3700m" \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_eval/feature_liner_spark_di.py "$pt_date" config/eval_liner_conf.yml
}

function frame_eval_line_da_collect() {
    # 户型解读动线和可视域特征全量日更
    pt_date=$1
    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=120 \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_eval/feature_liner_spark_merge.py "$pt_date" config/eval_liner_conf.yml
}

function upload_draw_feature_di() {
    # 上传绘图特征到redis(增量日更子任务)
    pt_date=$1
    spark-submit --py-files lib.zip \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_eval/feature_draw_spark_di.py "$pt_date" config/upload.yml
}

function frame_eval_final(){
    # 户型解读二期评分和文案生成全量日更
    pt_date=$1
    # 上传绘图特征
    upload_draw_feature_di "$pt_date"
    # 标签生成任务
    # 使用自行打包的python环境，有集成的必需包
    spark-submit --py-files lib.zip \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_eval/eval_spark.py "$pt_date" config/eval_conf.yml
}

function frame_eval_plus(){
    # 户型解读二期评分和文案生成全量日更
    pt_date=$1
    # 标签生成任务
    # 使用自行打包的python环境，有集成的必需包
    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=120 \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_eval/eval_spark.py "$pt_date" config/eval_plus_conf.yml
}

function api_short_update() {
    # 更新户型解读简介api 全量日更
    pt_date=$1
    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=120 \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_eval/feature_api_spark.py "$pt_date" 0 config/eval_api.yml
}

function api_full_update() {
    # 更新户型解读全文api 全量日更
    pt_date=$1
    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_eval/feature_api_spark.py "$pt_date" 1 config/eval_api.yml
}

function resblock_eval_feature() {
    # 小区户型解读特征日更
    pt_date=$1

    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=100 \
    --master yarn \
    --deploy-mode cluster \
    --executor-memory 14G \
    --driver-memory 10G \
    --executor-cores 3 \
    --conf spark.sql.shuffle.partitions=300 \
    --conf spark.default.parallelism=300 \
    --conf spark.shuffle.memoryFraction=0.6 \
    --conf spark.storage.memoryFraction=0.2 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    resblock_eval/resblock_eval_feature.py "$pt_date" config/resblock_eval_conf.yml
}

function newhouse_v2() {
    pt_date=$1
    rm -f frame_eval/newhouse_v2/all_newhouse_frame.tsv
    hadoop fs -get /user/kecv/zhuc/dockershell/all_newhouse_frame.tsv frame_eval/newhouse_v2/all_newhouse_frame.tsv
    ls frame_eval/newhouse_v2
    zip -q -r ./lib.zip ./*

    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_eval/newhouse_v2/spark_main.py "$pt_date" frame_eval/newhouse_v2/conf_newhouse_v2.yml

    python frame_eval/newhouse_v2/get_all_newhouse_frame.py \
    --pt_data "$pt_date" \
    --sql_file frame_eval/newhouse_v2/get_all_newhouse_frame.sql

    hadoop fs -put -f frame_eval/newhouse_v2/all_newhouse_frame.tsv /user/kecv/zhuc/dockershell/.
}

function newhouse_qa() {
    pt_date=$1

    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_eval/newhouse_QA/spark_main.py -pt_date  "$pt_date" -config_file frame_eval/newhouse_QA/conf_newhouse_QA.yml
}

function newhouse_qa_v2() {
    pt_date=$1

    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_eval/newhouse_QA_v2/spark_main.py -pt_date  "$pt_date" -config_file frame_eval/newhouse_QA_v2/conf_newhouse_QA.yml
}

function newhousev2_frame_compare() {
    pt_date=$1

    spark-submit --py-files lib.zip \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_eval/newhouse_v2/frame_compare_spark_main.py "$pt_date" frame_eval/newhouse_v2/frame_compare_conf.yml
}

function ershou_resblock_frame_eval() {
    pt_date=$1

    spark-submit --py-files lib.zip \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    resblock_eval/ershou_resblock_frame/spark_main.py "$pt_date" resblock_eval/ershou_resblock_frame/conf.yml
}

function update_frame_vec_all() {
    pt_date=$1
    old_date=`date +'%F'` # 任务执行时间之前的数据删除
    spark-submit --py-files lib.zip \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.dynamicAllocation.maxExecutors=100 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_search/update_frame_vec_all.py "$pt_date" config/frame_search_all_conf.yml

    curl --location --request POST 'http://self-service.search.ke.com/spark/hive/es/direct' \
    --header 'Content-Type: application/json' \
    --header 'Cookie: lianjia_uuid=9f64cd22-880e-4628-b027-39ef7cefee47; lianjia_ssid=ae9b1c31-3480-473e-b7fe-0c64e283ccc7' \
    --data '{
        "expired": "'${old_date}' 00:00:00",
        "alarmUserCode": "20375270|26025531",
        "env": "prod",
        "index": "1047901001",
        "db": "data_mining",
        "table": "data_mining_frame_vec_feature_da",
        "pt": "'${pt_date}'000000",
        "bizIdField": "housedel_id",
        "fieldsMap": {
            "housedel_id": "housedelId",
            "bizcircle_id": "bizcircleId",
            "city_code": "cityCode",
            "house_id": "houseId",
            "frame_id": "frameId",
            "resblock_id": "resblockId",
            "district_code": "districtCode",
            "floor_area": "floorArea",
            "inside_area": "insideArea",
            "frame_size": "frameSize",
            "frame_label": "frameLabel",
            "t_shi": "tShi",
            "mass_layout_lst": "massLayoutLst"
        }
    }'

}

function update_decoration_frame_vec() {
    pt_date=$1
    old_date=`date +'%F'` # 任务执行时间之前的数据删除
    spark-submit --py-files lib.zip \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_search/update_decoration_vec.py "$pt_date" config/decoration_vec_conf.yml

    curl --location --request POST 'http://self-service.search.ke.com/spark/hive/es/direct' \
    --header 'Content-Type: application/json' \
    --header 'Cookie: lianjia_uuid=9f64cd22-880e-4628-b027-39ef7cefee47; lianjia_ssid=20f61709-857e-42c6-98d4-f9ffe327c512' \
    --data '{
        "expired": "'${old_date}' 00:00:00",
        "alarmUserCode": "20375270",
        "env": "prod",
        "index": "1047901002",
        "db": "data_mining",
        "table": "data_mining_frame_decoration_vec_feature_da",
        "pt": "'${pt_date}'000000",
        "bizIdField": "id",
        "fieldsMap": {
            "housedel_id": "housedelId",
            "bizcircle_id": "bizcircleId",
            "city_code": "cityCode",
            "house_id": "houseId",
            "frame_id": "frameId",
            "resblock_id": "resblockId",
            "district_code": "districtCode",
            "floor_area": "floorArea",
            "inside_area": "insideArea",
            "frame_size": "frameSize",
            "frame_label": "frameLabel",
            "t_shi": "tShi",
            "mass_layout_lst": "massLayoutLst",
            "type_label": "typeLabel",
            "edge_lst": "edgeLst"
        }
    }'
}

function update_decoration_vec_redis(){
    pt_date=$1
    echo $1
    echo $2
    spark-submit --py-files lib.zip \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_search/update_decoration_vec_redis.py "$pt_date" config/decoration_vec_conf.yml "$2"
}

function frame_tag_lib_feature() {
    pt_date=$1
    city_code=$2
    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --conf spark.sql.hive.convertMetastoreOrc=false \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_eval/frame_tag_lib/spark_main_feature.py frame_eval/frame_tag_lib/conf.yml "$pt_date" "$city_code"
}

function rpt_frame_tag_lib() {
    last_pt=$(get_nearst_pt data_mining.data_mining_frame_tag_lib_da)
    pt_date=$1

    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_eval/frame_tag_lib/spark_main_deco_rpt.py frame_eval/frame_tag_lib/doc.yml "$pt_date" "$last_pt"
}

function frame_compare_v2_newhouse() {
    pt_date=$1
    hot_pt_date=$(get_nearst_pt ai_content.ai_content_new_house_similarity_ma)

    spark-submit --py-files lib.zip \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH2} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_eval/frame_compare/newhouse_spark_main_v2.py -hot_pt_date ${hot_pt_date}
}

function sh_demo_content(){
    # 二手户型新demo页内容
    pt_date=$1

    spark-submit --py-files lib.zip \
    --conf spark.yarn.executor.memoryOverhead=7G \
    --conf spark.dynamicAllocation.maxExecutors=200 \
    --master yarn \
    --deploy-mode cluster \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    frame_mod_eval/secondhand_mod/demo_spark_main.py -pt_date  "$pt_date" \
    -config_file frame_mod_eval/secondhand_mod/demo_conf.yml
}

function frame_feature_extractor(){
    # 执行计算特征提取脚本 2019-11-11
    # $1 任务当天PT $2 相对增量的PT
    bash ${FEATURE_EXTRACT} "$1" "$2"
}

function run_lighting(){
    # 执行光照计算
    bash ${LIGHTING_SHELL} $1
}

function frame_res_group(){
    # $1 任务当天PT
    bash ${RES_GROUP} "$1"
}

function second_hand_mod_eval() {
    pt_date=$1

    cluster_last_pt=$(get_nearst_pt data_mining.data_mining_frame_cluster_v3_da)

    spark-submit --py-files lib.zip \
    --master yarn \
    --deploy-mode cluster \
    --executor-memory 10G \
    --driver-memory 10G \
    --conf spark.dynamicAllocation.maxExecutors=300 \
    --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH2} \
    --conf spark.pyspark.python="python/bin/python" \
    --conf spark.sql.storeAssignmentPolicy="LEGACY" \
    --conf spark.sql.hive.convertMetastoreOrc=false \
    --conf "spark.executor.extraJavaOptions=-verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps" \
    --conf "spark.driver.extraJavaOptions=-verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps" \
    frame_mod_eval/secondhand_mod/sh_mod_eval_spark.py -cluster_last_pt ${cluster_last_pt} -pt_date ${pt_date} \
                     -config_file frame_mod_eval/mod_period/period_2th/draw_mod_params.yml \

}


function period_2th_collect_url(){
    # 第二阶段收集画完的URL
    # $1 任务当天PT
    spark-submit --py-files lib.zip \
                 --master yarn \
                 --deploy-mode cluster \
                 --driver-memory 10G \
                 --executor-memory 10G \
                 --conf spark.dynamicAllocation.maxExecutors=200 \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH2} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.sql.storeAssignmentPolicy="LEGACY" \
                 --conf spark.sql.hive.convertMetastoreOrc=false \
    "${PERIOD_2TH_PULL_URL_PY_PATH}" -pt_date "$1" -config_file ${PERIOD_2TH_PULL_URL_PY_CONFIG}
}


function period_2th_push_vec(){
    pt_date=$1
    last_pt_date=$2
    spark-submit --py-files lib.zip \
                 --executor-memory 10G \
                 --conf spark.dynamicAllocation.maxExecutors=200 \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.pyspark.driver.python=${PYTHON_CMD}\
    "${PERIOD_2TH_PUSH_VEC_PY_PATH}" -pt_date "${pt_date}" -last_pt_date "${last_pt_date}" \
                 -config_file "${PERIOD_2TH_PUSH_VEC_CONFIG_PATH}"
}


function frame_mod_eval_first_period(){
    pt_date=$1
    city_code=$2
    spark_config_key=$3

    if [ "$spark_config_key" = "dec_toB" ]; then
        config_file=frame_mod_eval/mod_toB/collect_mod_toB_params.yml
        sql_file=frame_mod_eval/mod_toB/collect_mod_toB_data.sql
    elif [ "$spark_config_key" = "secondhand_toC" ]; then
        config_file=frame_mod_eval/mod_ershou/collect_mod_ershou_params.yml
        sql_file=frame_mod_eval/mod_ershou/collect_mod_ershou_data.sql
    fi

    spark-submit --py-files lib.zip \
                 --master yarn \
                 --deploy-mode cluster \
                 --num-executors 100 \
                 --executor-memory 14G \
                 --driver-memory 10G \
                 --executor-cores 2 \
                 --conf spark.dynamicAllocation.maxExecutors=180 \
                 --conf spark.sql.shuffle.partitions=1230 \
                 --conf spark.default.parallelism=940 \
                 --conf spark.shuffle.memoryFraction=0.55 \
                 --conf spark.storage.memoryFraction=0.25 \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH2} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.sql.storeAssignmentPolicy="LEGACY" \
                 --conf spark.sql.hive.convertMetastoreOrc=false \
    frame_mod_eval/mod_period/period_1th/mod_1th_spark_main.py \
                 -pt_date "${pt_date}" \
                 -city_code "${city_code}" \
                 -config_file ${config_file} \
                 -sql_file ${sql_file} \
                 -spark_config_key "${spark_config_key}"
}

function frame_mod_eval_PushRedis(){
    pt_date=$1
    last_pt_date=$2
    # spark_config_key是业务标识的字符串，通过该参数会自动修改sql文件下的inner_table
    spark_config_key=$3

    spark-submit --py-files lib.zip \
                 --executor-memory 10G \
                 --master yarn \
                 --deploy-mode cluster \
                 --driver-memory 10G \
                 --conf spark.dynamicAllocation.maxExecutors=200 \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH2} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.sql.storeAssignmentPolicy="LEGACY" \
                 --conf spark.sql.hive.convertMetastoreOrc=false \
    frame_mod_eval/mod_period/period_2th/mod_2th_spark_main.py \
                 -pt_date "${pt_date}" \
                 -last_pt_date "${last_pt_date}" \
                 -config_file frame_mod_eval/mod_period/period_2th/draw_mod_params.yml \
                 -sql_file frame_mod_eval/mod_period/period_2th/draw_mod_data.sql \
                 -spark_config_key "${spark_config_key}"
}

function frame_mod_eval_PullRedis(){
    # 第二阶段收集画完的URL
    pt_date=$1
    spark-submit --py-files lib.zip \
                 --executor-memory 10G \
                 --master yarn \
                 --deploy-mode cluster \
                 --driver-memory 10G \
                 --conf spark.dynamicAllocation.maxExecutors=200 \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH2} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.sql.storeAssignmentPolicy="LEGACY" \
                 --conf spark.sql.hive.convertMetastoreOrc=false \
    frame_mod_eval/mod_period/period_2th/mod_2th_url_collect_spark_main.py \
                 -pt_date "${pt_date}" \
                 -config_file frame_mod_eval/mod_period/period_2th/mod_2th_url_collect_params.yml
}

function frame_mod_eval_third_period(){
    pt_date=$1
    city_code=$2
    # spark_config_key是业务标识的字符串
    spark_config_key=$3

    if [ "$spark_config_key" = "dec_toB" ]; then
        config_file=frame_mod_eval/mod_toB/merge_mod_toB_params.yml
        sql_file=frame_mod_eval/mod_toB/merge_mod_toB_data.sql
    elif [ "$spark_config_key" = "secondhand_toC" ]; then
        config_file=frame_mod_eval/mod_ershou/merge_mod_ershou_params.yml
        sql_file=frame_mod_eval/mod_ershou/merge_mod_ershou_data.sql
    elif [ "$spark_config_key" = "dec_bigC" ]; then
        config_file=frame_mod_eval/mod_bigC/merge_mod_bigC_params.yml
        sql_file=frame_mod_eval/mod_bigC/merge_mod_bigC_data.sql
    fi

    spark-submit --py-files lib.zip \
                 --executor-memory 10G \
                 --master yarn \
                 --deploy-mode cluster \
                 --driver-memory 10G \
                 --conf spark.dynamicAllocation.maxExecutors=200 \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH2} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.sql.storeAssignmentPolicy="LEGACY" \
                 --conf spark.sql.hive.convertMetastoreOrc=false \
    frame_mod_eval/mod_period/period_3th/mod_3th_spark_main.py \
                 -pt_date "${pt_date}" \
                 -city_code "${city_code}" \
                 -config_file ${config_file} \
                 -sql_file ${sql_file} \
                 -spark_config_key "${spark_config_key}"
}

function frame_eval_groupC_v1() {
    pt_date=$1
    city_code=$2

    spark-submit --py-files lib.zip \
                 --executor-memory 10G \
                 --master yarn \
                 --deploy-mode cluster \
                 --driver-memory 10G \
                 --conf spark.dynamicAllocation.maxExecutors=200 \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH2} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.sql.storeAssignmentPolicy="LEGACY" \
                 --conf spark.sql.hive.convertMetastoreOrc=false \
    frame_eval/group_toC_v1/spark_main.py \
                 -pt_date "${pt_date}" \
                 -city_code "${city_code}" \
                 -config_file frame_eval/group_toC_v1/decoration_conf.yml \
                 -sql_file frame_eval/group_toC_v1/frame_decoration_da.sql
}


function room_rendering() {
    pt_date=$1
    city_code=$2

    spark-submit --py-files lib.zip \
                 --executor-memory 10G \
                 --master yarn \
                 --deploy-mode cluster \
                 --driver-memory 10G \
                 --conf spark.dynamicAllocation.maxExecutors=200 \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH2} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.sql.storeAssignmentPolicy="LEGACY" \
                 --conf spark.sql.hive.convertMetastoreOrc=false \
                 --files frame_eval/room_rendering/room_rendering_class.csv \
    frame_eval/room_rendering/spark_main.py \
                 -pt_date "${pt_date}" \
                 -city_code "${city_code}" \
                 -config_file frame_eval/room_rendering/room_rendering.yml
}

function room_rendering_v2() {
    pt_date=$1
    city_code=$2

    spark-submit --py-files lib.zip \
                 --executor-memory 10G \
                 --master yarn \
                 --deploy-mode cluster \
                 --driver-memory 10G \
                 --conf spark.dynamicAllocation.maxExecutors=200 \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH2} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.sql.storeAssignmentPolicy="LEGACY" \
                 --conf spark.sql.hive.convertMetastoreOrc=false \
                 --files frame_eval/room_rendering_v2/room_rendering_class_drop_duplicates.csv \
    frame_eval/room_rendering_v2/spark_main.py \
                 -pt_date "${pt_date}" \
                 -city_code "${city_code}" \
                 -config_file frame_eval/room_rendering_v2/room_rendering.yml
}

function GetRoomLabel() {
    pt_date=$1
    city_code=$2

    spark-submit --py-files lib.zip \
                 --executor-memory 10G \
                 --master yarn \
                 --deploy-mode cluster \
                 --driver-memory 10G \
                 --conf spark.dynamicAllocation.maxExecutors=200 \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH2} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.sql.storeAssignmentPolicy="LEGACY" \
                 --conf spark.sql.hive.convertMetastoreOrc=false \
    frame_eval/room_label/spark_main.py \
                 -pt_date "${pt_date}" \
                 -city_code "${city_code}" \
                 -config_file frame_eval/room_label/room_label_conf.yml
}

function inspired_album() {
    pt_date=$1
    city_code=$2

    spark-submit --py-files lib.zip \
                 --executor-memory 10G \
                 --master yarn \
                 --deploy-mode cluster \
                 --driver-memory 10G \
                 --conf spark.dynamicAllocation.maxExecutors=500 \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH2} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.sql.hive.convertMetastoreOrc=false \
                 --files frame_eval/inspired_album/beauty_info_drop_duplicates.csv \
    frame_eval/inspired_album/spark_main.py \
                 -pt_date "${pt_date}" \
                 -city_code "${city_code}" \
                 -config_file frame_eval/inspired_album/inspired_album.yml
}

function inspired_album_v2() {
    pt_date=$1
    city_code=$2

    spark-submit --py-files lib.zip \
                 --executor-memory 10G \
                 --master yarn \
                 --deploy-mode cluster \
                 --driver-memory 10G \
                 --conf spark.dynamicAllocation.maxExecutors=500 \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH2} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.sql.hive.convertMetastoreOrc=false \
                 --conf spark.driver.maxResultSize=4096M \
                 --files frame_eval/inspired_album_v2/beauty_info_drop_duplicates.csv \
    frame_eval/inspired_album_v2/spark_main.py \
                 -pt_date "${pt_date}" \
                 -city_code "${city_code}" \
                 -config_file frame_eval/inspired_album_v2/inspired_album.yml
}

function frame_mod_beiwo () {
    pt_date=$1

    spark-submit --py-files lib.zip \
                 --master yarn \
                 --deploy-mode cluster \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH2} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.sql.hive.convertMetastoreOrc=false \
    frame_mod_eval/mod_beiwo/spark_main.py \
                 -pt_date "${pt_date}" \
                 -config_file frame_mod_eval/mod_beiwo/mod_beiwo.yml
}

function frame_mod_ershou_cun () {
    pt_date=$1

    spark-submit --py-files lib.zip \
                 --master yarn \
                 --deploy-mode cluster \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH2} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.sql.hive.convertMetastoreOrc=false \
    frame_mod_eval/mod_ershou/v2/spark_main_cun.py \
                 -pt_date "${pt_date}" \
                 -config_file frame_mod_eval/mod_ershou/v2/mod_ershou_cun.yml
}

function newhouse_v2_label () {
    pt_date=$1

    spark-submit --py-files lib.zip \
                 --master yarn \
                 --deploy-mode cluster \
                 --conf spark.yarn.dist.archives=${HDFS_PYTHON_PATH2} \
                 --conf spark.pyspark.python="python/bin/python" \
                 --conf spark.sql.hive.convertMetastoreOrc=false \
    frame_eval/newhouse_label/newhouse_label_main.py \
                 -pt_date "${pt_date}" \
                 -config_file frame_eval/newhouse_label/conf_newhouse_label.yml
}


PROJECT_TITLE="
  ______                       __   __
 |  ____|                      \\ \\ / /
 | |__ _ __ __ _ _ __ ___   ___ \\ V /
 |  __| '__/ _' | '_ ' _ \\ / _ \\ > <
 | |  | | | (_| | | | | | |  __// . \\
 |_|  |_|  \\__,_|_| |_| |_|\\___/_/ \\_\\
"
KE_TITLE="
  _  ________   _____ ____  __  __
 | |/ /  ____| / ____/ __ \\|  \\/  |
 | ' /| |__   | |   | |  | | \\  / |
 |  < |  __|  | |   | |  | | |\\/| |
 | . \\| |____ | |___| |__| | |  | |
 |_|\\_\\______(_)_____\\____/|_|  |_|

"

function usage {
    echo "usage:"
    echo "bash frame_miner.sh <job_name> [job_params...]"
    exit 1
}

function main
{
    echo """${PROJECT_TITLE}"""
    echo """${KE_TITLE}"""
    if [[ $# -lt 1 ]] ; then
        echo "error! lack <job_name>"
        usage
    fi
    job_name=$1
    echo "TASK: ${job_name}  "

    zip -q -r ./lib.zip ./*

    case ${job_name} in

        label_all )
        pt_date=$2
        label_all "$pt_date"
        ;;

        label_all_v2 )
        pt_date=$2
        label_all_v2 "$pt_date"
        ;;

        frame_score )
        pt_date=$2
        frame_score "$pt_date"
        ;;

        frame_score_v2 )
        pt_data=$2
        frame_score_v2 "$pt_data"
        ;;

        frame_score_short )
        pt_date=$2
        frame_score_short "$pt_date"
        ;;

        frame_eval_base )
        pt_date=$2
        frame_eval_base ${pt_date}
        ;;

        frame_decoration )
        pt_date=$2
        frame_decoration ${pt_date}
        ;;

        frame_eval_line_di )
        pt_date=$2
        frame_eval_line_di ${pt_date}
        ;;

        frame_eval_line_da_collect )
        pt_date=$2
        frame_eval_line_da_collect ${pt_date}
        ;;

        frame_eval_final )
        pt_date=$2
        frame_eval_final ${pt_date}
        ;;

        frame_eval_plus)
        pt_date=$2
        frame_eval_plus ${pt_date}
        ;;

        api_full_update )
        pt_date=$2
        api_full_update ${pt_date}
        ;;

        api_short_update )
        pt_date=$2
        api_short_update ${pt_date}
        ;;

        resblock_eval_feature )
        pt_date=$2
        resblock_eval_feature ${pt_date}
        ;;

        newhouse_v2 )
        pt_date=$2
        newhouse_v2 ${pt_date}
        ;;

        newhouse_qa )
        pt_date=$2
        newhouse_qa ${pt_date}
        ;;

        newhouse_qa_v2 )
        pt_date=$2
        newhouse_qa_v2 ${pt_date}
        ;;

        newhousev2_frame_compare )
        pt_date=$2
        newhousev2_frame_compare ${pt_date}
        ;;

        ershou_resblock_frame_eval )
        pt_date=$2
        ershou_resblock_frame_eval ${pt_date}
        ;;

        frame_lighting )
        pt_date=$2
        run_lighting ${pt_date}
        ;;

        frame_mod_eval )
        pt_date=$2
        cpu_cnt=$3
        image_last_pt=$4
        frame_mod_eval ${pt_date} ${cpu_cnt} ${image_last_pt}
        ;;

        frame_mod_eval_spark )
        pt_date=$2
        city_code=$3
        report_last_pt=$4
        frame_mod_eval_spark ${pt_date} ${city_code} ${report_last_pt}
        ;;

        frame_mod_eval_merge_spark )
        pt_date=$2
        last_final_report_date=$3
        last_image_date=$4
        frame_mod_eval_merge_spark ${pt_date} ${last_final_report_date} ${last_image_date}
        ;;

        frame_mod_eval_draw_spark )
        pt_date=$2
        last_image_date=$3
        frame_mod_eval_draw_spark ${pt_date} ${last_image_date}
        ;;

        frame_feature_extractor )
        pt_date=$2
        # 相对特征增量的PT
        relative_group_pt=$3
        frame_feature_extractor ${pt_date} ${relative_group_pt}
        ;;

        frame_res_group )
        pt_date=$2
        frame_res_group ${pt_date}
        ;;

        update_frame_vec_all )
        pt_date=$2
        update_frame_vec_all ${pt_date}
        ;;

        update_decoration_frame_vec )
        pt_date=$2
        update_decoration_frame_vec ${pt_date}
        ;;

        update_decoration_vec_redis )
        pt_date=$2
        update_decoration_vec_redis ${pt_date} $3
        ;;

        frame_tag_lib_feature )
        pt_date=$2
        city_code=$3
        frame_tag_lib_feature ${pt_date} ${city_code}
        ;;

        rpt_frame_tag_lib )
        pt_date=$2
        rpt_frame_tag_lib ${pt_date}
        ;;

        frame_compare_v2_newhouse)
        pt_date=$2
        frame_compare_v2_newhouse ${pt_date}
        ;;

        sh_demo_content)
        pt_date=$2
        sh_demo_content ${pt_date}
        ;;


        second_hand_mod_eval )
        pt_date=$2
        second_hand_mod_eval ${pt_date}
        ;;

        period_2th_push_vec )
        pt_data=$2
        last_pt_date=$3
        period_2th_push_vec "$pt_data" "$last_pt_date"
        ;;

        period_2th_collect_url )
        pt_date=$2
        period_2th_collect_url "$pt_date"
        ;;

        frame_mod_eval_first_period )
        pt_date=$2
        city_code=$3
        spark_config_key=$4
        frame_mod_eval_first_period "$pt_date" "$city_code" "$spark_config_key"
        ;;

        frame_mod_eval_PushRedis )
        pt_date=$2
        last_pt_date=$3
        spark_config_key=$4
        frame_mod_eval_PushRedis "$pt_date" "$last_pt_date" "$spark_config_key"
        ;;

        frame_mod_eval_PullRedis )
        pt_date=$2
        frame_mod_eval_PullRedis "$pt_date"
        ;;

        frame_mod_eval_third_period )
        pt_date=$2
        city_code=$3
        spark_config_key=$4
        frame_mod_eval_third_period "$pt_date" "$city_code" "$spark_config_key"
        ;;

        GetRoomLabel )
        pt_date=$2
        city_code=$3
        GetRoomLabel "$pt_date" "$city_code"
        ;;

        frame_eval_groupC_v1 )
        pt_data=$2
        city_code=$3
        frame_eval_groupC_v1 "$pt_data" "$city_code"
        ;;

        room_rendering )
        pt_date=$2
        city_code=$3
        room_rendering "$pt_date" "$city_code"
        ;;

        room_rendering_v2 )
        pt_date=$2
        city_code=$3
        room_rendering_v2 "$pt_date" "$city_code"
        ;;

        inspired_album )
        pt_data=$2
        city_code=$3
        inspired_album "$pt_data" "$city_code"
        ;;

        inspired_album_v2 )
        pt_data=$2
        city_code=$3
        inspired_album_v2 "$pt_data" "$city_code"
        ;;

        frame_mod_beiwo )
        pt_data=$2
        frame_mod_beiwo "$pt_data"
        ;;

        frame_mod_ershou_cun )
        pt_data=$2
        frame_mod_ershou_cun "$pt_data"
        ;;

        newhouse_v2_label )
        pt_data=$2
        newhouse_v2_label "$pt_data"
        ;;

        * )
        echo "error! invalid <job_name>"
        usage
        ;;
    esac

    rm -f lib.zip
}

main $*
