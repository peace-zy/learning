#!/bin/bash
python gradio_vlchat.py.bk --server-name 10.201.225.29 --server-port 8006 --share
