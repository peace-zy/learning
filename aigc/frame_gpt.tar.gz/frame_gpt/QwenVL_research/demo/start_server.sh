#!/bin/bash
PYTHON_BIN="/mnt/aigc_cb_v2/zhangyan461/env/miniconda3/envs/pytorch_2.1.0_cu12.1_py3.11_qwen_vl/bin/python"
CUDA_VISIBLE_DEVICES=3 ${PYTHON_BIN} server.py
