# 模型评估
## 生成
sh infer_frame_des.sh

## 评估
sh eval_floor_plan.sh

