#!/bin/bash
PYTHON_BIN=/data/nfs-ten9/nfs/zhangyan461/env/pytorch_2.1.0_cu12.1_py3.11_qwen_vl/bin/python
#${PYTHON_BIN} infer_floor_plan.py --checkpoint ../output_qwen_sekuai_des_align_zero2_a800_vit_on_cosine_2048_ep1/checkpoint-4500 --output output_qwen_sekuai_des_align_zero2_a800_vit_on_cosine_2048_ep1_checkpoint-4500 --infile ../../dataset/sekuai_des/qwen_format_test_sekuai_des.json
checkpoint=../output_qwen_frame_des_align_zero2_h800_vit_off_cosine_2048_ep1/checkpoint-4000
${PYTHON_BIN} -m torch.distributed.launch --use-env \
    --nproc_per_node ${NPROC_PER_NODE:-8} \
    --nnodes ${WORLD_SIZE:-1} \
    --node_rank ${RANK:-0} \
    --master_addr ${MASTER_ADDR:-127.0.0.1} \
    --master_port ${MASTER_PORT:-12346} \
    infer_floor_plan_batch_chat.py \
    --checkpoint $checkpoint \
    --infile ../../dataset/frame_des/frame_des/qwen_format_test_frame_des.json \
    --output infer_out/output_qwen_frame_des_align_zero2_a800_vit_off_cosine_2048_ep1_checkpoint-4000 \
    --batch-size 8 \
    --num-workers 8
