echo "\033[32mword\033[0m"
python eval_floor_plan.py --dataset sekuai --standardization --cut_mode phrase --save_path debug --submit --res_file Qwen-VL-Chat-sekuai_des_align_zero2_a800_vit_on_cosine_2048_ep1/res_d.json --gt_file /aistudio/workspace/qwen_train/dataset/sekuai_des/qwen_format_test_sekuai_des.json
