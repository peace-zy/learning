#!/bin/bash
#/aistudio/workspace/qwen_train/env/pytorch_2.1.0_cu12.1_py3.11_qwen_vl/bin/python eval.py
/data/nfs-ten9/nfs/zhangyan461/env/pytorch_2.1.0_cu12.1_py3.11_qwen_vl/bin/python eval.py
