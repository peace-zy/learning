#-*-coding: utf-8-*-

import sys
import os
from tqdm import tqdm

from transformers import AutoModelForCausalLM, AutoTokenizer
from transformers.generation import GenerationConfig

version = sys.version_info.major
if version >= 3:
    import importlib
    importlib.reload(sys)
elif version >= 2:
    reload(sys)
    sys.setdefaultencoding('utf8')
print(sys.getdefaultencoding())


checkpoint = '/aistudio/workspace/qwen_train/Qwen-VL/output_qwen/checkpoint-2000'
checkpoint = '/aistudio/workspace/qwen_train/Qwen-VL/output_qwen/checkpoint-1000'
checkpoint = '/aistudio/workspace/qwen_train/Qwen-VL/output_qwen/checkpoint-2000'
checkpoint = '/aistudio/workspace/qwen_train/Qwen-VL/output_qwen/checkpoint-3000'
checkpoint = '/aistudio/workspace/qwen_train/Qwen-VL/output_qwen/checkpoint-4000'
checkpoint = '/aistudio/workspace/qwen_train/Qwen-VL/output_qwen/checkpoint-6000'
checkpoint = '/data/nfs-ten9/nfs/zhangyan461/models/output_qwen_new_llava'
checkpoint = '/data/nfs-ten9/nfs/zhangyan461/models/checkpoint-2000'
checkpoint = "/aistudio/workspace/qwen_train/Qwen-VL/output_qwen_frame_des_align_zero2_h800_vit_on_cosine_2048_ep1/checkpoint-4000"
checkpoint = "/aistudio/workspace/qwen_train/Qwen-VL/output_qwen_frame_des_align_zero2_h800_vit_off_cosine_2048_ep1/checkpoint-4000"

#checkpoint = '/mnt/aigc_chubao/zhangyan461/models/Qwen/Qwen-VL-Chat'
tokenizer = AutoTokenizer.from_pretrained(checkpoint, trust_remote_code=True)
model = AutoModelForCausalLM.from_pretrained(
    checkpoint, device_map='cuda', trust_remote_code=True).eval()

model.generation_config = GenerationConfig.from_pretrained(checkpoint, trust_remote_code=True)
model.generation_config.top_p = 0.01


root = 'Your_Results'
output = 'Qwen-VL-Chat-finetune-2000'
output = 'Qwen-VL-Chat-finetune-1000'
output = 'Qwen-VL-Chat-finetune-2000-a100'
output = 'Qwen-VL-Chat-finetune-3000-a100'
output = 'Qwen-VL-Chat-finetune-4000-a100'
output = 'Qwen-VL-Chat-finetune-5000-a100'
output = 'Qwen-VL-Chat-finetune-6000-a100'
output = 'Qwen-VL-Chat-finetune-llava-a800'
output = 'Qwen-VL-Chat-finetune-2000-a800'
output = 'Qwen-VL-Chat-frame_des-h800'
output = 'Qwen-VL-Chat-frame_des-h800-vit-off'
#output = 'Qwen-VL-Chat-a100'
os.makedirs(output, exist_ok=True)
for filename in os.listdir(root):
    print(os.path.join(root, filename))
    with open(os.path.join(root, filename), 'r', encoding="utf-8") as fin, open(os.path.join(output, filename), 'w', encoding="utf-8") as fout:
        lines = fin.read().splitlines()
        filename = filename.replace('.txt', '')
        for line in tqdm(lines):
            img, question, gt = line.strip().split('\t')
            img_path = os.path.join('images', filename, img)
            assert os.path.exists(img_path), img_path
            #query = f'<img>{img_path}</img>\n{question}'
            query = f'<qwen_vl_img>{img_path}</qwen_vl_img>\n{question}'
            response, _ = model.chat(tokenizer, query=query, history=None)
            print(img, question, gt, response, sep='\t', file=fout)
